<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-01 08:45:17 --> Config Class Initialized
INFO - 2023-05-01 08:45:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:17 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:17 --> URI Class Initialized
DEBUG - 2023-05-01 08:45:17 --> No URI present. Default controller set.
INFO - 2023-05-01 08:45:17 --> Router Class Initialized
INFO - 2023-05-01 08:45:17 --> Output Class Initialized
INFO - 2023-05-01 08:45:17 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:17 --> Input Class Initialized
INFO - 2023-05-01 08:45:17 --> Language Class Initialized
INFO - 2023-05-01 08:45:17 --> Language Class Initialized
INFO - 2023-05-01 08:45:17 --> Config Class Initialized
INFO - 2023-05-01 08:45:17 --> Loader Class Initialized
INFO - 2023-05-01 08:45:17 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:17 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:17 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:17 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:18 --> Controller Class Initialized
INFO - 2023-05-01 08:45:18 --> Config Class Initialized
INFO - 2023-05-01 08:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:18 --> URI Class Initialized
INFO - 2023-05-01 08:45:18 --> Router Class Initialized
INFO - 2023-05-01 08:45:18 --> Output Class Initialized
INFO - 2023-05-01 08:45:18 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:18 --> Input Class Initialized
INFO - 2023-05-01 08:45:18 --> Language Class Initialized
INFO - 2023-05-01 08:45:18 --> Language Class Initialized
INFO - 2023-05-01 08:45:18 --> Config Class Initialized
INFO - 2023-05-01 08:45:18 --> Loader Class Initialized
INFO - 2023-05-01 08:45:18 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:18 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:18 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:18 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:18 --> Controller Class Initialized
DEBUG - 2023-05-01 08:45:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 08:45:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:45:18 --> Final output sent to browser
DEBUG - 2023-05-01 08:45:18 --> Total execution time: 0.0891
INFO - 2023-05-01 08:45:30 --> Config Class Initialized
INFO - 2023-05-01 08:45:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:30 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:30 --> URI Class Initialized
INFO - 2023-05-01 08:45:30 --> Router Class Initialized
INFO - 2023-05-01 08:45:30 --> Output Class Initialized
INFO - 2023-05-01 08:45:30 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:30 --> Input Class Initialized
INFO - 2023-05-01 08:45:30 --> Language Class Initialized
INFO - 2023-05-01 08:45:30 --> Language Class Initialized
INFO - 2023-05-01 08:45:30 --> Config Class Initialized
INFO - 2023-05-01 08:45:30 --> Loader Class Initialized
INFO - 2023-05-01 08:45:30 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:30 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:30 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:30 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:30 --> Controller Class Initialized
INFO - 2023-05-01 08:45:31 --> Helper loaded: cookie_helper
INFO - 2023-05-01 08:45:31 --> Final output sent to browser
DEBUG - 2023-05-01 08:45:31 --> Total execution time: 1.0462
INFO - 2023-05-01 08:45:31 --> Config Class Initialized
INFO - 2023-05-01 08:45:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:31 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:31 --> URI Class Initialized
INFO - 2023-05-01 08:45:31 --> Router Class Initialized
INFO - 2023-05-01 08:45:31 --> Output Class Initialized
INFO - 2023-05-01 08:45:31 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:31 --> Input Class Initialized
INFO - 2023-05-01 08:45:31 --> Language Class Initialized
INFO - 2023-05-01 08:45:31 --> Language Class Initialized
INFO - 2023-05-01 08:45:31 --> Config Class Initialized
INFO - 2023-05-01 08:45:31 --> Loader Class Initialized
INFO - 2023-05-01 08:45:31 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:31 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:31 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:31 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:31 --> Controller Class Initialized
DEBUG - 2023-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:45:31 --> Final output sent to browser
DEBUG - 2023-05-01 08:45:31 --> Total execution time: 0.1238
INFO - 2023-05-01 08:45:33 --> Config Class Initialized
INFO - 2023-05-01 08:45:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:33 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:33 --> URI Class Initialized
INFO - 2023-05-01 08:45:33 --> Router Class Initialized
INFO - 2023-05-01 08:45:33 --> Output Class Initialized
INFO - 2023-05-01 08:45:33 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:33 --> Input Class Initialized
INFO - 2023-05-01 08:45:33 --> Language Class Initialized
INFO - 2023-05-01 08:45:33 --> Language Class Initialized
INFO - 2023-05-01 08:45:33 --> Config Class Initialized
INFO - 2023-05-01 08:45:33 --> Loader Class Initialized
INFO - 2023-05-01 08:45:33 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:33 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:33 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:33 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:33 --> Controller Class Initialized
DEBUG - 2023-05-01 08:45:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 08:45:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:45:34 --> Final output sent to browser
DEBUG - 2023-05-01 08:45:34 --> Total execution time: 1.7682
INFO - 2023-05-01 08:45:38 --> Config Class Initialized
INFO - 2023-05-01 08:45:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:38 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:38 --> URI Class Initialized
INFO - 2023-05-01 08:45:38 --> Router Class Initialized
INFO - 2023-05-01 08:45:38 --> Output Class Initialized
INFO - 2023-05-01 08:45:38 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:38 --> Input Class Initialized
INFO - 2023-05-01 08:45:38 --> Language Class Initialized
INFO - 2023-05-01 08:45:38 --> Language Class Initialized
INFO - 2023-05-01 08:45:38 --> Config Class Initialized
INFO - 2023-05-01 08:45:38 --> Loader Class Initialized
INFO - 2023-05-01 08:45:38 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:38 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:38 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:38 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:38 --> Controller Class Initialized
DEBUG - 2023-05-01 08:45:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 08:45:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:45:38 --> Final output sent to browser
DEBUG - 2023-05-01 08:45:38 --> Total execution time: 0.0902
INFO - 2023-05-01 08:45:41 --> Config Class Initialized
INFO - 2023-05-01 08:45:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:45:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:45:41 --> Utf8 Class Initialized
INFO - 2023-05-01 08:45:41 --> URI Class Initialized
INFO - 2023-05-01 08:45:41 --> Router Class Initialized
INFO - 2023-05-01 08:45:41 --> Output Class Initialized
INFO - 2023-05-01 08:45:41 --> Security Class Initialized
DEBUG - 2023-05-01 08:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:45:41 --> Input Class Initialized
INFO - 2023-05-01 08:45:41 --> Language Class Initialized
INFO - 2023-05-01 08:45:41 --> Language Class Initialized
INFO - 2023-05-01 08:45:41 --> Config Class Initialized
INFO - 2023-05-01 08:45:41 --> Loader Class Initialized
INFO - 2023-05-01 08:45:41 --> Helper loaded: url_helper
INFO - 2023-05-01 08:45:41 --> Helper loaded: file_helper
INFO - 2023-05-01 08:45:41 --> Helper loaded: form_helper
INFO - 2023-05-01 08:45:41 --> Helper loaded: my_helper
INFO - 2023-05-01 08:45:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:45:41 --> Controller Class Initialized
INFO - 2023-05-01 08:45:41 --> Final output sent to browser
DEBUG - 2023-05-01 08:45:41 --> Total execution time: 0.0554
INFO - 2023-05-01 08:46:02 --> Config Class Initialized
INFO - 2023-05-01 08:46:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:46:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:46:02 --> Utf8 Class Initialized
INFO - 2023-05-01 08:46:02 --> URI Class Initialized
INFO - 2023-05-01 08:46:02 --> Router Class Initialized
INFO - 2023-05-01 08:46:02 --> Output Class Initialized
INFO - 2023-05-01 08:46:02 --> Security Class Initialized
DEBUG - 2023-05-01 08:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:46:02 --> Input Class Initialized
INFO - 2023-05-01 08:46:02 --> Language Class Initialized
INFO - 2023-05-01 08:46:02 --> Language Class Initialized
INFO - 2023-05-01 08:46:02 --> Config Class Initialized
INFO - 2023-05-01 08:46:02 --> Loader Class Initialized
INFO - 2023-05-01 08:46:02 --> Helper loaded: url_helper
INFO - 2023-05-01 08:46:02 --> Helper loaded: file_helper
INFO - 2023-05-01 08:46:02 --> Helper loaded: form_helper
INFO - 2023-05-01 08:46:02 --> Helper loaded: my_helper
INFO - 2023-05-01 08:46:02 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:46:02 --> Controller Class Initialized
DEBUG - 2023-05-01 08:46:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 08:46:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:46:02 --> Final output sent to browser
DEBUG - 2023-05-01 08:46:02 --> Total execution time: 0.0318
INFO - 2023-05-01 08:46:05 --> Config Class Initialized
INFO - 2023-05-01 08:46:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:46:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:46:05 --> Utf8 Class Initialized
INFO - 2023-05-01 08:46:05 --> URI Class Initialized
INFO - 2023-05-01 08:46:05 --> Router Class Initialized
INFO - 2023-05-01 08:46:05 --> Output Class Initialized
INFO - 2023-05-01 08:46:05 --> Security Class Initialized
DEBUG - 2023-05-01 08:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:46:05 --> Input Class Initialized
INFO - 2023-05-01 08:46:05 --> Language Class Initialized
INFO - 2023-05-01 08:46:05 --> Language Class Initialized
INFO - 2023-05-01 08:46:05 --> Config Class Initialized
INFO - 2023-05-01 08:46:05 --> Loader Class Initialized
INFO - 2023-05-01 08:46:05 --> Helper loaded: url_helper
INFO - 2023-05-01 08:46:05 --> Helper loaded: file_helper
INFO - 2023-05-01 08:46:05 --> Helper loaded: form_helper
INFO - 2023-05-01 08:46:05 --> Helper loaded: my_helper
INFO - 2023-05-01 08:46:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:46:06 --> Controller Class Initialized
DEBUG - 2023-05-01 08:46:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 08:46:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:46:06 --> Final output sent to browser
DEBUG - 2023-05-01 08:46:06 --> Total execution time: 0.0741
INFO - 2023-05-01 08:46:06 --> Config Class Initialized
INFO - 2023-05-01 08:46:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:46:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:46:06 --> Utf8 Class Initialized
INFO - 2023-05-01 08:46:06 --> URI Class Initialized
INFO - 2023-05-01 08:46:06 --> Router Class Initialized
INFO - 2023-05-01 08:46:06 --> Output Class Initialized
INFO - 2023-05-01 08:46:06 --> Security Class Initialized
DEBUG - 2023-05-01 08:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:46:06 --> Input Class Initialized
INFO - 2023-05-01 08:46:06 --> Language Class Initialized
INFO - 2023-05-01 08:46:06 --> Language Class Initialized
INFO - 2023-05-01 08:46:06 --> Config Class Initialized
INFO - 2023-05-01 08:46:06 --> Loader Class Initialized
INFO - 2023-05-01 08:46:06 --> Helper loaded: url_helper
INFO - 2023-05-01 08:46:06 --> Helper loaded: file_helper
INFO - 2023-05-01 08:46:06 --> Helper loaded: form_helper
INFO - 2023-05-01 08:46:06 --> Helper loaded: my_helper
INFO - 2023-05-01 08:46:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:46:06 --> Controller Class Initialized
INFO - 2023-05-01 08:46:09 --> Config Class Initialized
INFO - 2023-05-01 08:46:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:46:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:46:09 --> Utf8 Class Initialized
INFO - 2023-05-01 08:46:09 --> URI Class Initialized
INFO - 2023-05-01 08:46:09 --> Router Class Initialized
INFO - 2023-05-01 08:46:09 --> Output Class Initialized
INFO - 2023-05-01 08:46:09 --> Security Class Initialized
DEBUG - 2023-05-01 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:46:09 --> Input Class Initialized
INFO - 2023-05-01 08:46:09 --> Language Class Initialized
INFO - 2023-05-01 08:46:09 --> Language Class Initialized
INFO - 2023-05-01 08:46:09 --> Config Class Initialized
INFO - 2023-05-01 08:46:09 --> Loader Class Initialized
INFO - 2023-05-01 08:46:09 --> Helper loaded: url_helper
INFO - 2023-05-01 08:46:09 --> Helper loaded: file_helper
INFO - 2023-05-01 08:46:09 --> Helper loaded: form_helper
INFO - 2023-05-01 08:46:09 --> Helper loaded: my_helper
INFO - 2023-05-01 08:46:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:46:09 --> Controller Class Initialized
INFO - 2023-05-01 08:46:09 --> Final output sent to browser
DEBUG - 2023-05-01 08:46:09 --> Total execution time: 0.0455
INFO - 2023-05-01 08:46:55 --> Config Class Initialized
INFO - 2023-05-01 08:46:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:46:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:46:55 --> Utf8 Class Initialized
INFO - 2023-05-01 08:46:55 --> URI Class Initialized
INFO - 2023-05-01 08:46:55 --> Router Class Initialized
INFO - 2023-05-01 08:46:55 --> Output Class Initialized
INFO - 2023-05-01 08:46:55 --> Security Class Initialized
DEBUG - 2023-05-01 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:46:55 --> Input Class Initialized
INFO - 2023-05-01 08:46:55 --> Language Class Initialized
INFO - 2023-05-01 08:46:55 --> Language Class Initialized
INFO - 2023-05-01 08:46:55 --> Config Class Initialized
INFO - 2023-05-01 08:46:55 --> Loader Class Initialized
INFO - 2023-05-01 08:46:55 --> Helper loaded: url_helper
INFO - 2023-05-01 08:46:55 --> Helper loaded: file_helper
INFO - 2023-05-01 08:46:55 --> Helper loaded: form_helper
INFO - 2023-05-01 08:46:55 --> Helper loaded: my_helper
INFO - 2023-05-01 08:46:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:46:55 --> Controller Class Initialized
DEBUG - 2023-05-01 08:46:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 08:46:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:46:55 --> Final output sent to browser
DEBUG - 2023-05-01 08:46:55 --> Total execution time: 0.0318
INFO - 2023-05-01 08:50:56 --> Config Class Initialized
INFO - 2023-05-01 08:50:56 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:50:56 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:50:56 --> Utf8 Class Initialized
INFO - 2023-05-01 08:50:56 --> URI Class Initialized
INFO - 2023-05-01 08:50:56 --> Router Class Initialized
INFO - 2023-05-01 08:50:56 --> Output Class Initialized
INFO - 2023-05-01 08:50:56 --> Security Class Initialized
DEBUG - 2023-05-01 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:50:56 --> Input Class Initialized
INFO - 2023-05-01 08:50:56 --> Language Class Initialized
INFO - 2023-05-01 08:50:56 --> Language Class Initialized
INFO - 2023-05-01 08:50:56 --> Config Class Initialized
INFO - 2023-05-01 08:50:56 --> Loader Class Initialized
INFO - 2023-05-01 08:50:56 --> Helper loaded: url_helper
INFO - 2023-05-01 08:50:56 --> Helper loaded: file_helper
INFO - 2023-05-01 08:50:56 --> Helper loaded: form_helper
INFO - 2023-05-01 08:50:56 --> Helper loaded: my_helper
INFO - 2023-05-01 08:50:56 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:50:56 --> Controller Class Initialized
DEBUG - 2023-05-01 08:50:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 08:50:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:50:56 --> Final output sent to browser
DEBUG - 2023-05-01 08:50:56 --> Total execution time: 0.0311
INFO - 2023-05-01 08:50:58 --> Config Class Initialized
INFO - 2023-05-01 08:50:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:50:58 --> Utf8 Class Initialized
INFO - 2023-05-01 08:50:58 --> URI Class Initialized
INFO - 2023-05-01 08:50:58 --> Router Class Initialized
INFO - 2023-05-01 08:50:58 --> Output Class Initialized
INFO - 2023-05-01 08:50:58 --> Security Class Initialized
DEBUG - 2023-05-01 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:50:58 --> Input Class Initialized
INFO - 2023-05-01 08:50:58 --> Language Class Initialized
INFO - 2023-05-01 08:50:58 --> Language Class Initialized
INFO - 2023-05-01 08:50:58 --> Config Class Initialized
INFO - 2023-05-01 08:50:58 --> Loader Class Initialized
INFO - 2023-05-01 08:50:58 --> Helper loaded: url_helper
INFO - 2023-05-01 08:50:58 --> Helper loaded: file_helper
INFO - 2023-05-01 08:50:58 --> Helper loaded: form_helper
INFO - 2023-05-01 08:50:58 --> Helper loaded: my_helper
INFO - 2023-05-01 08:50:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:50:58 --> Controller Class Initialized
DEBUG - 2023-05-01 08:50:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 08:50:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:50:58 --> Final output sent to browser
DEBUG - 2023-05-01 08:50:58 --> Total execution time: 0.0325
INFO - 2023-05-01 08:51:01 --> Config Class Initialized
INFO - 2023-05-01 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:01 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:01 --> URI Class Initialized
INFO - 2023-05-01 08:51:01 --> Router Class Initialized
INFO - 2023-05-01 08:51:01 --> Output Class Initialized
INFO - 2023-05-01 08:51:01 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:01 --> Input Class Initialized
INFO - 2023-05-01 08:51:01 --> Language Class Initialized
INFO - 2023-05-01 08:51:01 --> Language Class Initialized
INFO - 2023-05-01 08:51:01 --> Config Class Initialized
INFO - 2023-05-01 08:51:01 --> Loader Class Initialized
INFO - 2023-05-01 08:51:01 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:01 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:01 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:01 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:01 --> Controller Class Initialized
DEBUG - 2023-05-01 08:51:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 08:51:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:51:01 --> Final output sent to browser
DEBUG - 2023-05-01 08:51:01 --> Total execution time: 0.0322
INFO - 2023-05-01 08:51:01 --> Config Class Initialized
INFO - 2023-05-01 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:01 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:01 --> URI Class Initialized
INFO - 2023-05-01 08:51:01 --> Router Class Initialized
INFO - 2023-05-01 08:51:01 --> Output Class Initialized
INFO - 2023-05-01 08:51:01 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:01 --> Input Class Initialized
INFO - 2023-05-01 08:51:01 --> Language Class Initialized
INFO - 2023-05-01 08:51:01 --> Language Class Initialized
INFO - 2023-05-01 08:51:01 --> Config Class Initialized
INFO - 2023-05-01 08:51:01 --> Loader Class Initialized
INFO - 2023-05-01 08:51:01 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:01 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:01 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:01 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:01 --> Controller Class Initialized
INFO - 2023-05-01 08:51:04 --> Config Class Initialized
INFO - 2023-05-01 08:51:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:04 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:04 --> URI Class Initialized
INFO - 2023-05-01 08:51:04 --> Router Class Initialized
INFO - 2023-05-01 08:51:04 --> Output Class Initialized
INFO - 2023-05-01 08:51:04 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:04 --> Input Class Initialized
INFO - 2023-05-01 08:51:04 --> Language Class Initialized
INFO - 2023-05-01 08:51:04 --> Language Class Initialized
INFO - 2023-05-01 08:51:04 --> Config Class Initialized
INFO - 2023-05-01 08:51:04 --> Loader Class Initialized
INFO - 2023-05-01 08:51:04 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:04 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:04 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:04 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:04 --> Controller Class Initialized
INFO - 2023-05-01 08:51:04 --> Final output sent to browser
DEBUG - 2023-05-01 08:51:04 --> Total execution time: 0.0411
INFO - 2023-05-01 08:51:05 --> Config Class Initialized
INFO - 2023-05-01 08:51:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:05 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:05 --> URI Class Initialized
INFO - 2023-05-01 08:51:05 --> Router Class Initialized
INFO - 2023-05-01 08:51:05 --> Output Class Initialized
INFO - 2023-05-01 08:51:05 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:05 --> Input Class Initialized
INFO - 2023-05-01 08:51:05 --> Language Class Initialized
INFO - 2023-05-01 08:51:05 --> Language Class Initialized
INFO - 2023-05-01 08:51:05 --> Config Class Initialized
INFO - 2023-05-01 08:51:05 --> Loader Class Initialized
INFO - 2023-05-01 08:51:05 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:05 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:05 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:05 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:05 --> Controller Class Initialized
INFO - 2023-05-01 08:51:05 --> Final output sent to browser
DEBUG - 2023-05-01 08:51:05 --> Total execution time: 0.0436
INFO - 2023-05-01 08:51:11 --> Config Class Initialized
INFO - 2023-05-01 08:51:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:11 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:11 --> URI Class Initialized
INFO - 2023-05-01 08:51:11 --> Router Class Initialized
INFO - 2023-05-01 08:51:11 --> Output Class Initialized
INFO - 2023-05-01 08:51:11 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:11 --> Input Class Initialized
INFO - 2023-05-01 08:51:11 --> Language Class Initialized
INFO - 2023-05-01 08:51:11 --> Language Class Initialized
INFO - 2023-05-01 08:51:11 --> Config Class Initialized
INFO - 2023-05-01 08:51:11 --> Loader Class Initialized
INFO - 2023-05-01 08:51:11 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:11 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:11 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:11 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:11 --> Controller Class Initialized
INFO - 2023-05-01 08:51:11 --> Final output sent to browser
DEBUG - 2023-05-01 08:51:11 --> Total execution time: 0.0434
INFO - 2023-05-01 08:51:12 --> Config Class Initialized
INFO - 2023-05-01 08:51:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:12 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:12 --> URI Class Initialized
INFO - 2023-05-01 08:51:12 --> Router Class Initialized
INFO - 2023-05-01 08:51:12 --> Output Class Initialized
INFO - 2023-05-01 08:51:12 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:12 --> Input Class Initialized
INFO - 2023-05-01 08:51:12 --> Language Class Initialized
INFO - 2023-05-01 08:51:12 --> Language Class Initialized
INFO - 2023-05-01 08:51:12 --> Config Class Initialized
INFO - 2023-05-01 08:51:12 --> Loader Class Initialized
INFO - 2023-05-01 08:51:12 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:12 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:12 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:12 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:12 --> Controller Class Initialized
INFO - 2023-05-01 08:51:12 --> Final output sent to browser
DEBUG - 2023-05-01 08:51:12 --> Total execution time: 0.0429
INFO - 2023-05-01 08:51:15 --> Config Class Initialized
INFO - 2023-05-01 08:51:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:51:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:51:15 --> Utf8 Class Initialized
INFO - 2023-05-01 08:51:15 --> URI Class Initialized
INFO - 2023-05-01 08:51:15 --> Router Class Initialized
INFO - 2023-05-01 08:51:15 --> Output Class Initialized
INFO - 2023-05-01 08:51:15 --> Security Class Initialized
DEBUG - 2023-05-01 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:51:15 --> Input Class Initialized
INFO - 2023-05-01 08:51:15 --> Language Class Initialized
INFO - 2023-05-01 08:51:15 --> Language Class Initialized
INFO - 2023-05-01 08:51:15 --> Config Class Initialized
INFO - 2023-05-01 08:51:15 --> Loader Class Initialized
INFO - 2023-05-01 08:51:15 --> Helper loaded: url_helper
INFO - 2023-05-01 08:51:15 --> Helper loaded: file_helper
INFO - 2023-05-01 08:51:15 --> Helper loaded: form_helper
INFO - 2023-05-01 08:51:15 --> Helper loaded: my_helper
INFO - 2023-05-01 08:51:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:51:15 --> Controller Class Initialized
INFO - 2023-05-01 08:52:49 --> Config Class Initialized
INFO - 2023-05-01 08:52:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 08:52:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 08:52:49 --> Utf8 Class Initialized
INFO - 2023-05-01 08:52:49 --> URI Class Initialized
INFO - 2023-05-01 08:52:49 --> Router Class Initialized
INFO - 2023-05-01 08:52:49 --> Output Class Initialized
INFO - 2023-05-01 08:52:49 --> Security Class Initialized
DEBUG - 2023-05-01 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 08:52:49 --> Input Class Initialized
INFO - 2023-05-01 08:52:49 --> Language Class Initialized
INFO - 2023-05-01 08:52:49 --> Language Class Initialized
INFO - 2023-05-01 08:52:49 --> Config Class Initialized
INFO - 2023-05-01 08:52:49 --> Loader Class Initialized
INFO - 2023-05-01 08:52:49 --> Helper loaded: url_helper
INFO - 2023-05-01 08:52:49 --> Helper loaded: file_helper
INFO - 2023-05-01 08:52:49 --> Helper loaded: form_helper
INFO - 2023-05-01 08:52:49 --> Helper loaded: my_helper
INFO - 2023-05-01 08:52:49 --> Database Driver Class Initialized
DEBUG - 2023-05-01 08:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 08:52:49 --> Controller Class Initialized
DEBUG - 2023-05-01 08:52:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 08:52:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 08:52:49 --> Final output sent to browser
DEBUG - 2023-05-01 08:52:49 --> Total execution time: 0.0573
INFO - 2023-05-01 09:00:55 --> Config Class Initialized
INFO - 2023-05-01 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:00:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:00:55 --> URI Class Initialized
INFO - 2023-05-01 09:00:55 --> Router Class Initialized
INFO - 2023-05-01 09:00:55 --> Output Class Initialized
INFO - 2023-05-01 09:00:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:00:55 --> Input Class Initialized
INFO - 2023-05-01 09:00:55 --> Language Class Initialized
INFO - 2023-05-01 09:00:55 --> Language Class Initialized
INFO - 2023-05-01 09:00:55 --> Config Class Initialized
INFO - 2023-05-01 09:00:55 --> Loader Class Initialized
INFO - 2023-05-01 09:00:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:00:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:00:55 --> Controller Class Initialized
INFO - 2023-05-01 09:00:55 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:00:55 --> Config Class Initialized
INFO - 2023-05-01 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:00:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:00:55 --> URI Class Initialized
INFO - 2023-05-01 09:00:55 --> Router Class Initialized
INFO - 2023-05-01 09:00:55 --> Output Class Initialized
INFO - 2023-05-01 09:00:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:00:55 --> Input Class Initialized
INFO - 2023-05-01 09:00:55 --> Language Class Initialized
INFO - 2023-05-01 09:00:55 --> Language Class Initialized
INFO - 2023-05-01 09:00:55 --> Config Class Initialized
INFO - 2023-05-01 09:00:55 --> Loader Class Initialized
INFO - 2023-05-01 09:00:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:00:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:00:55 --> Controller Class Initialized
INFO - 2023-05-01 09:00:55 --> Config Class Initialized
INFO - 2023-05-01 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:00:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:00:55 --> URI Class Initialized
INFO - 2023-05-01 09:00:55 --> Router Class Initialized
INFO - 2023-05-01 09:00:55 --> Output Class Initialized
INFO - 2023-05-01 09:00:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:00:55 --> Input Class Initialized
INFO - 2023-05-01 09:00:55 --> Language Class Initialized
INFO - 2023-05-01 09:00:55 --> Language Class Initialized
INFO - 2023-05-01 09:00:55 --> Config Class Initialized
INFO - 2023-05-01 09:00:55 --> Loader Class Initialized
INFO - 2023-05-01 09:00:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:00:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:00:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:00:55 --> Controller Class Initialized
DEBUG - 2023-05-01 09:00:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 09:00:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:00:55 --> Final output sent to browser
DEBUG - 2023-05-01 09:00:55 --> Total execution time: 0.0408
INFO - 2023-05-01 09:00:59 --> Config Class Initialized
INFO - 2023-05-01 09:00:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:00:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:00:59 --> Utf8 Class Initialized
INFO - 2023-05-01 09:00:59 --> URI Class Initialized
INFO - 2023-05-01 09:00:59 --> Router Class Initialized
INFO - 2023-05-01 09:00:59 --> Output Class Initialized
INFO - 2023-05-01 09:00:59 --> Security Class Initialized
DEBUG - 2023-05-01 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:00:59 --> Input Class Initialized
INFO - 2023-05-01 09:00:59 --> Language Class Initialized
INFO - 2023-05-01 09:00:59 --> Language Class Initialized
INFO - 2023-05-01 09:00:59 --> Config Class Initialized
INFO - 2023-05-01 09:00:59 --> Loader Class Initialized
INFO - 2023-05-01 09:00:59 --> Helper loaded: url_helper
INFO - 2023-05-01 09:00:59 --> Helper loaded: file_helper
INFO - 2023-05-01 09:00:59 --> Helper loaded: form_helper
INFO - 2023-05-01 09:00:59 --> Helper loaded: my_helper
INFO - 2023-05-01 09:00:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:00:59 --> Controller Class Initialized
INFO - 2023-05-01 09:00:59 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:00:59 --> Final output sent to browser
DEBUG - 2023-05-01 09:00:59 --> Total execution time: 0.0453
INFO - 2023-05-01 09:00:59 --> Config Class Initialized
INFO - 2023-05-01 09:00:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:00:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:00:59 --> Utf8 Class Initialized
INFO - 2023-05-01 09:00:59 --> URI Class Initialized
INFO - 2023-05-01 09:00:59 --> Router Class Initialized
INFO - 2023-05-01 09:00:59 --> Output Class Initialized
INFO - 2023-05-01 09:00:59 --> Security Class Initialized
DEBUG - 2023-05-01 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:00:59 --> Input Class Initialized
INFO - 2023-05-01 09:00:59 --> Language Class Initialized
INFO - 2023-05-01 09:00:59 --> Language Class Initialized
INFO - 2023-05-01 09:00:59 --> Config Class Initialized
INFO - 2023-05-01 09:00:59 --> Loader Class Initialized
INFO - 2023-05-01 09:00:59 --> Helper loaded: url_helper
INFO - 2023-05-01 09:00:59 --> Helper loaded: file_helper
INFO - 2023-05-01 09:00:59 --> Helper loaded: form_helper
INFO - 2023-05-01 09:00:59 --> Helper loaded: my_helper
INFO - 2023-05-01 09:00:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:00:59 --> Controller Class Initialized
DEBUG - 2023-05-01 09:00:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-01 09:00:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:00:59 --> Final output sent to browser
DEBUG - 2023-05-01 09:00:59 --> Total execution time: 0.0842
INFO - 2023-05-01 09:01:07 --> Config Class Initialized
INFO - 2023-05-01 09:01:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:01:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:01:07 --> Utf8 Class Initialized
INFO - 2023-05-01 09:01:07 --> URI Class Initialized
INFO - 2023-05-01 09:01:07 --> Router Class Initialized
INFO - 2023-05-01 09:01:07 --> Output Class Initialized
INFO - 2023-05-01 09:01:07 --> Security Class Initialized
DEBUG - 2023-05-01 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:01:07 --> Input Class Initialized
INFO - 2023-05-01 09:01:07 --> Language Class Initialized
INFO - 2023-05-01 09:01:07 --> Language Class Initialized
INFO - 2023-05-01 09:01:07 --> Config Class Initialized
INFO - 2023-05-01 09:01:07 --> Loader Class Initialized
INFO - 2023-05-01 09:01:07 --> Helper loaded: url_helper
INFO - 2023-05-01 09:01:07 --> Helper loaded: file_helper
INFO - 2023-05-01 09:01:07 --> Helper loaded: form_helper
INFO - 2023-05-01 09:01:07 --> Helper loaded: my_helper
INFO - 2023-05-01 09:01:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:01:07 --> Controller Class Initialized
DEBUG - 2023-05-01 09:01:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-05-01 09:01:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:01:07 --> Final output sent to browser
DEBUG - 2023-05-01 09:01:07 --> Total execution time: 0.0782
INFO - 2023-05-01 09:01:07 --> Config Class Initialized
INFO - 2023-05-01 09:01:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:01:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:01:07 --> Utf8 Class Initialized
INFO - 2023-05-01 09:01:07 --> URI Class Initialized
INFO - 2023-05-01 09:01:07 --> Router Class Initialized
INFO - 2023-05-01 09:01:07 --> Output Class Initialized
INFO - 2023-05-01 09:01:07 --> Security Class Initialized
DEBUG - 2023-05-01 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:01:07 --> Input Class Initialized
INFO - 2023-05-01 09:01:07 --> Language Class Initialized
INFO - 2023-05-01 09:01:07 --> Language Class Initialized
INFO - 2023-05-01 09:01:07 --> Config Class Initialized
INFO - 2023-05-01 09:01:07 --> Loader Class Initialized
INFO - 2023-05-01 09:01:07 --> Helper loaded: url_helper
INFO - 2023-05-01 09:01:07 --> Helper loaded: file_helper
INFO - 2023-05-01 09:01:07 --> Helper loaded: form_helper
INFO - 2023-05-01 09:01:07 --> Helper loaded: my_helper
INFO - 2023-05-01 09:01:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:01:07 --> Controller Class Initialized
INFO - 2023-05-01 09:01:09 --> Config Class Initialized
INFO - 2023-05-01 09:01:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:01:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:01:09 --> Utf8 Class Initialized
INFO - 2023-05-01 09:01:09 --> URI Class Initialized
INFO - 2023-05-01 09:01:09 --> Router Class Initialized
INFO - 2023-05-01 09:01:09 --> Output Class Initialized
INFO - 2023-05-01 09:01:09 --> Security Class Initialized
DEBUG - 2023-05-01 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:01:09 --> Input Class Initialized
INFO - 2023-05-01 09:01:09 --> Language Class Initialized
INFO - 2023-05-01 09:01:09 --> Language Class Initialized
INFO - 2023-05-01 09:01:09 --> Config Class Initialized
INFO - 2023-05-01 09:01:09 --> Loader Class Initialized
INFO - 2023-05-01 09:01:09 --> Helper loaded: url_helper
INFO - 2023-05-01 09:01:09 --> Helper loaded: file_helper
INFO - 2023-05-01 09:01:09 --> Helper loaded: form_helper
INFO - 2023-05-01 09:01:09 --> Helper loaded: my_helper
INFO - 2023-05-01 09:01:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:01:09 --> Controller Class Initialized
INFO - 2023-05-01 09:01:09 --> Final output sent to browser
DEBUG - 2023-05-01 09:01:09 --> Total execution time: 0.0327
INFO - 2023-05-01 09:01:30 --> Config Class Initialized
INFO - 2023-05-01 09:01:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:01:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:01:30 --> Utf8 Class Initialized
INFO - 2023-05-01 09:01:30 --> URI Class Initialized
DEBUG - 2023-05-01 09:01:30 --> No URI present. Default controller set.
INFO - 2023-05-01 09:01:30 --> Router Class Initialized
INFO - 2023-05-01 09:01:30 --> Output Class Initialized
INFO - 2023-05-01 09:01:30 --> Security Class Initialized
DEBUG - 2023-05-01 09:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:01:30 --> Input Class Initialized
INFO - 2023-05-01 09:01:30 --> Language Class Initialized
INFO - 2023-05-01 09:01:30 --> Language Class Initialized
INFO - 2023-05-01 09:01:30 --> Config Class Initialized
INFO - 2023-05-01 09:01:30 --> Loader Class Initialized
INFO - 2023-05-01 09:01:30 --> Helper loaded: url_helper
INFO - 2023-05-01 09:01:30 --> Helper loaded: file_helper
INFO - 2023-05-01 09:01:30 --> Helper loaded: form_helper
INFO - 2023-05-01 09:01:30 --> Helper loaded: my_helper
INFO - 2023-05-01 09:01:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:01:30 --> Controller Class Initialized
DEBUG - 2023-05-01 09:01:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-01 09:01:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:01:30 --> Final output sent to browser
DEBUG - 2023-05-01 09:01:30 --> Total execution time: 0.0485
INFO - 2023-05-01 09:06:45 --> Config Class Initialized
INFO - 2023-05-01 09:06:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:06:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:06:45 --> Utf8 Class Initialized
INFO - 2023-05-01 09:06:45 --> URI Class Initialized
INFO - 2023-05-01 09:06:45 --> Router Class Initialized
INFO - 2023-05-01 09:06:45 --> Output Class Initialized
INFO - 2023-05-01 09:06:45 --> Security Class Initialized
DEBUG - 2023-05-01 09:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:06:45 --> Input Class Initialized
INFO - 2023-05-01 09:06:45 --> Language Class Initialized
INFO - 2023-05-01 09:06:45 --> Language Class Initialized
INFO - 2023-05-01 09:06:45 --> Config Class Initialized
INFO - 2023-05-01 09:06:45 --> Loader Class Initialized
INFO - 2023-05-01 09:06:45 --> Helper loaded: url_helper
INFO - 2023-05-01 09:06:45 --> Helper loaded: file_helper
INFO - 2023-05-01 09:06:45 --> Helper loaded: form_helper
INFO - 2023-05-01 09:06:45 --> Helper loaded: my_helper
INFO - 2023-05-01 09:06:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:06:45 --> Controller Class Initialized
DEBUG - 2023-05-01 09:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-05-01 09:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:06:45 --> Final output sent to browser
DEBUG - 2023-05-01 09:06:45 --> Total execution time: 0.0548
INFO - 2023-05-01 09:06:45 --> Config Class Initialized
INFO - 2023-05-01 09:06:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:06:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:06:45 --> Utf8 Class Initialized
INFO - 2023-05-01 09:06:45 --> URI Class Initialized
INFO - 2023-05-01 09:06:45 --> Router Class Initialized
INFO - 2023-05-01 09:06:45 --> Output Class Initialized
INFO - 2023-05-01 09:06:45 --> Security Class Initialized
DEBUG - 2023-05-01 09:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:06:45 --> Input Class Initialized
INFO - 2023-05-01 09:06:45 --> Language Class Initialized
INFO - 2023-05-01 09:06:45 --> Language Class Initialized
INFO - 2023-05-01 09:06:45 --> Config Class Initialized
INFO - 2023-05-01 09:06:45 --> Loader Class Initialized
INFO - 2023-05-01 09:06:45 --> Helper loaded: url_helper
INFO - 2023-05-01 09:06:45 --> Helper loaded: file_helper
INFO - 2023-05-01 09:06:45 --> Helper loaded: form_helper
INFO - 2023-05-01 09:06:45 --> Helper loaded: my_helper
INFO - 2023-05-01 09:06:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:06:45 --> Controller Class Initialized
INFO - 2023-05-01 09:06:47 --> Config Class Initialized
INFO - 2023-05-01 09:06:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:06:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:06:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:06:47 --> URI Class Initialized
INFO - 2023-05-01 09:06:47 --> Router Class Initialized
INFO - 2023-05-01 09:06:47 --> Output Class Initialized
INFO - 2023-05-01 09:06:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:06:47 --> Input Class Initialized
INFO - 2023-05-01 09:06:47 --> Language Class Initialized
INFO - 2023-05-01 09:06:47 --> Language Class Initialized
INFO - 2023-05-01 09:06:47 --> Config Class Initialized
INFO - 2023-05-01 09:06:47 --> Loader Class Initialized
INFO - 2023-05-01 09:06:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:06:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:06:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:06:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:06:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:06:47 --> Controller Class Initialized
INFO - 2023-05-01 09:06:47 --> Final output sent to browser
DEBUG - 2023-05-01 09:06:47 --> Total execution time: 0.0557
INFO - 2023-05-01 09:09:11 --> Config Class Initialized
INFO - 2023-05-01 09:09:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:09:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:09:11 --> Utf8 Class Initialized
INFO - 2023-05-01 09:09:11 --> URI Class Initialized
INFO - 2023-05-01 09:09:11 --> Router Class Initialized
INFO - 2023-05-01 09:09:11 --> Output Class Initialized
INFO - 2023-05-01 09:09:11 --> Security Class Initialized
DEBUG - 2023-05-01 09:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:09:11 --> Input Class Initialized
INFO - 2023-05-01 09:09:11 --> Language Class Initialized
INFO - 2023-05-01 09:09:11 --> Language Class Initialized
INFO - 2023-05-01 09:09:11 --> Config Class Initialized
INFO - 2023-05-01 09:09:11 --> Loader Class Initialized
INFO - 2023-05-01 09:09:11 --> Helper loaded: url_helper
INFO - 2023-05-01 09:09:11 --> Helper loaded: file_helper
INFO - 2023-05-01 09:09:11 --> Helper loaded: form_helper
INFO - 2023-05-01 09:09:11 --> Helper loaded: my_helper
INFO - 2023-05-01 09:09:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:09:11 --> Controller Class Initialized
DEBUG - 2023-05-01 09:09:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-05-01 09:09:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:09:11 --> Final output sent to browser
DEBUG - 2023-05-01 09:09:11 --> Total execution time: 0.0289
INFO - 2023-05-01 09:09:11 --> Config Class Initialized
INFO - 2023-05-01 09:09:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:09:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:09:11 --> Utf8 Class Initialized
INFO - 2023-05-01 09:09:11 --> URI Class Initialized
INFO - 2023-05-01 09:09:11 --> Router Class Initialized
INFO - 2023-05-01 09:09:11 --> Output Class Initialized
INFO - 2023-05-01 09:09:11 --> Security Class Initialized
DEBUG - 2023-05-01 09:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:09:11 --> Input Class Initialized
INFO - 2023-05-01 09:09:11 --> Language Class Initialized
INFO - 2023-05-01 09:09:11 --> Language Class Initialized
INFO - 2023-05-01 09:09:11 --> Config Class Initialized
INFO - 2023-05-01 09:09:11 --> Loader Class Initialized
INFO - 2023-05-01 09:09:11 --> Helper loaded: url_helper
INFO - 2023-05-01 09:09:11 --> Helper loaded: file_helper
INFO - 2023-05-01 09:09:11 --> Helper loaded: form_helper
INFO - 2023-05-01 09:09:11 --> Helper loaded: my_helper
INFO - 2023-05-01 09:09:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:09:11 --> Controller Class Initialized
INFO - 2023-05-01 09:09:13 --> Config Class Initialized
INFO - 2023-05-01 09:09:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:09:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:09:13 --> Utf8 Class Initialized
INFO - 2023-05-01 09:09:13 --> URI Class Initialized
INFO - 2023-05-01 09:09:13 --> Router Class Initialized
INFO - 2023-05-01 09:09:13 --> Output Class Initialized
INFO - 2023-05-01 09:09:13 --> Security Class Initialized
DEBUG - 2023-05-01 09:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:09:13 --> Input Class Initialized
INFO - 2023-05-01 09:09:13 --> Language Class Initialized
INFO - 2023-05-01 09:09:13 --> Language Class Initialized
INFO - 2023-05-01 09:09:13 --> Config Class Initialized
INFO - 2023-05-01 09:09:13 --> Loader Class Initialized
INFO - 2023-05-01 09:09:13 --> Helper loaded: url_helper
INFO - 2023-05-01 09:09:13 --> Helper loaded: file_helper
INFO - 2023-05-01 09:09:13 --> Helper loaded: form_helper
INFO - 2023-05-01 09:09:13 --> Helper loaded: my_helper
INFO - 2023-05-01 09:09:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:09:13 --> Controller Class Initialized
INFO - 2023-05-01 09:09:13 --> Final output sent to browser
DEBUG - 2023-05-01 09:09:13 --> Total execution time: 0.0576
INFO - 2023-05-01 09:18:12 --> Config Class Initialized
INFO - 2023-05-01 09:18:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:18:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:18:12 --> Utf8 Class Initialized
INFO - 2023-05-01 09:18:12 --> URI Class Initialized
INFO - 2023-05-01 09:18:12 --> Router Class Initialized
INFO - 2023-05-01 09:18:12 --> Output Class Initialized
INFO - 2023-05-01 09:18:12 --> Security Class Initialized
DEBUG - 2023-05-01 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:18:12 --> Input Class Initialized
INFO - 2023-05-01 09:18:12 --> Language Class Initialized
INFO - 2023-05-01 09:18:12 --> Language Class Initialized
INFO - 2023-05-01 09:18:12 --> Config Class Initialized
INFO - 2023-05-01 09:18:12 --> Loader Class Initialized
INFO - 2023-05-01 09:18:12 --> Helper loaded: url_helper
INFO - 2023-05-01 09:18:12 --> Helper loaded: file_helper
INFO - 2023-05-01 09:18:12 --> Helper loaded: form_helper
INFO - 2023-05-01 09:18:12 --> Helper loaded: my_helper
INFO - 2023-05-01 09:18:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:18:12 --> Controller Class Initialized
INFO - 2023-05-01 09:18:12 --> Final output sent to browser
DEBUG - 2023-05-01 09:18:12 --> Total execution time: 0.0420
INFO - 2023-05-01 09:18:12 --> Config Class Initialized
INFO - 2023-05-01 09:18:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:18:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:18:12 --> Utf8 Class Initialized
INFO - 2023-05-01 09:18:12 --> URI Class Initialized
INFO - 2023-05-01 09:18:12 --> Router Class Initialized
INFO - 2023-05-01 09:18:12 --> Output Class Initialized
INFO - 2023-05-01 09:18:12 --> Security Class Initialized
DEBUG - 2023-05-01 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:18:12 --> Input Class Initialized
INFO - 2023-05-01 09:18:12 --> Language Class Initialized
INFO - 2023-05-01 09:18:12 --> Language Class Initialized
INFO - 2023-05-01 09:18:12 --> Config Class Initialized
INFO - 2023-05-01 09:18:12 --> Loader Class Initialized
INFO - 2023-05-01 09:18:12 --> Helper loaded: url_helper
INFO - 2023-05-01 09:18:12 --> Helper loaded: file_helper
INFO - 2023-05-01 09:18:12 --> Helper loaded: form_helper
INFO - 2023-05-01 09:18:12 --> Helper loaded: my_helper
INFO - 2023-05-01 09:18:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:18:12 --> Controller Class Initialized
INFO - 2023-05-01 09:18:17 --> Config Class Initialized
INFO - 2023-05-01 09:18:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:18:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:18:17 --> Utf8 Class Initialized
INFO - 2023-05-01 09:18:17 --> URI Class Initialized
INFO - 2023-05-01 09:18:17 --> Router Class Initialized
INFO - 2023-05-01 09:18:17 --> Output Class Initialized
INFO - 2023-05-01 09:18:17 --> Security Class Initialized
DEBUG - 2023-05-01 09:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:18:17 --> Input Class Initialized
INFO - 2023-05-01 09:18:17 --> Language Class Initialized
INFO - 2023-05-01 09:18:17 --> Language Class Initialized
INFO - 2023-05-01 09:18:17 --> Config Class Initialized
INFO - 2023-05-01 09:18:17 --> Loader Class Initialized
INFO - 2023-05-01 09:18:17 --> Helper loaded: url_helper
INFO - 2023-05-01 09:18:17 --> Helper loaded: file_helper
INFO - 2023-05-01 09:18:17 --> Helper loaded: form_helper
INFO - 2023-05-01 09:18:17 --> Helper loaded: my_helper
INFO - 2023-05-01 09:18:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:18:17 --> Controller Class Initialized
INFO - 2023-05-01 09:18:17 --> Final output sent to browser
DEBUG - 2023-05-01 09:18:17 --> Total execution time: 0.0411
INFO - 2023-05-01 09:18:20 --> Config Class Initialized
INFO - 2023-05-01 09:18:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:18:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:18:20 --> Utf8 Class Initialized
INFO - 2023-05-01 09:18:20 --> URI Class Initialized
INFO - 2023-05-01 09:18:20 --> Router Class Initialized
INFO - 2023-05-01 09:18:20 --> Output Class Initialized
INFO - 2023-05-01 09:18:20 --> Security Class Initialized
DEBUG - 2023-05-01 09:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:18:20 --> Input Class Initialized
INFO - 2023-05-01 09:18:20 --> Language Class Initialized
INFO - 2023-05-01 09:18:20 --> Language Class Initialized
INFO - 2023-05-01 09:18:20 --> Config Class Initialized
INFO - 2023-05-01 09:18:20 --> Loader Class Initialized
INFO - 2023-05-01 09:18:20 --> Helper loaded: url_helper
INFO - 2023-05-01 09:18:21 --> Helper loaded: file_helper
INFO - 2023-05-01 09:18:21 --> Helper loaded: form_helper
INFO - 2023-05-01 09:18:21 --> Helper loaded: my_helper
INFO - 2023-05-01 09:18:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:18:21 --> Controller Class Initialized
INFO - 2023-05-01 09:18:21 --> Final output sent to browser
DEBUG - 2023-05-01 09:18:21 --> Total execution time: 0.0417
INFO - 2023-05-01 09:18:21 --> Config Class Initialized
INFO - 2023-05-01 09:18:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:18:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:18:21 --> Utf8 Class Initialized
INFO - 2023-05-01 09:18:21 --> URI Class Initialized
INFO - 2023-05-01 09:18:21 --> Router Class Initialized
INFO - 2023-05-01 09:18:21 --> Output Class Initialized
INFO - 2023-05-01 09:18:21 --> Security Class Initialized
DEBUG - 2023-05-01 09:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:18:21 --> Input Class Initialized
INFO - 2023-05-01 09:18:21 --> Language Class Initialized
INFO - 2023-05-01 09:18:21 --> Language Class Initialized
INFO - 2023-05-01 09:18:21 --> Config Class Initialized
INFO - 2023-05-01 09:18:21 --> Loader Class Initialized
INFO - 2023-05-01 09:18:21 --> Helper loaded: url_helper
INFO - 2023-05-01 09:18:21 --> Helper loaded: file_helper
INFO - 2023-05-01 09:18:21 --> Helper loaded: form_helper
INFO - 2023-05-01 09:18:21 --> Helper loaded: my_helper
INFO - 2023-05-01 09:18:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:18:21 --> Controller Class Initialized
INFO - 2023-05-01 09:24:27 --> Config Class Initialized
INFO - 2023-05-01 09:24:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:27 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:27 --> URI Class Initialized
INFO - 2023-05-01 09:24:27 --> Router Class Initialized
INFO - 2023-05-01 09:24:27 --> Output Class Initialized
INFO - 2023-05-01 09:24:27 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:27 --> Input Class Initialized
INFO - 2023-05-01 09:24:27 --> Language Class Initialized
INFO - 2023-05-01 09:24:27 --> Language Class Initialized
INFO - 2023-05-01 09:24:27 --> Config Class Initialized
INFO - 2023-05-01 09:24:27 --> Loader Class Initialized
INFO - 2023-05-01 09:24:27 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:27 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:27 --> Controller Class Initialized
INFO - 2023-05-01 09:24:27 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:24:27 --> Config Class Initialized
INFO - 2023-05-01 09:24:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:27 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:27 --> URI Class Initialized
INFO - 2023-05-01 09:24:27 --> Router Class Initialized
INFO - 2023-05-01 09:24:27 --> Output Class Initialized
INFO - 2023-05-01 09:24:27 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:27 --> Input Class Initialized
INFO - 2023-05-01 09:24:27 --> Language Class Initialized
INFO - 2023-05-01 09:24:27 --> Language Class Initialized
INFO - 2023-05-01 09:24:27 --> Config Class Initialized
INFO - 2023-05-01 09:24:27 --> Loader Class Initialized
INFO - 2023-05-01 09:24:27 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:27 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:27 --> Controller Class Initialized
INFO - 2023-05-01 09:24:27 --> Config Class Initialized
INFO - 2023-05-01 09:24:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:27 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:27 --> URI Class Initialized
INFO - 2023-05-01 09:24:27 --> Router Class Initialized
INFO - 2023-05-01 09:24:27 --> Output Class Initialized
INFO - 2023-05-01 09:24:27 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:27 --> Input Class Initialized
INFO - 2023-05-01 09:24:27 --> Language Class Initialized
INFO - 2023-05-01 09:24:27 --> Language Class Initialized
INFO - 2023-05-01 09:24:27 --> Config Class Initialized
INFO - 2023-05-01 09:24:27 --> Loader Class Initialized
INFO - 2023-05-01 09:24:27 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:27 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:28 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:28 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:28 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:28 --> Controller Class Initialized
DEBUG - 2023-05-01 09:24:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 09:24:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:24:28 --> Final output sent to browser
DEBUG - 2023-05-01 09:24:28 --> Total execution time: 0.0221
INFO - 2023-05-01 09:24:41 --> Config Class Initialized
INFO - 2023-05-01 09:24:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:41 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:41 --> URI Class Initialized
INFO - 2023-05-01 09:24:41 --> Router Class Initialized
INFO - 2023-05-01 09:24:41 --> Output Class Initialized
INFO - 2023-05-01 09:24:41 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:41 --> Input Class Initialized
INFO - 2023-05-01 09:24:41 --> Language Class Initialized
INFO - 2023-05-01 09:24:41 --> Language Class Initialized
INFO - 2023-05-01 09:24:41 --> Config Class Initialized
INFO - 2023-05-01 09:24:41 --> Loader Class Initialized
INFO - 2023-05-01 09:24:41 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:41 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:41 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:41 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:41 --> Controller Class Initialized
INFO - 2023-05-01 09:24:41 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:24:41 --> Final output sent to browser
DEBUG - 2023-05-01 09:24:41 --> Total execution time: 0.0515
INFO - 2023-05-01 09:24:41 --> Config Class Initialized
INFO - 2023-05-01 09:24:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:41 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:41 --> URI Class Initialized
INFO - 2023-05-01 09:24:41 --> Router Class Initialized
INFO - 2023-05-01 09:24:41 --> Output Class Initialized
INFO - 2023-05-01 09:24:41 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:41 --> Input Class Initialized
INFO - 2023-05-01 09:24:41 --> Language Class Initialized
INFO - 2023-05-01 09:24:41 --> Language Class Initialized
INFO - 2023-05-01 09:24:41 --> Config Class Initialized
INFO - 2023-05-01 09:24:41 --> Loader Class Initialized
INFO - 2023-05-01 09:24:41 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:41 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:41 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:41 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:41 --> Controller Class Initialized
DEBUG - 2023-05-01 09:24:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-01 09:24:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:24:41 --> Final output sent to browser
DEBUG - 2023-05-01 09:24:41 --> Total execution time: 0.0612
INFO - 2023-05-01 09:24:47 --> Config Class Initialized
INFO - 2023-05-01 09:24:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:47 --> URI Class Initialized
INFO - 2023-05-01 09:24:47 --> Router Class Initialized
INFO - 2023-05-01 09:24:47 --> Output Class Initialized
INFO - 2023-05-01 09:24:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:47 --> Input Class Initialized
INFO - 2023-05-01 09:24:47 --> Language Class Initialized
INFO - 2023-05-01 09:24:47 --> Language Class Initialized
INFO - 2023-05-01 09:24:47 --> Config Class Initialized
INFO - 2023-05-01 09:24:47 --> Loader Class Initialized
INFO - 2023-05-01 09:24:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:47 --> Controller Class Initialized
DEBUG - 2023-05-01 09:24:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-05-01 09:24:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:24:47 --> Final output sent to browser
DEBUG - 2023-05-01 09:24:47 --> Total execution time: 0.0400
INFO - 2023-05-01 09:24:47 --> Config Class Initialized
INFO - 2023-05-01 09:24:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:47 --> URI Class Initialized
INFO - 2023-05-01 09:24:47 --> Router Class Initialized
INFO - 2023-05-01 09:24:47 --> Output Class Initialized
INFO - 2023-05-01 09:24:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:47 --> Input Class Initialized
INFO - 2023-05-01 09:24:47 --> Language Class Initialized
INFO - 2023-05-01 09:24:47 --> Language Class Initialized
INFO - 2023-05-01 09:24:47 --> Config Class Initialized
INFO - 2023-05-01 09:24:47 --> Loader Class Initialized
INFO - 2023-05-01 09:24:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:47 --> Controller Class Initialized
INFO - 2023-05-01 09:24:55 --> Config Class Initialized
INFO - 2023-05-01 09:24:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:55 --> URI Class Initialized
INFO - 2023-05-01 09:24:55 --> Router Class Initialized
INFO - 2023-05-01 09:24:55 --> Output Class Initialized
INFO - 2023-05-01 09:24:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:55 --> Input Class Initialized
INFO - 2023-05-01 09:24:55 --> Language Class Initialized
INFO - 2023-05-01 09:24:55 --> Language Class Initialized
INFO - 2023-05-01 09:24:55 --> Config Class Initialized
INFO - 2023-05-01 09:24:55 --> Loader Class Initialized
INFO - 2023-05-01 09:24:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:55 --> Controller Class Initialized
DEBUG - 2023-05-01 09:24:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 09:24:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:24:55 --> Final output sent to browser
DEBUG - 2023-05-01 09:24:55 --> Total execution time: 0.0732
INFO - 2023-05-01 09:24:55 --> Config Class Initialized
INFO - 2023-05-01 09:24:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:55 --> URI Class Initialized
INFO - 2023-05-01 09:24:55 --> Router Class Initialized
INFO - 2023-05-01 09:24:55 --> Output Class Initialized
INFO - 2023-05-01 09:24:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:55 --> Input Class Initialized
INFO - 2023-05-01 09:24:55 --> Language Class Initialized
INFO - 2023-05-01 09:24:55 --> Language Class Initialized
INFO - 2023-05-01 09:24:55 --> Config Class Initialized
INFO - 2023-05-01 09:24:55 --> Loader Class Initialized
INFO - 2023-05-01 09:24:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:55 --> Controller Class Initialized
INFO - 2023-05-01 09:24:57 --> Config Class Initialized
INFO - 2023-05-01 09:24:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:24:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:24:57 --> Utf8 Class Initialized
INFO - 2023-05-01 09:24:57 --> URI Class Initialized
INFO - 2023-05-01 09:24:57 --> Router Class Initialized
INFO - 2023-05-01 09:24:57 --> Output Class Initialized
INFO - 2023-05-01 09:24:57 --> Security Class Initialized
DEBUG - 2023-05-01 09:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:24:57 --> Input Class Initialized
INFO - 2023-05-01 09:24:57 --> Language Class Initialized
INFO - 2023-05-01 09:24:57 --> Language Class Initialized
INFO - 2023-05-01 09:24:57 --> Config Class Initialized
INFO - 2023-05-01 09:24:57 --> Loader Class Initialized
INFO - 2023-05-01 09:24:57 --> Helper loaded: url_helper
INFO - 2023-05-01 09:24:57 --> Helper loaded: file_helper
INFO - 2023-05-01 09:24:57 --> Helper loaded: form_helper
INFO - 2023-05-01 09:24:57 --> Helper loaded: my_helper
INFO - 2023-05-01 09:24:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:24:57 --> Controller Class Initialized
DEBUG - 2023-05-01 09:24:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-05-01 09:24:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:24:57 --> Final output sent to browser
DEBUG - 2023-05-01 09:24:57 --> Total execution time: 0.0462
INFO - 2023-05-01 09:25:00 --> Config Class Initialized
INFO - 2023-05-01 09:25:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:00 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:00 --> URI Class Initialized
INFO - 2023-05-01 09:25:00 --> Router Class Initialized
INFO - 2023-05-01 09:25:00 --> Output Class Initialized
INFO - 2023-05-01 09:25:00 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:00 --> Input Class Initialized
INFO - 2023-05-01 09:25:00 --> Language Class Initialized
INFO - 2023-05-01 09:25:00 --> Language Class Initialized
INFO - 2023-05-01 09:25:00 --> Config Class Initialized
INFO - 2023-05-01 09:25:00 --> Loader Class Initialized
INFO - 2023-05-01 09:25:00 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:00 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:00 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:00 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:00 --> Controller Class Initialized
DEBUG - 2023-05-01 09:25:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 09:25:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:25:00 --> Final output sent to browser
DEBUG - 2023-05-01 09:25:00 --> Total execution time: 0.0257
INFO - 2023-05-01 09:25:00 --> Config Class Initialized
INFO - 2023-05-01 09:25:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:00 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:00 --> URI Class Initialized
INFO - 2023-05-01 09:25:00 --> Router Class Initialized
INFO - 2023-05-01 09:25:00 --> Output Class Initialized
INFO - 2023-05-01 09:25:00 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:00 --> Input Class Initialized
INFO - 2023-05-01 09:25:00 --> Language Class Initialized
INFO - 2023-05-01 09:25:00 --> Language Class Initialized
INFO - 2023-05-01 09:25:00 --> Config Class Initialized
INFO - 2023-05-01 09:25:00 --> Loader Class Initialized
INFO - 2023-05-01 09:25:00 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:00 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:00 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:00 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:00 --> Controller Class Initialized
INFO - 2023-05-01 09:25:21 --> Config Class Initialized
INFO - 2023-05-01 09:25:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:21 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:21 --> URI Class Initialized
INFO - 2023-05-01 09:25:21 --> Router Class Initialized
INFO - 2023-05-01 09:25:21 --> Output Class Initialized
INFO - 2023-05-01 09:25:21 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:21 --> Input Class Initialized
INFO - 2023-05-01 09:25:21 --> Language Class Initialized
INFO - 2023-05-01 09:25:21 --> Language Class Initialized
INFO - 2023-05-01 09:25:21 --> Config Class Initialized
INFO - 2023-05-01 09:25:21 --> Loader Class Initialized
INFO - 2023-05-01 09:25:21 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:21 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:21 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:21 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:21 --> Controller Class Initialized
DEBUG - 2023-05-01 09:25:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-05-01 09:25:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:25:21 --> Final output sent to browser
DEBUG - 2023-05-01 09:25:21 --> Total execution time: 0.0456
INFO - 2023-05-01 09:25:22 --> Config Class Initialized
INFO - 2023-05-01 09:25:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:22 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:22 --> URI Class Initialized
INFO - 2023-05-01 09:25:22 --> Router Class Initialized
INFO - 2023-05-01 09:25:22 --> Output Class Initialized
INFO - 2023-05-01 09:25:22 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:22 --> Input Class Initialized
INFO - 2023-05-01 09:25:22 --> Language Class Initialized
INFO - 2023-05-01 09:25:22 --> Language Class Initialized
INFO - 2023-05-01 09:25:22 --> Config Class Initialized
INFO - 2023-05-01 09:25:22 --> Loader Class Initialized
INFO - 2023-05-01 09:25:22 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:22 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:22 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:22 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:22 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:22 --> Controller Class Initialized
INFO - 2023-05-01 09:25:23 --> Config Class Initialized
INFO - 2023-05-01 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:23 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:23 --> URI Class Initialized
INFO - 2023-05-01 09:25:23 --> Router Class Initialized
INFO - 2023-05-01 09:25:23 --> Output Class Initialized
INFO - 2023-05-01 09:25:23 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:23 --> Input Class Initialized
INFO - 2023-05-01 09:25:23 --> Language Class Initialized
INFO - 2023-05-01 09:25:23 --> Language Class Initialized
INFO - 2023-05-01 09:25:23 --> Config Class Initialized
INFO - 2023-05-01 09:25:23 --> Loader Class Initialized
INFO - 2023-05-01 09:25:23 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:23 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:23 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:23 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:23 --> Controller Class Initialized
DEBUG - 2023-05-01 09:25:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-05-01 09:25:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:25:23 --> Final output sent to browser
DEBUG - 2023-05-01 09:25:23 --> Total execution time: 0.0217
INFO - 2023-05-01 09:25:24 --> Config Class Initialized
INFO - 2023-05-01 09:25:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:24 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:24 --> URI Class Initialized
INFO - 2023-05-01 09:25:24 --> Router Class Initialized
INFO - 2023-05-01 09:25:24 --> Output Class Initialized
INFO - 2023-05-01 09:25:24 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:24 --> Input Class Initialized
INFO - 2023-05-01 09:25:24 --> Language Class Initialized
INFO - 2023-05-01 09:25:24 --> Language Class Initialized
INFO - 2023-05-01 09:25:24 --> Config Class Initialized
INFO - 2023-05-01 09:25:24 --> Loader Class Initialized
INFO - 2023-05-01 09:25:24 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:24 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:24 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:24 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:24 --> Controller Class Initialized
INFO - 2023-05-01 09:25:34 --> Config Class Initialized
INFO - 2023-05-01 09:25:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:34 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:34 --> URI Class Initialized
INFO - 2023-05-01 09:25:34 --> Router Class Initialized
INFO - 2023-05-01 09:25:34 --> Output Class Initialized
INFO - 2023-05-01 09:25:34 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:34 --> Input Class Initialized
INFO - 2023-05-01 09:25:34 --> Language Class Initialized
INFO - 2023-05-01 09:25:34 --> Language Class Initialized
INFO - 2023-05-01 09:25:34 --> Config Class Initialized
INFO - 2023-05-01 09:25:34 --> Loader Class Initialized
INFO - 2023-05-01 09:25:34 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:34 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:34 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:34 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:34 --> Controller Class Initialized
INFO - 2023-05-01 09:25:34 --> Final output sent to browser
DEBUG - 2023-05-01 09:25:34 --> Total execution time: 0.0399
INFO - 2023-05-01 09:25:55 --> Config Class Initialized
INFO - 2023-05-01 09:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:55 --> URI Class Initialized
INFO - 2023-05-01 09:25:55 --> Router Class Initialized
INFO - 2023-05-01 09:25:55 --> Output Class Initialized
INFO - 2023-05-01 09:25:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:55 --> Input Class Initialized
INFO - 2023-05-01 09:25:55 --> Language Class Initialized
INFO - 2023-05-01 09:25:55 --> Language Class Initialized
INFO - 2023-05-01 09:25:55 --> Config Class Initialized
INFO - 2023-05-01 09:25:55 --> Loader Class Initialized
INFO - 2023-05-01 09:25:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:55 --> Controller Class Initialized
INFO - 2023-05-01 09:25:55 --> Final output sent to browser
DEBUG - 2023-05-01 09:25:55 --> Total execution time: 0.0251
INFO - 2023-05-01 09:25:55 --> Config Class Initialized
INFO - 2023-05-01 09:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:25:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:25:55 --> URI Class Initialized
INFO - 2023-05-01 09:25:55 --> Router Class Initialized
INFO - 2023-05-01 09:25:55 --> Output Class Initialized
INFO - 2023-05-01 09:25:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:25:55 --> Input Class Initialized
INFO - 2023-05-01 09:25:55 --> Language Class Initialized
INFO - 2023-05-01 09:25:55 --> Language Class Initialized
INFO - 2023-05-01 09:25:55 --> Config Class Initialized
INFO - 2023-05-01 09:25:55 --> Loader Class Initialized
INFO - 2023-05-01 09:25:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:25:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:25:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:25:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:25:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:25:55 --> Controller Class Initialized
INFO - 2023-05-01 09:26:22 --> Config Class Initialized
INFO - 2023-05-01 09:26:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:22 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:22 --> URI Class Initialized
INFO - 2023-05-01 09:26:22 --> Router Class Initialized
INFO - 2023-05-01 09:26:22 --> Output Class Initialized
INFO - 2023-05-01 09:26:22 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:22 --> Input Class Initialized
INFO - 2023-05-01 09:26:22 --> Language Class Initialized
INFO - 2023-05-01 09:26:22 --> Language Class Initialized
INFO - 2023-05-01 09:26:22 --> Config Class Initialized
INFO - 2023-05-01 09:26:22 --> Loader Class Initialized
INFO - 2023-05-01 09:26:22 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:22 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:22 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:22 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:22 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:22 --> Controller Class Initialized
INFO - 2023-05-01 09:26:22 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:22 --> Total execution time: 0.0305
INFO - 2023-05-01 09:26:30 --> Config Class Initialized
INFO - 2023-05-01 09:26:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:30 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:30 --> URI Class Initialized
INFO - 2023-05-01 09:26:30 --> Router Class Initialized
INFO - 2023-05-01 09:26:30 --> Output Class Initialized
INFO - 2023-05-01 09:26:30 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:30 --> Input Class Initialized
INFO - 2023-05-01 09:26:30 --> Language Class Initialized
INFO - 2023-05-01 09:26:30 --> Language Class Initialized
INFO - 2023-05-01 09:26:30 --> Config Class Initialized
INFO - 2023-05-01 09:26:30 --> Loader Class Initialized
INFO - 2023-05-01 09:26:30 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:30 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:30 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:30 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:30 --> Controller Class Initialized
INFO - 2023-05-01 09:26:30 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:30 --> Total execution time: 0.0255
INFO - 2023-05-01 09:26:30 --> Config Class Initialized
INFO - 2023-05-01 09:26:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:30 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:30 --> URI Class Initialized
INFO - 2023-05-01 09:26:30 --> Router Class Initialized
INFO - 2023-05-01 09:26:30 --> Output Class Initialized
INFO - 2023-05-01 09:26:30 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:30 --> Input Class Initialized
INFO - 2023-05-01 09:26:30 --> Language Class Initialized
INFO - 2023-05-01 09:26:31 --> Language Class Initialized
INFO - 2023-05-01 09:26:31 --> Config Class Initialized
INFO - 2023-05-01 09:26:31 --> Loader Class Initialized
INFO - 2023-05-01 09:26:31 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:31 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:31 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:31 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:31 --> Controller Class Initialized
INFO - 2023-05-01 09:26:34 --> Config Class Initialized
INFO - 2023-05-01 09:26:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:34 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:34 --> URI Class Initialized
DEBUG - 2023-05-01 09:26:34 --> No URI present. Default controller set.
INFO - 2023-05-01 09:26:34 --> Router Class Initialized
INFO - 2023-05-01 09:26:34 --> Output Class Initialized
INFO - 2023-05-01 09:26:34 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:34 --> Input Class Initialized
INFO - 2023-05-01 09:26:34 --> Language Class Initialized
INFO - 2023-05-01 09:26:34 --> Language Class Initialized
INFO - 2023-05-01 09:26:34 --> Config Class Initialized
INFO - 2023-05-01 09:26:34 --> Loader Class Initialized
INFO - 2023-05-01 09:26:34 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:34 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:34 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:34 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:34 --> Controller Class Initialized
DEBUG - 2023-05-01 09:26:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-01 09:26:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:26:34 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:34 --> Total execution time: 0.0422
INFO - 2023-05-01 09:26:37 --> Config Class Initialized
INFO - 2023-05-01 09:26:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:37 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:37 --> URI Class Initialized
INFO - 2023-05-01 09:26:37 --> Router Class Initialized
INFO - 2023-05-01 09:26:37 --> Output Class Initialized
INFO - 2023-05-01 09:26:37 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:37 --> Input Class Initialized
INFO - 2023-05-01 09:26:37 --> Language Class Initialized
INFO - 2023-05-01 09:26:37 --> Language Class Initialized
INFO - 2023-05-01 09:26:37 --> Config Class Initialized
INFO - 2023-05-01 09:26:37 --> Loader Class Initialized
INFO - 2023-05-01 09:26:37 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:37 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:37 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:37 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:37 --> Controller Class Initialized
DEBUG - 2023-05-01 09:26:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 09:26:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:26:37 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:37 --> Total execution time: 0.0408
INFO - 2023-05-01 09:26:37 --> Config Class Initialized
INFO - 2023-05-01 09:26:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:37 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:37 --> URI Class Initialized
INFO - 2023-05-01 09:26:37 --> Router Class Initialized
INFO - 2023-05-01 09:26:37 --> Output Class Initialized
INFO - 2023-05-01 09:26:37 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:37 --> Input Class Initialized
INFO - 2023-05-01 09:26:37 --> Language Class Initialized
INFO - 2023-05-01 09:26:37 --> Language Class Initialized
INFO - 2023-05-01 09:26:37 --> Config Class Initialized
INFO - 2023-05-01 09:26:37 --> Loader Class Initialized
INFO - 2023-05-01 09:26:37 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:37 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:37 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:37 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:37 --> Controller Class Initialized
INFO - 2023-05-01 09:26:38 --> Config Class Initialized
INFO - 2023-05-01 09:26:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:38 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:38 --> URI Class Initialized
INFO - 2023-05-01 09:26:38 --> Router Class Initialized
INFO - 2023-05-01 09:26:38 --> Output Class Initialized
INFO - 2023-05-01 09:26:38 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:38 --> Input Class Initialized
INFO - 2023-05-01 09:26:38 --> Language Class Initialized
INFO - 2023-05-01 09:26:38 --> Language Class Initialized
INFO - 2023-05-01 09:26:38 --> Config Class Initialized
INFO - 2023-05-01 09:26:38 --> Loader Class Initialized
INFO - 2023-05-01 09:26:38 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:38 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:38 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:38 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:38 --> Controller Class Initialized
DEBUG - 2023-05-01 09:26:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-05-01 09:26:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:26:38 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:38 --> Total execution time: 0.0288
INFO - 2023-05-01 09:26:42 --> Config Class Initialized
INFO - 2023-05-01 09:26:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:42 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:42 --> URI Class Initialized
INFO - 2023-05-01 09:26:42 --> Router Class Initialized
INFO - 2023-05-01 09:26:42 --> Output Class Initialized
INFO - 2023-05-01 09:26:42 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:42 --> Input Class Initialized
INFO - 2023-05-01 09:26:42 --> Language Class Initialized
INFO - 2023-05-01 09:26:42 --> Language Class Initialized
INFO - 2023-05-01 09:26:42 --> Config Class Initialized
INFO - 2023-05-01 09:26:42 --> Loader Class Initialized
INFO - 2023-05-01 09:26:42 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:42 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:42 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:42 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:42 --> Controller Class Initialized
DEBUG - 2023-05-01 09:26:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 09:26:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:26:42 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:42 --> Total execution time: 0.0420
INFO - 2023-05-01 09:26:42 --> Config Class Initialized
INFO - 2023-05-01 09:26:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:42 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:42 --> URI Class Initialized
INFO - 2023-05-01 09:26:42 --> Router Class Initialized
INFO - 2023-05-01 09:26:42 --> Output Class Initialized
INFO - 2023-05-01 09:26:42 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:42 --> Input Class Initialized
INFO - 2023-05-01 09:26:42 --> Language Class Initialized
INFO - 2023-05-01 09:26:42 --> Language Class Initialized
INFO - 2023-05-01 09:26:42 --> Config Class Initialized
INFO - 2023-05-01 09:26:42 --> Loader Class Initialized
INFO - 2023-05-01 09:26:42 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:42 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:42 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:42 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:42 --> Controller Class Initialized
INFO - 2023-05-01 09:26:45 --> Config Class Initialized
INFO - 2023-05-01 09:26:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:45 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:45 --> URI Class Initialized
INFO - 2023-05-01 09:26:45 --> Router Class Initialized
INFO - 2023-05-01 09:26:45 --> Output Class Initialized
INFO - 2023-05-01 09:26:45 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:45 --> Input Class Initialized
INFO - 2023-05-01 09:26:45 --> Language Class Initialized
INFO - 2023-05-01 09:26:45 --> Language Class Initialized
INFO - 2023-05-01 09:26:45 --> Config Class Initialized
INFO - 2023-05-01 09:26:45 --> Loader Class Initialized
INFO - 2023-05-01 09:26:45 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:45 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:45 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:45 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:45 --> Controller Class Initialized
DEBUG - 2023-05-01 09:26:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-05-01 09:26:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:26:45 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:45 --> Total execution time: 0.0255
INFO - 2023-05-01 09:26:58 --> Config Class Initialized
INFO - 2023-05-01 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:58 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:58 --> URI Class Initialized
INFO - 2023-05-01 09:26:58 --> Router Class Initialized
INFO - 2023-05-01 09:26:58 --> Output Class Initialized
INFO - 2023-05-01 09:26:58 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:58 --> Input Class Initialized
INFO - 2023-05-01 09:26:58 --> Language Class Initialized
INFO - 2023-05-01 09:26:58 --> Language Class Initialized
INFO - 2023-05-01 09:26:58 --> Config Class Initialized
INFO - 2023-05-01 09:26:58 --> Loader Class Initialized
INFO - 2023-05-01 09:26:58 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:58 --> Controller Class Initialized
INFO - 2023-05-01 09:26:58 --> Config Class Initialized
INFO - 2023-05-01 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:58 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:58 --> URI Class Initialized
INFO - 2023-05-01 09:26:58 --> Router Class Initialized
INFO - 2023-05-01 09:26:58 --> Output Class Initialized
INFO - 2023-05-01 09:26:58 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:58 --> Input Class Initialized
INFO - 2023-05-01 09:26:58 --> Language Class Initialized
INFO - 2023-05-01 09:26:58 --> Language Class Initialized
INFO - 2023-05-01 09:26:58 --> Config Class Initialized
INFO - 2023-05-01 09:26:58 --> Loader Class Initialized
INFO - 2023-05-01 09:26:58 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:58 --> Controller Class Initialized
DEBUG - 2023-05-01 09:26:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 09:26:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:26:58 --> Final output sent to browser
DEBUG - 2023-05-01 09:26:58 --> Total execution time: 0.0357
INFO - 2023-05-01 09:26:58 --> Config Class Initialized
INFO - 2023-05-01 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:26:58 --> Utf8 Class Initialized
INFO - 2023-05-01 09:26:58 --> URI Class Initialized
INFO - 2023-05-01 09:26:58 --> Router Class Initialized
INFO - 2023-05-01 09:26:58 --> Output Class Initialized
INFO - 2023-05-01 09:26:58 --> Security Class Initialized
DEBUG - 2023-05-01 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:26:58 --> Input Class Initialized
INFO - 2023-05-01 09:26:58 --> Language Class Initialized
INFO - 2023-05-01 09:26:58 --> Language Class Initialized
INFO - 2023-05-01 09:26:58 --> Config Class Initialized
INFO - 2023-05-01 09:26:58 --> Loader Class Initialized
INFO - 2023-05-01 09:26:58 --> Helper loaded: url_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: file_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: form_helper
INFO - 2023-05-01 09:26:58 --> Helper loaded: my_helper
INFO - 2023-05-01 09:26:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:26:58 --> Controller Class Initialized
INFO - 2023-05-01 09:27:08 --> Config Class Initialized
INFO - 2023-05-01 09:27:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:08 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:08 --> URI Class Initialized
INFO - 2023-05-01 09:27:08 --> Router Class Initialized
INFO - 2023-05-01 09:27:08 --> Output Class Initialized
INFO - 2023-05-01 09:27:08 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:08 --> Input Class Initialized
INFO - 2023-05-01 09:27:08 --> Language Class Initialized
INFO - 2023-05-01 09:27:08 --> Language Class Initialized
INFO - 2023-05-01 09:27:08 --> Config Class Initialized
INFO - 2023-05-01 09:27:08 --> Loader Class Initialized
INFO - 2023-05-01 09:27:08 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:08 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:08 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:08 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:08 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:08 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-05-01 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:08 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:08 --> Total execution time: 0.0274
INFO - 2023-05-01 09:27:20 --> Config Class Initialized
INFO - 2023-05-01 09:27:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:20 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:20 --> URI Class Initialized
INFO - 2023-05-01 09:27:20 --> Router Class Initialized
INFO - 2023-05-01 09:27:20 --> Output Class Initialized
INFO - 2023-05-01 09:27:20 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:20 --> Input Class Initialized
INFO - 2023-05-01 09:27:20 --> Language Class Initialized
INFO - 2023-05-01 09:27:20 --> Language Class Initialized
INFO - 2023-05-01 09:27:20 --> Config Class Initialized
INFO - 2023-05-01 09:27:20 --> Loader Class Initialized
INFO - 2023-05-01 09:27:20 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:20 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:20 --> Controller Class Initialized
INFO - 2023-05-01 09:27:20 --> Config Class Initialized
INFO - 2023-05-01 09:27:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:20 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:20 --> URI Class Initialized
INFO - 2023-05-01 09:27:20 --> Router Class Initialized
INFO - 2023-05-01 09:27:20 --> Output Class Initialized
INFO - 2023-05-01 09:27:20 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:20 --> Input Class Initialized
INFO - 2023-05-01 09:27:20 --> Language Class Initialized
INFO - 2023-05-01 09:27:20 --> Language Class Initialized
INFO - 2023-05-01 09:27:20 --> Config Class Initialized
INFO - 2023-05-01 09:27:20 --> Loader Class Initialized
INFO - 2023-05-01 09:27:20 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:20 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:20 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 09:27:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:20 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:20 --> Total execution time: 0.0262
INFO - 2023-05-01 09:27:20 --> Config Class Initialized
INFO - 2023-05-01 09:27:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:20 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:20 --> URI Class Initialized
INFO - 2023-05-01 09:27:20 --> Router Class Initialized
INFO - 2023-05-01 09:27:20 --> Output Class Initialized
INFO - 2023-05-01 09:27:20 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:20 --> Input Class Initialized
INFO - 2023-05-01 09:27:20 --> Language Class Initialized
INFO - 2023-05-01 09:27:20 --> Language Class Initialized
INFO - 2023-05-01 09:27:20 --> Config Class Initialized
INFO - 2023-05-01 09:27:20 --> Loader Class Initialized
INFO - 2023-05-01 09:27:20 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:20 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:20 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:20 --> Controller Class Initialized
INFO - 2023-05-01 09:27:23 --> Config Class Initialized
INFO - 2023-05-01 09:27:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:23 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:23 --> URI Class Initialized
INFO - 2023-05-01 09:27:23 --> Router Class Initialized
INFO - 2023-05-01 09:27:23 --> Output Class Initialized
INFO - 2023-05-01 09:27:23 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:23 --> Input Class Initialized
INFO - 2023-05-01 09:27:23 --> Language Class Initialized
INFO - 2023-05-01 09:27:23 --> Language Class Initialized
INFO - 2023-05-01 09:27:23 --> Config Class Initialized
INFO - 2023-05-01 09:27:23 --> Loader Class Initialized
INFO - 2023-05-01 09:27:23 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:23 --> Controller Class Initialized
INFO - 2023-05-01 09:27:23 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:27:23 --> Config Class Initialized
INFO - 2023-05-01 09:27:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:23 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:23 --> URI Class Initialized
INFO - 2023-05-01 09:27:23 --> Router Class Initialized
INFO - 2023-05-01 09:27:23 --> Output Class Initialized
INFO - 2023-05-01 09:27:23 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:23 --> Input Class Initialized
INFO - 2023-05-01 09:27:23 --> Language Class Initialized
INFO - 2023-05-01 09:27:23 --> Language Class Initialized
INFO - 2023-05-01 09:27:23 --> Config Class Initialized
INFO - 2023-05-01 09:27:23 --> Loader Class Initialized
INFO - 2023-05-01 09:27:23 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:23 --> Controller Class Initialized
INFO - 2023-05-01 09:27:23 --> Config Class Initialized
INFO - 2023-05-01 09:27:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:23 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:23 --> URI Class Initialized
INFO - 2023-05-01 09:27:23 --> Router Class Initialized
INFO - 2023-05-01 09:27:23 --> Output Class Initialized
INFO - 2023-05-01 09:27:23 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:23 --> Input Class Initialized
INFO - 2023-05-01 09:27:23 --> Language Class Initialized
INFO - 2023-05-01 09:27:23 --> Language Class Initialized
INFO - 2023-05-01 09:27:23 --> Config Class Initialized
INFO - 2023-05-01 09:27:23 --> Loader Class Initialized
INFO - 2023-05-01 09:27:23 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:23 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:23 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 09:27:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:23 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:23 --> Total execution time: 0.0477
INFO - 2023-05-01 09:27:31 --> Config Class Initialized
INFO - 2023-05-01 09:27:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:31 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:31 --> URI Class Initialized
INFO - 2023-05-01 09:27:31 --> Router Class Initialized
INFO - 2023-05-01 09:27:31 --> Output Class Initialized
INFO - 2023-05-01 09:27:31 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:31 --> Input Class Initialized
INFO - 2023-05-01 09:27:31 --> Language Class Initialized
INFO - 2023-05-01 09:27:31 --> Language Class Initialized
INFO - 2023-05-01 09:27:31 --> Config Class Initialized
INFO - 2023-05-01 09:27:31 --> Loader Class Initialized
INFO - 2023-05-01 09:27:31 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:31 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:31 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:31 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:31 --> Controller Class Initialized
INFO - 2023-05-01 09:27:31 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:27:31 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:31 --> Total execution time: 0.0254
INFO - 2023-05-01 09:27:31 --> Config Class Initialized
INFO - 2023-05-01 09:27:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:31 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:31 --> URI Class Initialized
INFO - 2023-05-01 09:27:31 --> Router Class Initialized
INFO - 2023-05-01 09:27:31 --> Output Class Initialized
INFO - 2023-05-01 09:27:31 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:31 --> Input Class Initialized
INFO - 2023-05-01 09:27:31 --> Language Class Initialized
INFO - 2023-05-01 09:27:31 --> Language Class Initialized
INFO - 2023-05-01 09:27:31 --> Config Class Initialized
INFO - 2023-05-01 09:27:31 --> Loader Class Initialized
INFO - 2023-05-01 09:27:31 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:31 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:31 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:31 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:31 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 09:27:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:31 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:31 --> Total execution time: 0.0504
INFO - 2023-05-01 09:27:33 --> Config Class Initialized
INFO - 2023-05-01 09:27:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:33 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:33 --> URI Class Initialized
INFO - 2023-05-01 09:27:33 --> Router Class Initialized
INFO - 2023-05-01 09:27:33 --> Output Class Initialized
INFO - 2023-05-01 09:27:33 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:33 --> Input Class Initialized
INFO - 2023-05-01 09:27:33 --> Language Class Initialized
INFO - 2023-05-01 09:27:33 --> Language Class Initialized
INFO - 2023-05-01 09:27:33 --> Config Class Initialized
INFO - 2023-05-01 09:27:33 --> Loader Class Initialized
INFO - 2023-05-01 09:27:33 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:33 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:33 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:33 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:33 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:27:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:33 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:33 --> Total execution time: 0.0415
INFO - 2023-05-01 09:27:40 --> Config Class Initialized
INFO - 2023-05-01 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:40 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:40 --> URI Class Initialized
INFO - 2023-05-01 09:27:40 --> Router Class Initialized
INFO - 2023-05-01 09:27:40 --> Output Class Initialized
INFO - 2023-05-01 09:27:40 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:40 --> Input Class Initialized
INFO - 2023-05-01 09:27:40 --> Language Class Initialized
INFO - 2023-05-01 09:27:40 --> Language Class Initialized
INFO - 2023-05-01 09:27:40 --> Config Class Initialized
INFO - 2023-05-01 09:27:40 --> Loader Class Initialized
INFO - 2023-05-01 09:27:40 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:40 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:40 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:40 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:40 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 09:27:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:40 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:40 --> Total execution time: 0.0484
INFO - 2023-05-01 09:27:40 --> Config Class Initialized
INFO - 2023-05-01 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:40 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:40 --> URI Class Initialized
INFO - 2023-05-01 09:27:40 --> Router Class Initialized
INFO - 2023-05-01 09:27:40 --> Output Class Initialized
INFO - 2023-05-01 09:27:40 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:40 --> Input Class Initialized
INFO - 2023-05-01 09:27:40 --> Language Class Initialized
INFO - 2023-05-01 09:27:40 --> Language Class Initialized
INFO - 2023-05-01 09:27:40 --> Config Class Initialized
INFO - 2023-05-01 09:27:40 --> Loader Class Initialized
INFO - 2023-05-01 09:27:40 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:40 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:40 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:40 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:40 --> Controller Class Initialized
INFO - 2023-05-01 09:27:44 --> Config Class Initialized
INFO - 2023-05-01 09:27:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:44 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:44 --> URI Class Initialized
INFO - 2023-05-01 09:27:44 --> Router Class Initialized
INFO - 2023-05-01 09:27:44 --> Output Class Initialized
INFO - 2023-05-01 09:27:44 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:44 --> Input Class Initialized
INFO - 2023-05-01 09:27:44 --> Language Class Initialized
INFO - 2023-05-01 09:27:44 --> Language Class Initialized
INFO - 2023-05-01 09:27:44 --> Config Class Initialized
INFO - 2023-05-01 09:27:44 --> Loader Class Initialized
INFO - 2023-05-01 09:27:44 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:44 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:44 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:44 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:44 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:44 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:27:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:44 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:44 --> Total execution time: 0.0436
INFO - 2023-05-01 09:27:47 --> Config Class Initialized
INFO - 2023-05-01 09:27:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:47 --> URI Class Initialized
INFO - 2023-05-01 09:27:47 --> Router Class Initialized
INFO - 2023-05-01 09:27:47 --> Output Class Initialized
INFO - 2023-05-01 09:27:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:47 --> Input Class Initialized
INFO - 2023-05-01 09:27:47 --> Language Class Initialized
INFO - 2023-05-01 09:27:47 --> Language Class Initialized
INFO - 2023-05-01 09:27:47 --> Config Class Initialized
INFO - 2023-05-01 09:27:47 --> Loader Class Initialized
INFO - 2023-05-01 09:27:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:47 --> Controller Class Initialized
INFO - 2023-05-01 09:27:47 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:27:47 --> Config Class Initialized
INFO - 2023-05-01 09:27:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:47 --> URI Class Initialized
INFO - 2023-05-01 09:27:47 --> Router Class Initialized
INFO - 2023-05-01 09:27:47 --> Output Class Initialized
INFO - 2023-05-01 09:27:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:47 --> Input Class Initialized
INFO - 2023-05-01 09:27:47 --> Language Class Initialized
INFO - 2023-05-01 09:27:47 --> Language Class Initialized
INFO - 2023-05-01 09:27:47 --> Config Class Initialized
INFO - 2023-05-01 09:27:47 --> Loader Class Initialized
INFO - 2023-05-01 09:27:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:47 --> Controller Class Initialized
INFO - 2023-05-01 09:27:47 --> Config Class Initialized
INFO - 2023-05-01 09:27:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:47 --> URI Class Initialized
INFO - 2023-05-01 09:27:47 --> Router Class Initialized
INFO - 2023-05-01 09:27:47 --> Output Class Initialized
INFO - 2023-05-01 09:27:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:47 --> Input Class Initialized
INFO - 2023-05-01 09:27:47 --> Language Class Initialized
INFO - 2023-05-01 09:27:47 --> Language Class Initialized
INFO - 2023-05-01 09:27:47 --> Config Class Initialized
INFO - 2023-05-01 09:27:47 --> Loader Class Initialized
INFO - 2023-05-01 09:27:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:47 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 09:27:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:47 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:47 --> Total execution time: 0.0473
INFO - 2023-05-01 09:27:54 --> Config Class Initialized
INFO - 2023-05-01 09:27:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:54 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:54 --> URI Class Initialized
INFO - 2023-05-01 09:27:54 --> Router Class Initialized
INFO - 2023-05-01 09:27:54 --> Output Class Initialized
INFO - 2023-05-01 09:27:54 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:54 --> Input Class Initialized
INFO - 2023-05-01 09:27:54 --> Language Class Initialized
INFO - 2023-05-01 09:27:54 --> Language Class Initialized
INFO - 2023-05-01 09:27:54 --> Config Class Initialized
INFO - 2023-05-01 09:27:54 --> Loader Class Initialized
INFO - 2023-05-01 09:27:54 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:54 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:54 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:54 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:54 --> Controller Class Initialized
INFO - 2023-05-01 09:27:54 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:27:54 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:54 --> Total execution time: 0.0286
INFO - 2023-05-01 09:27:54 --> Config Class Initialized
INFO - 2023-05-01 09:27:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:54 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:54 --> URI Class Initialized
INFO - 2023-05-01 09:27:54 --> Router Class Initialized
INFO - 2023-05-01 09:27:54 --> Output Class Initialized
INFO - 2023-05-01 09:27:54 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:54 --> Input Class Initialized
INFO - 2023-05-01 09:27:54 --> Language Class Initialized
INFO - 2023-05-01 09:27:54 --> Language Class Initialized
INFO - 2023-05-01 09:27:54 --> Config Class Initialized
INFO - 2023-05-01 09:27:54 --> Loader Class Initialized
INFO - 2023-05-01 09:27:54 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:54 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:54 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:54 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:54 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 09:27:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:54 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:54 --> Total execution time: 0.0299
INFO - 2023-05-01 09:27:56 --> Config Class Initialized
INFO - 2023-05-01 09:27:56 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:56 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:56 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:56 --> URI Class Initialized
INFO - 2023-05-01 09:27:56 --> Router Class Initialized
INFO - 2023-05-01 09:27:56 --> Output Class Initialized
INFO - 2023-05-01 09:27:56 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:56 --> Input Class Initialized
INFO - 2023-05-01 09:27:56 --> Language Class Initialized
INFO - 2023-05-01 09:27:56 --> Language Class Initialized
INFO - 2023-05-01 09:27:56 --> Config Class Initialized
INFO - 2023-05-01 09:27:56 --> Loader Class Initialized
INFO - 2023-05-01 09:27:56 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:56 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:56 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:56 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:56 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:56 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:27:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:56 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:56 --> Total execution time: 0.0305
INFO - 2023-05-01 09:27:57 --> Config Class Initialized
INFO - 2023-05-01 09:27:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:57 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:57 --> URI Class Initialized
INFO - 2023-05-01 09:27:57 --> Router Class Initialized
INFO - 2023-05-01 09:27:57 --> Output Class Initialized
INFO - 2023-05-01 09:27:57 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:57 --> Input Class Initialized
INFO - 2023-05-01 09:27:57 --> Language Class Initialized
INFO - 2023-05-01 09:27:57 --> Language Class Initialized
INFO - 2023-05-01 09:27:57 --> Config Class Initialized
INFO - 2023-05-01 09:27:57 --> Loader Class Initialized
INFO - 2023-05-01 09:27:57 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:57 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:57 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:57 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:57 --> Controller Class Initialized
DEBUG - 2023-05-01 09:27:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-01 09:27:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:27:57 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:57 --> Total execution time: 0.0785
INFO - 2023-05-01 09:27:57 --> Config Class Initialized
INFO - 2023-05-01 09:27:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:57 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:57 --> URI Class Initialized
INFO - 2023-05-01 09:27:57 --> Router Class Initialized
INFO - 2023-05-01 09:27:57 --> Output Class Initialized
INFO - 2023-05-01 09:27:57 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:57 --> Input Class Initialized
INFO - 2023-05-01 09:27:57 --> Language Class Initialized
INFO - 2023-05-01 09:27:57 --> Language Class Initialized
INFO - 2023-05-01 09:27:57 --> Config Class Initialized
INFO - 2023-05-01 09:27:57 --> Loader Class Initialized
INFO - 2023-05-01 09:27:57 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:57 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:57 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:57 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:57 --> Controller Class Initialized
INFO - 2023-05-01 09:27:59 --> Config Class Initialized
INFO - 2023-05-01 09:27:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:27:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:27:59 --> Utf8 Class Initialized
INFO - 2023-05-01 09:27:59 --> URI Class Initialized
INFO - 2023-05-01 09:27:59 --> Router Class Initialized
INFO - 2023-05-01 09:27:59 --> Output Class Initialized
INFO - 2023-05-01 09:27:59 --> Security Class Initialized
DEBUG - 2023-05-01 09:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:27:59 --> Input Class Initialized
INFO - 2023-05-01 09:27:59 --> Language Class Initialized
INFO - 2023-05-01 09:27:59 --> Language Class Initialized
INFO - 2023-05-01 09:27:59 --> Config Class Initialized
INFO - 2023-05-01 09:27:59 --> Loader Class Initialized
INFO - 2023-05-01 09:27:59 --> Helper loaded: url_helper
INFO - 2023-05-01 09:27:59 --> Helper loaded: file_helper
INFO - 2023-05-01 09:27:59 --> Helper loaded: form_helper
INFO - 2023-05-01 09:27:59 --> Helper loaded: my_helper
INFO - 2023-05-01 09:27:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:27:59 --> Controller Class Initialized
INFO - 2023-05-01 09:27:59 --> Final output sent to browser
DEBUG - 2023-05-01 09:27:59 --> Total execution time: 0.0250
INFO - 2023-05-01 09:28:00 --> Config Class Initialized
INFO - 2023-05-01 09:28:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:00 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:00 --> URI Class Initialized
INFO - 2023-05-01 09:28:00 --> Router Class Initialized
INFO - 2023-05-01 09:28:00 --> Output Class Initialized
INFO - 2023-05-01 09:28:00 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:00 --> Input Class Initialized
INFO - 2023-05-01 09:28:00 --> Language Class Initialized
INFO - 2023-05-01 09:28:00 --> Language Class Initialized
INFO - 2023-05-01 09:28:00 --> Config Class Initialized
INFO - 2023-05-01 09:28:00 --> Loader Class Initialized
INFO - 2023-05-01 09:28:00 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:00 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:00 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:00 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:00 --> Controller Class Initialized
INFO - 2023-05-01 09:28:00 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:00 --> Total execution time: 0.0234
INFO - 2023-05-01 09:28:05 --> Config Class Initialized
INFO - 2023-05-01 09:28:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:05 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:05 --> URI Class Initialized
INFO - 2023-05-01 09:28:05 --> Router Class Initialized
INFO - 2023-05-01 09:28:05 --> Output Class Initialized
INFO - 2023-05-01 09:28:05 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:05 --> Input Class Initialized
INFO - 2023-05-01 09:28:05 --> Language Class Initialized
INFO - 2023-05-01 09:28:05 --> Language Class Initialized
INFO - 2023-05-01 09:28:05 --> Config Class Initialized
INFO - 2023-05-01 09:28:05 --> Loader Class Initialized
INFO - 2023-05-01 09:28:05 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:05 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:05 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:05 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:05 --> Controller Class Initialized
DEBUG - 2023-05-01 09:28:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:28:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:28:05 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:05 --> Total execution time: 0.0414
INFO - 2023-05-01 09:28:25 --> Config Class Initialized
INFO - 2023-05-01 09:28:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:25 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:25 --> URI Class Initialized
INFO - 2023-05-01 09:28:25 --> Router Class Initialized
INFO - 2023-05-01 09:28:25 --> Output Class Initialized
INFO - 2023-05-01 09:28:25 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:25 --> Input Class Initialized
INFO - 2023-05-01 09:28:25 --> Language Class Initialized
INFO - 2023-05-01 09:28:25 --> Language Class Initialized
INFO - 2023-05-01 09:28:25 --> Config Class Initialized
INFO - 2023-05-01 09:28:25 --> Loader Class Initialized
INFO - 2023-05-01 09:28:25 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:25 --> Controller Class Initialized
INFO - 2023-05-01 09:28:25 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:28:25 --> Config Class Initialized
INFO - 2023-05-01 09:28:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:25 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:25 --> URI Class Initialized
INFO - 2023-05-01 09:28:25 --> Router Class Initialized
INFO - 2023-05-01 09:28:25 --> Output Class Initialized
INFO - 2023-05-01 09:28:25 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:25 --> Input Class Initialized
INFO - 2023-05-01 09:28:25 --> Language Class Initialized
INFO - 2023-05-01 09:28:25 --> Language Class Initialized
INFO - 2023-05-01 09:28:25 --> Config Class Initialized
INFO - 2023-05-01 09:28:25 --> Loader Class Initialized
INFO - 2023-05-01 09:28:25 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:25 --> Controller Class Initialized
INFO - 2023-05-01 09:28:25 --> Config Class Initialized
INFO - 2023-05-01 09:28:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:25 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:25 --> URI Class Initialized
INFO - 2023-05-01 09:28:25 --> Router Class Initialized
INFO - 2023-05-01 09:28:25 --> Output Class Initialized
INFO - 2023-05-01 09:28:25 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:25 --> Input Class Initialized
INFO - 2023-05-01 09:28:25 --> Language Class Initialized
INFO - 2023-05-01 09:28:25 --> Language Class Initialized
INFO - 2023-05-01 09:28:25 --> Config Class Initialized
INFO - 2023-05-01 09:28:25 --> Loader Class Initialized
INFO - 2023-05-01 09:28:25 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:25 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:25 --> Controller Class Initialized
DEBUG - 2023-05-01 09:28:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 09:28:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:28:25 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:25 --> Total execution time: 0.0427
INFO - 2023-05-01 09:28:32 --> Config Class Initialized
INFO - 2023-05-01 09:28:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:32 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:32 --> URI Class Initialized
INFO - 2023-05-01 09:28:32 --> Router Class Initialized
INFO - 2023-05-01 09:28:32 --> Output Class Initialized
INFO - 2023-05-01 09:28:32 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:32 --> Input Class Initialized
INFO - 2023-05-01 09:28:32 --> Language Class Initialized
INFO - 2023-05-01 09:28:32 --> Language Class Initialized
INFO - 2023-05-01 09:28:32 --> Config Class Initialized
INFO - 2023-05-01 09:28:32 --> Loader Class Initialized
INFO - 2023-05-01 09:28:32 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:32 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:32 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:32 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:32 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:32 --> Controller Class Initialized
INFO - 2023-05-01 09:28:32 --> Helper loaded: cookie_helper
INFO - 2023-05-01 09:28:32 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:32 --> Total execution time: 0.0361
INFO - 2023-05-01 09:28:32 --> Config Class Initialized
INFO - 2023-05-01 09:28:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:32 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:32 --> URI Class Initialized
INFO - 2023-05-01 09:28:32 --> Router Class Initialized
INFO - 2023-05-01 09:28:32 --> Output Class Initialized
INFO - 2023-05-01 09:28:32 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:32 --> Input Class Initialized
INFO - 2023-05-01 09:28:32 --> Language Class Initialized
INFO - 2023-05-01 09:28:32 --> Language Class Initialized
INFO - 2023-05-01 09:28:32 --> Config Class Initialized
INFO - 2023-05-01 09:28:33 --> Loader Class Initialized
INFO - 2023-05-01 09:28:33 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:33 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:33 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:33 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:33 --> Controller Class Initialized
DEBUG - 2023-05-01 09:28:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 09:28:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:28:33 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:33 --> Total execution time: 0.0300
INFO - 2023-05-01 09:28:34 --> Config Class Initialized
INFO - 2023-05-01 09:28:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:34 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:34 --> URI Class Initialized
INFO - 2023-05-01 09:28:34 --> Router Class Initialized
INFO - 2023-05-01 09:28:34 --> Output Class Initialized
INFO - 2023-05-01 09:28:34 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:34 --> Input Class Initialized
INFO - 2023-05-01 09:28:34 --> Language Class Initialized
INFO - 2023-05-01 09:28:34 --> Language Class Initialized
INFO - 2023-05-01 09:28:34 --> Config Class Initialized
INFO - 2023-05-01 09:28:34 --> Loader Class Initialized
INFO - 2023-05-01 09:28:34 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:34 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:34 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:34 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:34 --> Controller Class Initialized
DEBUG - 2023-05-01 09:28:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:28:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:28:34 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:34 --> Total execution time: 0.0433
INFO - 2023-05-01 09:28:42 --> Config Class Initialized
INFO - 2023-05-01 09:28:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:42 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:42 --> URI Class Initialized
INFO - 2023-05-01 09:28:42 --> Router Class Initialized
INFO - 2023-05-01 09:28:42 --> Output Class Initialized
INFO - 2023-05-01 09:28:42 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:42 --> Input Class Initialized
INFO - 2023-05-01 09:28:42 --> Language Class Initialized
INFO - 2023-05-01 09:28:42 --> Language Class Initialized
INFO - 2023-05-01 09:28:42 --> Config Class Initialized
INFO - 2023-05-01 09:28:42 --> Loader Class Initialized
INFO - 2023-05-01 09:28:42 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:42 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:42 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:42 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:42 --> Controller Class Initialized
DEBUG - 2023-05-01 09:28:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 09:28:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:28:42 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:42 --> Total execution time: 0.0254
INFO - 2023-05-01 09:28:42 --> Config Class Initialized
INFO - 2023-05-01 09:28:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:42 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:42 --> URI Class Initialized
INFO - 2023-05-01 09:28:42 --> Router Class Initialized
INFO - 2023-05-01 09:28:42 --> Output Class Initialized
INFO - 2023-05-01 09:28:42 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:42 --> Input Class Initialized
INFO - 2023-05-01 09:28:42 --> Language Class Initialized
INFO - 2023-05-01 09:28:42 --> Language Class Initialized
INFO - 2023-05-01 09:28:42 --> Config Class Initialized
INFO - 2023-05-01 09:28:42 --> Loader Class Initialized
INFO - 2023-05-01 09:28:42 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:42 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:42 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:42 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:42 --> Controller Class Initialized
INFO - 2023-05-01 09:28:47 --> Config Class Initialized
INFO - 2023-05-01 09:28:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:28:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:28:47 --> Utf8 Class Initialized
INFO - 2023-05-01 09:28:47 --> URI Class Initialized
INFO - 2023-05-01 09:28:47 --> Router Class Initialized
INFO - 2023-05-01 09:28:47 --> Output Class Initialized
INFO - 2023-05-01 09:28:47 --> Security Class Initialized
DEBUG - 2023-05-01 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:28:47 --> Input Class Initialized
INFO - 2023-05-01 09:28:47 --> Language Class Initialized
INFO - 2023-05-01 09:28:47 --> Language Class Initialized
INFO - 2023-05-01 09:28:47 --> Config Class Initialized
INFO - 2023-05-01 09:28:47 --> Loader Class Initialized
INFO - 2023-05-01 09:28:47 --> Helper loaded: url_helper
INFO - 2023-05-01 09:28:47 --> Helper loaded: file_helper
INFO - 2023-05-01 09:28:47 --> Helper loaded: form_helper
INFO - 2023-05-01 09:28:47 --> Helper loaded: my_helper
INFO - 2023-05-01 09:28:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:28:47 --> Controller Class Initialized
DEBUG - 2023-05-01 09:28:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:28:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:28:47 --> Final output sent to browser
DEBUG - 2023-05-01 09:28:47 --> Total execution time: 0.0268
INFO - 2023-05-01 09:29:24 --> Config Class Initialized
INFO - 2023-05-01 09:29:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:29:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:29:24 --> Utf8 Class Initialized
INFO - 2023-05-01 09:29:24 --> URI Class Initialized
INFO - 2023-05-01 09:29:24 --> Router Class Initialized
INFO - 2023-05-01 09:29:24 --> Output Class Initialized
INFO - 2023-05-01 09:29:24 --> Security Class Initialized
DEBUG - 2023-05-01 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:29:24 --> Input Class Initialized
INFO - 2023-05-01 09:29:24 --> Language Class Initialized
INFO - 2023-05-01 09:29:24 --> Language Class Initialized
INFO - 2023-05-01 09:29:24 --> Config Class Initialized
INFO - 2023-05-01 09:29:24 --> Loader Class Initialized
INFO - 2023-05-01 09:29:24 --> Helper loaded: url_helper
INFO - 2023-05-01 09:29:24 --> Helper loaded: file_helper
INFO - 2023-05-01 09:29:24 --> Helper loaded: form_helper
INFO - 2023-05-01 09:29:24 --> Helper loaded: my_helper
INFO - 2023-05-01 09:29:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:29:24 --> Controller Class Initialized
DEBUG - 2023-05-01 09:29:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 09:29:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:29:24 --> Final output sent to browser
DEBUG - 2023-05-01 09:29:24 --> Total execution time: 0.0335
INFO - 2023-05-01 09:29:24 --> Config Class Initialized
INFO - 2023-05-01 09:29:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:29:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:29:24 --> Utf8 Class Initialized
INFO - 2023-05-01 09:29:24 --> URI Class Initialized
INFO - 2023-05-01 09:29:24 --> Router Class Initialized
INFO - 2023-05-01 09:29:24 --> Output Class Initialized
INFO - 2023-05-01 09:29:24 --> Security Class Initialized
DEBUG - 2023-05-01 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:29:24 --> Input Class Initialized
INFO - 2023-05-01 09:29:24 --> Language Class Initialized
INFO - 2023-05-01 09:29:24 --> Language Class Initialized
INFO - 2023-05-01 09:29:24 --> Config Class Initialized
INFO - 2023-05-01 09:29:24 --> Loader Class Initialized
INFO - 2023-05-01 09:29:24 --> Helper loaded: url_helper
INFO - 2023-05-01 09:29:24 --> Helper loaded: file_helper
INFO - 2023-05-01 09:29:24 --> Helper loaded: form_helper
INFO - 2023-05-01 09:29:24 --> Helper loaded: my_helper
INFO - 2023-05-01 09:29:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:29:24 --> Controller Class Initialized
INFO - 2023-05-01 09:29:26 --> Config Class Initialized
INFO - 2023-05-01 09:29:26 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:29:26 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:29:26 --> Utf8 Class Initialized
INFO - 2023-05-01 09:29:26 --> URI Class Initialized
INFO - 2023-05-01 09:29:26 --> Router Class Initialized
INFO - 2023-05-01 09:29:26 --> Output Class Initialized
INFO - 2023-05-01 09:29:26 --> Security Class Initialized
DEBUG - 2023-05-01 09:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:29:26 --> Input Class Initialized
INFO - 2023-05-01 09:29:26 --> Language Class Initialized
INFO - 2023-05-01 09:29:26 --> Language Class Initialized
INFO - 2023-05-01 09:29:26 --> Config Class Initialized
INFO - 2023-05-01 09:29:26 --> Loader Class Initialized
INFO - 2023-05-01 09:29:26 --> Helper loaded: url_helper
INFO - 2023-05-01 09:29:26 --> Helper loaded: file_helper
INFO - 2023-05-01 09:29:26 --> Helper loaded: form_helper
INFO - 2023-05-01 09:29:26 --> Helper loaded: my_helper
INFO - 2023-05-01 09:29:26 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:29:26 --> Controller Class Initialized
INFO - 2023-05-01 09:29:26 --> Final output sent to browser
DEBUG - 2023-05-01 09:29:26 --> Total execution time: 0.0456
INFO - 2023-05-01 09:29:28 --> Config Class Initialized
INFO - 2023-05-01 09:29:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:29:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:29:28 --> Utf8 Class Initialized
INFO - 2023-05-01 09:29:28 --> URI Class Initialized
INFO - 2023-05-01 09:29:28 --> Router Class Initialized
INFO - 2023-05-01 09:29:28 --> Output Class Initialized
INFO - 2023-05-01 09:29:28 --> Security Class Initialized
DEBUG - 2023-05-01 09:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:29:28 --> Input Class Initialized
INFO - 2023-05-01 09:29:28 --> Language Class Initialized
INFO - 2023-05-01 09:29:28 --> Language Class Initialized
INFO - 2023-05-01 09:29:28 --> Config Class Initialized
INFO - 2023-05-01 09:29:28 --> Loader Class Initialized
INFO - 2023-05-01 09:29:28 --> Helper loaded: url_helper
INFO - 2023-05-01 09:29:28 --> Helper loaded: file_helper
INFO - 2023-05-01 09:29:28 --> Helper loaded: form_helper
INFO - 2023-05-01 09:29:28 --> Helper loaded: my_helper
INFO - 2023-05-01 09:29:28 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:29:28 --> Controller Class Initialized
DEBUG - 2023-05-01 09:29:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:29:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:29:28 --> Final output sent to browser
DEBUG - 2023-05-01 09:29:28 --> Total execution time: 0.0434
INFO - 2023-05-01 09:33:51 --> Config Class Initialized
INFO - 2023-05-01 09:33:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:33:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:33:51 --> Utf8 Class Initialized
INFO - 2023-05-01 09:33:51 --> URI Class Initialized
INFO - 2023-05-01 09:33:51 --> Router Class Initialized
INFO - 2023-05-01 09:33:51 --> Output Class Initialized
INFO - 2023-05-01 09:33:51 --> Security Class Initialized
DEBUG - 2023-05-01 09:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:33:51 --> Input Class Initialized
INFO - 2023-05-01 09:33:51 --> Language Class Initialized
INFO - 2023-05-01 09:33:51 --> Language Class Initialized
INFO - 2023-05-01 09:33:51 --> Config Class Initialized
INFO - 2023-05-01 09:33:51 --> Loader Class Initialized
INFO - 2023-05-01 09:33:51 --> Helper loaded: url_helper
INFO - 2023-05-01 09:33:51 --> Helper loaded: file_helper
INFO - 2023-05-01 09:33:51 --> Helper loaded: form_helper
INFO - 2023-05-01 09:33:51 --> Helper loaded: my_helper
INFO - 2023-05-01 09:33:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:33:51 --> Controller Class Initialized
DEBUG - 2023-05-01 09:33:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:33:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:33:51 --> Final output sent to browser
DEBUG - 2023-05-01 09:33:51 --> Total execution time: 0.0401
INFO - 2023-05-01 09:33:54 --> Config Class Initialized
INFO - 2023-05-01 09:33:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:33:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:33:54 --> Utf8 Class Initialized
INFO - 2023-05-01 09:33:54 --> URI Class Initialized
INFO - 2023-05-01 09:33:54 --> Router Class Initialized
INFO - 2023-05-01 09:33:54 --> Output Class Initialized
INFO - 2023-05-01 09:33:54 --> Security Class Initialized
DEBUG - 2023-05-01 09:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:33:54 --> Input Class Initialized
INFO - 2023-05-01 09:33:54 --> Language Class Initialized
INFO - 2023-05-01 09:33:54 --> Language Class Initialized
INFO - 2023-05-01 09:33:54 --> Config Class Initialized
INFO - 2023-05-01 09:33:54 --> Loader Class Initialized
INFO - 2023-05-01 09:33:54 --> Helper loaded: url_helper
INFO - 2023-05-01 09:33:54 --> Helper loaded: file_helper
INFO - 2023-05-01 09:33:54 --> Helper loaded: form_helper
INFO - 2023-05-01 09:33:54 --> Helper loaded: my_helper
INFO - 2023-05-01 09:33:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:33:54 --> Controller Class Initialized
DEBUG - 2023-05-01 09:33:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:33:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:33:54 --> Final output sent to browser
DEBUG - 2023-05-01 09:33:54 --> Total execution time: 0.0250
INFO - 2023-05-01 09:33:55 --> Config Class Initialized
INFO - 2023-05-01 09:33:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:33:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:33:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:33:55 --> URI Class Initialized
INFO - 2023-05-01 09:33:55 --> Router Class Initialized
INFO - 2023-05-01 09:33:55 --> Output Class Initialized
INFO - 2023-05-01 09:33:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:33:55 --> Input Class Initialized
INFO - 2023-05-01 09:33:55 --> Language Class Initialized
INFO - 2023-05-01 09:33:55 --> Language Class Initialized
INFO - 2023-05-01 09:33:55 --> Config Class Initialized
INFO - 2023-05-01 09:33:55 --> Loader Class Initialized
INFO - 2023-05-01 09:33:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:33:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:33:55 --> Controller Class Initialized
DEBUG - 2023-05-01 09:33:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:33:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:33:55 --> Final output sent to browser
DEBUG - 2023-05-01 09:33:55 --> Total execution time: 0.0460
INFO - 2023-05-01 09:33:55 --> Config Class Initialized
INFO - 2023-05-01 09:33:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:33:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:33:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:33:55 --> URI Class Initialized
INFO - 2023-05-01 09:33:55 --> Router Class Initialized
INFO - 2023-05-01 09:33:55 --> Output Class Initialized
INFO - 2023-05-01 09:33:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:33:55 --> Input Class Initialized
INFO - 2023-05-01 09:33:55 --> Language Class Initialized
INFO - 2023-05-01 09:33:55 --> Language Class Initialized
INFO - 2023-05-01 09:33:55 --> Config Class Initialized
INFO - 2023-05-01 09:33:55 --> Loader Class Initialized
INFO - 2023-05-01 09:33:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:33:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:33:55 --> Controller Class Initialized
DEBUG - 2023-05-01 09:33:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:33:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:33:55 --> Final output sent to browser
DEBUG - 2023-05-01 09:33:55 --> Total execution time: 0.0424
INFO - 2023-05-01 09:33:55 --> Config Class Initialized
INFO - 2023-05-01 09:33:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:33:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:33:55 --> Utf8 Class Initialized
INFO - 2023-05-01 09:33:55 --> URI Class Initialized
INFO - 2023-05-01 09:33:55 --> Router Class Initialized
INFO - 2023-05-01 09:33:55 --> Output Class Initialized
INFO - 2023-05-01 09:33:55 --> Security Class Initialized
DEBUG - 2023-05-01 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:33:55 --> Input Class Initialized
INFO - 2023-05-01 09:33:55 --> Language Class Initialized
INFO - 2023-05-01 09:33:55 --> Language Class Initialized
INFO - 2023-05-01 09:33:55 --> Config Class Initialized
INFO - 2023-05-01 09:33:55 --> Loader Class Initialized
INFO - 2023-05-01 09:33:55 --> Helper loaded: url_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: file_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: form_helper
INFO - 2023-05-01 09:33:55 --> Helper loaded: my_helper
INFO - 2023-05-01 09:33:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:33:55 --> Controller Class Initialized
DEBUG - 2023-05-01 09:33:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:33:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:33:55 --> Final output sent to browser
DEBUG - 2023-05-01 09:33:55 --> Total execution time: 0.0462
INFO - 2023-05-01 09:34:15 --> Config Class Initialized
INFO - 2023-05-01 09:34:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:15 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:15 --> URI Class Initialized
INFO - 2023-05-01 09:34:15 --> Router Class Initialized
INFO - 2023-05-01 09:34:15 --> Output Class Initialized
INFO - 2023-05-01 09:34:15 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:15 --> Input Class Initialized
INFO - 2023-05-01 09:34:15 --> Language Class Initialized
INFO - 2023-05-01 09:34:15 --> Language Class Initialized
INFO - 2023-05-01 09:34:15 --> Config Class Initialized
INFO - 2023-05-01 09:34:15 --> Loader Class Initialized
INFO - 2023-05-01 09:34:15 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:15 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:15 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:15 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:15 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:15 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:15 --> Total execution time: 0.0417
INFO - 2023-05-01 09:34:16 --> Config Class Initialized
INFO - 2023-05-01 09:34:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:16 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:16 --> URI Class Initialized
INFO - 2023-05-01 09:34:16 --> Router Class Initialized
INFO - 2023-05-01 09:34:16 --> Output Class Initialized
INFO - 2023-05-01 09:34:16 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:16 --> Input Class Initialized
INFO - 2023-05-01 09:34:16 --> Language Class Initialized
INFO - 2023-05-01 09:34:16 --> Language Class Initialized
INFO - 2023-05-01 09:34:16 --> Config Class Initialized
INFO - 2023-05-01 09:34:16 --> Loader Class Initialized
INFO - 2023-05-01 09:34:16 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:16 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:16 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:16 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:16 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:16 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:16 --> Total execution time: 0.0234
INFO - 2023-05-01 09:34:17 --> Config Class Initialized
INFO - 2023-05-01 09:34:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:17 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:17 --> URI Class Initialized
INFO - 2023-05-01 09:34:17 --> Router Class Initialized
INFO - 2023-05-01 09:34:17 --> Output Class Initialized
INFO - 2023-05-01 09:34:17 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:17 --> Input Class Initialized
INFO - 2023-05-01 09:34:17 --> Language Class Initialized
INFO - 2023-05-01 09:34:17 --> Language Class Initialized
INFO - 2023-05-01 09:34:17 --> Config Class Initialized
INFO - 2023-05-01 09:34:17 --> Loader Class Initialized
INFO - 2023-05-01 09:34:17 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:17 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:17 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:17 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:17 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:17 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:17 --> Total execution time: 0.0230
INFO - 2023-05-01 09:34:17 --> Config Class Initialized
INFO - 2023-05-01 09:34:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:17 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:17 --> URI Class Initialized
INFO - 2023-05-01 09:34:17 --> Router Class Initialized
INFO - 2023-05-01 09:34:17 --> Output Class Initialized
INFO - 2023-05-01 09:34:17 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:17 --> Input Class Initialized
INFO - 2023-05-01 09:34:17 --> Language Class Initialized
INFO - 2023-05-01 09:34:17 --> Language Class Initialized
INFO - 2023-05-01 09:34:17 --> Config Class Initialized
INFO - 2023-05-01 09:34:17 --> Loader Class Initialized
INFO - 2023-05-01 09:34:17 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:17 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:17 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:17 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:17 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:17 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:17 --> Total execution time: 0.0347
INFO - 2023-05-01 09:34:18 --> Config Class Initialized
INFO - 2023-05-01 09:34:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:18 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:18 --> URI Class Initialized
INFO - 2023-05-01 09:34:18 --> Router Class Initialized
INFO - 2023-05-01 09:34:18 --> Output Class Initialized
INFO - 2023-05-01 09:34:18 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:18 --> Input Class Initialized
INFO - 2023-05-01 09:34:18 --> Language Class Initialized
INFO - 2023-05-01 09:34:18 --> Language Class Initialized
INFO - 2023-05-01 09:34:18 --> Config Class Initialized
INFO - 2023-05-01 09:34:18 --> Loader Class Initialized
INFO - 2023-05-01 09:34:18 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:18 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:18 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:18 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:18 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:18 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:18 --> Total execution time: 0.0440
INFO - 2023-05-01 09:34:18 --> Config Class Initialized
INFO - 2023-05-01 09:34:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:18 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:18 --> URI Class Initialized
INFO - 2023-05-01 09:34:18 --> Router Class Initialized
INFO - 2023-05-01 09:34:18 --> Output Class Initialized
INFO - 2023-05-01 09:34:18 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:18 --> Input Class Initialized
INFO - 2023-05-01 09:34:18 --> Language Class Initialized
INFO - 2023-05-01 09:34:18 --> Language Class Initialized
INFO - 2023-05-01 09:34:18 --> Config Class Initialized
INFO - 2023-05-01 09:34:18 --> Loader Class Initialized
INFO - 2023-05-01 09:34:18 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:18 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:18 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:18 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:18 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:18 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:18 --> Total execution time: 0.0275
INFO - 2023-05-01 09:34:59 --> Config Class Initialized
INFO - 2023-05-01 09:34:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:34:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:34:59 --> Utf8 Class Initialized
INFO - 2023-05-01 09:34:59 --> URI Class Initialized
INFO - 2023-05-01 09:34:59 --> Router Class Initialized
INFO - 2023-05-01 09:34:59 --> Output Class Initialized
INFO - 2023-05-01 09:34:59 --> Security Class Initialized
DEBUG - 2023-05-01 09:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:34:59 --> Input Class Initialized
INFO - 2023-05-01 09:34:59 --> Language Class Initialized
INFO - 2023-05-01 09:34:59 --> Language Class Initialized
INFO - 2023-05-01 09:34:59 --> Config Class Initialized
INFO - 2023-05-01 09:34:59 --> Loader Class Initialized
INFO - 2023-05-01 09:34:59 --> Helper loaded: url_helper
INFO - 2023-05-01 09:34:59 --> Helper loaded: file_helper
INFO - 2023-05-01 09:34:59 --> Helper loaded: form_helper
INFO - 2023-05-01 09:34:59 --> Helper loaded: my_helper
INFO - 2023-05-01 09:34:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:34:59 --> Controller Class Initialized
DEBUG - 2023-05-01 09:34:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:34:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:34:59 --> Final output sent to browser
DEBUG - 2023-05-01 09:34:59 --> Total execution time: 0.0287
INFO - 2023-05-01 09:36:46 --> Config Class Initialized
INFO - 2023-05-01 09:36:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:36:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:36:46 --> Utf8 Class Initialized
INFO - 2023-05-01 09:36:46 --> URI Class Initialized
INFO - 2023-05-01 09:36:46 --> Router Class Initialized
INFO - 2023-05-01 09:36:46 --> Output Class Initialized
INFO - 2023-05-01 09:36:46 --> Security Class Initialized
DEBUG - 2023-05-01 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:36:46 --> Input Class Initialized
INFO - 2023-05-01 09:36:46 --> Language Class Initialized
INFO - 2023-05-01 09:36:46 --> Language Class Initialized
INFO - 2023-05-01 09:36:46 --> Config Class Initialized
INFO - 2023-05-01 09:36:46 --> Loader Class Initialized
INFO - 2023-05-01 09:36:46 --> Helper loaded: url_helper
INFO - 2023-05-01 09:36:46 --> Helper loaded: file_helper
INFO - 2023-05-01 09:36:46 --> Helper loaded: form_helper
INFO - 2023-05-01 09:36:46 --> Helper loaded: my_helper
INFO - 2023-05-01 09:36:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:36:46 --> Controller Class Initialized
DEBUG - 2023-05-01 09:36:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:36:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:36:46 --> Final output sent to browser
DEBUG - 2023-05-01 09:36:46 --> Total execution time: 0.4284
INFO - 2023-05-01 09:37:32 --> Config Class Initialized
INFO - 2023-05-01 09:37:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:37:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:37:32 --> Utf8 Class Initialized
INFO - 2023-05-01 09:37:32 --> URI Class Initialized
INFO - 2023-05-01 09:37:32 --> Router Class Initialized
INFO - 2023-05-01 09:37:32 --> Output Class Initialized
INFO - 2023-05-01 09:37:32 --> Security Class Initialized
DEBUG - 2023-05-01 09:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:37:32 --> Input Class Initialized
INFO - 2023-05-01 09:37:32 --> Language Class Initialized
INFO - 2023-05-01 09:37:32 --> Language Class Initialized
INFO - 2023-05-01 09:37:32 --> Config Class Initialized
INFO - 2023-05-01 09:37:32 --> Loader Class Initialized
INFO - 2023-05-01 09:37:32 --> Helper loaded: url_helper
INFO - 2023-05-01 09:37:32 --> Helper loaded: file_helper
INFO - 2023-05-01 09:37:32 --> Helper loaded: form_helper
INFO - 2023-05-01 09:37:32 --> Helper loaded: my_helper
INFO - 2023-05-01 09:37:32 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:37:32 --> Controller Class Initialized
DEBUG - 2023-05-01 09:37:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:37:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:37:32 --> Final output sent to browser
DEBUG - 2023-05-01 09:37:32 --> Total execution time: 0.0270
INFO - 2023-05-01 09:37:33 --> Config Class Initialized
INFO - 2023-05-01 09:37:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:37:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:37:33 --> Utf8 Class Initialized
INFO - 2023-05-01 09:37:33 --> URI Class Initialized
INFO - 2023-05-01 09:37:33 --> Router Class Initialized
INFO - 2023-05-01 09:37:33 --> Output Class Initialized
INFO - 2023-05-01 09:37:33 --> Security Class Initialized
DEBUG - 2023-05-01 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:37:33 --> Input Class Initialized
INFO - 2023-05-01 09:37:33 --> Language Class Initialized
INFO - 2023-05-01 09:37:33 --> Language Class Initialized
INFO - 2023-05-01 09:37:33 --> Config Class Initialized
INFO - 2023-05-01 09:37:33 --> Loader Class Initialized
INFO - 2023-05-01 09:37:33 --> Helper loaded: url_helper
INFO - 2023-05-01 09:37:33 --> Helper loaded: file_helper
INFO - 2023-05-01 09:37:33 --> Helper loaded: form_helper
INFO - 2023-05-01 09:37:33 --> Helper loaded: my_helper
INFO - 2023-05-01 09:37:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 09:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 09:37:33 --> Controller Class Initialized
DEBUG - 2023-05-01 09:37:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 09:37:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 09:37:33 --> Final output sent to browser
DEBUG - 2023-05-01 09:37:33 --> Total execution time: 0.0273
INFO - 2023-05-01 09:37:39 --> Config Class Initialized
INFO - 2023-05-01 09:37:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 09:37:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 09:37:39 --> Utf8 Class Initialized
INFO - 2023-05-01 09:37:39 --> URI Class Initialized
INFO - 2023-05-01 09:37:39 --> Router Class Initialized
INFO - 2023-05-01 09:37:39 --> Output Class Initialized
INFO - 2023-05-01 09:37:39 --> Security Class Initialized
DEBUG - 2023-05-01 09:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 09:37:39 --> Input Class Initialized
INFO - 2023-05-01 09:37:39 --> Language Class Initialized
ERROR - 2023-05-01 09:37:39 --> 404 Page Not Found: /index
INFO - 2023-05-01 13:42:04 --> Config Class Initialized
INFO - 2023-05-01 13:42:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:42:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:42:04 --> Utf8 Class Initialized
INFO - 2023-05-01 13:42:04 --> URI Class Initialized
INFO - 2023-05-01 13:42:04 --> Router Class Initialized
INFO - 2023-05-01 13:42:04 --> Output Class Initialized
INFO - 2023-05-01 13:42:04 --> Security Class Initialized
DEBUG - 2023-05-01 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:42:04 --> Input Class Initialized
INFO - 2023-05-01 13:42:04 --> Language Class Initialized
INFO - 2023-05-01 13:42:04 --> Language Class Initialized
INFO - 2023-05-01 13:42:04 --> Config Class Initialized
INFO - 2023-05-01 13:42:04 --> Loader Class Initialized
INFO - 2023-05-01 13:42:04 --> Helper loaded: url_helper
INFO - 2023-05-01 13:42:04 --> Helper loaded: file_helper
INFO - 2023-05-01 13:42:04 --> Helper loaded: form_helper
INFO - 2023-05-01 13:42:04 --> Helper loaded: my_helper
INFO - 2023-05-01 13:42:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:42:04 --> Controller Class Initialized
INFO - 2023-05-01 13:42:04 --> Config Class Initialized
INFO - 2023-05-01 13:42:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:42:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:42:04 --> Utf8 Class Initialized
INFO - 2023-05-01 13:42:04 --> URI Class Initialized
INFO - 2023-05-01 13:42:04 --> Router Class Initialized
INFO - 2023-05-01 13:42:04 --> Output Class Initialized
INFO - 2023-05-01 13:42:04 --> Security Class Initialized
DEBUG - 2023-05-01 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:42:04 --> Input Class Initialized
INFO - 2023-05-01 13:42:04 --> Language Class Initialized
INFO - 2023-05-01 13:42:04 --> Language Class Initialized
INFO - 2023-05-01 13:42:04 --> Config Class Initialized
INFO - 2023-05-01 13:42:04 --> Loader Class Initialized
INFO - 2023-05-01 13:42:04 --> Helper loaded: url_helper
INFO - 2023-05-01 13:42:04 --> Helper loaded: file_helper
INFO - 2023-05-01 13:42:04 --> Helper loaded: form_helper
INFO - 2023-05-01 13:42:04 --> Helper loaded: my_helper
INFO - 2023-05-01 13:42:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:42:04 --> Controller Class Initialized
DEBUG - 2023-05-01 13:42:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 13:42:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:42:04 --> Final output sent to browser
DEBUG - 2023-05-01 13:42:04 --> Total execution time: 0.1026
INFO - 2023-05-01 13:42:38 --> Config Class Initialized
INFO - 2023-05-01 13:42:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:42:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:42:38 --> Utf8 Class Initialized
INFO - 2023-05-01 13:42:38 --> URI Class Initialized
INFO - 2023-05-01 13:42:38 --> Router Class Initialized
INFO - 2023-05-01 13:42:38 --> Output Class Initialized
INFO - 2023-05-01 13:42:38 --> Security Class Initialized
DEBUG - 2023-05-01 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:42:38 --> Input Class Initialized
INFO - 2023-05-01 13:42:38 --> Language Class Initialized
INFO - 2023-05-01 13:42:38 --> Language Class Initialized
INFO - 2023-05-01 13:42:38 --> Config Class Initialized
INFO - 2023-05-01 13:42:38 --> Loader Class Initialized
INFO - 2023-05-01 13:42:38 --> Helper loaded: url_helper
INFO - 2023-05-01 13:42:38 --> Helper loaded: file_helper
INFO - 2023-05-01 13:42:38 --> Helper loaded: form_helper
INFO - 2023-05-01 13:42:38 --> Helper loaded: my_helper
INFO - 2023-05-01 13:42:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:42:38 --> Controller Class Initialized
INFO - 2023-05-01 13:42:38 --> Helper loaded: cookie_helper
INFO - 2023-05-01 13:42:38 --> Final output sent to browser
DEBUG - 2023-05-01 13:42:38 --> Total execution time: 0.0833
INFO - 2023-05-01 13:42:38 --> Config Class Initialized
INFO - 2023-05-01 13:42:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:42:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:42:38 --> Utf8 Class Initialized
INFO - 2023-05-01 13:42:38 --> URI Class Initialized
INFO - 2023-05-01 13:42:38 --> Router Class Initialized
INFO - 2023-05-01 13:42:38 --> Output Class Initialized
INFO - 2023-05-01 13:42:38 --> Security Class Initialized
DEBUG - 2023-05-01 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:42:38 --> Input Class Initialized
INFO - 2023-05-01 13:42:38 --> Language Class Initialized
INFO - 2023-05-01 13:42:38 --> Language Class Initialized
INFO - 2023-05-01 13:42:38 --> Config Class Initialized
INFO - 2023-05-01 13:42:38 --> Loader Class Initialized
INFO - 2023-05-01 13:42:38 --> Helper loaded: url_helper
INFO - 2023-05-01 13:42:38 --> Helper loaded: file_helper
INFO - 2023-05-01 13:42:38 --> Helper loaded: form_helper
INFO - 2023-05-01 13:42:38 --> Helper loaded: my_helper
INFO - 2023-05-01 13:42:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:42:38 --> Controller Class Initialized
DEBUG - 2023-05-01 13:42:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 13:42:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:42:38 --> Final output sent to browser
DEBUG - 2023-05-01 13:42:38 --> Total execution time: 0.0541
INFO - 2023-05-01 13:42:40 --> Config Class Initialized
INFO - 2023-05-01 13:42:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:42:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:42:40 --> Utf8 Class Initialized
INFO - 2023-05-01 13:42:40 --> URI Class Initialized
INFO - 2023-05-01 13:42:40 --> Router Class Initialized
INFO - 2023-05-01 13:42:40 --> Output Class Initialized
INFO - 2023-05-01 13:42:40 --> Security Class Initialized
DEBUG - 2023-05-01 13:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:42:40 --> Input Class Initialized
INFO - 2023-05-01 13:42:40 --> Language Class Initialized
INFO - 2023-05-01 13:42:40 --> Language Class Initialized
INFO - 2023-05-01 13:42:40 --> Config Class Initialized
INFO - 2023-05-01 13:42:40 --> Loader Class Initialized
INFO - 2023-05-01 13:42:40 --> Helper loaded: url_helper
INFO - 2023-05-01 13:42:40 --> Helper loaded: file_helper
INFO - 2023-05-01 13:42:40 --> Helper loaded: form_helper
INFO - 2023-05-01 13:42:40 --> Helper loaded: my_helper
INFO - 2023-05-01 13:42:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:42:40 --> Controller Class Initialized
DEBUG - 2023-05-01 13:42:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 13:42:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:42:40 --> Final output sent to browser
DEBUG - 2023-05-01 13:42:40 --> Total execution time: 0.0558
INFO - 2023-05-01 13:43:28 --> Config Class Initialized
INFO - 2023-05-01 13:43:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:28 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:28 --> URI Class Initialized
INFO - 2023-05-01 13:43:28 --> Router Class Initialized
INFO - 2023-05-01 13:43:28 --> Output Class Initialized
INFO - 2023-05-01 13:43:28 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:28 --> Input Class Initialized
INFO - 2023-05-01 13:43:28 --> Language Class Initialized
ERROR - 2023-05-01 13:43:28 --> 404 Page Not Found: /index
INFO - 2023-05-01 13:43:30 --> Config Class Initialized
INFO - 2023-05-01 13:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:30 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:30 --> URI Class Initialized
INFO - 2023-05-01 13:43:30 --> Router Class Initialized
INFO - 2023-05-01 13:43:30 --> Output Class Initialized
INFO - 2023-05-01 13:43:30 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:30 --> Input Class Initialized
INFO - 2023-05-01 13:43:30 --> Language Class Initialized
INFO - 2023-05-01 13:43:30 --> Language Class Initialized
INFO - 2023-05-01 13:43:30 --> Config Class Initialized
INFO - 2023-05-01 13:43:30 --> Loader Class Initialized
INFO - 2023-05-01 13:43:30 --> Helper loaded: url_helper
INFO - 2023-05-01 13:43:30 --> Helper loaded: file_helper
INFO - 2023-05-01 13:43:30 --> Helper loaded: form_helper
INFO - 2023-05-01 13:43:30 --> Helper loaded: my_helper
INFO - 2023-05-01 13:43:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:43:30 --> Controller Class Initialized
DEBUG - 2023-05-01 13:43:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 13:43:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:43:30 --> Final output sent to browser
DEBUG - 2023-05-01 13:43:30 --> Total execution time: 0.0588
INFO - 2023-05-01 13:43:34 --> Config Class Initialized
INFO - 2023-05-01 13:43:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:34 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:34 --> URI Class Initialized
INFO - 2023-05-01 13:43:34 --> Router Class Initialized
INFO - 2023-05-01 13:43:34 --> Output Class Initialized
INFO - 2023-05-01 13:43:34 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:34 --> Input Class Initialized
INFO - 2023-05-01 13:43:34 --> Language Class Initialized
INFO - 2023-05-01 13:43:34 --> Language Class Initialized
INFO - 2023-05-01 13:43:34 --> Config Class Initialized
INFO - 2023-05-01 13:43:34 --> Loader Class Initialized
INFO - 2023-05-01 13:43:34 --> Helper loaded: url_helper
INFO - 2023-05-01 13:43:34 --> Helper loaded: file_helper
INFO - 2023-05-01 13:43:34 --> Helper loaded: form_helper
INFO - 2023-05-01 13:43:34 --> Helper loaded: my_helper
INFO - 2023-05-01 13:43:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:43:34 --> Controller Class Initialized
DEBUG - 2023-05-01 13:43:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 13:43:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:43:34 --> Final output sent to browser
DEBUG - 2023-05-01 13:43:34 --> Total execution time: 0.1092
INFO - 2023-05-01 13:43:37 --> Config Class Initialized
INFO - 2023-05-01 13:43:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:37 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:37 --> URI Class Initialized
INFO - 2023-05-01 13:43:37 --> Router Class Initialized
INFO - 2023-05-01 13:43:37 --> Output Class Initialized
INFO - 2023-05-01 13:43:37 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:37 --> Input Class Initialized
INFO - 2023-05-01 13:43:37 --> Language Class Initialized
INFO - 2023-05-01 13:43:37 --> Language Class Initialized
INFO - 2023-05-01 13:43:37 --> Config Class Initialized
INFO - 2023-05-01 13:43:37 --> Loader Class Initialized
INFO - 2023-05-01 13:43:37 --> Helper loaded: url_helper
INFO - 2023-05-01 13:43:37 --> Helper loaded: file_helper
INFO - 2023-05-01 13:43:37 --> Helper loaded: form_helper
INFO - 2023-05-01 13:43:37 --> Helper loaded: my_helper
INFO - 2023-05-01 13:43:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:43:37 --> Controller Class Initialized
INFO - 2023-05-01 13:43:37 --> Final output sent to browser
DEBUG - 2023-05-01 13:43:37 --> Total execution time: 0.0435
INFO - 2023-05-01 13:43:48 --> Config Class Initialized
INFO - 2023-05-01 13:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:48 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:48 --> URI Class Initialized
INFO - 2023-05-01 13:43:48 --> Router Class Initialized
INFO - 2023-05-01 13:43:48 --> Output Class Initialized
INFO - 2023-05-01 13:43:48 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:48 --> Input Class Initialized
INFO - 2023-05-01 13:43:48 --> Language Class Initialized
INFO - 2023-05-01 13:43:48 --> Language Class Initialized
INFO - 2023-05-01 13:43:48 --> Config Class Initialized
INFO - 2023-05-01 13:43:48 --> Loader Class Initialized
INFO - 2023-05-01 13:43:48 --> Helper loaded: url_helper
INFO - 2023-05-01 13:43:48 --> Helper loaded: file_helper
INFO - 2023-05-01 13:43:48 --> Helper loaded: form_helper
INFO - 2023-05-01 13:43:48 --> Helper loaded: my_helper
INFO - 2023-05-01 13:43:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:43:48 --> Controller Class Initialized
DEBUG - 2023-05-01 13:43:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 13:43:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:43:48 --> Final output sent to browser
DEBUG - 2023-05-01 13:43:48 --> Total execution time: 0.0452
INFO - 2023-05-01 13:43:52 --> Config Class Initialized
INFO - 2023-05-01 13:43:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:52 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:52 --> URI Class Initialized
INFO - 2023-05-01 13:43:52 --> Router Class Initialized
INFO - 2023-05-01 13:43:52 --> Output Class Initialized
INFO - 2023-05-01 13:43:52 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:52 --> Input Class Initialized
INFO - 2023-05-01 13:43:52 --> Language Class Initialized
INFO - 2023-05-01 13:43:52 --> Language Class Initialized
INFO - 2023-05-01 13:43:52 --> Config Class Initialized
INFO - 2023-05-01 13:43:52 --> Loader Class Initialized
INFO - 2023-05-01 13:43:52 --> Helper loaded: url_helper
INFO - 2023-05-01 13:43:52 --> Helper loaded: file_helper
INFO - 2023-05-01 13:43:52 --> Helper loaded: form_helper
INFO - 2023-05-01 13:43:52 --> Helper loaded: my_helper
INFO - 2023-05-01 13:43:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:43:52 --> Controller Class Initialized
DEBUG - 2023-05-01 13:43:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 13:43:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:43:52 --> Final output sent to browser
DEBUG - 2023-05-01 13:43:52 --> Total execution time: 0.0580
INFO - 2023-05-01 13:43:54 --> Config Class Initialized
INFO - 2023-05-01 13:43:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:43:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:43:54 --> Utf8 Class Initialized
INFO - 2023-05-01 13:43:54 --> URI Class Initialized
INFO - 2023-05-01 13:43:54 --> Router Class Initialized
INFO - 2023-05-01 13:43:54 --> Output Class Initialized
INFO - 2023-05-01 13:43:54 --> Security Class Initialized
DEBUG - 2023-05-01 13:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:43:54 --> Input Class Initialized
INFO - 2023-05-01 13:43:54 --> Language Class Initialized
INFO - 2023-05-01 13:43:54 --> Language Class Initialized
INFO - 2023-05-01 13:43:54 --> Config Class Initialized
INFO - 2023-05-01 13:43:54 --> Loader Class Initialized
INFO - 2023-05-01 13:43:54 --> Helper loaded: url_helper
INFO - 2023-05-01 13:43:54 --> Helper loaded: file_helper
INFO - 2023-05-01 13:43:54 --> Helper loaded: form_helper
INFO - 2023-05-01 13:43:54 --> Helper loaded: my_helper
INFO - 2023-05-01 13:43:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:43:54 --> Controller Class Initialized
INFO - 2023-05-01 13:43:54 --> Final output sent to browser
DEBUG - 2023-05-01 13:43:54 --> Total execution time: 0.0592
INFO - 2023-05-01 13:44:02 --> Config Class Initialized
INFO - 2023-05-01 13:44:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:02 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:02 --> URI Class Initialized
INFO - 2023-05-01 13:44:02 --> Router Class Initialized
INFO - 2023-05-01 13:44:02 --> Output Class Initialized
INFO - 2023-05-01 13:44:02 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:02 --> Input Class Initialized
INFO - 2023-05-01 13:44:02 --> Language Class Initialized
INFO - 2023-05-01 13:44:02 --> Language Class Initialized
INFO - 2023-05-01 13:44:02 --> Config Class Initialized
INFO - 2023-05-01 13:44:02 --> Loader Class Initialized
INFO - 2023-05-01 13:44:02 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:02 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:02 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:02 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:02 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:02 --> Controller Class Initialized
DEBUG - 2023-05-01 13:44:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 13:44:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:44:02 --> Final output sent to browser
DEBUG - 2023-05-01 13:44:02 --> Total execution time: 0.0566
INFO - 2023-05-01 13:44:06 --> Config Class Initialized
INFO - 2023-05-01 13:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:06 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:06 --> URI Class Initialized
INFO - 2023-05-01 13:44:06 --> Router Class Initialized
INFO - 2023-05-01 13:44:06 --> Output Class Initialized
INFO - 2023-05-01 13:44:06 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:06 --> Input Class Initialized
INFO - 2023-05-01 13:44:06 --> Language Class Initialized
INFO - 2023-05-01 13:44:06 --> Language Class Initialized
INFO - 2023-05-01 13:44:06 --> Config Class Initialized
INFO - 2023-05-01 13:44:06 --> Loader Class Initialized
INFO - 2023-05-01 13:44:06 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:06 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:06 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:06 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:06 --> Controller Class Initialized
DEBUG - 2023-05-01 13:44:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 13:44:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:44:06 --> Final output sent to browser
DEBUG - 2023-05-01 13:44:06 --> Total execution time: 0.0591
INFO - 2023-05-01 13:44:08 --> Config Class Initialized
INFO - 2023-05-01 13:44:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:08 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:08 --> URI Class Initialized
INFO - 2023-05-01 13:44:08 --> Router Class Initialized
INFO - 2023-05-01 13:44:08 --> Output Class Initialized
INFO - 2023-05-01 13:44:08 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:08 --> Input Class Initialized
INFO - 2023-05-01 13:44:08 --> Language Class Initialized
INFO - 2023-05-01 13:44:08 --> Language Class Initialized
INFO - 2023-05-01 13:44:08 --> Config Class Initialized
INFO - 2023-05-01 13:44:08 --> Loader Class Initialized
INFO - 2023-05-01 13:44:08 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:08 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:08 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:08 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:08 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:08 --> Controller Class Initialized
INFO - 2023-05-01 13:44:08 --> Final output sent to browser
DEBUG - 2023-05-01 13:44:08 --> Total execution time: 0.0668
INFO - 2023-05-01 13:44:34 --> Config Class Initialized
INFO - 2023-05-01 13:44:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:34 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:34 --> URI Class Initialized
INFO - 2023-05-01 13:44:34 --> Router Class Initialized
INFO - 2023-05-01 13:44:34 --> Output Class Initialized
INFO - 2023-05-01 13:44:34 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:34 --> Input Class Initialized
INFO - 2023-05-01 13:44:35 --> Language Class Initialized
INFO - 2023-05-01 13:44:35 --> Language Class Initialized
INFO - 2023-05-01 13:44:35 --> Config Class Initialized
INFO - 2023-05-01 13:44:35 --> Loader Class Initialized
INFO - 2023-05-01 13:44:35 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:35 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:35 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:35 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:35 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:35 --> Controller Class Initialized
DEBUG - 2023-05-01 13:44:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 13:44:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:44:35 --> Final output sent to browser
DEBUG - 2023-05-01 13:44:35 --> Total execution time: 0.0445
INFO - 2023-05-01 13:44:36 --> Config Class Initialized
INFO - 2023-05-01 13:44:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:36 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:36 --> URI Class Initialized
INFO - 2023-05-01 13:44:36 --> Router Class Initialized
INFO - 2023-05-01 13:44:36 --> Output Class Initialized
INFO - 2023-05-01 13:44:36 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:36 --> Input Class Initialized
INFO - 2023-05-01 13:44:36 --> Language Class Initialized
INFO - 2023-05-01 13:44:36 --> Language Class Initialized
INFO - 2023-05-01 13:44:36 --> Config Class Initialized
INFO - 2023-05-01 13:44:36 --> Loader Class Initialized
INFO - 2023-05-01 13:44:36 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:36 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:36 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:36 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:36 --> Controller Class Initialized
DEBUG - 2023-05-01 13:44:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 13:44:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:44:36 --> Final output sent to browser
DEBUG - 2023-05-01 13:44:36 --> Total execution time: 0.1031
INFO - 2023-05-01 13:44:36 --> Config Class Initialized
INFO - 2023-05-01 13:44:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:36 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:36 --> URI Class Initialized
INFO - 2023-05-01 13:44:36 --> Router Class Initialized
INFO - 2023-05-01 13:44:36 --> Output Class Initialized
INFO - 2023-05-01 13:44:36 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:36 --> Input Class Initialized
INFO - 2023-05-01 13:44:36 --> Language Class Initialized
INFO - 2023-05-01 13:44:36 --> Language Class Initialized
INFO - 2023-05-01 13:44:36 --> Config Class Initialized
INFO - 2023-05-01 13:44:36 --> Loader Class Initialized
INFO - 2023-05-01 13:44:36 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:36 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:36 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:36 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:36 --> Controller Class Initialized
INFO - 2023-05-01 13:44:41 --> Config Class Initialized
INFO - 2023-05-01 13:44:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:44:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:44:41 --> Utf8 Class Initialized
INFO - 2023-05-01 13:44:41 --> URI Class Initialized
INFO - 2023-05-01 13:44:41 --> Router Class Initialized
INFO - 2023-05-01 13:44:41 --> Output Class Initialized
INFO - 2023-05-01 13:44:41 --> Security Class Initialized
DEBUG - 2023-05-01 13:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:44:41 --> Input Class Initialized
INFO - 2023-05-01 13:44:41 --> Language Class Initialized
INFO - 2023-05-01 13:44:41 --> Language Class Initialized
INFO - 2023-05-01 13:44:41 --> Config Class Initialized
INFO - 2023-05-01 13:44:41 --> Loader Class Initialized
INFO - 2023-05-01 13:44:41 --> Helper loaded: url_helper
INFO - 2023-05-01 13:44:41 --> Helper loaded: file_helper
INFO - 2023-05-01 13:44:41 --> Helper loaded: form_helper
INFO - 2023-05-01 13:44:41 --> Helper loaded: my_helper
INFO - 2023-05-01 13:44:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:44:41 --> Controller Class Initialized
INFO - 2023-05-01 13:44:41 --> Final output sent to browser
DEBUG - 2023-05-01 13:44:41 --> Total execution time: 0.0585
INFO - 2023-05-01 13:46:53 --> Config Class Initialized
INFO - 2023-05-01 13:46:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:46:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:46:53 --> Utf8 Class Initialized
INFO - 2023-05-01 13:46:53 --> URI Class Initialized
INFO - 2023-05-01 13:46:53 --> Router Class Initialized
INFO - 2023-05-01 13:46:53 --> Output Class Initialized
INFO - 2023-05-01 13:46:53 --> Security Class Initialized
DEBUG - 2023-05-01 13:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:46:53 --> Input Class Initialized
INFO - 2023-05-01 13:46:53 --> Language Class Initialized
INFO - 2023-05-01 13:46:53 --> Language Class Initialized
INFO - 2023-05-01 13:46:53 --> Config Class Initialized
INFO - 2023-05-01 13:46:53 --> Loader Class Initialized
INFO - 2023-05-01 13:46:53 --> Helper loaded: url_helper
INFO - 2023-05-01 13:46:53 --> Helper loaded: file_helper
INFO - 2023-05-01 13:46:53 --> Helper loaded: form_helper
INFO - 2023-05-01 13:46:53 --> Helper loaded: my_helper
INFO - 2023-05-01 13:46:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:46:53 --> Controller Class Initialized
DEBUG - 2023-05-01 13:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 13:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:46:53 --> Final output sent to browser
DEBUG - 2023-05-01 13:46:53 --> Total execution time: 0.0563
INFO - 2023-05-01 13:46:54 --> Config Class Initialized
INFO - 2023-05-01 13:46:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:46:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:46:54 --> Utf8 Class Initialized
INFO - 2023-05-01 13:46:54 --> URI Class Initialized
INFO - 2023-05-01 13:46:54 --> Router Class Initialized
INFO - 2023-05-01 13:46:54 --> Output Class Initialized
INFO - 2023-05-01 13:46:54 --> Security Class Initialized
DEBUG - 2023-05-01 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:46:54 --> Input Class Initialized
INFO - 2023-05-01 13:46:54 --> Language Class Initialized
INFO - 2023-05-01 13:46:54 --> Language Class Initialized
INFO - 2023-05-01 13:46:54 --> Config Class Initialized
INFO - 2023-05-01 13:46:54 --> Loader Class Initialized
INFO - 2023-05-01 13:46:54 --> Helper loaded: url_helper
INFO - 2023-05-01 13:46:54 --> Helper loaded: file_helper
INFO - 2023-05-01 13:46:54 --> Helper loaded: form_helper
INFO - 2023-05-01 13:46:54 --> Helper loaded: my_helper
INFO - 2023-05-01 13:46:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:46:54 --> Controller Class Initialized
DEBUG - 2023-05-01 13:46:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 13:46:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 13:46:54 --> Final output sent to browser
DEBUG - 2023-05-01 13:46:54 --> Total execution time: 0.0925
INFO - 2023-05-01 13:46:54 --> Config Class Initialized
INFO - 2023-05-01 13:46:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 13:46:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 13:46:54 --> Utf8 Class Initialized
INFO - 2023-05-01 13:46:54 --> URI Class Initialized
INFO - 2023-05-01 13:46:54 --> Router Class Initialized
INFO - 2023-05-01 13:46:54 --> Output Class Initialized
INFO - 2023-05-01 13:46:54 --> Security Class Initialized
DEBUG - 2023-05-01 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 13:46:54 --> Input Class Initialized
INFO - 2023-05-01 13:46:54 --> Language Class Initialized
INFO - 2023-05-01 13:46:54 --> Language Class Initialized
INFO - 2023-05-01 13:46:54 --> Config Class Initialized
INFO - 2023-05-01 13:46:54 --> Loader Class Initialized
INFO - 2023-05-01 13:46:54 --> Helper loaded: url_helper
INFO - 2023-05-01 13:46:54 --> Helper loaded: file_helper
INFO - 2023-05-01 13:46:54 --> Helper loaded: form_helper
INFO - 2023-05-01 13:46:54 --> Helper loaded: my_helper
INFO - 2023-05-01 13:46:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 13:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 13:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 13:46:54 --> Controller Class Initialized
INFO - 2023-05-01 14:00:11 --> Config Class Initialized
INFO - 2023-05-01 14:00:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:11 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:11 --> URI Class Initialized
INFO - 2023-05-01 14:00:11 --> Router Class Initialized
INFO - 2023-05-01 14:00:11 --> Output Class Initialized
INFO - 2023-05-01 14:00:11 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:11 --> Input Class Initialized
INFO - 2023-05-01 14:00:11 --> Language Class Initialized
INFO - 2023-05-01 14:00:11 --> Language Class Initialized
INFO - 2023-05-01 14:00:11 --> Config Class Initialized
INFO - 2023-05-01 14:00:11 --> Loader Class Initialized
INFO - 2023-05-01 14:00:11 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:11 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:11 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:11 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:11 --> Controller Class Initialized
DEBUG - 2023-05-01 14:00:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:00:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:00:11 --> Final output sent to browser
DEBUG - 2023-05-01 14:00:11 --> Total execution time: 0.0579
INFO - 2023-05-01 14:00:12 --> Config Class Initialized
INFO - 2023-05-01 14:00:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:12 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:12 --> URI Class Initialized
INFO - 2023-05-01 14:00:12 --> Router Class Initialized
INFO - 2023-05-01 14:00:12 --> Output Class Initialized
INFO - 2023-05-01 14:00:12 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:12 --> Input Class Initialized
INFO - 2023-05-01 14:00:12 --> Language Class Initialized
INFO - 2023-05-01 14:00:12 --> Language Class Initialized
INFO - 2023-05-01 14:00:12 --> Config Class Initialized
INFO - 2023-05-01 14:00:12 --> Loader Class Initialized
INFO - 2023-05-01 14:00:12 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:12 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:12 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:12 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:12 --> Controller Class Initialized
INFO - 2023-05-01 14:00:13 --> Config Class Initialized
INFO - 2023-05-01 14:00:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:13 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:13 --> URI Class Initialized
INFO - 2023-05-01 14:00:13 --> Router Class Initialized
INFO - 2023-05-01 14:00:13 --> Output Class Initialized
INFO - 2023-05-01 14:00:13 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:13 --> Input Class Initialized
INFO - 2023-05-01 14:00:13 --> Language Class Initialized
INFO - 2023-05-01 14:00:13 --> Language Class Initialized
INFO - 2023-05-01 14:00:13 --> Config Class Initialized
INFO - 2023-05-01 14:00:13 --> Loader Class Initialized
INFO - 2023-05-01 14:00:13 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:13 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:13 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:13 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:13 --> Controller Class Initialized
DEBUG - 2023-05-01 14:00:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:00:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:00:13 --> Final output sent to browser
DEBUG - 2023-05-01 14:00:13 --> Total execution time: 0.0457
INFO - 2023-05-01 14:00:13 --> Config Class Initialized
INFO - 2023-05-01 14:00:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:13 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:13 --> URI Class Initialized
INFO - 2023-05-01 14:00:13 --> Router Class Initialized
INFO - 2023-05-01 14:00:13 --> Output Class Initialized
INFO - 2023-05-01 14:00:13 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:13 --> Input Class Initialized
INFO - 2023-05-01 14:00:13 --> Language Class Initialized
INFO - 2023-05-01 14:00:13 --> Language Class Initialized
INFO - 2023-05-01 14:00:13 --> Config Class Initialized
INFO - 2023-05-01 14:00:13 --> Loader Class Initialized
INFO - 2023-05-01 14:00:13 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:13 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:13 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:13 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:13 --> Controller Class Initialized
INFO - 2023-05-01 14:00:16 --> Config Class Initialized
INFO - 2023-05-01 14:00:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:16 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:16 --> URI Class Initialized
INFO - 2023-05-01 14:00:16 --> Router Class Initialized
INFO - 2023-05-01 14:00:16 --> Output Class Initialized
INFO - 2023-05-01 14:00:16 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:16 --> Input Class Initialized
INFO - 2023-05-01 14:00:16 --> Language Class Initialized
INFO - 2023-05-01 14:00:16 --> Language Class Initialized
INFO - 2023-05-01 14:00:16 --> Config Class Initialized
INFO - 2023-05-01 14:00:16 --> Loader Class Initialized
INFO - 2023-05-01 14:00:16 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:16 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:16 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:16 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:16 --> Controller Class Initialized
DEBUG - 2023-05-01 14:00:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:00:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:00:16 --> Final output sent to browser
DEBUG - 2023-05-01 14:00:16 --> Total execution time: 0.0556
INFO - 2023-05-01 14:00:18 --> Config Class Initialized
INFO - 2023-05-01 14:00:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:18 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:18 --> URI Class Initialized
INFO - 2023-05-01 14:00:18 --> Router Class Initialized
INFO - 2023-05-01 14:00:18 --> Output Class Initialized
INFO - 2023-05-01 14:00:18 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:18 --> Input Class Initialized
INFO - 2023-05-01 14:00:18 --> Language Class Initialized
INFO - 2023-05-01 14:00:18 --> Language Class Initialized
INFO - 2023-05-01 14:00:18 --> Config Class Initialized
INFO - 2023-05-01 14:00:18 --> Loader Class Initialized
INFO - 2023-05-01 14:00:18 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:18 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:18 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:18 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:18 --> Controller Class Initialized
DEBUG - 2023-05-01 14:00:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 14:00:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:00:18 --> Final output sent to browser
DEBUG - 2023-05-01 14:00:18 --> Total execution time: 0.0586
INFO - 2023-05-01 14:00:18 --> Config Class Initialized
INFO - 2023-05-01 14:00:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:18 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:18 --> URI Class Initialized
INFO - 2023-05-01 14:00:18 --> Router Class Initialized
INFO - 2023-05-01 14:00:18 --> Output Class Initialized
INFO - 2023-05-01 14:00:18 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:18 --> Input Class Initialized
INFO - 2023-05-01 14:00:18 --> Language Class Initialized
INFO - 2023-05-01 14:00:18 --> Language Class Initialized
INFO - 2023-05-01 14:00:18 --> Config Class Initialized
INFO - 2023-05-01 14:00:18 --> Loader Class Initialized
INFO - 2023-05-01 14:00:18 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:18 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:18 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:18 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:18 --> Controller Class Initialized
INFO - 2023-05-01 14:00:22 --> Config Class Initialized
INFO - 2023-05-01 14:00:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:22 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:22 --> URI Class Initialized
INFO - 2023-05-01 14:00:22 --> Router Class Initialized
INFO - 2023-05-01 14:00:22 --> Output Class Initialized
INFO - 2023-05-01 14:00:22 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:22 --> Input Class Initialized
INFO - 2023-05-01 14:00:22 --> Language Class Initialized
INFO - 2023-05-01 14:00:22 --> Language Class Initialized
INFO - 2023-05-01 14:00:22 --> Config Class Initialized
INFO - 2023-05-01 14:00:22 --> Loader Class Initialized
INFO - 2023-05-01 14:00:22 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:22 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:22 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:22 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:22 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:22 --> Controller Class Initialized
DEBUG - 2023-05-01 14:00:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:00:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:00:22 --> Final output sent to browser
DEBUG - 2023-05-01 14:00:22 --> Total execution time: 0.0539
INFO - 2023-05-01 14:00:24 --> Config Class Initialized
INFO - 2023-05-01 14:00:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:24 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:24 --> URI Class Initialized
INFO - 2023-05-01 14:00:24 --> Router Class Initialized
INFO - 2023-05-01 14:00:24 --> Output Class Initialized
INFO - 2023-05-01 14:00:24 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:24 --> Input Class Initialized
INFO - 2023-05-01 14:00:24 --> Language Class Initialized
INFO - 2023-05-01 14:00:24 --> Language Class Initialized
INFO - 2023-05-01 14:00:24 --> Config Class Initialized
INFO - 2023-05-01 14:00:24 --> Loader Class Initialized
INFO - 2023-05-01 14:00:24 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:24 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:24 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:24 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:24 --> Controller Class Initialized
DEBUG - 2023-05-01 14:00:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:00:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:00:25 --> Final output sent to browser
DEBUG - 2023-05-01 14:00:25 --> Total execution time: 0.0573
INFO - 2023-05-01 14:00:25 --> Config Class Initialized
INFO - 2023-05-01 14:00:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:00:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:00:25 --> Utf8 Class Initialized
INFO - 2023-05-01 14:00:25 --> URI Class Initialized
INFO - 2023-05-01 14:00:25 --> Router Class Initialized
INFO - 2023-05-01 14:00:25 --> Output Class Initialized
INFO - 2023-05-01 14:00:25 --> Security Class Initialized
DEBUG - 2023-05-01 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:00:25 --> Input Class Initialized
INFO - 2023-05-01 14:00:25 --> Language Class Initialized
INFO - 2023-05-01 14:00:25 --> Language Class Initialized
INFO - 2023-05-01 14:00:25 --> Config Class Initialized
INFO - 2023-05-01 14:00:25 --> Loader Class Initialized
INFO - 2023-05-01 14:00:25 --> Helper loaded: url_helper
INFO - 2023-05-01 14:00:25 --> Helper loaded: file_helper
INFO - 2023-05-01 14:00:25 --> Helper loaded: form_helper
INFO - 2023-05-01 14:00:25 --> Helper loaded: my_helper
INFO - 2023-05-01 14:00:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:00:25 --> Controller Class Initialized
INFO - 2023-05-01 14:02:17 --> Config Class Initialized
INFO - 2023-05-01 14:02:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:02:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:02:17 --> Utf8 Class Initialized
INFO - 2023-05-01 14:02:17 --> URI Class Initialized
INFO - 2023-05-01 14:02:17 --> Router Class Initialized
INFO - 2023-05-01 14:02:17 --> Output Class Initialized
INFO - 2023-05-01 14:02:17 --> Security Class Initialized
DEBUG - 2023-05-01 14:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:02:17 --> Input Class Initialized
INFO - 2023-05-01 14:02:17 --> Language Class Initialized
INFO - 2023-05-01 14:02:17 --> Language Class Initialized
INFO - 2023-05-01 14:02:17 --> Config Class Initialized
INFO - 2023-05-01 14:02:17 --> Loader Class Initialized
INFO - 2023-05-01 14:02:17 --> Helper loaded: url_helper
INFO - 2023-05-01 14:02:17 --> Helper loaded: file_helper
INFO - 2023-05-01 14:02:17 --> Helper loaded: form_helper
INFO - 2023-05-01 14:02:17 --> Helper loaded: my_helper
INFO - 2023-05-01 14:02:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:02:17 --> Controller Class Initialized
INFO - 2023-05-01 14:02:17 --> Final output sent to browser
DEBUG - 2023-05-01 14:02:17 --> Total execution time: 0.0396
INFO - 2023-05-01 14:03:19 --> Config Class Initialized
INFO - 2023-05-01 14:03:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:03:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:03:19 --> Utf8 Class Initialized
INFO - 2023-05-01 14:03:19 --> URI Class Initialized
INFO - 2023-05-01 14:03:19 --> Router Class Initialized
INFO - 2023-05-01 14:03:19 --> Output Class Initialized
INFO - 2023-05-01 14:03:19 --> Security Class Initialized
DEBUG - 2023-05-01 14:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:03:19 --> Input Class Initialized
INFO - 2023-05-01 14:03:19 --> Language Class Initialized
INFO - 2023-05-01 14:03:19 --> Language Class Initialized
INFO - 2023-05-01 14:03:19 --> Config Class Initialized
INFO - 2023-05-01 14:03:19 --> Loader Class Initialized
INFO - 2023-05-01 14:03:19 --> Helper loaded: url_helper
INFO - 2023-05-01 14:03:19 --> Helper loaded: file_helper
INFO - 2023-05-01 14:03:19 --> Helper loaded: form_helper
INFO - 2023-05-01 14:03:19 --> Helper loaded: my_helper
INFO - 2023-05-01 14:03:19 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:03:19 --> Controller Class Initialized
DEBUG - 2023-05-01 14:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:03:19 --> Final output sent to browser
DEBUG - 2023-05-01 14:03:19 --> Total execution time: 0.0595
INFO - 2023-05-01 14:03:19 --> Config Class Initialized
INFO - 2023-05-01 14:03:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:03:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:03:19 --> Utf8 Class Initialized
INFO - 2023-05-01 14:03:19 --> URI Class Initialized
INFO - 2023-05-01 14:03:19 --> Router Class Initialized
INFO - 2023-05-01 14:03:19 --> Output Class Initialized
INFO - 2023-05-01 14:03:19 --> Security Class Initialized
DEBUG - 2023-05-01 14:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:03:19 --> Input Class Initialized
INFO - 2023-05-01 14:03:19 --> Language Class Initialized
INFO - 2023-05-01 14:03:19 --> Language Class Initialized
INFO - 2023-05-01 14:03:19 --> Config Class Initialized
INFO - 2023-05-01 14:03:19 --> Loader Class Initialized
INFO - 2023-05-01 14:03:19 --> Helper loaded: url_helper
INFO - 2023-05-01 14:03:19 --> Helper loaded: file_helper
INFO - 2023-05-01 14:03:19 --> Helper loaded: form_helper
INFO - 2023-05-01 14:03:19 --> Helper loaded: my_helper
INFO - 2023-05-01 14:03:19 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:03:19 --> Controller Class Initialized
INFO - 2023-05-01 14:11:32 --> Config Class Initialized
INFO - 2023-05-01 14:11:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:11:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:11:32 --> Utf8 Class Initialized
INFO - 2023-05-01 14:11:32 --> URI Class Initialized
INFO - 2023-05-01 14:11:32 --> Router Class Initialized
INFO - 2023-05-01 14:11:32 --> Output Class Initialized
INFO - 2023-05-01 14:11:32 --> Security Class Initialized
DEBUG - 2023-05-01 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:11:32 --> Input Class Initialized
INFO - 2023-05-01 14:11:32 --> Language Class Initialized
INFO - 2023-05-01 14:11:32 --> Language Class Initialized
INFO - 2023-05-01 14:11:32 --> Config Class Initialized
INFO - 2023-05-01 14:11:32 --> Loader Class Initialized
INFO - 2023-05-01 14:11:32 --> Helper loaded: url_helper
INFO - 2023-05-01 14:11:32 --> Helper loaded: file_helper
INFO - 2023-05-01 14:11:32 --> Helper loaded: form_helper
INFO - 2023-05-01 14:11:32 --> Helper loaded: my_helper
INFO - 2023-05-01 14:11:32 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:11:32 --> Controller Class Initialized
DEBUG - 2023-05-01 14:11:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:11:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:11:32 --> Final output sent to browser
DEBUG - 2023-05-01 14:11:32 --> Total execution time: 0.0568
INFO - 2023-05-01 14:11:32 --> Config Class Initialized
INFO - 2023-05-01 14:11:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:11:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:11:32 --> Utf8 Class Initialized
INFO - 2023-05-01 14:11:32 --> URI Class Initialized
INFO - 2023-05-01 14:11:32 --> Router Class Initialized
INFO - 2023-05-01 14:11:32 --> Output Class Initialized
INFO - 2023-05-01 14:11:32 --> Security Class Initialized
DEBUG - 2023-05-01 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:11:32 --> Input Class Initialized
INFO - 2023-05-01 14:11:32 --> Language Class Initialized
INFO - 2023-05-01 14:11:32 --> Language Class Initialized
INFO - 2023-05-01 14:11:32 --> Config Class Initialized
INFO - 2023-05-01 14:11:32 --> Loader Class Initialized
INFO - 2023-05-01 14:11:32 --> Helper loaded: url_helper
INFO - 2023-05-01 14:11:32 --> Helper loaded: file_helper
INFO - 2023-05-01 14:11:32 --> Helper loaded: form_helper
INFO - 2023-05-01 14:11:32 --> Helper loaded: my_helper
INFO - 2023-05-01 14:11:32 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:11:32 --> Controller Class Initialized
INFO - 2023-05-01 14:11:34 --> Config Class Initialized
INFO - 2023-05-01 14:11:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:11:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:11:34 --> Utf8 Class Initialized
INFO - 2023-05-01 14:11:34 --> URI Class Initialized
INFO - 2023-05-01 14:11:34 --> Router Class Initialized
INFO - 2023-05-01 14:11:34 --> Output Class Initialized
INFO - 2023-05-01 14:11:34 --> Security Class Initialized
DEBUG - 2023-05-01 14:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:11:34 --> Input Class Initialized
INFO - 2023-05-01 14:11:34 --> Language Class Initialized
INFO - 2023-05-01 14:11:34 --> Language Class Initialized
INFO - 2023-05-01 14:11:34 --> Config Class Initialized
INFO - 2023-05-01 14:11:34 --> Loader Class Initialized
INFO - 2023-05-01 14:11:34 --> Helper loaded: url_helper
INFO - 2023-05-01 14:11:34 --> Helper loaded: file_helper
INFO - 2023-05-01 14:11:34 --> Helper loaded: form_helper
INFO - 2023-05-01 14:11:34 --> Helper loaded: my_helper
INFO - 2023-05-01 14:11:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:11:34 --> Controller Class Initialized
INFO - 2023-05-01 14:11:34 --> Final output sent to browser
DEBUG - 2023-05-01 14:11:34 --> Total execution time: 0.0395
INFO - 2023-05-01 14:11:55 --> Config Class Initialized
INFO - 2023-05-01 14:11:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:11:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:11:55 --> Utf8 Class Initialized
INFO - 2023-05-01 14:11:55 --> URI Class Initialized
INFO - 2023-05-01 14:11:55 --> Router Class Initialized
INFO - 2023-05-01 14:11:55 --> Output Class Initialized
INFO - 2023-05-01 14:11:55 --> Security Class Initialized
DEBUG - 2023-05-01 14:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:11:55 --> Input Class Initialized
INFO - 2023-05-01 14:11:55 --> Language Class Initialized
INFO - 2023-05-01 14:11:55 --> Language Class Initialized
INFO - 2023-05-01 14:11:55 --> Config Class Initialized
INFO - 2023-05-01 14:11:55 --> Loader Class Initialized
INFO - 2023-05-01 14:11:55 --> Helper loaded: url_helper
INFO - 2023-05-01 14:11:55 --> Helper loaded: file_helper
INFO - 2023-05-01 14:11:55 --> Helper loaded: form_helper
INFO - 2023-05-01 14:11:55 --> Helper loaded: my_helper
INFO - 2023-05-01 14:11:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:11:55 --> Controller Class Initialized
DEBUG - 2023-05-01 14:11:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:11:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:11:55 --> Final output sent to browser
DEBUG - 2023-05-01 14:11:55 --> Total execution time: 0.0580
INFO - 2023-05-01 14:11:55 --> Config Class Initialized
INFO - 2023-05-01 14:11:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:11:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:11:55 --> Utf8 Class Initialized
INFO - 2023-05-01 14:11:55 --> URI Class Initialized
INFO - 2023-05-01 14:11:55 --> Router Class Initialized
INFO - 2023-05-01 14:11:55 --> Output Class Initialized
INFO - 2023-05-01 14:11:55 --> Security Class Initialized
DEBUG - 2023-05-01 14:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:11:55 --> Input Class Initialized
INFO - 2023-05-01 14:11:55 --> Language Class Initialized
INFO - 2023-05-01 14:11:55 --> Language Class Initialized
INFO - 2023-05-01 14:11:55 --> Config Class Initialized
INFO - 2023-05-01 14:11:55 --> Loader Class Initialized
INFO - 2023-05-01 14:11:55 --> Helper loaded: url_helper
INFO - 2023-05-01 14:11:55 --> Helper loaded: file_helper
INFO - 2023-05-01 14:11:55 --> Helper loaded: form_helper
INFO - 2023-05-01 14:11:55 --> Helper loaded: my_helper
INFO - 2023-05-01 14:11:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:11:55 --> Controller Class Initialized
INFO - 2023-05-01 14:11:58 --> Config Class Initialized
INFO - 2023-05-01 14:11:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:11:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:11:58 --> Utf8 Class Initialized
INFO - 2023-05-01 14:11:58 --> URI Class Initialized
INFO - 2023-05-01 14:11:58 --> Router Class Initialized
INFO - 2023-05-01 14:11:58 --> Output Class Initialized
INFO - 2023-05-01 14:11:58 --> Security Class Initialized
DEBUG - 2023-05-01 14:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:11:58 --> Input Class Initialized
INFO - 2023-05-01 14:11:58 --> Language Class Initialized
INFO - 2023-05-01 14:11:58 --> Language Class Initialized
INFO - 2023-05-01 14:11:58 --> Config Class Initialized
INFO - 2023-05-01 14:11:58 --> Loader Class Initialized
INFO - 2023-05-01 14:11:58 --> Helper loaded: url_helper
INFO - 2023-05-01 14:11:58 --> Helper loaded: file_helper
INFO - 2023-05-01 14:11:58 --> Helper loaded: form_helper
INFO - 2023-05-01 14:11:58 --> Helper loaded: my_helper
INFO - 2023-05-01 14:11:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:11:58 --> Controller Class Initialized
INFO - 2023-05-01 14:11:58 --> Final output sent to browser
DEBUG - 2023-05-01 14:11:58 --> Total execution time: 0.0587
INFO - 2023-05-01 14:12:16 --> Config Class Initialized
INFO - 2023-05-01 14:12:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:12:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:12:16 --> Utf8 Class Initialized
INFO - 2023-05-01 14:12:16 --> URI Class Initialized
INFO - 2023-05-01 14:12:16 --> Router Class Initialized
INFO - 2023-05-01 14:12:16 --> Output Class Initialized
INFO - 2023-05-01 14:12:16 --> Security Class Initialized
DEBUG - 2023-05-01 14:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:12:16 --> Input Class Initialized
INFO - 2023-05-01 14:12:16 --> Language Class Initialized
INFO - 2023-05-01 14:12:16 --> Language Class Initialized
INFO - 2023-05-01 14:12:16 --> Config Class Initialized
INFO - 2023-05-01 14:12:16 --> Loader Class Initialized
INFO - 2023-05-01 14:12:16 --> Helper loaded: url_helper
INFO - 2023-05-01 14:12:16 --> Helper loaded: file_helper
INFO - 2023-05-01 14:12:16 --> Helper loaded: form_helper
INFO - 2023-05-01 14:12:16 --> Helper loaded: my_helper
INFO - 2023-05-01 14:12:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:12:16 --> Controller Class Initialized
ERROR - 2023-05-01 14:12:16 --> Severity: Notice --> Undefined variable: q_siswa_kelas C:\xampp\htdocs\myraportk13\application\modules\n_preschool\controllers\N_preschool.php 115
ERROR - 2023-05-01 14:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_preschool\controllers\N_preschool.php 115
DEBUG - 2023-05-01 14:12:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/cetak.php
INFO - 2023-05-01 14:12:16 --> Final output sent to browser
DEBUG - 2023-05-01 14:12:16 --> Total execution time: 0.1395
INFO - 2023-05-01 14:15:34 --> Config Class Initialized
INFO - 2023-05-01 14:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:15:34 --> Utf8 Class Initialized
INFO - 2023-05-01 14:15:34 --> URI Class Initialized
INFO - 2023-05-01 14:15:34 --> Router Class Initialized
INFO - 2023-05-01 14:15:34 --> Output Class Initialized
INFO - 2023-05-01 14:15:34 --> Security Class Initialized
DEBUG - 2023-05-01 14:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:15:34 --> Input Class Initialized
INFO - 2023-05-01 14:15:34 --> Language Class Initialized
INFO - 2023-05-01 14:15:34 --> Language Class Initialized
INFO - 2023-05-01 14:15:34 --> Config Class Initialized
INFO - 2023-05-01 14:15:34 --> Loader Class Initialized
INFO - 2023-05-01 14:15:34 --> Helper loaded: url_helper
INFO - 2023-05-01 14:15:34 --> Helper loaded: file_helper
INFO - 2023-05-01 14:15:34 --> Helper loaded: form_helper
INFO - 2023-05-01 14:15:34 --> Helper loaded: my_helper
INFO - 2023-05-01 14:15:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:15:34 --> Controller Class Initialized
DEBUG - 2023-05-01 14:15:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:15:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:15:34 --> Final output sent to browser
DEBUG - 2023-05-01 14:15:34 --> Total execution time: 0.0545
INFO - 2023-05-01 14:15:40 --> Config Class Initialized
INFO - 2023-05-01 14:15:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:15:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:15:40 --> Utf8 Class Initialized
INFO - 2023-05-01 14:15:40 --> URI Class Initialized
INFO - 2023-05-01 14:15:40 --> Router Class Initialized
INFO - 2023-05-01 14:15:40 --> Output Class Initialized
INFO - 2023-05-01 14:15:40 --> Security Class Initialized
DEBUG - 2023-05-01 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:15:40 --> Input Class Initialized
INFO - 2023-05-01 14:15:40 --> Language Class Initialized
INFO - 2023-05-01 14:15:40 --> Language Class Initialized
INFO - 2023-05-01 14:15:40 --> Config Class Initialized
INFO - 2023-05-01 14:15:40 --> Loader Class Initialized
INFO - 2023-05-01 14:15:40 --> Helper loaded: url_helper
INFO - 2023-05-01 14:15:40 --> Helper loaded: file_helper
INFO - 2023-05-01 14:15:40 --> Helper loaded: form_helper
INFO - 2023-05-01 14:15:40 --> Helper loaded: my_helper
INFO - 2023-05-01 14:15:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:15:40 --> Controller Class Initialized
DEBUG - 2023-05-01 14:15:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:15:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:15:40 --> Final output sent to browser
DEBUG - 2023-05-01 14:15:40 --> Total execution time: 0.0578
INFO - 2023-05-01 14:15:40 --> Config Class Initialized
INFO - 2023-05-01 14:15:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:15:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:15:40 --> Utf8 Class Initialized
INFO - 2023-05-01 14:15:40 --> URI Class Initialized
INFO - 2023-05-01 14:15:40 --> Router Class Initialized
INFO - 2023-05-01 14:15:40 --> Output Class Initialized
INFO - 2023-05-01 14:15:40 --> Security Class Initialized
DEBUG - 2023-05-01 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:15:40 --> Input Class Initialized
INFO - 2023-05-01 14:15:40 --> Language Class Initialized
INFO - 2023-05-01 14:15:40 --> Language Class Initialized
INFO - 2023-05-01 14:15:40 --> Config Class Initialized
INFO - 2023-05-01 14:15:40 --> Loader Class Initialized
INFO - 2023-05-01 14:15:40 --> Helper loaded: url_helper
INFO - 2023-05-01 14:15:40 --> Helper loaded: file_helper
INFO - 2023-05-01 14:15:40 --> Helper loaded: form_helper
INFO - 2023-05-01 14:15:40 --> Helper loaded: my_helper
INFO - 2023-05-01 14:15:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:15:41 --> Controller Class Initialized
INFO - 2023-05-01 14:15:43 --> Config Class Initialized
INFO - 2023-05-01 14:15:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:15:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:15:43 --> Utf8 Class Initialized
INFO - 2023-05-01 14:15:43 --> URI Class Initialized
INFO - 2023-05-01 14:15:43 --> Router Class Initialized
INFO - 2023-05-01 14:15:43 --> Output Class Initialized
INFO - 2023-05-01 14:15:43 --> Security Class Initialized
DEBUG - 2023-05-01 14:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:15:43 --> Input Class Initialized
INFO - 2023-05-01 14:15:43 --> Language Class Initialized
INFO - 2023-05-01 14:15:43 --> Language Class Initialized
INFO - 2023-05-01 14:15:43 --> Config Class Initialized
INFO - 2023-05-01 14:15:43 --> Loader Class Initialized
INFO - 2023-05-01 14:15:43 --> Helper loaded: url_helper
INFO - 2023-05-01 14:15:43 --> Helper loaded: file_helper
INFO - 2023-05-01 14:15:43 --> Helper loaded: form_helper
INFO - 2023-05-01 14:15:43 --> Helper loaded: my_helper
INFO - 2023-05-01 14:15:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:15:43 --> Controller Class Initialized
DEBUG - 2023-05-01 14:15:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:15:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:15:43 --> Final output sent to browser
DEBUG - 2023-05-01 14:15:43 --> Total execution time: 0.0598
INFO - 2023-05-01 14:15:45 --> Config Class Initialized
INFO - 2023-05-01 14:15:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:15:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:15:45 --> Utf8 Class Initialized
INFO - 2023-05-01 14:15:45 --> URI Class Initialized
INFO - 2023-05-01 14:15:45 --> Router Class Initialized
INFO - 2023-05-01 14:15:45 --> Output Class Initialized
INFO - 2023-05-01 14:15:45 --> Security Class Initialized
DEBUG - 2023-05-01 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:15:45 --> Input Class Initialized
INFO - 2023-05-01 14:15:45 --> Language Class Initialized
INFO - 2023-05-01 14:15:45 --> Language Class Initialized
INFO - 2023-05-01 14:15:45 --> Config Class Initialized
INFO - 2023-05-01 14:15:45 --> Loader Class Initialized
INFO - 2023-05-01 14:15:45 --> Helper loaded: url_helper
INFO - 2023-05-01 14:15:45 --> Helper loaded: file_helper
INFO - 2023-05-01 14:15:45 --> Helper loaded: form_helper
INFO - 2023-05-01 14:15:45 --> Helper loaded: my_helper
INFO - 2023-05-01 14:15:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:15:45 --> Controller Class Initialized
DEBUG - 2023-05-01 14:15:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:15:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:15:45 --> Final output sent to browser
DEBUG - 2023-05-01 14:15:45 --> Total execution time: 0.0419
INFO - 2023-05-01 14:15:45 --> Config Class Initialized
INFO - 2023-05-01 14:15:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:15:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:15:45 --> Utf8 Class Initialized
INFO - 2023-05-01 14:15:45 --> URI Class Initialized
INFO - 2023-05-01 14:15:45 --> Router Class Initialized
INFO - 2023-05-01 14:15:45 --> Output Class Initialized
INFO - 2023-05-01 14:15:45 --> Security Class Initialized
DEBUG - 2023-05-01 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:15:45 --> Input Class Initialized
INFO - 2023-05-01 14:15:45 --> Language Class Initialized
INFO - 2023-05-01 14:15:45 --> Language Class Initialized
INFO - 2023-05-01 14:15:45 --> Config Class Initialized
INFO - 2023-05-01 14:15:45 --> Loader Class Initialized
INFO - 2023-05-01 14:15:45 --> Helper loaded: url_helper
INFO - 2023-05-01 14:15:45 --> Helper loaded: file_helper
INFO - 2023-05-01 14:15:45 --> Helper loaded: form_helper
INFO - 2023-05-01 14:15:45 --> Helper loaded: my_helper
INFO - 2023-05-01 14:15:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:15:45 --> Controller Class Initialized
INFO - 2023-05-01 14:16:38 --> Config Class Initialized
INFO - 2023-05-01 14:16:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:16:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:16:38 --> Utf8 Class Initialized
INFO - 2023-05-01 14:16:38 --> URI Class Initialized
INFO - 2023-05-01 14:16:38 --> Router Class Initialized
INFO - 2023-05-01 14:16:38 --> Output Class Initialized
INFO - 2023-05-01 14:16:38 --> Security Class Initialized
DEBUG - 2023-05-01 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:16:38 --> Input Class Initialized
INFO - 2023-05-01 14:16:38 --> Language Class Initialized
INFO - 2023-05-01 14:16:38 --> Language Class Initialized
INFO - 2023-05-01 14:16:38 --> Config Class Initialized
INFO - 2023-05-01 14:16:38 --> Loader Class Initialized
INFO - 2023-05-01 14:16:38 --> Helper loaded: url_helper
INFO - 2023-05-01 14:16:38 --> Helper loaded: file_helper
INFO - 2023-05-01 14:16:38 --> Helper loaded: form_helper
INFO - 2023-05-01 14:16:38 --> Helper loaded: my_helper
INFO - 2023-05-01 14:16:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:16:38 --> Controller Class Initialized
INFO - 2023-05-01 14:16:38 --> Final output sent to browser
DEBUG - 2023-05-01 14:16:38 --> Total execution time: 0.0696
INFO - 2023-05-01 14:17:04 --> Config Class Initialized
INFO - 2023-05-01 14:17:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:04 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:04 --> URI Class Initialized
INFO - 2023-05-01 14:17:04 --> Router Class Initialized
INFO - 2023-05-01 14:17:04 --> Output Class Initialized
INFO - 2023-05-01 14:17:04 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:04 --> Input Class Initialized
INFO - 2023-05-01 14:17:04 --> Language Class Initialized
INFO - 2023-05-01 14:17:04 --> Language Class Initialized
INFO - 2023-05-01 14:17:04 --> Config Class Initialized
INFO - 2023-05-01 14:17:05 --> Loader Class Initialized
INFO - 2023-05-01 14:17:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:05 --> Controller Class Initialized
INFO - 2023-05-01 14:17:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:17:05 --> Total execution time: 0.0582
INFO - 2023-05-01 14:17:05 --> Config Class Initialized
INFO - 2023-05-01 14:17:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:05 --> URI Class Initialized
INFO - 2023-05-01 14:17:05 --> Router Class Initialized
INFO - 2023-05-01 14:17:05 --> Output Class Initialized
INFO - 2023-05-01 14:17:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:05 --> Input Class Initialized
INFO - 2023-05-01 14:17:05 --> Language Class Initialized
INFO - 2023-05-01 14:17:05 --> Language Class Initialized
INFO - 2023-05-01 14:17:05 --> Config Class Initialized
INFO - 2023-05-01 14:17:05 --> Loader Class Initialized
INFO - 2023-05-01 14:17:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:05 --> Controller Class Initialized
INFO - 2023-05-01 14:17:20 --> Config Class Initialized
INFO - 2023-05-01 14:17:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:20 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:20 --> URI Class Initialized
INFO - 2023-05-01 14:17:20 --> Router Class Initialized
INFO - 2023-05-01 14:17:20 --> Output Class Initialized
INFO - 2023-05-01 14:17:20 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:20 --> Input Class Initialized
INFO - 2023-05-01 14:17:20 --> Language Class Initialized
INFO - 2023-05-01 14:17:20 --> Language Class Initialized
INFO - 2023-05-01 14:17:20 --> Config Class Initialized
INFO - 2023-05-01 14:17:20 --> Loader Class Initialized
INFO - 2023-05-01 14:17:20 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:20 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:20 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:20 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:20 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:20 --> Controller Class Initialized
INFO - 2023-05-01 14:17:20 --> Final output sent to browser
DEBUG - 2023-05-01 14:17:20 --> Total execution time: 0.0558
INFO - 2023-05-01 14:17:28 --> Config Class Initialized
INFO - 2023-05-01 14:17:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:28 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:28 --> URI Class Initialized
INFO - 2023-05-01 14:17:28 --> Router Class Initialized
INFO - 2023-05-01 14:17:28 --> Output Class Initialized
INFO - 2023-05-01 14:17:28 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:28 --> Input Class Initialized
INFO - 2023-05-01 14:17:28 --> Language Class Initialized
INFO - 2023-05-01 14:17:28 --> Language Class Initialized
INFO - 2023-05-01 14:17:28 --> Config Class Initialized
INFO - 2023-05-01 14:17:28 --> Loader Class Initialized
INFO - 2023-05-01 14:17:28 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:28 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:28 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:28 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:28 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:28 --> Controller Class Initialized
INFO - 2023-05-01 14:17:28 --> Final output sent to browser
DEBUG - 2023-05-01 14:17:28 --> Total execution time: 0.0441
INFO - 2023-05-01 14:17:28 --> Config Class Initialized
INFO - 2023-05-01 14:17:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:28 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:28 --> URI Class Initialized
INFO - 2023-05-01 14:17:28 --> Router Class Initialized
INFO - 2023-05-01 14:17:28 --> Output Class Initialized
INFO - 2023-05-01 14:17:28 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:28 --> Input Class Initialized
INFO - 2023-05-01 14:17:28 --> Language Class Initialized
INFO - 2023-05-01 14:17:28 --> Language Class Initialized
INFO - 2023-05-01 14:17:28 --> Config Class Initialized
INFO - 2023-05-01 14:17:28 --> Loader Class Initialized
INFO - 2023-05-01 14:17:28 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:28 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:28 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:28 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:28 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:28 --> Controller Class Initialized
INFO - 2023-05-01 14:17:30 --> Config Class Initialized
INFO - 2023-05-01 14:17:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:30 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:30 --> URI Class Initialized
INFO - 2023-05-01 14:17:30 --> Router Class Initialized
INFO - 2023-05-01 14:17:30 --> Output Class Initialized
INFO - 2023-05-01 14:17:30 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:30 --> Input Class Initialized
INFO - 2023-05-01 14:17:30 --> Language Class Initialized
INFO - 2023-05-01 14:17:30 --> Language Class Initialized
INFO - 2023-05-01 14:17:30 --> Config Class Initialized
INFO - 2023-05-01 14:17:30 --> Loader Class Initialized
INFO - 2023-05-01 14:17:30 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:30 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:30 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:30 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:30 --> Controller Class Initialized
INFO - 2023-05-01 14:17:58 --> Config Class Initialized
INFO - 2023-05-01 14:17:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:17:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:17:58 --> Utf8 Class Initialized
INFO - 2023-05-01 14:17:58 --> URI Class Initialized
INFO - 2023-05-01 14:17:58 --> Router Class Initialized
INFO - 2023-05-01 14:17:58 --> Output Class Initialized
INFO - 2023-05-01 14:17:58 --> Security Class Initialized
DEBUG - 2023-05-01 14:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:17:58 --> Input Class Initialized
INFO - 2023-05-01 14:17:58 --> Language Class Initialized
INFO - 2023-05-01 14:17:58 --> Language Class Initialized
INFO - 2023-05-01 14:17:58 --> Config Class Initialized
INFO - 2023-05-01 14:17:58 --> Loader Class Initialized
INFO - 2023-05-01 14:17:58 --> Helper loaded: url_helper
INFO - 2023-05-01 14:17:58 --> Helper loaded: file_helper
INFO - 2023-05-01 14:17:58 --> Helper loaded: form_helper
INFO - 2023-05-01 14:17:58 --> Helper loaded: my_helper
INFO - 2023-05-01 14:17:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:17:58 --> Controller Class Initialized
DEBUG - 2023-05-01 14:17:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:17:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:17:58 --> Final output sent to browser
DEBUG - 2023-05-01 14:17:58 --> Total execution time: 0.0649
INFO - 2023-05-01 14:18:01 --> Config Class Initialized
INFO - 2023-05-01 14:18:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:01 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:01 --> URI Class Initialized
INFO - 2023-05-01 14:18:01 --> Router Class Initialized
INFO - 2023-05-01 14:18:01 --> Output Class Initialized
INFO - 2023-05-01 14:18:01 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:01 --> Input Class Initialized
INFO - 2023-05-01 14:18:01 --> Language Class Initialized
INFO - 2023-05-01 14:18:01 --> Language Class Initialized
INFO - 2023-05-01 14:18:01 --> Config Class Initialized
INFO - 2023-05-01 14:18:01 --> Loader Class Initialized
INFO - 2023-05-01 14:18:01 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:01 --> Controller Class Initialized
INFO - 2023-05-01 14:18:01 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:18:01 --> Config Class Initialized
INFO - 2023-05-01 14:18:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:01 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:01 --> URI Class Initialized
INFO - 2023-05-01 14:18:01 --> Router Class Initialized
INFO - 2023-05-01 14:18:01 --> Output Class Initialized
INFO - 2023-05-01 14:18:01 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:01 --> Input Class Initialized
INFO - 2023-05-01 14:18:01 --> Language Class Initialized
INFO - 2023-05-01 14:18:01 --> Language Class Initialized
INFO - 2023-05-01 14:18:01 --> Config Class Initialized
INFO - 2023-05-01 14:18:01 --> Loader Class Initialized
INFO - 2023-05-01 14:18:01 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:01 --> Controller Class Initialized
INFO - 2023-05-01 14:18:01 --> Config Class Initialized
INFO - 2023-05-01 14:18:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:01 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:01 --> URI Class Initialized
INFO - 2023-05-01 14:18:01 --> Router Class Initialized
INFO - 2023-05-01 14:18:01 --> Output Class Initialized
INFO - 2023-05-01 14:18:01 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:01 --> Input Class Initialized
INFO - 2023-05-01 14:18:01 --> Language Class Initialized
INFO - 2023-05-01 14:18:01 --> Language Class Initialized
INFO - 2023-05-01 14:18:01 --> Config Class Initialized
INFO - 2023-05-01 14:18:01 --> Loader Class Initialized
INFO - 2023-05-01 14:18:01 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:01 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:01 --> Controller Class Initialized
DEBUG - 2023-05-01 14:18:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 14:18:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:18:01 --> Final output sent to browser
DEBUG - 2023-05-01 14:18:01 --> Total execution time: 0.0343
INFO - 2023-05-01 14:18:05 --> Config Class Initialized
INFO - 2023-05-01 14:18:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:05 --> URI Class Initialized
INFO - 2023-05-01 14:18:05 --> Router Class Initialized
INFO - 2023-05-01 14:18:05 --> Output Class Initialized
INFO - 2023-05-01 14:18:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:05 --> Input Class Initialized
INFO - 2023-05-01 14:18:05 --> Language Class Initialized
INFO - 2023-05-01 14:18:05 --> Language Class Initialized
INFO - 2023-05-01 14:18:05 --> Config Class Initialized
INFO - 2023-05-01 14:18:05 --> Loader Class Initialized
INFO - 2023-05-01 14:18:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:05 --> Controller Class Initialized
INFO - 2023-05-01 14:18:05 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:18:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:18:05 --> Total execution time: 0.0456
INFO - 2023-05-01 14:18:05 --> Config Class Initialized
INFO - 2023-05-01 14:18:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:05 --> URI Class Initialized
INFO - 2023-05-01 14:18:05 --> Router Class Initialized
INFO - 2023-05-01 14:18:05 --> Output Class Initialized
INFO - 2023-05-01 14:18:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:05 --> Input Class Initialized
INFO - 2023-05-01 14:18:05 --> Language Class Initialized
INFO - 2023-05-01 14:18:05 --> Language Class Initialized
INFO - 2023-05-01 14:18:05 --> Config Class Initialized
INFO - 2023-05-01 14:18:05 --> Loader Class Initialized
INFO - 2023-05-01 14:18:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:05 --> Controller Class Initialized
DEBUG - 2023-05-01 14:18:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 14:18:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:18:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:18:05 --> Total execution time: 0.0468
INFO - 2023-05-01 14:18:07 --> Config Class Initialized
INFO - 2023-05-01 14:18:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:07 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:07 --> URI Class Initialized
INFO - 2023-05-01 14:18:07 --> Router Class Initialized
INFO - 2023-05-01 14:18:07 --> Output Class Initialized
INFO - 2023-05-01 14:18:07 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:07 --> Input Class Initialized
INFO - 2023-05-01 14:18:07 --> Language Class Initialized
INFO - 2023-05-01 14:18:07 --> Language Class Initialized
INFO - 2023-05-01 14:18:07 --> Config Class Initialized
INFO - 2023-05-01 14:18:07 --> Loader Class Initialized
INFO - 2023-05-01 14:18:07 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:07 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:07 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:07 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:07 --> Controller Class Initialized
DEBUG - 2023-05-01 14:18:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:18:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:18:07 --> Final output sent to browser
DEBUG - 2023-05-01 14:18:07 --> Total execution time: 0.0572
INFO - 2023-05-01 14:18:08 --> Config Class Initialized
INFO - 2023-05-01 14:18:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:08 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:08 --> URI Class Initialized
INFO - 2023-05-01 14:18:08 --> Router Class Initialized
INFO - 2023-05-01 14:18:08 --> Output Class Initialized
INFO - 2023-05-01 14:18:08 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:09 --> Input Class Initialized
INFO - 2023-05-01 14:18:09 --> Language Class Initialized
INFO - 2023-05-01 14:18:09 --> Language Class Initialized
INFO - 2023-05-01 14:18:09 --> Config Class Initialized
INFO - 2023-05-01 14:18:09 --> Loader Class Initialized
INFO - 2023-05-01 14:18:09 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:09 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:09 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:09 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:09 --> Controller Class Initialized
DEBUG - 2023-05-01 14:18:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-01 14:18:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:18:09 --> Final output sent to browser
DEBUG - 2023-05-01 14:18:09 --> Total execution time: 0.0850
INFO - 2023-05-01 14:18:09 --> Config Class Initialized
INFO - 2023-05-01 14:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:09 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:09 --> URI Class Initialized
INFO - 2023-05-01 14:18:09 --> Router Class Initialized
INFO - 2023-05-01 14:18:09 --> Output Class Initialized
INFO - 2023-05-01 14:18:09 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:09 --> Input Class Initialized
INFO - 2023-05-01 14:18:09 --> Language Class Initialized
INFO - 2023-05-01 14:18:09 --> Language Class Initialized
INFO - 2023-05-01 14:18:09 --> Config Class Initialized
INFO - 2023-05-01 14:18:09 --> Loader Class Initialized
INFO - 2023-05-01 14:18:09 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:09 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:09 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:09 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:09 --> Controller Class Initialized
INFO - 2023-05-01 14:18:10 --> Config Class Initialized
INFO - 2023-05-01 14:18:10 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:18:10 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:18:10 --> Utf8 Class Initialized
INFO - 2023-05-01 14:18:10 --> URI Class Initialized
INFO - 2023-05-01 14:18:10 --> Router Class Initialized
INFO - 2023-05-01 14:18:10 --> Output Class Initialized
INFO - 2023-05-01 14:18:10 --> Security Class Initialized
DEBUG - 2023-05-01 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:18:10 --> Input Class Initialized
INFO - 2023-05-01 14:18:10 --> Language Class Initialized
INFO - 2023-05-01 14:18:10 --> Language Class Initialized
INFO - 2023-05-01 14:18:10 --> Config Class Initialized
INFO - 2023-05-01 14:18:10 --> Loader Class Initialized
INFO - 2023-05-01 14:18:10 --> Helper loaded: url_helper
INFO - 2023-05-01 14:18:10 --> Helper loaded: file_helper
INFO - 2023-05-01 14:18:10 --> Helper loaded: form_helper
INFO - 2023-05-01 14:18:10 --> Helper loaded: my_helper
INFO - 2023-05-01 14:18:10 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:18:10 --> Controller Class Initialized
INFO - 2023-05-01 14:20:57 --> Config Class Initialized
INFO - 2023-05-01 14:20:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:20:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:20:57 --> Utf8 Class Initialized
INFO - 2023-05-01 14:20:57 --> URI Class Initialized
INFO - 2023-05-01 14:20:57 --> Router Class Initialized
INFO - 2023-05-01 14:20:57 --> Output Class Initialized
INFO - 2023-05-01 14:20:57 --> Security Class Initialized
DEBUG - 2023-05-01 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:20:57 --> Input Class Initialized
INFO - 2023-05-01 14:20:57 --> Language Class Initialized
INFO - 2023-05-01 14:20:57 --> Language Class Initialized
INFO - 2023-05-01 14:20:57 --> Config Class Initialized
INFO - 2023-05-01 14:20:57 --> Loader Class Initialized
INFO - 2023-05-01 14:20:57 --> Helper loaded: url_helper
INFO - 2023-05-01 14:20:57 --> Helper loaded: file_helper
INFO - 2023-05-01 14:20:57 --> Helper loaded: form_helper
INFO - 2023-05-01 14:20:57 --> Helper loaded: my_helper
INFO - 2023-05-01 14:20:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:20:57 --> Controller Class Initialized
DEBUG - 2023-05-01 14:20:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-01 14:20:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:20:57 --> Final output sent to browser
DEBUG - 2023-05-01 14:20:57 --> Total execution time: 0.0441
INFO - 2023-05-01 14:20:57 --> Config Class Initialized
INFO - 2023-05-01 14:20:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:20:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:20:57 --> Utf8 Class Initialized
INFO - 2023-05-01 14:20:57 --> URI Class Initialized
INFO - 2023-05-01 14:20:57 --> Router Class Initialized
INFO - 2023-05-01 14:20:57 --> Output Class Initialized
INFO - 2023-05-01 14:20:57 --> Security Class Initialized
DEBUG - 2023-05-01 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:20:57 --> Input Class Initialized
INFO - 2023-05-01 14:20:57 --> Language Class Initialized
INFO - 2023-05-01 14:20:57 --> Language Class Initialized
INFO - 2023-05-01 14:20:57 --> Config Class Initialized
INFO - 2023-05-01 14:20:57 --> Loader Class Initialized
INFO - 2023-05-01 14:20:57 --> Helper loaded: url_helper
INFO - 2023-05-01 14:20:57 --> Helper loaded: file_helper
INFO - 2023-05-01 14:20:57 --> Helper loaded: form_helper
INFO - 2023-05-01 14:20:57 --> Helper loaded: my_helper
INFO - 2023-05-01 14:20:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:20:57 --> Controller Class Initialized
INFO - 2023-05-01 14:20:58 --> Config Class Initialized
INFO - 2023-05-01 14:20:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:20:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:20:58 --> Utf8 Class Initialized
INFO - 2023-05-01 14:20:58 --> URI Class Initialized
INFO - 2023-05-01 14:20:58 --> Router Class Initialized
INFO - 2023-05-01 14:20:58 --> Output Class Initialized
INFO - 2023-05-01 14:20:58 --> Security Class Initialized
DEBUG - 2023-05-01 14:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:20:58 --> Input Class Initialized
INFO - 2023-05-01 14:20:58 --> Language Class Initialized
INFO - 2023-05-01 14:20:58 --> Language Class Initialized
INFO - 2023-05-01 14:20:58 --> Config Class Initialized
INFO - 2023-05-01 14:20:58 --> Loader Class Initialized
INFO - 2023-05-01 14:20:58 --> Helper loaded: url_helper
INFO - 2023-05-01 14:20:58 --> Helper loaded: file_helper
INFO - 2023-05-01 14:20:58 --> Helper loaded: form_helper
INFO - 2023-05-01 14:20:58 --> Helper loaded: my_helper
INFO - 2023-05-01 14:20:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:20:58 --> Controller Class Initialized
DEBUG - 2023-05-01 14:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:20:58 --> Final output sent to browser
DEBUG - 2023-05-01 14:20:58 --> Total execution time: 0.0550
INFO - 2023-05-01 14:21:00 --> Config Class Initialized
INFO - 2023-05-01 14:21:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:00 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:00 --> URI Class Initialized
INFO - 2023-05-01 14:21:00 --> Router Class Initialized
INFO - 2023-05-01 14:21:00 --> Output Class Initialized
INFO - 2023-05-01 14:21:00 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:00 --> Input Class Initialized
INFO - 2023-05-01 14:21:00 --> Language Class Initialized
INFO - 2023-05-01 14:21:00 --> Language Class Initialized
INFO - 2023-05-01 14:21:00 --> Config Class Initialized
INFO - 2023-05-01 14:21:00 --> Loader Class Initialized
INFO - 2023-05-01 14:21:00 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:00 --> Controller Class Initialized
INFO - 2023-05-01 14:21:00 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:21:00 --> Config Class Initialized
INFO - 2023-05-01 14:21:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:00 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:00 --> URI Class Initialized
INFO - 2023-05-01 14:21:00 --> Router Class Initialized
INFO - 2023-05-01 14:21:00 --> Output Class Initialized
INFO - 2023-05-01 14:21:00 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:00 --> Input Class Initialized
INFO - 2023-05-01 14:21:00 --> Language Class Initialized
INFO - 2023-05-01 14:21:00 --> Language Class Initialized
INFO - 2023-05-01 14:21:00 --> Config Class Initialized
INFO - 2023-05-01 14:21:00 --> Loader Class Initialized
INFO - 2023-05-01 14:21:00 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:00 --> Controller Class Initialized
INFO - 2023-05-01 14:21:00 --> Config Class Initialized
INFO - 2023-05-01 14:21:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:00 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:00 --> URI Class Initialized
INFO - 2023-05-01 14:21:00 --> Router Class Initialized
INFO - 2023-05-01 14:21:00 --> Output Class Initialized
INFO - 2023-05-01 14:21:00 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:00 --> Input Class Initialized
INFO - 2023-05-01 14:21:00 --> Language Class Initialized
INFO - 2023-05-01 14:21:00 --> Language Class Initialized
INFO - 2023-05-01 14:21:00 --> Config Class Initialized
INFO - 2023-05-01 14:21:00 --> Loader Class Initialized
INFO - 2023-05-01 14:21:00 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:00 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:00 --> Controller Class Initialized
DEBUG - 2023-05-01 14:21:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 14:21:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:21:00 --> Final output sent to browser
DEBUG - 2023-05-01 14:21:00 --> Total execution time: 0.0351
INFO - 2023-05-01 14:21:05 --> Config Class Initialized
INFO - 2023-05-01 14:21:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:05 --> URI Class Initialized
INFO - 2023-05-01 14:21:05 --> Router Class Initialized
INFO - 2023-05-01 14:21:05 --> Output Class Initialized
INFO - 2023-05-01 14:21:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:05 --> Input Class Initialized
INFO - 2023-05-01 14:21:05 --> Language Class Initialized
INFO - 2023-05-01 14:21:05 --> Language Class Initialized
INFO - 2023-05-01 14:21:05 --> Config Class Initialized
INFO - 2023-05-01 14:21:05 --> Loader Class Initialized
INFO - 2023-05-01 14:21:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:05 --> Controller Class Initialized
INFO - 2023-05-01 14:21:05 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:21:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:21:05 --> Total execution time: 0.0392
INFO - 2023-05-01 14:21:05 --> Config Class Initialized
INFO - 2023-05-01 14:21:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:05 --> URI Class Initialized
INFO - 2023-05-01 14:21:05 --> Router Class Initialized
INFO - 2023-05-01 14:21:05 --> Output Class Initialized
INFO - 2023-05-01 14:21:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:05 --> Input Class Initialized
INFO - 2023-05-01 14:21:05 --> Language Class Initialized
INFO - 2023-05-01 14:21:05 --> Language Class Initialized
INFO - 2023-05-01 14:21:05 --> Config Class Initialized
INFO - 2023-05-01 14:21:05 --> Loader Class Initialized
INFO - 2023-05-01 14:21:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:05 --> Controller Class Initialized
DEBUG - 2023-05-01 14:21:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 14:21:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:21:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:21:05 --> Total execution time: 0.0468
INFO - 2023-05-01 14:21:07 --> Config Class Initialized
INFO - 2023-05-01 14:21:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:07 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:07 --> URI Class Initialized
INFO - 2023-05-01 14:21:07 --> Router Class Initialized
INFO - 2023-05-01 14:21:07 --> Output Class Initialized
INFO - 2023-05-01 14:21:07 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:07 --> Input Class Initialized
INFO - 2023-05-01 14:21:07 --> Language Class Initialized
INFO - 2023-05-01 14:21:07 --> Language Class Initialized
INFO - 2023-05-01 14:21:07 --> Config Class Initialized
INFO - 2023-05-01 14:21:07 --> Loader Class Initialized
INFO - 2023-05-01 14:21:07 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:07 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:07 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:07 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:07 --> Controller Class Initialized
DEBUG - 2023-05-01 14:21:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:21:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:21:07 --> Final output sent to browser
DEBUG - 2023-05-01 14:21:07 --> Total execution time: 0.0577
INFO - 2023-05-01 14:21:09 --> Config Class Initialized
INFO - 2023-05-01 14:21:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:09 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:09 --> URI Class Initialized
INFO - 2023-05-01 14:21:09 --> Router Class Initialized
INFO - 2023-05-01 14:21:09 --> Output Class Initialized
INFO - 2023-05-01 14:21:09 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:09 --> Input Class Initialized
INFO - 2023-05-01 14:21:09 --> Language Class Initialized
INFO - 2023-05-01 14:21:09 --> Language Class Initialized
INFO - 2023-05-01 14:21:09 --> Config Class Initialized
INFO - 2023-05-01 14:21:09 --> Loader Class Initialized
INFO - 2023-05-01 14:21:09 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:09 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:09 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:09 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:09 --> Controller Class Initialized
DEBUG - 2023-05-01 14:21:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:21:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:21:09 --> Final output sent to browser
DEBUG - 2023-05-01 14:21:09 --> Total execution time: 0.0593
INFO - 2023-05-01 14:21:09 --> Config Class Initialized
INFO - 2023-05-01 14:21:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:09 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:09 --> URI Class Initialized
INFO - 2023-05-01 14:21:09 --> Router Class Initialized
INFO - 2023-05-01 14:21:09 --> Output Class Initialized
INFO - 2023-05-01 14:21:09 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:09 --> Input Class Initialized
INFO - 2023-05-01 14:21:09 --> Language Class Initialized
INFO - 2023-05-01 14:21:09 --> Language Class Initialized
INFO - 2023-05-01 14:21:09 --> Config Class Initialized
INFO - 2023-05-01 14:21:09 --> Loader Class Initialized
INFO - 2023-05-01 14:21:09 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:09 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:09 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:09 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:09 --> Controller Class Initialized
INFO - 2023-05-01 14:21:14 --> Config Class Initialized
INFO - 2023-05-01 14:21:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:14 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:14 --> URI Class Initialized
INFO - 2023-05-01 14:21:14 --> Router Class Initialized
INFO - 2023-05-01 14:21:14 --> Output Class Initialized
INFO - 2023-05-01 14:21:14 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:14 --> Input Class Initialized
INFO - 2023-05-01 14:21:14 --> Language Class Initialized
INFO - 2023-05-01 14:21:14 --> Language Class Initialized
INFO - 2023-05-01 14:21:14 --> Config Class Initialized
INFO - 2023-05-01 14:21:14 --> Loader Class Initialized
INFO - 2023-05-01 14:21:14 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:14 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:14 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:14 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:14 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:14 --> Controller Class Initialized
INFO - 2023-05-01 14:21:25 --> Config Class Initialized
INFO - 2023-05-01 14:21:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:21:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:21:25 --> Utf8 Class Initialized
INFO - 2023-05-01 14:21:25 --> URI Class Initialized
INFO - 2023-05-01 14:21:25 --> Router Class Initialized
INFO - 2023-05-01 14:21:25 --> Output Class Initialized
INFO - 2023-05-01 14:21:25 --> Security Class Initialized
DEBUG - 2023-05-01 14:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:21:25 --> Input Class Initialized
INFO - 2023-05-01 14:21:25 --> Language Class Initialized
INFO - 2023-05-01 14:21:25 --> Language Class Initialized
INFO - 2023-05-01 14:21:25 --> Config Class Initialized
INFO - 2023-05-01 14:21:25 --> Loader Class Initialized
INFO - 2023-05-01 14:21:25 --> Helper loaded: url_helper
INFO - 2023-05-01 14:21:25 --> Helper loaded: file_helper
INFO - 2023-05-01 14:21:25 --> Helper loaded: form_helper
INFO - 2023-05-01 14:21:25 --> Helper loaded: my_helper
INFO - 2023-05-01 14:21:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:21:25 --> Controller Class Initialized
INFO - 2023-05-01 14:21:25 --> Final output sent to browser
DEBUG - 2023-05-01 14:21:25 --> Total execution time: 0.0591
INFO - 2023-05-01 14:22:06 --> Config Class Initialized
INFO - 2023-05-01 14:22:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:22:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:22:06 --> Utf8 Class Initialized
INFO - 2023-05-01 14:22:06 --> URI Class Initialized
INFO - 2023-05-01 14:22:06 --> Router Class Initialized
INFO - 2023-05-01 14:22:06 --> Output Class Initialized
INFO - 2023-05-01 14:22:06 --> Security Class Initialized
DEBUG - 2023-05-01 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:22:06 --> Input Class Initialized
INFO - 2023-05-01 14:22:06 --> Language Class Initialized
INFO - 2023-05-01 14:22:06 --> Language Class Initialized
INFO - 2023-05-01 14:22:06 --> Config Class Initialized
INFO - 2023-05-01 14:22:06 --> Loader Class Initialized
INFO - 2023-05-01 14:22:06 --> Helper loaded: url_helper
INFO - 2023-05-01 14:22:06 --> Helper loaded: file_helper
INFO - 2023-05-01 14:22:06 --> Helper loaded: form_helper
INFO - 2023-05-01 14:22:06 --> Helper loaded: my_helper
INFO - 2023-05-01 14:22:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:22:06 --> Controller Class Initialized
DEBUG - 2023-05-01 14:22:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:22:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:22:06 --> Final output sent to browser
DEBUG - 2023-05-01 14:22:06 --> Total execution time: 0.0432
INFO - 2023-05-01 14:22:06 --> Config Class Initialized
INFO - 2023-05-01 14:22:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:22:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:22:06 --> Utf8 Class Initialized
INFO - 2023-05-01 14:22:06 --> URI Class Initialized
INFO - 2023-05-01 14:22:06 --> Router Class Initialized
INFO - 2023-05-01 14:22:06 --> Output Class Initialized
INFO - 2023-05-01 14:22:06 --> Security Class Initialized
DEBUG - 2023-05-01 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:22:06 --> Input Class Initialized
INFO - 2023-05-01 14:22:06 --> Language Class Initialized
INFO - 2023-05-01 14:22:06 --> Language Class Initialized
INFO - 2023-05-01 14:22:06 --> Config Class Initialized
INFO - 2023-05-01 14:22:06 --> Loader Class Initialized
INFO - 2023-05-01 14:22:06 --> Helper loaded: url_helper
INFO - 2023-05-01 14:22:06 --> Helper loaded: file_helper
INFO - 2023-05-01 14:22:06 --> Helper loaded: form_helper
INFO - 2023-05-01 14:22:06 --> Helper loaded: my_helper
INFO - 2023-05-01 14:22:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:22:06 --> Controller Class Initialized
INFO - 2023-05-01 14:22:10 --> Config Class Initialized
INFO - 2023-05-01 14:22:10 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:22:10 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:22:10 --> Utf8 Class Initialized
INFO - 2023-05-01 14:22:10 --> URI Class Initialized
INFO - 2023-05-01 14:22:10 --> Router Class Initialized
INFO - 2023-05-01 14:22:10 --> Output Class Initialized
INFO - 2023-05-01 14:22:10 --> Security Class Initialized
DEBUG - 2023-05-01 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:22:10 --> Input Class Initialized
INFO - 2023-05-01 14:22:10 --> Language Class Initialized
INFO - 2023-05-01 14:22:10 --> Language Class Initialized
INFO - 2023-05-01 14:22:10 --> Config Class Initialized
INFO - 2023-05-01 14:22:10 --> Loader Class Initialized
INFO - 2023-05-01 14:22:10 --> Helper loaded: url_helper
INFO - 2023-05-01 14:22:10 --> Helper loaded: file_helper
INFO - 2023-05-01 14:22:10 --> Helper loaded: form_helper
INFO - 2023-05-01 14:22:10 --> Helper loaded: my_helper
INFO - 2023-05-01 14:22:10 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:22:10 --> Controller Class Initialized
INFO - 2023-05-01 14:22:10 --> Final output sent to browser
DEBUG - 2023-05-01 14:22:10 --> Total execution time: 0.0590
INFO - 2023-05-01 14:24:32 --> Config Class Initialized
INFO - 2023-05-01 14:24:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:24:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:24:32 --> Utf8 Class Initialized
INFO - 2023-05-01 14:24:32 --> URI Class Initialized
INFO - 2023-05-01 14:24:32 --> Router Class Initialized
INFO - 2023-05-01 14:24:32 --> Output Class Initialized
INFO - 2023-05-01 14:24:32 --> Security Class Initialized
DEBUG - 2023-05-01 14:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:24:32 --> Input Class Initialized
INFO - 2023-05-01 14:24:32 --> Language Class Initialized
INFO - 2023-05-01 14:24:32 --> Language Class Initialized
INFO - 2023-05-01 14:24:32 --> Config Class Initialized
INFO - 2023-05-01 14:24:32 --> Loader Class Initialized
INFO - 2023-05-01 14:24:32 --> Helper loaded: url_helper
INFO - 2023-05-01 14:24:32 --> Helper loaded: file_helper
INFO - 2023-05-01 14:24:32 --> Helper loaded: form_helper
INFO - 2023-05-01 14:24:32 --> Helper loaded: my_helper
INFO - 2023-05-01 14:24:32 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:24:32 --> Controller Class Initialized
INFO - 2023-05-01 14:24:32 --> Final output sent to browser
DEBUG - 2023-05-01 14:24:32 --> Total execution time: 0.0600
INFO - 2023-05-01 14:24:36 --> Config Class Initialized
INFO - 2023-05-01 14:24:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:24:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:24:36 --> Utf8 Class Initialized
INFO - 2023-05-01 14:24:36 --> URI Class Initialized
INFO - 2023-05-01 14:24:36 --> Router Class Initialized
INFO - 2023-05-01 14:24:36 --> Output Class Initialized
INFO - 2023-05-01 14:24:36 --> Security Class Initialized
DEBUG - 2023-05-01 14:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:24:36 --> Input Class Initialized
INFO - 2023-05-01 14:24:36 --> Language Class Initialized
INFO - 2023-05-01 14:24:36 --> Language Class Initialized
INFO - 2023-05-01 14:24:36 --> Config Class Initialized
INFO - 2023-05-01 14:24:36 --> Loader Class Initialized
INFO - 2023-05-01 14:24:36 --> Helper loaded: url_helper
INFO - 2023-05-01 14:24:36 --> Helper loaded: file_helper
INFO - 2023-05-01 14:24:36 --> Helper loaded: form_helper
INFO - 2023-05-01 14:24:36 --> Helper loaded: my_helper
INFO - 2023-05-01 14:24:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:24:36 --> Controller Class Initialized
DEBUG - 2023-05-01 14:24:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:24:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:24:36 --> Final output sent to browser
DEBUG - 2023-05-01 14:24:36 --> Total execution time: 0.0454
INFO - 2023-05-01 14:24:36 --> Config Class Initialized
INFO - 2023-05-01 14:24:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:24:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:24:36 --> Utf8 Class Initialized
INFO - 2023-05-01 14:24:36 --> URI Class Initialized
INFO - 2023-05-01 14:24:36 --> Router Class Initialized
INFO - 2023-05-01 14:24:36 --> Output Class Initialized
INFO - 2023-05-01 14:24:36 --> Security Class Initialized
DEBUG - 2023-05-01 14:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:24:36 --> Input Class Initialized
INFO - 2023-05-01 14:24:36 --> Language Class Initialized
INFO - 2023-05-01 14:24:36 --> Language Class Initialized
INFO - 2023-05-01 14:24:36 --> Config Class Initialized
INFO - 2023-05-01 14:24:36 --> Loader Class Initialized
INFO - 2023-05-01 14:24:36 --> Helper loaded: url_helper
INFO - 2023-05-01 14:24:36 --> Helper loaded: file_helper
INFO - 2023-05-01 14:24:36 --> Helper loaded: form_helper
INFO - 2023-05-01 14:24:36 --> Helper loaded: my_helper
INFO - 2023-05-01 14:24:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:24:36 --> Controller Class Initialized
INFO - 2023-05-01 14:24:38 --> Config Class Initialized
INFO - 2023-05-01 14:24:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:24:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:24:38 --> Utf8 Class Initialized
INFO - 2023-05-01 14:24:38 --> URI Class Initialized
INFO - 2023-05-01 14:24:38 --> Router Class Initialized
INFO - 2023-05-01 14:24:38 --> Output Class Initialized
INFO - 2023-05-01 14:24:38 --> Security Class Initialized
DEBUG - 2023-05-01 14:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:24:38 --> Input Class Initialized
INFO - 2023-05-01 14:24:38 --> Language Class Initialized
INFO - 2023-05-01 14:24:38 --> Language Class Initialized
INFO - 2023-05-01 14:24:38 --> Config Class Initialized
INFO - 2023-05-01 14:24:38 --> Loader Class Initialized
INFO - 2023-05-01 14:24:38 --> Helper loaded: url_helper
INFO - 2023-05-01 14:24:38 --> Helper loaded: file_helper
INFO - 2023-05-01 14:24:38 --> Helper loaded: form_helper
INFO - 2023-05-01 14:24:38 --> Helper loaded: my_helper
INFO - 2023-05-01 14:24:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:24:38 --> Controller Class Initialized
INFO - 2023-05-01 14:24:38 --> Final output sent to browser
DEBUG - 2023-05-01 14:24:38 --> Total execution time: 0.0588
INFO - 2023-05-01 14:24:52 --> Config Class Initialized
INFO - 2023-05-01 14:24:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:24:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:24:52 --> Utf8 Class Initialized
INFO - 2023-05-01 14:24:52 --> URI Class Initialized
INFO - 2023-05-01 14:24:52 --> Router Class Initialized
INFO - 2023-05-01 14:24:52 --> Output Class Initialized
INFO - 2023-05-01 14:24:52 --> Security Class Initialized
DEBUG - 2023-05-01 14:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:24:52 --> Input Class Initialized
INFO - 2023-05-01 14:24:52 --> Language Class Initialized
INFO - 2023-05-01 14:24:52 --> Language Class Initialized
INFO - 2023-05-01 14:24:52 --> Config Class Initialized
INFO - 2023-05-01 14:24:52 --> Loader Class Initialized
INFO - 2023-05-01 14:24:52 --> Helper loaded: url_helper
INFO - 2023-05-01 14:24:52 --> Helper loaded: file_helper
INFO - 2023-05-01 14:24:52 --> Helper loaded: form_helper
INFO - 2023-05-01 14:24:52 --> Helper loaded: my_helper
INFO - 2023-05-01 14:24:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:24:52 --> Controller Class Initialized
INFO - 2023-05-01 14:24:52 --> Final output sent to browser
DEBUG - 2023-05-01 14:24:52 --> Total execution time: 0.0611
INFO - 2023-05-01 14:25:16 --> Config Class Initialized
INFO - 2023-05-01 14:25:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:16 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:16 --> URI Class Initialized
INFO - 2023-05-01 14:25:16 --> Router Class Initialized
INFO - 2023-05-01 14:25:16 --> Output Class Initialized
INFO - 2023-05-01 14:25:16 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:16 --> Input Class Initialized
INFO - 2023-05-01 14:25:16 --> Language Class Initialized
INFO - 2023-05-01 14:25:16 --> Language Class Initialized
INFO - 2023-05-01 14:25:16 --> Config Class Initialized
INFO - 2023-05-01 14:25:16 --> Loader Class Initialized
INFO - 2023-05-01 14:25:16 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:16 --> Controller Class Initialized
INFO - 2023-05-01 14:25:16 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:25:16 --> Config Class Initialized
INFO - 2023-05-01 14:25:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:16 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:16 --> URI Class Initialized
INFO - 2023-05-01 14:25:16 --> Router Class Initialized
INFO - 2023-05-01 14:25:16 --> Output Class Initialized
INFO - 2023-05-01 14:25:16 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:16 --> Input Class Initialized
INFO - 2023-05-01 14:25:16 --> Language Class Initialized
INFO - 2023-05-01 14:25:16 --> Language Class Initialized
INFO - 2023-05-01 14:25:16 --> Config Class Initialized
INFO - 2023-05-01 14:25:16 --> Loader Class Initialized
INFO - 2023-05-01 14:25:16 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:16 --> Controller Class Initialized
INFO - 2023-05-01 14:25:16 --> Config Class Initialized
INFO - 2023-05-01 14:25:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:16 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:16 --> URI Class Initialized
INFO - 2023-05-01 14:25:16 --> Router Class Initialized
INFO - 2023-05-01 14:25:16 --> Output Class Initialized
INFO - 2023-05-01 14:25:16 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:16 --> Input Class Initialized
INFO - 2023-05-01 14:25:16 --> Language Class Initialized
INFO - 2023-05-01 14:25:16 --> Language Class Initialized
INFO - 2023-05-01 14:25:16 --> Config Class Initialized
INFO - 2023-05-01 14:25:16 --> Loader Class Initialized
INFO - 2023-05-01 14:25:16 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:16 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:16 --> Controller Class Initialized
DEBUG - 2023-05-01 14:25:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 14:25:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:25:16 --> Final output sent to browser
DEBUG - 2023-05-01 14:25:16 --> Total execution time: 0.0578
INFO - 2023-05-01 14:25:21 --> Config Class Initialized
INFO - 2023-05-01 14:25:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:21 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:21 --> URI Class Initialized
INFO - 2023-05-01 14:25:21 --> Router Class Initialized
INFO - 2023-05-01 14:25:21 --> Output Class Initialized
INFO - 2023-05-01 14:25:21 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:21 --> Input Class Initialized
INFO - 2023-05-01 14:25:21 --> Language Class Initialized
INFO - 2023-05-01 14:25:21 --> Language Class Initialized
INFO - 2023-05-01 14:25:21 --> Config Class Initialized
INFO - 2023-05-01 14:25:21 --> Loader Class Initialized
INFO - 2023-05-01 14:25:21 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:21 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:21 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:21 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:21 --> Controller Class Initialized
INFO - 2023-05-01 14:25:21 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:25:21 --> Final output sent to browser
DEBUG - 2023-05-01 14:25:21 --> Total execution time: 0.0641
INFO - 2023-05-01 14:25:21 --> Config Class Initialized
INFO - 2023-05-01 14:25:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:21 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:21 --> URI Class Initialized
INFO - 2023-05-01 14:25:21 --> Router Class Initialized
INFO - 2023-05-01 14:25:21 --> Output Class Initialized
INFO - 2023-05-01 14:25:21 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:21 --> Input Class Initialized
INFO - 2023-05-01 14:25:21 --> Language Class Initialized
INFO - 2023-05-01 14:25:21 --> Language Class Initialized
INFO - 2023-05-01 14:25:21 --> Config Class Initialized
INFO - 2023-05-01 14:25:21 --> Loader Class Initialized
INFO - 2023-05-01 14:25:21 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:21 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:21 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:21 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:21 --> Controller Class Initialized
DEBUG - 2023-05-01 14:25:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 14:25:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:25:21 --> Final output sent to browser
DEBUG - 2023-05-01 14:25:21 --> Total execution time: 0.0649
INFO - 2023-05-01 14:25:25 --> Config Class Initialized
INFO - 2023-05-01 14:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:25 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:25 --> URI Class Initialized
INFO - 2023-05-01 14:25:25 --> Router Class Initialized
INFO - 2023-05-01 14:25:25 --> Output Class Initialized
INFO - 2023-05-01 14:25:25 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:25 --> Input Class Initialized
INFO - 2023-05-01 14:25:25 --> Language Class Initialized
INFO - 2023-05-01 14:25:25 --> Language Class Initialized
INFO - 2023-05-01 14:25:25 --> Config Class Initialized
INFO - 2023-05-01 14:25:25 --> Loader Class Initialized
INFO - 2023-05-01 14:25:25 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:25 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:25 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:25 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:25 --> Controller Class Initialized
DEBUG - 2023-05-01 14:25:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-05-01 14:25:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:25:25 --> Final output sent to browser
DEBUG - 2023-05-01 14:25:25 --> Total execution time: 0.1011
INFO - 2023-05-01 14:25:29 --> Config Class Initialized
INFO - 2023-05-01 14:25:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:29 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:29 --> URI Class Initialized
INFO - 2023-05-01 14:25:29 --> Router Class Initialized
INFO - 2023-05-01 14:25:29 --> Output Class Initialized
INFO - 2023-05-01 14:25:29 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:29 --> Input Class Initialized
INFO - 2023-05-01 14:25:29 --> Language Class Initialized
INFO - 2023-05-01 14:25:29 --> Language Class Initialized
INFO - 2023-05-01 14:25:29 --> Config Class Initialized
INFO - 2023-05-01 14:25:29 --> Loader Class Initialized
INFO - 2023-05-01 14:25:29 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:29 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:29 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:29 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:29 --> Controller Class Initialized
DEBUG - 2023-05-01 14:25:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-05-01 14:25:31 --> Final output sent to browser
DEBUG - 2023-05-01 14:25:31 --> Total execution time: 2.4817
INFO - 2023-05-01 14:25:41 --> Config Class Initialized
INFO - 2023-05-01 14:25:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:25:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:25:41 --> Utf8 Class Initialized
INFO - 2023-05-01 14:25:41 --> URI Class Initialized
INFO - 2023-05-01 14:25:41 --> Router Class Initialized
INFO - 2023-05-01 14:25:41 --> Output Class Initialized
INFO - 2023-05-01 14:25:41 --> Security Class Initialized
DEBUG - 2023-05-01 14:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:25:41 --> Input Class Initialized
INFO - 2023-05-01 14:25:41 --> Language Class Initialized
INFO - 2023-05-01 14:25:41 --> Language Class Initialized
INFO - 2023-05-01 14:25:41 --> Config Class Initialized
INFO - 2023-05-01 14:25:41 --> Loader Class Initialized
INFO - 2023-05-01 14:25:41 --> Helper loaded: url_helper
INFO - 2023-05-01 14:25:41 --> Helper loaded: file_helper
INFO - 2023-05-01 14:25:41 --> Helper loaded: form_helper
INFO - 2023-05-01 14:25:41 --> Helper loaded: my_helper
INFO - 2023-05-01 14:25:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:25:41 --> Controller Class Initialized
DEBUG - 2023-05-01 14:25:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-05-01 14:25:42 --> Final output sent to browser
DEBUG - 2023-05-01 14:25:42 --> Total execution time: 1.4785
INFO - 2023-05-01 14:26:00 --> Config Class Initialized
INFO - 2023-05-01 14:26:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:00 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:00 --> URI Class Initialized
INFO - 2023-05-01 14:26:00 --> Router Class Initialized
INFO - 2023-05-01 14:26:00 --> Output Class Initialized
INFO - 2023-05-01 14:26:00 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:00 --> Input Class Initialized
INFO - 2023-05-01 14:26:00 --> Language Class Initialized
INFO - 2023-05-01 14:26:00 --> Language Class Initialized
INFO - 2023-05-01 14:26:00 --> Config Class Initialized
INFO - 2023-05-01 14:26:00 --> Loader Class Initialized
INFO - 2023-05-01 14:26:00 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:00 --> Controller Class Initialized
INFO - 2023-05-01 14:26:00 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:26:00 --> Config Class Initialized
INFO - 2023-05-01 14:26:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:00 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:00 --> URI Class Initialized
INFO - 2023-05-01 14:26:00 --> Router Class Initialized
INFO - 2023-05-01 14:26:00 --> Output Class Initialized
INFO - 2023-05-01 14:26:00 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:00 --> Input Class Initialized
INFO - 2023-05-01 14:26:00 --> Language Class Initialized
INFO - 2023-05-01 14:26:00 --> Language Class Initialized
INFO - 2023-05-01 14:26:00 --> Config Class Initialized
INFO - 2023-05-01 14:26:00 --> Loader Class Initialized
INFO - 2023-05-01 14:26:00 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:00 --> Controller Class Initialized
INFO - 2023-05-01 14:26:00 --> Config Class Initialized
INFO - 2023-05-01 14:26:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:00 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:00 --> URI Class Initialized
INFO - 2023-05-01 14:26:00 --> Router Class Initialized
INFO - 2023-05-01 14:26:00 --> Output Class Initialized
INFO - 2023-05-01 14:26:00 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:00 --> Input Class Initialized
INFO - 2023-05-01 14:26:00 --> Language Class Initialized
INFO - 2023-05-01 14:26:00 --> Language Class Initialized
INFO - 2023-05-01 14:26:00 --> Config Class Initialized
INFO - 2023-05-01 14:26:00 --> Loader Class Initialized
INFO - 2023-05-01 14:26:00 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:00 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:00 --> Controller Class Initialized
DEBUG - 2023-05-01 14:26:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 14:26:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:26:00 --> Final output sent to browser
DEBUG - 2023-05-01 14:26:00 --> Total execution time: 0.0563
INFO - 2023-05-01 14:26:07 --> Config Class Initialized
INFO - 2023-05-01 14:26:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:07 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:07 --> URI Class Initialized
INFO - 2023-05-01 14:26:07 --> Router Class Initialized
INFO - 2023-05-01 14:26:07 --> Output Class Initialized
INFO - 2023-05-01 14:26:07 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:07 --> Input Class Initialized
INFO - 2023-05-01 14:26:07 --> Language Class Initialized
INFO - 2023-05-01 14:26:07 --> Language Class Initialized
INFO - 2023-05-01 14:26:07 --> Config Class Initialized
INFO - 2023-05-01 14:26:07 --> Loader Class Initialized
INFO - 2023-05-01 14:26:07 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:07 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:07 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:07 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:08 --> Controller Class Initialized
INFO - 2023-05-01 14:26:08 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:26:08 --> Final output sent to browser
DEBUG - 2023-05-01 14:26:08 --> Total execution time: 0.0656
INFO - 2023-05-01 14:26:08 --> Config Class Initialized
INFO - 2023-05-01 14:26:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:08 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:08 --> URI Class Initialized
INFO - 2023-05-01 14:26:08 --> Router Class Initialized
INFO - 2023-05-01 14:26:08 --> Output Class Initialized
INFO - 2023-05-01 14:26:08 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:08 --> Input Class Initialized
INFO - 2023-05-01 14:26:08 --> Language Class Initialized
INFO - 2023-05-01 14:26:08 --> Language Class Initialized
INFO - 2023-05-01 14:26:08 --> Config Class Initialized
INFO - 2023-05-01 14:26:08 --> Loader Class Initialized
INFO - 2023-05-01 14:26:08 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:08 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:08 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:08 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:08 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:08 --> Controller Class Initialized
DEBUG - 2023-05-01 14:26:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 14:26:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:26:08 --> Final output sent to browser
DEBUG - 2023-05-01 14:26:08 --> Total execution time: 0.0503
INFO - 2023-05-01 14:26:09 --> Config Class Initialized
INFO - 2023-05-01 14:26:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:09 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:09 --> URI Class Initialized
INFO - 2023-05-01 14:26:09 --> Router Class Initialized
INFO - 2023-05-01 14:26:09 --> Output Class Initialized
INFO - 2023-05-01 14:26:09 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:09 --> Input Class Initialized
INFO - 2023-05-01 14:26:09 --> Language Class Initialized
INFO - 2023-05-01 14:26:09 --> Language Class Initialized
INFO - 2023-05-01 14:26:09 --> Config Class Initialized
INFO - 2023-05-01 14:26:09 --> Loader Class Initialized
INFO - 2023-05-01 14:26:09 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:09 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:09 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:09 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:09 --> Controller Class Initialized
DEBUG - 2023-05-01 14:26:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:26:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:26:09 --> Final output sent to browser
DEBUG - 2023-05-01 14:26:09 --> Total execution time: 0.0571
INFO - 2023-05-01 14:26:12 --> Config Class Initialized
INFO - 2023-05-01 14:26:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:12 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:12 --> URI Class Initialized
INFO - 2023-05-01 14:26:12 --> Router Class Initialized
INFO - 2023-05-01 14:26:12 --> Output Class Initialized
INFO - 2023-05-01 14:26:12 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:12 --> Input Class Initialized
INFO - 2023-05-01 14:26:12 --> Language Class Initialized
INFO - 2023-05-01 14:26:12 --> Language Class Initialized
INFO - 2023-05-01 14:26:12 --> Config Class Initialized
INFO - 2023-05-01 14:26:12 --> Loader Class Initialized
INFO - 2023-05-01 14:26:12 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:12 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:12 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:12 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:12 --> Controller Class Initialized
DEBUG - 2023-05-01 14:26:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:26:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:26:12 --> Final output sent to browser
DEBUG - 2023-05-01 14:26:12 --> Total execution time: 0.0585
INFO - 2023-05-01 14:26:12 --> Config Class Initialized
INFO - 2023-05-01 14:26:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:12 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:12 --> URI Class Initialized
INFO - 2023-05-01 14:26:12 --> Router Class Initialized
INFO - 2023-05-01 14:26:12 --> Output Class Initialized
INFO - 2023-05-01 14:26:12 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:12 --> Input Class Initialized
INFO - 2023-05-01 14:26:12 --> Language Class Initialized
INFO - 2023-05-01 14:26:12 --> Language Class Initialized
INFO - 2023-05-01 14:26:12 --> Config Class Initialized
INFO - 2023-05-01 14:26:12 --> Loader Class Initialized
INFO - 2023-05-01 14:26:12 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:12 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:12 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:12 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:12 --> Controller Class Initialized
INFO - 2023-05-01 14:26:14 --> Config Class Initialized
INFO - 2023-05-01 14:26:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:14 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:14 --> URI Class Initialized
INFO - 2023-05-01 14:26:14 --> Router Class Initialized
INFO - 2023-05-01 14:26:14 --> Output Class Initialized
INFO - 2023-05-01 14:26:14 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:14 --> Input Class Initialized
INFO - 2023-05-01 14:26:14 --> Language Class Initialized
INFO - 2023-05-01 14:26:14 --> Language Class Initialized
INFO - 2023-05-01 14:26:14 --> Config Class Initialized
INFO - 2023-05-01 14:26:14 --> Loader Class Initialized
INFO - 2023-05-01 14:26:14 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:14 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:14 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:14 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:14 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:14 --> Controller Class Initialized
INFO - 2023-05-01 14:26:14 --> Final output sent to browser
DEBUG - 2023-05-01 14:26:14 --> Total execution time: 0.0373
INFO - 2023-05-01 14:26:24 --> Config Class Initialized
INFO - 2023-05-01 14:26:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:26:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:26:24 --> Utf8 Class Initialized
INFO - 2023-05-01 14:26:24 --> URI Class Initialized
INFO - 2023-05-01 14:26:24 --> Router Class Initialized
INFO - 2023-05-01 14:26:24 --> Output Class Initialized
INFO - 2023-05-01 14:26:24 --> Security Class Initialized
DEBUG - 2023-05-01 14:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:26:24 --> Input Class Initialized
INFO - 2023-05-01 14:26:24 --> Language Class Initialized
INFO - 2023-05-01 14:26:24 --> Language Class Initialized
INFO - 2023-05-01 14:26:24 --> Config Class Initialized
INFO - 2023-05-01 14:26:24 --> Loader Class Initialized
INFO - 2023-05-01 14:26:24 --> Helper loaded: url_helper
INFO - 2023-05-01 14:26:24 --> Helper loaded: file_helper
INFO - 2023-05-01 14:26:24 --> Helper loaded: form_helper
INFO - 2023-05-01 14:26:24 --> Helper loaded: my_helper
INFO - 2023-05-01 14:26:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:26:24 --> Controller Class Initialized
INFO - 2023-05-01 14:29:06 --> Config Class Initialized
INFO - 2023-05-01 14:29:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:06 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:06 --> URI Class Initialized
INFO - 2023-05-01 14:29:06 --> Router Class Initialized
INFO - 2023-05-01 14:29:06 --> Output Class Initialized
INFO - 2023-05-01 14:29:06 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:06 --> Input Class Initialized
INFO - 2023-05-01 14:29:06 --> Language Class Initialized
INFO - 2023-05-01 14:29:06 --> Language Class Initialized
INFO - 2023-05-01 14:29:06 --> Config Class Initialized
INFO - 2023-05-01 14:29:06 --> Loader Class Initialized
INFO - 2023-05-01 14:29:06 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:06 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:06 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:06 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:06 --> Controller Class Initialized
DEBUG - 2023-05-01 14:29:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 14:29:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:29:06 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:06 --> Total execution time: 0.0733
INFO - 2023-05-01 14:29:33 --> Config Class Initialized
INFO - 2023-05-01 14:29:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:33 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:33 --> URI Class Initialized
INFO - 2023-05-01 14:29:33 --> Router Class Initialized
INFO - 2023-05-01 14:29:33 --> Output Class Initialized
INFO - 2023-05-01 14:29:33 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:33 --> Input Class Initialized
INFO - 2023-05-01 14:29:33 --> Language Class Initialized
INFO - 2023-05-01 14:29:33 --> Language Class Initialized
INFO - 2023-05-01 14:29:33 --> Config Class Initialized
INFO - 2023-05-01 14:29:33 --> Loader Class Initialized
INFO - 2023-05-01 14:29:33 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:33 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:33 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:33 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:33 --> Controller Class Initialized
INFO - 2023-05-01 14:29:33 --> Config Class Initialized
INFO - 2023-05-01 14:29:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:33 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:33 --> URI Class Initialized
INFO - 2023-05-01 14:29:33 --> Router Class Initialized
INFO - 2023-05-01 14:29:33 --> Output Class Initialized
INFO - 2023-05-01 14:29:33 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:33 --> Input Class Initialized
INFO - 2023-05-01 14:29:33 --> Language Class Initialized
INFO - 2023-05-01 14:29:33 --> Language Class Initialized
INFO - 2023-05-01 14:29:33 --> Config Class Initialized
INFO - 2023-05-01 14:29:33 --> Loader Class Initialized
INFO - 2023-05-01 14:29:33 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:33 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:33 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:33 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:34 --> Controller Class Initialized
DEBUG - 2023-05-01 14:29:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 14:29:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:29:34 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:34 --> Total execution time: 0.0627
INFO - 2023-05-01 14:29:34 --> Config Class Initialized
INFO - 2023-05-01 14:29:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:34 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:34 --> URI Class Initialized
INFO - 2023-05-01 14:29:34 --> Router Class Initialized
INFO - 2023-05-01 14:29:34 --> Output Class Initialized
INFO - 2023-05-01 14:29:34 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:34 --> Input Class Initialized
INFO - 2023-05-01 14:29:34 --> Language Class Initialized
INFO - 2023-05-01 14:29:34 --> Language Class Initialized
INFO - 2023-05-01 14:29:34 --> Config Class Initialized
INFO - 2023-05-01 14:29:34 --> Loader Class Initialized
INFO - 2023-05-01 14:29:34 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:34 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:34 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:34 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:34 --> Controller Class Initialized
INFO - 2023-05-01 14:29:36 --> Config Class Initialized
INFO - 2023-05-01 14:29:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:36 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:36 --> URI Class Initialized
INFO - 2023-05-01 14:29:36 --> Router Class Initialized
INFO - 2023-05-01 14:29:36 --> Output Class Initialized
INFO - 2023-05-01 14:29:36 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:36 --> Input Class Initialized
INFO - 2023-05-01 14:29:36 --> Language Class Initialized
INFO - 2023-05-01 14:29:36 --> Language Class Initialized
INFO - 2023-05-01 14:29:36 --> Config Class Initialized
INFO - 2023-05-01 14:29:36 --> Loader Class Initialized
INFO - 2023-05-01 14:29:36 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:36 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:36 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:36 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:36 --> Controller Class Initialized
INFO - 2023-05-01 14:29:36 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:36 --> Total execution time: 0.0599
INFO - 2023-05-01 14:29:40 --> Config Class Initialized
INFO - 2023-05-01 14:29:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:40 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:40 --> URI Class Initialized
INFO - 2023-05-01 14:29:40 --> Router Class Initialized
INFO - 2023-05-01 14:29:40 --> Output Class Initialized
INFO - 2023-05-01 14:29:40 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:40 --> Input Class Initialized
INFO - 2023-05-01 14:29:40 --> Language Class Initialized
INFO - 2023-05-01 14:29:40 --> Language Class Initialized
INFO - 2023-05-01 14:29:40 --> Config Class Initialized
INFO - 2023-05-01 14:29:40 --> Loader Class Initialized
INFO - 2023-05-01 14:29:40 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:40 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:40 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:40 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:40 --> Controller Class Initialized
INFO - 2023-05-01 14:29:40 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:40 --> Total execution time: 0.0379
INFO - 2023-05-01 14:29:44 --> Config Class Initialized
INFO - 2023-05-01 14:29:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:44 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:44 --> URI Class Initialized
INFO - 2023-05-01 14:29:44 --> Router Class Initialized
INFO - 2023-05-01 14:29:44 --> Output Class Initialized
INFO - 2023-05-01 14:29:44 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:44 --> Input Class Initialized
INFO - 2023-05-01 14:29:44 --> Language Class Initialized
INFO - 2023-05-01 14:29:44 --> Language Class Initialized
INFO - 2023-05-01 14:29:44 --> Config Class Initialized
INFO - 2023-05-01 14:29:44 --> Loader Class Initialized
INFO - 2023-05-01 14:29:44 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:44 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:44 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:44 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:44 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:44 --> Controller Class Initialized
DEBUG - 2023-05-01 14:29:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:29:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:29:44 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:44 --> Total execution time: 0.0585
INFO - 2023-05-01 14:29:46 --> Config Class Initialized
INFO - 2023-05-01 14:29:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:46 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:46 --> URI Class Initialized
INFO - 2023-05-01 14:29:46 --> Router Class Initialized
INFO - 2023-05-01 14:29:46 --> Output Class Initialized
INFO - 2023-05-01 14:29:46 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:46 --> Input Class Initialized
INFO - 2023-05-01 14:29:46 --> Language Class Initialized
INFO - 2023-05-01 14:29:46 --> Language Class Initialized
INFO - 2023-05-01 14:29:46 --> Config Class Initialized
INFO - 2023-05-01 14:29:46 --> Loader Class Initialized
INFO - 2023-05-01 14:29:46 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:46 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:46 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:46 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:46 --> Controller Class Initialized
DEBUG - 2023-05-01 14:29:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:29:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:29:46 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:46 --> Total execution time: 0.0601
INFO - 2023-05-01 14:29:46 --> Config Class Initialized
INFO - 2023-05-01 14:29:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:46 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:46 --> URI Class Initialized
INFO - 2023-05-01 14:29:46 --> Router Class Initialized
INFO - 2023-05-01 14:29:46 --> Output Class Initialized
INFO - 2023-05-01 14:29:46 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:46 --> Input Class Initialized
INFO - 2023-05-01 14:29:46 --> Language Class Initialized
INFO - 2023-05-01 14:29:46 --> Language Class Initialized
INFO - 2023-05-01 14:29:46 --> Config Class Initialized
INFO - 2023-05-01 14:29:46 --> Loader Class Initialized
INFO - 2023-05-01 14:29:46 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:46 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:46 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:46 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:46 --> Controller Class Initialized
INFO - 2023-05-01 14:29:47 --> Config Class Initialized
INFO - 2023-05-01 14:29:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:47 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:47 --> URI Class Initialized
INFO - 2023-05-01 14:29:47 --> Router Class Initialized
INFO - 2023-05-01 14:29:47 --> Output Class Initialized
INFO - 2023-05-01 14:29:47 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:47 --> Input Class Initialized
INFO - 2023-05-01 14:29:47 --> Language Class Initialized
INFO - 2023-05-01 14:29:47 --> Language Class Initialized
INFO - 2023-05-01 14:29:47 --> Config Class Initialized
INFO - 2023-05-01 14:29:47 --> Loader Class Initialized
INFO - 2023-05-01 14:29:47 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:47 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:47 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:47 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:47 --> Controller Class Initialized
INFO - 2023-05-01 14:29:47 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:47 --> Total execution time: 0.0359
INFO - 2023-05-01 14:29:50 --> Config Class Initialized
INFO - 2023-05-01 14:29:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:50 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:50 --> URI Class Initialized
INFO - 2023-05-01 14:29:50 --> Router Class Initialized
INFO - 2023-05-01 14:29:50 --> Output Class Initialized
INFO - 2023-05-01 14:29:50 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:50 --> Input Class Initialized
INFO - 2023-05-01 14:29:50 --> Language Class Initialized
INFO - 2023-05-01 14:29:50 --> Language Class Initialized
INFO - 2023-05-01 14:29:50 --> Config Class Initialized
INFO - 2023-05-01 14:29:50 --> Loader Class Initialized
INFO - 2023-05-01 14:29:50 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:50 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:50 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:50 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:50 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:50 --> Controller Class Initialized
INFO - 2023-05-01 14:29:50 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:50 --> Total execution time: 0.0609
INFO - 2023-05-01 14:29:51 --> Config Class Initialized
INFO - 2023-05-01 14:29:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:51 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:51 --> URI Class Initialized
INFO - 2023-05-01 14:29:51 --> Router Class Initialized
INFO - 2023-05-01 14:29:51 --> Output Class Initialized
INFO - 2023-05-01 14:29:51 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:51 --> Input Class Initialized
INFO - 2023-05-01 14:29:51 --> Language Class Initialized
INFO - 2023-05-01 14:29:51 --> Language Class Initialized
INFO - 2023-05-01 14:29:51 --> Config Class Initialized
INFO - 2023-05-01 14:29:51 --> Loader Class Initialized
INFO - 2023-05-01 14:29:51 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:51 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:51 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:51 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:51 --> Controller Class Initialized
INFO - 2023-05-01 14:29:51 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:51 --> Total execution time: 0.0607
INFO - 2023-05-01 14:29:54 --> Config Class Initialized
INFO - 2023-05-01 14:29:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:29:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:29:54 --> Utf8 Class Initialized
INFO - 2023-05-01 14:29:54 --> URI Class Initialized
INFO - 2023-05-01 14:29:54 --> Router Class Initialized
INFO - 2023-05-01 14:29:54 --> Output Class Initialized
INFO - 2023-05-01 14:29:54 --> Security Class Initialized
DEBUG - 2023-05-01 14:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:29:54 --> Input Class Initialized
INFO - 2023-05-01 14:29:54 --> Language Class Initialized
INFO - 2023-05-01 14:29:54 --> Language Class Initialized
INFO - 2023-05-01 14:29:54 --> Config Class Initialized
INFO - 2023-05-01 14:29:54 --> Loader Class Initialized
INFO - 2023-05-01 14:29:54 --> Helper loaded: url_helper
INFO - 2023-05-01 14:29:54 --> Helper loaded: file_helper
INFO - 2023-05-01 14:29:54 --> Helper loaded: form_helper
INFO - 2023-05-01 14:29:54 --> Helper loaded: my_helper
INFO - 2023-05-01 14:29:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:29:54 --> Controller Class Initialized
INFO - 2023-05-01 14:29:54 --> Final output sent to browser
DEBUG - 2023-05-01 14:29:54 --> Total execution time: 0.0606
INFO - 2023-05-01 14:31:43 --> Config Class Initialized
INFO - 2023-05-01 14:31:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:31:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:31:43 --> Utf8 Class Initialized
INFO - 2023-05-01 14:31:43 --> URI Class Initialized
INFO - 2023-05-01 14:31:43 --> Router Class Initialized
INFO - 2023-05-01 14:31:43 --> Output Class Initialized
INFO - 2023-05-01 14:31:43 --> Security Class Initialized
DEBUG - 2023-05-01 14:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:31:43 --> Input Class Initialized
INFO - 2023-05-01 14:31:43 --> Language Class Initialized
INFO - 2023-05-01 14:31:43 --> Language Class Initialized
INFO - 2023-05-01 14:31:43 --> Config Class Initialized
INFO - 2023-05-01 14:31:43 --> Loader Class Initialized
INFO - 2023-05-01 14:31:43 --> Helper loaded: url_helper
INFO - 2023-05-01 14:31:43 --> Helper loaded: file_helper
INFO - 2023-05-01 14:31:43 --> Helper loaded: form_helper
INFO - 2023-05-01 14:31:43 --> Helper loaded: my_helper
INFO - 2023-05-01 14:31:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:31:43 --> Controller Class Initialized
INFO - 2023-05-01 14:31:43 --> Final output sent to browser
DEBUG - 2023-05-01 14:31:43 --> Total execution time: 0.0595
INFO - 2023-05-01 14:31:45 --> Config Class Initialized
INFO - 2023-05-01 14:31:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:31:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:31:45 --> Utf8 Class Initialized
INFO - 2023-05-01 14:31:45 --> URI Class Initialized
INFO - 2023-05-01 14:31:45 --> Router Class Initialized
INFO - 2023-05-01 14:31:45 --> Output Class Initialized
INFO - 2023-05-01 14:31:45 --> Security Class Initialized
DEBUG - 2023-05-01 14:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:31:45 --> Input Class Initialized
INFO - 2023-05-01 14:31:45 --> Language Class Initialized
INFO - 2023-05-01 14:31:45 --> Language Class Initialized
INFO - 2023-05-01 14:31:45 --> Config Class Initialized
INFO - 2023-05-01 14:31:45 --> Loader Class Initialized
INFO - 2023-05-01 14:31:45 --> Helper loaded: url_helper
INFO - 2023-05-01 14:31:45 --> Helper loaded: file_helper
INFO - 2023-05-01 14:31:45 --> Helper loaded: form_helper
INFO - 2023-05-01 14:31:45 --> Helper loaded: my_helper
INFO - 2023-05-01 14:31:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:31:45 --> Controller Class Initialized
INFO - 2023-05-01 14:31:45 --> Final output sent to browser
DEBUG - 2023-05-01 14:31:45 --> Total execution time: 0.0602
INFO - 2023-05-01 14:31:47 --> Config Class Initialized
INFO - 2023-05-01 14:31:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:31:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:31:47 --> Utf8 Class Initialized
INFO - 2023-05-01 14:31:47 --> URI Class Initialized
INFO - 2023-05-01 14:31:47 --> Router Class Initialized
INFO - 2023-05-01 14:31:47 --> Output Class Initialized
INFO - 2023-05-01 14:31:47 --> Security Class Initialized
DEBUG - 2023-05-01 14:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:31:47 --> Input Class Initialized
INFO - 2023-05-01 14:31:47 --> Language Class Initialized
INFO - 2023-05-01 14:31:47 --> Language Class Initialized
INFO - 2023-05-01 14:31:47 --> Config Class Initialized
INFO - 2023-05-01 14:31:47 --> Loader Class Initialized
INFO - 2023-05-01 14:31:47 --> Helper loaded: url_helper
INFO - 2023-05-01 14:31:47 --> Helper loaded: file_helper
INFO - 2023-05-01 14:31:47 --> Helper loaded: form_helper
INFO - 2023-05-01 14:31:47 --> Helper loaded: my_helper
INFO - 2023-05-01 14:31:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:31:47 --> Controller Class Initialized
INFO - 2023-05-01 14:31:47 --> Final output sent to browser
DEBUG - 2023-05-01 14:31:47 --> Total execution time: 0.0374
INFO - 2023-05-01 14:32:03 --> Config Class Initialized
INFO - 2023-05-01 14:32:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:32:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:32:03 --> Utf8 Class Initialized
INFO - 2023-05-01 14:32:03 --> URI Class Initialized
INFO - 2023-05-01 14:32:03 --> Router Class Initialized
INFO - 2023-05-01 14:32:03 --> Output Class Initialized
INFO - 2023-05-01 14:32:03 --> Security Class Initialized
DEBUG - 2023-05-01 14:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:32:03 --> Input Class Initialized
INFO - 2023-05-01 14:32:03 --> Language Class Initialized
INFO - 2023-05-01 14:32:03 --> Language Class Initialized
INFO - 2023-05-01 14:32:03 --> Config Class Initialized
INFO - 2023-05-01 14:32:03 --> Loader Class Initialized
INFO - 2023-05-01 14:32:03 --> Helper loaded: url_helper
INFO - 2023-05-01 14:32:03 --> Helper loaded: file_helper
INFO - 2023-05-01 14:32:03 --> Helper loaded: form_helper
INFO - 2023-05-01 14:32:03 --> Helper loaded: my_helper
INFO - 2023-05-01 14:32:03 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:32:03 --> Controller Class Initialized
DEBUG - 2023-05-01 14:32:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 14:32:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:32:03 --> Final output sent to browser
DEBUG - 2023-05-01 14:32:03 --> Total execution time: 0.0463
INFO - 2023-05-01 14:32:08 --> Config Class Initialized
INFO - 2023-05-01 14:32:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:32:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:32:08 --> Utf8 Class Initialized
INFO - 2023-05-01 14:32:08 --> URI Class Initialized
INFO - 2023-05-01 14:32:08 --> Router Class Initialized
INFO - 2023-05-01 14:32:08 --> Output Class Initialized
INFO - 2023-05-01 14:32:08 --> Security Class Initialized
DEBUG - 2023-05-01 14:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:32:08 --> Input Class Initialized
INFO - 2023-05-01 14:32:08 --> Language Class Initialized
ERROR - 2023-05-01 14:32:08 --> 404 Page Not Found: /index
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:29 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:29 --> URI Class Initialized
INFO - 2023-05-01 14:33:29 --> Router Class Initialized
INFO - 2023-05-01 14:33:29 --> Output Class Initialized
INFO - 2023-05-01 14:33:29 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:29 --> Input Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Loader Class Initialized
INFO - 2023-05-01 14:33:29 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:29 --> Controller Class Initialized
INFO - 2023-05-01 14:33:29 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:29 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:29 --> URI Class Initialized
INFO - 2023-05-01 14:33:29 --> Router Class Initialized
INFO - 2023-05-01 14:33:29 --> Output Class Initialized
INFO - 2023-05-01 14:33:29 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:29 --> Input Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Loader Class Initialized
INFO - 2023-05-01 14:33:29 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:29 --> Controller Class Initialized
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:29 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:29 --> URI Class Initialized
INFO - 2023-05-01 14:33:29 --> Router Class Initialized
INFO - 2023-05-01 14:33:29 --> Output Class Initialized
INFO - 2023-05-01 14:33:29 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:29 --> Input Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Loader Class Initialized
INFO - 2023-05-01 14:33:29 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:29 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:29 --> Controller Class Initialized
DEBUG - 2023-05-01 14:33:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 14:33:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:33:29 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:29 --> Total execution time: 0.0587
INFO - 2023-05-01 14:33:29 --> Config Class Initialized
INFO - 2023-05-01 14:33:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:29 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:29 --> URI Class Initialized
INFO - 2023-05-01 14:33:29 --> Router Class Initialized
INFO - 2023-05-01 14:33:29 --> Output Class Initialized
INFO - 2023-05-01 14:33:29 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:29 --> Input Class Initialized
INFO - 2023-05-01 14:33:29 --> Language Class Initialized
ERROR - 2023-05-01 14:33:29 --> 404 Page Not Found: /index
INFO - 2023-05-01 14:33:33 --> Config Class Initialized
INFO - 2023-05-01 14:33:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:33 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:33 --> URI Class Initialized
INFO - 2023-05-01 14:33:33 --> Router Class Initialized
INFO - 2023-05-01 14:33:33 --> Output Class Initialized
INFO - 2023-05-01 14:33:33 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:33 --> Input Class Initialized
INFO - 2023-05-01 14:33:33 --> Language Class Initialized
INFO - 2023-05-01 14:33:33 --> Language Class Initialized
INFO - 2023-05-01 14:33:33 --> Config Class Initialized
INFO - 2023-05-01 14:33:33 --> Loader Class Initialized
INFO - 2023-05-01 14:33:33 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:33 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:33 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:33 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:33 --> Controller Class Initialized
INFO - 2023-05-01 14:33:33 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:33:33 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:33 --> Total execution time: 0.0462
INFO - 2023-05-01 14:33:33 --> Config Class Initialized
INFO - 2023-05-01 14:33:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:33 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:33 --> URI Class Initialized
INFO - 2023-05-01 14:33:33 --> Router Class Initialized
INFO - 2023-05-01 14:33:33 --> Output Class Initialized
INFO - 2023-05-01 14:33:33 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:33 --> Input Class Initialized
INFO - 2023-05-01 14:33:33 --> Language Class Initialized
INFO - 2023-05-01 14:33:33 --> Language Class Initialized
INFO - 2023-05-01 14:33:33 --> Config Class Initialized
INFO - 2023-05-01 14:33:33 --> Loader Class Initialized
INFO - 2023-05-01 14:33:33 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:33 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:33 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:33 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:33 --> Controller Class Initialized
DEBUG - 2023-05-01 14:33:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 14:33:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:33:33 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:33 --> Total execution time: 0.0627
INFO - 2023-05-01 14:33:33 --> Config Class Initialized
INFO - 2023-05-01 14:33:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:33 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:33 --> URI Class Initialized
INFO - 2023-05-01 14:33:33 --> Router Class Initialized
INFO - 2023-05-01 14:33:33 --> Output Class Initialized
INFO - 2023-05-01 14:33:33 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:33 --> Input Class Initialized
INFO - 2023-05-01 14:33:33 --> Language Class Initialized
ERROR - 2023-05-01 14:33:33 --> 404 Page Not Found: /index
INFO - 2023-05-01 14:33:35 --> Config Class Initialized
INFO - 2023-05-01 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:35 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:35 --> URI Class Initialized
INFO - 2023-05-01 14:33:35 --> Router Class Initialized
INFO - 2023-05-01 14:33:35 --> Output Class Initialized
INFO - 2023-05-01 14:33:35 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:35 --> Input Class Initialized
INFO - 2023-05-01 14:33:35 --> Language Class Initialized
INFO - 2023-05-01 14:33:35 --> Language Class Initialized
INFO - 2023-05-01 14:33:35 --> Config Class Initialized
INFO - 2023-05-01 14:33:35 --> Loader Class Initialized
INFO - 2023-05-01 14:33:35 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:35 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:35 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:35 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:35 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:35 --> Controller Class Initialized
DEBUG - 2023-05-01 14:33:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:33:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:33:35 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:35 --> Total execution time: 0.0564
INFO - 2023-05-01 14:33:35 --> Config Class Initialized
INFO - 2023-05-01 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:35 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:35 --> URI Class Initialized
INFO - 2023-05-01 14:33:35 --> Router Class Initialized
INFO - 2023-05-01 14:33:35 --> Output Class Initialized
INFO - 2023-05-01 14:33:35 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:35 --> Input Class Initialized
INFO - 2023-05-01 14:33:35 --> Language Class Initialized
ERROR - 2023-05-01 14:33:35 --> 404 Page Not Found: /index
INFO - 2023-05-01 14:33:39 --> Config Class Initialized
INFO - 2023-05-01 14:33:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:39 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:39 --> URI Class Initialized
INFO - 2023-05-01 14:33:39 --> Router Class Initialized
INFO - 2023-05-01 14:33:39 --> Output Class Initialized
INFO - 2023-05-01 14:33:39 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:39 --> Input Class Initialized
INFO - 2023-05-01 14:33:39 --> Language Class Initialized
INFO - 2023-05-01 14:33:39 --> Language Class Initialized
INFO - 2023-05-01 14:33:39 --> Config Class Initialized
INFO - 2023-05-01 14:33:39 --> Loader Class Initialized
INFO - 2023-05-01 14:33:39 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:39 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:39 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:39 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:39 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:39 --> Controller Class Initialized
DEBUG - 2023-05-01 14:33:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-01 14:33:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:33:39 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:39 --> Total execution time: 0.0564
INFO - 2023-05-01 14:33:39 --> Config Class Initialized
INFO - 2023-05-01 14:33:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:39 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:39 --> URI Class Initialized
INFO - 2023-05-01 14:33:39 --> Router Class Initialized
INFO - 2023-05-01 14:33:39 --> Output Class Initialized
INFO - 2023-05-01 14:33:39 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:39 --> Input Class Initialized
INFO - 2023-05-01 14:33:39 --> Language Class Initialized
ERROR - 2023-05-01 14:33:39 --> 404 Page Not Found: /index
INFO - 2023-05-01 14:33:39 --> Config Class Initialized
INFO - 2023-05-01 14:33:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:40 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:40 --> URI Class Initialized
INFO - 2023-05-01 14:33:40 --> Router Class Initialized
INFO - 2023-05-01 14:33:40 --> Output Class Initialized
INFO - 2023-05-01 14:33:40 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:40 --> Input Class Initialized
INFO - 2023-05-01 14:33:40 --> Language Class Initialized
INFO - 2023-05-01 14:33:40 --> Language Class Initialized
INFO - 2023-05-01 14:33:40 --> Config Class Initialized
INFO - 2023-05-01 14:33:40 --> Loader Class Initialized
INFO - 2023-05-01 14:33:40 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:40 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:40 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:40 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:40 --> Controller Class Initialized
INFO - 2023-05-01 14:33:43 --> Config Class Initialized
INFO - 2023-05-01 14:33:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:43 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:43 --> URI Class Initialized
INFO - 2023-05-01 14:33:43 --> Router Class Initialized
INFO - 2023-05-01 14:33:43 --> Output Class Initialized
INFO - 2023-05-01 14:33:43 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:43 --> Input Class Initialized
INFO - 2023-05-01 14:33:43 --> Language Class Initialized
INFO - 2023-05-01 14:33:43 --> Language Class Initialized
INFO - 2023-05-01 14:33:43 --> Config Class Initialized
INFO - 2023-05-01 14:33:43 --> Loader Class Initialized
INFO - 2023-05-01 14:33:43 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:43 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:43 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:43 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:43 --> Controller Class Initialized
INFO - 2023-05-01 14:33:43 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:43 --> Total execution time: 0.0605
INFO - 2023-05-01 14:33:46 --> Config Class Initialized
INFO - 2023-05-01 14:33:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:46 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:46 --> URI Class Initialized
INFO - 2023-05-01 14:33:46 --> Router Class Initialized
INFO - 2023-05-01 14:33:46 --> Output Class Initialized
INFO - 2023-05-01 14:33:46 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:46 --> Input Class Initialized
INFO - 2023-05-01 14:33:46 --> Language Class Initialized
INFO - 2023-05-01 14:33:46 --> Language Class Initialized
INFO - 2023-05-01 14:33:46 --> Config Class Initialized
INFO - 2023-05-01 14:33:46 --> Loader Class Initialized
INFO - 2023-05-01 14:33:46 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:46 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:46 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:46 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:46 --> Controller Class Initialized
INFO - 2023-05-01 14:33:46 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:46 --> Total execution time: 0.0608
INFO - 2023-05-01 14:33:47 --> Config Class Initialized
INFO - 2023-05-01 14:33:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:47 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:47 --> URI Class Initialized
INFO - 2023-05-01 14:33:47 --> Router Class Initialized
INFO - 2023-05-01 14:33:47 --> Output Class Initialized
INFO - 2023-05-01 14:33:47 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:47 --> Input Class Initialized
INFO - 2023-05-01 14:33:47 --> Language Class Initialized
INFO - 2023-05-01 14:33:47 --> Language Class Initialized
INFO - 2023-05-01 14:33:47 --> Config Class Initialized
INFO - 2023-05-01 14:33:47 --> Loader Class Initialized
INFO - 2023-05-01 14:33:47 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:47 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:47 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:47 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:47 --> Controller Class Initialized
DEBUG - 2023-05-01 14:33:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:33:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:33:47 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:47 --> Total execution time: 0.0419
INFO - 2023-05-01 14:33:49 --> Config Class Initialized
INFO - 2023-05-01 14:33:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:49 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:49 --> URI Class Initialized
INFO - 2023-05-01 14:33:49 --> Router Class Initialized
INFO - 2023-05-01 14:33:49 --> Output Class Initialized
INFO - 2023-05-01 14:33:49 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:49 --> Input Class Initialized
INFO - 2023-05-01 14:33:49 --> Language Class Initialized
INFO - 2023-05-01 14:33:49 --> Language Class Initialized
INFO - 2023-05-01 14:33:49 --> Config Class Initialized
INFO - 2023-05-01 14:33:49 --> Loader Class Initialized
INFO - 2023-05-01 14:33:49 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:49 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:49 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:49 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:49 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:49 --> Controller Class Initialized
DEBUG - 2023-05-01 14:33:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_la/views/list.php
DEBUG - 2023-05-01 14:33:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:33:49 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:49 --> Total execution time: 0.1020
INFO - 2023-05-01 14:33:49 --> Config Class Initialized
INFO - 2023-05-01 14:33:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:49 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:49 --> URI Class Initialized
INFO - 2023-05-01 14:33:49 --> Router Class Initialized
INFO - 2023-05-01 14:33:49 --> Output Class Initialized
INFO - 2023-05-01 14:33:49 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:49 --> Input Class Initialized
INFO - 2023-05-01 14:33:49 --> Language Class Initialized
INFO - 2023-05-01 14:33:49 --> Language Class Initialized
INFO - 2023-05-01 14:33:49 --> Config Class Initialized
INFO - 2023-05-01 14:33:49 --> Loader Class Initialized
INFO - 2023-05-01 14:33:49 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:49 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:49 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:49 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:49 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:49 --> Controller Class Initialized
INFO - 2023-05-01 14:33:51 --> Config Class Initialized
INFO - 2023-05-01 14:33:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:33:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:33:51 --> Utf8 Class Initialized
INFO - 2023-05-01 14:33:51 --> URI Class Initialized
INFO - 2023-05-01 14:33:51 --> Router Class Initialized
INFO - 2023-05-01 14:33:51 --> Output Class Initialized
INFO - 2023-05-01 14:33:51 --> Security Class Initialized
DEBUG - 2023-05-01 14:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:33:51 --> Input Class Initialized
INFO - 2023-05-01 14:33:51 --> Language Class Initialized
INFO - 2023-05-01 14:33:51 --> Language Class Initialized
INFO - 2023-05-01 14:33:51 --> Config Class Initialized
INFO - 2023-05-01 14:33:51 --> Loader Class Initialized
INFO - 2023-05-01 14:33:51 --> Helper loaded: url_helper
INFO - 2023-05-01 14:33:51 --> Helper loaded: file_helper
INFO - 2023-05-01 14:33:51 --> Helper loaded: form_helper
INFO - 2023-05-01 14:33:51 --> Helper loaded: my_helper
INFO - 2023-05-01 14:33:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:33:51 --> Controller Class Initialized
INFO - 2023-05-01 14:33:51 --> Final output sent to browser
DEBUG - 2023-05-01 14:33:51 --> Total execution time: 0.0595
INFO - 2023-05-01 14:34:01 --> Config Class Initialized
INFO - 2023-05-01 14:34:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:34:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:34:01 --> Utf8 Class Initialized
INFO - 2023-05-01 14:34:01 --> URI Class Initialized
INFO - 2023-05-01 14:34:01 --> Router Class Initialized
INFO - 2023-05-01 14:34:01 --> Output Class Initialized
INFO - 2023-05-01 14:34:01 --> Security Class Initialized
DEBUG - 2023-05-01 14:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:34:01 --> Input Class Initialized
INFO - 2023-05-01 14:34:01 --> Language Class Initialized
INFO - 2023-05-01 14:34:01 --> Language Class Initialized
INFO - 2023-05-01 14:34:01 --> Config Class Initialized
INFO - 2023-05-01 14:34:01 --> Loader Class Initialized
INFO - 2023-05-01 14:34:01 --> Helper loaded: url_helper
INFO - 2023-05-01 14:34:01 --> Helper loaded: file_helper
INFO - 2023-05-01 14:34:01 --> Helper loaded: form_helper
INFO - 2023-05-01 14:34:01 --> Helper loaded: my_helper
INFO - 2023-05-01 14:34:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:34:01 --> Controller Class Initialized
INFO - 2023-05-01 14:44:48 --> Config Class Initialized
INFO - 2023-05-01 14:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:48 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:48 --> URI Class Initialized
INFO - 2023-05-01 14:44:48 --> Router Class Initialized
INFO - 2023-05-01 14:44:48 --> Output Class Initialized
INFO - 2023-05-01 14:44:48 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:48 --> Input Class Initialized
INFO - 2023-05-01 14:44:48 --> Language Class Initialized
INFO - 2023-05-01 14:44:48 --> Language Class Initialized
INFO - 2023-05-01 14:44:48 --> Config Class Initialized
INFO - 2023-05-01 14:44:48 --> Loader Class Initialized
INFO - 2023-05-01 14:44:48 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:48 --> Controller Class Initialized
INFO - 2023-05-01 14:44:48 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:44:48 --> Config Class Initialized
INFO - 2023-05-01 14:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:48 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:48 --> URI Class Initialized
INFO - 2023-05-01 14:44:48 --> Router Class Initialized
INFO - 2023-05-01 14:44:48 --> Output Class Initialized
INFO - 2023-05-01 14:44:48 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:48 --> Input Class Initialized
INFO - 2023-05-01 14:44:48 --> Language Class Initialized
INFO - 2023-05-01 14:44:48 --> Language Class Initialized
INFO - 2023-05-01 14:44:48 --> Config Class Initialized
INFO - 2023-05-01 14:44:48 --> Loader Class Initialized
INFO - 2023-05-01 14:44:48 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:48 --> Controller Class Initialized
INFO - 2023-05-01 14:44:48 --> Config Class Initialized
INFO - 2023-05-01 14:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:48 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:48 --> URI Class Initialized
INFO - 2023-05-01 14:44:48 --> Router Class Initialized
INFO - 2023-05-01 14:44:48 --> Output Class Initialized
INFO - 2023-05-01 14:44:48 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:48 --> Input Class Initialized
INFO - 2023-05-01 14:44:48 --> Language Class Initialized
INFO - 2023-05-01 14:44:48 --> Language Class Initialized
INFO - 2023-05-01 14:44:48 --> Config Class Initialized
INFO - 2023-05-01 14:44:48 --> Loader Class Initialized
INFO - 2023-05-01 14:44:48 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:48 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:48 --> Controller Class Initialized
DEBUG - 2023-05-01 14:44:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 14:44:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:44:48 --> Final output sent to browser
DEBUG - 2023-05-01 14:44:48 --> Total execution time: 0.0541
INFO - 2023-05-01 14:44:53 --> Config Class Initialized
INFO - 2023-05-01 14:44:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:53 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:53 --> URI Class Initialized
INFO - 2023-05-01 14:44:53 --> Router Class Initialized
INFO - 2023-05-01 14:44:53 --> Output Class Initialized
INFO - 2023-05-01 14:44:53 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:53 --> Input Class Initialized
INFO - 2023-05-01 14:44:53 --> Language Class Initialized
INFO - 2023-05-01 14:44:53 --> Language Class Initialized
INFO - 2023-05-01 14:44:53 --> Config Class Initialized
INFO - 2023-05-01 14:44:53 --> Loader Class Initialized
INFO - 2023-05-01 14:44:53 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:53 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:53 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:53 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:53 --> Controller Class Initialized
INFO - 2023-05-01 14:44:53 --> Helper loaded: cookie_helper
INFO - 2023-05-01 14:44:53 --> Final output sent to browser
DEBUG - 2023-05-01 14:44:53 --> Total execution time: 0.0461
INFO - 2023-05-01 14:44:53 --> Config Class Initialized
INFO - 2023-05-01 14:44:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:53 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:53 --> URI Class Initialized
INFO - 2023-05-01 14:44:53 --> Router Class Initialized
INFO - 2023-05-01 14:44:53 --> Output Class Initialized
INFO - 2023-05-01 14:44:53 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:53 --> Input Class Initialized
INFO - 2023-05-01 14:44:53 --> Language Class Initialized
INFO - 2023-05-01 14:44:53 --> Language Class Initialized
INFO - 2023-05-01 14:44:53 --> Config Class Initialized
INFO - 2023-05-01 14:44:53 --> Loader Class Initialized
INFO - 2023-05-01 14:44:53 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:53 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:53 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:53 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:54 --> Controller Class Initialized
DEBUG - 2023-05-01 14:44:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 14:44:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:44:54 --> Final output sent to browser
DEBUG - 2023-05-01 14:44:54 --> Total execution time: 0.0478
INFO - 2023-05-01 14:44:55 --> Config Class Initialized
INFO - 2023-05-01 14:44:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:55 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:55 --> URI Class Initialized
INFO - 2023-05-01 14:44:55 --> Router Class Initialized
INFO - 2023-05-01 14:44:55 --> Output Class Initialized
INFO - 2023-05-01 14:44:55 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:55 --> Input Class Initialized
INFO - 2023-05-01 14:44:55 --> Language Class Initialized
INFO - 2023-05-01 14:44:55 --> Language Class Initialized
INFO - 2023-05-01 14:44:55 --> Config Class Initialized
INFO - 2023-05-01 14:44:55 --> Loader Class Initialized
INFO - 2023-05-01 14:44:55 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:55 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:55 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:55 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:55 --> Controller Class Initialized
DEBUG - 2023-05-01 14:44:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:44:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:44:55 --> Final output sent to browser
DEBUG - 2023-05-01 14:44:55 --> Total execution time: 0.0559
INFO - 2023-05-01 14:44:57 --> Config Class Initialized
INFO - 2023-05-01 14:44:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:57 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:57 --> URI Class Initialized
INFO - 2023-05-01 14:44:57 --> Router Class Initialized
INFO - 2023-05-01 14:44:57 --> Output Class Initialized
INFO - 2023-05-01 14:44:57 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:57 --> Input Class Initialized
INFO - 2023-05-01 14:44:57 --> Language Class Initialized
INFO - 2023-05-01 14:44:57 --> Language Class Initialized
INFO - 2023-05-01 14:44:57 --> Config Class Initialized
INFO - 2023-05-01 14:44:57 --> Loader Class Initialized
INFO - 2023-05-01 14:44:57 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:57 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:57 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:57 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:57 --> Controller Class Initialized
DEBUG - 2023-05-01 14:44:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:44:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:44:57 --> Final output sent to browser
DEBUG - 2023-05-01 14:44:57 --> Total execution time: 0.0565
INFO - 2023-05-01 14:44:57 --> Config Class Initialized
INFO - 2023-05-01 14:44:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:57 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:57 --> URI Class Initialized
INFO - 2023-05-01 14:44:57 --> Router Class Initialized
INFO - 2023-05-01 14:44:57 --> Output Class Initialized
INFO - 2023-05-01 14:44:57 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:57 --> Input Class Initialized
INFO - 2023-05-01 14:44:57 --> Language Class Initialized
INFO - 2023-05-01 14:44:57 --> Language Class Initialized
INFO - 2023-05-01 14:44:57 --> Config Class Initialized
INFO - 2023-05-01 14:44:57 --> Loader Class Initialized
INFO - 2023-05-01 14:44:57 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:57 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:57 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:57 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:57 --> Controller Class Initialized
INFO - 2023-05-01 14:44:59 --> Config Class Initialized
INFO - 2023-05-01 14:44:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:44:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:44:59 --> Utf8 Class Initialized
INFO - 2023-05-01 14:44:59 --> URI Class Initialized
INFO - 2023-05-01 14:44:59 --> Router Class Initialized
INFO - 2023-05-01 14:44:59 --> Output Class Initialized
INFO - 2023-05-01 14:44:59 --> Security Class Initialized
DEBUG - 2023-05-01 14:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:44:59 --> Input Class Initialized
INFO - 2023-05-01 14:44:59 --> Language Class Initialized
INFO - 2023-05-01 14:44:59 --> Language Class Initialized
INFO - 2023-05-01 14:44:59 --> Config Class Initialized
INFO - 2023-05-01 14:44:59 --> Loader Class Initialized
INFO - 2023-05-01 14:44:59 --> Helper loaded: url_helper
INFO - 2023-05-01 14:44:59 --> Helper loaded: file_helper
INFO - 2023-05-01 14:44:59 --> Helper loaded: form_helper
INFO - 2023-05-01 14:44:59 --> Helper loaded: my_helper
INFO - 2023-05-01 14:44:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:44:59 --> Controller Class Initialized
DEBUG - 2023-05-01 14:44:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 14:44:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:44:59 --> Final output sent to browser
DEBUG - 2023-05-01 14:44:59 --> Total execution time: 0.0468
INFO - 2023-05-01 14:45:05 --> Config Class Initialized
INFO - 2023-05-01 14:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:05 --> URI Class Initialized
INFO - 2023-05-01 14:45:05 --> Router Class Initialized
INFO - 2023-05-01 14:45:05 --> Output Class Initialized
INFO - 2023-05-01 14:45:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:05 --> Input Class Initialized
INFO - 2023-05-01 14:45:05 --> Language Class Initialized
INFO - 2023-05-01 14:45:05 --> Language Class Initialized
INFO - 2023-05-01 14:45:05 --> Config Class Initialized
INFO - 2023-05-01 14:45:05 --> Loader Class Initialized
INFO - 2023-05-01 14:45:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:05 --> Controller Class Initialized
INFO - 2023-05-01 14:45:05 --> Config Class Initialized
INFO - 2023-05-01 14:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:05 --> URI Class Initialized
INFO - 2023-05-01 14:45:05 --> Router Class Initialized
INFO - 2023-05-01 14:45:05 --> Output Class Initialized
INFO - 2023-05-01 14:45:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:05 --> Input Class Initialized
INFO - 2023-05-01 14:45:05 --> Language Class Initialized
INFO - 2023-05-01 14:45:05 --> Language Class Initialized
INFO - 2023-05-01 14:45:05 --> Config Class Initialized
INFO - 2023-05-01 14:45:05 --> Loader Class Initialized
INFO - 2023-05-01 14:45:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:05 --> Controller Class Initialized
DEBUG - 2023-05-01 14:45:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 14:45:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:45:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:05 --> Total execution time: 0.0546
INFO - 2023-05-01 14:45:05 --> Config Class Initialized
INFO - 2023-05-01 14:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:05 --> URI Class Initialized
INFO - 2023-05-01 14:45:05 --> Router Class Initialized
INFO - 2023-05-01 14:45:05 --> Output Class Initialized
INFO - 2023-05-01 14:45:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:05 --> Input Class Initialized
INFO - 2023-05-01 14:45:05 --> Language Class Initialized
INFO - 2023-05-01 14:45:05 --> Language Class Initialized
INFO - 2023-05-01 14:45:05 --> Config Class Initialized
INFO - 2023-05-01 14:45:05 --> Loader Class Initialized
INFO - 2023-05-01 14:45:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:05 --> Controller Class Initialized
INFO - 2023-05-01 14:45:07 --> Config Class Initialized
INFO - 2023-05-01 14:45:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:07 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:07 --> URI Class Initialized
INFO - 2023-05-01 14:45:07 --> Router Class Initialized
INFO - 2023-05-01 14:45:07 --> Output Class Initialized
INFO - 2023-05-01 14:45:07 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:07 --> Input Class Initialized
INFO - 2023-05-01 14:45:07 --> Language Class Initialized
INFO - 2023-05-01 14:45:07 --> Language Class Initialized
INFO - 2023-05-01 14:45:07 --> Config Class Initialized
INFO - 2023-05-01 14:45:07 --> Loader Class Initialized
INFO - 2023-05-01 14:45:07 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:07 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:07 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:07 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:07 --> Controller Class Initialized
INFO - 2023-05-01 14:45:07 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:07 --> Total execution time: 0.0599
INFO - 2023-05-01 14:45:11 --> Config Class Initialized
INFO - 2023-05-01 14:45:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:11 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:11 --> URI Class Initialized
INFO - 2023-05-01 14:45:11 --> Router Class Initialized
INFO - 2023-05-01 14:45:11 --> Output Class Initialized
INFO - 2023-05-01 14:45:11 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:11 --> Input Class Initialized
INFO - 2023-05-01 14:45:11 --> Language Class Initialized
INFO - 2023-05-01 14:45:11 --> Language Class Initialized
INFO - 2023-05-01 14:45:11 --> Config Class Initialized
INFO - 2023-05-01 14:45:11 --> Loader Class Initialized
INFO - 2023-05-01 14:45:11 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:11 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:11 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:11 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:11 --> Controller Class Initialized
INFO - 2023-05-01 14:45:11 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:11 --> Total execution time: 0.0586
INFO - 2023-05-01 14:45:15 --> Config Class Initialized
INFO - 2023-05-01 14:45:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:15 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:15 --> URI Class Initialized
INFO - 2023-05-01 14:45:15 --> Router Class Initialized
INFO - 2023-05-01 14:45:15 --> Output Class Initialized
INFO - 2023-05-01 14:45:15 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:15 --> Input Class Initialized
INFO - 2023-05-01 14:45:15 --> Language Class Initialized
INFO - 2023-05-01 14:45:15 --> Language Class Initialized
INFO - 2023-05-01 14:45:15 --> Config Class Initialized
INFO - 2023-05-01 14:45:15 --> Loader Class Initialized
INFO - 2023-05-01 14:45:15 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:15 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:15 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:15 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:15 --> Controller Class Initialized
DEBUG - 2023-05-01 14:45:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 14:45:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:45:15 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:15 --> Total execution time: 0.0382
INFO - 2023-05-01 14:45:17 --> Config Class Initialized
INFO - 2023-05-01 14:45:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:17 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:17 --> URI Class Initialized
INFO - 2023-05-01 14:45:17 --> Router Class Initialized
INFO - 2023-05-01 14:45:17 --> Output Class Initialized
INFO - 2023-05-01 14:45:17 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:17 --> Input Class Initialized
INFO - 2023-05-01 14:45:17 --> Language Class Initialized
INFO - 2023-05-01 14:45:17 --> Language Class Initialized
INFO - 2023-05-01 14:45:17 --> Config Class Initialized
INFO - 2023-05-01 14:45:17 --> Loader Class Initialized
INFO - 2023-05-01 14:45:17 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:17 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:17 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:17 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:17 --> Controller Class Initialized
DEBUG - 2023-05-01 14:45:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:45:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:45:17 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:17 --> Total execution time: 0.0588
INFO - 2023-05-01 14:45:17 --> Config Class Initialized
INFO - 2023-05-01 14:45:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:17 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:17 --> URI Class Initialized
INFO - 2023-05-01 14:45:17 --> Router Class Initialized
INFO - 2023-05-01 14:45:17 --> Output Class Initialized
INFO - 2023-05-01 14:45:17 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:17 --> Input Class Initialized
INFO - 2023-05-01 14:45:17 --> Language Class Initialized
INFO - 2023-05-01 14:45:17 --> Language Class Initialized
INFO - 2023-05-01 14:45:17 --> Config Class Initialized
INFO - 2023-05-01 14:45:17 --> Loader Class Initialized
INFO - 2023-05-01 14:45:17 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:17 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:17 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:17 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:17 --> Controller Class Initialized
INFO - 2023-05-01 14:45:18 --> Config Class Initialized
INFO - 2023-05-01 14:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:18 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:18 --> URI Class Initialized
INFO - 2023-05-01 14:45:18 --> Router Class Initialized
INFO - 2023-05-01 14:45:18 --> Output Class Initialized
INFO - 2023-05-01 14:45:18 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:18 --> Input Class Initialized
INFO - 2023-05-01 14:45:18 --> Language Class Initialized
INFO - 2023-05-01 14:45:18 --> Language Class Initialized
INFO - 2023-05-01 14:45:18 --> Config Class Initialized
INFO - 2023-05-01 14:45:18 --> Loader Class Initialized
INFO - 2023-05-01 14:45:18 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:18 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:18 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:18 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:18 --> Controller Class Initialized
INFO - 2023-05-01 14:45:18 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:18 --> Total execution time: 0.0419
INFO - 2023-05-01 14:45:21 --> Config Class Initialized
INFO - 2023-05-01 14:45:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:21 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:21 --> URI Class Initialized
INFO - 2023-05-01 14:45:21 --> Router Class Initialized
INFO - 2023-05-01 14:45:21 --> Output Class Initialized
INFO - 2023-05-01 14:45:21 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:21 --> Input Class Initialized
INFO - 2023-05-01 14:45:21 --> Language Class Initialized
INFO - 2023-05-01 14:45:21 --> Language Class Initialized
INFO - 2023-05-01 14:45:21 --> Config Class Initialized
INFO - 2023-05-01 14:45:21 --> Loader Class Initialized
INFO - 2023-05-01 14:45:21 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:21 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:21 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:21 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:21 --> Controller Class Initialized
INFO - 2023-05-01 14:45:21 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:21 --> Total execution time: 0.0360
INFO - 2023-05-01 14:45:22 --> Config Class Initialized
INFO - 2023-05-01 14:45:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:45:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:45:22 --> Utf8 Class Initialized
INFO - 2023-05-01 14:45:22 --> URI Class Initialized
INFO - 2023-05-01 14:45:22 --> Router Class Initialized
INFO - 2023-05-01 14:45:22 --> Output Class Initialized
INFO - 2023-05-01 14:45:22 --> Security Class Initialized
DEBUG - 2023-05-01 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:45:22 --> Input Class Initialized
INFO - 2023-05-01 14:45:22 --> Language Class Initialized
INFO - 2023-05-01 14:45:22 --> Language Class Initialized
INFO - 2023-05-01 14:45:22 --> Config Class Initialized
INFO - 2023-05-01 14:45:22 --> Loader Class Initialized
INFO - 2023-05-01 14:45:22 --> Helper loaded: url_helper
INFO - 2023-05-01 14:45:22 --> Helper loaded: file_helper
INFO - 2023-05-01 14:45:22 --> Helper loaded: form_helper
INFO - 2023-05-01 14:45:22 --> Helper loaded: my_helper
INFO - 2023-05-01 14:45:22 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:45:22 --> Controller Class Initialized
INFO - 2023-05-01 14:45:22 --> Final output sent to browser
DEBUG - 2023-05-01 14:45:22 --> Total execution time: 0.0588
INFO - 2023-05-01 14:46:59 --> Config Class Initialized
INFO - 2023-05-01 14:46:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:46:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:46:59 --> Utf8 Class Initialized
INFO - 2023-05-01 14:46:59 --> URI Class Initialized
INFO - 2023-05-01 14:46:59 --> Router Class Initialized
INFO - 2023-05-01 14:46:59 --> Output Class Initialized
INFO - 2023-05-01 14:46:59 --> Security Class Initialized
DEBUG - 2023-05-01 14:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:46:59 --> Input Class Initialized
INFO - 2023-05-01 14:46:59 --> Language Class Initialized
INFO - 2023-05-01 14:46:59 --> Language Class Initialized
INFO - 2023-05-01 14:46:59 --> Config Class Initialized
INFO - 2023-05-01 14:46:59 --> Loader Class Initialized
INFO - 2023-05-01 14:46:59 --> Helper loaded: url_helper
INFO - 2023-05-01 14:46:59 --> Helper loaded: file_helper
INFO - 2023-05-01 14:46:59 --> Helper loaded: form_helper
INFO - 2023-05-01 14:46:59 --> Helper loaded: my_helper
INFO - 2023-05-01 14:46:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:46:59 --> Controller Class Initialized
INFO - 2023-05-01 14:46:59 --> Final output sent to browser
DEBUG - 2023-05-01 14:46:59 --> Total execution time: 0.0411
INFO - 2023-05-01 14:47:05 --> Config Class Initialized
INFO - 2023-05-01 14:47:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:05 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:05 --> URI Class Initialized
INFO - 2023-05-01 14:47:05 --> Router Class Initialized
INFO - 2023-05-01 14:47:05 --> Output Class Initialized
INFO - 2023-05-01 14:47:05 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:05 --> Input Class Initialized
INFO - 2023-05-01 14:47:05 --> Language Class Initialized
INFO - 2023-05-01 14:47:05 --> Language Class Initialized
INFO - 2023-05-01 14:47:05 --> Config Class Initialized
INFO - 2023-05-01 14:47:05 --> Loader Class Initialized
INFO - 2023-05-01 14:47:05 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:05 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:05 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:05 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:05 --> Controller Class Initialized
INFO - 2023-05-01 14:47:05 --> Final output sent to browser
DEBUG - 2023-05-01 14:47:05 --> Total execution time: 0.0444
INFO - 2023-05-01 14:47:07 --> Config Class Initialized
INFO - 2023-05-01 14:47:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:07 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:07 --> URI Class Initialized
INFO - 2023-05-01 14:47:07 --> Router Class Initialized
INFO - 2023-05-01 14:47:07 --> Output Class Initialized
INFO - 2023-05-01 14:47:07 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:07 --> Input Class Initialized
INFO - 2023-05-01 14:47:07 --> Language Class Initialized
INFO - 2023-05-01 14:47:07 --> Language Class Initialized
INFO - 2023-05-01 14:47:07 --> Config Class Initialized
INFO - 2023-05-01 14:47:07 --> Loader Class Initialized
INFO - 2023-05-01 14:47:07 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:07 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:07 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:07 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:07 --> Controller Class Initialized
INFO - 2023-05-01 14:47:07 --> Final output sent to browser
DEBUG - 2023-05-01 14:47:07 --> Total execution time: 0.0607
INFO - 2023-05-01 14:47:11 --> Config Class Initialized
INFO - 2023-05-01 14:47:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:11 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:11 --> URI Class Initialized
INFO - 2023-05-01 14:47:11 --> Router Class Initialized
INFO - 2023-05-01 14:47:11 --> Output Class Initialized
INFO - 2023-05-01 14:47:11 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:11 --> Input Class Initialized
INFO - 2023-05-01 14:47:11 --> Language Class Initialized
INFO - 2023-05-01 14:47:11 --> Language Class Initialized
INFO - 2023-05-01 14:47:11 --> Config Class Initialized
INFO - 2023-05-01 14:47:11 --> Loader Class Initialized
INFO - 2023-05-01 14:47:11 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:11 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:11 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:11 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:11 --> Controller Class Initialized
INFO - 2023-05-01 14:47:11 --> Final output sent to browser
DEBUG - 2023-05-01 14:47:11 --> Total execution time: 0.0597
INFO - 2023-05-01 14:47:31 --> Config Class Initialized
INFO - 2023-05-01 14:47:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:31 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:31 --> URI Class Initialized
INFO - 2023-05-01 14:47:31 --> Router Class Initialized
INFO - 2023-05-01 14:47:31 --> Output Class Initialized
INFO - 2023-05-01 14:47:31 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:31 --> Input Class Initialized
INFO - 2023-05-01 14:47:31 --> Language Class Initialized
INFO - 2023-05-01 14:47:31 --> Language Class Initialized
INFO - 2023-05-01 14:47:31 --> Config Class Initialized
INFO - 2023-05-01 14:47:31 --> Loader Class Initialized
INFO - 2023-05-01 14:47:31 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:31 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:31 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:31 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:31 --> Controller Class Initialized
DEBUG - 2023-05-01 14:47:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 14:47:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 14:47:31 --> Final output sent to browser
DEBUG - 2023-05-01 14:47:31 --> Total execution time: 0.0446
INFO - 2023-05-01 14:47:31 --> Config Class Initialized
INFO - 2023-05-01 14:47:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:31 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:31 --> URI Class Initialized
INFO - 2023-05-01 14:47:31 --> Router Class Initialized
INFO - 2023-05-01 14:47:31 --> Output Class Initialized
INFO - 2023-05-01 14:47:31 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:31 --> Input Class Initialized
INFO - 2023-05-01 14:47:31 --> Language Class Initialized
INFO - 2023-05-01 14:47:31 --> Language Class Initialized
INFO - 2023-05-01 14:47:31 --> Config Class Initialized
INFO - 2023-05-01 14:47:31 --> Loader Class Initialized
INFO - 2023-05-01 14:47:31 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:31 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:31 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:31 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:31 --> Controller Class Initialized
INFO - 2023-05-01 14:47:33 --> Config Class Initialized
INFO - 2023-05-01 14:47:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:33 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:33 --> URI Class Initialized
INFO - 2023-05-01 14:47:33 --> Router Class Initialized
INFO - 2023-05-01 14:47:33 --> Output Class Initialized
INFO - 2023-05-01 14:47:33 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:33 --> Input Class Initialized
INFO - 2023-05-01 14:47:33 --> Language Class Initialized
INFO - 2023-05-01 14:47:33 --> Language Class Initialized
INFO - 2023-05-01 14:47:33 --> Config Class Initialized
INFO - 2023-05-01 14:47:33 --> Loader Class Initialized
INFO - 2023-05-01 14:47:33 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:33 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:33 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:33 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:33 --> Controller Class Initialized
INFO - 2023-05-01 14:47:33 --> Final output sent to browser
DEBUG - 2023-05-01 14:47:33 --> Total execution time: 0.0592
INFO - 2023-05-01 14:47:36 --> Config Class Initialized
INFO - 2023-05-01 14:47:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:47:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:47:36 --> Utf8 Class Initialized
INFO - 2023-05-01 14:47:36 --> URI Class Initialized
INFO - 2023-05-01 14:47:36 --> Router Class Initialized
INFO - 2023-05-01 14:47:36 --> Output Class Initialized
INFO - 2023-05-01 14:47:36 --> Security Class Initialized
DEBUG - 2023-05-01 14:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:47:36 --> Input Class Initialized
INFO - 2023-05-01 14:47:36 --> Language Class Initialized
INFO - 2023-05-01 14:47:36 --> Language Class Initialized
INFO - 2023-05-01 14:47:36 --> Config Class Initialized
INFO - 2023-05-01 14:47:36 --> Loader Class Initialized
INFO - 2023-05-01 14:47:36 --> Helper loaded: url_helper
INFO - 2023-05-01 14:47:36 --> Helper loaded: file_helper
INFO - 2023-05-01 14:47:36 --> Helper loaded: form_helper
INFO - 2023-05-01 14:47:36 --> Helper loaded: my_helper
INFO - 2023-05-01 14:47:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:47:36 --> Controller Class Initialized
INFO - 2023-05-01 14:47:36 --> Final output sent to browser
DEBUG - 2023-05-01 14:47:36 --> Total execution time: 0.0598
INFO - 2023-05-01 14:49:57 --> Config Class Initialized
INFO - 2023-05-01 14:49:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:49:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:49:57 --> Utf8 Class Initialized
INFO - 2023-05-01 14:49:57 --> URI Class Initialized
INFO - 2023-05-01 14:49:57 --> Router Class Initialized
INFO - 2023-05-01 14:49:57 --> Output Class Initialized
INFO - 2023-05-01 14:49:57 --> Security Class Initialized
DEBUG - 2023-05-01 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:49:57 --> Input Class Initialized
INFO - 2023-05-01 14:49:57 --> Language Class Initialized
INFO - 2023-05-01 14:49:57 --> Language Class Initialized
INFO - 2023-05-01 14:49:57 --> Config Class Initialized
INFO - 2023-05-01 14:49:57 --> Loader Class Initialized
INFO - 2023-05-01 14:49:57 --> Helper loaded: url_helper
INFO - 2023-05-01 14:49:57 --> Helper loaded: file_helper
INFO - 2023-05-01 14:49:57 --> Helper loaded: form_helper
INFO - 2023-05-01 14:49:57 --> Helper loaded: my_helper
INFO - 2023-05-01 14:49:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:49:57 --> Controller Class Initialized
INFO - 2023-05-01 14:53:43 --> Config Class Initialized
INFO - 2023-05-01 14:53:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 14:53:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 14:53:43 --> Utf8 Class Initialized
INFO - 2023-05-01 14:53:43 --> URI Class Initialized
INFO - 2023-05-01 14:53:43 --> Router Class Initialized
INFO - 2023-05-01 14:53:43 --> Output Class Initialized
INFO - 2023-05-01 14:53:43 --> Security Class Initialized
DEBUG - 2023-05-01 14:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 14:53:43 --> Input Class Initialized
INFO - 2023-05-01 14:53:43 --> Language Class Initialized
INFO - 2023-05-01 14:53:43 --> Language Class Initialized
INFO - 2023-05-01 14:53:43 --> Config Class Initialized
INFO - 2023-05-01 14:53:43 --> Loader Class Initialized
INFO - 2023-05-01 14:53:43 --> Helper loaded: url_helper
INFO - 2023-05-01 14:53:43 --> Helper loaded: file_helper
INFO - 2023-05-01 14:53:43 --> Helper loaded: form_helper
INFO - 2023-05-01 14:53:43 --> Helper loaded: my_helper
INFO - 2023-05-01 14:53:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 14:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 14:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 14:53:43 --> Controller Class Initialized
INFO - 2023-05-01 15:06:16 --> Config Class Initialized
INFO - 2023-05-01 15:06:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:16 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:16 --> URI Class Initialized
INFO - 2023-05-01 15:06:16 --> Router Class Initialized
INFO - 2023-05-01 15:06:16 --> Output Class Initialized
INFO - 2023-05-01 15:06:16 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:16 --> Input Class Initialized
INFO - 2023-05-01 15:06:16 --> Language Class Initialized
INFO - 2023-05-01 15:06:16 --> Language Class Initialized
INFO - 2023-05-01 15:06:16 --> Config Class Initialized
INFO - 2023-05-01 15:06:16 --> Loader Class Initialized
INFO - 2023-05-01 15:06:16 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:16 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:16 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:16 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:16 --> Controller Class Initialized
DEBUG - 2023-05-01 15:06:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 15:06:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:06:16 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:16 --> Total execution time: 0.0500
INFO - 2023-05-01 15:06:25 --> Config Class Initialized
INFO - 2023-05-01 15:06:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:25 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:25 --> URI Class Initialized
INFO - 2023-05-01 15:06:25 --> Router Class Initialized
INFO - 2023-05-01 15:06:25 --> Output Class Initialized
INFO - 2023-05-01 15:06:25 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:25 --> Input Class Initialized
INFO - 2023-05-01 15:06:25 --> Language Class Initialized
INFO - 2023-05-01 15:06:25 --> Language Class Initialized
INFO - 2023-05-01 15:06:25 --> Config Class Initialized
INFO - 2023-05-01 15:06:25 --> Loader Class Initialized
INFO - 2023-05-01 15:06:25 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:25 --> Controller Class Initialized
INFO - 2023-05-01 15:06:25 --> Config Class Initialized
INFO - 2023-05-01 15:06:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:25 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:25 --> URI Class Initialized
INFO - 2023-05-01 15:06:25 --> Router Class Initialized
INFO - 2023-05-01 15:06:25 --> Output Class Initialized
INFO - 2023-05-01 15:06:25 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:25 --> Input Class Initialized
INFO - 2023-05-01 15:06:25 --> Language Class Initialized
INFO - 2023-05-01 15:06:25 --> Language Class Initialized
INFO - 2023-05-01 15:06:25 --> Config Class Initialized
INFO - 2023-05-01 15:06:25 --> Loader Class Initialized
INFO - 2023-05-01 15:06:25 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:25 --> Controller Class Initialized
DEBUG - 2023-05-01 15:06:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 15:06:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:06:25 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:25 --> Total execution time: 0.0420
INFO - 2023-05-01 15:06:25 --> Config Class Initialized
INFO - 2023-05-01 15:06:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:25 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:25 --> URI Class Initialized
INFO - 2023-05-01 15:06:25 --> Router Class Initialized
INFO - 2023-05-01 15:06:25 --> Output Class Initialized
INFO - 2023-05-01 15:06:25 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:25 --> Input Class Initialized
INFO - 2023-05-01 15:06:25 --> Language Class Initialized
INFO - 2023-05-01 15:06:25 --> Language Class Initialized
INFO - 2023-05-01 15:06:25 --> Config Class Initialized
INFO - 2023-05-01 15:06:25 --> Loader Class Initialized
INFO - 2023-05-01 15:06:25 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:25 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:25 --> Controller Class Initialized
INFO - 2023-05-01 15:06:26 --> Config Class Initialized
INFO - 2023-05-01 15:06:26 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:26 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:26 --> URI Class Initialized
INFO - 2023-05-01 15:06:26 --> Router Class Initialized
INFO - 2023-05-01 15:06:26 --> Output Class Initialized
INFO - 2023-05-01 15:06:26 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:26 --> Input Class Initialized
INFO - 2023-05-01 15:06:26 --> Language Class Initialized
INFO - 2023-05-01 15:06:26 --> Language Class Initialized
INFO - 2023-05-01 15:06:26 --> Config Class Initialized
INFO - 2023-05-01 15:06:26 --> Loader Class Initialized
INFO - 2023-05-01 15:06:26 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:26 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:26 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:26 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:26 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:26 --> Controller Class Initialized
INFO - 2023-05-01 15:06:26 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:26 --> Total execution time: 0.0488
INFO - 2023-05-01 15:06:28 --> Config Class Initialized
INFO - 2023-05-01 15:06:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:28 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:28 --> URI Class Initialized
INFO - 2023-05-01 15:06:28 --> Router Class Initialized
INFO - 2023-05-01 15:06:28 --> Output Class Initialized
INFO - 2023-05-01 15:06:28 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:28 --> Input Class Initialized
INFO - 2023-05-01 15:06:28 --> Language Class Initialized
INFO - 2023-05-01 15:06:28 --> Language Class Initialized
INFO - 2023-05-01 15:06:28 --> Config Class Initialized
INFO - 2023-05-01 15:06:28 --> Loader Class Initialized
INFO - 2023-05-01 15:06:28 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:28 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:28 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:28 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:28 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:28 --> Controller Class Initialized
INFO - 2023-05-01 15:06:28 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:28 --> Total execution time: 0.0502
INFO - 2023-05-01 15:06:30 --> Config Class Initialized
INFO - 2023-05-01 15:06:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:30 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:30 --> URI Class Initialized
INFO - 2023-05-01 15:06:30 --> Router Class Initialized
INFO - 2023-05-01 15:06:30 --> Output Class Initialized
INFO - 2023-05-01 15:06:30 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:30 --> Input Class Initialized
INFO - 2023-05-01 15:06:30 --> Language Class Initialized
INFO - 2023-05-01 15:06:30 --> Language Class Initialized
INFO - 2023-05-01 15:06:30 --> Config Class Initialized
INFO - 2023-05-01 15:06:30 --> Loader Class Initialized
INFO - 2023-05-01 15:06:30 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:30 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:30 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:30 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:30 --> Controller Class Initialized
INFO - 2023-05-01 15:06:30 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:30 --> Total execution time: 0.0520
INFO - 2023-05-01 15:06:32 --> Config Class Initialized
INFO - 2023-05-01 15:06:32 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:32 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:32 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:32 --> URI Class Initialized
INFO - 2023-05-01 15:06:32 --> Router Class Initialized
INFO - 2023-05-01 15:06:32 --> Output Class Initialized
INFO - 2023-05-01 15:06:32 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:32 --> Input Class Initialized
INFO - 2023-05-01 15:06:32 --> Language Class Initialized
INFO - 2023-05-01 15:06:32 --> Language Class Initialized
INFO - 2023-05-01 15:06:32 --> Config Class Initialized
INFO - 2023-05-01 15:06:32 --> Loader Class Initialized
INFO - 2023-05-01 15:06:32 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:32 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:32 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:32 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:32 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:32 --> Controller Class Initialized
INFO - 2023-05-01 15:06:32 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:32 --> Total execution time: 0.0376
INFO - 2023-05-01 15:06:33 --> Config Class Initialized
INFO - 2023-05-01 15:06:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:33 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:33 --> URI Class Initialized
INFO - 2023-05-01 15:06:33 --> Router Class Initialized
INFO - 2023-05-01 15:06:33 --> Output Class Initialized
INFO - 2023-05-01 15:06:33 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:33 --> Input Class Initialized
INFO - 2023-05-01 15:06:33 --> Language Class Initialized
INFO - 2023-05-01 15:06:33 --> Language Class Initialized
INFO - 2023-05-01 15:06:33 --> Config Class Initialized
INFO - 2023-05-01 15:06:33 --> Loader Class Initialized
INFO - 2023-05-01 15:06:33 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:33 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:33 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:33 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:33 --> Controller Class Initialized
INFO - 2023-05-01 15:06:33 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:33 --> Total execution time: 0.0528
INFO - 2023-05-01 15:06:37 --> Config Class Initialized
INFO - 2023-05-01 15:06:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:37 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:37 --> URI Class Initialized
DEBUG - 2023-05-01 15:06:37 --> No URI present. Default controller set.
INFO - 2023-05-01 15:06:37 --> Router Class Initialized
INFO - 2023-05-01 15:06:37 --> Output Class Initialized
INFO - 2023-05-01 15:06:37 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:37 --> Input Class Initialized
INFO - 2023-05-01 15:06:37 --> Language Class Initialized
INFO - 2023-05-01 15:06:37 --> Language Class Initialized
INFO - 2023-05-01 15:06:37 --> Config Class Initialized
INFO - 2023-05-01 15:06:37 --> Loader Class Initialized
INFO - 2023-05-01 15:06:37 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:37 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:37 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:37 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:37 --> Controller Class Initialized
DEBUG - 2023-05-01 15:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 15:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:06:37 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:37 --> Total execution time: 0.0591
INFO - 2023-05-01 15:06:38 --> Config Class Initialized
INFO - 2023-05-01 15:06:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:38 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:38 --> URI Class Initialized
INFO - 2023-05-01 15:06:38 --> Router Class Initialized
INFO - 2023-05-01 15:06:38 --> Output Class Initialized
INFO - 2023-05-01 15:06:38 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:38 --> Input Class Initialized
INFO - 2023-05-01 15:06:38 --> Language Class Initialized
INFO - 2023-05-01 15:06:38 --> Language Class Initialized
INFO - 2023-05-01 15:06:38 --> Config Class Initialized
INFO - 2023-05-01 15:06:38 --> Loader Class Initialized
INFO - 2023-05-01 15:06:38 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:38 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:38 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:38 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:38 --> Controller Class Initialized
DEBUG - 2023-05-01 15:06:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:06:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:06:38 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:38 --> Total execution time: 0.0609
INFO - 2023-05-01 15:06:40 --> Config Class Initialized
INFO - 2023-05-01 15:06:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:40 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:40 --> URI Class Initialized
INFO - 2023-05-01 15:06:40 --> Router Class Initialized
INFO - 2023-05-01 15:06:40 --> Output Class Initialized
INFO - 2023-05-01 15:06:40 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:40 --> Input Class Initialized
INFO - 2023-05-01 15:06:40 --> Language Class Initialized
INFO - 2023-05-01 15:06:40 --> Language Class Initialized
INFO - 2023-05-01 15:06:40 --> Config Class Initialized
INFO - 2023-05-01 15:06:40 --> Loader Class Initialized
INFO - 2023-05-01 15:06:40 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:40 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:40 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:40 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:40 --> Controller Class Initialized
DEBUG - 2023-05-01 15:06:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 15:06:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:06:40 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:40 --> Total execution time: 0.0521
INFO - 2023-05-01 15:06:40 --> Config Class Initialized
INFO - 2023-05-01 15:06:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:40 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:40 --> URI Class Initialized
INFO - 2023-05-01 15:06:40 --> Router Class Initialized
INFO - 2023-05-01 15:06:40 --> Output Class Initialized
INFO - 2023-05-01 15:06:40 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:40 --> Input Class Initialized
INFO - 2023-05-01 15:06:40 --> Language Class Initialized
INFO - 2023-05-01 15:06:40 --> Language Class Initialized
INFO - 2023-05-01 15:06:40 --> Config Class Initialized
INFO - 2023-05-01 15:06:40 --> Loader Class Initialized
INFO - 2023-05-01 15:06:40 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:40 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:40 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:40 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:40 --> Controller Class Initialized
INFO - 2023-05-01 15:06:41 --> Config Class Initialized
INFO - 2023-05-01 15:06:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:41 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:41 --> URI Class Initialized
INFO - 2023-05-01 15:06:41 --> Router Class Initialized
INFO - 2023-05-01 15:06:41 --> Output Class Initialized
INFO - 2023-05-01 15:06:41 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:41 --> Input Class Initialized
INFO - 2023-05-01 15:06:41 --> Language Class Initialized
INFO - 2023-05-01 15:06:41 --> Language Class Initialized
INFO - 2023-05-01 15:06:41 --> Config Class Initialized
INFO - 2023-05-01 15:06:41 --> Loader Class Initialized
INFO - 2023-05-01 15:06:41 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:41 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:41 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:41 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:41 --> Controller Class Initialized
INFO - 2023-05-01 15:06:41 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:41 --> Total execution time: 0.0405
INFO - 2023-05-01 15:06:43 --> Config Class Initialized
INFO - 2023-05-01 15:06:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:43 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:43 --> URI Class Initialized
INFO - 2023-05-01 15:06:43 --> Router Class Initialized
INFO - 2023-05-01 15:06:43 --> Output Class Initialized
INFO - 2023-05-01 15:06:43 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:43 --> Input Class Initialized
INFO - 2023-05-01 15:06:43 --> Language Class Initialized
INFO - 2023-05-01 15:06:43 --> Language Class Initialized
INFO - 2023-05-01 15:06:43 --> Config Class Initialized
INFO - 2023-05-01 15:06:43 --> Loader Class Initialized
INFO - 2023-05-01 15:06:43 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:43 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:43 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:43 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:43 --> Controller Class Initialized
INFO - 2023-05-01 15:06:43 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:43 --> Total execution time: 0.0548
INFO - 2023-05-01 15:06:44 --> Config Class Initialized
INFO - 2023-05-01 15:06:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:06:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:06:44 --> Utf8 Class Initialized
INFO - 2023-05-01 15:06:44 --> URI Class Initialized
INFO - 2023-05-01 15:06:44 --> Router Class Initialized
INFO - 2023-05-01 15:06:44 --> Output Class Initialized
INFO - 2023-05-01 15:06:44 --> Security Class Initialized
DEBUG - 2023-05-01 15:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:06:44 --> Input Class Initialized
INFO - 2023-05-01 15:06:44 --> Language Class Initialized
INFO - 2023-05-01 15:06:44 --> Language Class Initialized
INFO - 2023-05-01 15:06:44 --> Config Class Initialized
INFO - 2023-05-01 15:06:44 --> Loader Class Initialized
INFO - 2023-05-01 15:06:44 --> Helper loaded: url_helper
INFO - 2023-05-01 15:06:44 --> Helper loaded: file_helper
INFO - 2023-05-01 15:06:44 --> Helper loaded: form_helper
INFO - 2023-05-01 15:06:44 --> Helper loaded: my_helper
INFO - 2023-05-01 15:06:44 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:06:44 --> Controller Class Initialized
INFO - 2023-05-01 15:06:44 --> Final output sent to browser
DEBUG - 2023-05-01 15:06:44 --> Total execution time: 0.0361
INFO - 2023-05-01 15:07:50 --> Config Class Initialized
INFO - 2023-05-01 15:07:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:50 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:50 --> URI Class Initialized
INFO - 2023-05-01 15:07:50 --> Router Class Initialized
INFO - 2023-05-01 15:07:50 --> Output Class Initialized
INFO - 2023-05-01 15:07:50 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:50 --> Input Class Initialized
INFO - 2023-05-01 15:07:50 --> Language Class Initialized
INFO - 2023-05-01 15:07:50 --> Language Class Initialized
INFO - 2023-05-01 15:07:50 --> Config Class Initialized
INFO - 2023-05-01 15:07:50 --> Loader Class Initialized
INFO - 2023-05-01 15:07:50 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:50 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:50 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:50 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:50 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:50 --> Controller Class Initialized
DEBUG - 2023-05-01 15:07:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 15:07:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:07:50 --> Final output sent to browser
DEBUG - 2023-05-01 15:07:50 --> Total execution time: 0.0578
INFO - 2023-05-01 15:07:54 --> Config Class Initialized
INFO - 2023-05-01 15:07:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:54 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:54 --> URI Class Initialized
INFO - 2023-05-01 15:07:54 --> Router Class Initialized
INFO - 2023-05-01 15:07:54 --> Output Class Initialized
INFO - 2023-05-01 15:07:54 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:54 --> Input Class Initialized
INFO - 2023-05-01 15:07:54 --> Language Class Initialized
INFO - 2023-05-01 15:07:54 --> Language Class Initialized
INFO - 2023-05-01 15:07:54 --> Config Class Initialized
INFO - 2023-05-01 15:07:54 --> Loader Class Initialized
INFO - 2023-05-01 15:07:54 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:54 --> Controller Class Initialized
INFO - 2023-05-01 15:07:54 --> Config Class Initialized
INFO - 2023-05-01 15:07:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:54 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:54 --> URI Class Initialized
INFO - 2023-05-01 15:07:54 --> Router Class Initialized
INFO - 2023-05-01 15:07:54 --> Output Class Initialized
INFO - 2023-05-01 15:07:54 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:54 --> Input Class Initialized
INFO - 2023-05-01 15:07:54 --> Language Class Initialized
INFO - 2023-05-01 15:07:54 --> Language Class Initialized
INFO - 2023-05-01 15:07:54 --> Config Class Initialized
INFO - 2023-05-01 15:07:54 --> Loader Class Initialized
INFO - 2023-05-01 15:07:54 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:54 --> Controller Class Initialized
DEBUG - 2023-05-01 15:07:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 15:07:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:07:54 --> Final output sent to browser
DEBUG - 2023-05-01 15:07:54 --> Total execution time: 0.0667
INFO - 2023-05-01 15:07:54 --> Config Class Initialized
INFO - 2023-05-01 15:07:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:54 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:54 --> URI Class Initialized
INFO - 2023-05-01 15:07:54 --> Router Class Initialized
INFO - 2023-05-01 15:07:54 --> Output Class Initialized
INFO - 2023-05-01 15:07:54 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:54 --> Input Class Initialized
INFO - 2023-05-01 15:07:54 --> Language Class Initialized
INFO - 2023-05-01 15:07:54 --> Language Class Initialized
INFO - 2023-05-01 15:07:54 --> Config Class Initialized
INFO - 2023-05-01 15:07:54 --> Loader Class Initialized
INFO - 2023-05-01 15:07:54 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:54 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:54 --> Controller Class Initialized
INFO - 2023-05-01 15:07:56 --> Config Class Initialized
INFO - 2023-05-01 15:07:56 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:56 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:56 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:56 --> URI Class Initialized
INFO - 2023-05-01 15:07:56 --> Router Class Initialized
INFO - 2023-05-01 15:07:56 --> Output Class Initialized
INFO - 2023-05-01 15:07:56 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:56 --> Input Class Initialized
INFO - 2023-05-01 15:07:56 --> Language Class Initialized
INFO - 2023-05-01 15:07:56 --> Language Class Initialized
INFO - 2023-05-01 15:07:56 --> Config Class Initialized
INFO - 2023-05-01 15:07:56 --> Loader Class Initialized
INFO - 2023-05-01 15:07:56 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:56 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:56 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:56 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:56 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:56 --> Controller Class Initialized
DEBUG - 2023-05-01 15:07:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:07:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:07:56 --> Final output sent to browser
DEBUG - 2023-05-01 15:07:56 --> Total execution time: 0.0638
INFO - 2023-05-01 15:07:57 --> Config Class Initialized
INFO - 2023-05-01 15:07:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:57 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:57 --> URI Class Initialized
INFO - 2023-05-01 15:07:57 --> Router Class Initialized
INFO - 2023-05-01 15:07:57 --> Output Class Initialized
INFO - 2023-05-01 15:07:57 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:57 --> Input Class Initialized
INFO - 2023-05-01 15:07:58 --> Language Class Initialized
INFO - 2023-05-01 15:07:58 --> Language Class Initialized
INFO - 2023-05-01 15:07:58 --> Config Class Initialized
INFO - 2023-05-01 15:07:58 --> Loader Class Initialized
INFO - 2023-05-01 15:07:58 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:58 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:58 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:58 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:58 --> Controller Class Initialized
DEBUG - 2023-05-01 15:07:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 15:07:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:07:58 --> Final output sent to browser
DEBUG - 2023-05-01 15:07:58 --> Total execution time: 0.0644
INFO - 2023-05-01 15:07:58 --> Config Class Initialized
INFO - 2023-05-01 15:07:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:58 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:58 --> URI Class Initialized
INFO - 2023-05-01 15:07:58 --> Router Class Initialized
INFO - 2023-05-01 15:07:58 --> Output Class Initialized
INFO - 2023-05-01 15:07:58 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:58 --> Input Class Initialized
INFO - 2023-05-01 15:07:58 --> Language Class Initialized
INFO - 2023-05-01 15:07:58 --> Language Class Initialized
INFO - 2023-05-01 15:07:58 --> Config Class Initialized
INFO - 2023-05-01 15:07:58 --> Loader Class Initialized
INFO - 2023-05-01 15:07:58 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:58 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:58 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:58 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:58 --> Controller Class Initialized
INFO - 2023-05-01 15:07:59 --> Config Class Initialized
INFO - 2023-05-01 15:07:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:07:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:07:59 --> Utf8 Class Initialized
INFO - 2023-05-01 15:07:59 --> URI Class Initialized
INFO - 2023-05-01 15:07:59 --> Router Class Initialized
INFO - 2023-05-01 15:07:59 --> Output Class Initialized
INFO - 2023-05-01 15:07:59 --> Security Class Initialized
DEBUG - 2023-05-01 15:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:07:59 --> Input Class Initialized
INFO - 2023-05-01 15:07:59 --> Language Class Initialized
INFO - 2023-05-01 15:07:59 --> Language Class Initialized
INFO - 2023-05-01 15:07:59 --> Config Class Initialized
INFO - 2023-05-01 15:07:59 --> Loader Class Initialized
INFO - 2023-05-01 15:07:59 --> Helper loaded: url_helper
INFO - 2023-05-01 15:07:59 --> Helper loaded: file_helper
INFO - 2023-05-01 15:07:59 --> Helper loaded: form_helper
INFO - 2023-05-01 15:07:59 --> Helper loaded: my_helper
INFO - 2023-05-01 15:07:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:07:59 --> Controller Class Initialized
INFO - 2023-05-01 15:07:59 --> Final output sent to browser
DEBUG - 2023-05-01 15:07:59 --> Total execution time: 0.0620
INFO - 2023-05-01 15:08:44 --> Config Class Initialized
INFO - 2023-05-01 15:08:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:44 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:44 --> URI Class Initialized
INFO - 2023-05-01 15:08:44 --> Router Class Initialized
INFO - 2023-05-01 15:08:44 --> Output Class Initialized
INFO - 2023-05-01 15:08:44 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:44 --> Input Class Initialized
INFO - 2023-05-01 15:08:44 --> Language Class Initialized
INFO - 2023-05-01 15:08:44 --> Language Class Initialized
INFO - 2023-05-01 15:08:44 --> Config Class Initialized
INFO - 2023-05-01 15:08:44 --> Loader Class Initialized
INFO - 2023-05-01 15:08:44 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:44 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:44 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:44 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:44 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:44 --> Controller Class Initialized
DEBUG - 2023-05-01 15:08:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 15:08:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:08:44 --> Final output sent to browser
DEBUG - 2023-05-01 15:08:44 --> Total execution time: 0.0469
INFO - 2023-05-01 15:08:47 --> Config Class Initialized
INFO - 2023-05-01 15:08:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:47 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:47 --> URI Class Initialized
INFO - 2023-05-01 15:08:47 --> Router Class Initialized
INFO - 2023-05-01 15:08:47 --> Output Class Initialized
INFO - 2023-05-01 15:08:47 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:47 --> Input Class Initialized
INFO - 2023-05-01 15:08:47 --> Language Class Initialized
INFO - 2023-05-01 15:08:47 --> Language Class Initialized
INFO - 2023-05-01 15:08:47 --> Config Class Initialized
INFO - 2023-05-01 15:08:47 --> Loader Class Initialized
INFO - 2023-05-01 15:08:47 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:47 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:47 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:47 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:47 --> Controller Class Initialized
INFO - 2023-05-01 15:08:48 --> Config Class Initialized
INFO - 2023-05-01 15:08:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:48 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:48 --> URI Class Initialized
INFO - 2023-05-01 15:08:48 --> Router Class Initialized
INFO - 2023-05-01 15:08:48 --> Output Class Initialized
INFO - 2023-05-01 15:08:48 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:48 --> Input Class Initialized
INFO - 2023-05-01 15:08:48 --> Language Class Initialized
INFO - 2023-05-01 15:08:48 --> Language Class Initialized
INFO - 2023-05-01 15:08:48 --> Config Class Initialized
INFO - 2023-05-01 15:08:48 --> Loader Class Initialized
INFO - 2023-05-01 15:08:48 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:48 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:48 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:48 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:48 --> Controller Class Initialized
DEBUG - 2023-05-01 15:08:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 15:08:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:08:48 --> Final output sent to browser
DEBUG - 2023-05-01 15:08:48 --> Total execution time: 0.0508
INFO - 2023-05-01 15:08:48 --> Config Class Initialized
INFO - 2023-05-01 15:08:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:48 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:48 --> URI Class Initialized
INFO - 2023-05-01 15:08:48 --> Router Class Initialized
INFO - 2023-05-01 15:08:48 --> Output Class Initialized
INFO - 2023-05-01 15:08:48 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:48 --> Input Class Initialized
INFO - 2023-05-01 15:08:48 --> Language Class Initialized
INFO - 2023-05-01 15:08:48 --> Language Class Initialized
INFO - 2023-05-01 15:08:48 --> Config Class Initialized
INFO - 2023-05-01 15:08:48 --> Loader Class Initialized
INFO - 2023-05-01 15:08:48 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:48 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:48 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:48 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:48 --> Controller Class Initialized
INFO - 2023-05-01 15:08:49 --> Config Class Initialized
INFO - 2023-05-01 15:08:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:49 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:49 --> URI Class Initialized
DEBUG - 2023-05-01 15:08:49 --> No URI present. Default controller set.
INFO - 2023-05-01 15:08:49 --> Router Class Initialized
INFO - 2023-05-01 15:08:49 --> Output Class Initialized
INFO - 2023-05-01 15:08:49 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:49 --> Input Class Initialized
INFO - 2023-05-01 15:08:49 --> Language Class Initialized
INFO - 2023-05-01 15:08:49 --> Language Class Initialized
INFO - 2023-05-01 15:08:49 --> Config Class Initialized
INFO - 2023-05-01 15:08:49 --> Loader Class Initialized
INFO - 2023-05-01 15:08:49 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:49 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:49 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:49 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:49 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:49 --> Controller Class Initialized
DEBUG - 2023-05-01 15:08:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 15:08:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:08:49 --> Final output sent to browser
DEBUG - 2023-05-01 15:08:49 --> Total execution time: 0.0699
INFO - 2023-05-01 15:08:51 --> Config Class Initialized
INFO - 2023-05-01 15:08:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:51 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:51 --> URI Class Initialized
INFO - 2023-05-01 15:08:51 --> Router Class Initialized
INFO - 2023-05-01 15:08:51 --> Output Class Initialized
INFO - 2023-05-01 15:08:51 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:51 --> Input Class Initialized
INFO - 2023-05-01 15:08:51 --> Language Class Initialized
INFO - 2023-05-01 15:08:51 --> Language Class Initialized
INFO - 2023-05-01 15:08:51 --> Config Class Initialized
INFO - 2023-05-01 15:08:51 --> Loader Class Initialized
INFO - 2023-05-01 15:08:51 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:51 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:51 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:51 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:51 --> Controller Class Initialized
DEBUG - 2023-05-01 15:08:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:08:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:08:51 --> Final output sent to browser
DEBUG - 2023-05-01 15:08:51 --> Total execution time: 0.0635
INFO - 2023-05-01 15:08:52 --> Config Class Initialized
INFO - 2023-05-01 15:08:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:52 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:52 --> URI Class Initialized
INFO - 2023-05-01 15:08:52 --> Router Class Initialized
INFO - 2023-05-01 15:08:52 --> Output Class Initialized
INFO - 2023-05-01 15:08:52 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:52 --> Input Class Initialized
INFO - 2023-05-01 15:08:52 --> Language Class Initialized
INFO - 2023-05-01 15:08:52 --> Language Class Initialized
INFO - 2023-05-01 15:08:52 --> Config Class Initialized
INFO - 2023-05-01 15:08:52 --> Loader Class Initialized
INFO - 2023-05-01 15:08:52 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:52 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:52 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:52 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:52 --> Controller Class Initialized
DEBUG - 2023-05-01 15:08:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 15:08:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:08:52 --> Final output sent to browser
DEBUG - 2023-05-01 15:08:52 --> Total execution time: 0.0627
INFO - 2023-05-01 15:08:52 --> Config Class Initialized
INFO - 2023-05-01 15:08:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:52 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:52 --> URI Class Initialized
INFO - 2023-05-01 15:08:52 --> Router Class Initialized
INFO - 2023-05-01 15:08:52 --> Output Class Initialized
INFO - 2023-05-01 15:08:52 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:52 --> Input Class Initialized
INFO - 2023-05-01 15:08:52 --> Language Class Initialized
INFO - 2023-05-01 15:08:52 --> Language Class Initialized
INFO - 2023-05-01 15:08:52 --> Config Class Initialized
INFO - 2023-05-01 15:08:52 --> Loader Class Initialized
INFO - 2023-05-01 15:08:52 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:52 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:52 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:52 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:52 --> Controller Class Initialized
INFO - 2023-05-01 15:08:54 --> Config Class Initialized
INFO - 2023-05-01 15:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:08:54 --> Utf8 Class Initialized
INFO - 2023-05-01 15:08:54 --> URI Class Initialized
INFO - 2023-05-01 15:08:54 --> Router Class Initialized
INFO - 2023-05-01 15:08:54 --> Output Class Initialized
INFO - 2023-05-01 15:08:54 --> Security Class Initialized
DEBUG - 2023-05-01 15:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:08:54 --> Input Class Initialized
INFO - 2023-05-01 15:08:54 --> Language Class Initialized
INFO - 2023-05-01 15:08:54 --> Language Class Initialized
INFO - 2023-05-01 15:08:54 --> Config Class Initialized
INFO - 2023-05-01 15:08:54 --> Loader Class Initialized
INFO - 2023-05-01 15:08:54 --> Helper loaded: url_helper
INFO - 2023-05-01 15:08:54 --> Helper loaded: file_helper
INFO - 2023-05-01 15:08:54 --> Helper loaded: form_helper
INFO - 2023-05-01 15:08:54 --> Helper loaded: my_helper
INFO - 2023-05-01 15:08:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:08:54 --> Controller Class Initialized
INFO - 2023-05-01 15:08:54 --> Final output sent to browser
DEBUG - 2023-05-01 15:08:54 --> Total execution time: 0.0601
INFO - 2023-05-01 15:31:22 --> Config Class Initialized
INFO - 2023-05-01 15:31:22 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:31:22 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:31:22 --> Utf8 Class Initialized
INFO - 2023-05-01 15:31:22 --> URI Class Initialized
DEBUG - 2023-05-01 15:31:22 --> No URI present. Default controller set.
INFO - 2023-05-01 15:31:22 --> Router Class Initialized
INFO - 2023-05-01 15:31:22 --> Output Class Initialized
INFO - 2023-05-01 15:31:22 --> Security Class Initialized
DEBUG - 2023-05-01 15:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:31:22 --> Input Class Initialized
INFO - 2023-05-01 15:31:22 --> Language Class Initialized
INFO - 2023-05-01 15:31:22 --> Language Class Initialized
INFO - 2023-05-01 15:31:22 --> Config Class Initialized
INFO - 2023-05-01 15:31:22 --> Loader Class Initialized
INFO - 2023-05-01 15:31:22 --> Helper loaded: url_helper
INFO - 2023-05-01 15:31:22 --> Helper loaded: file_helper
INFO - 2023-05-01 15:31:22 --> Helper loaded: form_helper
INFO - 2023-05-01 15:31:22 --> Helper loaded: my_helper
INFO - 2023-05-01 15:31:22 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:31:22 --> Controller Class Initialized
DEBUG - 2023-05-01 15:31:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 15:31:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:31:22 --> Final output sent to browser
DEBUG - 2023-05-01 15:31:22 --> Total execution time: 0.0547
INFO - 2023-05-01 15:31:23 --> Config Class Initialized
INFO - 2023-05-01 15:31:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:31:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:31:23 --> Utf8 Class Initialized
INFO - 2023-05-01 15:31:23 --> URI Class Initialized
INFO - 2023-05-01 15:31:23 --> Router Class Initialized
INFO - 2023-05-01 15:31:23 --> Output Class Initialized
INFO - 2023-05-01 15:31:23 --> Security Class Initialized
DEBUG - 2023-05-01 15:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:31:23 --> Input Class Initialized
INFO - 2023-05-01 15:31:23 --> Language Class Initialized
INFO - 2023-05-01 15:31:23 --> Language Class Initialized
INFO - 2023-05-01 15:31:23 --> Config Class Initialized
INFO - 2023-05-01 15:31:23 --> Loader Class Initialized
INFO - 2023-05-01 15:31:23 --> Helper loaded: url_helper
INFO - 2023-05-01 15:31:23 --> Helper loaded: file_helper
INFO - 2023-05-01 15:31:23 --> Helper loaded: form_helper
INFO - 2023-05-01 15:31:23 --> Helper loaded: my_helper
INFO - 2023-05-01 15:31:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:31:23 --> Controller Class Initialized
DEBUG - 2023-05-01 15:31:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:31:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:31:23 --> Final output sent to browser
DEBUG - 2023-05-01 15:31:23 --> Total execution time: 0.0312
INFO - 2023-05-01 15:31:25 --> Config Class Initialized
INFO - 2023-05-01 15:31:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:31:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:31:25 --> Utf8 Class Initialized
INFO - 2023-05-01 15:31:25 --> URI Class Initialized
INFO - 2023-05-01 15:31:25 --> Router Class Initialized
INFO - 2023-05-01 15:31:25 --> Output Class Initialized
INFO - 2023-05-01 15:31:25 --> Security Class Initialized
DEBUG - 2023-05-01 15:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:31:25 --> Input Class Initialized
INFO - 2023-05-01 15:31:25 --> Language Class Initialized
INFO - 2023-05-01 15:31:25 --> Language Class Initialized
INFO - 2023-05-01 15:31:25 --> Config Class Initialized
INFO - 2023-05-01 15:31:25 --> Loader Class Initialized
INFO - 2023-05-01 15:31:25 --> Helper loaded: url_helper
INFO - 2023-05-01 15:31:25 --> Helper loaded: file_helper
INFO - 2023-05-01 15:31:25 --> Helper loaded: form_helper
INFO - 2023-05-01 15:31:25 --> Helper loaded: my_helper
INFO - 2023-05-01 15:31:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:31:25 --> Controller Class Initialized
DEBUG - 2023-05-01 15:31:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:31:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:31:25 --> Final output sent to browser
DEBUG - 2023-05-01 15:31:25 --> Total execution time: 0.0342
INFO - 2023-05-01 15:31:26 --> Config Class Initialized
INFO - 2023-05-01 15:31:26 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:31:26 --> Utf8 Class Initialized
INFO - 2023-05-01 15:31:26 --> URI Class Initialized
INFO - 2023-05-01 15:31:26 --> Router Class Initialized
INFO - 2023-05-01 15:31:26 --> Output Class Initialized
INFO - 2023-05-01 15:31:26 --> Security Class Initialized
DEBUG - 2023-05-01 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:31:26 --> Input Class Initialized
INFO - 2023-05-01 15:31:26 --> Language Class Initialized
INFO - 2023-05-01 15:31:26 --> Language Class Initialized
INFO - 2023-05-01 15:31:26 --> Config Class Initialized
INFO - 2023-05-01 15:31:26 --> Loader Class Initialized
INFO - 2023-05-01 15:31:26 --> Helper loaded: url_helper
INFO - 2023-05-01 15:31:26 --> Helper loaded: file_helper
INFO - 2023-05-01 15:31:26 --> Helper loaded: form_helper
INFO - 2023-05-01 15:31:26 --> Helper loaded: my_helper
INFO - 2023-05-01 15:31:27 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:31:27 --> Controller Class Initialized
INFO - 2023-05-01 15:31:27 --> Final output sent to browser
DEBUG - 2023-05-01 15:31:27 --> Total execution time: 0.0292
INFO - 2023-05-01 15:37:34 --> Config Class Initialized
INFO - 2023-05-01 15:37:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:37:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:37:34 --> Utf8 Class Initialized
INFO - 2023-05-01 15:37:34 --> URI Class Initialized
INFO - 2023-05-01 15:37:34 --> Router Class Initialized
INFO - 2023-05-01 15:37:34 --> Output Class Initialized
INFO - 2023-05-01 15:37:34 --> Security Class Initialized
DEBUG - 2023-05-01 15:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:37:34 --> Input Class Initialized
INFO - 2023-05-01 15:37:34 --> Language Class Initialized
INFO - 2023-05-01 15:37:34 --> Language Class Initialized
INFO - 2023-05-01 15:37:34 --> Config Class Initialized
INFO - 2023-05-01 15:37:34 --> Loader Class Initialized
INFO - 2023-05-01 15:37:34 --> Helper loaded: url_helper
INFO - 2023-05-01 15:37:34 --> Helper loaded: file_helper
INFO - 2023-05-01 15:37:34 --> Helper loaded: form_helper
INFO - 2023-05-01 15:37:34 --> Helper loaded: my_helper
INFO - 2023-05-01 15:37:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:37:34 --> Controller Class Initialized
DEBUG - 2023-05-01 15:37:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:37:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:37:34 --> Final output sent to browser
DEBUG - 2023-05-01 15:37:34 --> Total execution time: 0.0437
INFO - 2023-05-01 15:38:55 --> Config Class Initialized
INFO - 2023-05-01 15:38:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:38:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:38:55 --> Utf8 Class Initialized
INFO - 2023-05-01 15:38:55 --> URI Class Initialized
INFO - 2023-05-01 15:38:55 --> Router Class Initialized
INFO - 2023-05-01 15:38:55 --> Output Class Initialized
INFO - 2023-05-01 15:38:55 --> Security Class Initialized
DEBUG - 2023-05-01 15:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:38:55 --> Input Class Initialized
INFO - 2023-05-01 15:38:55 --> Language Class Initialized
INFO - 2023-05-01 15:38:55 --> Language Class Initialized
INFO - 2023-05-01 15:38:55 --> Config Class Initialized
INFO - 2023-05-01 15:38:55 --> Loader Class Initialized
INFO - 2023-05-01 15:38:55 --> Helper loaded: url_helper
INFO - 2023-05-01 15:38:55 --> Helper loaded: file_helper
INFO - 2023-05-01 15:38:55 --> Helper loaded: form_helper
INFO - 2023-05-01 15:38:55 --> Helper loaded: my_helper
INFO - 2023-05-01 15:38:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:38:55 --> Controller Class Initialized
DEBUG - 2023-05-01 15:38:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 15:38:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:38:55 --> Final output sent to browser
DEBUG - 2023-05-01 15:38:55 --> Total execution time: 0.0339
INFO - 2023-05-01 15:38:55 --> Config Class Initialized
INFO - 2023-05-01 15:38:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:38:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:38:55 --> Utf8 Class Initialized
INFO - 2023-05-01 15:38:55 --> URI Class Initialized
INFO - 2023-05-01 15:38:55 --> Router Class Initialized
INFO - 2023-05-01 15:38:55 --> Output Class Initialized
INFO - 2023-05-01 15:38:55 --> Security Class Initialized
DEBUG - 2023-05-01 15:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:38:55 --> Input Class Initialized
INFO - 2023-05-01 15:38:55 --> Language Class Initialized
INFO - 2023-05-01 15:38:55 --> Language Class Initialized
INFO - 2023-05-01 15:38:55 --> Config Class Initialized
INFO - 2023-05-01 15:38:55 --> Loader Class Initialized
INFO - 2023-05-01 15:38:55 --> Helper loaded: url_helper
INFO - 2023-05-01 15:38:55 --> Helper loaded: file_helper
INFO - 2023-05-01 15:38:55 --> Helper loaded: form_helper
INFO - 2023-05-01 15:38:55 --> Helper loaded: my_helper
INFO - 2023-05-01 15:38:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:38:55 --> Controller Class Initialized
INFO - 2023-05-01 15:38:58 --> Config Class Initialized
INFO - 2023-05-01 15:38:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:38:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:38:58 --> Utf8 Class Initialized
INFO - 2023-05-01 15:38:58 --> URI Class Initialized
INFO - 2023-05-01 15:38:58 --> Router Class Initialized
INFO - 2023-05-01 15:38:58 --> Output Class Initialized
INFO - 2023-05-01 15:38:58 --> Security Class Initialized
DEBUG - 2023-05-01 15:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:38:58 --> Input Class Initialized
INFO - 2023-05-01 15:38:58 --> Language Class Initialized
INFO - 2023-05-01 15:38:58 --> Language Class Initialized
INFO - 2023-05-01 15:38:58 --> Config Class Initialized
INFO - 2023-05-01 15:38:58 --> Loader Class Initialized
INFO - 2023-05-01 15:38:58 --> Helper loaded: url_helper
INFO - 2023-05-01 15:38:58 --> Helper loaded: file_helper
INFO - 2023-05-01 15:38:58 --> Helper loaded: form_helper
INFO - 2023-05-01 15:38:58 --> Helper loaded: my_helper
INFO - 2023-05-01 15:38:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:38:58 --> Controller Class Initialized
DEBUG - 2023-05-01 15:38:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:38:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:38:58 --> Final output sent to browser
DEBUG - 2023-05-01 15:38:58 --> Total execution time: 0.0295
INFO - 2023-05-01 15:47:31 --> Config Class Initialized
INFO - 2023-05-01 15:47:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:47:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:47:31 --> Utf8 Class Initialized
INFO - 2023-05-01 15:47:31 --> URI Class Initialized
INFO - 2023-05-01 15:47:31 --> Router Class Initialized
INFO - 2023-05-01 15:47:31 --> Output Class Initialized
INFO - 2023-05-01 15:47:31 --> Security Class Initialized
DEBUG - 2023-05-01 15:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:47:31 --> Input Class Initialized
INFO - 2023-05-01 15:47:31 --> Language Class Initialized
INFO - 2023-05-01 15:47:31 --> Language Class Initialized
INFO - 2023-05-01 15:47:31 --> Config Class Initialized
INFO - 2023-05-01 15:47:31 --> Loader Class Initialized
INFO - 2023-05-01 15:47:31 --> Helper loaded: url_helper
INFO - 2023-05-01 15:47:31 --> Helper loaded: file_helper
INFO - 2023-05-01 15:47:31 --> Helper loaded: form_helper
INFO - 2023-05-01 15:47:31 --> Helper loaded: my_helper
INFO - 2023-05-01 15:47:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:47:31 --> Controller Class Initialized
DEBUG - 2023-05-01 15:47:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:47:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:47:31 --> Final output sent to browser
DEBUG - 2023-05-01 15:47:31 --> Total execution time: 0.0348
INFO - 2023-05-01 15:47:33 --> Config Class Initialized
INFO - 2023-05-01 15:47:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:47:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:47:33 --> Utf8 Class Initialized
INFO - 2023-05-01 15:47:33 --> URI Class Initialized
INFO - 2023-05-01 15:47:33 --> Router Class Initialized
INFO - 2023-05-01 15:47:33 --> Output Class Initialized
INFO - 2023-05-01 15:47:33 --> Security Class Initialized
DEBUG - 2023-05-01 15:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:47:33 --> Input Class Initialized
INFO - 2023-05-01 15:47:33 --> Language Class Initialized
INFO - 2023-05-01 15:47:33 --> Language Class Initialized
INFO - 2023-05-01 15:47:33 --> Config Class Initialized
INFO - 2023-05-01 15:47:33 --> Loader Class Initialized
INFO - 2023-05-01 15:47:33 --> Helper loaded: url_helper
INFO - 2023-05-01 15:47:33 --> Helper loaded: file_helper
INFO - 2023-05-01 15:47:33 --> Helper loaded: form_helper
INFO - 2023-05-01 15:47:33 --> Helper loaded: my_helper
INFO - 2023-05-01 15:47:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:47:33 --> Controller Class Initialized
DEBUG - 2023-05-01 15:47:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:47:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:47:33 --> Final output sent to browser
DEBUG - 2023-05-01 15:47:33 --> Total execution time: 0.0480
INFO - 2023-05-01 15:47:34 --> Config Class Initialized
INFO - 2023-05-01 15:47:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:47:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:47:34 --> Utf8 Class Initialized
INFO - 2023-05-01 15:47:34 --> URI Class Initialized
INFO - 2023-05-01 15:47:34 --> Router Class Initialized
INFO - 2023-05-01 15:47:34 --> Output Class Initialized
INFO - 2023-05-01 15:47:34 --> Security Class Initialized
DEBUG - 2023-05-01 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:47:34 --> Input Class Initialized
INFO - 2023-05-01 15:47:34 --> Language Class Initialized
INFO - 2023-05-01 15:47:34 --> Language Class Initialized
INFO - 2023-05-01 15:47:34 --> Config Class Initialized
INFO - 2023-05-01 15:47:34 --> Loader Class Initialized
INFO - 2023-05-01 15:47:34 --> Helper loaded: url_helper
INFO - 2023-05-01 15:47:34 --> Helper loaded: file_helper
INFO - 2023-05-01 15:47:34 --> Helper loaded: form_helper
INFO - 2023-05-01 15:47:34 --> Helper loaded: my_helper
INFO - 2023-05-01 15:47:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:47:34 --> Controller Class Initialized
INFO - 2023-05-01 15:47:34 --> Final output sent to browser
DEBUG - 2023-05-01 15:47:34 --> Total execution time: 0.0485
INFO - 2023-05-01 15:48:12 --> Config Class Initialized
INFO - 2023-05-01 15:48:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:48:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:48:12 --> Utf8 Class Initialized
INFO - 2023-05-01 15:48:12 --> URI Class Initialized
INFO - 2023-05-01 15:48:12 --> Router Class Initialized
INFO - 2023-05-01 15:48:12 --> Output Class Initialized
INFO - 2023-05-01 15:48:12 --> Security Class Initialized
DEBUG - 2023-05-01 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:48:12 --> Input Class Initialized
INFO - 2023-05-01 15:48:12 --> Language Class Initialized
INFO - 2023-05-01 15:48:12 --> Language Class Initialized
INFO - 2023-05-01 15:48:12 --> Config Class Initialized
INFO - 2023-05-01 15:48:12 --> Loader Class Initialized
INFO - 2023-05-01 15:48:12 --> Helper loaded: url_helper
INFO - 2023-05-01 15:48:12 --> Helper loaded: file_helper
INFO - 2023-05-01 15:48:12 --> Helper loaded: form_helper
INFO - 2023-05-01 15:48:12 --> Helper loaded: my_helper
INFO - 2023-05-01 15:48:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:48:12 --> Controller Class Initialized
ERROR - 2023-05-01 15:48:12 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
ERROR - 2023-05-01 15:48:12 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
INFO - 2023-05-01 15:51:21 --> Config Class Initialized
INFO - 2023-05-01 15:51:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:51:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:51:21 --> Utf8 Class Initialized
INFO - 2023-05-01 15:51:21 --> URI Class Initialized
INFO - 2023-05-01 15:51:21 --> Router Class Initialized
INFO - 2023-05-01 15:51:21 --> Output Class Initialized
INFO - 2023-05-01 15:51:21 --> Security Class Initialized
DEBUG - 2023-05-01 15:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:51:21 --> Input Class Initialized
INFO - 2023-05-01 15:51:21 --> Language Class Initialized
INFO - 2023-05-01 15:51:21 --> Language Class Initialized
INFO - 2023-05-01 15:51:21 --> Config Class Initialized
INFO - 2023-05-01 15:51:21 --> Loader Class Initialized
INFO - 2023-05-01 15:51:21 --> Helper loaded: url_helper
INFO - 2023-05-01 15:51:21 --> Helper loaded: file_helper
INFO - 2023-05-01 15:51:21 --> Helper loaded: form_helper
INFO - 2023-05-01 15:51:21 --> Helper loaded: my_helper
INFO - 2023-05-01 15:51:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:51:21 --> Controller Class Initialized
INFO - 2023-05-01 15:51:21 --> Final output sent to browser
DEBUG - 2023-05-01 15:51:21 --> Total execution time: 0.0404
INFO - 2023-05-01 15:51:24 --> Config Class Initialized
INFO - 2023-05-01 15:51:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:51:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:51:24 --> Utf8 Class Initialized
INFO - 2023-05-01 15:51:24 --> URI Class Initialized
INFO - 2023-05-01 15:51:24 --> Router Class Initialized
INFO - 2023-05-01 15:51:24 --> Output Class Initialized
INFO - 2023-05-01 15:51:24 --> Security Class Initialized
DEBUG - 2023-05-01 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:51:24 --> Input Class Initialized
INFO - 2023-05-01 15:51:24 --> Language Class Initialized
INFO - 2023-05-01 15:51:24 --> Language Class Initialized
INFO - 2023-05-01 15:51:24 --> Config Class Initialized
INFO - 2023-05-01 15:51:24 --> Loader Class Initialized
INFO - 2023-05-01 15:51:24 --> Helper loaded: url_helper
INFO - 2023-05-01 15:51:24 --> Helper loaded: file_helper
INFO - 2023-05-01 15:51:24 --> Helper loaded: form_helper
INFO - 2023-05-01 15:51:24 --> Helper loaded: my_helper
INFO - 2023-05-01 15:51:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:51:24 --> Controller Class Initialized
DEBUG - 2023-05-01 15:51:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:51:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:51:24 --> Final output sent to browser
DEBUG - 2023-05-01 15:51:24 --> Total execution time: 0.0349
INFO - 2023-05-01 15:51:25 --> Config Class Initialized
INFO - 2023-05-01 15:51:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:51:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:51:25 --> Utf8 Class Initialized
INFO - 2023-05-01 15:51:25 --> URI Class Initialized
INFO - 2023-05-01 15:51:25 --> Router Class Initialized
INFO - 2023-05-01 15:51:25 --> Output Class Initialized
INFO - 2023-05-01 15:51:25 --> Security Class Initialized
DEBUG - 2023-05-01 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:51:25 --> Input Class Initialized
INFO - 2023-05-01 15:51:25 --> Language Class Initialized
INFO - 2023-05-01 15:51:25 --> Language Class Initialized
INFO - 2023-05-01 15:51:25 --> Config Class Initialized
INFO - 2023-05-01 15:51:25 --> Loader Class Initialized
INFO - 2023-05-01 15:51:25 --> Helper loaded: url_helper
INFO - 2023-05-01 15:51:25 --> Helper loaded: file_helper
INFO - 2023-05-01 15:51:25 --> Helper loaded: form_helper
INFO - 2023-05-01 15:51:25 --> Helper loaded: my_helper
INFO - 2023-05-01 15:51:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:51:25 --> Controller Class Initialized
INFO - 2023-05-01 15:51:25 --> Final output sent to browser
DEBUG - 2023-05-01 15:51:25 --> Total execution time: 0.0424
INFO - 2023-05-01 15:51:51 --> Config Class Initialized
INFO - 2023-05-01 15:51:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:51:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:51:51 --> Utf8 Class Initialized
INFO - 2023-05-01 15:51:51 --> URI Class Initialized
INFO - 2023-05-01 15:51:51 --> Router Class Initialized
INFO - 2023-05-01 15:51:51 --> Output Class Initialized
INFO - 2023-05-01 15:51:51 --> Security Class Initialized
DEBUG - 2023-05-01 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:51:51 --> Input Class Initialized
INFO - 2023-05-01 15:51:51 --> Language Class Initialized
INFO - 2023-05-01 15:51:51 --> Language Class Initialized
INFO - 2023-05-01 15:51:51 --> Config Class Initialized
INFO - 2023-05-01 15:51:51 --> Loader Class Initialized
INFO - 2023-05-01 15:51:51 --> Helper loaded: url_helper
INFO - 2023-05-01 15:51:51 --> Helper loaded: file_helper
INFO - 2023-05-01 15:51:51 --> Helper loaded: form_helper
INFO - 2023-05-01 15:51:51 --> Helper loaded: my_helper
INFO - 2023-05-01 15:51:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:51:51 --> Controller Class Initialized
DEBUG - 2023-05-01 15:51:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:51:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:51:51 --> Final output sent to browser
DEBUG - 2023-05-01 15:51:51 --> Total execution time: 0.0348
INFO - 2023-05-01 15:51:52 --> Config Class Initialized
INFO - 2023-05-01 15:51:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:51:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:51:52 --> Utf8 Class Initialized
INFO - 2023-05-01 15:51:52 --> URI Class Initialized
INFO - 2023-05-01 15:51:52 --> Router Class Initialized
INFO - 2023-05-01 15:51:52 --> Output Class Initialized
INFO - 2023-05-01 15:51:52 --> Security Class Initialized
DEBUG - 2023-05-01 15:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:51:52 --> Input Class Initialized
INFO - 2023-05-01 15:51:52 --> Language Class Initialized
INFO - 2023-05-01 15:51:52 --> Language Class Initialized
INFO - 2023-05-01 15:51:52 --> Config Class Initialized
INFO - 2023-05-01 15:51:52 --> Loader Class Initialized
INFO - 2023-05-01 15:51:52 --> Helper loaded: url_helper
INFO - 2023-05-01 15:51:52 --> Helper loaded: file_helper
INFO - 2023-05-01 15:51:52 --> Helper loaded: form_helper
INFO - 2023-05-01 15:51:52 --> Helper loaded: my_helper
INFO - 2023-05-01 15:51:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:51:52 --> Controller Class Initialized
DEBUG - 2023-05-01 15:51:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:51:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:51:52 --> Final output sent to browser
DEBUG - 2023-05-01 15:51:52 --> Total execution time: 0.0314
INFO - 2023-05-01 15:51:54 --> Config Class Initialized
INFO - 2023-05-01 15:51:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:51:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:51:54 --> Utf8 Class Initialized
INFO - 2023-05-01 15:51:54 --> URI Class Initialized
INFO - 2023-05-01 15:51:54 --> Router Class Initialized
INFO - 2023-05-01 15:51:54 --> Output Class Initialized
INFO - 2023-05-01 15:51:54 --> Security Class Initialized
DEBUG - 2023-05-01 15:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:51:54 --> Input Class Initialized
INFO - 2023-05-01 15:51:54 --> Language Class Initialized
INFO - 2023-05-01 15:51:54 --> Language Class Initialized
INFO - 2023-05-01 15:51:54 --> Config Class Initialized
INFO - 2023-05-01 15:51:54 --> Loader Class Initialized
INFO - 2023-05-01 15:51:54 --> Helper loaded: url_helper
INFO - 2023-05-01 15:51:54 --> Helper loaded: file_helper
INFO - 2023-05-01 15:51:54 --> Helper loaded: form_helper
INFO - 2023-05-01 15:51:54 --> Helper loaded: my_helper
INFO - 2023-05-01 15:51:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:51:54 --> Controller Class Initialized
INFO - 2023-05-01 15:51:54 --> Final output sent to browser
DEBUG - 2023-05-01 15:51:54 --> Total execution time: 0.0530
INFO - 2023-05-01 15:52:00 --> Config Class Initialized
INFO - 2023-05-01 15:52:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:52:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:52:00 --> Utf8 Class Initialized
INFO - 2023-05-01 15:52:00 --> URI Class Initialized
INFO - 2023-05-01 15:52:00 --> Router Class Initialized
INFO - 2023-05-01 15:52:00 --> Output Class Initialized
INFO - 2023-05-01 15:52:00 --> Security Class Initialized
DEBUG - 2023-05-01 15:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:52:00 --> Input Class Initialized
INFO - 2023-05-01 15:52:00 --> Language Class Initialized
INFO - 2023-05-01 15:52:00 --> Language Class Initialized
INFO - 2023-05-01 15:52:00 --> Config Class Initialized
INFO - 2023-05-01 15:52:00 --> Loader Class Initialized
INFO - 2023-05-01 15:52:00 --> Helper loaded: url_helper
INFO - 2023-05-01 15:52:00 --> Helper loaded: file_helper
INFO - 2023-05-01 15:52:00 --> Helper loaded: form_helper
INFO - 2023-05-01 15:52:00 --> Helper loaded: my_helper
INFO - 2023-05-01 15:52:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:52:00 --> Controller Class Initialized
INFO - 2023-05-01 15:52:00 --> Final output sent to browser
DEBUG - 2023-05-01 15:52:00 --> Total execution time: 0.0356
INFO - 2023-05-01 15:52:09 --> Config Class Initialized
INFO - 2023-05-01 15:52:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:52:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:52:09 --> Utf8 Class Initialized
INFO - 2023-05-01 15:52:09 --> URI Class Initialized
INFO - 2023-05-01 15:52:09 --> Router Class Initialized
INFO - 2023-05-01 15:52:09 --> Output Class Initialized
INFO - 2023-05-01 15:52:09 --> Security Class Initialized
DEBUG - 2023-05-01 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:52:09 --> Input Class Initialized
INFO - 2023-05-01 15:52:09 --> Language Class Initialized
INFO - 2023-05-01 15:52:09 --> Language Class Initialized
INFO - 2023-05-01 15:52:09 --> Config Class Initialized
INFO - 2023-05-01 15:52:09 --> Loader Class Initialized
INFO - 2023-05-01 15:52:09 --> Helper loaded: url_helper
INFO - 2023-05-01 15:52:09 --> Helper loaded: file_helper
INFO - 2023-05-01 15:52:09 --> Helper loaded: form_helper
INFO - 2023-05-01 15:52:09 --> Helper loaded: my_helper
INFO - 2023-05-01 15:52:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:52:09 --> Controller Class Initialized
DEBUG - 2023-05-01 15:52:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:52:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:52:09 --> Final output sent to browser
DEBUG - 2023-05-01 15:52:09 --> Total execution time: 0.0465
INFO - 2023-05-01 15:52:11 --> Config Class Initialized
INFO - 2023-05-01 15:52:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:52:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:52:11 --> Utf8 Class Initialized
INFO - 2023-05-01 15:52:11 --> URI Class Initialized
INFO - 2023-05-01 15:52:11 --> Router Class Initialized
INFO - 2023-05-01 15:52:11 --> Output Class Initialized
INFO - 2023-05-01 15:52:11 --> Security Class Initialized
DEBUG - 2023-05-01 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:52:11 --> Input Class Initialized
INFO - 2023-05-01 15:52:11 --> Language Class Initialized
INFO - 2023-05-01 15:52:11 --> Language Class Initialized
INFO - 2023-05-01 15:52:11 --> Config Class Initialized
INFO - 2023-05-01 15:52:11 --> Loader Class Initialized
INFO - 2023-05-01 15:52:11 --> Helper loaded: url_helper
INFO - 2023-05-01 15:52:11 --> Helper loaded: file_helper
INFO - 2023-05-01 15:52:11 --> Helper loaded: form_helper
INFO - 2023-05-01 15:52:11 --> Helper loaded: my_helper
INFO - 2023-05-01 15:52:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:52:11 --> Controller Class Initialized
INFO - 2023-05-01 15:52:11 --> Final output sent to browser
DEBUG - 2023-05-01 15:52:11 --> Total execution time: 0.0396
INFO - 2023-05-01 15:52:21 --> Config Class Initialized
INFO - 2023-05-01 15:52:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:52:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:52:21 --> Utf8 Class Initialized
INFO - 2023-05-01 15:52:21 --> URI Class Initialized
INFO - 2023-05-01 15:52:21 --> Router Class Initialized
INFO - 2023-05-01 15:52:21 --> Output Class Initialized
INFO - 2023-05-01 15:52:21 --> Security Class Initialized
DEBUG - 2023-05-01 15:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:52:21 --> Input Class Initialized
INFO - 2023-05-01 15:52:21 --> Language Class Initialized
INFO - 2023-05-01 15:52:21 --> Language Class Initialized
INFO - 2023-05-01 15:52:21 --> Config Class Initialized
INFO - 2023-05-01 15:52:21 --> Loader Class Initialized
INFO - 2023-05-01 15:52:21 --> Helper loaded: url_helper
INFO - 2023-05-01 15:52:21 --> Helper loaded: file_helper
INFO - 2023-05-01 15:52:21 --> Helper loaded: form_helper
INFO - 2023-05-01 15:52:21 --> Helper loaded: my_helper
INFO - 2023-05-01 15:52:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:52:21 --> Controller Class Initialized
INFO - 2023-05-01 15:52:21 --> Final output sent to browser
DEBUG - 2023-05-01 15:52:21 --> Total execution time: 0.0315
INFO - 2023-05-01 15:55:17 --> Config Class Initialized
INFO - 2023-05-01 15:55:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:17 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:17 --> URI Class Initialized
INFO - 2023-05-01 15:55:17 --> Router Class Initialized
INFO - 2023-05-01 15:55:17 --> Output Class Initialized
INFO - 2023-05-01 15:55:17 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:17 --> Input Class Initialized
INFO - 2023-05-01 15:55:17 --> Language Class Initialized
INFO - 2023-05-01 15:55:17 --> Language Class Initialized
INFO - 2023-05-01 15:55:17 --> Config Class Initialized
INFO - 2023-05-01 15:55:17 --> Loader Class Initialized
INFO - 2023-05-01 15:55:17 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:17 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:17 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:17 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:17 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:55:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:17 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:17 --> Total execution time: 0.0571
INFO - 2023-05-01 15:55:18 --> Config Class Initialized
INFO - 2023-05-01 15:55:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:18 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:18 --> URI Class Initialized
INFO - 2023-05-01 15:55:18 --> Router Class Initialized
INFO - 2023-05-01 15:55:18 --> Output Class Initialized
INFO - 2023-05-01 15:55:18 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:18 --> Input Class Initialized
INFO - 2023-05-01 15:55:18 --> Language Class Initialized
INFO - 2023-05-01 15:55:18 --> Language Class Initialized
INFO - 2023-05-01 15:55:18 --> Config Class Initialized
INFO - 2023-05-01 15:55:18 --> Loader Class Initialized
INFO - 2023-05-01 15:55:18 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:18 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:18 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:18 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:18 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 15:55:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:18 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:18 --> Total execution time: 0.0298
INFO - 2023-05-01 15:55:18 --> Config Class Initialized
INFO - 2023-05-01 15:55:18 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:18 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:18 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:18 --> URI Class Initialized
INFO - 2023-05-01 15:55:18 --> Router Class Initialized
INFO - 2023-05-01 15:55:18 --> Output Class Initialized
INFO - 2023-05-01 15:55:18 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:18 --> Input Class Initialized
INFO - 2023-05-01 15:55:18 --> Language Class Initialized
INFO - 2023-05-01 15:55:18 --> Language Class Initialized
INFO - 2023-05-01 15:55:18 --> Config Class Initialized
INFO - 2023-05-01 15:55:18 --> Loader Class Initialized
INFO - 2023-05-01 15:55:18 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:18 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:18 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:18 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:18 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:18 --> Controller Class Initialized
INFO - 2023-05-01 15:55:19 --> Config Class Initialized
INFO - 2023-05-01 15:55:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:19 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:19 --> URI Class Initialized
INFO - 2023-05-01 15:55:19 --> Router Class Initialized
INFO - 2023-05-01 15:55:19 --> Output Class Initialized
INFO - 2023-05-01 15:55:19 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:19 --> Input Class Initialized
INFO - 2023-05-01 15:55:19 --> Language Class Initialized
INFO - 2023-05-01 15:55:19 --> Language Class Initialized
INFO - 2023-05-01 15:55:19 --> Config Class Initialized
INFO - 2023-05-01 15:55:19 --> Loader Class Initialized
INFO - 2023-05-01 15:55:19 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:19 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:19 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:19 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:19 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:19 --> Controller Class Initialized
INFO - 2023-05-01 15:55:19 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:19 --> Total execution time: 0.0424
INFO - 2023-05-01 15:55:23 --> Config Class Initialized
INFO - 2023-05-01 15:55:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:23 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:23 --> URI Class Initialized
INFO - 2023-05-01 15:55:23 --> Router Class Initialized
INFO - 2023-05-01 15:55:23 --> Output Class Initialized
INFO - 2023-05-01 15:55:23 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:23 --> Input Class Initialized
INFO - 2023-05-01 15:55:23 --> Language Class Initialized
INFO - 2023-05-01 15:55:23 --> Language Class Initialized
INFO - 2023-05-01 15:55:23 --> Config Class Initialized
INFO - 2023-05-01 15:55:23 --> Loader Class Initialized
INFO - 2023-05-01 15:55:23 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:23 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:23 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:23 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:23 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:55:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:23 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:23 --> Total execution time: 0.0507
INFO - 2023-05-01 15:55:24 --> Config Class Initialized
INFO - 2023-05-01 15:55:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:24 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:24 --> URI Class Initialized
INFO - 2023-05-01 15:55:24 --> Router Class Initialized
INFO - 2023-05-01 15:55:24 --> Output Class Initialized
INFO - 2023-05-01 15:55:24 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:24 --> Input Class Initialized
INFO - 2023-05-01 15:55:24 --> Language Class Initialized
INFO - 2023-05-01 15:55:24 --> Language Class Initialized
INFO - 2023-05-01 15:55:24 --> Config Class Initialized
INFO - 2023-05-01 15:55:24 --> Loader Class Initialized
INFO - 2023-05-01 15:55:24 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:24 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:24 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:24 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:24 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:55:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:24 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:24 --> Total execution time: 0.0443
INFO - 2023-05-01 15:55:26 --> Config Class Initialized
INFO - 2023-05-01 15:55:26 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:26 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:26 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:26 --> URI Class Initialized
INFO - 2023-05-01 15:55:26 --> Router Class Initialized
INFO - 2023-05-01 15:55:26 --> Output Class Initialized
INFO - 2023-05-01 15:55:26 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:26 --> Input Class Initialized
INFO - 2023-05-01 15:55:26 --> Language Class Initialized
INFO - 2023-05-01 15:55:26 --> Language Class Initialized
INFO - 2023-05-01 15:55:26 --> Config Class Initialized
INFO - 2023-05-01 15:55:26 --> Loader Class Initialized
INFO - 2023-05-01 15:55:26 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:26 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:26 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:26 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:26 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:26 --> Controller Class Initialized
INFO - 2023-05-01 15:55:26 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:26 --> Total execution time: 0.0282
INFO - 2023-05-01 15:55:27 --> Config Class Initialized
INFO - 2023-05-01 15:55:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:27 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:27 --> URI Class Initialized
INFO - 2023-05-01 15:55:27 --> Router Class Initialized
INFO - 2023-05-01 15:55:27 --> Output Class Initialized
INFO - 2023-05-01 15:55:27 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:27 --> Input Class Initialized
INFO - 2023-05-01 15:55:27 --> Language Class Initialized
INFO - 2023-05-01 15:55:27 --> Language Class Initialized
INFO - 2023-05-01 15:55:27 --> Config Class Initialized
INFO - 2023-05-01 15:55:27 --> Loader Class Initialized
INFO - 2023-05-01 15:55:27 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:27 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:27 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:27 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:27 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:27 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:55:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:27 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:27 --> Total execution time: 0.0331
INFO - 2023-05-01 15:55:28 --> Config Class Initialized
INFO - 2023-05-01 15:55:28 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:28 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:28 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:28 --> URI Class Initialized
INFO - 2023-05-01 15:55:28 --> Router Class Initialized
INFO - 2023-05-01 15:55:28 --> Output Class Initialized
INFO - 2023-05-01 15:55:28 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:28 --> Input Class Initialized
INFO - 2023-05-01 15:55:28 --> Language Class Initialized
INFO - 2023-05-01 15:55:28 --> Language Class Initialized
INFO - 2023-05-01 15:55:28 --> Config Class Initialized
INFO - 2023-05-01 15:55:28 --> Loader Class Initialized
INFO - 2023-05-01 15:55:28 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:28 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:28 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:28 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:28 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:28 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:55:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:28 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:28 --> Total execution time: 0.0304
INFO - 2023-05-01 15:55:29 --> Config Class Initialized
INFO - 2023-05-01 15:55:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:29 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:29 --> URI Class Initialized
INFO - 2023-05-01 15:55:29 --> Router Class Initialized
INFO - 2023-05-01 15:55:29 --> Output Class Initialized
INFO - 2023-05-01 15:55:29 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:29 --> Input Class Initialized
INFO - 2023-05-01 15:55:29 --> Language Class Initialized
INFO - 2023-05-01 15:55:29 --> Language Class Initialized
INFO - 2023-05-01 15:55:29 --> Config Class Initialized
INFO - 2023-05-01 15:55:29 --> Loader Class Initialized
INFO - 2023-05-01 15:55:29 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:29 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:29 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:29 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:29 --> Controller Class Initialized
INFO - 2023-05-01 15:55:29 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:29 --> Total execution time: 0.0513
INFO - 2023-05-01 15:55:36 --> Config Class Initialized
INFO - 2023-05-01 15:55:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:36 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:36 --> URI Class Initialized
INFO - 2023-05-01 15:55:36 --> Router Class Initialized
INFO - 2023-05-01 15:55:36 --> Output Class Initialized
INFO - 2023-05-01 15:55:36 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:36 --> Input Class Initialized
INFO - 2023-05-01 15:55:36 --> Language Class Initialized
INFO - 2023-05-01 15:55:36 --> Language Class Initialized
INFO - 2023-05-01 15:55:36 --> Config Class Initialized
INFO - 2023-05-01 15:55:36 --> Loader Class Initialized
INFO - 2023-05-01 15:55:36 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:36 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:36 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:36 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:36 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:55:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:36 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:36 --> Total execution time: 0.0321
INFO - 2023-05-01 15:55:37 --> Config Class Initialized
INFO - 2023-05-01 15:55:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:37 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:37 --> URI Class Initialized
INFO - 2023-05-01 15:55:37 --> Router Class Initialized
INFO - 2023-05-01 15:55:37 --> Output Class Initialized
INFO - 2023-05-01 15:55:37 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:37 --> Input Class Initialized
INFO - 2023-05-01 15:55:37 --> Language Class Initialized
INFO - 2023-05-01 15:55:37 --> Language Class Initialized
INFO - 2023-05-01 15:55:37 --> Config Class Initialized
INFO - 2023-05-01 15:55:37 --> Loader Class Initialized
INFO - 2023-05-01 15:55:37 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:37 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:37 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:37 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:37 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:55:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:37 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:37 --> Total execution time: 0.0332
INFO - 2023-05-01 15:55:38 --> Config Class Initialized
INFO - 2023-05-01 15:55:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:38 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:38 --> URI Class Initialized
INFO - 2023-05-01 15:55:38 --> Router Class Initialized
INFO - 2023-05-01 15:55:38 --> Output Class Initialized
INFO - 2023-05-01 15:55:38 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:38 --> Input Class Initialized
INFO - 2023-05-01 15:55:38 --> Language Class Initialized
INFO - 2023-05-01 15:55:38 --> Language Class Initialized
INFO - 2023-05-01 15:55:38 --> Config Class Initialized
INFO - 2023-05-01 15:55:38 --> Loader Class Initialized
INFO - 2023-05-01 15:55:38 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:38 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:38 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:38 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:38 --> Controller Class Initialized
INFO - 2023-05-01 15:55:38 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:38 --> Total execution time: 0.0290
INFO - 2023-05-01 15:55:45 --> Config Class Initialized
INFO - 2023-05-01 15:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:45 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:45 --> URI Class Initialized
INFO - 2023-05-01 15:55:45 --> Router Class Initialized
INFO - 2023-05-01 15:55:45 --> Output Class Initialized
INFO - 2023-05-01 15:55:45 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:45 --> Input Class Initialized
INFO - 2023-05-01 15:55:45 --> Language Class Initialized
INFO - 2023-05-01 15:55:45 --> Language Class Initialized
INFO - 2023-05-01 15:55:45 --> Config Class Initialized
INFO - 2023-05-01 15:55:45 --> Loader Class Initialized
INFO - 2023-05-01 15:55:45 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:45 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:45 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:45 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:45 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:55:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:45 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:45 --> Total execution time: 0.0328
INFO - 2023-05-01 15:55:47 --> Config Class Initialized
INFO - 2023-05-01 15:55:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:55:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:55:47 --> Utf8 Class Initialized
INFO - 2023-05-01 15:55:47 --> URI Class Initialized
INFO - 2023-05-01 15:55:47 --> Router Class Initialized
INFO - 2023-05-01 15:55:47 --> Output Class Initialized
INFO - 2023-05-01 15:55:47 --> Security Class Initialized
DEBUG - 2023-05-01 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:55:47 --> Input Class Initialized
INFO - 2023-05-01 15:55:47 --> Language Class Initialized
INFO - 2023-05-01 15:55:47 --> Language Class Initialized
INFO - 2023-05-01 15:55:47 --> Config Class Initialized
INFO - 2023-05-01 15:55:47 --> Loader Class Initialized
INFO - 2023-05-01 15:55:47 --> Helper loaded: url_helper
INFO - 2023-05-01 15:55:47 --> Helper loaded: file_helper
INFO - 2023-05-01 15:55:47 --> Helper loaded: form_helper
INFO - 2023-05-01 15:55:47 --> Helper loaded: my_helper
INFO - 2023-05-01 15:55:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:55:47 --> Controller Class Initialized
DEBUG - 2023-05-01 15:55:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:55:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:55:47 --> Final output sent to browser
DEBUG - 2023-05-01 15:55:47 --> Total execution time: 0.0559
INFO - 2023-05-01 15:56:02 --> Config Class Initialized
INFO - 2023-05-01 15:56:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:02 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:02 --> URI Class Initialized
INFO - 2023-05-01 15:56:02 --> Router Class Initialized
INFO - 2023-05-01 15:56:02 --> Output Class Initialized
INFO - 2023-05-01 15:56:02 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:02 --> Input Class Initialized
INFO - 2023-05-01 15:56:02 --> Language Class Initialized
INFO - 2023-05-01 15:56:02 --> Language Class Initialized
INFO - 2023-05-01 15:56:02 --> Config Class Initialized
INFO - 2023-05-01 15:56:02 --> Loader Class Initialized
INFO - 2023-05-01 15:56:02 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:02 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:02 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:02 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:02 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:02 --> Controller Class Initialized
INFO - 2023-05-01 15:56:02 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:02 --> Total execution time: 0.0406
INFO - 2023-05-01 15:56:03 --> Config Class Initialized
INFO - 2023-05-01 15:56:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:03 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:03 --> URI Class Initialized
INFO - 2023-05-01 15:56:03 --> Router Class Initialized
INFO - 2023-05-01 15:56:03 --> Output Class Initialized
INFO - 2023-05-01 15:56:03 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:03 --> Input Class Initialized
INFO - 2023-05-01 15:56:03 --> Language Class Initialized
INFO - 2023-05-01 15:56:03 --> Language Class Initialized
INFO - 2023-05-01 15:56:03 --> Config Class Initialized
INFO - 2023-05-01 15:56:03 --> Loader Class Initialized
INFO - 2023-05-01 15:56:03 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:03 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:03 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:03 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:03 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:04 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:56:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:04 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:04 --> Total execution time: 0.0593
INFO - 2023-05-01 15:56:05 --> Config Class Initialized
INFO - 2023-05-01 15:56:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:05 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:05 --> URI Class Initialized
INFO - 2023-05-01 15:56:05 --> Router Class Initialized
INFO - 2023-05-01 15:56:05 --> Output Class Initialized
INFO - 2023-05-01 15:56:05 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:05 --> Input Class Initialized
INFO - 2023-05-01 15:56:05 --> Language Class Initialized
INFO - 2023-05-01 15:56:05 --> Language Class Initialized
INFO - 2023-05-01 15:56:05 --> Config Class Initialized
INFO - 2023-05-01 15:56:05 --> Loader Class Initialized
INFO - 2023-05-01 15:56:05 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:05 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:05 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:05 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:05 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:56:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:05 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:05 --> Total execution time: 0.0523
INFO - 2023-05-01 15:56:08 --> Config Class Initialized
INFO - 2023-05-01 15:56:08 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:08 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:08 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:08 --> URI Class Initialized
INFO - 2023-05-01 15:56:08 --> Router Class Initialized
INFO - 2023-05-01 15:56:08 --> Output Class Initialized
INFO - 2023-05-01 15:56:08 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:08 --> Input Class Initialized
INFO - 2023-05-01 15:56:08 --> Language Class Initialized
INFO - 2023-05-01 15:56:08 --> Language Class Initialized
INFO - 2023-05-01 15:56:08 --> Config Class Initialized
INFO - 2023-05-01 15:56:08 --> Loader Class Initialized
INFO - 2023-05-01 15:56:08 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:08 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:08 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:08 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:08 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:08 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:08 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:08 --> Total execution time: 0.0350
INFO - 2023-05-01 15:56:09 --> Config Class Initialized
INFO - 2023-05-01 15:56:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:09 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:09 --> URI Class Initialized
INFO - 2023-05-01 15:56:09 --> Router Class Initialized
INFO - 2023-05-01 15:56:09 --> Output Class Initialized
INFO - 2023-05-01 15:56:09 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:09 --> Input Class Initialized
INFO - 2023-05-01 15:56:09 --> Language Class Initialized
INFO - 2023-05-01 15:56:09 --> Language Class Initialized
INFO - 2023-05-01 15:56:09 --> Config Class Initialized
INFO - 2023-05-01 15:56:09 --> Loader Class Initialized
INFO - 2023-05-01 15:56:09 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:09 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:09 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:09 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:09 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:56:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:09 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:09 --> Total execution time: 0.0504
INFO - 2023-05-01 15:56:11 --> Config Class Initialized
INFO - 2023-05-01 15:56:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:11 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:11 --> URI Class Initialized
INFO - 2023-05-01 15:56:11 --> Router Class Initialized
INFO - 2023-05-01 15:56:11 --> Output Class Initialized
INFO - 2023-05-01 15:56:11 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:11 --> Input Class Initialized
INFO - 2023-05-01 15:56:11 --> Language Class Initialized
INFO - 2023-05-01 15:56:11 --> Language Class Initialized
INFO - 2023-05-01 15:56:11 --> Config Class Initialized
INFO - 2023-05-01 15:56:11 --> Loader Class Initialized
INFO - 2023-05-01 15:56:11 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:11 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:11 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:11 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:11 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:56:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:11 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:11 --> Total execution time: 0.0341
INFO - 2023-05-01 15:56:13 --> Config Class Initialized
INFO - 2023-05-01 15:56:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:13 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:13 --> URI Class Initialized
INFO - 2023-05-01 15:56:13 --> Router Class Initialized
INFO - 2023-05-01 15:56:13 --> Output Class Initialized
INFO - 2023-05-01 15:56:13 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:13 --> Input Class Initialized
INFO - 2023-05-01 15:56:13 --> Language Class Initialized
INFO - 2023-05-01 15:56:13 --> Language Class Initialized
INFO - 2023-05-01 15:56:13 --> Config Class Initialized
INFO - 2023-05-01 15:56:13 --> Loader Class Initialized
INFO - 2023-05-01 15:56:13 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:13 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:13 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:13 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:13 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:56:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:13 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:13 --> Total execution time: 0.0453
INFO - 2023-05-01 15:56:15 --> Config Class Initialized
INFO - 2023-05-01 15:56:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:15 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:15 --> URI Class Initialized
INFO - 2023-05-01 15:56:15 --> Router Class Initialized
INFO - 2023-05-01 15:56:15 --> Output Class Initialized
INFO - 2023-05-01 15:56:15 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:15 --> Input Class Initialized
INFO - 2023-05-01 15:56:15 --> Language Class Initialized
INFO - 2023-05-01 15:56:15 --> Language Class Initialized
INFO - 2023-05-01 15:56:15 --> Config Class Initialized
INFO - 2023-05-01 15:56:15 --> Loader Class Initialized
INFO - 2023-05-01 15:56:15 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:15 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:15 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:15 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:15 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 15:56:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:15 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:15 --> Total execution time: 0.0478
INFO - 2023-05-01 15:56:19 --> Config Class Initialized
INFO - 2023-05-01 15:56:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:19 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:19 --> URI Class Initialized
INFO - 2023-05-01 15:56:19 --> Router Class Initialized
INFO - 2023-05-01 15:56:19 --> Output Class Initialized
INFO - 2023-05-01 15:56:19 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:19 --> Input Class Initialized
INFO - 2023-05-01 15:56:19 --> Language Class Initialized
INFO - 2023-05-01 15:56:19 --> Language Class Initialized
INFO - 2023-05-01 15:56:19 --> Config Class Initialized
INFO - 2023-05-01 15:56:19 --> Loader Class Initialized
INFO - 2023-05-01 15:56:19 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:19 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:19 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:19 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:19 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:19 --> Controller Class Initialized
DEBUG - 2023-05-01 15:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:56:19 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:19 --> Total execution time: 0.0520
INFO - 2023-05-01 15:56:21 --> Config Class Initialized
INFO - 2023-05-01 15:56:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:56:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:56:21 --> Utf8 Class Initialized
INFO - 2023-05-01 15:56:21 --> URI Class Initialized
INFO - 2023-05-01 15:56:21 --> Router Class Initialized
INFO - 2023-05-01 15:56:21 --> Output Class Initialized
INFO - 2023-05-01 15:56:21 --> Security Class Initialized
DEBUG - 2023-05-01 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:56:21 --> Input Class Initialized
INFO - 2023-05-01 15:56:21 --> Language Class Initialized
INFO - 2023-05-01 15:56:21 --> Language Class Initialized
INFO - 2023-05-01 15:56:21 --> Config Class Initialized
INFO - 2023-05-01 15:56:21 --> Loader Class Initialized
INFO - 2023-05-01 15:56:21 --> Helper loaded: url_helper
INFO - 2023-05-01 15:56:21 --> Helper loaded: file_helper
INFO - 2023-05-01 15:56:21 --> Helper loaded: form_helper
INFO - 2023-05-01 15:56:21 --> Helper loaded: my_helper
INFO - 2023-05-01 15:56:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:56:21 --> Controller Class Initialized
INFO - 2023-05-01 15:56:21 --> Final output sent to browser
DEBUG - 2023-05-01 15:56:21 --> Total execution time: 0.0538
INFO - 2023-05-01 15:58:12 --> Config Class Initialized
INFO - 2023-05-01 15:58:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:12 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:12 --> URI Class Initialized
INFO - 2023-05-01 15:58:12 --> Router Class Initialized
INFO - 2023-05-01 15:58:12 --> Output Class Initialized
INFO - 2023-05-01 15:58:12 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:12 --> Input Class Initialized
INFO - 2023-05-01 15:58:12 --> Language Class Initialized
INFO - 2023-05-01 15:58:12 --> Language Class Initialized
INFO - 2023-05-01 15:58:12 --> Config Class Initialized
INFO - 2023-05-01 15:58:12 --> Loader Class Initialized
INFO - 2023-05-01 15:58:12 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:12 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:12 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:12 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:12 --> Controller Class Initialized
INFO - 2023-05-01 15:58:12 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:12 --> Total execution time: 0.0603
INFO - 2023-05-01 15:58:48 --> Config Class Initialized
INFO - 2023-05-01 15:58:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:48 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:48 --> URI Class Initialized
INFO - 2023-05-01 15:58:48 --> Router Class Initialized
INFO - 2023-05-01 15:58:48 --> Output Class Initialized
INFO - 2023-05-01 15:58:48 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:48 --> Input Class Initialized
INFO - 2023-05-01 15:58:48 --> Language Class Initialized
INFO - 2023-05-01 15:58:48 --> Language Class Initialized
INFO - 2023-05-01 15:58:48 --> Config Class Initialized
INFO - 2023-05-01 15:58:48 --> Loader Class Initialized
INFO - 2023-05-01 15:58:48 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:48 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:48 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:48 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:48 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:48 --> Controller Class Initialized
DEBUG - 2023-05-01 15:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:58:48 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:48 --> Total execution time: 0.0369
INFO - 2023-05-01 15:58:49 --> Config Class Initialized
INFO - 2023-05-01 15:58:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:49 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:49 --> URI Class Initialized
INFO - 2023-05-01 15:58:49 --> Router Class Initialized
INFO - 2023-05-01 15:58:49 --> Output Class Initialized
INFO - 2023-05-01 15:58:49 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:49 --> Input Class Initialized
INFO - 2023-05-01 15:58:49 --> Language Class Initialized
INFO - 2023-05-01 15:58:49 --> Language Class Initialized
INFO - 2023-05-01 15:58:49 --> Config Class Initialized
INFO - 2023-05-01 15:58:49 --> Loader Class Initialized
INFO - 2023-05-01 15:58:49 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:49 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:49 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:49 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:49 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:49 --> Controller Class Initialized
INFO - 2023-05-01 15:58:49 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:49 --> Total execution time: 0.0327
INFO - 2023-05-01 15:58:50 --> Config Class Initialized
INFO - 2023-05-01 15:58:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:50 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:50 --> URI Class Initialized
INFO - 2023-05-01 15:58:50 --> Router Class Initialized
INFO - 2023-05-01 15:58:50 --> Output Class Initialized
INFO - 2023-05-01 15:58:50 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:50 --> Input Class Initialized
INFO - 2023-05-01 15:58:50 --> Language Class Initialized
INFO - 2023-05-01 15:58:50 --> Language Class Initialized
INFO - 2023-05-01 15:58:50 --> Config Class Initialized
INFO - 2023-05-01 15:58:50 --> Loader Class Initialized
INFO - 2023-05-01 15:58:50 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:50 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:50 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:50 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:50 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:50 --> Controller Class Initialized
INFO - 2023-05-01 15:58:50 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:50 --> Total execution time: 0.0285
INFO - 2023-05-01 15:58:51 --> Config Class Initialized
INFO - 2023-05-01 15:58:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:51 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:51 --> URI Class Initialized
INFO - 2023-05-01 15:58:51 --> Router Class Initialized
INFO - 2023-05-01 15:58:51 --> Output Class Initialized
INFO - 2023-05-01 15:58:51 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:51 --> Input Class Initialized
INFO - 2023-05-01 15:58:51 --> Language Class Initialized
INFO - 2023-05-01 15:58:51 --> Language Class Initialized
INFO - 2023-05-01 15:58:51 --> Config Class Initialized
INFO - 2023-05-01 15:58:51 --> Loader Class Initialized
INFO - 2023-05-01 15:58:51 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:51 --> Controller Class Initialized
INFO - 2023-05-01 15:58:51 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:51 --> Total execution time: 0.0448
INFO - 2023-05-01 15:58:51 --> Config Class Initialized
INFO - 2023-05-01 15:58:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:51 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:51 --> URI Class Initialized
INFO - 2023-05-01 15:58:51 --> Router Class Initialized
INFO - 2023-05-01 15:58:51 --> Output Class Initialized
INFO - 2023-05-01 15:58:51 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:51 --> Input Class Initialized
INFO - 2023-05-01 15:58:51 --> Language Class Initialized
INFO - 2023-05-01 15:58:51 --> Language Class Initialized
INFO - 2023-05-01 15:58:51 --> Config Class Initialized
INFO - 2023-05-01 15:58:51 --> Loader Class Initialized
INFO - 2023-05-01 15:58:51 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:51 --> Controller Class Initialized
INFO - 2023-05-01 15:58:51 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:51 --> Total execution time: 0.0294
INFO - 2023-05-01 15:58:51 --> Config Class Initialized
INFO - 2023-05-01 15:58:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:51 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:51 --> URI Class Initialized
INFO - 2023-05-01 15:58:51 --> Router Class Initialized
INFO - 2023-05-01 15:58:51 --> Output Class Initialized
INFO - 2023-05-01 15:58:51 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:51 --> Input Class Initialized
INFO - 2023-05-01 15:58:51 --> Language Class Initialized
INFO - 2023-05-01 15:58:51 --> Language Class Initialized
INFO - 2023-05-01 15:58:51 --> Config Class Initialized
INFO - 2023-05-01 15:58:51 --> Loader Class Initialized
INFO - 2023-05-01 15:58:51 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:51 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:51 --> Controller Class Initialized
INFO - 2023-05-01 15:58:51 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:51 --> Total execution time: 0.0534
INFO - 2023-05-01 15:58:52 --> Config Class Initialized
INFO - 2023-05-01 15:58:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:52 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:52 --> URI Class Initialized
INFO - 2023-05-01 15:58:52 --> Router Class Initialized
INFO - 2023-05-01 15:58:52 --> Output Class Initialized
INFO - 2023-05-01 15:58:52 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:52 --> Input Class Initialized
INFO - 2023-05-01 15:58:52 --> Language Class Initialized
INFO - 2023-05-01 15:58:52 --> Language Class Initialized
INFO - 2023-05-01 15:58:52 --> Config Class Initialized
INFO - 2023-05-01 15:58:52 --> Loader Class Initialized
INFO - 2023-05-01 15:58:52 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:52 --> Controller Class Initialized
INFO - 2023-05-01 15:58:52 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:52 --> Total execution time: 0.0381
INFO - 2023-05-01 15:58:52 --> Config Class Initialized
INFO - 2023-05-01 15:58:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:52 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:52 --> URI Class Initialized
INFO - 2023-05-01 15:58:52 --> Router Class Initialized
INFO - 2023-05-01 15:58:52 --> Output Class Initialized
INFO - 2023-05-01 15:58:52 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:52 --> Input Class Initialized
INFO - 2023-05-01 15:58:52 --> Language Class Initialized
INFO - 2023-05-01 15:58:52 --> Language Class Initialized
INFO - 2023-05-01 15:58:52 --> Config Class Initialized
INFO - 2023-05-01 15:58:52 --> Loader Class Initialized
INFO - 2023-05-01 15:58:52 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:52 --> Controller Class Initialized
INFO - 2023-05-01 15:58:52 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:52 --> Total execution time: 0.0429
INFO - 2023-05-01 15:58:52 --> Config Class Initialized
INFO - 2023-05-01 15:58:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:52 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:52 --> URI Class Initialized
INFO - 2023-05-01 15:58:52 --> Router Class Initialized
INFO - 2023-05-01 15:58:52 --> Output Class Initialized
INFO - 2023-05-01 15:58:52 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:52 --> Input Class Initialized
INFO - 2023-05-01 15:58:52 --> Language Class Initialized
INFO - 2023-05-01 15:58:52 --> Language Class Initialized
INFO - 2023-05-01 15:58:52 --> Config Class Initialized
INFO - 2023-05-01 15:58:52 --> Loader Class Initialized
INFO - 2023-05-01 15:58:52 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:52 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:52 --> Controller Class Initialized
INFO - 2023-05-01 15:58:52 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:52 --> Total execution time: 0.0465
INFO - 2023-05-01 15:58:53 --> Config Class Initialized
INFO - 2023-05-01 15:58:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:53 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:53 --> URI Class Initialized
INFO - 2023-05-01 15:58:53 --> Router Class Initialized
INFO - 2023-05-01 15:58:53 --> Output Class Initialized
INFO - 2023-05-01 15:58:53 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:53 --> Input Class Initialized
INFO - 2023-05-01 15:58:53 --> Language Class Initialized
INFO - 2023-05-01 15:58:53 --> Language Class Initialized
INFO - 2023-05-01 15:58:53 --> Config Class Initialized
INFO - 2023-05-01 15:58:53 --> Loader Class Initialized
INFO - 2023-05-01 15:58:53 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:53 --> Controller Class Initialized
INFO - 2023-05-01 15:58:53 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:53 --> Total execution time: 0.0492
INFO - 2023-05-01 15:58:53 --> Config Class Initialized
INFO - 2023-05-01 15:58:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:53 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:53 --> URI Class Initialized
INFO - 2023-05-01 15:58:53 --> Router Class Initialized
INFO - 2023-05-01 15:58:53 --> Output Class Initialized
INFO - 2023-05-01 15:58:53 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:53 --> Input Class Initialized
INFO - 2023-05-01 15:58:53 --> Language Class Initialized
INFO - 2023-05-01 15:58:53 --> Language Class Initialized
INFO - 2023-05-01 15:58:53 --> Config Class Initialized
INFO - 2023-05-01 15:58:53 --> Loader Class Initialized
INFO - 2023-05-01 15:58:53 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:53 --> Controller Class Initialized
INFO - 2023-05-01 15:58:53 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:53 --> Total execution time: 0.0499
INFO - 2023-05-01 15:58:53 --> Config Class Initialized
INFO - 2023-05-01 15:58:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:58:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:58:53 --> Utf8 Class Initialized
INFO - 2023-05-01 15:58:53 --> URI Class Initialized
INFO - 2023-05-01 15:58:53 --> Router Class Initialized
INFO - 2023-05-01 15:58:53 --> Output Class Initialized
INFO - 2023-05-01 15:58:53 --> Security Class Initialized
DEBUG - 2023-05-01 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:58:53 --> Input Class Initialized
INFO - 2023-05-01 15:58:53 --> Language Class Initialized
INFO - 2023-05-01 15:58:53 --> Language Class Initialized
INFO - 2023-05-01 15:58:53 --> Config Class Initialized
INFO - 2023-05-01 15:58:53 --> Loader Class Initialized
INFO - 2023-05-01 15:58:53 --> Helper loaded: url_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: file_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: form_helper
INFO - 2023-05-01 15:58:53 --> Helper loaded: my_helper
INFO - 2023-05-01 15:58:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:58:53 --> Controller Class Initialized
INFO - 2023-05-01 15:58:53 --> Final output sent to browser
DEBUG - 2023-05-01 15:58:53 --> Total execution time: 0.0461
INFO - 2023-05-01 15:59:01 --> Config Class Initialized
INFO - 2023-05-01 15:59:01 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:59:01 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:59:01 --> Utf8 Class Initialized
INFO - 2023-05-01 15:59:01 --> URI Class Initialized
INFO - 2023-05-01 15:59:01 --> Router Class Initialized
INFO - 2023-05-01 15:59:01 --> Output Class Initialized
INFO - 2023-05-01 15:59:01 --> Security Class Initialized
DEBUG - 2023-05-01 15:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:59:01 --> Input Class Initialized
INFO - 2023-05-01 15:59:01 --> Language Class Initialized
INFO - 2023-05-01 15:59:01 --> Language Class Initialized
INFO - 2023-05-01 15:59:01 --> Config Class Initialized
INFO - 2023-05-01 15:59:01 --> Loader Class Initialized
INFO - 2023-05-01 15:59:01 --> Helper loaded: url_helper
INFO - 2023-05-01 15:59:01 --> Helper loaded: file_helper
INFO - 2023-05-01 15:59:01 --> Helper loaded: form_helper
INFO - 2023-05-01 15:59:01 --> Helper loaded: my_helper
INFO - 2023-05-01 15:59:01 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:59:01 --> Controller Class Initialized
DEBUG - 2023-05-01 15:59:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 15:59:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 15:59:01 --> Final output sent to browser
DEBUG - 2023-05-01 15:59:01 --> Total execution time: 0.0351
INFO - 2023-05-01 15:59:27 --> Config Class Initialized
INFO - 2023-05-01 15:59:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:59:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:59:27 --> Utf8 Class Initialized
INFO - 2023-05-01 15:59:27 --> URI Class Initialized
INFO - 2023-05-01 15:59:27 --> Router Class Initialized
INFO - 2023-05-01 15:59:27 --> Output Class Initialized
INFO - 2023-05-01 15:59:27 --> Security Class Initialized
DEBUG - 2023-05-01 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:59:27 --> Input Class Initialized
INFO - 2023-05-01 15:59:27 --> Language Class Initialized
ERROR - 2023-05-01 15:59:27 --> 404 Page Not Found: /index
INFO - 2023-05-01 15:59:29 --> Config Class Initialized
INFO - 2023-05-01 15:59:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 15:59:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 15:59:29 --> Utf8 Class Initialized
INFO - 2023-05-01 15:59:29 --> URI Class Initialized
INFO - 2023-05-01 15:59:29 --> Router Class Initialized
INFO - 2023-05-01 15:59:29 --> Output Class Initialized
INFO - 2023-05-01 15:59:29 --> Security Class Initialized
DEBUG - 2023-05-01 15:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 15:59:29 --> Input Class Initialized
INFO - 2023-05-01 15:59:29 --> Language Class Initialized
INFO - 2023-05-01 15:59:29 --> Language Class Initialized
INFO - 2023-05-01 15:59:29 --> Config Class Initialized
INFO - 2023-05-01 15:59:29 --> Loader Class Initialized
INFO - 2023-05-01 15:59:29 --> Helper loaded: url_helper
INFO - 2023-05-01 15:59:29 --> Helper loaded: file_helper
INFO - 2023-05-01 15:59:29 --> Helper loaded: form_helper
INFO - 2023-05-01 15:59:29 --> Helper loaded: my_helper
INFO - 2023-05-01 15:59:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 15:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 15:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 15:59:29 --> Controller Class Initialized
INFO - 2023-05-01 15:59:29 --> Final output sent to browser
DEBUG - 2023-05-01 15:59:29 --> Total execution time: 0.0463
INFO - 2023-05-01 17:21:40 --> Config Class Initialized
INFO - 2023-05-01 17:21:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:21:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:21:40 --> Utf8 Class Initialized
INFO - 2023-05-01 17:21:40 --> URI Class Initialized
INFO - 2023-05-01 17:21:40 --> Router Class Initialized
INFO - 2023-05-01 17:21:40 --> Output Class Initialized
INFO - 2023-05-01 17:21:40 --> Security Class Initialized
DEBUG - 2023-05-01 17:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:21:40 --> Input Class Initialized
INFO - 2023-05-01 17:21:40 --> Language Class Initialized
INFO - 2023-05-01 17:21:40 --> Language Class Initialized
INFO - 2023-05-01 17:21:40 --> Config Class Initialized
INFO - 2023-05-01 17:21:40 --> Loader Class Initialized
INFO - 2023-05-01 17:21:40 --> Helper loaded: url_helper
INFO - 2023-05-01 17:21:40 --> Helper loaded: file_helper
INFO - 2023-05-01 17:21:40 --> Helper loaded: form_helper
INFO - 2023-05-01 17:21:40 --> Helper loaded: my_helper
INFO - 2023-05-01 17:21:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:21:40 --> Controller Class Initialized
DEBUG - 2023-05-01 17:21:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 17:21:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:21:40 --> Final output sent to browser
DEBUG - 2023-05-01 17:21:40 --> Total execution time: 0.0707
INFO - 2023-05-01 17:21:42 --> Config Class Initialized
INFO - 2023-05-01 17:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:21:42 --> Utf8 Class Initialized
INFO - 2023-05-01 17:21:42 --> URI Class Initialized
INFO - 2023-05-01 17:21:42 --> Router Class Initialized
INFO - 2023-05-01 17:21:42 --> Output Class Initialized
INFO - 2023-05-01 17:21:42 --> Security Class Initialized
DEBUG - 2023-05-01 17:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:21:42 --> Input Class Initialized
INFO - 2023-05-01 17:21:42 --> Language Class Initialized
INFO - 2023-05-01 17:21:42 --> Language Class Initialized
INFO - 2023-05-01 17:21:42 --> Config Class Initialized
INFO - 2023-05-01 17:21:42 --> Loader Class Initialized
INFO - 2023-05-01 17:21:42 --> Helper loaded: url_helper
INFO - 2023-05-01 17:21:42 --> Helper loaded: file_helper
INFO - 2023-05-01 17:21:42 --> Helper loaded: form_helper
INFO - 2023-05-01 17:21:42 --> Helper loaded: my_helper
INFO - 2023-05-01 17:21:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:21:42 --> Controller Class Initialized
DEBUG - 2023-05-01 17:21:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 17:21:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:21:42 --> Final output sent to browser
DEBUG - 2023-05-01 17:21:42 --> Total execution time: 0.0553
INFO - 2023-05-01 17:21:43 --> Config Class Initialized
INFO - 2023-05-01 17:21:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:21:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:21:43 --> Utf8 Class Initialized
INFO - 2023-05-01 17:21:43 --> URI Class Initialized
INFO - 2023-05-01 17:21:43 --> Router Class Initialized
INFO - 2023-05-01 17:21:43 --> Output Class Initialized
INFO - 2023-05-01 17:21:43 --> Security Class Initialized
DEBUG - 2023-05-01 17:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:21:43 --> Input Class Initialized
INFO - 2023-05-01 17:21:43 --> Language Class Initialized
INFO - 2023-05-01 17:21:43 --> Language Class Initialized
INFO - 2023-05-01 17:21:43 --> Config Class Initialized
INFO - 2023-05-01 17:21:43 --> Loader Class Initialized
INFO - 2023-05-01 17:21:43 --> Helper loaded: url_helper
INFO - 2023-05-01 17:21:43 --> Helper loaded: file_helper
INFO - 2023-05-01 17:21:43 --> Helper loaded: form_helper
INFO - 2023-05-01 17:21:43 --> Helper loaded: my_helper
INFO - 2023-05-01 17:21:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:21:43 --> Controller Class Initialized
INFO - 2023-05-01 17:21:43 --> Final output sent to browser
DEBUG - 2023-05-01 17:21:43 --> Total execution time: 0.0667
INFO - 2023-05-01 17:22:00 --> Config Class Initialized
INFO - 2023-05-01 17:22:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:22:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:22:00 --> Utf8 Class Initialized
INFO - 2023-05-01 17:22:00 --> URI Class Initialized
INFO - 2023-05-01 17:22:00 --> Router Class Initialized
INFO - 2023-05-01 17:22:00 --> Output Class Initialized
INFO - 2023-05-01 17:22:00 --> Security Class Initialized
DEBUG - 2023-05-01 17:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:22:00 --> Input Class Initialized
INFO - 2023-05-01 17:22:00 --> Language Class Initialized
INFO - 2023-05-01 17:22:00 --> Language Class Initialized
INFO - 2023-05-01 17:22:00 --> Config Class Initialized
INFO - 2023-05-01 17:22:00 --> Loader Class Initialized
INFO - 2023-05-01 17:22:00 --> Helper loaded: url_helper
INFO - 2023-05-01 17:22:00 --> Helper loaded: file_helper
INFO - 2023-05-01 17:22:00 --> Helper loaded: form_helper
INFO - 2023-05-01 17:22:00 --> Helper loaded: my_helper
INFO - 2023-05-01 17:22:00 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:22:00 --> Controller Class Initialized
INFO - 2023-05-01 17:22:00 --> Final output sent to browser
DEBUG - 2023-05-01 17:22:00 --> Total execution time: 0.0626
INFO - 2023-05-01 17:22:02 --> Config Class Initialized
INFO - 2023-05-01 17:22:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:22:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:22:02 --> Utf8 Class Initialized
INFO - 2023-05-01 17:22:02 --> URI Class Initialized
INFO - 2023-05-01 17:22:02 --> Router Class Initialized
INFO - 2023-05-01 17:22:02 --> Output Class Initialized
INFO - 2023-05-01 17:22:02 --> Security Class Initialized
DEBUG - 2023-05-01 17:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:22:02 --> Input Class Initialized
INFO - 2023-05-01 17:22:02 --> Language Class Initialized
INFO - 2023-05-01 17:22:02 --> Language Class Initialized
INFO - 2023-05-01 17:22:02 --> Config Class Initialized
INFO - 2023-05-01 17:22:02 --> Loader Class Initialized
INFO - 2023-05-01 17:22:02 --> Helper loaded: url_helper
INFO - 2023-05-01 17:22:02 --> Helper loaded: file_helper
INFO - 2023-05-01 17:22:02 --> Helper loaded: form_helper
INFO - 2023-05-01 17:22:02 --> Helper loaded: my_helper
INFO - 2023-05-01 17:22:02 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:22:02 --> Controller Class Initialized
DEBUG - 2023-05-01 17:22:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 17:22:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:22:02 --> Final output sent to browser
DEBUG - 2023-05-01 17:22:02 --> Total execution time: 0.0675
INFO - 2023-05-01 17:22:03 --> Config Class Initialized
INFO - 2023-05-01 17:22:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:22:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:22:03 --> Utf8 Class Initialized
INFO - 2023-05-01 17:22:03 --> URI Class Initialized
INFO - 2023-05-01 17:22:03 --> Router Class Initialized
INFO - 2023-05-01 17:22:03 --> Output Class Initialized
INFO - 2023-05-01 17:22:03 --> Security Class Initialized
DEBUG - 2023-05-01 17:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:22:03 --> Input Class Initialized
INFO - 2023-05-01 17:22:03 --> Language Class Initialized
INFO - 2023-05-01 17:22:03 --> Language Class Initialized
INFO - 2023-05-01 17:22:03 --> Config Class Initialized
INFO - 2023-05-01 17:22:03 --> Loader Class Initialized
INFO - 2023-05-01 17:22:03 --> Helper loaded: url_helper
INFO - 2023-05-01 17:22:03 --> Helper loaded: file_helper
INFO - 2023-05-01 17:22:03 --> Helper loaded: form_helper
INFO - 2023-05-01 17:22:03 --> Helper loaded: my_helper
INFO - 2023-05-01 17:22:03 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:22:03 --> Controller Class Initialized
INFO - 2023-05-01 17:22:03 --> Final output sent to browser
DEBUG - 2023-05-01 17:22:03 --> Total execution time: 0.0525
INFO - 2023-05-01 17:22:09 --> Config Class Initialized
INFO - 2023-05-01 17:22:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:22:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:22:09 --> Utf8 Class Initialized
INFO - 2023-05-01 17:22:09 --> URI Class Initialized
INFO - 2023-05-01 17:22:09 --> Router Class Initialized
INFO - 2023-05-01 17:22:09 --> Output Class Initialized
INFO - 2023-05-01 17:22:09 --> Security Class Initialized
DEBUG - 2023-05-01 17:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:22:09 --> Input Class Initialized
INFO - 2023-05-01 17:22:09 --> Language Class Initialized
INFO - 2023-05-01 17:22:09 --> Language Class Initialized
INFO - 2023-05-01 17:22:09 --> Config Class Initialized
INFO - 2023-05-01 17:22:09 --> Loader Class Initialized
INFO - 2023-05-01 17:22:09 --> Helper loaded: url_helper
INFO - 2023-05-01 17:22:09 --> Helper loaded: file_helper
INFO - 2023-05-01 17:22:09 --> Helper loaded: form_helper
INFO - 2023-05-01 17:22:09 --> Helper loaded: my_helper
INFO - 2023-05-01 17:22:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:22:09 --> Controller Class Initialized
INFO - 2023-05-01 17:22:09 --> Final output sent to browser
DEBUG - 2023-05-01 17:22:09 --> Total execution time: 0.0469
INFO - 2023-05-01 17:22:11 --> Config Class Initialized
INFO - 2023-05-01 17:22:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:22:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:22:11 --> Utf8 Class Initialized
INFO - 2023-05-01 17:22:11 --> URI Class Initialized
INFO - 2023-05-01 17:22:11 --> Router Class Initialized
INFO - 2023-05-01 17:22:11 --> Output Class Initialized
INFO - 2023-05-01 17:22:11 --> Security Class Initialized
DEBUG - 2023-05-01 17:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:22:11 --> Input Class Initialized
INFO - 2023-05-01 17:22:11 --> Language Class Initialized
INFO - 2023-05-01 17:22:11 --> Language Class Initialized
INFO - 2023-05-01 17:22:11 --> Config Class Initialized
INFO - 2023-05-01 17:22:11 --> Loader Class Initialized
INFO - 2023-05-01 17:22:11 --> Helper loaded: url_helper
INFO - 2023-05-01 17:22:11 --> Helper loaded: file_helper
INFO - 2023-05-01 17:22:11 --> Helper loaded: form_helper
INFO - 2023-05-01 17:22:11 --> Helper loaded: my_helper
INFO - 2023-05-01 17:22:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:22:11 --> Controller Class Initialized
ERROR - 2023-05-01 17:22:11 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
ERROR - 2023-05-01 17:22:11 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
INFO - 2023-05-01 17:32:17 --> Config Class Initialized
INFO - 2023-05-01 17:32:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:32:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:32:17 --> Utf8 Class Initialized
INFO - 2023-05-01 17:32:17 --> URI Class Initialized
INFO - 2023-05-01 17:32:17 --> Router Class Initialized
INFO - 2023-05-01 17:32:17 --> Output Class Initialized
INFO - 2023-05-01 17:32:17 --> Security Class Initialized
DEBUG - 2023-05-01 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:32:17 --> Input Class Initialized
INFO - 2023-05-01 17:32:17 --> Language Class Initialized
INFO - 2023-05-01 17:32:17 --> Language Class Initialized
INFO - 2023-05-01 17:32:17 --> Config Class Initialized
INFO - 2023-05-01 17:32:17 --> Loader Class Initialized
INFO - 2023-05-01 17:32:17 --> Helper loaded: url_helper
INFO - 2023-05-01 17:32:17 --> Helper loaded: file_helper
INFO - 2023-05-01 17:32:17 --> Helper loaded: form_helper
INFO - 2023-05-01 17:32:17 --> Helper loaded: my_helper
INFO - 2023-05-01 17:32:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:32:17 --> Controller Class Initialized
DEBUG - 2023-05-01 17:32:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 17:32:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:32:17 --> Final output sent to browser
DEBUG - 2023-05-01 17:32:17 --> Total execution time: 0.0664
INFO - 2023-05-01 17:32:19 --> Config Class Initialized
INFO - 2023-05-01 17:32:19 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:32:19 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:32:19 --> Utf8 Class Initialized
INFO - 2023-05-01 17:32:19 --> URI Class Initialized
INFO - 2023-05-01 17:32:19 --> Router Class Initialized
INFO - 2023-05-01 17:32:19 --> Output Class Initialized
INFO - 2023-05-01 17:32:19 --> Security Class Initialized
DEBUG - 2023-05-01 17:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:32:19 --> Input Class Initialized
INFO - 2023-05-01 17:32:19 --> Language Class Initialized
INFO - 2023-05-01 17:32:19 --> Language Class Initialized
INFO - 2023-05-01 17:32:19 --> Config Class Initialized
INFO - 2023-05-01 17:32:19 --> Loader Class Initialized
INFO - 2023-05-01 17:32:19 --> Helper loaded: url_helper
INFO - 2023-05-01 17:32:19 --> Helper loaded: file_helper
INFO - 2023-05-01 17:32:19 --> Helper loaded: form_helper
INFO - 2023-05-01 17:32:19 --> Helper loaded: my_helper
INFO - 2023-05-01 17:32:19 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:32:19 --> Controller Class Initialized
ERROR - 2023-05-01 17:32:19 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
ERROR - 2023-05-01 17:32:19 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
INFO - 2023-05-01 17:33:12 --> Config Class Initialized
INFO - 2023-05-01 17:33:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:33:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:33:12 --> Utf8 Class Initialized
INFO - 2023-05-01 17:33:12 --> URI Class Initialized
INFO - 2023-05-01 17:33:12 --> Router Class Initialized
INFO - 2023-05-01 17:33:12 --> Output Class Initialized
INFO - 2023-05-01 17:33:12 --> Security Class Initialized
DEBUG - 2023-05-01 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:33:12 --> Input Class Initialized
INFO - 2023-05-01 17:33:12 --> Language Class Initialized
INFO - 2023-05-01 17:33:12 --> Language Class Initialized
INFO - 2023-05-01 17:33:12 --> Config Class Initialized
INFO - 2023-05-01 17:33:12 --> Loader Class Initialized
INFO - 2023-05-01 17:33:12 --> Helper loaded: url_helper
INFO - 2023-05-01 17:33:12 --> Helper loaded: file_helper
INFO - 2023-05-01 17:33:12 --> Helper loaded: form_helper
INFO - 2023-05-01 17:33:12 --> Helper loaded: my_helper
INFO - 2023-05-01 17:33:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:33:12 --> Controller Class Initialized
ERROR - 2023-05-01 17:33:12 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
ERROR - 2023-05-01 17:33:12 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
INFO - 2023-05-01 17:33:47 --> Config Class Initialized
INFO - 2023-05-01 17:33:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:33:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:33:47 --> Utf8 Class Initialized
INFO - 2023-05-01 17:33:47 --> URI Class Initialized
INFO - 2023-05-01 17:33:47 --> Router Class Initialized
INFO - 2023-05-01 17:33:47 --> Output Class Initialized
INFO - 2023-05-01 17:33:47 --> Security Class Initialized
DEBUG - 2023-05-01 17:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:33:47 --> Input Class Initialized
INFO - 2023-05-01 17:33:47 --> Language Class Initialized
INFO - 2023-05-01 17:33:47 --> Language Class Initialized
INFO - 2023-05-01 17:33:47 --> Config Class Initialized
INFO - 2023-05-01 17:33:47 --> Loader Class Initialized
INFO - 2023-05-01 17:33:47 --> Helper loaded: url_helper
INFO - 2023-05-01 17:33:47 --> Helper loaded: file_helper
INFO - 2023-05-01 17:33:47 --> Helper loaded: form_helper
INFO - 2023-05-01 17:33:47 --> Helper loaded: my_helper
INFO - 2023-05-01 17:33:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:33:47 --> Controller Class Initialized
ERROR - 2023-05-01 17:33:47 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
ERROR - 2023-05-01 17:33:47 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_guru\controllers\N_catatan_guru.php 175
INFO - 2023-05-01 17:38:12 --> Config Class Initialized
INFO - 2023-05-01 17:38:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:38:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:38:12 --> Utf8 Class Initialized
INFO - 2023-05-01 17:38:12 --> URI Class Initialized
INFO - 2023-05-01 17:38:12 --> Router Class Initialized
INFO - 2023-05-01 17:38:12 --> Output Class Initialized
INFO - 2023-05-01 17:38:12 --> Security Class Initialized
DEBUG - 2023-05-01 17:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:38:12 --> Input Class Initialized
INFO - 2023-05-01 17:38:12 --> Language Class Initialized
INFO - 2023-05-01 17:38:12 --> Language Class Initialized
INFO - 2023-05-01 17:38:12 --> Config Class Initialized
INFO - 2023-05-01 17:38:12 --> Loader Class Initialized
INFO - 2023-05-01 17:38:12 --> Helper loaded: url_helper
INFO - 2023-05-01 17:38:12 --> Helper loaded: file_helper
INFO - 2023-05-01 17:38:12 --> Helper loaded: form_helper
INFO - 2023-05-01 17:38:12 --> Helper loaded: my_helper
INFO - 2023-05-01 17:38:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:38:12 --> Controller Class Initialized
DEBUG - 2023-05-01 17:38:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 17:38:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:38:12 --> Final output sent to browser
DEBUG - 2023-05-01 17:38:12 --> Total execution time: 0.0508
INFO - 2023-05-01 17:38:13 --> Config Class Initialized
INFO - 2023-05-01 17:38:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:38:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:38:13 --> Utf8 Class Initialized
INFO - 2023-05-01 17:38:13 --> URI Class Initialized
INFO - 2023-05-01 17:38:13 --> Router Class Initialized
INFO - 2023-05-01 17:38:13 --> Output Class Initialized
INFO - 2023-05-01 17:38:13 --> Security Class Initialized
DEBUG - 2023-05-01 17:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:38:13 --> Input Class Initialized
INFO - 2023-05-01 17:38:13 --> Language Class Initialized
INFO - 2023-05-01 17:38:13 --> Language Class Initialized
INFO - 2023-05-01 17:38:13 --> Config Class Initialized
INFO - 2023-05-01 17:38:13 --> Loader Class Initialized
INFO - 2023-05-01 17:38:13 --> Helper loaded: url_helper
INFO - 2023-05-01 17:38:13 --> Helper loaded: file_helper
INFO - 2023-05-01 17:38:13 --> Helper loaded: form_helper
INFO - 2023-05-01 17:38:13 --> Helper loaded: my_helper
INFO - 2023-05-01 17:38:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:38:13 --> Controller Class Initialized
INFO - 2023-05-01 17:38:37 --> Config Class Initialized
INFO - 2023-05-01 17:38:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:38:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:38:37 --> Utf8 Class Initialized
INFO - 2023-05-01 17:38:37 --> URI Class Initialized
INFO - 2023-05-01 17:38:37 --> Router Class Initialized
INFO - 2023-05-01 17:38:37 --> Output Class Initialized
INFO - 2023-05-01 17:38:37 --> Security Class Initialized
DEBUG - 2023-05-01 17:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:38:37 --> Input Class Initialized
INFO - 2023-05-01 17:38:37 --> Language Class Initialized
INFO - 2023-05-01 17:38:37 --> Language Class Initialized
INFO - 2023-05-01 17:38:37 --> Config Class Initialized
INFO - 2023-05-01 17:38:37 --> Loader Class Initialized
INFO - 2023-05-01 17:38:37 --> Helper loaded: url_helper
INFO - 2023-05-01 17:38:37 --> Helper loaded: file_helper
INFO - 2023-05-01 17:38:37 --> Helper loaded: form_helper
INFO - 2023-05-01 17:38:37 --> Helper loaded: my_helper
INFO - 2023-05-01 17:38:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:38:37 --> Controller Class Initialized
INFO - 2023-05-01 17:38:37 --> Final output sent to browser
DEBUG - 2023-05-01 17:38:37 --> Total execution time: 0.0540
INFO - 2023-05-01 17:39:58 --> Config Class Initialized
INFO - 2023-05-01 17:39:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:39:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:39:58 --> Utf8 Class Initialized
INFO - 2023-05-01 17:39:58 --> URI Class Initialized
INFO - 2023-05-01 17:39:58 --> Router Class Initialized
INFO - 2023-05-01 17:39:58 --> Output Class Initialized
INFO - 2023-05-01 17:39:58 --> Security Class Initialized
DEBUG - 2023-05-01 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:39:58 --> Input Class Initialized
INFO - 2023-05-01 17:39:58 --> Language Class Initialized
INFO - 2023-05-01 17:39:58 --> Language Class Initialized
INFO - 2023-05-01 17:39:58 --> Config Class Initialized
INFO - 2023-05-01 17:39:58 --> Loader Class Initialized
INFO - 2023-05-01 17:39:58 --> Helper loaded: url_helper
INFO - 2023-05-01 17:39:58 --> Helper loaded: file_helper
INFO - 2023-05-01 17:39:58 --> Helper loaded: form_helper
INFO - 2023-05-01 17:39:58 --> Helper loaded: my_helper
INFO - 2023-05-01 17:39:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:39:58 --> Controller Class Initialized
DEBUG - 2023-05-01 17:39:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 17:39:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:39:58 --> Final output sent to browser
DEBUG - 2023-05-01 17:39:58 --> Total execution time: 0.0422
INFO - 2023-05-01 17:40:33 --> Config Class Initialized
INFO - 2023-05-01 17:40:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:40:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:40:33 --> Utf8 Class Initialized
INFO - 2023-05-01 17:40:33 --> URI Class Initialized
INFO - 2023-05-01 17:40:33 --> Router Class Initialized
INFO - 2023-05-01 17:40:33 --> Output Class Initialized
INFO - 2023-05-01 17:40:33 --> Security Class Initialized
DEBUG - 2023-05-01 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:40:33 --> Input Class Initialized
INFO - 2023-05-01 17:40:33 --> Language Class Initialized
INFO - 2023-05-01 17:40:33 --> Language Class Initialized
INFO - 2023-05-01 17:40:33 --> Config Class Initialized
INFO - 2023-05-01 17:40:33 --> Loader Class Initialized
INFO - 2023-05-01 17:40:33 --> Helper loaded: url_helper
INFO - 2023-05-01 17:40:33 --> Helper loaded: file_helper
INFO - 2023-05-01 17:40:33 --> Helper loaded: form_helper
INFO - 2023-05-01 17:40:33 --> Helper loaded: my_helper
INFO - 2023-05-01 17:40:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:40:33 --> Controller Class Initialized
DEBUG - 2023-05-01 17:40:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 17:40:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:40:33 --> Final output sent to browser
DEBUG - 2023-05-01 17:40:33 --> Total execution time: 0.0579
INFO - 2023-05-01 17:40:33 --> Config Class Initialized
INFO - 2023-05-01 17:40:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:40:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:40:33 --> Utf8 Class Initialized
INFO - 2023-05-01 17:40:33 --> URI Class Initialized
INFO - 2023-05-01 17:40:33 --> Router Class Initialized
INFO - 2023-05-01 17:40:33 --> Output Class Initialized
INFO - 2023-05-01 17:40:33 --> Security Class Initialized
DEBUG - 2023-05-01 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:40:33 --> Input Class Initialized
INFO - 2023-05-01 17:40:33 --> Language Class Initialized
INFO - 2023-05-01 17:40:33 --> Language Class Initialized
INFO - 2023-05-01 17:40:33 --> Config Class Initialized
INFO - 2023-05-01 17:40:33 --> Loader Class Initialized
INFO - 2023-05-01 17:40:33 --> Helper loaded: url_helper
INFO - 2023-05-01 17:40:33 --> Helper loaded: file_helper
INFO - 2023-05-01 17:40:33 --> Helper loaded: form_helper
INFO - 2023-05-01 17:40:33 --> Helper loaded: my_helper
INFO - 2023-05-01 17:40:33 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:40:33 --> Controller Class Initialized
INFO - 2023-05-01 17:41:10 --> Config Class Initialized
INFO - 2023-05-01 17:41:10 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:41:10 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:41:10 --> Utf8 Class Initialized
INFO - 2023-05-01 17:41:10 --> URI Class Initialized
INFO - 2023-05-01 17:41:10 --> Router Class Initialized
INFO - 2023-05-01 17:41:10 --> Output Class Initialized
INFO - 2023-05-01 17:41:10 --> Security Class Initialized
DEBUG - 2023-05-01 17:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:41:10 --> Input Class Initialized
INFO - 2023-05-01 17:41:10 --> Language Class Initialized
INFO - 2023-05-01 17:41:10 --> Language Class Initialized
INFO - 2023-05-01 17:41:10 --> Config Class Initialized
INFO - 2023-05-01 17:41:10 --> Loader Class Initialized
INFO - 2023-05-01 17:41:10 --> Helper loaded: url_helper
INFO - 2023-05-01 17:41:10 --> Helper loaded: file_helper
INFO - 2023-05-01 17:41:10 --> Helper loaded: form_helper
INFO - 2023-05-01 17:41:10 --> Helper loaded: my_helper
INFO - 2023-05-01 17:41:10 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:41:10 --> Controller Class Initialized
INFO - 2023-05-01 17:41:10 --> Final output sent to browser
DEBUG - 2023-05-01 17:41:10 --> Total execution time: 0.0599
INFO - 2023-05-01 17:41:15 --> Config Class Initialized
INFO - 2023-05-01 17:41:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:41:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:41:15 --> Utf8 Class Initialized
INFO - 2023-05-01 17:41:15 --> URI Class Initialized
INFO - 2023-05-01 17:41:15 --> Router Class Initialized
INFO - 2023-05-01 17:41:15 --> Output Class Initialized
INFO - 2023-05-01 17:41:15 --> Security Class Initialized
DEBUG - 2023-05-01 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:41:15 --> Input Class Initialized
INFO - 2023-05-01 17:41:15 --> Language Class Initialized
INFO - 2023-05-01 17:41:15 --> Language Class Initialized
INFO - 2023-05-01 17:41:15 --> Config Class Initialized
INFO - 2023-05-01 17:41:15 --> Loader Class Initialized
INFO - 2023-05-01 17:41:15 --> Helper loaded: url_helper
INFO - 2023-05-01 17:41:15 --> Helper loaded: file_helper
INFO - 2023-05-01 17:41:15 --> Helper loaded: form_helper
INFO - 2023-05-01 17:41:15 --> Helper loaded: my_helper
INFO - 2023-05-01 17:41:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:41:15 --> Controller Class Initialized
DEBUG - 2023-05-01 17:41:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 17:41:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:41:15 --> Final output sent to browser
DEBUG - 2023-05-01 17:41:15 --> Total execution time: 0.0413
INFO - 2023-05-01 17:42:39 --> Config Class Initialized
INFO - 2023-05-01 17:42:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:42:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:42:39 --> Utf8 Class Initialized
INFO - 2023-05-01 17:42:39 --> URI Class Initialized
INFO - 2023-05-01 17:42:39 --> Router Class Initialized
INFO - 2023-05-01 17:42:39 --> Output Class Initialized
INFO - 2023-05-01 17:42:39 --> Security Class Initialized
DEBUG - 2023-05-01 17:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:42:39 --> Input Class Initialized
INFO - 2023-05-01 17:42:39 --> Language Class Initialized
INFO - 2023-05-01 17:42:39 --> Language Class Initialized
INFO - 2023-05-01 17:42:39 --> Config Class Initialized
INFO - 2023-05-01 17:42:39 --> Loader Class Initialized
INFO - 2023-05-01 17:42:39 --> Helper loaded: url_helper
INFO - 2023-05-01 17:42:39 --> Helper loaded: file_helper
INFO - 2023-05-01 17:42:39 --> Helper loaded: form_helper
INFO - 2023-05-01 17:42:39 --> Helper loaded: my_helper
INFO - 2023-05-01 17:42:39 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:42:39 --> Controller Class Initialized
DEBUG - 2023-05-01 17:42:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 17:42:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:42:39 --> Final output sent to browser
DEBUG - 2023-05-01 17:42:39 --> Total execution time: 0.0639
INFO - 2023-05-01 17:42:39 --> Config Class Initialized
INFO - 2023-05-01 17:42:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:42:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:42:39 --> Utf8 Class Initialized
INFO - 2023-05-01 17:42:39 --> URI Class Initialized
INFO - 2023-05-01 17:42:39 --> Router Class Initialized
INFO - 2023-05-01 17:42:39 --> Output Class Initialized
INFO - 2023-05-01 17:42:39 --> Security Class Initialized
DEBUG - 2023-05-01 17:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:42:39 --> Input Class Initialized
INFO - 2023-05-01 17:42:39 --> Language Class Initialized
INFO - 2023-05-01 17:42:39 --> Language Class Initialized
INFO - 2023-05-01 17:42:39 --> Config Class Initialized
INFO - 2023-05-01 17:42:39 --> Loader Class Initialized
INFO - 2023-05-01 17:42:39 --> Helper loaded: url_helper
INFO - 2023-05-01 17:42:39 --> Helper loaded: file_helper
INFO - 2023-05-01 17:42:39 --> Helper loaded: form_helper
INFO - 2023-05-01 17:42:39 --> Helper loaded: my_helper
INFO - 2023-05-01 17:42:39 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:42:39 --> Controller Class Initialized
INFO - 2023-05-01 17:42:46 --> Config Class Initialized
INFO - 2023-05-01 17:42:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:42:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:42:46 --> Utf8 Class Initialized
INFO - 2023-05-01 17:42:46 --> URI Class Initialized
INFO - 2023-05-01 17:42:46 --> Router Class Initialized
INFO - 2023-05-01 17:42:46 --> Output Class Initialized
INFO - 2023-05-01 17:42:46 --> Security Class Initialized
DEBUG - 2023-05-01 17:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:42:46 --> Input Class Initialized
INFO - 2023-05-01 17:42:46 --> Language Class Initialized
INFO - 2023-05-01 17:42:46 --> Language Class Initialized
INFO - 2023-05-01 17:42:46 --> Config Class Initialized
INFO - 2023-05-01 17:42:46 --> Loader Class Initialized
INFO - 2023-05-01 17:42:46 --> Helper loaded: url_helper
INFO - 2023-05-01 17:42:46 --> Helper loaded: file_helper
INFO - 2023-05-01 17:42:46 --> Helper loaded: form_helper
INFO - 2023-05-01 17:42:46 --> Helper loaded: my_helper
INFO - 2023-05-01 17:42:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:42:46 --> Controller Class Initialized
DEBUG - 2023-05-01 17:42:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 17:42:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:42:46 --> Final output sent to browser
DEBUG - 2023-05-01 17:42:46 --> Total execution time: 0.0540
INFO - 2023-05-01 17:44:29 --> Config Class Initialized
INFO - 2023-05-01 17:44:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:44:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:44:29 --> Utf8 Class Initialized
INFO - 2023-05-01 17:44:29 --> URI Class Initialized
INFO - 2023-05-01 17:44:29 --> Router Class Initialized
INFO - 2023-05-01 17:44:29 --> Output Class Initialized
INFO - 2023-05-01 17:44:29 --> Security Class Initialized
DEBUG - 2023-05-01 17:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:44:29 --> Input Class Initialized
INFO - 2023-05-01 17:44:29 --> Language Class Initialized
INFO - 2023-05-01 17:44:29 --> Language Class Initialized
INFO - 2023-05-01 17:44:29 --> Config Class Initialized
INFO - 2023-05-01 17:44:29 --> Loader Class Initialized
INFO - 2023-05-01 17:44:29 --> Helper loaded: url_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: file_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: form_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: my_helper
INFO - 2023-05-01 17:44:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:44:29 --> Controller Class Initialized
INFO - 2023-05-01 17:44:29 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:44:29 --> Config Class Initialized
INFO - 2023-05-01 17:44:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:44:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:44:29 --> Utf8 Class Initialized
INFO - 2023-05-01 17:44:29 --> URI Class Initialized
INFO - 2023-05-01 17:44:29 --> Router Class Initialized
INFO - 2023-05-01 17:44:29 --> Output Class Initialized
INFO - 2023-05-01 17:44:29 --> Security Class Initialized
DEBUG - 2023-05-01 17:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:44:29 --> Input Class Initialized
INFO - 2023-05-01 17:44:29 --> Language Class Initialized
INFO - 2023-05-01 17:44:29 --> Language Class Initialized
INFO - 2023-05-01 17:44:29 --> Config Class Initialized
INFO - 2023-05-01 17:44:29 --> Loader Class Initialized
INFO - 2023-05-01 17:44:29 --> Helper loaded: url_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: file_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: form_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: my_helper
INFO - 2023-05-01 17:44:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:44:29 --> Controller Class Initialized
INFO - 2023-05-01 17:44:29 --> Config Class Initialized
INFO - 2023-05-01 17:44:29 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:44:29 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:44:29 --> Utf8 Class Initialized
INFO - 2023-05-01 17:44:29 --> URI Class Initialized
INFO - 2023-05-01 17:44:29 --> Router Class Initialized
INFO - 2023-05-01 17:44:29 --> Output Class Initialized
INFO - 2023-05-01 17:44:29 --> Security Class Initialized
DEBUG - 2023-05-01 17:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:44:29 --> Input Class Initialized
INFO - 2023-05-01 17:44:29 --> Language Class Initialized
INFO - 2023-05-01 17:44:29 --> Language Class Initialized
INFO - 2023-05-01 17:44:29 --> Config Class Initialized
INFO - 2023-05-01 17:44:29 --> Loader Class Initialized
INFO - 2023-05-01 17:44:29 --> Helper loaded: url_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: file_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: form_helper
INFO - 2023-05-01 17:44:29 --> Helper loaded: my_helper
INFO - 2023-05-01 17:44:29 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:44:29 --> Controller Class Initialized
DEBUG - 2023-05-01 17:44:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 17:44:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:44:29 --> Final output sent to browser
DEBUG - 2023-05-01 17:44:29 --> Total execution time: 0.0486
INFO - 2023-05-01 17:44:34 --> Config Class Initialized
INFO - 2023-05-01 17:44:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:44:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:44:34 --> Utf8 Class Initialized
INFO - 2023-05-01 17:44:34 --> URI Class Initialized
INFO - 2023-05-01 17:44:34 --> Router Class Initialized
INFO - 2023-05-01 17:44:34 --> Output Class Initialized
INFO - 2023-05-01 17:44:34 --> Security Class Initialized
DEBUG - 2023-05-01 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:44:34 --> Input Class Initialized
INFO - 2023-05-01 17:44:34 --> Language Class Initialized
INFO - 2023-05-01 17:44:34 --> Language Class Initialized
INFO - 2023-05-01 17:44:34 --> Config Class Initialized
INFO - 2023-05-01 17:44:34 --> Loader Class Initialized
INFO - 2023-05-01 17:44:34 --> Helper loaded: url_helper
INFO - 2023-05-01 17:44:34 --> Helper loaded: file_helper
INFO - 2023-05-01 17:44:34 --> Helper loaded: form_helper
INFO - 2023-05-01 17:44:34 --> Helper loaded: my_helper
INFO - 2023-05-01 17:44:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:44:34 --> Controller Class Initialized
INFO - 2023-05-01 17:44:34 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:44:34 --> Final output sent to browser
DEBUG - 2023-05-01 17:44:34 --> Total execution time: 0.0684
INFO - 2023-05-01 17:44:34 --> Config Class Initialized
INFO - 2023-05-01 17:44:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:44:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:44:34 --> Utf8 Class Initialized
INFO - 2023-05-01 17:44:34 --> URI Class Initialized
INFO - 2023-05-01 17:44:34 --> Router Class Initialized
INFO - 2023-05-01 17:44:34 --> Output Class Initialized
INFO - 2023-05-01 17:44:34 --> Security Class Initialized
DEBUG - 2023-05-01 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:44:34 --> Input Class Initialized
INFO - 2023-05-01 17:44:34 --> Language Class Initialized
INFO - 2023-05-01 17:44:34 --> Language Class Initialized
INFO - 2023-05-01 17:44:34 --> Config Class Initialized
INFO - 2023-05-01 17:44:34 --> Loader Class Initialized
INFO - 2023-05-01 17:44:34 --> Helper loaded: url_helper
INFO - 2023-05-01 17:44:34 --> Helper loaded: file_helper
INFO - 2023-05-01 17:44:34 --> Helper loaded: form_helper
INFO - 2023-05-01 17:44:34 --> Helper loaded: my_helper
INFO - 2023-05-01 17:44:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:44:34 --> Controller Class Initialized
DEBUG - 2023-05-01 17:44:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 17:44:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:44:34 --> Final output sent to browser
DEBUG - 2023-05-01 17:44:34 --> Total execution time: 0.0405
INFO - 2023-05-01 17:45:20 --> Config Class Initialized
INFO - 2023-05-01 17:45:20 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:45:20 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:45:20 --> Utf8 Class Initialized
INFO - 2023-05-01 17:45:20 --> URI Class Initialized
INFO - 2023-05-01 17:45:20 --> Router Class Initialized
INFO - 2023-05-01 17:45:20 --> Output Class Initialized
INFO - 2023-05-01 17:45:20 --> Security Class Initialized
DEBUG - 2023-05-01 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:45:20 --> Input Class Initialized
INFO - 2023-05-01 17:45:20 --> Language Class Initialized
INFO - 2023-05-01 17:45:20 --> Language Class Initialized
INFO - 2023-05-01 17:45:20 --> Config Class Initialized
INFO - 2023-05-01 17:45:20 --> Loader Class Initialized
INFO - 2023-05-01 17:45:20 --> Helper loaded: url_helper
INFO - 2023-05-01 17:45:20 --> Helper loaded: file_helper
INFO - 2023-05-01 17:45:20 --> Helper loaded: form_helper
INFO - 2023-05-01 17:45:20 --> Helper loaded: my_helper
INFO - 2023-05-01 17:45:20 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:45:20 --> Controller Class Initialized
DEBUG - 2023-05-01 17:45:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-05-01 17:45:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:45:20 --> Final output sent to browser
DEBUG - 2023-05-01 17:45:20 --> Total execution time: 0.0517
INFO - 2023-05-01 17:45:46 --> Config Class Initialized
INFO - 2023-05-01 17:45:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:45:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:45:46 --> Utf8 Class Initialized
INFO - 2023-05-01 17:45:46 --> URI Class Initialized
INFO - 2023-05-01 17:45:46 --> Router Class Initialized
INFO - 2023-05-01 17:45:46 --> Output Class Initialized
INFO - 2023-05-01 17:45:46 --> Security Class Initialized
DEBUG - 2023-05-01 17:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:45:46 --> Input Class Initialized
INFO - 2023-05-01 17:45:46 --> Language Class Initialized
INFO - 2023-05-01 17:45:46 --> Language Class Initialized
INFO - 2023-05-01 17:45:46 --> Config Class Initialized
INFO - 2023-05-01 17:45:46 --> Loader Class Initialized
INFO - 2023-05-01 17:45:46 --> Helper loaded: url_helper
INFO - 2023-05-01 17:45:46 --> Helper loaded: file_helper
INFO - 2023-05-01 17:45:46 --> Helper loaded: form_helper
INFO - 2023-05-01 17:45:46 --> Helper loaded: my_helper
INFO - 2023-05-01 17:45:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:45:46 --> Controller Class Initialized
DEBUG - 2023-05-01 17:45:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-05-01 17:45:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:45:46 --> Final output sent to browser
DEBUG - 2023-05-01 17:45:46 --> Total execution time: 0.0595
INFO - 2023-05-01 17:45:50 --> Config Class Initialized
INFO - 2023-05-01 17:45:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:45:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:45:50 --> Utf8 Class Initialized
INFO - 2023-05-01 17:45:50 --> URI Class Initialized
INFO - 2023-05-01 17:45:50 --> Router Class Initialized
INFO - 2023-05-01 17:45:50 --> Output Class Initialized
INFO - 2023-05-01 17:45:50 --> Security Class Initialized
DEBUG - 2023-05-01 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:45:50 --> Input Class Initialized
INFO - 2023-05-01 17:45:50 --> Language Class Initialized
INFO - 2023-05-01 17:45:50 --> Language Class Initialized
INFO - 2023-05-01 17:45:50 --> Config Class Initialized
INFO - 2023-05-01 17:45:50 --> Loader Class Initialized
INFO - 2023-05-01 17:45:50 --> Helper loaded: url_helper
INFO - 2023-05-01 17:45:50 --> Helper loaded: file_helper
INFO - 2023-05-01 17:45:50 --> Helper loaded: form_helper
INFO - 2023-05-01 17:45:50 --> Helper loaded: my_helper
INFO - 2023-05-01 17:45:50 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:45:50 --> Controller Class Initialized
DEBUG - 2023-05-01 17:45:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-05-01 17:45:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:45:50 --> Final output sent to browser
DEBUG - 2023-05-01 17:45:50 --> Total execution time: 0.0568
INFO - 2023-05-01 17:46:47 --> Config Class Initialized
INFO - 2023-05-01 17:46:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:47 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:47 --> URI Class Initialized
INFO - 2023-05-01 17:46:47 --> Router Class Initialized
INFO - 2023-05-01 17:46:47 --> Output Class Initialized
INFO - 2023-05-01 17:46:47 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:47 --> Input Class Initialized
INFO - 2023-05-01 17:46:47 --> Language Class Initialized
INFO - 2023-05-01 17:46:47 --> Language Class Initialized
INFO - 2023-05-01 17:46:47 --> Config Class Initialized
INFO - 2023-05-01 17:46:47 --> Loader Class Initialized
INFO - 2023-05-01 17:46:47 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:47 --> Controller Class Initialized
INFO - 2023-05-01 17:46:47 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:46:47 --> Config Class Initialized
INFO - 2023-05-01 17:46:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:47 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:47 --> URI Class Initialized
INFO - 2023-05-01 17:46:47 --> Router Class Initialized
INFO - 2023-05-01 17:46:47 --> Output Class Initialized
INFO - 2023-05-01 17:46:47 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:47 --> Input Class Initialized
INFO - 2023-05-01 17:46:47 --> Language Class Initialized
INFO - 2023-05-01 17:46:47 --> Language Class Initialized
INFO - 2023-05-01 17:46:47 --> Config Class Initialized
INFO - 2023-05-01 17:46:47 --> Loader Class Initialized
INFO - 2023-05-01 17:46:47 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:47 --> Controller Class Initialized
INFO - 2023-05-01 17:46:47 --> Config Class Initialized
INFO - 2023-05-01 17:46:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:47 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:47 --> URI Class Initialized
INFO - 2023-05-01 17:46:47 --> Router Class Initialized
INFO - 2023-05-01 17:46:47 --> Output Class Initialized
INFO - 2023-05-01 17:46:47 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:47 --> Input Class Initialized
INFO - 2023-05-01 17:46:47 --> Language Class Initialized
INFO - 2023-05-01 17:46:47 --> Language Class Initialized
INFO - 2023-05-01 17:46:47 --> Config Class Initialized
INFO - 2023-05-01 17:46:47 --> Loader Class Initialized
INFO - 2023-05-01 17:46:47 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:47 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:47 --> Controller Class Initialized
DEBUG - 2023-05-01 17:46:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 17:46:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:46:47 --> Final output sent to browser
DEBUG - 2023-05-01 17:46:47 --> Total execution time: 0.0578
INFO - 2023-05-01 17:46:53 --> Config Class Initialized
INFO - 2023-05-01 17:46:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:53 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:53 --> URI Class Initialized
INFO - 2023-05-01 17:46:53 --> Router Class Initialized
INFO - 2023-05-01 17:46:53 --> Output Class Initialized
INFO - 2023-05-01 17:46:53 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:53 --> Input Class Initialized
INFO - 2023-05-01 17:46:53 --> Language Class Initialized
INFO - 2023-05-01 17:46:53 --> Language Class Initialized
INFO - 2023-05-01 17:46:53 --> Config Class Initialized
INFO - 2023-05-01 17:46:53 --> Loader Class Initialized
INFO - 2023-05-01 17:46:53 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:53 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:53 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:53 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:53 --> Controller Class Initialized
INFO - 2023-05-01 17:46:53 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:46:53 --> Final output sent to browser
DEBUG - 2023-05-01 17:46:53 --> Total execution time: 0.0526
INFO - 2023-05-01 17:46:53 --> Config Class Initialized
INFO - 2023-05-01 17:46:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:53 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:53 --> URI Class Initialized
INFO - 2023-05-01 17:46:53 --> Router Class Initialized
INFO - 2023-05-01 17:46:53 --> Output Class Initialized
INFO - 2023-05-01 17:46:53 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:53 --> Input Class Initialized
INFO - 2023-05-01 17:46:53 --> Language Class Initialized
INFO - 2023-05-01 17:46:53 --> Language Class Initialized
INFO - 2023-05-01 17:46:53 --> Config Class Initialized
INFO - 2023-05-01 17:46:53 --> Loader Class Initialized
INFO - 2023-05-01 17:46:53 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:53 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:53 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:53 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:53 --> Controller Class Initialized
DEBUG - 2023-05-01 17:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 17:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:46:53 --> Final output sent to browser
DEBUG - 2023-05-01 17:46:53 --> Total execution time: 0.0686
INFO - 2023-05-01 17:46:55 --> Config Class Initialized
INFO - 2023-05-01 17:46:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:55 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:55 --> URI Class Initialized
INFO - 2023-05-01 17:46:55 --> Router Class Initialized
INFO - 2023-05-01 17:46:55 --> Output Class Initialized
INFO - 2023-05-01 17:46:55 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:55 --> Input Class Initialized
INFO - 2023-05-01 17:46:55 --> Language Class Initialized
INFO - 2023-05-01 17:46:55 --> Language Class Initialized
INFO - 2023-05-01 17:46:55 --> Config Class Initialized
INFO - 2023-05-01 17:46:55 --> Loader Class Initialized
INFO - 2023-05-01 17:46:55 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:55 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:55 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:55 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:55 --> Controller Class Initialized
DEBUG - 2023-05-01 17:46:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 17:46:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:46:55 --> Final output sent to browser
DEBUG - 2023-05-01 17:46:55 --> Total execution time: 0.0518
INFO - 2023-05-01 17:46:57 --> Config Class Initialized
INFO - 2023-05-01 17:46:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:57 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:57 --> URI Class Initialized
INFO - 2023-05-01 17:46:57 --> Router Class Initialized
INFO - 2023-05-01 17:46:57 --> Output Class Initialized
INFO - 2023-05-01 17:46:57 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:57 --> Input Class Initialized
INFO - 2023-05-01 17:46:57 --> Language Class Initialized
INFO - 2023-05-01 17:46:57 --> Language Class Initialized
INFO - 2023-05-01 17:46:57 --> Config Class Initialized
INFO - 2023-05-01 17:46:57 --> Loader Class Initialized
INFO - 2023-05-01 17:46:57 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:57 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:57 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:57 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:57 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:57 --> Controller Class Initialized
DEBUG - 2023-05-01 17:46:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 17:46:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:46:57 --> Final output sent to browser
DEBUG - 2023-05-01 17:46:57 --> Total execution time: 0.0416
INFO - 2023-05-01 17:46:57 --> Config Class Initialized
INFO - 2023-05-01 17:46:57 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:46:57 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:46:57 --> Utf8 Class Initialized
INFO - 2023-05-01 17:46:57 --> URI Class Initialized
INFO - 2023-05-01 17:46:57 --> Router Class Initialized
INFO - 2023-05-01 17:46:57 --> Output Class Initialized
INFO - 2023-05-01 17:46:57 --> Security Class Initialized
DEBUG - 2023-05-01 17:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:46:57 --> Input Class Initialized
INFO - 2023-05-01 17:46:57 --> Language Class Initialized
INFO - 2023-05-01 17:46:57 --> Language Class Initialized
INFO - 2023-05-01 17:46:57 --> Config Class Initialized
INFO - 2023-05-01 17:46:57 --> Loader Class Initialized
INFO - 2023-05-01 17:46:57 --> Helper loaded: url_helper
INFO - 2023-05-01 17:46:58 --> Helper loaded: file_helper
INFO - 2023-05-01 17:46:58 --> Helper loaded: form_helper
INFO - 2023-05-01 17:46:58 --> Helper loaded: my_helper
INFO - 2023-05-01 17:46:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:46:58 --> Controller Class Initialized
INFO - 2023-05-01 17:47:51 --> Config Class Initialized
INFO - 2023-05-01 17:47:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:47:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:47:51 --> Utf8 Class Initialized
INFO - 2023-05-01 17:47:51 --> URI Class Initialized
INFO - 2023-05-01 17:47:51 --> Router Class Initialized
INFO - 2023-05-01 17:47:51 --> Output Class Initialized
INFO - 2023-05-01 17:47:51 --> Security Class Initialized
DEBUG - 2023-05-01 17:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:47:51 --> Input Class Initialized
INFO - 2023-05-01 17:47:51 --> Language Class Initialized
INFO - 2023-05-01 17:47:51 --> Language Class Initialized
INFO - 2023-05-01 17:47:51 --> Config Class Initialized
INFO - 2023-05-01 17:47:51 --> Loader Class Initialized
INFO - 2023-05-01 17:47:51 --> Helper loaded: url_helper
INFO - 2023-05-01 17:47:51 --> Helper loaded: file_helper
INFO - 2023-05-01 17:47:51 --> Helper loaded: form_helper
INFO - 2023-05-01 17:47:51 --> Helper loaded: my_helper
INFO - 2023-05-01 17:47:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:47:51 --> Controller Class Initialized
DEBUG - 2023-05-01 17:47:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 17:47:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:47:51 --> Final output sent to browser
DEBUG - 2023-05-01 17:47:51 --> Total execution time: 0.0599
INFO - 2023-05-01 17:47:51 --> Config Class Initialized
INFO - 2023-05-01 17:47:51 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:47:51 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:47:51 --> Utf8 Class Initialized
INFO - 2023-05-01 17:47:51 --> URI Class Initialized
INFO - 2023-05-01 17:47:51 --> Router Class Initialized
INFO - 2023-05-01 17:47:51 --> Output Class Initialized
INFO - 2023-05-01 17:47:51 --> Security Class Initialized
DEBUG - 2023-05-01 17:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:47:51 --> Input Class Initialized
INFO - 2023-05-01 17:47:51 --> Language Class Initialized
INFO - 2023-05-01 17:47:51 --> Language Class Initialized
INFO - 2023-05-01 17:47:51 --> Config Class Initialized
INFO - 2023-05-01 17:47:51 --> Loader Class Initialized
INFO - 2023-05-01 17:47:51 --> Helper loaded: url_helper
INFO - 2023-05-01 17:47:51 --> Helper loaded: file_helper
INFO - 2023-05-01 17:47:51 --> Helper loaded: form_helper
INFO - 2023-05-01 17:47:51 --> Helper loaded: my_helper
INFO - 2023-05-01 17:47:51 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:47:51 --> Controller Class Initialized
INFO - 2023-05-01 17:48:12 --> Config Class Initialized
INFO - 2023-05-01 17:48:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:48:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:48:12 --> Utf8 Class Initialized
INFO - 2023-05-01 17:48:12 --> URI Class Initialized
INFO - 2023-05-01 17:48:12 --> Router Class Initialized
INFO - 2023-05-01 17:48:12 --> Output Class Initialized
INFO - 2023-05-01 17:48:12 --> Security Class Initialized
DEBUG - 2023-05-01 17:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:48:12 --> Input Class Initialized
INFO - 2023-05-01 17:48:12 --> Language Class Initialized
INFO - 2023-05-01 17:48:12 --> Language Class Initialized
INFO - 2023-05-01 17:48:12 --> Config Class Initialized
INFO - 2023-05-01 17:48:12 --> Loader Class Initialized
INFO - 2023-05-01 17:48:12 --> Helper loaded: url_helper
INFO - 2023-05-01 17:48:12 --> Helper loaded: file_helper
INFO - 2023-05-01 17:48:12 --> Helper loaded: form_helper
INFO - 2023-05-01 17:48:12 --> Helper loaded: my_helper
INFO - 2023-05-01 17:48:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:48:12 --> Controller Class Initialized
DEBUG - 2023-05-01 17:48:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 17:48:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:48:12 --> Final output sent to browser
DEBUG - 2023-05-01 17:48:12 --> Total execution time: 0.0416
INFO - 2023-05-01 17:48:12 --> Config Class Initialized
INFO - 2023-05-01 17:48:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:48:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:48:12 --> Utf8 Class Initialized
INFO - 2023-05-01 17:48:12 --> URI Class Initialized
INFO - 2023-05-01 17:48:12 --> Router Class Initialized
INFO - 2023-05-01 17:48:12 --> Output Class Initialized
INFO - 2023-05-01 17:48:12 --> Security Class Initialized
DEBUG - 2023-05-01 17:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:48:12 --> Input Class Initialized
INFO - 2023-05-01 17:48:12 --> Language Class Initialized
INFO - 2023-05-01 17:48:12 --> Language Class Initialized
INFO - 2023-05-01 17:48:12 --> Config Class Initialized
INFO - 2023-05-01 17:48:12 --> Loader Class Initialized
INFO - 2023-05-01 17:48:12 --> Helper loaded: url_helper
INFO - 2023-05-01 17:48:12 --> Helper loaded: file_helper
INFO - 2023-05-01 17:48:12 --> Helper loaded: form_helper
INFO - 2023-05-01 17:48:12 --> Helper loaded: my_helper
INFO - 2023-05-01 17:48:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:48:12 --> Controller Class Initialized
INFO - 2023-05-01 17:48:16 --> Config Class Initialized
INFO - 2023-05-01 17:48:16 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:48:16 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:48:16 --> Utf8 Class Initialized
INFO - 2023-05-01 17:48:16 --> URI Class Initialized
INFO - 2023-05-01 17:48:16 --> Router Class Initialized
INFO - 2023-05-01 17:48:16 --> Output Class Initialized
INFO - 2023-05-01 17:48:16 --> Security Class Initialized
DEBUG - 2023-05-01 17:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:48:16 --> Input Class Initialized
INFO - 2023-05-01 17:48:16 --> Language Class Initialized
INFO - 2023-05-01 17:48:16 --> Language Class Initialized
INFO - 2023-05-01 17:48:16 --> Config Class Initialized
INFO - 2023-05-01 17:48:16 --> Loader Class Initialized
INFO - 2023-05-01 17:48:16 --> Helper loaded: url_helper
INFO - 2023-05-01 17:48:16 --> Helper loaded: file_helper
INFO - 2023-05-01 17:48:16 --> Helper loaded: form_helper
INFO - 2023-05-01 17:48:16 --> Helper loaded: my_helper
INFO - 2023-05-01 17:48:16 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:48:16 --> Controller Class Initialized
INFO - 2023-05-01 17:48:16 --> Final output sent to browser
DEBUG - 2023-05-01 17:48:16 --> Total execution time: 0.0396
INFO - 2023-05-01 17:48:17 --> Config Class Initialized
INFO - 2023-05-01 17:48:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:48:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:48:17 --> Utf8 Class Initialized
INFO - 2023-05-01 17:48:17 --> URI Class Initialized
INFO - 2023-05-01 17:48:17 --> Router Class Initialized
INFO - 2023-05-01 17:48:17 --> Output Class Initialized
INFO - 2023-05-01 17:48:17 --> Security Class Initialized
DEBUG - 2023-05-01 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:48:17 --> Input Class Initialized
INFO - 2023-05-01 17:48:17 --> Language Class Initialized
INFO - 2023-05-01 17:48:17 --> Language Class Initialized
INFO - 2023-05-01 17:48:17 --> Config Class Initialized
INFO - 2023-05-01 17:48:17 --> Loader Class Initialized
INFO - 2023-05-01 17:48:17 --> Helper loaded: url_helper
INFO - 2023-05-01 17:48:17 --> Helper loaded: file_helper
INFO - 2023-05-01 17:48:17 --> Helper loaded: form_helper
INFO - 2023-05-01 17:48:17 --> Helper loaded: my_helper
INFO - 2023-05-01 17:48:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:48:17 --> Controller Class Initialized
INFO - 2023-05-01 17:48:17 --> Final output sent to browser
DEBUG - 2023-05-01 17:48:17 --> Total execution time: 0.0603
INFO - 2023-05-01 17:48:17 --> Config Class Initialized
INFO - 2023-05-01 17:48:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:48:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:48:17 --> Utf8 Class Initialized
INFO - 2023-05-01 17:48:17 --> URI Class Initialized
INFO - 2023-05-01 17:48:17 --> Router Class Initialized
INFO - 2023-05-01 17:48:17 --> Output Class Initialized
INFO - 2023-05-01 17:48:17 --> Security Class Initialized
DEBUG - 2023-05-01 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:48:17 --> Input Class Initialized
INFO - 2023-05-01 17:48:17 --> Language Class Initialized
INFO - 2023-05-01 17:48:17 --> Language Class Initialized
INFO - 2023-05-01 17:48:17 --> Config Class Initialized
INFO - 2023-05-01 17:48:17 --> Loader Class Initialized
INFO - 2023-05-01 17:48:17 --> Helper loaded: url_helper
INFO - 2023-05-01 17:48:17 --> Helper loaded: file_helper
INFO - 2023-05-01 17:48:17 --> Helper loaded: form_helper
INFO - 2023-05-01 17:48:17 --> Helper loaded: my_helper
INFO - 2023-05-01 17:48:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:48:18 --> Controller Class Initialized
INFO - 2023-05-01 17:48:18 --> Final output sent to browser
DEBUG - 2023-05-01 17:48:18 --> Total execution time: 0.0613
INFO - 2023-05-01 17:48:34 --> Config Class Initialized
INFO - 2023-05-01 17:48:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:48:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:48:34 --> Utf8 Class Initialized
INFO - 2023-05-01 17:48:34 --> URI Class Initialized
INFO - 2023-05-01 17:48:34 --> Router Class Initialized
INFO - 2023-05-01 17:48:34 --> Output Class Initialized
INFO - 2023-05-01 17:48:34 --> Security Class Initialized
DEBUG - 2023-05-01 17:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:48:34 --> Input Class Initialized
INFO - 2023-05-01 17:48:34 --> Language Class Initialized
INFO - 2023-05-01 17:48:34 --> Language Class Initialized
INFO - 2023-05-01 17:48:34 --> Config Class Initialized
INFO - 2023-05-01 17:48:34 --> Loader Class Initialized
INFO - 2023-05-01 17:48:34 --> Helper loaded: url_helper
INFO - 2023-05-01 17:48:34 --> Helper loaded: file_helper
INFO - 2023-05-01 17:48:34 --> Helper loaded: form_helper
INFO - 2023-05-01 17:48:34 --> Helper loaded: my_helper
INFO - 2023-05-01 17:48:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:48:34 --> Controller Class Initialized
INFO - 2023-05-01 17:50:39 --> Config Class Initialized
INFO - 2023-05-01 17:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:50:39 --> Utf8 Class Initialized
INFO - 2023-05-01 17:50:39 --> URI Class Initialized
INFO - 2023-05-01 17:50:39 --> Router Class Initialized
INFO - 2023-05-01 17:50:39 --> Output Class Initialized
INFO - 2023-05-01 17:50:39 --> Security Class Initialized
DEBUG - 2023-05-01 17:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:50:39 --> Input Class Initialized
INFO - 2023-05-01 17:50:39 --> Language Class Initialized
INFO - 2023-05-01 17:50:39 --> Language Class Initialized
INFO - 2023-05-01 17:50:39 --> Config Class Initialized
INFO - 2023-05-01 17:50:39 --> Loader Class Initialized
INFO - 2023-05-01 17:50:39 --> Helper loaded: url_helper
INFO - 2023-05-01 17:50:39 --> Helper loaded: file_helper
INFO - 2023-05-01 17:50:39 --> Helper loaded: form_helper
INFO - 2023-05-01 17:50:39 --> Helper loaded: my_helper
INFO - 2023-05-01 17:50:39 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:50:39 --> Controller Class Initialized
INFO - 2023-05-01 17:52:39 --> Config Class Initialized
INFO - 2023-05-01 17:52:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:39 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:39 --> URI Class Initialized
INFO - 2023-05-01 17:52:39 --> Router Class Initialized
INFO - 2023-05-01 17:52:39 --> Output Class Initialized
INFO - 2023-05-01 17:52:39 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:39 --> Input Class Initialized
INFO - 2023-05-01 17:52:39 --> Language Class Initialized
INFO - 2023-05-01 17:52:39 --> Language Class Initialized
INFO - 2023-05-01 17:52:39 --> Config Class Initialized
INFO - 2023-05-01 17:52:39 --> Loader Class Initialized
INFO - 2023-05-01 17:52:39 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:39 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:39 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:39 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:39 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:39 --> Controller Class Initialized
DEBUG - 2023-05-01 17:52:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/form.php
DEBUG - 2023-05-01 17:52:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:52:39 --> Final output sent to browser
DEBUG - 2023-05-01 17:52:39 --> Total execution time: 0.0379
INFO - 2023-05-01 17:52:42 --> Config Class Initialized
INFO - 2023-05-01 17:52:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:42 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:42 --> URI Class Initialized
INFO - 2023-05-01 17:52:42 --> Router Class Initialized
INFO - 2023-05-01 17:52:42 --> Output Class Initialized
INFO - 2023-05-01 17:52:42 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:42 --> Input Class Initialized
INFO - 2023-05-01 17:52:42 --> Language Class Initialized
INFO - 2023-05-01 17:52:42 --> Language Class Initialized
INFO - 2023-05-01 17:52:42 --> Config Class Initialized
INFO - 2023-05-01 17:52:42 --> Loader Class Initialized
INFO - 2023-05-01 17:52:42 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:42 --> Controller Class Initialized
INFO - 2023-05-01 17:52:42 --> Config Class Initialized
INFO - 2023-05-01 17:52:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:42 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:42 --> URI Class Initialized
INFO - 2023-05-01 17:52:42 --> Router Class Initialized
INFO - 2023-05-01 17:52:42 --> Output Class Initialized
INFO - 2023-05-01 17:52:42 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:42 --> Input Class Initialized
INFO - 2023-05-01 17:52:42 --> Language Class Initialized
INFO - 2023-05-01 17:52:42 --> Language Class Initialized
INFO - 2023-05-01 17:52:42 --> Config Class Initialized
INFO - 2023-05-01 17:52:42 --> Loader Class Initialized
INFO - 2023-05-01 17:52:42 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:42 --> Controller Class Initialized
DEBUG - 2023-05-01 17:52:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-05-01 17:52:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:52:42 --> Final output sent to browser
DEBUG - 2023-05-01 17:52:42 --> Total execution time: 0.0584
INFO - 2023-05-01 17:52:42 --> Config Class Initialized
INFO - 2023-05-01 17:52:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:42 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:42 --> URI Class Initialized
INFO - 2023-05-01 17:52:42 --> Router Class Initialized
INFO - 2023-05-01 17:52:42 --> Output Class Initialized
INFO - 2023-05-01 17:52:42 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:42 --> Input Class Initialized
INFO - 2023-05-01 17:52:42 --> Language Class Initialized
INFO - 2023-05-01 17:52:42 --> Language Class Initialized
INFO - 2023-05-01 17:52:42 --> Config Class Initialized
INFO - 2023-05-01 17:52:42 --> Loader Class Initialized
INFO - 2023-05-01 17:52:42 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:42 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:42 --> Controller Class Initialized
INFO - 2023-05-01 17:52:44 --> Config Class Initialized
INFO - 2023-05-01 17:52:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:44 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:44 --> URI Class Initialized
INFO - 2023-05-01 17:52:44 --> Router Class Initialized
INFO - 2023-05-01 17:52:44 --> Output Class Initialized
INFO - 2023-05-01 17:52:44 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:44 --> Input Class Initialized
INFO - 2023-05-01 17:52:44 --> Language Class Initialized
INFO - 2023-05-01 17:52:44 --> Language Class Initialized
INFO - 2023-05-01 17:52:44 --> Config Class Initialized
INFO - 2023-05-01 17:52:44 --> Loader Class Initialized
INFO - 2023-05-01 17:52:44 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:44 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:44 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:44 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:44 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:44 --> Controller Class Initialized
DEBUG - 2023-05-01 17:52:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 17:52:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:52:44 --> Final output sent to browser
DEBUG - 2023-05-01 17:52:44 --> Total execution time: 0.0332
INFO - 2023-05-01 17:52:46 --> Config Class Initialized
INFO - 2023-05-01 17:52:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:46 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:46 --> URI Class Initialized
INFO - 2023-05-01 17:52:46 --> Router Class Initialized
INFO - 2023-05-01 17:52:46 --> Output Class Initialized
INFO - 2023-05-01 17:52:46 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:46 --> Input Class Initialized
INFO - 2023-05-01 17:52:46 --> Language Class Initialized
INFO - 2023-05-01 17:52:46 --> Language Class Initialized
INFO - 2023-05-01 17:52:46 --> Config Class Initialized
INFO - 2023-05-01 17:52:46 --> Loader Class Initialized
INFO - 2023-05-01 17:52:46 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:46 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:46 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:46 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:46 --> Controller Class Initialized
DEBUG - 2023-05-01 17:52:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_preschool/views/list.php
DEBUG - 2023-05-01 17:52:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:52:46 --> Final output sent to browser
DEBUG - 2023-05-01 17:52:46 --> Total execution time: 0.0459
INFO - 2023-05-01 17:52:46 --> Config Class Initialized
INFO - 2023-05-01 17:52:46 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:46 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:46 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:46 --> URI Class Initialized
INFO - 2023-05-01 17:52:46 --> Router Class Initialized
INFO - 2023-05-01 17:52:46 --> Output Class Initialized
INFO - 2023-05-01 17:52:46 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:46 --> Input Class Initialized
INFO - 2023-05-01 17:52:46 --> Language Class Initialized
INFO - 2023-05-01 17:52:46 --> Language Class Initialized
INFO - 2023-05-01 17:52:46 --> Config Class Initialized
INFO - 2023-05-01 17:52:46 --> Loader Class Initialized
INFO - 2023-05-01 17:52:46 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:46 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:46 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:46 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:46 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:46 --> Controller Class Initialized
INFO - 2023-05-01 17:52:47 --> Config Class Initialized
INFO - 2023-05-01 17:52:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:47 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:47 --> URI Class Initialized
INFO - 2023-05-01 17:52:47 --> Router Class Initialized
INFO - 2023-05-01 17:52:47 --> Output Class Initialized
INFO - 2023-05-01 17:52:47 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:47 --> Input Class Initialized
INFO - 2023-05-01 17:52:47 --> Language Class Initialized
INFO - 2023-05-01 17:52:47 --> Language Class Initialized
INFO - 2023-05-01 17:52:47 --> Config Class Initialized
INFO - 2023-05-01 17:52:47 --> Loader Class Initialized
INFO - 2023-05-01 17:52:47 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:47 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:47 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:47 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:47 --> Controller Class Initialized
INFO - 2023-05-01 17:52:47 --> Final output sent to browser
DEBUG - 2023-05-01 17:52:47 --> Total execution time: 0.0522
INFO - 2023-05-01 17:52:49 --> Config Class Initialized
INFO - 2023-05-01 17:52:49 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:52:49 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:52:49 --> Utf8 Class Initialized
INFO - 2023-05-01 17:52:49 --> URI Class Initialized
INFO - 2023-05-01 17:52:49 --> Router Class Initialized
INFO - 2023-05-01 17:52:49 --> Output Class Initialized
INFO - 2023-05-01 17:52:49 --> Security Class Initialized
DEBUG - 2023-05-01 17:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:52:49 --> Input Class Initialized
INFO - 2023-05-01 17:52:49 --> Language Class Initialized
INFO - 2023-05-01 17:52:49 --> Language Class Initialized
INFO - 2023-05-01 17:52:49 --> Config Class Initialized
INFO - 2023-05-01 17:52:49 --> Loader Class Initialized
INFO - 2023-05-01 17:52:49 --> Helper loaded: url_helper
INFO - 2023-05-01 17:52:49 --> Helper loaded: file_helper
INFO - 2023-05-01 17:52:49 --> Helper loaded: form_helper
INFO - 2023-05-01 17:52:49 --> Helper loaded: my_helper
INFO - 2023-05-01 17:52:49 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:52:49 --> Controller Class Initialized
INFO - 2023-05-01 17:52:49 --> Final output sent to browser
DEBUG - 2023-05-01 17:52:49 --> Total execution time: 0.0310
INFO - 2023-05-01 17:53:21 --> Config Class Initialized
INFO - 2023-05-01 17:53:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:21 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:21 --> URI Class Initialized
INFO - 2023-05-01 17:53:21 --> Router Class Initialized
INFO - 2023-05-01 17:53:21 --> Output Class Initialized
INFO - 2023-05-01 17:53:21 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:21 --> Input Class Initialized
INFO - 2023-05-01 17:53:21 --> Language Class Initialized
INFO - 2023-05-01 17:53:21 --> Language Class Initialized
INFO - 2023-05-01 17:53:21 --> Config Class Initialized
INFO - 2023-05-01 17:53:21 --> Loader Class Initialized
INFO - 2023-05-01 17:53:21 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:21 --> Controller Class Initialized
INFO - 2023-05-01 17:53:21 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:53:21 --> Config Class Initialized
INFO - 2023-05-01 17:53:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:21 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:21 --> URI Class Initialized
INFO - 2023-05-01 17:53:21 --> Router Class Initialized
INFO - 2023-05-01 17:53:21 --> Output Class Initialized
INFO - 2023-05-01 17:53:21 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:21 --> Input Class Initialized
INFO - 2023-05-01 17:53:21 --> Language Class Initialized
INFO - 2023-05-01 17:53:21 --> Language Class Initialized
INFO - 2023-05-01 17:53:21 --> Config Class Initialized
INFO - 2023-05-01 17:53:21 --> Loader Class Initialized
INFO - 2023-05-01 17:53:21 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:21 --> Controller Class Initialized
INFO - 2023-05-01 17:53:21 --> Config Class Initialized
INFO - 2023-05-01 17:53:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:21 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:21 --> URI Class Initialized
INFO - 2023-05-01 17:53:21 --> Router Class Initialized
INFO - 2023-05-01 17:53:21 --> Output Class Initialized
INFO - 2023-05-01 17:53:21 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:21 --> Input Class Initialized
INFO - 2023-05-01 17:53:21 --> Language Class Initialized
INFO - 2023-05-01 17:53:21 --> Language Class Initialized
INFO - 2023-05-01 17:53:21 --> Config Class Initialized
INFO - 2023-05-01 17:53:21 --> Loader Class Initialized
INFO - 2023-05-01 17:53:21 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:21 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:21 --> Controller Class Initialized
DEBUG - 2023-05-01 17:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 17:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:53:21 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:21 --> Total execution time: 0.0278
INFO - 2023-05-01 17:53:26 --> Config Class Initialized
INFO - 2023-05-01 17:53:26 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:26 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:26 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:26 --> URI Class Initialized
INFO - 2023-05-01 17:53:26 --> Router Class Initialized
INFO - 2023-05-01 17:53:26 --> Output Class Initialized
INFO - 2023-05-01 17:53:26 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:26 --> Input Class Initialized
INFO - 2023-05-01 17:53:26 --> Language Class Initialized
INFO - 2023-05-01 17:53:26 --> Language Class Initialized
INFO - 2023-05-01 17:53:26 --> Config Class Initialized
INFO - 2023-05-01 17:53:26 --> Loader Class Initialized
INFO - 2023-05-01 17:53:26 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:26 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:26 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:26 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:26 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:26 --> Controller Class Initialized
INFO - 2023-05-01 17:53:26 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:53:26 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:26 --> Total execution time: 0.0294
INFO - 2023-05-01 17:53:26 --> Config Class Initialized
INFO - 2023-05-01 17:53:26 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:26 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:26 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:26 --> URI Class Initialized
INFO - 2023-05-01 17:53:26 --> Router Class Initialized
INFO - 2023-05-01 17:53:26 --> Output Class Initialized
INFO - 2023-05-01 17:53:26 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:26 --> Input Class Initialized
INFO - 2023-05-01 17:53:26 --> Language Class Initialized
INFO - 2023-05-01 17:53:26 --> Language Class Initialized
INFO - 2023-05-01 17:53:26 --> Config Class Initialized
INFO - 2023-05-01 17:53:26 --> Loader Class Initialized
INFO - 2023-05-01 17:53:26 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:26 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:26 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:26 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:26 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:26 --> Controller Class Initialized
DEBUG - 2023-05-01 17:53:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-01 17:53:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:53:26 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:26 --> Total execution time: 0.0350
INFO - 2023-05-01 17:53:31 --> Config Class Initialized
INFO - 2023-05-01 17:53:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:31 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:31 --> URI Class Initialized
INFO - 2023-05-01 17:53:31 --> Router Class Initialized
INFO - 2023-05-01 17:53:31 --> Output Class Initialized
INFO - 2023-05-01 17:53:31 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:31 --> Input Class Initialized
INFO - 2023-05-01 17:53:31 --> Language Class Initialized
INFO - 2023-05-01 17:53:31 --> Language Class Initialized
INFO - 2023-05-01 17:53:31 --> Config Class Initialized
INFO - 2023-05-01 17:53:31 --> Loader Class Initialized
INFO - 2023-05-01 17:53:31 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:31 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:31 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:31 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:31 --> Controller Class Initialized
DEBUG - 2023-05-01 17:53:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-05-01 17:53:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:53:31 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:31 --> Total execution time: 0.0329
INFO - 2023-05-01 17:53:31 --> Config Class Initialized
INFO - 2023-05-01 17:53:31 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:31 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:31 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:31 --> URI Class Initialized
INFO - 2023-05-01 17:53:31 --> Router Class Initialized
INFO - 2023-05-01 17:53:31 --> Output Class Initialized
INFO - 2023-05-01 17:53:31 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:31 --> Input Class Initialized
INFO - 2023-05-01 17:53:31 --> Language Class Initialized
INFO - 2023-05-01 17:53:31 --> Language Class Initialized
INFO - 2023-05-01 17:53:31 --> Config Class Initialized
INFO - 2023-05-01 17:53:31 --> Loader Class Initialized
INFO - 2023-05-01 17:53:31 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:31 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:31 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:31 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:31 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:31 --> Controller Class Initialized
INFO - 2023-05-01 17:53:36 --> Config Class Initialized
INFO - 2023-05-01 17:53:36 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:36 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:36 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:36 --> URI Class Initialized
INFO - 2023-05-01 17:53:36 --> Router Class Initialized
INFO - 2023-05-01 17:53:36 --> Output Class Initialized
INFO - 2023-05-01 17:53:36 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:36 --> Input Class Initialized
INFO - 2023-05-01 17:53:36 --> Language Class Initialized
INFO - 2023-05-01 17:53:36 --> Language Class Initialized
INFO - 2023-05-01 17:53:36 --> Config Class Initialized
INFO - 2023-05-01 17:53:36 --> Loader Class Initialized
INFO - 2023-05-01 17:53:36 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:36 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:36 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:36 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:36 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:36 --> Controller Class Initialized
DEBUG - 2023-05-01 17:53:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-05-01 17:53:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:53:36 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:36 --> Total execution time: 0.0482
INFO - 2023-05-01 17:53:41 --> Config Class Initialized
INFO - 2023-05-01 17:53:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:41 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:41 --> URI Class Initialized
INFO - 2023-05-01 17:53:41 --> Router Class Initialized
INFO - 2023-05-01 17:53:41 --> Output Class Initialized
INFO - 2023-05-01 17:53:41 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:41 --> Input Class Initialized
INFO - 2023-05-01 17:53:41 --> Language Class Initialized
INFO - 2023-05-01 17:53:41 --> Language Class Initialized
INFO - 2023-05-01 17:53:41 --> Config Class Initialized
INFO - 2023-05-01 17:53:41 --> Loader Class Initialized
INFO - 2023-05-01 17:53:41 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:41 --> Controller Class Initialized
INFO - 2023-05-01 17:53:41 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:53:41 --> Config Class Initialized
INFO - 2023-05-01 17:53:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:41 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:41 --> URI Class Initialized
INFO - 2023-05-01 17:53:41 --> Router Class Initialized
INFO - 2023-05-01 17:53:41 --> Output Class Initialized
INFO - 2023-05-01 17:53:41 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:41 --> Input Class Initialized
INFO - 2023-05-01 17:53:41 --> Language Class Initialized
INFO - 2023-05-01 17:53:41 --> Language Class Initialized
INFO - 2023-05-01 17:53:41 --> Config Class Initialized
INFO - 2023-05-01 17:53:41 --> Loader Class Initialized
INFO - 2023-05-01 17:53:41 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:41 --> Controller Class Initialized
INFO - 2023-05-01 17:53:41 --> Config Class Initialized
INFO - 2023-05-01 17:53:41 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:41 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:41 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:41 --> URI Class Initialized
INFO - 2023-05-01 17:53:41 --> Router Class Initialized
INFO - 2023-05-01 17:53:41 --> Output Class Initialized
INFO - 2023-05-01 17:53:41 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:41 --> Input Class Initialized
INFO - 2023-05-01 17:53:41 --> Language Class Initialized
INFO - 2023-05-01 17:53:41 --> Language Class Initialized
INFO - 2023-05-01 17:53:41 --> Config Class Initialized
INFO - 2023-05-01 17:53:41 --> Loader Class Initialized
INFO - 2023-05-01 17:53:41 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:41 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:41 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:41 --> Controller Class Initialized
DEBUG - 2023-05-01 17:53:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 17:53:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:53:41 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:41 --> Total execution time: 0.0259
INFO - 2023-05-01 17:53:45 --> Config Class Initialized
INFO - 2023-05-01 17:53:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:45 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:45 --> URI Class Initialized
INFO - 2023-05-01 17:53:45 --> Router Class Initialized
INFO - 2023-05-01 17:53:45 --> Output Class Initialized
INFO - 2023-05-01 17:53:45 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:45 --> Input Class Initialized
INFO - 2023-05-01 17:53:45 --> Language Class Initialized
INFO - 2023-05-01 17:53:45 --> Language Class Initialized
INFO - 2023-05-01 17:53:45 --> Config Class Initialized
INFO - 2023-05-01 17:53:45 --> Loader Class Initialized
INFO - 2023-05-01 17:53:45 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:45 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:45 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:45 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:45 --> Controller Class Initialized
INFO - 2023-05-01 17:53:45 --> Helper loaded: cookie_helper
INFO - 2023-05-01 17:53:45 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:45 --> Total execution time: 0.0360
INFO - 2023-05-01 17:53:45 --> Config Class Initialized
INFO - 2023-05-01 17:53:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 17:53:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 17:53:45 --> Utf8 Class Initialized
INFO - 2023-05-01 17:53:45 --> URI Class Initialized
INFO - 2023-05-01 17:53:45 --> Router Class Initialized
INFO - 2023-05-01 17:53:45 --> Output Class Initialized
INFO - 2023-05-01 17:53:45 --> Security Class Initialized
DEBUG - 2023-05-01 17:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 17:53:45 --> Input Class Initialized
INFO - 2023-05-01 17:53:45 --> Language Class Initialized
INFO - 2023-05-01 17:53:45 --> Language Class Initialized
INFO - 2023-05-01 17:53:45 --> Config Class Initialized
INFO - 2023-05-01 17:53:45 --> Loader Class Initialized
INFO - 2023-05-01 17:53:45 --> Helper loaded: url_helper
INFO - 2023-05-01 17:53:45 --> Helper loaded: file_helper
INFO - 2023-05-01 17:53:45 --> Helper loaded: form_helper
INFO - 2023-05-01 17:53:45 --> Helper loaded: my_helper
INFO - 2023-05-01 17:53:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 17:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 17:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 17:53:45 --> Controller Class Initialized
DEBUG - 2023-05-01 17:53:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 17:53:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 17:53:45 --> Final output sent to browser
DEBUG - 2023-05-01 17:53:45 --> Total execution time: 0.0516
INFO - 2023-05-01 18:14:30 --> Config Class Initialized
INFO - 2023-05-01 18:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:30 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:30 --> URI Class Initialized
INFO - 2023-05-01 18:14:30 --> Router Class Initialized
INFO - 2023-05-01 18:14:30 --> Output Class Initialized
INFO - 2023-05-01 18:14:30 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:30 --> Input Class Initialized
INFO - 2023-05-01 18:14:30 --> Language Class Initialized
INFO - 2023-05-01 18:14:30 --> Language Class Initialized
INFO - 2023-05-01 18:14:30 --> Config Class Initialized
INFO - 2023-05-01 18:14:30 --> Loader Class Initialized
INFO - 2023-05-01 18:14:30 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:30 --> Controller Class Initialized
INFO - 2023-05-01 18:14:30 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:30 --> Config Class Initialized
INFO - 2023-05-01 18:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:30 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:30 --> URI Class Initialized
INFO - 2023-05-01 18:14:30 --> Router Class Initialized
INFO - 2023-05-01 18:14:30 --> Output Class Initialized
INFO - 2023-05-01 18:14:30 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:30 --> Input Class Initialized
INFO - 2023-05-01 18:14:30 --> Language Class Initialized
INFO - 2023-05-01 18:14:30 --> Language Class Initialized
INFO - 2023-05-01 18:14:30 --> Config Class Initialized
INFO - 2023-05-01 18:14:30 --> Loader Class Initialized
INFO - 2023-05-01 18:14:30 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:30 --> Controller Class Initialized
INFO - 2023-05-01 18:14:30 --> Config Class Initialized
INFO - 2023-05-01 18:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:30 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:30 --> URI Class Initialized
INFO - 2023-05-01 18:14:30 --> Router Class Initialized
INFO - 2023-05-01 18:14:30 --> Output Class Initialized
INFO - 2023-05-01 18:14:30 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:30 --> Input Class Initialized
INFO - 2023-05-01 18:14:30 --> Language Class Initialized
INFO - 2023-05-01 18:14:30 --> Language Class Initialized
INFO - 2023-05-01 18:14:30 --> Config Class Initialized
INFO - 2023-05-01 18:14:30 --> Loader Class Initialized
INFO - 2023-05-01 18:14:30 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:30 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:30 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 18:14:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:14:30 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:30 --> Total execution time: 0.0442
INFO - 2023-05-01 18:14:43 --> Config Class Initialized
INFO - 2023-05-01 18:14:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:43 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:43 --> URI Class Initialized
INFO - 2023-05-01 18:14:43 --> Router Class Initialized
INFO - 2023-05-01 18:14:43 --> Output Class Initialized
INFO - 2023-05-01 18:14:43 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:43 --> Input Class Initialized
INFO - 2023-05-01 18:14:43 --> Language Class Initialized
INFO - 2023-05-01 18:14:43 --> Language Class Initialized
INFO - 2023-05-01 18:14:43 --> Config Class Initialized
INFO - 2023-05-01 18:14:43 --> Loader Class Initialized
INFO - 2023-05-01 18:14:43 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:43 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:43 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:43 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:43 --> Controller Class Initialized
INFO - 2023-05-01 18:14:43 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:14:43 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:43 --> Total execution time: 0.0367
INFO - 2023-05-01 18:14:43 --> Config Class Initialized
INFO - 2023-05-01 18:14:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:43 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:43 --> URI Class Initialized
INFO - 2023-05-01 18:14:43 --> Router Class Initialized
INFO - 2023-05-01 18:14:43 --> Output Class Initialized
INFO - 2023-05-01 18:14:43 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:43 --> Input Class Initialized
INFO - 2023-05-01 18:14:43 --> Language Class Initialized
INFO - 2023-05-01 18:14:43 --> Language Class Initialized
INFO - 2023-05-01 18:14:43 --> Config Class Initialized
INFO - 2023-05-01 18:14:43 --> Loader Class Initialized
INFO - 2023-05-01 18:14:43 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:43 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:43 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:43 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:43 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-05-01 18:14:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:14:43 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:43 --> Total execution time: 0.0536
INFO - 2023-05-01 18:14:50 --> Config Class Initialized
INFO - 2023-05-01 18:14:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:50 --> URI Class Initialized
INFO - 2023-05-01 18:14:50 --> Router Class Initialized
INFO - 2023-05-01 18:14:50 --> Output Class Initialized
INFO - 2023-05-01 18:14:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:50 --> Input Class Initialized
INFO - 2023-05-01 18:14:50 --> Language Class Initialized
INFO - 2023-05-01 18:14:50 --> Language Class Initialized
INFO - 2023-05-01 18:14:50 --> Config Class Initialized
INFO - 2023-05-01 18:14:50 --> Loader Class Initialized
INFO - 2023-05-01 18:14:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:50 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:50 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:50 --> Controller Class Initialized
DEBUG - 2023-05-01 18:14:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-05-01 18:14:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:14:50 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:50 --> Total execution time: 0.0303
INFO - 2023-05-01 18:14:50 --> Config Class Initialized
INFO - 2023-05-01 18:14:50 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:50 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:50 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:50 --> URI Class Initialized
INFO - 2023-05-01 18:14:50 --> Router Class Initialized
INFO - 2023-05-01 18:14:50 --> Output Class Initialized
INFO - 2023-05-01 18:14:50 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:50 --> Input Class Initialized
INFO - 2023-05-01 18:14:50 --> Language Class Initialized
INFO - 2023-05-01 18:14:50 --> Language Class Initialized
INFO - 2023-05-01 18:14:50 --> Config Class Initialized
INFO - 2023-05-01 18:14:50 --> Loader Class Initialized
INFO - 2023-05-01 18:14:50 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:50 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:50 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:50 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:50 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:50 --> Controller Class Initialized
INFO - 2023-05-01 18:14:54 --> Config Class Initialized
INFO - 2023-05-01 18:14:54 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:14:54 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:14:54 --> Utf8 Class Initialized
INFO - 2023-05-01 18:14:54 --> URI Class Initialized
INFO - 2023-05-01 18:14:54 --> Router Class Initialized
INFO - 2023-05-01 18:14:54 --> Output Class Initialized
INFO - 2023-05-01 18:14:54 --> Security Class Initialized
DEBUG - 2023-05-01 18:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:14:54 --> Input Class Initialized
INFO - 2023-05-01 18:14:54 --> Language Class Initialized
INFO - 2023-05-01 18:14:54 --> Language Class Initialized
INFO - 2023-05-01 18:14:54 --> Config Class Initialized
INFO - 2023-05-01 18:14:54 --> Loader Class Initialized
INFO - 2023-05-01 18:14:54 --> Helper loaded: url_helper
INFO - 2023-05-01 18:14:54 --> Helper loaded: file_helper
INFO - 2023-05-01 18:14:54 --> Helper loaded: form_helper
INFO - 2023-05-01 18:14:54 --> Helper loaded: my_helper
INFO - 2023-05-01 18:14:54 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:14:54 --> Controller Class Initialized
INFO - 2023-05-01 18:14:54 --> Final output sent to browser
DEBUG - 2023-05-01 18:14:54 --> Total execution time: 0.0333
INFO - 2023-05-01 18:16:35 --> Config Class Initialized
INFO - 2023-05-01 18:16:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:16:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:16:35 --> Utf8 Class Initialized
INFO - 2023-05-01 18:16:35 --> URI Class Initialized
INFO - 2023-05-01 18:16:35 --> Router Class Initialized
INFO - 2023-05-01 18:16:35 --> Output Class Initialized
INFO - 2023-05-01 18:16:35 --> Security Class Initialized
DEBUG - 2023-05-01 18:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:16:35 --> Input Class Initialized
INFO - 2023-05-01 18:16:35 --> Language Class Initialized
INFO - 2023-05-01 18:16:35 --> Language Class Initialized
INFO - 2023-05-01 18:16:35 --> Config Class Initialized
INFO - 2023-05-01 18:16:35 --> Loader Class Initialized
INFO - 2023-05-01 18:16:35 --> Helper loaded: url_helper
INFO - 2023-05-01 18:16:35 --> Helper loaded: file_helper
INFO - 2023-05-01 18:16:35 --> Helper loaded: form_helper
INFO - 2023-05-01 18:16:35 --> Helper loaded: my_helper
INFO - 2023-05-01 18:16:35 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:16:35 --> Controller Class Initialized
INFO - 2023-05-01 18:16:35 --> Final output sent to browser
DEBUG - 2023-05-01 18:16:35 --> Total execution time: 0.0534
INFO - 2023-05-01 18:16:56 --> Config Class Initialized
INFO - 2023-05-01 18:16:56 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:16:56 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:16:56 --> Utf8 Class Initialized
INFO - 2023-05-01 18:16:56 --> URI Class Initialized
INFO - 2023-05-01 18:16:56 --> Router Class Initialized
INFO - 2023-05-01 18:16:56 --> Output Class Initialized
INFO - 2023-05-01 18:16:56 --> Security Class Initialized
DEBUG - 2023-05-01 18:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:16:56 --> Input Class Initialized
INFO - 2023-05-01 18:16:56 --> Language Class Initialized
INFO - 2023-05-01 18:16:56 --> Language Class Initialized
INFO - 2023-05-01 18:16:56 --> Config Class Initialized
INFO - 2023-05-01 18:16:56 --> Loader Class Initialized
INFO - 2023-05-01 18:16:56 --> Helper loaded: url_helper
INFO - 2023-05-01 18:16:56 --> Helper loaded: file_helper
INFO - 2023-05-01 18:16:56 --> Helper loaded: form_helper
INFO - 2023-05-01 18:16:56 --> Helper loaded: my_helper
INFO - 2023-05-01 18:16:56 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:16:56 --> Controller Class Initialized
INFO - 2023-05-01 18:16:56 --> Final output sent to browser
DEBUG - 2023-05-01 18:16:56 --> Total execution time: 0.0492
INFO - 2023-05-01 18:18:34 --> Config Class Initialized
INFO - 2023-05-01 18:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:18:34 --> Utf8 Class Initialized
INFO - 2023-05-01 18:18:34 --> URI Class Initialized
INFO - 2023-05-01 18:18:34 --> Router Class Initialized
INFO - 2023-05-01 18:18:34 --> Output Class Initialized
INFO - 2023-05-01 18:18:34 --> Security Class Initialized
DEBUG - 2023-05-01 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:18:34 --> Input Class Initialized
INFO - 2023-05-01 18:18:34 --> Language Class Initialized
INFO - 2023-05-01 18:18:34 --> Language Class Initialized
INFO - 2023-05-01 18:18:34 --> Config Class Initialized
INFO - 2023-05-01 18:18:34 --> Loader Class Initialized
INFO - 2023-05-01 18:18:34 --> Helper loaded: url_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: file_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: form_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: my_helper
INFO - 2023-05-01 18:18:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:18:34 --> Controller Class Initialized
INFO - 2023-05-01 18:18:34 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:18:34 --> Config Class Initialized
INFO - 2023-05-01 18:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:18:34 --> Utf8 Class Initialized
INFO - 2023-05-01 18:18:34 --> URI Class Initialized
INFO - 2023-05-01 18:18:34 --> Router Class Initialized
INFO - 2023-05-01 18:18:34 --> Output Class Initialized
INFO - 2023-05-01 18:18:34 --> Security Class Initialized
DEBUG - 2023-05-01 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:18:34 --> Input Class Initialized
INFO - 2023-05-01 18:18:34 --> Language Class Initialized
INFO - 2023-05-01 18:18:34 --> Language Class Initialized
INFO - 2023-05-01 18:18:34 --> Config Class Initialized
INFO - 2023-05-01 18:18:34 --> Loader Class Initialized
INFO - 2023-05-01 18:18:34 --> Helper loaded: url_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: file_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: form_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: my_helper
INFO - 2023-05-01 18:18:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:18:34 --> Controller Class Initialized
INFO - 2023-05-01 18:18:34 --> Config Class Initialized
INFO - 2023-05-01 18:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:18:34 --> Utf8 Class Initialized
INFO - 2023-05-01 18:18:34 --> URI Class Initialized
INFO - 2023-05-01 18:18:34 --> Router Class Initialized
INFO - 2023-05-01 18:18:34 --> Output Class Initialized
INFO - 2023-05-01 18:18:34 --> Security Class Initialized
DEBUG - 2023-05-01 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:18:34 --> Input Class Initialized
INFO - 2023-05-01 18:18:34 --> Language Class Initialized
INFO - 2023-05-01 18:18:34 --> Language Class Initialized
INFO - 2023-05-01 18:18:34 --> Config Class Initialized
INFO - 2023-05-01 18:18:34 --> Loader Class Initialized
INFO - 2023-05-01 18:18:34 --> Helper loaded: url_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: file_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: form_helper
INFO - 2023-05-01 18:18:34 --> Helper loaded: my_helper
INFO - 2023-05-01 18:18:34 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:18:34 --> Controller Class Initialized
DEBUG - 2023-05-01 18:18:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 18:18:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:18:34 --> Final output sent to browser
DEBUG - 2023-05-01 18:18:34 --> Total execution time: 0.0392
INFO - 2023-05-01 18:18:40 --> Config Class Initialized
INFO - 2023-05-01 18:18:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:18:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:18:40 --> Utf8 Class Initialized
INFO - 2023-05-01 18:18:40 --> URI Class Initialized
INFO - 2023-05-01 18:18:40 --> Router Class Initialized
INFO - 2023-05-01 18:18:40 --> Output Class Initialized
INFO - 2023-05-01 18:18:40 --> Security Class Initialized
DEBUG - 2023-05-01 18:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:18:40 --> Input Class Initialized
INFO - 2023-05-01 18:18:40 --> Language Class Initialized
INFO - 2023-05-01 18:18:40 --> Language Class Initialized
INFO - 2023-05-01 18:18:40 --> Config Class Initialized
INFO - 2023-05-01 18:18:40 --> Loader Class Initialized
INFO - 2023-05-01 18:18:40 --> Helper loaded: url_helper
INFO - 2023-05-01 18:18:40 --> Helper loaded: file_helper
INFO - 2023-05-01 18:18:40 --> Helper loaded: form_helper
INFO - 2023-05-01 18:18:40 --> Helper loaded: my_helper
INFO - 2023-05-01 18:18:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:18:40 --> Controller Class Initialized
INFO - 2023-05-01 18:18:40 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:18:40 --> Final output sent to browser
DEBUG - 2023-05-01 18:18:40 --> Total execution time: 0.0330
INFO - 2023-05-01 18:18:40 --> Config Class Initialized
INFO - 2023-05-01 18:18:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:18:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:18:40 --> Utf8 Class Initialized
INFO - 2023-05-01 18:18:40 --> URI Class Initialized
INFO - 2023-05-01 18:18:40 --> Router Class Initialized
INFO - 2023-05-01 18:18:40 --> Output Class Initialized
INFO - 2023-05-01 18:18:40 --> Security Class Initialized
DEBUG - 2023-05-01 18:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:18:40 --> Input Class Initialized
INFO - 2023-05-01 18:18:40 --> Language Class Initialized
INFO - 2023-05-01 18:18:40 --> Language Class Initialized
INFO - 2023-05-01 18:18:40 --> Config Class Initialized
INFO - 2023-05-01 18:18:40 --> Loader Class Initialized
INFO - 2023-05-01 18:18:40 --> Helper loaded: url_helper
INFO - 2023-05-01 18:18:40 --> Helper loaded: file_helper
INFO - 2023-05-01 18:18:40 --> Helper loaded: form_helper
INFO - 2023-05-01 18:18:40 --> Helper loaded: my_helper
INFO - 2023-05-01 18:18:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:18:40 --> Controller Class Initialized
DEBUG - 2023-05-01 18:18:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:18:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:18:40 --> Final output sent to browser
DEBUG - 2023-05-01 18:18:40 --> Total execution time: 0.0343
INFO - 2023-05-01 18:21:27 --> Config Class Initialized
INFO - 2023-05-01 18:21:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:21:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:21:27 --> Utf8 Class Initialized
INFO - 2023-05-01 18:21:27 --> URI Class Initialized
INFO - 2023-05-01 18:21:27 --> Router Class Initialized
INFO - 2023-05-01 18:21:27 --> Output Class Initialized
INFO - 2023-05-01 18:21:27 --> Security Class Initialized
DEBUG - 2023-05-01 18:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:21:27 --> Input Class Initialized
INFO - 2023-05-01 18:21:27 --> Language Class Initialized
INFO - 2023-05-01 18:21:27 --> Language Class Initialized
INFO - 2023-05-01 18:21:27 --> Config Class Initialized
INFO - 2023-05-01 18:21:27 --> Loader Class Initialized
INFO - 2023-05-01 18:21:27 --> Helper loaded: url_helper
INFO - 2023-05-01 18:21:27 --> Helper loaded: file_helper
INFO - 2023-05-01 18:21:27 --> Helper loaded: form_helper
INFO - 2023-05-01 18:21:27 --> Helper loaded: my_helper
INFO - 2023-05-01 18:21:27 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:21:27 --> Controller Class Initialized
DEBUG - 2023-05-01 18:21:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:21:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:21:27 --> Final output sent to browser
DEBUG - 2023-05-01 18:21:27 --> Total execution time: 0.0296
INFO - 2023-05-01 18:23:30 --> Config Class Initialized
INFO - 2023-05-01 18:23:30 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:23:30 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:23:30 --> Utf8 Class Initialized
INFO - 2023-05-01 18:23:30 --> URI Class Initialized
INFO - 2023-05-01 18:23:30 --> Router Class Initialized
INFO - 2023-05-01 18:23:30 --> Output Class Initialized
INFO - 2023-05-01 18:23:30 --> Security Class Initialized
DEBUG - 2023-05-01 18:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:23:30 --> Input Class Initialized
INFO - 2023-05-01 18:23:30 --> Language Class Initialized
INFO - 2023-05-01 18:23:30 --> Language Class Initialized
INFO - 2023-05-01 18:23:30 --> Config Class Initialized
INFO - 2023-05-01 18:23:30 --> Loader Class Initialized
INFO - 2023-05-01 18:23:30 --> Helper loaded: url_helper
INFO - 2023-05-01 18:23:30 --> Helper loaded: file_helper
INFO - 2023-05-01 18:23:30 --> Helper loaded: form_helper
INFO - 2023-05-01 18:23:30 --> Helper loaded: my_helper
INFO - 2023-05-01 18:23:30 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:23:30 --> Controller Class Initialized
DEBUG - 2023-05-01 18:23:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:23:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:23:30 --> Final output sent to browser
DEBUG - 2023-05-01 18:23:30 --> Total execution time: 0.0291
INFO - 2023-05-01 18:24:13 --> Config Class Initialized
INFO - 2023-05-01 18:24:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:24:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:24:13 --> Utf8 Class Initialized
INFO - 2023-05-01 18:24:13 --> URI Class Initialized
INFO - 2023-05-01 18:24:13 --> Router Class Initialized
INFO - 2023-05-01 18:24:13 --> Output Class Initialized
INFO - 2023-05-01 18:24:13 --> Security Class Initialized
DEBUG - 2023-05-01 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:24:13 --> Input Class Initialized
INFO - 2023-05-01 18:24:13 --> Language Class Initialized
INFO - 2023-05-01 18:24:13 --> Language Class Initialized
INFO - 2023-05-01 18:24:13 --> Config Class Initialized
INFO - 2023-05-01 18:24:13 --> Loader Class Initialized
INFO - 2023-05-01 18:24:13 --> Helper loaded: url_helper
INFO - 2023-05-01 18:24:13 --> Helper loaded: file_helper
INFO - 2023-05-01 18:24:13 --> Helper loaded: form_helper
INFO - 2023-05-01 18:24:13 --> Helper loaded: my_helper
INFO - 2023-05-01 18:24:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:24:13 --> Controller Class Initialized
DEBUG - 2023-05-01 18:24:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:24:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:24:13 --> Final output sent to browser
DEBUG - 2023-05-01 18:24:13 --> Total execution time: 0.0816
INFO - 2023-05-01 18:25:07 --> Config Class Initialized
INFO - 2023-05-01 18:25:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:07 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:07 --> URI Class Initialized
INFO - 2023-05-01 18:25:07 --> Router Class Initialized
INFO - 2023-05-01 18:25:07 --> Output Class Initialized
INFO - 2023-05-01 18:25:07 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:07 --> Input Class Initialized
INFO - 2023-05-01 18:25:07 --> Language Class Initialized
INFO - 2023-05-01 18:25:07 --> Language Class Initialized
INFO - 2023-05-01 18:25:07 --> Config Class Initialized
INFO - 2023-05-01 18:25:07 --> Loader Class Initialized
INFO - 2023-05-01 18:25:07 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:07 --> Controller Class Initialized
INFO - 2023-05-01 18:25:07 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:07 --> Config Class Initialized
INFO - 2023-05-01 18:25:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:07 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:07 --> URI Class Initialized
INFO - 2023-05-01 18:25:07 --> Router Class Initialized
INFO - 2023-05-01 18:25:07 --> Output Class Initialized
INFO - 2023-05-01 18:25:07 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:07 --> Input Class Initialized
INFO - 2023-05-01 18:25:07 --> Language Class Initialized
INFO - 2023-05-01 18:25:07 --> Language Class Initialized
INFO - 2023-05-01 18:25:07 --> Config Class Initialized
INFO - 2023-05-01 18:25:07 --> Loader Class Initialized
INFO - 2023-05-01 18:25:07 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:07 --> Controller Class Initialized
INFO - 2023-05-01 18:25:07 --> Config Class Initialized
INFO - 2023-05-01 18:25:07 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:07 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:07 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:07 --> URI Class Initialized
INFO - 2023-05-01 18:25:07 --> Router Class Initialized
INFO - 2023-05-01 18:25:07 --> Output Class Initialized
INFO - 2023-05-01 18:25:07 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:07 --> Input Class Initialized
INFO - 2023-05-01 18:25:07 --> Language Class Initialized
INFO - 2023-05-01 18:25:07 --> Language Class Initialized
INFO - 2023-05-01 18:25:07 --> Config Class Initialized
INFO - 2023-05-01 18:25:07 --> Loader Class Initialized
INFO - 2023-05-01 18:25:07 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:07 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:07 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:07 --> Controller Class Initialized
DEBUG - 2023-05-01 18:25:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 18:25:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:25:07 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:07 --> Total execution time: 0.0426
INFO - 2023-05-01 18:25:11 --> Config Class Initialized
INFO - 2023-05-01 18:25:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:11 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:11 --> URI Class Initialized
INFO - 2023-05-01 18:25:11 --> Router Class Initialized
INFO - 2023-05-01 18:25:11 --> Output Class Initialized
INFO - 2023-05-01 18:25:11 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:11 --> Input Class Initialized
INFO - 2023-05-01 18:25:11 --> Language Class Initialized
INFO - 2023-05-01 18:25:11 --> Language Class Initialized
INFO - 2023-05-01 18:25:11 --> Config Class Initialized
INFO - 2023-05-01 18:25:11 --> Loader Class Initialized
INFO - 2023-05-01 18:25:11 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:11 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:11 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:11 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:11 --> Controller Class Initialized
INFO - 2023-05-01 18:25:11 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:25:11 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:11 --> Total execution time: 0.0245
INFO - 2023-05-01 18:25:11 --> Config Class Initialized
INFO - 2023-05-01 18:25:11 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:11 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:11 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:11 --> URI Class Initialized
INFO - 2023-05-01 18:25:11 --> Router Class Initialized
INFO - 2023-05-01 18:25:11 --> Output Class Initialized
INFO - 2023-05-01 18:25:11 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:11 --> Input Class Initialized
INFO - 2023-05-01 18:25:11 --> Language Class Initialized
INFO - 2023-05-01 18:25:11 --> Language Class Initialized
INFO - 2023-05-01 18:25:11 --> Config Class Initialized
INFO - 2023-05-01 18:25:11 --> Loader Class Initialized
INFO - 2023-05-01 18:25:11 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:11 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:11 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:11 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:11 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:11 --> Controller Class Initialized
DEBUG - 2023-05-01 18:25:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:25:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:25:11 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:11 --> Total execution time: 0.0281
INFO - 2023-05-01 18:25:13 --> Config Class Initialized
INFO - 2023-05-01 18:25:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:13 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:13 --> URI Class Initialized
INFO - 2023-05-01 18:25:13 --> Router Class Initialized
INFO - 2023-05-01 18:25:13 --> Output Class Initialized
INFO - 2023-05-01 18:25:13 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:13 --> Input Class Initialized
INFO - 2023-05-01 18:25:13 --> Language Class Initialized
INFO - 2023-05-01 18:25:13 --> Language Class Initialized
INFO - 2023-05-01 18:25:13 --> Config Class Initialized
INFO - 2023-05-01 18:25:13 --> Loader Class Initialized
INFO - 2023-05-01 18:25:13 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:13 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:13 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:13 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:13 --> Controller Class Initialized
DEBUG - 2023-05-01 18:25:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-01 18:25:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:25:13 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:13 --> Total execution time: 0.0309
INFO - 2023-05-01 18:25:15 --> Config Class Initialized
INFO - 2023-05-01 18:25:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:15 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:15 --> URI Class Initialized
INFO - 2023-05-01 18:25:15 --> Router Class Initialized
INFO - 2023-05-01 18:25:15 --> Output Class Initialized
INFO - 2023-05-01 18:25:15 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:15 --> Input Class Initialized
INFO - 2023-05-01 18:25:15 --> Language Class Initialized
INFO - 2023-05-01 18:25:15 --> Language Class Initialized
INFO - 2023-05-01 18:25:15 --> Config Class Initialized
INFO - 2023-05-01 18:25:15 --> Loader Class Initialized
INFO - 2023-05-01 18:25:15 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:15 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:15 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:15 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:15 --> Controller Class Initialized
DEBUG - 2023-05-01 18:25:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:25:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:25:15 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:15 --> Total execution time: 0.0448
INFO - 2023-05-01 18:25:17 --> Config Class Initialized
INFO - 2023-05-01 18:25:17 --> Hooks Class Initialized
INFO - 2023-05-01 18:25:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:17 --> Controller Class Initialized
INFO - 2023-05-01 18:25:17 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:17 --> Total execution time: 0.0392
INFO - 2023-05-01 18:25:21 --> Config Class Initialized
INFO - 2023-05-01 18:25:21 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:21 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:21 --> URI Class Initialized
INFO - 2023-05-01 18:25:21 --> Router Class Initialized
INFO - 2023-05-01 18:25:21 --> Output Class Initialized
INFO - 2023-05-01 18:25:21 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:21 --> Input Class Initialized
INFO - 2023-05-01 18:25:21 --> Language Class Initialized
INFO - 2023-05-01 18:25:21 --> Language Class Initialized
INFO - 2023-05-01 18:25:21 --> Config Class Initialized
INFO - 2023-05-01 18:25:21 --> Loader Class Initialized
INFO - 2023-05-01 18:25:21 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:21 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:21 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:21 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:21 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:21 --> Controller Class Initialized
ERROR - 2023-05-01 18:25:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance.' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:25:21 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:25:25 --> Config Class Initialized
INFO - 2023-05-01 18:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:25 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:25 --> URI Class Initialized
INFO - 2023-05-01 18:25:25 --> Router Class Initialized
INFO - 2023-05-01 18:25:25 --> Output Class Initialized
INFO - 2023-05-01 18:25:25 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:25 --> Input Class Initialized
INFO - 2023-05-01 18:25:25 --> Language Class Initialized
INFO - 2023-05-01 18:25:25 --> Language Class Initialized
INFO - 2023-05-01 18:25:25 --> Config Class Initialized
INFO - 2023-05-01 18:25:25 --> Loader Class Initialized
INFO - 2023-05-01 18:25:25 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:25 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:25 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:25 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:25 --> Controller Class Initialized
DEBUG - 2023-05-01 18:25:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:25:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:25:25 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:25 --> Total execution time: 0.0397
INFO - 2023-05-01 18:25:27 --> Config Class Initialized
INFO - 2023-05-01 18:25:27 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:27 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:27 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:27 --> URI Class Initialized
INFO - 2023-05-01 18:25:27 --> Router Class Initialized
INFO - 2023-05-01 18:25:27 --> Output Class Initialized
INFO - 2023-05-01 18:25:27 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:27 --> Input Class Initialized
INFO - 2023-05-01 18:25:27 --> Language Class Initialized
INFO - 2023-05-01 18:25:27 --> Language Class Initialized
INFO - 2023-05-01 18:25:27 --> Config Class Initialized
INFO - 2023-05-01 18:25:27 --> Loader Class Initialized
INFO - 2023-05-01 18:25:27 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:27 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:27 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:27 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:27 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:27 --> Controller Class Initialized
INFO - 2023-05-01 18:25:27 --> Final output sent to browser
DEBUG - 2023-05-01 18:25:27 --> Total execution time: 0.0240
INFO - 2023-05-01 18:25:33 --> Config Class Initialized
INFO - 2023-05-01 18:25:33 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:33 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:33 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:33 --> URI Class Initialized
INFO - 2023-05-01 18:25:33 --> Router Class Initialized
INFO - 2023-05-01 18:25:33 --> Output Class Initialized
INFO - 2023-05-01 18:25:33 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:33 --> Input Class Initialized
INFO - 2023-05-01 18:25:33 --> Language Class Initialized
ERROR - 2023-05-01 18:25:33 --> 404 Page Not Found: /index
INFO - 2023-05-01 18:25:37 --> Config Class Initialized
INFO - 2023-05-01 18:25:37 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:25:37 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:25:37 --> Utf8 Class Initialized
INFO - 2023-05-01 18:25:37 --> URI Class Initialized
INFO - 2023-05-01 18:25:37 --> Router Class Initialized
INFO - 2023-05-01 18:25:37 --> Output Class Initialized
INFO - 2023-05-01 18:25:37 --> Security Class Initialized
DEBUG - 2023-05-01 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:25:37 --> Input Class Initialized
INFO - 2023-05-01 18:25:37 --> Language Class Initialized
INFO - 2023-05-01 18:25:37 --> Language Class Initialized
INFO - 2023-05-01 18:25:37 --> Config Class Initialized
INFO - 2023-05-01 18:25:37 --> Loader Class Initialized
INFO - 2023-05-01 18:25:37 --> Helper loaded: url_helper
INFO - 2023-05-01 18:25:37 --> Helper loaded: file_helper
INFO - 2023-05-01 18:25:37 --> Helper loaded: form_helper
INFO - 2023-05-01 18:25:37 --> Helper loaded: my_helper
INFO - 2023-05-01 18:25:37 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:25:37 --> Controller Class Initialized
ERROR - 2023-05-01 18:25:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance.' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:25:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:26:14 --> Config Class Initialized
INFO - 2023-05-01 18:26:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:26:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:26:14 --> Utf8 Class Initialized
INFO - 2023-05-01 18:26:14 --> URI Class Initialized
INFO - 2023-05-01 18:26:14 --> Router Class Initialized
INFO - 2023-05-01 18:26:14 --> Output Class Initialized
INFO - 2023-05-01 18:26:14 --> Security Class Initialized
DEBUG - 2023-05-01 18:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:26:14 --> Input Class Initialized
INFO - 2023-05-01 18:26:14 --> Language Class Initialized
INFO - 2023-05-01 18:26:14 --> Language Class Initialized
INFO - 2023-05-01 18:26:14 --> Config Class Initialized
INFO - 2023-05-01 18:26:14 --> Loader Class Initialized
INFO - 2023-05-01 18:26:14 --> Helper loaded: url_helper
INFO - 2023-05-01 18:26:14 --> Helper loaded: file_helper
INFO - 2023-05-01 18:26:14 --> Helper loaded: form_helper
INFO - 2023-05-01 18:26:14 --> Helper loaded: my_helper
INFO - 2023-05-01 18:26:14 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:26:14 --> Controller Class Initialized
DEBUG - 2023-05-01 18:26:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:26:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:26:14 --> Final output sent to browser
DEBUG - 2023-05-01 18:26:14 --> Total execution time: 0.0569
INFO - 2023-05-01 18:26:14 --> Config Class Initialized
INFO - 2023-05-01 18:26:14 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:26:14 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:26:14 --> Utf8 Class Initialized
INFO - 2023-05-01 18:26:14 --> URI Class Initialized
INFO - 2023-05-01 18:26:14 --> Router Class Initialized
INFO - 2023-05-01 18:26:14 --> Output Class Initialized
INFO - 2023-05-01 18:26:14 --> Security Class Initialized
DEBUG - 2023-05-01 18:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:26:14 --> Input Class Initialized
INFO - 2023-05-01 18:26:14 --> Language Class Initialized
ERROR - 2023-05-01 18:26:14 --> 404 Page Not Found: /index
INFO - 2023-05-01 18:26:15 --> Config Class Initialized
INFO - 2023-05-01 18:26:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:26:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:26:15 --> Utf8 Class Initialized
INFO - 2023-05-01 18:26:15 --> URI Class Initialized
INFO - 2023-05-01 18:26:15 --> Router Class Initialized
INFO - 2023-05-01 18:26:15 --> Output Class Initialized
INFO - 2023-05-01 18:26:15 --> Security Class Initialized
DEBUG - 2023-05-01 18:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:26:15 --> Input Class Initialized
INFO - 2023-05-01 18:26:15 --> Language Class Initialized
INFO - 2023-05-01 18:26:15 --> Language Class Initialized
INFO - 2023-05-01 18:26:15 --> Config Class Initialized
INFO - 2023-05-01 18:26:15 --> Loader Class Initialized
INFO - 2023-05-01 18:26:15 --> Helper loaded: url_helper
INFO - 2023-05-01 18:26:15 --> Helper loaded: file_helper
INFO - 2023-05-01 18:26:15 --> Helper loaded: form_helper
INFO - 2023-05-01 18:26:15 --> Helper loaded: my_helper
INFO - 2023-05-01 18:26:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:26:15 --> Controller Class Initialized
INFO - 2023-05-01 18:27:02 --> Config Class Initialized
INFO - 2023-05-01 18:27:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:02 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:02 --> URI Class Initialized
INFO - 2023-05-01 18:27:02 --> Router Class Initialized
INFO - 2023-05-01 18:27:02 --> Output Class Initialized
INFO - 2023-05-01 18:27:02 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:02 --> Input Class Initialized
INFO - 2023-05-01 18:27:02 --> Language Class Initialized
INFO - 2023-05-01 18:27:02 --> Language Class Initialized
INFO - 2023-05-01 18:27:02 --> Config Class Initialized
INFO - 2023-05-01 18:27:02 --> Loader Class Initialized
INFO - 2023-05-01 18:27:02 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:02 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:02 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:02 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:02 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:02 --> Controller Class Initialized
DEBUG - 2023-05-01 18:27:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/form.php
DEBUG - 2023-05-01 18:27:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:27:02 --> Final output sent to browser
DEBUG - 2023-05-01 18:27:02 --> Total execution time: 0.0316
INFO - 2023-05-01 18:27:06 --> Config Class Initialized
INFO - 2023-05-01 18:27:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:06 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:06 --> URI Class Initialized
INFO - 2023-05-01 18:27:06 --> Router Class Initialized
INFO - 2023-05-01 18:27:06 --> Output Class Initialized
INFO - 2023-05-01 18:27:06 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:06 --> Input Class Initialized
INFO - 2023-05-01 18:27:06 --> Language Class Initialized
INFO - 2023-05-01 18:27:06 --> Language Class Initialized
INFO - 2023-05-01 18:27:06 --> Config Class Initialized
INFO - 2023-05-01 18:27:06 --> Loader Class Initialized
INFO - 2023-05-01 18:27:06 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:06 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:06 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:06 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:06 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '. She is also able to recite ta'awwuz before reading iqra and recite shodaqal...' at line 1 - Invalid query: REPLACE INTO t_nilai_cat (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '12', '36', '532', 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1 page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah , subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she is able to mention the name of the god of Muslims, namely Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the sequence of wudhu while playing games. She has learned of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman until al-qahhar by singing and started to be able to memorize it until al- qahhar with teacher’s guidance.', 'Salludin Gozali'),('20232', 'c', '12', '36', '532', '-', 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1 page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah , subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she is able to mention the name of the god of Muslims, namely Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the sequence of wudhu while playing games. She has learned of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman until al-qahhar by singing and started to be able to memorize it until al- qahhar with teacher’s guidance.'),('20232', 'c', '12', '36', '531', '-', 'SHIFA MISYA FIANDIA'),('20232', 'c', '12', '36', '531', '-', '-');
INFO - 2023-05-01 18:27:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:23 --> Config Class Initialized
INFO - 2023-05-01 18:27:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:23 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:23 --> URI Class Initialized
INFO - 2023-05-01 18:27:23 --> Router Class Initialized
INFO - 2023-05-01 18:27:23 --> Output Class Initialized
INFO - 2023-05-01 18:27:23 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:23 --> Input Class Initialized
INFO - 2023-05-01 18:27:23 --> Language Class Initialized
INFO - 2023-05-01 18:27:23 --> Language Class Initialized
INFO - 2023-05-01 18:27:23 --> Config Class Initialized
INFO - 2023-05-01 18:27:23 --> Loader Class Initialized
INFO - 2023-05-01 18:27:23 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:23 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:23 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:23 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:23 --> Controller Class Initialized
DEBUG - 2023-05-01 18:27:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/form.php
DEBUG - 2023-05-01 18:27:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:27:23 --> Final output sent to browser
DEBUG - 2023-05-01 18:27:23 --> Total execution time: 0.0440
INFO - 2023-05-01 18:27:24 --> Config Class Initialized
INFO - 2023-05-01 18:27:24 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:24 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:24 --> URI Class Initialized
INFO - 2023-05-01 18:27:24 --> Router Class Initialized
INFO - 2023-05-01 18:27:24 --> Output Class Initialized
INFO - 2023-05-01 18:27:24 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:24 --> Input Class Initialized
INFO - 2023-05-01 18:27:24 --> Language Class Initialized
INFO - 2023-05-01 18:27:24 --> Language Class Initialized
INFO - 2023-05-01 18:27:24 --> Config Class Initialized
INFO - 2023-05-01 18:27:24 --> Loader Class Initialized
INFO - 2023-05-01 18:27:24 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:24 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:24 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:24 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:24 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:24 --> Controller Class Initialized
DEBUG - 2023-05-01 18:27:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:27:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:27:24 --> Final output sent to browser
DEBUG - 2023-05-01 18:27:24 --> Total execution time: 0.0290
INFO - 2023-05-01 18:27:25 --> Config Class Initialized
INFO - 2023-05-01 18:27:25 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:25 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:25 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:25 --> URI Class Initialized
INFO - 2023-05-01 18:27:25 --> Router Class Initialized
INFO - 2023-05-01 18:27:25 --> Output Class Initialized
INFO - 2023-05-01 18:27:25 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:25 --> Input Class Initialized
INFO - 2023-05-01 18:27:25 --> Language Class Initialized
INFO - 2023-05-01 18:27:25 --> Language Class Initialized
INFO - 2023-05-01 18:27:25 --> Config Class Initialized
INFO - 2023-05-01 18:27:25 --> Loader Class Initialized
INFO - 2023-05-01 18:27:25 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:25 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:25 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:25 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:25 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:25 --> Controller Class Initialized
INFO - 2023-05-01 18:27:25 --> Final output sent to browser
DEBUG - 2023-05-01 18:27:25 --> Total execution time: 0.0259
INFO - 2023-05-01 18:27:42 --> Config Class Initialized
INFO - 2023-05-01 18:27:42 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:42 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:42 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:42 --> URI Class Initialized
INFO - 2023-05-01 18:27:42 --> Router Class Initialized
INFO - 2023-05-01 18:27:42 --> Output Class Initialized
INFO - 2023-05-01 18:27:42 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:42 --> Input Class Initialized
INFO - 2023-05-01 18:27:42 --> Language Class Initialized
INFO - 2023-05-01 18:27:42 --> Language Class Initialized
INFO - 2023-05-01 18:27:42 --> Config Class Initialized
INFO - 2023-05-01 18:27:42 --> Loader Class Initialized
INFO - 2023-05-01 18:27:42 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:42 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:42 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:42 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:42 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:42 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:42 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:43 --> Config Class Initialized
INFO - 2023-05-01 18:27:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:43 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:43 --> URI Class Initialized
INFO - 2023-05-01 18:27:43 --> Router Class Initialized
INFO - 2023-05-01 18:27:43 --> Output Class Initialized
INFO - 2023-05-01 18:27:43 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:43 --> Input Class Initialized
INFO - 2023-05-01 18:27:43 --> Language Class Initialized
INFO - 2023-05-01 18:27:43 --> Language Class Initialized
INFO - 2023-05-01 18:27:43 --> Config Class Initialized
INFO - 2023-05-01 18:27:43 --> Loader Class Initialized
INFO - 2023-05-01 18:27:43 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:43 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:43 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:43 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:43 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:43 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:43 --> Config Class Initialized
INFO - 2023-05-01 18:27:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:43 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:43 --> URI Class Initialized
INFO - 2023-05-01 18:27:43 --> Router Class Initialized
INFO - 2023-05-01 18:27:43 --> Output Class Initialized
INFO - 2023-05-01 18:27:43 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:43 --> Input Class Initialized
INFO - 2023-05-01 18:27:43 --> Language Class Initialized
INFO - 2023-05-01 18:27:43 --> Language Class Initialized
INFO - 2023-05-01 18:27:43 --> Config Class Initialized
INFO - 2023-05-01 18:27:43 --> Loader Class Initialized
INFO - 2023-05-01 18:27:43 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:43 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:43 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:43 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:43 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:43 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:44 --> Config Class Initialized
INFO - 2023-05-01 18:27:44 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:44 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:44 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:44 --> URI Class Initialized
INFO - 2023-05-01 18:27:44 --> Router Class Initialized
INFO - 2023-05-01 18:27:44 --> Output Class Initialized
INFO - 2023-05-01 18:27:44 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:44 --> Input Class Initialized
INFO - 2023-05-01 18:27:44 --> Language Class Initialized
INFO - 2023-05-01 18:27:44 --> Language Class Initialized
INFO - 2023-05-01 18:27:44 --> Config Class Initialized
INFO - 2023-05-01 18:27:44 --> Loader Class Initialized
INFO - 2023-05-01 18:27:44 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:44 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:44 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:44 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:44 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:44 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:45 --> Config Class Initialized
INFO - 2023-05-01 18:27:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:45 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:45 --> URI Class Initialized
INFO - 2023-05-01 18:27:45 --> Router Class Initialized
INFO - 2023-05-01 18:27:45 --> Output Class Initialized
INFO - 2023-05-01 18:27:45 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:45 --> Input Class Initialized
INFO - 2023-05-01 18:27:45 --> Language Class Initialized
INFO - 2023-05-01 18:27:45 --> Language Class Initialized
INFO - 2023-05-01 18:27:45 --> Config Class Initialized
INFO - 2023-05-01 18:27:45 --> Loader Class Initialized
INFO - 2023-05-01 18:27:45 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:45 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:45 --> Config Class Initialized
INFO - 2023-05-01 18:27:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:45 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:45 --> URI Class Initialized
INFO - 2023-05-01 18:27:45 --> Router Class Initialized
INFO - 2023-05-01 18:27:45 --> Output Class Initialized
INFO - 2023-05-01 18:27:45 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:45 --> Input Class Initialized
INFO - 2023-05-01 18:27:45 --> Language Class Initialized
INFO - 2023-05-01 18:27:45 --> Language Class Initialized
INFO - 2023-05-01 18:27:45 --> Config Class Initialized
INFO - 2023-05-01 18:27:45 --> Loader Class Initialized
INFO - 2023-05-01 18:27:45 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:45 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:45 --> Config Class Initialized
INFO - 2023-05-01 18:27:45 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:45 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:45 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:45 --> URI Class Initialized
INFO - 2023-05-01 18:27:45 --> Router Class Initialized
INFO - 2023-05-01 18:27:45 --> Output Class Initialized
INFO - 2023-05-01 18:27:45 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:45 --> Input Class Initialized
INFO - 2023-05-01 18:27:45 --> Language Class Initialized
INFO - 2023-05-01 18:27:45 --> Language Class Initialized
INFO - 2023-05-01 18:27:45 --> Config Class Initialized
INFO - 2023-05-01 18:27:45 --> Loader Class Initialized
INFO - 2023-05-01 18:27:45 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:45 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:45 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:45 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:48 --> Config Class Initialized
INFO - 2023-05-01 18:27:48 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:48 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:48 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:48 --> URI Class Initialized
INFO - 2023-05-01 18:27:48 --> Router Class Initialized
INFO - 2023-05-01 18:27:48 --> Output Class Initialized
INFO - 2023-05-01 18:27:48 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:48 --> Input Class Initialized
INFO - 2023-05-01 18:27:48 --> Language Class Initialized
ERROR - 2023-05-01 18:27:48 --> 404 Page Not Found: /index
INFO - 2023-05-01 18:27:53 --> Config Class Initialized
INFO - 2023-05-01 18:27:53 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:53 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:53 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:53 --> URI Class Initialized
INFO - 2023-05-01 18:27:53 --> Router Class Initialized
INFO - 2023-05-01 18:27:53 --> Output Class Initialized
INFO - 2023-05-01 18:27:53 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:53 --> Input Class Initialized
INFO - 2023-05-01 18:27:53 --> Language Class Initialized
INFO - 2023-05-01 18:27:53 --> Language Class Initialized
INFO - 2023-05-01 18:27:53 --> Config Class Initialized
INFO - 2023-05-01 18:27:53 --> Loader Class Initialized
INFO - 2023-05-01 18:27:53 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:53 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:53 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:53 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:53 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:53 --> Controller Class Initialized
ERROR - 2023-05-01 18:27:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesud...' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20232', nilai = '-', nilai_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected. She can recite and memorize several short
surah, hadith and du’a in this first semester. For short surah she is able to recite surah an-Nas until al-Kafirun
Independently. She is able to recite hadith kasih sayang, adab makan, saling memberi hadiah, sholat itu
cahaya. She is able to recite some dua’s such as : Du'a masuk kamar mandi, keluar kamar mandi, sebelum
tidur, sebelum makan, sesudah makan, Du’a for parents, du’a before study and du’a pembuka hati. in the BTQ
session, Akila is in Iqra’ 1 page 10. She is able to pronounce the thayyibah: takbir (Allahuakbar), tahmid
(Alhamdulillah), tasbih (Subhanallah), tahlil (Laa ilaaha illallahu) dan istighfar (Astaghfirullahal ‘adzim). She can
practice Wudu by tepuk wudu and she can follow duha prayer movements until finished and the sequence of
prayer movements such as takbir, ruku, sujud, duduk diantara dua sujud, duduk tahiyat akhir dan salam. She
also knows who our Prophet is (Nabi Muhammad SAW)from the Maulidur Rasul event. On the other hand, Akila
still needs practice to read iqra again. She still needs practice to memorize surah, du’a dan hadist, such as
surah al-Kautsar, al- ma’un, Quraish, du’a bangun tidur, and du’a bercermin, hadist malu sebagian dari iman
dan hadist jangan marah. Akila still needs more practice to listen to the story about Nabi. 
' WHERE id_guru_mapel = '12' AND id_mapel_kd = '36' AND id_siswa = '532' AND jenis = 'c'
INFO - 2023-05-01 18:27:53 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:27:55 --> Config Class Initialized
INFO - 2023-05-01 18:27:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:55 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:55 --> URI Class Initialized
INFO - 2023-05-01 18:27:55 --> Router Class Initialized
INFO - 2023-05-01 18:27:55 --> Output Class Initialized
INFO - 2023-05-01 18:27:55 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:55 --> Input Class Initialized
INFO - 2023-05-01 18:27:55 --> Language Class Initialized
INFO - 2023-05-01 18:27:55 --> Language Class Initialized
INFO - 2023-05-01 18:27:55 --> Config Class Initialized
INFO - 2023-05-01 18:27:55 --> Loader Class Initialized
INFO - 2023-05-01 18:27:55 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:55 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:55 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:55 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:55 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:55 --> Controller Class Initialized
DEBUG - 2023-05-01 18:27:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:27:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:27:55 --> Final output sent to browser
DEBUG - 2023-05-01 18:27:55 --> Total execution time: 0.0402
INFO - 2023-05-01 18:27:55 --> Config Class Initialized
INFO - 2023-05-01 18:27:55 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:55 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:55 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:55 --> URI Class Initialized
INFO - 2023-05-01 18:27:55 --> Router Class Initialized
INFO - 2023-05-01 18:27:55 --> Output Class Initialized
INFO - 2023-05-01 18:27:55 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:55 --> Input Class Initialized
INFO - 2023-05-01 18:27:55 --> Language Class Initialized
ERROR - 2023-05-01 18:27:55 --> 404 Page Not Found: /index
INFO - 2023-05-01 18:27:58 --> Config Class Initialized
INFO - 2023-05-01 18:27:58 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:27:58 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:27:58 --> Utf8 Class Initialized
INFO - 2023-05-01 18:27:58 --> URI Class Initialized
INFO - 2023-05-01 18:27:58 --> Router Class Initialized
INFO - 2023-05-01 18:27:58 --> Output Class Initialized
INFO - 2023-05-01 18:27:58 --> Security Class Initialized
DEBUG - 2023-05-01 18:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:27:58 --> Input Class Initialized
INFO - 2023-05-01 18:27:58 --> Language Class Initialized
INFO - 2023-05-01 18:27:58 --> Language Class Initialized
INFO - 2023-05-01 18:27:58 --> Config Class Initialized
INFO - 2023-05-01 18:27:58 --> Loader Class Initialized
INFO - 2023-05-01 18:27:58 --> Helper loaded: url_helper
INFO - 2023-05-01 18:27:58 --> Helper loaded: file_helper
INFO - 2023-05-01 18:27:58 --> Helper loaded: form_helper
INFO - 2023-05-01 18:27:58 --> Helper loaded: my_helper
INFO - 2023-05-01 18:27:58 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:27:58 --> Controller Class Initialized
INFO - 2023-05-01 18:27:58 --> Final output sent to browser
DEBUG - 2023-05-01 18:27:58 --> Total execution time: 0.0277
INFO - 2023-05-01 18:28:00 --> Config Class Initialized
INFO - 2023-05-01 18:28:00 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:28:00 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:28:00 --> Utf8 Class Initialized
INFO - 2023-05-01 18:28:00 --> URI Class Initialized
INFO - 2023-05-01 18:28:00 --> Router Class Initialized
INFO - 2023-05-01 18:28:00 --> Output Class Initialized
INFO - 2023-05-01 18:28:00 --> Security Class Initialized
DEBUG - 2023-05-01 18:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:28:00 --> Input Class Initialized
INFO - 2023-05-01 18:28:00 --> Language Class Initialized
INFO - 2023-05-01 18:29:05 --> Config Class Initialized
INFO - 2023-05-01 18:29:05 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:29:05 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:29:05 --> Utf8 Class Initialized
INFO - 2023-05-01 18:29:05 --> URI Class Initialized
INFO - 2023-05-01 18:29:05 --> Router Class Initialized
INFO - 2023-05-01 18:29:05 --> Output Class Initialized
INFO - 2023-05-01 18:29:05 --> Security Class Initialized
DEBUG - 2023-05-01 18:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:29:05 --> Input Class Initialized
INFO - 2023-05-01 18:29:05 --> Language Class Initialized
INFO - 2023-05-01 18:29:05 --> Language Class Initialized
INFO - 2023-05-01 18:29:05 --> Config Class Initialized
INFO - 2023-05-01 18:29:05 --> Loader Class Initialized
INFO - 2023-05-01 18:29:05 --> Helper loaded: url_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: file_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: form_helper
INFO - 2023-05-01 18:29:05 --> Helper loaded: my_helper
INFO - 2023-05-01 18:29:05 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:29:05 --> Controller Class Initialized
INFO - 2023-05-01 18:29:05 --> Final output sent to browser
DEBUG - 2023-05-01 18:29:05 --> Total execution time: 0.0512
INFO - 2023-05-01 18:31:43 --> Config Class Initialized
INFO - 2023-05-01 18:31:43 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:31:43 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:31:43 --> Utf8 Class Initialized
INFO - 2023-05-01 18:31:43 --> URI Class Initialized
INFO - 2023-05-01 18:31:43 --> Router Class Initialized
INFO - 2023-05-01 18:31:43 --> Output Class Initialized
INFO - 2023-05-01 18:31:43 --> Security Class Initialized
DEBUG - 2023-05-01 18:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:31:43 --> Input Class Initialized
INFO - 2023-05-01 18:31:43 --> Language Class Initialized
INFO - 2023-05-01 18:31:43 --> Language Class Initialized
INFO - 2023-05-01 18:31:43 --> Config Class Initialized
INFO - 2023-05-01 18:31:43 --> Loader Class Initialized
INFO - 2023-05-01 18:31:43 --> Helper loaded: url_helper
INFO - 2023-05-01 18:31:43 --> Helper loaded: file_helper
INFO - 2023-05-01 18:31:43 --> Helper loaded: form_helper
INFO - 2023-05-01 18:31:43 --> Helper loaded: my_helper
INFO - 2023-05-01 18:31:43 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:31:44 --> Controller Class Initialized
DEBUG - 2023-05-01 18:31:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/form.php
DEBUG - 2023-05-01 18:31:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:31:44 --> Final output sent to browser
DEBUG - 2023-05-01 18:31:44 --> Total execution time: 0.0664
INFO - 2023-05-01 18:31:47 --> Config Class Initialized
INFO - 2023-05-01 18:31:47 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:31:47 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:31:47 --> Utf8 Class Initialized
INFO - 2023-05-01 18:31:47 --> URI Class Initialized
INFO - 2023-05-01 18:31:47 --> Router Class Initialized
INFO - 2023-05-01 18:31:47 --> Output Class Initialized
INFO - 2023-05-01 18:31:47 --> Security Class Initialized
DEBUG - 2023-05-01 18:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:31:47 --> Input Class Initialized
INFO - 2023-05-01 18:31:47 --> Language Class Initialized
INFO - 2023-05-01 18:31:47 --> Language Class Initialized
INFO - 2023-05-01 18:31:47 --> Config Class Initialized
INFO - 2023-05-01 18:31:47 --> Loader Class Initialized
INFO - 2023-05-01 18:31:47 --> Helper loaded: url_helper
INFO - 2023-05-01 18:31:47 --> Helper loaded: file_helper
INFO - 2023-05-01 18:31:47 --> Helper loaded: form_helper
INFO - 2023-05-01 18:31:47 --> Helper loaded: my_helper
INFO - 2023-05-01 18:31:47 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:31:47 --> Controller Class Initialized
ERROR - 2023-05-01 18:31:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '. She is also able to recite ta'awwuz before reading iqra and recite shodaqal...' at line 1 - Invalid query: REPLACE INTO t_nilai_cat (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '12', '36', '532', 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1 page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah , subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she is able to mention the name of the god of Muslims, namely Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the sequence of wudhu while playing games. She has learned of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman until al-qahhar by singing and started to be able to memorize it until al- qahhar with teacher’s guidance.', 'Salludin Gozali'),('20232', 'c', '12', '36', '532', '-', 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1 page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah , subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she is able to mention the name of the god of Muslims, namely Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the sequence of wudhu while playing games. She has learned of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman until al-qahhar by singing and started to be able to memorize it until al- qahhar with teacher’s guidance.'),('20232', 'c', '12', '36', '531', '-', 'SHIFA MISYA FIANDIA'),('20232', 'c', '12', '36', '531', '-', '-');
INFO - 2023-05-01 18:31:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-01 18:33:12 --> Config Class Initialized
INFO - 2023-05-01 18:33:12 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:33:12 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:33:12 --> Utf8 Class Initialized
INFO - 2023-05-01 18:33:12 --> URI Class Initialized
INFO - 2023-05-01 18:33:12 --> Router Class Initialized
INFO - 2023-05-01 18:33:12 --> Output Class Initialized
INFO - 2023-05-01 18:33:12 --> Security Class Initialized
DEBUG - 2023-05-01 18:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:33:12 --> Input Class Initialized
INFO - 2023-05-01 18:33:12 --> Language Class Initialized
INFO - 2023-05-01 18:33:12 --> Language Class Initialized
INFO - 2023-05-01 18:33:12 --> Config Class Initialized
INFO - 2023-05-01 18:33:12 --> Loader Class Initialized
INFO - 2023-05-01 18:33:12 --> Helper loaded: url_helper
INFO - 2023-05-01 18:33:12 --> Helper loaded: file_helper
INFO - 2023-05-01 18:33:12 --> Helper loaded: form_helper
INFO - 2023-05-01 18:33:12 --> Helper loaded: my_helper
INFO - 2023-05-01 18:33:12 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:33:12 --> Controller Class Initialized
DEBUG - 2023-05-01 18:33:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/form.php
DEBUG - 2023-05-01 18:33:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:33:12 --> Final output sent to browser
DEBUG - 2023-05-01 18:33:12 --> Total execution time: 0.0297
INFO - 2023-05-01 18:33:15 --> Config Class Initialized
INFO - 2023-05-01 18:33:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:33:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:33:15 --> Utf8 Class Initialized
INFO - 2023-05-01 18:33:15 --> URI Class Initialized
INFO - 2023-05-01 18:33:15 --> Router Class Initialized
INFO - 2023-05-01 18:33:15 --> Output Class Initialized
INFO - 2023-05-01 18:33:15 --> Security Class Initialized
DEBUG - 2023-05-01 18:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:33:15 --> Input Class Initialized
INFO - 2023-05-01 18:33:15 --> Language Class Initialized
INFO - 2023-05-01 18:33:15 --> Language Class Initialized
INFO - 2023-05-01 18:33:15 --> Config Class Initialized
INFO - 2023-05-01 18:33:15 --> Loader Class Initialized
INFO - 2023-05-01 18:33:15 --> Helper loaded: url_helper
INFO - 2023-05-01 18:33:15 --> Helper loaded: file_helper
INFO - 2023-05-01 18:33:15 --> Helper loaded: form_helper
INFO - 2023-05-01 18:33:15 --> Helper loaded: my_helper
INFO - 2023-05-01 18:33:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:33:15 --> Controller Class Initialized
INFO - 2023-05-01 18:33:15 --> Config Class Initialized
INFO - 2023-05-01 18:33:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:33:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:33:15 --> Utf8 Class Initialized
INFO - 2023-05-01 18:33:15 --> URI Class Initialized
INFO - 2023-05-01 18:33:15 --> Router Class Initialized
INFO - 2023-05-01 18:33:15 --> Output Class Initialized
INFO - 2023-05-01 18:33:15 --> Security Class Initialized
DEBUG - 2023-05-01 18:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:33:15 --> Input Class Initialized
INFO - 2023-05-01 18:33:15 --> Language Class Initialized
INFO - 2023-05-01 18:33:15 --> Language Class Initialized
INFO - 2023-05-01 18:33:15 --> Config Class Initialized
INFO - 2023-05-01 18:33:15 --> Loader Class Initialized
INFO - 2023-05-01 18:33:15 --> Helper loaded: url_helper
INFO - 2023-05-01 18:33:15 --> Helper loaded: file_helper
INFO - 2023-05-01 18:33:15 --> Helper loaded: form_helper
INFO - 2023-05-01 18:33:15 --> Helper loaded: my_helper
INFO - 2023-05-01 18:33:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:33:16 --> Controller Class Initialized
DEBUG - 2023-05-01 18:33:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:33:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:33:16 --> Final output sent to browser
DEBUG - 2023-05-01 18:33:16 --> Total execution time: 0.0495
INFO - 2023-05-01 18:33:17 --> Config Class Initialized
INFO - 2023-05-01 18:33:17 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:33:17 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:33:17 --> Utf8 Class Initialized
INFO - 2023-05-01 18:33:17 --> URI Class Initialized
INFO - 2023-05-01 18:33:17 --> Router Class Initialized
INFO - 2023-05-01 18:33:17 --> Output Class Initialized
INFO - 2023-05-01 18:33:17 --> Security Class Initialized
DEBUG - 2023-05-01 18:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:33:17 --> Input Class Initialized
INFO - 2023-05-01 18:33:17 --> Language Class Initialized
INFO - 2023-05-01 18:33:17 --> Language Class Initialized
INFO - 2023-05-01 18:33:17 --> Config Class Initialized
INFO - 2023-05-01 18:33:17 --> Loader Class Initialized
INFO - 2023-05-01 18:33:17 --> Helper loaded: url_helper
INFO - 2023-05-01 18:33:17 --> Helper loaded: file_helper
INFO - 2023-05-01 18:33:17 --> Helper loaded: form_helper
INFO - 2023-05-01 18:33:17 --> Helper loaded: my_helper
INFO - 2023-05-01 18:33:17 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:33:17 --> Controller Class Initialized
INFO - 2023-05-01 18:33:17 --> Final output sent to browser
DEBUG - 2023-05-01 18:33:17 --> Total execution time: 0.0422
INFO - 2023-05-01 18:38:35 --> Config Class Initialized
INFO - 2023-05-01 18:38:35 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:38:35 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:38:35 --> Utf8 Class Initialized
INFO - 2023-05-01 18:38:35 --> URI Class Initialized
INFO - 2023-05-01 18:38:35 --> Router Class Initialized
INFO - 2023-05-01 18:38:35 --> Output Class Initialized
INFO - 2023-05-01 18:38:35 --> Security Class Initialized
DEBUG - 2023-05-01 18:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:38:35 --> Input Class Initialized
INFO - 2023-05-01 18:38:35 --> Language Class Initialized
INFO - 2023-05-01 18:38:35 --> Language Class Initialized
INFO - 2023-05-01 18:38:35 --> Config Class Initialized
INFO - 2023-05-01 18:38:35 --> Loader Class Initialized
INFO - 2023-05-01 18:38:35 --> Helper loaded: url_helper
INFO - 2023-05-01 18:38:35 --> Helper loaded: file_helper
INFO - 2023-05-01 18:38:35 --> Helper loaded: form_helper
INFO - 2023-05-01 18:38:35 --> Helper loaded: my_helper
INFO - 2023-05-01 18:38:35 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:38:35 --> Controller Class Initialized
DEBUG - 2023-05-01 18:38:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/form.php
DEBUG - 2023-05-01 18:38:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:38:35 --> Final output sent to browser
DEBUG - 2023-05-01 18:38:35 --> Total execution time: 0.0662
INFO - 2023-05-01 18:38:38 --> Config Class Initialized
INFO - 2023-05-01 18:38:38 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:38:38 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:38:38 --> Utf8 Class Initialized
INFO - 2023-05-01 18:38:38 --> URI Class Initialized
INFO - 2023-05-01 18:38:38 --> Router Class Initialized
INFO - 2023-05-01 18:38:38 --> Output Class Initialized
INFO - 2023-05-01 18:38:38 --> Security Class Initialized
DEBUG - 2023-05-01 18:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:38:38 --> Input Class Initialized
INFO - 2023-05-01 18:38:38 --> Language Class Initialized
INFO - 2023-05-01 18:38:38 --> Language Class Initialized
INFO - 2023-05-01 18:38:38 --> Config Class Initialized
INFO - 2023-05-01 18:38:38 --> Loader Class Initialized
INFO - 2023-05-01 18:38:38 --> Helper loaded: url_helper
INFO - 2023-05-01 18:38:38 --> Helper loaded: file_helper
INFO - 2023-05-01 18:38:38 --> Helper loaded: form_helper
INFO - 2023-05-01 18:38:38 --> Helper loaded: my_helper
INFO - 2023-05-01 18:38:38 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:38:38 --> Controller Class Initialized
INFO - 2023-05-01 18:38:39 --> Config Class Initialized
INFO - 2023-05-01 18:38:39 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:38:39 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:38:39 --> Utf8 Class Initialized
INFO - 2023-05-01 18:38:39 --> URI Class Initialized
INFO - 2023-05-01 18:38:39 --> Router Class Initialized
INFO - 2023-05-01 18:38:39 --> Output Class Initialized
INFO - 2023-05-01 18:38:39 --> Security Class Initialized
DEBUG - 2023-05-01 18:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:38:39 --> Input Class Initialized
INFO - 2023-05-01 18:38:39 --> Language Class Initialized
INFO - 2023-05-01 18:38:39 --> Language Class Initialized
INFO - 2023-05-01 18:38:39 --> Config Class Initialized
INFO - 2023-05-01 18:38:39 --> Loader Class Initialized
INFO - 2023-05-01 18:38:39 --> Helper loaded: url_helper
INFO - 2023-05-01 18:38:39 --> Helper loaded: file_helper
INFO - 2023-05-01 18:38:39 --> Helper loaded: form_helper
INFO - 2023-05-01 18:38:39 --> Helper loaded: my_helper
INFO - 2023-05-01 18:38:39 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:38:39 --> Controller Class Initialized
DEBUG - 2023-05-01 18:38:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-01 18:38:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:38:39 --> Final output sent to browser
DEBUG - 2023-05-01 18:38:39 --> Total execution time: 0.0349
INFO - 2023-05-01 18:38:40 --> Config Class Initialized
INFO - 2023-05-01 18:38:40 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:38:40 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:38:40 --> Utf8 Class Initialized
INFO - 2023-05-01 18:38:40 --> URI Class Initialized
INFO - 2023-05-01 18:38:40 --> Router Class Initialized
INFO - 2023-05-01 18:38:40 --> Output Class Initialized
INFO - 2023-05-01 18:38:40 --> Security Class Initialized
DEBUG - 2023-05-01 18:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:38:40 --> Input Class Initialized
INFO - 2023-05-01 18:38:40 --> Language Class Initialized
INFO - 2023-05-01 18:38:40 --> Language Class Initialized
INFO - 2023-05-01 18:38:40 --> Config Class Initialized
INFO - 2023-05-01 18:38:40 --> Loader Class Initialized
INFO - 2023-05-01 18:38:40 --> Helper loaded: url_helper
INFO - 2023-05-01 18:38:40 --> Helper loaded: file_helper
INFO - 2023-05-01 18:38:40 --> Helper loaded: form_helper
INFO - 2023-05-01 18:38:40 --> Helper loaded: my_helper
INFO - 2023-05-01 18:38:40 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:38:40 --> Controller Class Initialized
INFO - 2023-05-01 18:38:40 --> Final output sent to browser
DEBUG - 2023-05-01 18:38:40 --> Total execution time: 0.0527
INFO - 2023-05-01 18:46:03 --> Config Class Initialized
INFO - 2023-05-01 18:46:03 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:46:03 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:46:03 --> Utf8 Class Initialized
INFO - 2023-05-01 18:46:03 --> URI Class Initialized
DEBUG - 2023-05-01 18:46:03 --> No URI present. Default controller set.
INFO - 2023-05-01 18:46:03 --> Router Class Initialized
INFO - 2023-05-01 18:46:03 --> Output Class Initialized
INFO - 2023-05-01 18:46:03 --> Security Class Initialized
DEBUG - 2023-05-01 18:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:46:03 --> Input Class Initialized
INFO - 2023-05-01 18:46:03 --> Language Class Initialized
INFO - 2023-05-01 18:46:03 --> Language Class Initialized
INFO - 2023-05-01 18:46:03 --> Config Class Initialized
INFO - 2023-05-01 18:46:03 --> Loader Class Initialized
INFO - 2023-05-01 18:46:03 --> Helper loaded: url_helper
INFO - 2023-05-01 18:46:03 --> Helper loaded: file_helper
INFO - 2023-05-01 18:46:03 --> Helper loaded: form_helper
INFO - 2023-05-01 18:46:03 --> Helper loaded: my_helper
INFO - 2023-05-01 18:46:03 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:46:03 --> Controller Class Initialized
DEBUG - 2023-05-01 18:46:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:46:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:46:03 --> Final output sent to browser
DEBUG - 2023-05-01 18:46:03 --> Total execution time: 0.0410
INFO - 2023-05-01 18:46:04 --> Config Class Initialized
INFO - 2023-05-01 18:46:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:46:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:46:04 --> Utf8 Class Initialized
INFO - 2023-05-01 18:46:04 --> URI Class Initialized
INFO - 2023-05-01 18:46:04 --> Router Class Initialized
INFO - 2023-05-01 18:46:04 --> Output Class Initialized
INFO - 2023-05-01 18:46:04 --> Security Class Initialized
DEBUG - 2023-05-01 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:46:04 --> Input Class Initialized
INFO - 2023-05-01 18:46:04 --> Language Class Initialized
INFO - 2023-05-01 18:46:04 --> Language Class Initialized
INFO - 2023-05-01 18:46:04 --> Config Class Initialized
INFO - 2023-05-01 18:46:04 --> Loader Class Initialized
INFO - 2023-05-01 18:46:04 --> Helper loaded: url_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: file_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: form_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: my_helper
INFO - 2023-05-01 18:46:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:46:04 --> Controller Class Initialized
INFO - 2023-05-01 18:46:04 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:46:04 --> Config Class Initialized
INFO - 2023-05-01 18:46:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:46:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:46:04 --> Utf8 Class Initialized
INFO - 2023-05-01 18:46:04 --> URI Class Initialized
INFO - 2023-05-01 18:46:04 --> Router Class Initialized
INFO - 2023-05-01 18:46:04 --> Output Class Initialized
INFO - 2023-05-01 18:46:04 --> Security Class Initialized
DEBUG - 2023-05-01 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:46:04 --> Input Class Initialized
INFO - 2023-05-01 18:46:04 --> Language Class Initialized
INFO - 2023-05-01 18:46:04 --> Language Class Initialized
INFO - 2023-05-01 18:46:04 --> Config Class Initialized
INFO - 2023-05-01 18:46:04 --> Loader Class Initialized
INFO - 2023-05-01 18:46:04 --> Helper loaded: url_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: file_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: form_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: my_helper
INFO - 2023-05-01 18:46:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:46:04 --> Controller Class Initialized
INFO - 2023-05-01 18:46:04 --> Config Class Initialized
INFO - 2023-05-01 18:46:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:46:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:46:04 --> Utf8 Class Initialized
INFO - 2023-05-01 18:46:04 --> URI Class Initialized
INFO - 2023-05-01 18:46:04 --> Router Class Initialized
INFO - 2023-05-01 18:46:04 --> Output Class Initialized
INFO - 2023-05-01 18:46:04 --> Security Class Initialized
DEBUG - 2023-05-01 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:46:04 --> Input Class Initialized
INFO - 2023-05-01 18:46:04 --> Language Class Initialized
INFO - 2023-05-01 18:46:04 --> Language Class Initialized
INFO - 2023-05-01 18:46:04 --> Config Class Initialized
INFO - 2023-05-01 18:46:04 --> Loader Class Initialized
INFO - 2023-05-01 18:46:04 --> Helper loaded: url_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: file_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: form_helper
INFO - 2023-05-01 18:46:04 --> Helper loaded: my_helper
INFO - 2023-05-01 18:46:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:46:04 --> Controller Class Initialized
DEBUG - 2023-05-01 18:46:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-01 18:46:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:46:04 --> Final output sent to browser
DEBUG - 2023-05-01 18:46:04 --> Total execution time: 0.0371
INFO - 2023-05-01 18:46:59 --> Config Class Initialized
INFO - 2023-05-01 18:46:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:46:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:46:59 --> Utf8 Class Initialized
INFO - 2023-05-01 18:46:59 --> URI Class Initialized
INFO - 2023-05-01 18:46:59 --> Router Class Initialized
INFO - 2023-05-01 18:46:59 --> Output Class Initialized
INFO - 2023-05-01 18:46:59 --> Security Class Initialized
DEBUG - 2023-05-01 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:46:59 --> Input Class Initialized
INFO - 2023-05-01 18:46:59 --> Language Class Initialized
INFO - 2023-05-01 18:46:59 --> Language Class Initialized
INFO - 2023-05-01 18:46:59 --> Config Class Initialized
INFO - 2023-05-01 18:46:59 --> Loader Class Initialized
INFO - 2023-05-01 18:46:59 --> Helper loaded: url_helper
INFO - 2023-05-01 18:46:59 --> Helper loaded: file_helper
INFO - 2023-05-01 18:46:59 --> Helper loaded: form_helper
INFO - 2023-05-01 18:46:59 --> Helper loaded: my_helper
INFO - 2023-05-01 18:46:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:46:59 --> Controller Class Initialized
INFO - 2023-05-01 18:46:59 --> Helper loaded: cookie_helper
INFO - 2023-05-01 18:46:59 --> Final output sent to browser
DEBUG - 2023-05-01 18:46:59 --> Total execution time: 0.0474
INFO - 2023-05-01 18:46:59 --> Config Class Initialized
INFO - 2023-05-01 18:46:59 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:46:59 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:46:59 --> Utf8 Class Initialized
INFO - 2023-05-01 18:46:59 --> URI Class Initialized
INFO - 2023-05-01 18:46:59 --> Router Class Initialized
INFO - 2023-05-01 18:46:59 --> Output Class Initialized
INFO - 2023-05-01 18:46:59 --> Security Class Initialized
DEBUG - 2023-05-01 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:46:59 --> Input Class Initialized
INFO - 2023-05-01 18:46:59 --> Language Class Initialized
INFO - 2023-05-01 18:46:59 --> Language Class Initialized
INFO - 2023-05-01 18:46:59 --> Config Class Initialized
INFO - 2023-05-01 18:46:59 --> Loader Class Initialized
INFO - 2023-05-01 18:46:59 --> Helper loaded: url_helper
INFO - 2023-05-01 18:46:59 --> Helper loaded: file_helper
INFO - 2023-05-01 18:46:59 --> Helper loaded: form_helper
INFO - 2023-05-01 18:46:59 --> Helper loaded: my_helper
INFO - 2023-05-01 18:46:59 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:46:59 --> Controller Class Initialized
DEBUG - 2023-05-01 18:46:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:46:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:46:59 --> Final output sent to browser
DEBUG - 2023-05-01 18:46:59 --> Total execution time: 0.0413
INFO - 2023-05-01 18:49:23 --> Config Class Initialized
INFO - 2023-05-01 18:49:23 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:49:23 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:49:23 --> Utf8 Class Initialized
INFO - 2023-05-01 18:49:23 --> URI Class Initialized
INFO - 2023-05-01 18:49:23 --> Router Class Initialized
INFO - 2023-05-01 18:49:23 --> Output Class Initialized
INFO - 2023-05-01 18:49:23 --> Security Class Initialized
DEBUG - 2023-05-01 18:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:49:23 --> Input Class Initialized
INFO - 2023-05-01 18:49:23 --> Language Class Initialized
INFO - 2023-05-01 18:49:23 --> Language Class Initialized
INFO - 2023-05-01 18:49:23 --> Config Class Initialized
INFO - 2023-05-01 18:49:23 --> Loader Class Initialized
INFO - 2023-05-01 18:49:23 --> Helper loaded: url_helper
INFO - 2023-05-01 18:49:23 --> Helper loaded: file_helper
INFO - 2023-05-01 18:49:23 --> Helper loaded: form_helper
INFO - 2023-05-01 18:49:23 --> Helper loaded: my_helper
INFO - 2023-05-01 18:49:23 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:49:23 --> Controller Class Initialized
DEBUG - 2023-05-01 18:49:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:49:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:49:23 --> Final output sent to browser
DEBUG - 2023-05-01 18:49:23 --> Total execution time: 0.0802
INFO - 2023-05-01 18:49:52 --> Config Class Initialized
INFO - 2023-05-01 18:49:52 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:49:52 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:49:52 --> Utf8 Class Initialized
INFO - 2023-05-01 18:49:52 --> URI Class Initialized
INFO - 2023-05-01 18:49:52 --> Router Class Initialized
INFO - 2023-05-01 18:49:52 --> Output Class Initialized
INFO - 2023-05-01 18:49:52 --> Security Class Initialized
DEBUG - 2023-05-01 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:49:52 --> Input Class Initialized
INFO - 2023-05-01 18:49:52 --> Language Class Initialized
INFO - 2023-05-01 18:49:52 --> Language Class Initialized
INFO - 2023-05-01 18:49:52 --> Config Class Initialized
INFO - 2023-05-01 18:49:52 --> Loader Class Initialized
INFO - 2023-05-01 18:49:52 --> Helper loaded: url_helper
INFO - 2023-05-01 18:49:52 --> Helper loaded: file_helper
INFO - 2023-05-01 18:49:52 --> Helper loaded: form_helper
INFO - 2023-05-01 18:49:52 --> Helper loaded: my_helper
INFO - 2023-05-01 18:49:52 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:49:52 --> Controller Class Initialized
DEBUG - 2023-05-01 18:49:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:49:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:49:52 --> Final output sent to browser
DEBUG - 2023-05-01 18:49:52 --> Total execution time: 0.0465
INFO - 2023-05-01 18:50:04 --> Config Class Initialized
INFO - 2023-05-01 18:50:04 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:50:04 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:50:04 --> Utf8 Class Initialized
INFO - 2023-05-01 18:50:04 --> URI Class Initialized
INFO - 2023-05-01 18:50:04 --> Router Class Initialized
INFO - 2023-05-01 18:50:04 --> Output Class Initialized
INFO - 2023-05-01 18:50:04 --> Security Class Initialized
DEBUG - 2023-05-01 18:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:50:04 --> Input Class Initialized
INFO - 2023-05-01 18:50:04 --> Language Class Initialized
INFO - 2023-05-01 18:50:04 --> Language Class Initialized
INFO - 2023-05-01 18:50:04 --> Config Class Initialized
INFO - 2023-05-01 18:50:04 --> Loader Class Initialized
INFO - 2023-05-01 18:50:04 --> Helper loaded: url_helper
INFO - 2023-05-01 18:50:04 --> Helper loaded: file_helper
INFO - 2023-05-01 18:50:04 --> Helper loaded: form_helper
INFO - 2023-05-01 18:50:04 --> Helper loaded: my_helper
INFO - 2023-05-01 18:50:04 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:50:04 --> Controller Class Initialized
DEBUG - 2023-05-01 18:50:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-01 18:50:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:50:04 --> Final output sent to browser
DEBUG - 2023-05-01 18:50:04 --> Total execution time: 0.0438
INFO - 2023-05-01 18:50:10 --> Config Class Initialized
INFO - 2023-05-01 18:50:10 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:50:10 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:50:10 --> Utf8 Class Initialized
INFO - 2023-05-01 18:50:10 --> URI Class Initialized
INFO - 2023-05-01 18:50:10 --> Router Class Initialized
INFO - 2023-05-01 18:50:10 --> Output Class Initialized
INFO - 2023-05-01 18:50:10 --> Security Class Initialized
DEBUG - 2023-05-01 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:50:10 --> Input Class Initialized
INFO - 2023-05-01 18:50:10 --> Language Class Initialized
INFO - 2023-05-01 18:50:10 --> Language Class Initialized
INFO - 2023-05-01 18:50:10 --> Config Class Initialized
INFO - 2023-05-01 18:50:10 --> Loader Class Initialized
INFO - 2023-05-01 18:50:10 --> Helper loaded: url_helper
INFO - 2023-05-01 18:50:10 --> Helper loaded: file_helper
INFO - 2023-05-01 18:50:10 --> Helper loaded: form_helper
INFO - 2023-05-01 18:50:10 --> Helper loaded: my_helper
INFO - 2023-05-01 18:50:10 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:50:10 --> Controller Class Initialized
DEBUG - 2023-05-01 18:50:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-05-01 18:50:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:50:10 --> Final output sent to browser
DEBUG - 2023-05-01 18:50:10 --> Total execution time: 0.0505
INFO - 2023-05-01 18:50:15 --> Config Class Initialized
INFO - 2023-05-01 18:50:15 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:50:15 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:50:15 --> Utf8 Class Initialized
INFO - 2023-05-01 18:50:15 --> URI Class Initialized
INFO - 2023-05-01 18:50:15 --> Router Class Initialized
INFO - 2023-05-01 18:50:15 --> Output Class Initialized
INFO - 2023-05-01 18:50:15 --> Security Class Initialized
DEBUG - 2023-05-01 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:50:15 --> Input Class Initialized
INFO - 2023-05-01 18:50:15 --> Language Class Initialized
INFO - 2023-05-01 18:50:15 --> Language Class Initialized
INFO - 2023-05-01 18:50:15 --> Config Class Initialized
INFO - 2023-05-01 18:50:15 --> Loader Class Initialized
INFO - 2023-05-01 18:50:15 --> Helper loaded: url_helper
INFO - 2023-05-01 18:50:15 --> Helper loaded: file_helper
INFO - 2023-05-01 18:50:15 --> Helper loaded: form_helper
INFO - 2023-05-01 18:50:15 --> Helper loaded: my_helper
INFO - 2023-05-01 18:50:15 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:50:15 --> Controller Class Initialized
DEBUG - 2023-05-01 18:50:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-05-01 18:50:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:50:15 --> Final output sent to browser
DEBUG - 2023-05-01 18:50:15 --> Total execution time: 0.0288
INFO - 2023-05-01 18:51:02 --> Config Class Initialized
INFO - 2023-05-01 18:51:02 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:51:02 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:51:02 --> Utf8 Class Initialized
INFO - 2023-05-01 18:51:02 --> URI Class Initialized
INFO - 2023-05-01 18:51:02 --> Router Class Initialized
INFO - 2023-05-01 18:51:02 --> Output Class Initialized
INFO - 2023-05-01 18:51:02 --> Security Class Initialized
DEBUG - 2023-05-01 18:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:51:02 --> Input Class Initialized
INFO - 2023-05-01 18:51:02 --> Language Class Initialized
INFO - 2023-05-01 18:51:02 --> Language Class Initialized
INFO - 2023-05-01 18:51:02 --> Config Class Initialized
INFO - 2023-05-01 18:51:02 --> Loader Class Initialized
INFO - 2023-05-01 18:51:02 --> Helper loaded: url_helper
INFO - 2023-05-01 18:51:02 --> Helper loaded: file_helper
INFO - 2023-05-01 18:51:02 --> Helper loaded: form_helper
INFO - 2023-05-01 18:51:02 --> Helper loaded: my_helper
INFO - 2023-05-01 18:51:02 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:51:02 --> Controller Class Initialized
DEBUG - 2023-05-01 18:51:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-05-01 18:51:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:51:02 --> Final output sent to browser
DEBUG - 2023-05-01 18:51:02 --> Total execution time: 0.0329
INFO - 2023-05-01 18:51:06 --> Config Class Initialized
INFO - 2023-05-01 18:51:06 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:51:06 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:51:06 --> Utf8 Class Initialized
INFO - 2023-05-01 18:51:06 --> URI Class Initialized
INFO - 2023-05-01 18:51:06 --> Router Class Initialized
INFO - 2023-05-01 18:51:06 --> Output Class Initialized
INFO - 2023-05-01 18:51:06 --> Security Class Initialized
DEBUG - 2023-05-01 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:51:06 --> Input Class Initialized
INFO - 2023-05-01 18:51:06 --> Language Class Initialized
INFO - 2023-05-01 18:51:06 --> Language Class Initialized
INFO - 2023-05-01 18:51:06 --> Config Class Initialized
INFO - 2023-05-01 18:51:06 --> Loader Class Initialized
INFO - 2023-05-01 18:51:06 --> Helper loaded: url_helper
INFO - 2023-05-01 18:51:06 --> Helper loaded: file_helper
INFO - 2023-05-01 18:51:06 --> Helper loaded: form_helper
INFO - 2023-05-01 18:51:06 --> Helper loaded: my_helper
INFO - 2023-05-01 18:51:06 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:51:06 --> Controller Class Initialized
DEBUG - 2023-05-01 18:51:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-05-01 18:51:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:51:06 --> Final output sent to browser
DEBUG - 2023-05-01 18:51:06 --> Total execution time: 0.0299
INFO - 2023-05-01 18:51:09 --> Config Class Initialized
INFO - 2023-05-01 18:51:09 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:51:09 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:51:09 --> Utf8 Class Initialized
INFO - 2023-05-01 18:51:09 --> URI Class Initialized
INFO - 2023-05-01 18:51:09 --> Router Class Initialized
INFO - 2023-05-01 18:51:09 --> Output Class Initialized
INFO - 2023-05-01 18:51:09 --> Security Class Initialized
DEBUG - 2023-05-01 18:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:51:09 --> Input Class Initialized
INFO - 2023-05-01 18:51:09 --> Language Class Initialized
INFO - 2023-05-01 18:51:09 --> Language Class Initialized
INFO - 2023-05-01 18:51:09 --> Config Class Initialized
INFO - 2023-05-01 18:51:09 --> Loader Class Initialized
INFO - 2023-05-01 18:51:09 --> Helper loaded: url_helper
INFO - 2023-05-01 18:51:09 --> Helper loaded: file_helper
INFO - 2023-05-01 18:51:09 --> Helper loaded: form_helper
INFO - 2023-05-01 18:51:09 --> Helper loaded: my_helper
INFO - 2023-05-01 18:51:09 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:51:09 --> Controller Class Initialized
DEBUG - 2023-05-01 18:51:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-05-01 18:51:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:51:09 --> Final output sent to browser
DEBUG - 2023-05-01 18:51:09 --> Total execution time: 0.0310
INFO - 2023-05-01 18:51:13 --> Config Class Initialized
INFO - 2023-05-01 18:51:13 --> Hooks Class Initialized
DEBUG - 2023-05-01 18:51:13 --> UTF-8 Support Enabled
INFO - 2023-05-01 18:51:13 --> Utf8 Class Initialized
INFO - 2023-05-01 18:51:13 --> URI Class Initialized
INFO - 2023-05-01 18:51:13 --> Router Class Initialized
INFO - 2023-05-01 18:51:13 --> Output Class Initialized
INFO - 2023-05-01 18:51:13 --> Security Class Initialized
DEBUG - 2023-05-01 18:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-01 18:51:13 --> Input Class Initialized
INFO - 2023-05-01 18:51:13 --> Language Class Initialized
INFO - 2023-05-01 18:51:13 --> Language Class Initialized
INFO - 2023-05-01 18:51:13 --> Config Class Initialized
INFO - 2023-05-01 18:51:13 --> Loader Class Initialized
INFO - 2023-05-01 18:51:13 --> Helper loaded: url_helper
INFO - 2023-05-01 18:51:13 --> Helper loaded: file_helper
INFO - 2023-05-01 18:51:13 --> Helper loaded: form_helper
INFO - 2023-05-01 18:51:13 --> Helper loaded: my_helper
INFO - 2023-05-01 18:51:13 --> Database Driver Class Initialized
DEBUG - 2023-05-01 18:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-01 18:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-01 18:51:13 --> Controller Class Initialized
DEBUG - 2023-05-01 18:51:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-05-01 18:51:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-01 18:51:13 --> Final output sent to browser
DEBUG - 2023-05-01 18:51:13 --> Total execution time: 0.0286
