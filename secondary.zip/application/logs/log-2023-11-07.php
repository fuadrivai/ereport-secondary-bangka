<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-07 10:35:42 --> Config Class Initialized
INFO - 2023-11-07 10:35:42 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:35:42 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:35:42 --> Utf8 Class Initialized
INFO - 2023-11-07 10:35:42 --> URI Class Initialized
INFO - 2023-11-07 10:35:42 --> Router Class Initialized
INFO - 2023-11-07 10:35:42 --> Output Class Initialized
INFO - 2023-11-07 10:35:42 --> Security Class Initialized
DEBUG - 2023-11-07 10:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:35:42 --> Input Class Initialized
INFO - 2023-11-07 10:35:42 --> Language Class Initialized
INFO - 2023-11-07 10:35:42 --> Language Class Initialized
INFO - 2023-11-07 10:35:42 --> Config Class Initialized
INFO - 2023-11-07 10:35:42 --> Loader Class Initialized
INFO - 2023-11-07 10:35:42 --> Helper loaded: url_helper
INFO - 2023-11-07 10:35:42 --> Helper loaded: file_helper
INFO - 2023-11-07 10:35:42 --> Helper loaded: form_helper
INFO - 2023-11-07 10:35:42 --> Helper loaded: my_helper
INFO - 2023-11-07 10:35:42 --> Database Driver Class Initialized
INFO - 2023-11-07 10:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:35:42 --> Controller Class Initialized
DEBUG - 2023-11-07 10:35:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-07 10:35:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-07 10:35:42 --> Final output sent to browser
DEBUG - 2023-11-07 10:35:42 --> Total execution time: 0.0695
INFO - 2023-11-07 10:36:32 --> Config Class Initialized
INFO - 2023-11-07 10:36:32 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:36:32 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:36:32 --> Utf8 Class Initialized
INFO - 2023-11-07 10:36:32 --> URI Class Initialized
INFO - 2023-11-07 10:36:32 --> Router Class Initialized
INFO - 2023-11-07 10:36:32 --> Output Class Initialized
INFO - 2023-11-07 10:36:32 --> Security Class Initialized
DEBUG - 2023-11-07 10:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:36:32 --> Input Class Initialized
INFO - 2023-11-07 10:36:32 --> Language Class Initialized
INFO - 2023-11-07 10:36:32 --> Language Class Initialized
INFO - 2023-11-07 10:36:32 --> Config Class Initialized
INFO - 2023-11-07 10:36:32 --> Loader Class Initialized
INFO - 2023-11-07 10:36:32 --> Helper loaded: url_helper
INFO - 2023-11-07 10:36:32 --> Helper loaded: file_helper
INFO - 2023-11-07 10:36:32 --> Helper loaded: form_helper
INFO - 2023-11-07 10:36:32 --> Helper loaded: my_helper
INFO - 2023-11-07 10:36:32 --> Database Driver Class Initialized
INFO - 2023-11-07 10:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:36:32 --> Controller Class Initialized
INFO - 2023-11-07 10:36:32 --> Helper loaded: cookie_helper
INFO - 2023-11-07 10:36:32 --> Final output sent to browser
DEBUG - 2023-11-07 10:36:32 --> Total execution time: 0.0492
INFO - 2023-11-07 10:36:33 --> Config Class Initialized
INFO - 2023-11-07 10:36:33 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:36:33 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:36:33 --> Utf8 Class Initialized
INFO - 2023-11-07 10:36:33 --> URI Class Initialized
INFO - 2023-11-07 10:36:33 --> Router Class Initialized
INFO - 2023-11-07 10:36:33 --> Output Class Initialized
INFO - 2023-11-07 10:36:33 --> Security Class Initialized
DEBUG - 2023-11-07 10:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:36:33 --> Input Class Initialized
INFO - 2023-11-07 10:36:33 --> Language Class Initialized
INFO - 2023-11-07 10:36:33 --> Language Class Initialized
INFO - 2023-11-07 10:36:33 --> Config Class Initialized
INFO - 2023-11-07 10:36:33 --> Loader Class Initialized
INFO - 2023-11-07 10:36:33 --> Helper loaded: url_helper
INFO - 2023-11-07 10:36:33 --> Helper loaded: file_helper
INFO - 2023-11-07 10:36:33 --> Helper loaded: form_helper
INFO - 2023-11-07 10:36:33 --> Helper loaded: my_helper
INFO - 2023-11-07 10:36:33 --> Database Driver Class Initialized
INFO - 2023-11-07 10:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:36:33 --> Controller Class Initialized
DEBUG - 2023-11-07 10:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-07 10:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-07 10:36:33 --> Final output sent to browser
DEBUG - 2023-11-07 10:36:33 --> Total execution time: 0.3673
INFO - 2023-11-07 10:36:42 --> Config Class Initialized
INFO - 2023-11-07 10:36:42 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:36:42 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:36:42 --> Utf8 Class Initialized
INFO - 2023-11-07 10:36:42 --> URI Class Initialized
INFO - 2023-11-07 10:36:42 --> Router Class Initialized
INFO - 2023-11-07 10:36:42 --> Output Class Initialized
INFO - 2023-11-07 10:36:42 --> Security Class Initialized
DEBUG - 2023-11-07 10:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:36:42 --> Input Class Initialized
INFO - 2023-11-07 10:36:42 --> Language Class Initialized
INFO - 2023-11-07 10:36:42 --> Language Class Initialized
INFO - 2023-11-07 10:36:42 --> Config Class Initialized
INFO - 2023-11-07 10:36:42 --> Loader Class Initialized
INFO - 2023-11-07 10:36:42 --> Helper loaded: url_helper
INFO - 2023-11-07 10:36:42 --> Helper loaded: file_helper
INFO - 2023-11-07 10:36:42 --> Helper loaded: form_helper
INFO - 2023-11-07 10:36:42 --> Helper loaded: my_helper
INFO - 2023-11-07 10:36:42 --> Database Driver Class Initialized
INFO - 2023-11-07 10:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:36:42 --> Controller Class Initialized
DEBUG - 2023-11-07 10:36:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-11-07 10:36:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-07 10:36:42 --> Final output sent to browser
DEBUG - 2023-11-07 10:36:42 --> Total execution time: 0.0406
INFO - 2023-11-07 10:36:48 --> Config Class Initialized
INFO - 2023-11-07 10:36:48 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:36:48 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:36:48 --> Utf8 Class Initialized
INFO - 2023-11-07 10:36:48 --> URI Class Initialized
INFO - 2023-11-07 10:36:48 --> Router Class Initialized
INFO - 2023-11-07 10:36:48 --> Output Class Initialized
INFO - 2023-11-07 10:36:48 --> Security Class Initialized
DEBUG - 2023-11-07 10:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:36:48 --> Input Class Initialized
INFO - 2023-11-07 10:36:48 --> Language Class Initialized
INFO - 2023-11-07 10:36:48 --> Language Class Initialized
INFO - 2023-11-07 10:36:48 --> Config Class Initialized
INFO - 2023-11-07 10:36:48 --> Loader Class Initialized
INFO - 2023-11-07 10:36:48 --> Helper loaded: url_helper
INFO - 2023-11-07 10:36:48 --> Helper loaded: file_helper
INFO - 2023-11-07 10:36:48 --> Helper loaded: form_helper
INFO - 2023-11-07 10:36:48 --> Helper loaded: my_helper
INFO - 2023-11-07 10:36:48 --> Database Driver Class Initialized
INFO - 2023-11-07 10:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:36:48 --> Controller Class Initialized
DEBUG - 2023-11-07 10:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-07 10:36:51 --> Final output sent to browser
DEBUG - 2023-11-07 10:36:51 --> Total execution time: 3.6117
INFO - 2023-11-07 10:38:28 --> Config Class Initialized
INFO - 2023-11-07 10:38:28 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:38:28 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:38:28 --> Utf8 Class Initialized
INFO - 2023-11-07 10:38:28 --> URI Class Initialized
INFO - 2023-11-07 10:38:28 --> Router Class Initialized
INFO - 2023-11-07 10:38:28 --> Output Class Initialized
INFO - 2023-11-07 10:38:28 --> Security Class Initialized
DEBUG - 2023-11-07 10:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:38:28 --> Input Class Initialized
INFO - 2023-11-07 10:38:28 --> Language Class Initialized
INFO - 2023-11-07 10:38:28 --> Language Class Initialized
INFO - 2023-11-07 10:38:28 --> Config Class Initialized
INFO - 2023-11-07 10:38:28 --> Loader Class Initialized
INFO - 2023-11-07 10:38:28 --> Helper loaded: url_helper
INFO - 2023-11-07 10:38:28 --> Helper loaded: file_helper
INFO - 2023-11-07 10:38:28 --> Helper loaded: form_helper
INFO - 2023-11-07 10:38:28 --> Helper loaded: my_helper
INFO - 2023-11-07 10:38:28 --> Database Driver Class Initialized
INFO - 2023-11-07 10:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:38:28 --> Controller Class Initialized
DEBUG - 2023-11-07 10:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-07 10:38:32 --> Final output sent to browser
DEBUG - 2023-11-07 10:38:32 --> Total execution time: 4.0045
INFO - 2023-11-07 10:39:56 --> Config Class Initialized
INFO - 2023-11-07 10:39:56 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:39:56 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:39:56 --> Utf8 Class Initialized
INFO - 2023-11-07 10:39:56 --> URI Class Initialized
INFO - 2023-11-07 10:39:56 --> Router Class Initialized
INFO - 2023-11-07 10:39:56 --> Output Class Initialized
INFO - 2023-11-07 10:39:56 --> Security Class Initialized
DEBUG - 2023-11-07 10:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:39:56 --> Input Class Initialized
INFO - 2023-11-07 10:39:56 --> Language Class Initialized
INFO - 2023-11-07 10:39:56 --> Language Class Initialized
INFO - 2023-11-07 10:39:56 --> Config Class Initialized
INFO - 2023-11-07 10:39:56 --> Loader Class Initialized
INFO - 2023-11-07 10:39:56 --> Helper loaded: url_helper
INFO - 2023-11-07 10:39:56 --> Helper loaded: file_helper
INFO - 2023-11-07 10:39:56 --> Helper loaded: form_helper
INFO - 2023-11-07 10:39:56 --> Helper loaded: my_helper
INFO - 2023-11-07 10:39:56 --> Database Driver Class Initialized
INFO - 2023-11-07 10:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:39:56 --> Controller Class Initialized
DEBUG - 2023-11-07 10:39:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-07 10:40:00 --> Final output sent to browser
DEBUG - 2023-11-07 10:40:00 --> Total execution time: 3.7722
INFO - 2023-11-07 10:53:43 --> Config Class Initialized
INFO - 2023-11-07 10:53:43 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:53:43 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:53:43 --> Utf8 Class Initialized
INFO - 2023-11-07 10:53:43 --> URI Class Initialized
INFO - 2023-11-07 10:53:43 --> Router Class Initialized
INFO - 2023-11-07 10:53:43 --> Output Class Initialized
INFO - 2023-11-07 10:53:43 --> Security Class Initialized
DEBUG - 2023-11-07 10:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:53:43 --> Input Class Initialized
INFO - 2023-11-07 10:53:43 --> Language Class Initialized
INFO - 2023-11-07 10:53:43 --> Language Class Initialized
INFO - 2023-11-07 10:53:43 --> Config Class Initialized
INFO - 2023-11-07 10:53:43 --> Loader Class Initialized
INFO - 2023-11-07 10:53:43 --> Helper loaded: url_helper
INFO - 2023-11-07 10:53:43 --> Helper loaded: file_helper
INFO - 2023-11-07 10:53:43 --> Helper loaded: form_helper
INFO - 2023-11-07 10:53:43 --> Helper loaded: my_helper
INFO - 2023-11-07 10:53:43 --> Database Driver Class Initialized
INFO - 2023-11-07 10:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:53:43 --> Controller Class Initialized
DEBUG - 2023-11-07 10:53:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-07 10:53:47 --> Final output sent to browser
DEBUG - 2023-11-07 10:53:47 --> Total execution time: 4.2205
INFO - 2023-11-07 10:53:50 --> Config Class Initialized
INFO - 2023-11-07 10:53:50 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:53:50 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:53:50 --> Utf8 Class Initialized
INFO - 2023-11-07 10:53:50 --> URI Class Initialized
INFO - 2023-11-07 10:53:50 --> Router Class Initialized
INFO - 2023-11-07 10:53:50 --> Output Class Initialized
INFO - 2023-11-07 10:53:50 --> Security Class Initialized
DEBUG - 2023-11-07 10:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:53:50 --> Input Class Initialized
INFO - 2023-11-07 10:53:50 --> Language Class Initialized
INFO - 2023-11-07 10:53:50 --> Language Class Initialized
INFO - 2023-11-07 10:53:50 --> Config Class Initialized
INFO - 2023-11-07 10:53:50 --> Loader Class Initialized
INFO - 2023-11-07 10:53:50 --> Helper loaded: url_helper
INFO - 2023-11-07 10:53:50 --> Helper loaded: file_helper
INFO - 2023-11-07 10:53:50 --> Helper loaded: form_helper
INFO - 2023-11-07 10:53:50 --> Helper loaded: my_helper
INFO - 2023-11-07 10:53:50 --> Database Driver Class Initialized
INFO - 2023-11-07 10:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:53:50 --> Controller Class Initialized
DEBUG - 2023-11-07 10:53:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-07 10:53:54 --> Final output sent to browser
DEBUG - 2023-11-07 10:53:54 --> Total execution time: 3.6893
