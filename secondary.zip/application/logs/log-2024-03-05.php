<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-05 08:05:51 --> Config Class Initialized
INFO - 2024-03-05 08:05:51 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:05:51 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:05:51 --> Utf8 Class Initialized
INFO - 2024-03-05 08:05:51 --> URI Class Initialized
INFO - 2024-03-05 08:05:51 --> Router Class Initialized
INFO - 2024-03-05 08:05:51 --> Output Class Initialized
INFO - 2024-03-05 08:05:51 --> Security Class Initialized
DEBUG - 2024-03-05 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:05:51 --> Input Class Initialized
INFO - 2024-03-05 08:05:51 --> Language Class Initialized
INFO - 2024-03-05 08:05:51 --> Language Class Initialized
INFO - 2024-03-05 08:05:51 --> Config Class Initialized
INFO - 2024-03-05 08:05:51 --> Loader Class Initialized
INFO - 2024-03-05 08:05:51 --> Helper loaded: url_helper
INFO - 2024-03-05 08:05:51 --> Helper loaded: file_helper
INFO - 2024-03-05 08:05:51 --> Helper loaded: form_helper
INFO - 2024-03-05 08:05:51 --> Helper loaded: my_helper
INFO - 2024-03-05 08:05:51 --> Database Driver Class Initialized
INFO - 2024-03-05 08:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:05:51 --> Controller Class Initialized
DEBUG - 2024-03-05 08:05:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-05 08:05:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:05:51 --> Final output sent to browser
DEBUG - 2024-03-05 08:05:51 --> Total execution time: 0.0485
INFO - 2024-03-05 08:05:55 --> Config Class Initialized
INFO - 2024-03-05 08:05:55 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:05:55 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:05:55 --> Utf8 Class Initialized
INFO - 2024-03-05 08:05:55 --> URI Class Initialized
INFO - 2024-03-05 08:05:55 --> Router Class Initialized
INFO - 2024-03-05 08:05:55 --> Output Class Initialized
INFO - 2024-03-05 08:05:55 --> Security Class Initialized
DEBUG - 2024-03-05 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:05:55 --> Input Class Initialized
INFO - 2024-03-05 08:05:55 --> Language Class Initialized
INFO - 2024-03-05 08:05:55 --> Language Class Initialized
INFO - 2024-03-05 08:05:55 --> Config Class Initialized
INFO - 2024-03-05 08:05:55 --> Loader Class Initialized
INFO - 2024-03-05 08:05:55 --> Helper loaded: url_helper
INFO - 2024-03-05 08:05:55 --> Helper loaded: file_helper
INFO - 2024-03-05 08:05:55 --> Helper loaded: form_helper
INFO - 2024-03-05 08:05:55 --> Helper loaded: my_helper
INFO - 2024-03-05 08:05:55 --> Database Driver Class Initialized
INFO - 2024-03-05 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:05:55 --> Controller Class Initialized
INFO - 2024-03-05 08:05:55 --> Helper loaded: cookie_helper
INFO - 2024-03-05 08:05:55 --> Final output sent to browser
DEBUG - 2024-03-05 08:05:55 --> Total execution time: 0.0391
INFO - 2024-03-05 08:05:55 --> Config Class Initialized
INFO - 2024-03-05 08:05:55 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:05:55 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:05:55 --> Utf8 Class Initialized
INFO - 2024-03-05 08:05:55 --> URI Class Initialized
INFO - 2024-03-05 08:05:55 --> Router Class Initialized
INFO - 2024-03-05 08:05:55 --> Output Class Initialized
INFO - 2024-03-05 08:05:55 --> Security Class Initialized
DEBUG - 2024-03-05 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:05:55 --> Input Class Initialized
INFO - 2024-03-05 08:05:55 --> Language Class Initialized
INFO - 2024-03-05 08:05:55 --> Language Class Initialized
INFO - 2024-03-05 08:05:55 --> Config Class Initialized
INFO - 2024-03-05 08:05:55 --> Loader Class Initialized
INFO - 2024-03-05 08:05:55 --> Helper loaded: url_helper
INFO - 2024-03-05 08:05:55 --> Helper loaded: file_helper
INFO - 2024-03-05 08:05:55 --> Helper loaded: form_helper
INFO - 2024-03-05 08:05:55 --> Helper loaded: my_helper
INFO - 2024-03-05 08:05:55 --> Database Driver Class Initialized
INFO - 2024-03-05 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:05:55 --> Controller Class Initialized
DEBUG - 2024-03-05 08:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-05 08:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:05:55 --> Final output sent to browser
DEBUG - 2024-03-05 08:05:55 --> Total execution time: 0.0323
INFO - 2024-03-05 08:06:01 --> Config Class Initialized
INFO - 2024-03-05 08:06:01 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:06:01 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:06:01 --> Utf8 Class Initialized
INFO - 2024-03-05 08:06:01 --> URI Class Initialized
INFO - 2024-03-05 08:06:01 --> Router Class Initialized
INFO - 2024-03-05 08:06:01 --> Output Class Initialized
INFO - 2024-03-05 08:06:01 --> Security Class Initialized
DEBUG - 2024-03-05 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:06:01 --> Input Class Initialized
INFO - 2024-03-05 08:06:01 --> Language Class Initialized
INFO - 2024-03-05 08:06:01 --> Language Class Initialized
INFO - 2024-03-05 08:06:01 --> Config Class Initialized
INFO - 2024-03-05 08:06:01 --> Loader Class Initialized
INFO - 2024-03-05 08:06:01 --> Helper loaded: url_helper
INFO - 2024-03-05 08:06:01 --> Helper loaded: file_helper
INFO - 2024-03-05 08:06:01 --> Helper loaded: form_helper
INFO - 2024-03-05 08:06:01 --> Helper loaded: my_helper
INFO - 2024-03-05 08:06:01 --> Database Driver Class Initialized
INFO - 2024-03-05 08:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:06:01 --> Controller Class Initialized
DEBUG - 2024-03-05 08:06:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-05 08:06:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:06:01 --> Final output sent to browser
DEBUG - 2024-03-05 08:06:01 --> Total execution time: 0.0993
INFO - 2024-03-05 08:06:01 --> Config Class Initialized
INFO - 2024-03-05 08:06:01 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:06:01 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:06:01 --> Utf8 Class Initialized
INFO - 2024-03-05 08:06:01 --> URI Class Initialized
INFO - 2024-03-05 08:06:01 --> Router Class Initialized
INFO - 2024-03-05 08:06:01 --> Output Class Initialized
INFO - 2024-03-05 08:06:01 --> Security Class Initialized
DEBUG - 2024-03-05 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:06:01 --> Input Class Initialized
INFO - 2024-03-05 08:06:01 --> Language Class Initialized
ERROR - 2024-03-05 08:06:01 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:06:02 --> Config Class Initialized
INFO - 2024-03-05 08:06:02 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:06:02 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:06:02 --> Utf8 Class Initialized
INFO - 2024-03-05 08:06:02 --> URI Class Initialized
INFO - 2024-03-05 08:06:02 --> Router Class Initialized
INFO - 2024-03-05 08:06:02 --> Output Class Initialized
INFO - 2024-03-05 08:06:02 --> Security Class Initialized
DEBUG - 2024-03-05 08:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:06:02 --> Input Class Initialized
INFO - 2024-03-05 08:06:02 --> Language Class Initialized
INFO - 2024-03-05 08:06:02 --> Language Class Initialized
INFO - 2024-03-05 08:06:02 --> Config Class Initialized
INFO - 2024-03-05 08:06:02 --> Loader Class Initialized
INFO - 2024-03-05 08:06:02 --> Helper loaded: url_helper
INFO - 2024-03-05 08:06:02 --> Helper loaded: file_helper
INFO - 2024-03-05 08:06:02 --> Helper loaded: form_helper
INFO - 2024-03-05 08:06:02 --> Helper loaded: my_helper
INFO - 2024-03-05 08:06:02 --> Database Driver Class Initialized
INFO - 2024-03-05 08:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:06:02 --> Controller Class Initialized
INFO - 2024-03-05 08:51:57 --> Config Class Initialized
INFO - 2024-03-05 08:51:57 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:51:57 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:51:57 --> Utf8 Class Initialized
INFO - 2024-03-05 08:51:57 --> URI Class Initialized
INFO - 2024-03-05 08:51:57 --> Router Class Initialized
INFO - 2024-03-05 08:51:57 --> Output Class Initialized
INFO - 2024-03-05 08:51:57 --> Security Class Initialized
DEBUG - 2024-03-05 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:51:57 --> Input Class Initialized
INFO - 2024-03-05 08:51:57 --> Language Class Initialized
INFO - 2024-03-05 08:51:57 --> Language Class Initialized
INFO - 2024-03-05 08:51:57 --> Config Class Initialized
INFO - 2024-03-05 08:51:57 --> Loader Class Initialized
INFO - 2024-03-05 08:51:57 --> Helper loaded: url_helper
INFO - 2024-03-05 08:51:57 --> Helper loaded: file_helper
INFO - 2024-03-05 08:51:57 --> Helper loaded: form_helper
INFO - 2024-03-05 08:51:57 --> Helper loaded: my_helper
INFO - 2024-03-05 08:51:57 --> Database Driver Class Initialized
INFO - 2024-03-05 08:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:51:57 --> Controller Class Initialized
DEBUG - 2024-03-05 08:51:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-05 08:51:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:51:57 --> Final output sent to browser
DEBUG - 2024-03-05 08:51:57 --> Total execution time: 0.0551
INFO - 2024-03-05 08:52:00 --> Config Class Initialized
INFO - 2024-03-05 08:52:00 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:52:00 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:52:00 --> Utf8 Class Initialized
INFO - 2024-03-05 08:52:00 --> URI Class Initialized
INFO - 2024-03-05 08:52:00 --> Router Class Initialized
INFO - 2024-03-05 08:52:00 --> Output Class Initialized
INFO - 2024-03-05 08:52:00 --> Security Class Initialized
DEBUG - 2024-03-05 08:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:52:00 --> Input Class Initialized
INFO - 2024-03-05 08:52:00 --> Language Class Initialized
INFO - 2024-03-05 08:52:00 --> Language Class Initialized
INFO - 2024-03-05 08:52:00 --> Config Class Initialized
INFO - 2024-03-05 08:52:00 --> Loader Class Initialized
INFO - 2024-03-05 08:52:00 --> Helper loaded: url_helper
INFO - 2024-03-05 08:52:00 --> Helper loaded: file_helper
INFO - 2024-03-05 08:52:00 --> Helper loaded: form_helper
INFO - 2024-03-05 08:52:00 --> Helper loaded: my_helper
INFO - 2024-03-05 08:52:00 --> Database Driver Class Initialized
INFO - 2024-03-05 08:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:52:00 --> Controller Class Initialized
INFO - 2024-03-05 08:52:00 --> Helper loaded: cookie_helper
INFO - 2024-03-05 08:52:00 --> Final output sent to browser
DEBUG - 2024-03-05 08:52:00 --> Total execution time: 0.0434
INFO - 2024-03-05 08:52:00 --> Config Class Initialized
INFO - 2024-03-05 08:52:00 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:52:00 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:52:00 --> Utf8 Class Initialized
INFO - 2024-03-05 08:52:00 --> URI Class Initialized
INFO - 2024-03-05 08:52:00 --> Router Class Initialized
INFO - 2024-03-05 08:52:00 --> Output Class Initialized
INFO - 2024-03-05 08:52:00 --> Security Class Initialized
DEBUG - 2024-03-05 08:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:52:00 --> Input Class Initialized
INFO - 2024-03-05 08:52:00 --> Language Class Initialized
INFO - 2024-03-05 08:52:00 --> Language Class Initialized
INFO - 2024-03-05 08:52:00 --> Config Class Initialized
INFO - 2024-03-05 08:52:00 --> Loader Class Initialized
INFO - 2024-03-05 08:52:00 --> Helper loaded: url_helper
INFO - 2024-03-05 08:52:00 --> Helper loaded: file_helper
INFO - 2024-03-05 08:52:00 --> Helper loaded: form_helper
INFO - 2024-03-05 08:52:00 --> Helper loaded: my_helper
INFO - 2024-03-05 08:52:00 --> Database Driver Class Initialized
INFO - 2024-03-05 08:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:52:00 --> Controller Class Initialized
DEBUG - 2024-03-05 08:52:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-05 08:52:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:52:00 --> Final output sent to browser
DEBUG - 2024-03-05 08:52:00 --> Total execution time: 0.0364
INFO - 2024-03-05 08:52:18 --> Config Class Initialized
INFO - 2024-03-05 08:52:18 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:52:18 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:52:18 --> Utf8 Class Initialized
INFO - 2024-03-05 08:52:18 --> URI Class Initialized
INFO - 2024-03-05 08:52:18 --> Router Class Initialized
INFO - 2024-03-05 08:52:18 --> Output Class Initialized
INFO - 2024-03-05 08:52:18 --> Security Class Initialized
DEBUG - 2024-03-05 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:52:18 --> Input Class Initialized
INFO - 2024-03-05 08:52:18 --> Language Class Initialized
INFO - 2024-03-05 08:52:18 --> Language Class Initialized
INFO - 2024-03-05 08:52:18 --> Config Class Initialized
INFO - 2024-03-05 08:52:18 --> Loader Class Initialized
INFO - 2024-03-05 08:52:18 --> Helper loaded: url_helper
INFO - 2024-03-05 08:52:18 --> Helper loaded: file_helper
INFO - 2024-03-05 08:52:18 --> Helper loaded: form_helper
INFO - 2024-03-05 08:52:18 --> Helper loaded: my_helper
INFO - 2024-03-05 08:52:18 --> Database Driver Class Initialized
INFO - 2024-03-05 08:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:52:18 --> Controller Class Initialized
DEBUG - 2024-03-05 08:52:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-05 08:52:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:52:18 --> Final output sent to browser
DEBUG - 2024-03-05 08:52:18 --> Total execution time: 0.0339
INFO - 2024-03-05 08:52:18 --> Config Class Initialized
INFO - 2024-03-05 08:52:18 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:52:18 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:52:18 --> Utf8 Class Initialized
INFO - 2024-03-05 08:52:18 --> URI Class Initialized
INFO - 2024-03-05 08:52:18 --> Router Class Initialized
INFO - 2024-03-05 08:52:18 --> Output Class Initialized
INFO - 2024-03-05 08:52:18 --> Security Class Initialized
DEBUG - 2024-03-05 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:52:18 --> Input Class Initialized
INFO - 2024-03-05 08:52:18 --> Language Class Initialized
ERROR - 2024-03-05 08:52:18 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:52:18 --> Config Class Initialized
INFO - 2024-03-05 08:52:18 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:52:18 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:52:18 --> Utf8 Class Initialized
INFO - 2024-03-05 08:52:18 --> URI Class Initialized
INFO - 2024-03-05 08:52:18 --> Router Class Initialized
INFO - 2024-03-05 08:52:18 --> Output Class Initialized
INFO - 2024-03-05 08:52:18 --> Security Class Initialized
DEBUG - 2024-03-05 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:52:18 --> Input Class Initialized
INFO - 2024-03-05 08:52:18 --> Language Class Initialized
INFO - 2024-03-05 08:52:18 --> Language Class Initialized
INFO - 2024-03-05 08:52:18 --> Config Class Initialized
INFO - 2024-03-05 08:52:18 --> Loader Class Initialized
INFO - 2024-03-05 08:52:18 --> Helper loaded: url_helper
INFO - 2024-03-05 08:52:18 --> Helper loaded: file_helper
INFO - 2024-03-05 08:52:18 --> Helper loaded: form_helper
INFO - 2024-03-05 08:52:18 --> Helper loaded: my_helper
INFO - 2024-03-05 08:52:18 --> Database Driver Class Initialized
INFO - 2024-03-05 08:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:52:18 --> Controller Class Initialized
INFO - 2024-03-05 08:52:22 --> Config Class Initialized
INFO - 2024-03-05 08:52:22 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:52:22 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:52:22 --> Utf8 Class Initialized
INFO - 2024-03-05 08:52:22 --> URI Class Initialized
INFO - 2024-03-05 08:52:22 --> Router Class Initialized
INFO - 2024-03-05 08:52:22 --> Output Class Initialized
INFO - 2024-03-05 08:52:22 --> Security Class Initialized
DEBUG - 2024-03-05 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:52:22 --> Input Class Initialized
INFO - 2024-03-05 08:52:22 --> Language Class Initialized
INFO - 2024-03-05 08:52:22 --> Language Class Initialized
INFO - 2024-03-05 08:52:22 --> Config Class Initialized
INFO - 2024-03-05 08:52:22 --> Loader Class Initialized
INFO - 2024-03-05 08:52:22 --> Helper loaded: url_helper
INFO - 2024-03-05 08:52:22 --> Helper loaded: file_helper
INFO - 2024-03-05 08:52:22 --> Helper loaded: form_helper
INFO - 2024-03-05 08:52:22 --> Helper loaded: my_helper
INFO - 2024-03-05 08:52:22 --> Database Driver Class Initialized
INFO - 2024-03-05 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:52:22 --> Controller Class Initialized
INFO - 2024-03-05 08:52:22 --> Final output sent to browser
DEBUG - 2024-03-05 08:52:22 --> Total execution time: 0.0401
INFO - 2024-03-05 08:53:49 --> Config Class Initialized
INFO - 2024-03-05 08:53:49 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:53:49 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:53:49 --> Utf8 Class Initialized
INFO - 2024-03-05 08:53:49 --> URI Class Initialized
INFO - 2024-03-05 08:53:49 --> Router Class Initialized
INFO - 2024-03-05 08:53:49 --> Output Class Initialized
INFO - 2024-03-05 08:53:49 --> Security Class Initialized
DEBUG - 2024-03-05 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:53:49 --> Input Class Initialized
INFO - 2024-03-05 08:53:49 --> Language Class Initialized
INFO - 2024-03-05 08:53:49 --> Language Class Initialized
INFO - 2024-03-05 08:53:49 --> Config Class Initialized
INFO - 2024-03-05 08:53:49 --> Loader Class Initialized
INFO - 2024-03-05 08:53:49 --> Helper loaded: url_helper
INFO - 2024-03-05 08:53:49 --> Helper loaded: file_helper
INFO - 2024-03-05 08:53:49 --> Helper loaded: form_helper
INFO - 2024-03-05 08:53:49 --> Helper loaded: my_helper
INFO - 2024-03-05 08:53:49 --> Database Driver Class Initialized
INFO - 2024-03-05 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:53:49 --> Controller Class Initialized
INFO - 2024-03-05 08:53:49 --> Final output sent to browser
DEBUG - 2024-03-05 08:53:49 --> Total execution time: 0.0324
INFO - 2024-03-05 08:53:49 --> Config Class Initialized
INFO - 2024-03-05 08:53:49 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:53:49 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:53:49 --> Utf8 Class Initialized
INFO - 2024-03-05 08:53:49 --> URI Class Initialized
INFO - 2024-03-05 08:53:49 --> Router Class Initialized
INFO - 2024-03-05 08:53:49 --> Output Class Initialized
INFO - 2024-03-05 08:53:49 --> Security Class Initialized
DEBUG - 2024-03-05 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:53:49 --> Input Class Initialized
INFO - 2024-03-05 08:53:49 --> Language Class Initialized
ERROR - 2024-03-05 08:53:49 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:53:49 --> Config Class Initialized
INFO - 2024-03-05 08:53:49 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:53:49 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:53:49 --> Utf8 Class Initialized
INFO - 2024-03-05 08:53:49 --> URI Class Initialized
INFO - 2024-03-05 08:53:49 --> Router Class Initialized
INFO - 2024-03-05 08:53:49 --> Output Class Initialized
INFO - 2024-03-05 08:53:49 --> Security Class Initialized
DEBUG - 2024-03-05 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:53:49 --> Input Class Initialized
INFO - 2024-03-05 08:53:49 --> Language Class Initialized
INFO - 2024-03-05 08:53:49 --> Language Class Initialized
INFO - 2024-03-05 08:53:49 --> Config Class Initialized
INFO - 2024-03-05 08:53:49 --> Loader Class Initialized
INFO - 2024-03-05 08:53:49 --> Helper loaded: url_helper
INFO - 2024-03-05 08:53:49 --> Helper loaded: file_helper
INFO - 2024-03-05 08:53:49 --> Helper loaded: form_helper
INFO - 2024-03-05 08:53:49 --> Helper loaded: my_helper
INFO - 2024-03-05 08:53:49 --> Database Driver Class Initialized
INFO - 2024-03-05 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:53:49 --> Controller Class Initialized
INFO - 2024-03-05 08:53:59 --> Config Class Initialized
INFO - 2024-03-05 08:53:59 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:53:59 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:53:59 --> Utf8 Class Initialized
INFO - 2024-03-05 08:53:59 --> URI Class Initialized
INFO - 2024-03-05 08:53:59 --> Router Class Initialized
INFO - 2024-03-05 08:53:59 --> Output Class Initialized
INFO - 2024-03-05 08:53:59 --> Security Class Initialized
DEBUG - 2024-03-05 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:53:59 --> Input Class Initialized
INFO - 2024-03-05 08:53:59 --> Language Class Initialized
INFO - 2024-03-05 08:53:59 --> Language Class Initialized
INFO - 2024-03-05 08:53:59 --> Config Class Initialized
INFO - 2024-03-05 08:53:59 --> Loader Class Initialized
INFO - 2024-03-05 08:53:59 --> Helper loaded: url_helper
INFO - 2024-03-05 08:53:59 --> Helper loaded: file_helper
INFO - 2024-03-05 08:53:59 --> Helper loaded: form_helper
INFO - 2024-03-05 08:53:59 --> Helper loaded: my_helper
INFO - 2024-03-05 08:53:59 --> Database Driver Class Initialized
INFO - 2024-03-05 08:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:53:59 --> Controller Class Initialized
DEBUG - 2024-03-05 08:53:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-03-05 08:53:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:53:59 --> Final output sent to browser
DEBUG - 2024-03-05 08:53:59 --> Total execution time: 0.0411
INFO - 2024-03-05 08:53:59 --> Config Class Initialized
INFO - 2024-03-05 08:53:59 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:53:59 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:53:59 --> Utf8 Class Initialized
INFO - 2024-03-05 08:53:59 --> URI Class Initialized
INFO - 2024-03-05 08:53:59 --> Router Class Initialized
INFO - 2024-03-05 08:53:59 --> Output Class Initialized
INFO - 2024-03-05 08:53:59 --> Security Class Initialized
DEBUG - 2024-03-05 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:53:59 --> Input Class Initialized
INFO - 2024-03-05 08:53:59 --> Language Class Initialized
ERROR - 2024-03-05 08:53:59 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:53:59 --> Config Class Initialized
INFO - 2024-03-05 08:53:59 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:53:59 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:53:59 --> Utf8 Class Initialized
INFO - 2024-03-05 08:53:59 --> URI Class Initialized
INFO - 2024-03-05 08:53:59 --> Router Class Initialized
INFO - 2024-03-05 08:53:59 --> Output Class Initialized
INFO - 2024-03-05 08:53:59 --> Security Class Initialized
DEBUG - 2024-03-05 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:53:59 --> Input Class Initialized
INFO - 2024-03-05 08:53:59 --> Language Class Initialized
INFO - 2024-03-05 08:53:59 --> Language Class Initialized
INFO - 2024-03-05 08:53:59 --> Config Class Initialized
INFO - 2024-03-05 08:53:59 --> Loader Class Initialized
INFO - 2024-03-05 08:53:59 --> Helper loaded: url_helper
INFO - 2024-03-05 08:53:59 --> Helper loaded: file_helper
INFO - 2024-03-05 08:53:59 --> Helper loaded: form_helper
INFO - 2024-03-05 08:53:59 --> Helper loaded: my_helper
INFO - 2024-03-05 08:53:59 --> Database Driver Class Initialized
INFO - 2024-03-05 08:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:53:59 --> Controller Class Initialized
INFO - 2024-03-05 08:54:04 --> Config Class Initialized
INFO - 2024-03-05 08:54:04 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:04 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:04 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:04 --> URI Class Initialized
INFO - 2024-03-05 08:54:04 --> Router Class Initialized
INFO - 2024-03-05 08:54:04 --> Output Class Initialized
INFO - 2024-03-05 08:54:04 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:04 --> Input Class Initialized
INFO - 2024-03-05 08:54:04 --> Language Class Initialized
INFO - 2024-03-05 08:54:04 --> Language Class Initialized
INFO - 2024-03-05 08:54:04 --> Config Class Initialized
INFO - 2024-03-05 08:54:04 --> Loader Class Initialized
INFO - 2024-03-05 08:54:04 --> Helper loaded: url_helper
INFO - 2024-03-05 08:54:04 --> Helper loaded: file_helper
INFO - 2024-03-05 08:54:04 --> Helper loaded: form_helper
INFO - 2024-03-05 08:54:04 --> Helper loaded: my_helper
INFO - 2024-03-05 08:54:04 --> Database Driver Class Initialized
INFO - 2024-03-05 08:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:54:04 --> Controller Class Initialized
DEBUG - 2024-03-05 08:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-03-05 08:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:54:04 --> Final output sent to browser
DEBUG - 2024-03-05 08:54:04 --> Total execution time: 0.0339
INFO - 2024-03-05 08:54:04 --> Config Class Initialized
INFO - 2024-03-05 08:54:04 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:04 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:04 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:04 --> URI Class Initialized
INFO - 2024-03-05 08:54:04 --> Router Class Initialized
INFO - 2024-03-05 08:54:04 --> Output Class Initialized
INFO - 2024-03-05 08:54:04 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:04 --> Input Class Initialized
INFO - 2024-03-05 08:54:04 --> Language Class Initialized
ERROR - 2024-03-05 08:54:04 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:54:04 --> Config Class Initialized
INFO - 2024-03-05 08:54:04 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:04 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:04 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:04 --> URI Class Initialized
INFO - 2024-03-05 08:54:04 --> Router Class Initialized
INFO - 2024-03-05 08:54:04 --> Output Class Initialized
INFO - 2024-03-05 08:54:04 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:04 --> Input Class Initialized
INFO - 2024-03-05 08:54:04 --> Language Class Initialized
INFO - 2024-03-05 08:54:04 --> Language Class Initialized
INFO - 2024-03-05 08:54:04 --> Config Class Initialized
INFO - 2024-03-05 08:54:04 --> Loader Class Initialized
INFO - 2024-03-05 08:54:04 --> Helper loaded: url_helper
INFO - 2024-03-05 08:54:04 --> Helper loaded: file_helper
INFO - 2024-03-05 08:54:04 --> Helper loaded: form_helper
INFO - 2024-03-05 08:54:04 --> Helper loaded: my_helper
INFO - 2024-03-05 08:54:04 --> Database Driver Class Initialized
INFO - 2024-03-05 08:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:54:04 --> Controller Class Initialized
INFO - 2024-03-05 08:54:07 --> Config Class Initialized
INFO - 2024-03-05 08:54:07 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:07 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:07 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:07 --> URI Class Initialized
INFO - 2024-03-05 08:54:07 --> Router Class Initialized
INFO - 2024-03-05 08:54:07 --> Output Class Initialized
INFO - 2024-03-05 08:54:07 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:07 --> Input Class Initialized
INFO - 2024-03-05 08:54:07 --> Language Class Initialized
INFO - 2024-03-05 08:54:07 --> Language Class Initialized
INFO - 2024-03-05 08:54:07 --> Config Class Initialized
INFO - 2024-03-05 08:54:07 --> Loader Class Initialized
INFO - 2024-03-05 08:54:07 --> Helper loaded: url_helper
INFO - 2024-03-05 08:54:07 --> Helper loaded: file_helper
INFO - 2024-03-05 08:54:07 --> Helper loaded: form_helper
INFO - 2024-03-05 08:54:07 --> Helper loaded: my_helper
INFO - 2024-03-05 08:54:07 --> Database Driver Class Initialized
INFO - 2024-03-05 08:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:54:07 --> Controller Class Initialized
DEBUG - 2024-03-05 08:54:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-03-05 08:54:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:54:07 --> Final output sent to browser
DEBUG - 2024-03-05 08:54:07 --> Total execution time: 0.0343
INFO - 2024-03-05 08:54:07 --> Config Class Initialized
INFO - 2024-03-05 08:54:07 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:07 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:07 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:07 --> URI Class Initialized
INFO - 2024-03-05 08:54:07 --> Router Class Initialized
INFO - 2024-03-05 08:54:07 --> Output Class Initialized
INFO - 2024-03-05 08:54:07 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:07 --> Input Class Initialized
INFO - 2024-03-05 08:54:07 --> Language Class Initialized
ERROR - 2024-03-05 08:54:07 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:54:07 --> Config Class Initialized
INFO - 2024-03-05 08:54:07 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:07 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:07 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:07 --> URI Class Initialized
INFO - 2024-03-05 08:54:07 --> Router Class Initialized
INFO - 2024-03-05 08:54:07 --> Output Class Initialized
INFO - 2024-03-05 08:54:07 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:07 --> Input Class Initialized
INFO - 2024-03-05 08:54:07 --> Language Class Initialized
INFO - 2024-03-05 08:54:07 --> Language Class Initialized
INFO - 2024-03-05 08:54:07 --> Config Class Initialized
INFO - 2024-03-05 08:54:07 --> Loader Class Initialized
INFO - 2024-03-05 08:54:07 --> Helper loaded: url_helper
INFO - 2024-03-05 08:54:07 --> Helper loaded: file_helper
INFO - 2024-03-05 08:54:07 --> Helper loaded: form_helper
INFO - 2024-03-05 08:54:07 --> Helper loaded: my_helper
INFO - 2024-03-05 08:54:07 --> Database Driver Class Initialized
INFO - 2024-03-05 08:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:54:07 --> Controller Class Initialized
INFO - 2024-03-05 08:54:09 --> Config Class Initialized
INFO - 2024-03-05 08:54:09 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:09 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:09 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:09 --> URI Class Initialized
INFO - 2024-03-05 08:54:09 --> Router Class Initialized
INFO - 2024-03-05 08:54:09 --> Output Class Initialized
INFO - 2024-03-05 08:54:09 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:09 --> Input Class Initialized
INFO - 2024-03-05 08:54:09 --> Language Class Initialized
INFO - 2024-03-05 08:54:09 --> Language Class Initialized
INFO - 2024-03-05 08:54:09 --> Config Class Initialized
INFO - 2024-03-05 08:54:09 --> Loader Class Initialized
INFO - 2024-03-05 08:54:09 --> Helper loaded: url_helper
INFO - 2024-03-05 08:54:09 --> Helper loaded: file_helper
INFO - 2024-03-05 08:54:09 --> Helper loaded: form_helper
INFO - 2024-03-05 08:54:09 --> Helper loaded: my_helper
INFO - 2024-03-05 08:54:09 --> Database Driver Class Initialized
INFO - 2024-03-05 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:54:09 --> Controller Class Initialized
DEBUG - 2024-03-05 08:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-03-05 08:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-05 08:54:09 --> Final output sent to browser
DEBUG - 2024-03-05 08:54:09 --> Total execution time: 0.0375
INFO - 2024-03-05 08:54:09 --> Config Class Initialized
INFO - 2024-03-05 08:54:09 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:09 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:09 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:09 --> URI Class Initialized
INFO - 2024-03-05 08:54:09 --> Router Class Initialized
INFO - 2024-03-05 08:54:09 --> Output Class Initialized
INFO - 2024-03-05 08:54:09 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:09 --> Input Class Initialized
INFO - 2024-03-05 08:54:09 --> Language Class Initialized
ERROR - 2024-03-05 08:54:09 --> 404 Page Not Found: /index
INFO - 2024-03-05 08:54:09 --> Config Class Initialized
INFO - 2024-03-05 08:54:09 --> Hooks Class Initialized
DEBUG - 2024-03-05 08:54:09 --> UTF-8 Support Enabled
INFO - 2024-03-05 08:54:09 --> Utf8 Class Initialized
INFO - 2024-03-05 08:54:09 --> URI Class Initialized
INFO - 2024-03-05 08:54:09 --> Router Class Initialized
INFO - 2024-03-05 08:54:09 --> Output Class Initialized
INFO - 2024-03-05 08:54:09 --> Security Class Initialized
DEBUG - 2024-03-05 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-05 08:54:09 --> Input Class Initialized
INFO - 2024-03-05 08:54:09 --> Language Class Initialized
INFO - 2024-03-05 08:54:09 --> Language Class Initialized
INFO - 2024-03-05 08:54:09 --> Config Class Initialized
INFO - 2024-03-05 08:54:09 --> Loader Class Initialized
INFO - 2024-03-05 08:54:09 --> Helper loaded: url_helper
INFO - 2024-03-05 08:54:09 --> Helper loaded: file_helper
INFO - 2024-03-05 08:54:09 --> Helper loaded: form_helper
INFO - 2024-03-05 08:54:09 --> Helper loaded: my_helper
INFO - 2024-03-05 08:54:09 --> Database Driver Class Initialized
INFO - 2024-03-05 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-05 08:54:09 --> Controller Class Initialized
