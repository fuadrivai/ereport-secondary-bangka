<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-29 01:11:40 --> Config Class Initialized
INFO - 2024-06-29 01:11:40 --> Hooks Class Initialized
DEBUG - 2024-06-29 01:11:40 --> UTF-8 Support Enabled
INFO - 2024-06-29 01:11:40 --> Utf8 Class Initialized
INFO - 2024-06-29 01:11:40 --> URI Class Initialized
INFO - 2024-06-29 01:11:40 --> Router Class Initialized
INFO - 2024-06-29 01:11:40 --> Output Class Initialized
INFO - 2024-06-29 01:11:40 --> Security Class Initialized
DEBUG - 2024-06-29 01:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-29 01:11:40 --> Input Class Initialized
INFO - 2024-06-29 01:11:40 --> Language Class Initialized
INFO - 2024-06-29 01:11:40 --> Language Class Initialized
INFO - 2024-06-29 01:11:40 --> Config Class Initialized
INFO - 2024-06-29 01:11:40 --> Loader Class Initialized
INFO - 2024-06-29 01:11:40 --> Helper loaded: url_helper
INFO - 2024-06-29 01:11:40 --> Helper loaded: file_helper
INFO - 2024-06-29 01:11:40 --> Helper loaded: form_helper
INFO - 2024-06-29 01:11:40 --> Helper loaded: my_helper
INFO - 2024-06-29 01:11:40 --> Database Driver Class Initialized
INFO - 2024-06-29 01:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-29 01:11:40 --> Controller Class Initialized
INFO - 2024-06-29 01:11:40 --> Helper loaded: cookie_helper
INFO - 2024-06-29 01:11:40 --> Final output sent to browser
DEBUG - 2024-06-29 01:11:40 --> Total execution time: 0.0731
