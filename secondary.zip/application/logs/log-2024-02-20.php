<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-20 00:47:14 --> Config Class Initialized
INFO - 2024-02-20 00:47:14 --> Hooks Class Initialized
DEBUG - 2024-02-20 00:47:14 --> UTF-8 Support Enabled
INFO - 2024-02-20 00:47:14 --> Utf8 Class Initialized
INFO - 2024-02-20 00:47:14 --> URI Class Initialized
INFO - 2024-02-20 00:47:14 --> Router Class Initialized
INFO - 2024-02-20 00:47:14 --> Output Class Initialized
INFO - 2024-02-20 00:47:14 --> Security Class Initialized
DEBUG - 2024-02-20 00:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 00:47:14 --> Input Class Initialized
INFO - 2024-02-20 00:47:14 --> Language Class Initialized
INFO - 2024-02-20 00:47:14 --> Language Class Initialized
INFO - 2024-02-20 00:47:14 --> Config Class Initialized
INFO - 2024-02-20 00:47:14 --> Loader Class Initialized
INFO - 2024-02-20 00:47:14 --> Helper loaded: url_helper
INFO - 2024-02-20 00:47:14 --> Helper loaded: file_helper
INFO - 2024-02-20 00:47:14 --> Helper loaded: form_helper
INFO - 2024-02-20 00:47:14 --> Helper loaded: my_helper
INFO - 2024-02-20 00:47:14 --> Database Driver Class Initialized
INFO - 2024-02-20 00:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 00:47:14 --> Controller Class Initialized
DEBUG - 2024-02-20 00:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-20 00:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-20 00:47:14 --> Final output sent to browser
DEBUG - 2024-02-20 00:47:14 --> Total execution time: 0.1284
INFO - 2024-02-20 15:37:18 --> Config Class Initialized
INFO - 2024-02-20 15:37:18 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:18 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:18 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:18 --> URI Class Initialized
INFO - 2024-02-20 15:37:18 --> Router Class Initialized
INFO - 2024-02-20 15:37:18 --> Output Class Initialized
INFO - 2024-02-20 15:37:18 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:18 --> Input Class Initialized
INFO - 2024-02-20 15:37:18 --> Language Class Initialized
INFO - 2024-02-20 15:37:18 --> Language Class Initialized
INFO - 2024-02-20 15:37:18 --> Config Class Initialized
INFO - 2024-02-20 15:37:18 --> Loader Class Initialized
INFO - 2024-02-20 15:37:18 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:18 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:18 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:18 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:18 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:18 --> Controller Class Initialized
INFO - 2024-02-20 15:37:18 --> Helper loaded: cookie_helper
INFO - 2024-02-20 15:37:18 --> Final output sent to browser
DEBUG - 2024-02-20 15:37:18 --> Total execution time: 0.1062
INFO - 2024-02-20 15:37:19 --> Config Class Initialized
INFO - 2024-02-20 15:37:19 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:19 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:19 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:19 --> URI Class Initialized
INFO - 2024-02-20 15:37:19 --> Router Class Initialized
INFO - 2024-02-20 15:37:19 --> Output Class Initialized
INFO - 2024-02-20 15:37:19 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:19 --> Input Class Initialized
INFO - 2024-02-20 15:37:19 --> Language Class Initialized
INFO - 2024-02-20 15:37:19 --> Language Class Initialized
INFO - 2024-02-20 15:37:19 --> Config Class Initialized
INFO - 2024-02-20 15:37:19 --> Loader Class Initialized
INFO - 2024-02-20 15:37:19 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:19 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:19 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:19 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:19 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:19 --> Controller Class Initialized
INFO - 2024-02-20 15:37:19 --> Helper loaded: cookie_helper
INFO - 2024-02-20 15:37:19 --> Config Class Initialized
INFO - 2024-02-20 15:37:19 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:19 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:19 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:19 --> URI Class Initialized
INFO - 2024-02-20 15:37:19 --> Router Class Initialized
INFO - 2024-02-20 15:37:19 --> Output Class Initialized
INFO - 2024-02-20 15:37:19 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:19 --> Input Class Initialized
INFO - 2024-02-20 15:37:19 --> Language Class Initialized
INFO - 2024-02-20 15:37:19 --> Language Class Initialized
INFO - 2024-02-20 15:37:19 --> Config Class Initialized
INFO - 2024-02-20 15:37:19 --> Loader Class Initialized
INFO - 2024-02-20 15:37:19 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:19 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:19 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:19 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:19 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:19 --> Controller Class Initialized
DEBUG - 2024-02-20 15:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-20 15:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-20 15:37:19 --> Final output sent to browser
DEBUG - 2024-02-20 15:37:19 --> Total execution time: 0.1033
INFO - 2024-02-20 15:37:22 --> Config Class Initialized
INFO - 2024-02-20 15:37:22 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:22 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:22 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:22 --> URI Class Initialized
INFO - 2024-02-20 15:37:22 --> Router Class Initialized
INFO - 2024-02-20 15:37:22 --> Output Class Initialized
INFO - 2024-02-20 15:37:22 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:22 --> Input Class Initialized
INFO - 2024-02-20 15:37:22 --> Language Class Initialized
INFO - 2024-02-20 15:37:22 --> Language Class Initialized
INFO - 2024-02-20 15:37:22 --> Config Class Initialized
INFO - 2024-02-20 15:37:22 --> Loader Class Initialized
INFO - 2024-02-20 15:37:22 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:22 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:22 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:22 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:22 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:22 --> Controller Class Initialized
INFO - 2024-02-20 15:37:22 --> Helper loaded: cookie_helper
INFO - 2024-02-20 15:37:22 --> Final output sent to browser
DEBUG - 2024-02-20 15:37:22 --> Total execution time: 0.0447
INFO - 2024-02-20 15:37:22 --> Config Class Initialized
INFO - 2024-02-20 15:37:22 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:22 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:22 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:22 --> URI Class Initialized
INFO - 2024-02-20 15:37:22 --> Router Class Initialized
INFO - 2024-02-20 15:37:22 --> Output Class Initialized
INFO - 2024-02-20 15:37:22 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:22 --> Input Class Initialized
INFO - 2024-02-20 15:37:22 --> Language Class Initialized
INFO - 2024-02-20 15:37:23 --> Language Class Initialized
INFO - 2024-02-20 15:37:23 --> Config Class Initialized
INFO - 2024-02-20 15:37:23 --> Loader Class Initialized
INFO - 2024-02-20 15:37:23 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:23 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:23 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:23 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:23 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:23 --> Controller Class Initialized
INFO - 2024-02-20 15:37:23 --> Helper loaded: cookie_helper
INFO - 2024-02-20 15:37:23 --> Config Class Initialized
INFO - 2024-02-20 15:37:23 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:23 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:23 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:23 --> URI Class Initialized
INFO - 2024-02-20 15:37:23 --> Router Class Initialized
INFO - 2024-02-20 15:37:23 --> Output Class Initialized
INFO - 2024-02-20 15:37:23 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:23 --> Input Class Initialized
INFO - 2024-02-20 15:37:23 --> Language Class Initialized
INFO - 2024-02-20 15:37:23 --> Language Class Initialized
INFO - 2024-02-20 15:37:23 --> Config Class Initialized
INFO - 2024-02-20 15:37:23 --> Loader Class Initialized
INFO - 2024-02-20 15:37:23 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:23 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:23 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:23 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:23 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:23 --> Controller Class Initialized
DEBUG - 2024-02-20 15:37:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-20 15:37:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-20 15:37:23 --> Final output sent to browser
DEBUG - 2024-02-20 15:37:23 --> Total execution time: 0.0585
INFO - 2024-02-20 15:37:28 --> Config Class Initialized
INFO - 2024-02-20 15:37:28 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:28 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:28 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:28 --> URI Class Initialized
INFO - 2024-02-20 15:37:28 --> Router Class Initialized
INFO - 2024-02-20 15:37:28 --> Output Class Initialized
INFO - 2024-02-20 15:37:28 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:28 --> Input Class Initialized
INFO - 2024-02-20 15:37:28 --> Language Class Initialized
INFO - 2024-02-20 15:37:28 --> Language Class Initialized
INFO - 2024-02-20 15:37:28 --> Config Class Initialized
INFO - 2024-02-20 15:37:28 --> Loader Class Initialized
INFO - 2024-02-20 15:37:28 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:28 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:28 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:28 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:28 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:28 --> Controller Class Initialized
DEBUG - 2024-02-20 15:37:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-02-20 15:37:34 --> Final output sent to browser
DEBUG - 2024-02-20 15:37:34 --> Total execution time: 6.4870
INFO - 2024-02-20 15:37:38 --> Config Class Initialized
INFO - 2024-02-20 15:37:38 --> Hooks Class Initialized
DEBUG - 2024-02-20 15:37:38 --> UTF-8 Support Enabled
INFO - 2024-02-20 15:37:38 --> Utf8 Class Initialized
INFO - 2024-02-20 15:37:38 --> URI Class Initialized
INFO - 2024-02-20 15:37:38 --> Router Class Initialized
INFO - 2024-02-20 15:37:38 --> Output Class Initialized
INFO - 2024-02-20 15:37:38 --> Security Class Initialized
DEBUG - 2024-02-20 15:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-20 15:37:38 --> Input Class Initialized
INFO - 2024-02-20 15:37:38 --> Language Class Initialized
INFO - 2024-02-20 15:37:38 --> Language Class Initialized
INFO - 2024-02-20 15:37:38 --> Config Class Initialized
INFO - 2024-02-20 15:37:38 --> Loader Class Initialized
INFO - 2024-02-20 15:37:38 --> Helper loaded: url_helper
INFO - 2024-02-20 15:37:38 --> Helper loaded: file_helper
INFO - 2024-02-20 15:37:38 --> Helper loaded: form_helper
INFO - 2024-02-20 15:37:38 --> Helper loaded: my_helper
INFO - 2024-02-20 15:37:38 --> Database Driver Class Initialized
INFO - 2024-02-20 15:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-20 15:37:38 --> Controller Class Initialized
DEBUG - 2024-02-20 15:37:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-02-20 15:37:44 --> Final output sent to browser
DEBUG - 2024-02-20 15:37:44 --> Total execution time: 5.9633
