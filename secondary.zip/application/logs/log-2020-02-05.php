<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-05 01:32:48 --> Config Class Initialized
INFO - 2020-02-05 01:32:48 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:32:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:32:49 --> Utf8 Class Initialized
INFO - 2020-02-05 01:32:49 --> URI Class Initialized
DEBUG - 2020-02-05 01:32:49 --> No URI present. Default controller set.
INFO - 2020-02-05 01:32:49 --> Router Class Initialized
INFO - 2020-02-05 01:32:49 --> Output Class Initialized
INFO - 2020-02-05 01:32:49 --> Security Class Initialized
DEBUG - 2020-02-05 01:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:32:49 --> Input Class Initialized
INFO - 2020-02-05 01:32:49 --> Language Class Initialized
INFO - 2020-02-05 01:32:49 --> Language Class Initialized
INFO - 2020-02-05 01:32:49 --> Config Class Initialized
INFO - 2020-02-05 01:32:49 --> Loader Class Initialized
INFO - 2020-02-05 01:32:49 --> Helper loaded: url_helper
INFO - 2020-02-05 01:32:49 --> Helper loaded: file_helper
INFO - 2020-02-05 01:32:49 --> Helper loaded: form_helper
INFO - 2020-02-05 01:32:49 --> Helper loaded: my_helper
INFO - 2020-02-05 01:32:49 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:32:49 --> Controller Class Initialized
INFO - 2020-02-05 01:32:49 --> Config Class Initialized
INFO - 2020-02-05 01:32:49 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:32:49 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:32:49 --> Utf8 Class Initialized
INFO - 2020-02-05 01:32:49 --> URI Class Initialized
INFO - 2020-02-05 01:32:49 --> Router Class Initialized
INFO - 2020-02-05 01:32:49 --> Output Class Initialized
INFO - 2020-02-05 01:32:49 --> Security Class Initialized
DEBUG - 2020-02-05 01:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:32:49 --> Input Class Initialized
INFO - 2020-02-05 01:32:49 --> Language Class Initialized
INFO - 2020-02-05 01:32:49 --> Language Class Initialized
INFO - 2020-02-05 01:32:49 --> Config Class Initialized
INFO - 2020-02-05 01:32:49 --> Loader Class Initialized
INFO - 2020-02-05 01:32:49 --> Helper loaded: url_helper
INFO - 2020-02-05 01:32:49 --> Helper loaded: file_helper
INFO - 2020-02-05 01:32:49 --> Helper loaded: form_helper
INFO - 2020-02-05 01:32:49 --> Helper loaded: my_helper
INFO - 2020-02-05 01:32:49 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:32:49 --> Controller Class Initialized
DEBUG - 2020-02-05 01:32:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-05 01:32:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-05 01:32:50 --> Final output sent to browser
DEBUG - 2020-02-05 01:32:50 --> Total execution time: 0.3005
INFO - 2020-02-05 01:33:02 --> Config Class Initialized
INFO - 2020-02-05 01:33:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:33:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:33:02 --> Utf8 Class Initialized
INFO - 2020-02-05 01:33:02 --> URI Class Initialized
INFO - 2020-02-05 01:33:02 --> Router Class Initialized
INFO - 2020-02-05 01:33:02 --> Output Class Initialized
INFO - 2020-02-05 01:33:02 --> Security Class Initialized
DEBUG - 2020-02-05 01:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:33:02 --> Input Class Initialized
INFO - 2020-02-05 01:33:02 --> Language Class Initialized
INFO - 2020-02-05 01:33:02 --> Language Class Initialized
INFO - 2020-02-05 01:33:02 --> Config Class Initialized
INFO - 2020-02-05 01:33:02 --> Loader Class Initialized
INFO - 2020-02-05 01:33:02 --> Helper loaded: url_helper
INFO - 2020-02-05 01:33:02 --> Helper loaded: file_helper
INFO - 2020-02-05 01:33:02 --> Helper loaded: form_helper
INFO - 2020-02-05 01:33:02 --> Helper loaded: my_helper
INFO - 2020-02-05 01:33:02 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:33:02 --> Controller Class Initialized
INFO - 2020-02-05 01:33:02 --> Helper loaded: cookie_helper
INFO - 2020-02-05 01:33:02 --> Final output sent to browser
DEBUG - 2020-02-05 01:33:02 --> Total execution time: 0.3638
INFO - 2020-02-05 01:33:02 --> Config Class Initialized
INFO - 2020-02-05 01:33:02 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:33:02 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:33:02 --> Utf8 Class Initialized
INFO - 2020-02-05 01:33:02 --> URI Class Initialized
INFO - 2020-02-05 01:33:02 --> Router Class Initialized
INFO - 2020-02-05 01:33:02 --> Output Class Initialized
INFO - 2020-02-05 01:33:02 --> Security Class Initialized
DEBUG - 2020-02-05 01:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:33:02 --> Input Class Initialized
INFO - 2020-02-05 01:33:02 --> Language Class Initialized
INFO - 2020-02-05 01:33:02 --> Language Class Initialized
INFO - 2020-02-05 01:33:02 --> Config Class Initialized
INFO - 2020-02-05 01:33:02 --> Loader Class Initialized
INFO - 2020-02-05 01:33:02 --> Helper loaded: url_helper
INFO - 2020-02-05 01:33:02 --> Helper loaded: file_helper
INFO - 2020-02-05 01:33:02 --> Helper loaded: form_helper
INFO - 2020-02-05 01:33:02 --> Helper loaded: my_helper
INFO - 2020-02-05 01:33:02 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:33:02 --> Controller Class Initialized
DEBUG - 2020-02-05 01:33:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-05 01:33:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-05 01:33:02 --> Final output sent to browser
DEBUG - 2020-02-05 01:33:02 --> Total execution time: 0.4287
INFO - 2020-02-05 01:33:29 --> Config Class Initialized
INFO - 2020-02-05 01:33:29 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:33:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:33:29 --> Utf8 Class Initialized
INFO - 2020-02-05 01:33:29 --> URI Class Initialized
INFO - 2020-02-05 01:33:29 --> Router Class Initialized
INFO - 2020-02-05 01:33:29 --> Output Class Initialized
INFO - 2020-02-05 01:33:29 --> Security Class Initialized
DEBUG - 2020-02-05 01:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:33:29 --> Input Class Initialized
INFO - 2020-02-05 01:33:29 --> Language Class Initialized
INFO - 2020-02-05 01:33:29 --> Language Class Initialized
INFO - 2020-02-05 01:33:29 --> Config Class Initialized
INFO - 2020-02-05 01:33:29 --> Loader Class Initialized
INFO - 2020-02-05 01:33:29 --> Helper loaded: url_helper
INFO - 2020-02-05 01:33:29 --> Helper loaded: file_helper
INFO - 2020-02-05 01:33:29 --> Helper loaded: form_helper
INFO - 2020-02-05 01:33:29 --> Helper loaded: my_helper
INFO - 2020-02-05 01:33:29 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:33:29 --> Controller Class Initialized
DEBUG - 2020-02-05 01:33:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-02-05 01:33:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-05 01:33:29 --> Final output sent to browser
DEBUG - 2020-02-05 01:33:29 --> Total execution time: 0.2954
INFO - 2020-02-05 01:33:31 --> Config Class Initialized
INFO - 2020-02-05 01:33:31 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:33:31 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:33:31 --> Utf8 Class Initialized
INFO - 2020-02-05 01:33:31 --> URI Class Initialized
INFO - 2020-02-05 01:33:31 --> Router Class Initialized
INFO - 2020-02-05 01:33:31 --> Output Class Initialized
INFO - 2020-02-05 01:33:31 --> Security Class Initialized
DEBUG - 2020-02-05 01:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:33:31 --> Input Class Initialized
INFO - 2020-02-05 01:33:31 --> Language Class Initialized
INFO - 2020-02-05 01:33:31 --> Language Class Initialized
INFO - 2020-02-05 01:33:31 --> Config Class Initialized
INFO - 2020-02-05 01:33:31 --> Loader Class Initialized
INFO - 2020-02-05 01:33:31 --> Helper loaded: url_helper
INFO - 2020-02-05 01:33:31 --> Helper loaded: file_helper
INFO - 2020-02-05 01:33:31 --> Helper loaded: form_helper
INFO - 2020-02-05 01:33:31 --> Helper loaded: my_helper
INFO - 2020-02-05 01:33:31 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:33:31 --> Controller Class Initialized
DEBUG - 2020-02-05 01:33:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-05 01:33:31 --> Final output sent to browser
DEBUG - 2020-02-05 01:33:31 --> Total execution time: 0.3918
INFO - 2020-02-05 01:35:25 --> Config Class Initialized
INFO - 2020-02-05 01:35:25 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:35:25 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:35:25 --> Utf8 Class Initialized
INFO - 2020-02-05 01:35:25 --> URI Class Initialized
INFO - 2020-02-05 01:35:25 --> Router Class Initialized
INFO - 2020-02-05 01:35:25 --> Output Class Initialized
INFO - 2020-02-05 01:35:25 --> Security Class Initialized
DEBUG - 2020-02-05 01:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:35:25 --> Input Class Initialized
INFO - 2020-02-05 01:35:25 --> Language Class Initialized
INFO - 2020-02-05 01:35:25 --> Language Class Initialized
INFO - 2020-02-05 01:35:25 --> Config Class Initialized
INFO - 2020-02-05 01:35:25 --> Loader Class Initialized
INFO - 2020-02-05 01:35:25 --> Helper loaded: url_helper
INFO - 2020-02-05 01:35:25 --> Helper loaded: file_helper
INFO - 2020-02-05 01:35:25 --> Helper loaded: form_helper
INFO - 2020-02-05 01:35:25 --> Helper loaded: my_helper
INFO - 2020-02-05 01:35:25 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:35:26 --> Controller Class Initialized
DEBUG - 2020-02-05 01:35:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-05 01:35:26 --> Final output sent to browser
DEBUG - 2020-02-05 01:35:26 --> Total execution time: 0.2984
INFO - 2020-02-05 01:35:26 --> Config Class Initialized
INFO - 2020-02-05 01:35:26 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:35:26 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:35:26 --> Utf8 Class Initialized
INFO - 2020-02-05 01:35:26 --> URI Class Initialized
INFO - 2020-02-05 01:35:26 --> Router Class Initialized
INFO - 2020-02-05 01:35:26 --> Output Class Initialized
INFO - 2020-02-05 01:35:26 --> Security Class Initialized
DEBUG - 2020-02-05 01:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:35:26 --> Input Class Initialized
INFO - 2020-02-05 01:35:26 --> Language Class Initialized
ERROR - 2020-02-05 01:35:26 --> 404 Page Not Found: /index
INFO - 2020-02-05 01:35:42 --> Config Class Initialized
INFO - 2020-02-05 01:35:42 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:35:42 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:35:42 --> Utf8 Class Initialized
INFO - 2020-02-05 01:35:42 --> URI Class Initialized
INFO - 2020-02-05 01:35:42 --> Router Class Initialized
INFO - 2020-02-05 01:35:42 --> Output Class Initialized
INFO - 2020-02-05 01:35:42 --> Security Class Initialized
DEBUG - 2020-02-05 01:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:35:42 --> Input Class Initialized
INFO - 2020-02-05 01:35:42 --> Language Class Initialized
INFO - 2020-02-05 01:35:42 --> Language Class Initialized
INFO - 2020-02-05 01:35:42 --> Config Class Initialized
INFO - 2020-02-05 01:35:42 --> Loader Class Initialized
INFO - 2020-02-05 01:35:42 --> Helper loaded: url_helper
INFO - 2020-02-05 01:35:42 --> Helper loaded: file_helper
INFO - 2020-02-05 01:35:42 --> Helper loaded: form_helper
INFO - 2020-02-05 01:35:42 --> Helper loaded: my_helper
INFO - 2020-02-05 01:35:42 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:35:42 --> Controller Class Initialized
DEBUG - 2020-02-05 01:35:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-05 01:35:42 --> Final output sent to browser
DEBUG - 2020-02-05 01:35:42 --> Total execution time: 0.3042
INFO - 2020-02-05 01:37:29 --> Config Class Initialized
INFO - 2020-02-05 01:37:29 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:37:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:37:29 --> Utf8 Class Initialized
INFO - 2020-02-05 01:37:29 --> URI Class Initialized
INFO - 2020-02-05 01:37:29 --> Router Class Initialized
INFO - 2020-02-05 01:37:29 --> Output Class Initialized
INFO - 2020-02-05 01:37:29 --> Security Class Initialized
DEBUG - 2020-02-05 01:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:37:29 --> Input Class Initialized
INFO - 2020-02-05 01:37:29 --> Language Class Initialized
INFO - 2020-02-05 01:37:29 --> Language Class Initialized
INFO - 2020-02-05 01:37:29 --> Config Class Initialized
INFO - 2020-02-05 01:37:29 --> Loader Class Initialized
INFO - 2020-02-05 01:37:29 --> Helper loaded: url_helper
INFO - 2020-02-05 01:37:29 --> Helper loaded: file_helper
INFO - 2020-02-05 01:37:29 --> Helper loaded: form_helper
INFO - 2020-02-05 01:37:29 --> Helper loaded: my_helper
INFO - 2020-02-05 01:37:29 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:37:29 --> Controller Class Initialized
DEBUG - 2020-02-05 01:37:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-05 01:37:29 --> Final output sent to browser
DEBUG - 2020-02-05 01:37:29 --> Total execution time: 0.2665
INFO - 2020-02-05 01:38:25 --> Config Class Initialized
INFO - 2020-02-05 01:38:25 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:38:25 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:38:25 --> Utf8 Class Initialized
INFO - 2020-02-05 01:38:25 --> URI Class Initialized
INFO - 2020-02-05 01:38:25 --> Router Class Initialized
INFO - 2020-02-05 01:38:25 --> Output Class Initialized
INFO - 2020-02-05 01:38:25 --> Security Class Initialized
DEBUG - 2020-02-05 01:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:38:25 --> Input Class Initialized
INFO - 2020-02-05 01:38:25 --> Language Class Initialized
INFO - 2020-02-05 01:38:25 --> Language Class Initialized
INFO - 2020-02-05 01:38:25 --> Config Class Initialized
INFO - 2020-02-05 01:38:25 --> Loader Class Initialized
INFO - 2020-02-05 01:38:25 --> Helper loaded: url_helper
INFO - 2020-02-05 01:38:25 --> Helper loaded: file_helper
INFO - 2020-02-05 01:38:25 --> Helper loaded: form_helper
INFO - 2020-02-05 01:38:25 --> Helper loaded: my_helper
INFO - 2020-02-05 01:38:25 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:38:25 --> Controller Class Initialized
DEBUG - 2020-02-05 01:38:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-02-05 01:38:25 --> Final output sent to browser
DEBUG - 2020-02-05 01:38:25 --> Total execution time: 0.3620
INFO - 2020-02-05 01:38:28 --> Config Class Initialized
INFO - 2020-02-05 01:38:28 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:38:28 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:38:28 --> Utf8 Class Initialized
INFO - 2020-02-05 01:38:28 --> URI Class Initialized
INFO - 2020-02-05 01:38:28 --> Router Class Initialized
INFO - 2020-02-05 01:38:28 --> Output Class Initialized
INFO - 2020-02-05 01:38:28 --> Security Class Initialized
DEBUG - 2020-02-05 01:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:38:28 --> Input Class Initialized
INFO - 2020-02-05 01:38:28 --> Language Class Initialized
INFO - 2020-02-05 01:38:28 --> Language Class Initialized
INFO - 2020-02-05 01:38:28 --> Config Class Initialized
INFO - 2020-02-05 01:38:28 --> Loader Class Initialized
INFO - 2020-02-05 01:38:28 --> Helper loaded: url_helper
INFO - 2020-02-05 01:38:28 --> Helper loaded: file_helper
INFO - 2020-02-05 01:38:28 --> Helper loaded: form_helper
INFO - 2020-02-05 01:38:28 --> Helper loaded: my_helper
INFO - 2020-02-05 01:38:28 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:38:28 --> Controller Class Initialized
DEBUG - 2020-02-05 01:38:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:38:28 --> Final output sent to browser
DEBUG - 2020-02-05 01:38:28 --> Total execution time: 0.4136
INFO - 2020-02-05 01:41:08 --> Config Class Initialized
INFO - 2020-02-05 01:41:08 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:41:08 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:41:08 --> Utf8 Class Initialized
INFO - 2020-02-05 01:41:08 --> URI Class Initialized
INFO - 2020-02-05 01:41:08 --> Router Class Initialized
INFO - 2020-02-05 01:41:08 --> Output Class Initialized
INFO - 2020-02-05 01:41:08 --> Security Class Initialized
DEBUG - 2020-02-05 01:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:41:08 --> Input Class Initialized
INFO - 2020-02-05 01:41:08 --> Language Class Initialized
INFO - 2020-02-05 01:41:08 --> Language Class Initialized
INFO - 2020-02-05 01:41:08 --> Config Class Initialized
INFO - 2020-02-05 01:41:08 --> Loader Class Initialized
INFO - 2020-02-05 01:41:08 --> Helper loaded: url_helper
INFO - 2020-02-05 01:41:08 --> Helper loaded: file_helper
INFO - 2020-02-05 01:41:08 --> Helper loaded: form_helper
INFO - 2020-02-05 01:41:08 --> Helper loaded: my_helper
INFO - 2020-02-05 01:41:08 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:41:08 --> Controller Class Initialized
DEBUG - 2020-02-05 01:41:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-05 01:41:08 --> Final output sent to browser
DEBUG - 2020-02-05 01:41:08 --> Total execution time: 0.2790
INFO - 2020-02-05 01:41:54 --> Config Class Initialized
INFO - 2020-02-05 01:41:54 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:41:54 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:41:54 --> Utf8 Class Initialized
INFO - 2020-02-05 01:41:54 --> URI Class Initialized
INFO - 2020-02-05 01:41:54 --> Router Class Initialized
INFO - 2020-02-05 01:41:54 --> Output Class Initialized
INFO - 2020-02-05 01:41:54 --> Security Class Initialized
DEBUG - 2020-02-05 01:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:41:54 --> Input Class Initialized
INFO - 2020-02-05 01:41:54 --> Language Class Initialized
INFO - 2020-02-05 01:41:54 --> Language Class Initialized
INFO - 2020-02-05 01:41:54 --> Config Class Initialized
INFO - 2020-02-05 01:41:54 --> Loader Class Initialized
INFO - 2020-02-05 01:41:54 --> Helper loaded: url_helper
INFO - 2020-02-05 01:41:54 --> Helper loaded: file_helper
INFO - 2020-02-05 01:41:54 --> Helper loaded: form_helper
INFO - 2020-02-05 01:41:54 --> Helper loaded: my_helper
INFO - 2020-02-05 01:41:54 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:41:54 --> Controller Class Initialized
DEBUG - 2020-02-05 01:41:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:41:54 --> Final output sent to browser
DEBUG - 2020-02-05 01:41:54 --> Total execution time: 0.2901
INFO - 2020-02-05 01:42:23 --> Config Class Initialized
INFO - 2020-02-05 01:42:23 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:42:23 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:42:23 --> Utf8 Class Initialized
INFO - 2020-02-05 01:42:23 --> URI Class Initialized
INFO - 2020-02-05 01:42:23 --> Router Class Initialized
INFO - 2020-02-05 01:42:23 --> Output Class Initialized
INFO - 2020-02-05 01:42:23 --> Security Class Initialized
DEBUG - 2020-02-05 01:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:42:23 --> Input Class Initialized
INFO - 2020-02-05 01:42:24 --> Language Class Initialized
INFO - 2020-02-05 01:42:24 --> Language Class Initialized
INFO - 2020-02-05 01:42:24 --> Config Class Initialized
INFO - 2020-02-05 01:42:24 --> Loader Class Initialized
INFO - 2020-02-05 01:42:24 --> Helper loaded: url_helper
INFO - 2020-02-05 01:42:24 --> Helper loaded: file_helper
INFO - 2020-02-05 01:42:24 --> Helper loaded: form_helper
INFO - 2020-02-05 01:42:24 --> Helper loaded: my_helper
INFO - 2020-02-05 01:42:24 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:42:24 --> Controller Class Initialized
DEBUG - 2020-02-05 01:42:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:42:24 --> Final output sent to browser
DEBUG - 2020-02-05 01:42:24 --> Total execution time: 0.2897
INFO - 2020-02-05 01:43:11 --> Config Class Initialized
INFO - 2020-02-05 01:43:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:43:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:43:11 --> Utf8 Class Initialized
INFO - 2020-02-05 01:43:11 --> URI Class Initialized
INFO - 2020-02-05 01:43:11 --> Router Class Initialized
INFO - 2020-02-05 01:43:11 --> Output Class Initialized
INFO - 2020-02-05 01:43:11 --> Security Class Initialized
DEBUG - 2020-02-05 01:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:43:11 --> Input Class Initialized
INFO - 2020-02-05 01:43:11 --> Language Class Initialized
INFO - 2020-02-05 01:43:11 --> Language Class Initialized
INFO - 2020-02-05 01:43:11 --> Config Class Initialized
INFO - 2020-02-05 01:43:11 --> Loader Class Initialized
INFO - 2020-02-05 01:43:11 --> Helper loaded: url_helper
INFO - 2020-02-05 01:43:11 --> Helper loaded: file_helper
INFO - 2020-02-05 01:43:11 --> Helper loaded: form_helper
INFO - 2020-02-05 01:43:11 --> Helper loaded: my_helper
INFO - 2020-02-05 01:43:11 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:43:11 --> Controller Class Initialized
DEBUG - 2020-02-05 01:43:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:43:11 --> Final output sent to browser
DEBUG - 2020-02-05 01:43:11 --> Total execution time: 0.2912
INFO - 2020-02-05 01:43:29 --> Config Class Initialized
INFO - 2020-02-05 01:43:29 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:43:29 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:43:29 --> Utf8 Class Initialized
INFO - 2020-02-05 01:43:29 --> URI Class Initialized
INFO - 2020-02-05 01:43:29 --> Router Class Initialized
INFO - 2020-02-05 01:43:29 --> Output Class Initialized
INFO - 2020-02-05 01:43:29 --> Security Class Initialized
DEBUG - 2020-02-05 01:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:43:29 --> Input Class Initialized
INFO - 2020-02-05 01:43:29 --> Language Class Initialized
INFO - 2020-02-05 01:43:29 --> Language Class Initialized
INFO - 2020-02-05 01:43:29 --> Config Class Initialized
INFO - 2020-02-05 01:43:29 --> Loader Class Initialized
INFO - 2020-02-05 01:43:29 --> Helper loaded: url_helper
INFO - 2020-02-05 01:43:29 --> Helper loaded: file_helper
INFO - 2020-02-05 01:43:29 --> Helper loaded: form_helper
INFO - 2020-02-05 01:43:29 --> Helper loaded: my_helper
INFO - 2020-02-05 01:43:29 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:43:29 --> Controller Class Initialized
DEBUG - 2020-02-05 01:43:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:43:29 --> Final output sent to browser
DEBUG - 2020-02-05 01:43:29 --> Total execution time: 0.3287
INFO - 2020-02-05 01:43:39 --> Config Class Initialized
INFO - 2020-02-05 01:43:39 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:43:39 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:43:39 --> Utf8 Class Initialized
INFO - 2020-02-05 01:43:39 --> URI Class Initialized
INFO - 2020-02-05 01:43:39 --> Router Class Initialized
INFO - 2020-02-05 01:43:39 --> Output Class Initialized
INFO - 2020-02-05 01:43:39 --> Security Class Initialized
DEBUG - 2020-02-05 01:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:43:40 --> Input Class Initialized
INFO - 2020-02-05 01:43:40 --> Language Class Initialized
INFO - 2020-02-05 01:43:40 --> Language Class Initialized
INFO - 2020-02-05 01:43:40 --> Config Class Initialized
INFO - 2020-02-05 01:43:40 --> Loader Class Initialized
INFO - 2020-02-05 01:43:40 --> Helper loaded: url_helper
INFO - 2020-02-05 01:43:40 --> Helper loaded: file_helper
INFO - 2020-02-05 01:43:40 --> Helper loaded: form_helper
INFO - 2020-02-05 01:43:40 --> Helper loaded: my_helper
INFO - 2020-02-05 01:43:40 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:43:40 --> Controller Class Initialized
DEBUG - 2020-02-05 01:43:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:43:40 --> Final output sent to browser
DEBUG - 2020-02-05 01:43:40 --> Total execution time: 0.3013
INFO - 2020-02-05 01:43:53 --> Config Class Initialized
INFO - 2020-02-05 01:43:53 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:43:53 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:43:53 --> Utf8 Class Initialized
INFO - 2020-02-05 01:43:53 --> URI Class Initialized
INFO - 2020-02-05 01:43:53 --> Router Class Initialized
INFO - 2020-02-05 01:43:53 --> Output Class Initialized
INFO - 2020-02-05 01:43:53 --> Security Class Initialized
DEBUG - 2020-02-05 01:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:43:54 --> Input Class Initialized
INFO - 2020-02-05 01:43:54 --> Language Class Initialized
INFO - 2020-02-05 01:43:54 --> Language Class Initialized
INFO - 2020-02-05 01:43:54 --> Config Class Initialized
INFO - 2020-02-05 01:43:54 --> Loader Class Initialized
INFO - 2020-02-05 01:43:54 --> Helper loaded: url_helper
INFO - 2020-02-05 01:43:54 --> Helper loaded: file_helper
INFO - 2020-02-05 01:43:54 --> Helper loaded: form_helper
INFO - 2020-02-05 01:43:54 --> Helper loaded: my_helper
INFO - 2020-02-05 01:43:54 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:43:54 --> Controller Class Initialized
DEBUG - 2020-02-05 01:43:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:43:54 --> Final output sent to browser
DEBUG - 2020-02-05 01:43:54 --> Total execution time: 0.3001
INFO - 2020-02-05 01:43:59 --> Config Class Initialized
INFO - 2020-02-05 01:43:59 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:43:59 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:43:59 --> Utf8 Class Initialized
INFO - 2020-02-05 01:43:59 --> URI Class Initialized
INFO - 2020-02-05 01:43:59 --> Router Class Initialized
INFO - 2020-02-05 01:43:59 --> Output Class Initialized
INFO - 2020-02-05 01:43:59 --> Security Class Initialized
DEBUG - 2020-02-05 01:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:43:59 --> Input Class Initialized
INFO - 2020-02-05 01:43:59 --> Language Class Initialized
INFO - 2020-02-05 01:43:59 --> Language Class Initialized
INFO - 2020-02-05 01:43:59 --> Config Class Initialized
INFO - 2020-02-05 01:43:59 --> Loader Class Initialized
INFO - 2020-02-05 01:43:59 --> Helper loaded: url_helper
INFO - 2020-02-05 01:43:59 --> Helper loaded: file_helper
INFO - 2020-02-05 01:43:59 --> Helper loaded: form_helper
INFO - 2020-02-05 01:43:59 --> Helper loaded: my_helper
INFO - 2020-02-05 01:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:43:59 --> Controller Class Initialized
DEBUG - 2020-02-05 01:43:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:43:59 --> Final output sent to browser
DEBUG - 2020-02-05 01:43:59 --> Total execution time: 0.2967
INFO - 2020-02-05 01:44:55 --> Config Class Initialized
INFO - 2020-02-05 01:44:55 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:44:55 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:44:55 --> Utf8 Class Initialized
INFO - 2020-02-05 01:44:55 --> URI Class Initialized
INFO - 2020-02-05 01:44:55 --> Router Class Initialized
INFO - 2020-02-05 01:44:55 --> Output Class Initialized
INFO - 2020-02-05 01:44:55 --> Security Class Initialized
DEBUG - 2020-02-05 01:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:44:55 --> Input Class Initialized
INFO - 2020-02-05 01:44:55 --> Language Class Initialized
INFO - 2020-02-05 01:44:55 --> Language Class Initialized
INFO - 2020-02-05 01:44:55 --> Config Class Initialized
INFO - 2020-02-05 01:44:55 --> Loader Class Initialized
INFO - 2020-02-05 01:44:55 --> Helper loaded: url_helper
INFO - 2020-02-05 01:44:55 --> Helper loaded: file_helper
INFO - 2020-02-05 01:44:55 --> Helper loaded: form_helper
INFO - 2020-02-05 01:44:55 --> Helper loaded: my_helper
INFO - 2020-02-05 01:44:55 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:44:55 --> Controller Class Initialized
DEBUG - 2020-02-05 01:44:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:44:56 --> Final output sent to browser
DEBUG - 2020-02-05 01:44:56 --> Total execution time: 0.2989
INFO - 2020-02-05 01:46:06 --> Config Class Initialized
INFO - 2020-02-05 01:46:06 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:46:06 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:46:06 --> Utf8 Class Initialized
INFO - 2020-02-05 01:46:06 --> URI Class Initialized
INFO - 2020-02-05 01:46:06 --> Router Class Initialized
INFO - 2020-02-05 01:46:06 --> Output Class Initialized
INFO - 2020-02-05 01:46:06 --> Security Class Initialized
DEBUG - 2020-02-05 01:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:46:06 --> Input Class Initialized
INFO - 2020-02-05 01:46:06 --> Language Class Initialized
INFO - 2020-02-05 01:46:06 --> Language Class Initialized
INFO - 2020-02-05 01:46:06 --> Config Class Initialized
INFO - 2020-02-05 01:46:06 --> Loader Class Initialized
INFO - 2020-02-05 01:46:06 --> Helper loaded: url_helper
INFO - 2020-02-05 01:46:06 --> Helper loaded: file_helper
INFO - 2020-02-05 01:46:06 --> Helper loaded: form_helper
INFO - 2020-02-05 01:46:06 --> Helper loaded: my_helper
INFO - 2020-02-05 01:46:06 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:46:06 --> Controller Class Initialized
DEBUG - 2020-02-05 01:46:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-05 01:46:06 --> Final output sent to browser
DEBUG - 2020-02-05 01:46:06 --> Total execution time: 0.3547
INFO - 2020-02-05 01:46:11 --> Config Class Initialized
INFO - 2020-02-05 01:46:11 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:46:11 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:46:11 --> Utf8 Class Initialized
INFO - 2020-02-05 01:46:11 --> URI Class Initialized
INFO - 2020-02-05 01:46:11 --> Router Class Initialized
INFO - 2020-02-05 01:46:11 --> Output Class Initialized
INFO - 2020-02-05 01:46:11 --> Security Class Initialized
DEBUG - 2020-02-05 01:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:46:11 --> Input Class Initialized
INFO - 2020-02-05 01:46:11 --> Language Class Initialized
INFO - 2020-02-05 01:46:11 --> Language Class Initialized
INFO - 2020-02-05 01:46:11 --> Config Class Initialized
INFO - 2020-02-05 01:46:11 --> Loader Class Initialized
INFO - 2020-02-05 01:46:11 --> Helper loaded: url_helper
INFO - 2020-02-05 01:46:11 --> Helper loaded: file_helper
INFO - 2020-02-05 01:46:11 --> Helper loaded: form_helper
INFO - 2020-02-05 01:46:11 --> Helper loaded: my_helper
INFO - 2020-02-05 01:46:11 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:46:11 --> Controller Class Initialized
DEBUG - 2020-02-05 01:46:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-02-05 01:46:11 --> Final output sent to browser
DEBUG - 2020-02-05 01:46:11 --> Total execution time: 0.3258
INFO - 2020-02-05 01:46:14 --> Config Class Initialized
INFO - 2020-02-05 01:46:14 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:46:14 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:46:14 --> Utf8 Class Initialized
INFO - 2020-02-05 01:46:14 --> URI Class Initialized
INFO - 2020-02-05 01:46:14 --> Router Class Initialized
INFO - 2020-02-05 01:46:14 --> Output Class Initialized
INFO - 2020-02-05 01:46:14 --> Security Class Initialized
DEBUG - 2020-02-05 01:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:46:14 --> Input Class Initialized
INFO - 2020-02-05 01:46:14 --> Language Class Initialized
INFO - 2020-02-05 01:46:14 --> Language Class Initialized
INFO - 2020-02-05 01:46:14 --> Config Class Initialized
INFO - 2020-02-05 01:46:14 --> Loader Class Initialized
INFO - 2020-02-05 01:46:14 --> Helper loaded: url_helper
INFO - 2020-02-05 01:46:14 --> Helper loaded: file_helper
INFO - 2020-02-05 01:46:14 --> Helper loaded: form_helper
INFO - 2020-02-05 01:46:14 --> Helper loaded: my_helper
INFO - 2020-02-05 01:46:14 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:46:14 --> Controller Class Initialized
DEBUG - 2020-02-05 01:46:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:46:14 --> Final output sent to browser
DEBUG - 2020-02-05 01:46:14 --> Total execution time: 0.3870
INFO - 2020-02-05 01:46:50 --> Config Class Initialized
INFO - 2020-02-05 01:46:50 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:46:50 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:46:50 --> Utf8 Class Initialized
INFO - 2020-02-05 01:46:50 --> URI Class Initialized
INFO - 2020-02-05 01:46:50 --> Router Class Initialized
INFO - 2020-02-05 01:46:50 --> Output Class Initialized
INFO - 2020-02-05 01:46:50 --> Security Class Initialized
DEBUG - 2020-02-05 01:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:46:50 --> Input Class Initialized
INFO - 2020-02-05 01:46:50 --> Language Class Initialized
INFO - 2020-02-05 01:46:50 --> Language Class Initialized
INFO - 2020-02-05 01:46:50 --> Config Class Initialized
INFO - 2020-02-05 01:46:50 --> Loader Class Initialized
INFO - 2020-02-05 01:46:50 --> Helper loaded: url_helper
INFO - 2020-02-05 01:46:50 --> Helper loaded: file_helper
INFO - 2020-02-05 01:46:50 --> Helper loaded: form_helper
INFO - 2020-02-05 01:46:50 --> Helper loaded: my_helper
INFO - 2020-02-05 01:46:50 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:46:50 --> Controller Class Initialized
DEBUG - 2020-02-05 01:46:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:46:50 --> Final output sent to browser
DEBUG - 2020-02-05 01:46:50 --> Total execution time: 0.2906
INFO - 2020-02-05 01:47:05 --> Config Class Initialized
INFO - 2020-02-05 01:47:05 --> Hooks Class Initialized
DEBUG - 2020-02-05 01:47:05 --> UTF-8 Support Enabled
INFO - 2020-02-05 01:47:05 --> Utf8 Class Initialized
INFO - 2020-02-05 01:47:05 --> URI Class Initialized
INFO - 2020-02-05 01:47:05 --> Router Class Initialized
INFO - 2020-02-05 01:47:05 --> Output Class Initialized
INFO - 2020-02-05 01:47:05 --> Security Class Initialized
DEBUG - 2020-02-05 01:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 01:47:05 --> Input Class Initialized
INFO - 2020-02-05 01:47:05 --> Language Class Initialized
INFO - 2020-02-05 01:47:05 --> Language Class Initialized
INFO - 2020-02-05 01:47:05 --> Config Class Initialized
INFO - 2020-02-05 01:47:05 --> Loader Class Initialized
INFO - 2020-02-05 01:47:05 --> Helper loaded: url_helper
INFO - 2020-02-05 01:47:05 --> Helper loaded: file_helper
INFO - 2020-02-05 01:47:05 --> Helper loaded: form_helper
INFO - 2020-02-05 01:47:05 --> Helper loaded: my_helper
INFO - 2020-02-05 01:47:05 --> Database Driver Class Initialized
DEBUG - 2020-02-05 01:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 01:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 01:47:05 --> Controller Class Initialized
DEBUG - 2020-02-05 01:47:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-02-05 01:47:05 --> Final output sent to browser
DEBUG - 2020-02-05 01:47:05 --> Total execution time: 0.2988
INFO - 2020-02-05 02:35:23 --> Config Class Initialized
INFO - 2020-02-05 02:35:23 --> Hooks Class Initialized
DEBUG - 2020-02-05 02:35:23 --> UTF-8 Support Enabled
INFO - 2020-02-05 02:35:23 --> Utf8 Class Initialized
INFO - 2020-02-05 02:35:23 --> URI Class Initialized
INFO - 2020-02-05 02:35:23 --> Router Class Initialized
INFO - 2020-02-05 02:35:23 --> Output Class Initialized
INFO - 2020-02-05 02:35:23 --> Security Class Initialized
DEBUG - 2020-02-05 02:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-05 02:35:23 --> Input Class Initialized
INFO - 2020-02-05 02:35:23 --> Language Class Initialized
INFO - 2020-02-05 02:35:23 --> Language Class Initialized
INFO - 2020-02-05 02:35:23 --> Config Class Initialized
INFO - 2020-02-05 02:35:23 --> Loader Class Initialized
INFO - 2020-02-05 02:35:23 --> Helper loaded: url_helper
INFO - 2020-02-05 02:35:23 --> Helper loaded: file_helper
INFO - 2020-02-05 02:35:23 --> Helper loaded: form_helper
INFO - 2020-02-05 02:35:23 --> Helper loaded: my_helper
INFO - 2020-02-05 02:35:23 --> Database Driver Class Initialized
DEBUG - 2020-02-05 02:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-05 02:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-05 02:35:23 --> Controller Class Initialized
DEBUG - 2020-02-05 02:35:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-02-05 02:35:24 --> Final output sent to browser
DEBUG - 2020-02-05 02:35:24 --> Total execution time: 1.0013
