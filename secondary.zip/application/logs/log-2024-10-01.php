<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-01 06:30:18 --> Config Class Initialized
INFO - 2024-10-01 06:30:18 --> Hooks Class Initialized
DEBUG - 2024-10-01 06:30:18 --> UTF-8 Support Enabled
INFO - 2024-10-01 06:30:18 --> Utf8 Class Initialized
INFO - 2024-10-01 06:30:18 --> URI Class Initialized
INFO - 2024-10-01 06:30:18 --> Router Class Initialized
INFO - 2024-10-01 06:30:18 --> Output Class Initialized
INFO - 2024-10-01 06:30:18 --> Security Class Initialized
DEBUG - 2024-10-01 06:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 06:30:18 --> Input Class Initialized
INFO - 2024-10-01 06:30:18 --> Language Class Initialized
INFO - 2024-10-01 06:30:18 --> Language Class Initialized
INFO - 2024-10-01 06:30:18 --> Config Class Initialized
INFO - 2024-10-01 06:30:18 --> Loader Class Initialized
INFO - 2024-10-01 06:30:18 --> Helper loaded: url_helper
INFO - 2024-10-01 06:30:18 --> Helper loaded: file_helper
INFO - 2024-10-01 06:30:18 --> Helper loaded: form_helper
INFO - 2024-10-01 06:30:18 --> Helper loaded: my_helper
INFO - 2024-10-01 06:30:18 --> Database Driver Class Initialized
INFO - 2024-10-01 06:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 06:30:18 --> Controller Class Initialized
INFO - 2024-10-01 06:30:18 --> Helper loaded: cookie_helper
INFO - 2024-10-01 06:30:18 --> Final output sent to browser
DEBUG - 2024-10-01 06:30:18 --> Total execution time: 0.0756
INFO - 2024-10-01 06:30:19 --> Config Class Initialized
INFO - 2024-10-01 06:30:19 --> Hooks Class Initialized
DEBUG - 2024-10-01 06:30:19 --> UTF-8 Support Enabled
INFO - 2024-10-01 06:30:19 --> Utf8 Class Initialized
INFO - 2024-10-01 06:30:19 --> URI Class Initialized
INFO - 2024-10-01 06:30:19 --> Router Class Initialized
INFO - 2024-10-01 06:30:19 --> Output Class Initialized
INFO - 2024-10-01 06:30:19 --> Security Class Initialized
DEBUG - 2024-10-01 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 06:30:19 --> Input Class Initialized
INFO - 2024-10-01 06:30:19 --> Language Class Initialized
INFO - 2024-10-01 06:30:19 --> Language Class Initialized
INFO - 2024-10-01 06:30:19 --> Config Class Initialized
INFO - 2024-10-01 06:30:19 --> Loader Class Initialized
INFO - 2024-10-01 06:30:19 --> Helper loaded: url_helper
INFO - 2024-10-01 06:30:19 --> Helper loaded: file_helper
INFO - 2024-10-01 06:30:19 --> Helper loaded: form_helper
INFO - 2024-10-01 06:30:19 --> Helper loaded: my_helper
INFO - 2024-10-01 06:30:19 --> Database Driver Class Initialized
INFO - 2024-10-01 06:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 06:30:19 --> Controller Class Initialized
INFO - 2024-10-01 06:30:19 --> Helper loaded: cookie_helper
INFO - 2024-10-01 06:30:19 --> Config Class Initialized
INFO - 2024-10-01 06:30:19 --> Hooks Class Initialized
DEBUG - 2024-10-01 06:30:19 --> UTF-8 Support Enabled
INFO - 2024-10-01 06:30:19 --> Utf8 Class Initialized
INFO - 2024-10-01 06:30:19 --> URI Class Initialized
INFO - 2024-10-01 06:30:19 --> Router Class Initialized
INFO - 2024-10-01 06:30:19 --> Output Class Initialized
INFO - 2024-10-01 06:30:19 --> Security Class Initialized
DEBUG - 2024-10-01 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 06:30:19 --> Input Class Initialized
INFO - 2024-10-01 06:30:19 --> Language Class Initialized
INFO - 2024-10-01 06:30:19 --> Language Class Initialized
INFO - 2024-10-01 06:30:19 --> Config Class Initialized
INFO - 2024-10-01 06:30:19 --> Loader Class Initialized
INFO - 2024-10-01 06:30:19 --> Helper loaded: url_helper
INFO - 2024-10-01 06:30:19 --> Helper loaded: file_helper
INFO - 2024-10-01 06:30:19 --> Helper loaded: form_helper
INFO - 2024-10-01 06:30:19 --> Helper loaded: my_helper
INFO - 2024-10-01 06:30:19 --> Database Driver Class Initialized
INFO - 2024-10-01 06:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 06:30:19 --> Controller Class Initialized
DEBUG - 2024-10-01 06:30:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-01 06:30:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 06:30:19 --> Final output sent to browser
DEBUG - 2024-10-01 06:30:19 --> Total execution time: 0.0514
INFO - 2024-10-01 06:30:21 --> Config Class Initialized
INFO - 2024-10-01 06:30:21 --> Hooks Class Initialized
DEBUG - 2024-10-01 06:30:21 --> UTF-8 Support Enabled
INFO - 2024-10-01 06:30:21 --> Utf8 Class Initialized
INFO - 2024-10-01 06:30:21 --> URI Class Initialized
INFO - 2024-10-01 06:30:21 --> Router Class Initialized
INFO - 2024-10-01 06:30:21 --> Output Class Initialized
INFO - 2024-10-01 06:30:21 --> Security Class Initialized
DEBUG - 2024-10-01 06:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 06:30:21 --> Input Class Initialized
INFO - 2024-10-01 06:30:21 --> Language Class Initialized
INFO - 2024-10-01 06:30:21 --> Language Class Initialized
INFO - 2024-10-01 06:30:21 --> Config Class Initialized
INFO - 2024-10-01 06:30:21 --> Loader Class Initialized
INFO - 2024-10-01 06:30:21 --> Helper loaded: url_helper
INFO - 2024-10-01 06:30:21 --> Helper loaded: file_helper
INFO - 2024-10-01 06:30:21 --> Helper loaded: form_helper
INFO - 2024-10-01 06:30:21 --> Helper loaded: my_helper
INFO - 2024-10-01 06:30:21 --> Database Driver Class Initialized
INFO - 2024-10-01 06:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 06:30:21 --> Controller Class Initialized
ERROR - 2024-10-01 06:30:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-01 06:30:21 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-01 06:30:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-01 06:30:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-01 06:30:24 --> Final output sent to browser
DEBUG - 2024-10-01 06:30:24 --> Total execution time: 2.9838
INFO - 2024-10-01 09:03:20 --> Config Class Initialized
INFO - 2024-10-01 09:03:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:03:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:03:20 --> Utf8 Class Initialized
INFO - 2024-10-01 09:03:20 --> URI Class Initialized
INFO - 2024-10-01 09:03:20 --> Router Class Initialized
INFO - 2024-10-01 09:03:20 --> Output Class Initialized
INFO - 2024-10-01 09:03:20 --> Security Class Initialized
DEBUG - 2024-10-01 09:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:03:20 --> Input Class Initialized
INFO - 2024-10-01 09:03:20 --> Language Class Initialized
INFO - 2024-10-01 09:03:20 --> Language Class Initialized
INFO - 2024-10-01 09:03:20 --> Config Class Initialized
INFO - 2024-10-01 09:03:20 --> Loader Class Initialized
INFO - 2024-10-01 09:03:20 --> Helper loaded: url_helper
INFO - 2024-10-01 09:03:20 --> Helper loaded: file_helper
INFO - 2024-10-01 09:03:20 --> Helper loaded: form_helper
INFO - 2024-10-01 09:03:20 --> Helper loaded: my_helper
INFO - 2024-10-01 09:03:20 --> Database Driver Class Initialized
INFO - 2024-10-01 09:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:03:20 --> Controller Class Initialized
INFO - 2024-10-01 09:03:20 --> Final output sent to browser
DEBUG - 2024-10-01 09:03:20 --> Total execution time: 0.0633
INFO - 2024-10-01 09:10:39 --> Config Class Initialized
INFO - 2024-10-01 09:10:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:10:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:10:39 --> Utf8 Class Initialized
INFO - 2024-10-01 09:10:39 --> URI Class Initialized
INFO - 2024-10-01 09:10:39 --> Router Class Initialized
INFO - 2024-10-01 09:10:39 --> Output Class Initialized
INFO - 2024-10-01 09:10:39 --> Security Class Initialized
DEBUG - 2024-10-01 09:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:10:39 --> Input Class Initialized
INFO - 2024-10-01 09:10:39 --> Language Class Initialized
INFO - 2024-10-01 09:10:39 --> Language Class Initialized
INFO - 2024-10-01 09:10:39 --> Config Class Initialized
INFO - 2024-10-01 09:10:39 --> Loader Class Initialized
INFO - 2024-10-01 09:10:39 --> Helper loaded: url_helper
INFO - 2024-10-01 09:10:39 --> Helper loaded: file_helper
INFO - 2024-10-01 09:10:39 --> Helper loaded: form_helper
INFO - 2024-10-01 09:10:39 --> Helper loaded: my_helper
INFO - 2024-10-01 09:10:39 --> Database Driver Class Initialized
INFO - 2024-10-01 09:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:10:39 --> Controller Class Initialized
INFO - 2024-10-01 09:10:39 --> Config Class Initialized
INFO - 2024-10-01 09:10:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:10:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:10:39 --> Utf8 Class Initialized
INFO - 2024-10-01 09:10:39 --> URI Class Initialized
INFO - 2024-10-01 09:10:39 --> Router Class Initialized
INFO - 2024-10-01 09:10:39 --> Output Class Initialized
INFO - 2024-10-01 09:10:39 --> Security Class Initialized
DEBUG - 2024-10-01 09:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:10:39 --> Input Class Initialized
INFO - 2024-10-01 09:10:39 --> Language Class Initialized
INFO - 2024-10-01 09:10:39 --> Language Class Initialized
INFO - 2024-10-01 09:10:39 --> Config Class Initialized
INFO - 2024-10-01 09:10:39 --> Loader Class Initialized
INFO - 2024-10-01 09:10:39 --> Helper loaded: url_helper
INFO - 2024-10-01 09:10:39 --> Helper loaded: file_helper
INFO - 2024-10-01 09:10:39 --> Helper loaded: form_helper
INFO - 2024-10-01 09:10:39 --> Helper loaded: my_helper
INFO - 2024-10-01 09:10:39 --> Database Driver Class Initialized
INFO - 2024-10-01 09:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:10:39 --> Controller Class Initialized
DEBUG - 2024-10-01 09:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 09:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 09:10:39 --> Final output sent to browser
DEBUG - 2024-10-01 09:10:39 --> Total execution time: 0.0317
INFO - 2024-10-01 09:10:44 --> Config Class Initialized
INFO - 2024-10-01 09:10:44 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:10:44 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:10:44 --> Utf8 Class Initialized
INFO - 2024-10-01 09:10:44 --> URI Class Initialized
INFO - 2024-10-01 09:10:44 --> Router Class Initialized
INFO - 2024-10-01 09:10:44 --> Output Class Initialized
INFO - 2024-10-01 09:10:44 --> Security Class Initialized
DEBUG - 2024-10-01 09:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:10:44 --> Input Class Initialized
INFO - 2024-10-01 09:10:44 --> Language Class Initialized
INFO - 2024-10-01 09:10:44 --> Language Class Initialized
INFO - 2024-10-01 09:10:44 --> Config Class Initialized
INFO - 2024-10-01 09:10:44 --> Loader Class Initialized
INFO - 2024-10-01 09:10:44 --> Helper loaded: url_helper
INFO - 2024-10-01 09:10:44 --> Helper loaded: file_helper
INFO - 2024-10-01 09:10:44 --> Helper loaded: form_helper
INFO - 2024-10-01 09:10:44 --> Helper loaded: my_helper
INFO - 2024-10-01 09:10:44 --> Database Driver Class Initialized
INFO - 2024-10-01 09:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:10:44 --> Controller Class Initialized
INFO - 2024-10-01 09:10:44 --> Helper loaded: cookie_helper
INFO - 2024-10-01 09:10:44 --> Final output sent to browser
DEBUG - 2024-10-01 09:10:44 --> Total execution time: 0.0486
INFO - 2024-10-01 09:10:44 --> Config Class Initialized
INFO - 2024-10-01 09:10:44 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:10:44 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:10:44 --> Utf8 Class Initialized
INFO - 2024-10-01 09:10:44 --> URI Class Initialized
INFO - 2024-10-01 09:10:44 --> Router Class Initialized
INFO - 2024-10-01 09:10:44 --> Output Class Initialized
INFO - 2024-10-01 09:10:44 --> Security Class Initialized
DEBUG - 2024-10-01 09:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:10:44 --> Input Class Initialized
INFO - 2024-10-01 09:10:44 --> Language Class Initialized
INFO - 2024-10-01 09:10:44 --> Language Class Initialized
INFO - 2024-10-01 09:10:44 --> Config Class Initialized
INFO - 2024-10-01 09:10:44 --> Loader Class Initialized
INFO - 2024-10-01 09:10:44 --> Helper loaded: url_helper
INFO - 2024-10-01 09:10:44 --> Helper loaded: file_helper
INFO - 2024-10-01 09:10:44 --> Helper loaded: form_helper
INFO - 2024-10-01 09:10:44 --> Helper loaded: my_helper
INFO - 2024-10-01 09:10:44 --> Database Driver Class Initialized
INFO - 2024-10-01 09:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:10:44 --> Controller Class Initialized
DEBUG - 2024-10-01 09:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-01 09:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 09:10:44 --> Final output sent to browser
DEBUG - 2024-10-01 09:10:44 --> Total execution time: 0.0466
INFO - 2024-10-01 09:10:49 --> Config Class Initialized
INFO - 2024-10-01 09:10:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:10:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:10:49 --> Utf8 Class Initialized
INFO - 2024-10-01 09:10:49 --> URI Class Initialized
INFO - 2024-10-01 09:10:49 --> Router Class Initialized
INFO - 2024-10-01 09:10:49 --> Output Class Initialized
INFO - 2024-10-01 09:10:49 --> Security Class Initialized
DEBUG - 2024-10-01 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:10:49 --> Input Class Initialized
INFO - 2024-10-01 09:10:49 --> Language Class Initialized
INFO - 2024-10-01 09:10:49 --> Language Class Initialized
INFO - 2024-10-01 09:10:49 --> Config Class Initialized
INFO - 2024-10-01 09:10:49 --> Loader Class Initialized
INFO - 2024-10-01 09:10:49 --> Helper loaded: url_helper
INFO - 2024-10-01 09:10:49 --> Helper loaded: file_helper
INFO - 2024-10-01 09:10:49 --> Helper loaded: form_helper
INFO - 2024-10-01 09:10:49 --> Helper loaded: my_helper
INFO - 2024-10-01 09:10:49 --> Database Driver Class Initialized
INFO - 2024-10-01 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:10:49 --> Controller Class Initialized
DEBUG - 2024-10-01 09:10:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-10-01 09:10:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 09:10:49 --> Final output sent to browser
DEBUG - 2024-10-01 09:10:49 --> Total execution time: 0.2523
INFO - 2024-10-01 09:10:55 --> Config Class Initialized
INFO - 2024-10-01 09:10:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:10:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:10:55 --> Utf8 Class Initialized
INFO - 2024-10-01 09:10:55 --> URI Class Initialized
INFO - 2024-10-01 09:10:55 --> Router Class Initialized
INFO - 2024-10-01 09:10:55 --> Output Class Initialized
INFO - 2024-10-01 09:10:55 --> Security Class Initialized
DEBUG - 2024-10-01 09:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:10:55 --> Input Class Initialized
INFO - 2024-10-01 09:10:55 --> Language Class Initialized
INFO - 2024-10-01 09:10:55 --> Language Class Initialized
INFO - 2024-10-01 09:10:55 --> Config Class Initialized
INFO - 2024-10-01 09:10:55 --> Loader Class Initialized
INFO - 2024-10-01 09:10:55 --> Helper loaded: url_helper
INFO - 2024-10-01 09:10:55 --> Helper loaded: file_helper
INFO - 2024-10-01 09:10:55 --> Helper loaded: form_helper
INFO - 2024-10-01 09:10:55 --> Helper loaded: my_helper
INFO - 2024-10-01 09:10:55 --> Database Driver Class Initialized
INFO - 2024-10-01 09:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:10:55 --> Controller Class Initialized
DEBUG - 2024-10-01 09:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-01 09:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 09:10:55 --> Final output sent to browser
DEBUG - 2024-10-01 09:10:55 --> Total execution time: 0.0348
INFO - 2024-10-01 09:20:50 --> Config Class Initialized
INFO - 2024-10-01 09:20:50 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:20:50 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:20:50 --> Utf8 Class Initialized
INFO - 2024-10-01 09:20:50 --> URI Class Initialized
INFO - 2024-10-01 09:20:50 --> Router Class Initialized
INFO - 2024-10-01 09:20:50 --> Output Class Initialized
INFO - 2024-10-01 09:20:50 --> Security Class Initialized
DEBUG - 2024-10-01 09:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:20:50 --> Input Class Initialized
INFO - 2024-10-01 09:20:50 --> Language Class Initialized
INFO - 2024-10-01 09:20:50 --> Language Class Initialized
INFO - 2024-10-01 09:20:50 --> Config Class Initialized
INFO - 2024-10-01 09:20:50 --> Loader Class Initialized
INFO - 2024-10-01 09:20:50 --> Helper loaded: url_helper
INFO - 2024-10-01 09:20:50 --> Helper loaded: file_helper
INFO - 2024-10-01 09:20:50 --> Helper loaded: form_helper
INFO - 2024-10-01 09:20:50 --> Helper loaded: my_helper
INFO - 2024-10-01 09:20:50 --> Database Driver Class Initialized
INFO - 2024-10-01 09:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:20:50 --> Controller Class Initialized
INFO - 2024-10-01 09:20:50 --> Final output sent to browser
DEBUG - 2024-10-01 09:20:50 --> Total execution time: 0.1148
INFO - 2024-10-01 09:20:56 --> Config Class Initialized
INFO - 2024-10-01 09:20:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:20:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:20:56 --> Utf8 Class Initialized
INFO - 2024-10-01 09:20:56 --> URI Class Initialized
INFO - 2024-10-01 09:20:56 --> Router Class Initialized
INFO - 2024-10-01 09:20:56 --> Output Class Initialized
INFO - 2024-10-01 09:20:56 --> Security Class Initialized
DEBUG - 2024-10-01 09:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:20:56 --> Input Class Initialized
INFO - 2024-10-01 09:20:56 --> Language Class Initialized
INFO - 2024-10-01 09:20:56 --> Language Class Initialized
INFO - 2024-10-01 09:20:56 --> Config Class Initialized
INFO - 2024-10-01 09:20:56 --> Loader Class Initialized
INFO - 2024-10-01 09:20:56 --> Helper loaded: url_helper
INFO - 2024-10-01 09:20:56 --> Helper loaded: file_helper
INFO - 2024-10-01 09:20:56 --> Helper loaded: form_helper
INFO - 2024-10-01 09:20:56 --> Helper loaded: my_helper
INFO - 2024-10-01 09:20:56 --> Database Driver Class Initialized
INFO - 2024-10-01 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:20:56 --> Controller Class Initialized
DEBUG - 2024-10-01 09:20:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 09:20:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 09:20:56 --> Final output sent to browser
DEBUG - 2024-10-01 09:20:56 --> Total execution time: 0.0382
INFO - 2024-10-01 09:22:38 --> Config Class Initialized
INFO - 2024-10-01 09:22:38 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:22:38 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:22:38 --> Utf8 Class Initialized
INFO - 2024-10-01 09:22:38 --> URI Class Initialized
INFO - 2024-10-01 09:22:38 --> Router Class Initialized
INFO - 2024-10-01 09:22:38 --> Output Class Initialized
INFO - 2024-10-01 09:22:38 --> Security Class Initialized
DEBUG - 2024-10-01 09:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:22:38 --> Input Class Initialized
INFO - 2024-10-01 09:22:38 --> Language Class Initialized
INFO - 2024-10-01 09:22:38 --> Language Class Initialized
INFO - 2024-10-01 09:22:38 --> Config Class Initialized
INFO - 2024-10-01 09:22:38 --> Loader Class Initialized
INFO - 2024-10-01 09:22:38 --> Helper loaded: url_helper
INFO - 2024-10-01 09:22:38 --> Helper loaded: file_helper
INFO - 2024-10-01 09:22:38 --> Helper loaded: form_helper
INFO - 2024-10-01 09:22:38 --> Helper loaded: my_helper
INFO - 2024-10-01 09:22:38 --> Database Driver Class Initialized
INFO - 2024-10-01 09:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:22:38 --> Controller Class Initialized
DEBUG - 2024-10-01 09:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 09:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 09:22:38 --> Final output sent to browser
DEBUG - 2024-10-01 09:22:38 --> Total execution time: 0.0360
INFO - 2024-10-01 09:22:40 --> Config Class Initialized
INFO - 2024-10-01 09:22:40 --> Hooks Class Initialized
DEBUG - 2024-10-01 09:22:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 09:22:40 --> Utf8 Class Initialized
INFO - 2024-10-01 09:22:40 --> URI Class Initialized
INFO - 2024-10-01 09:22:40 --> Router Class Initialized
INFO - 2024-10-01 09:22:40 --> Output Class Initialized
INFO - 2024-10-01 09:22:40 --> Security Class Initialized
DEBUG - 2024-10-01 09:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 09:22:40 --> Input Class Initialized
INFO - 2024-10-01 09:22:40 --> Language Class Initialized
INFO - 2024-10-01 09:22:40 --> Language Class Initialized
INFO - 2024-10-01 09:22:40 --> Config Class Initialized
INFO - 2024-10-01 09:22:40 --> Loader Class Initialized
INFO - 2024-10-01 09:22:40 --> Helper loaded: url_helper
INFO - 2024-10-01 09:22:40 --> Helper loaded: file_helper
INFO - 2024-10-01 09:22:40 --> Helper loaded: form_helper
INFO - 2024-10-01 09:22:40 --> Helper loaded: my_helper
INFO - 2024-10-01 09:22:40 --> Database Driver Class Initialized
INFO - 2024-10-01 09:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 09:22:40 --> Controller Class Initialized
INFO - 2024-10-01 10:05:20 --> Config Class Initialized
INFO - 2024-10-01 10:05:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:05:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:05:20 --> Utf8 Class Initialized
INFO - 2024-10-01 10:05:20 --> URI Class Initialized
INFO - 2024-10-01 10:05:20 --> Router Class Initialized
INFO - 2024-10-01 10:05:20 --> Output Class Initialized
INFO - 2024-10-01 10:05:20 --> Security Class Initialized
DEBUG - 2024-10-01 10:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:05:20 --> Input Class Initialized
INFO - 2024-10-01 10:05:20 --> Language Class Initialized
INFO - 2024-10-01 10:05:20 --> Language Class Initialized
INFO - 2024-10-01 10:05:20 --> Config Class Initialized
INFO - 2024-10-01 10:05:20 --> Loader Class Initialized
INFO - 2024-10-01 10:05:20 --> Helper loaded: url_helper
INFO - 2024-10-01 10:05:20 --> Helper loaded: file_helper
INFO - 2024-10-01 10:05:20 --> Helper loaded: form_helper
INFO - 2024-10-01 10:05:20 --> Helper loaded: my_helper
INFO - 2024-10-01 10:05:20 --> Database Driver Class Initialized
INFO - 2024-10-01 10:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:05:20 --> Controller Class Initialized
DEBUG - 2024-10-01 10:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-01 10:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:05:20 --> Final output sent to browser
DEBUG - 2024-10-01 10:05:20 --> Total execution time: 0.0769
INFO - 2024-10-01 10:05:25 --> Config Class Initialized
INFO - 2024-10-01 10:05:25 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:05:25 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:05:25 --> Utf8 Class Initialized
INFO - 2024-10-01 10:05:25 --> URI Class Initialized
INFO - 2024-10-01 10:05:25 --> Router Class Initialized
INFO - 2024-10-01 10:05:25 --> Output Class Initialized
INFO - 2024-10-01 10:05:25 --> Security Class Initialized
DEBUG - 2024-10-01 10:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:05:25 --> Input Class Initialized
INFO - 2024-10-01 10:05:25 --> Language Class Initialized
INFO - 2024-10-01 10:05:25 --> Language Class Initialized
INFO - 2024-10-01 10:05:25 --> Config Class Initialized
INFO - 2024-10-01 10:05:25 --> Loader Class Initialized
INFO - 2024-10-01 10:05:25 --> Helper loaded: url_helper
INFO - 2024-10-01 10:05:25 --> Helper loaded: file_helper
INFO - 2024-10-01 10:05:25 --> Helper loaded: form_helper
INFO - 2024-10-01 10:05:25 --> Helper loaded: my_helper
INFO - 2024-10-01 10:05:25 --> Database Driver Class Initialized
INFO - 2024-10-01 10:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:05:25 --> Controller Class Initialized
INFO - 2024-10-01 10:05:27 --> Config Class Initialized
INFO - 2024-10-01 10:05:27 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:05:27 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:05:27 --> Utf8 Class Initialized
INFO - 2024-10-01 10:05:27 --> URI Class Initialized
INFO - 2024-10-01 10:05:27 --> Router Class Initialized
INFO - 2024-10-01 10:05:27 --> Output Class Initialized
INFO - 2024-10-01 10:05:27 --> Security Class Initialized
DEBUG - 2024-10-01 10:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:05:27 --> Input Class Initialized
INFO - 2024-10-01 10:05:27 --> Language Class Initialized
INFO - 2024-10-01 10:05:27 --> Language Class Initialized
INFO - 2024-10-01 10:05:27 --> Config Class Initialized
INFO - 2024-10-01 10:05:27 --> Loader Class Initialized
INFO - 2024-10-01 10:05:27 --> Helper loaded: url_helper
INFO - 2024-10-01 10:05:27 --> Helper loaded: file_helper
INFO - 2024-10-01 10:05:27 --> Helper loaded: form_helper
INFO - 2024-10-01 10:05:27 --> Helper loaded: my_helper
INFO - 2024-10-01 10:05:27 --> Database Driver Class Initialized
INFO - 2024-10-01 10:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:05:27 --> Controller Class Initialized
DEBUG - 2024-10-01 10:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:05:27 --> Final output sent to browser
DEBUG - 2024-10-01 10:05:27 --> Total execution time: 0.1605
INFO - 2024-10-01 10:05:28 --> Config Class Initialized
INFO - 2024-10-01 10:05:28 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:05:28 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:05:28 --> Utf8 Class Initialized
INFO - 2024-10-01 10:05:28 --> URI Class Initialized
INFO - 2024-10-01 10:05:28 --> Router Class Initialized
INFO - 2024-10-01 10:05:28 --> Output Class Initialized
INFO - 2024-10-01 10:05:28 --> Security Class Initialized
DEBUG - 2024-10-01 10:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:05:28 --> Input Class Initialized
INFO - 2024-10-01 10:05:28 --> Language Class Initialized
INFO - 2024-10-01 10:05:28 --> Language Class Initialized
INFO - 2024-10-01 10:05:28 --> Config Class Initialized
INFO - 2024-10-01 10:05:28 --> Loader Class Initialized
INFO - 2024-10-01 10:05:28 --> Helper loaded: url_helper
INFO - 2024-10-01 10:05:28 --> Helper loaded: file_helper
INFO - 2024-10-01 10:05:28 --> Helper loaded: form_helper
INFO - 2024-10-01 10:05:28 --> Helper loaded: my_helper
INFO - 2024-10-01 10:05:28 --> Database Driver Class Initialized
INFO - 2024-10-01 10:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:05:28 --> Controller Class Initialized
INFO - 2024-10-01 10:05:28 --> Final output sent to browser
DEBUG - 2024-10-01 10:05:28 --> Total execution time: 0.0330
INFO - 2024-10-01 10:06:20 --> Config Class Initialized
INFO - 2024-10-01 10:06:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:06:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:06:20 --> Utf8 Class Initialized
INFO - 2024-10-01 10:06:20 --> URI Class Initialized
INFO - 2024-10-01 10:06:20 --> Router Class Initialized
INFO - 2024-10-01 10:06:20 --> Output Class Initialized
INFO - 2024-10-01 10:06:20 --> Security Class Initialized
DEBUG - 2024-10-01 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:06:20 --> Input Class Initialized
INFO - 2024-10-01 10:06:20 --> Language Class Initialized
INFO - 2024-10-01 10:06:20 --> Language Class Initialized
INFO - 2024-10-01 10:06:20 --> Config Class Initialized
INFO - 2024-10-01 10:06:20 --> Loader Class Initialized
INFO - 2024-10-01 10:06:20 --> Helper loaded: url_helper
INFO - 2024-10-01 10:06:20 --> Helper loaded: file_helper
INFO - 2024-10-01 10:06:20 --> Helper loaded: form_helper
INFO - 2024-10-01 10:06:20 --> Helper loaded: my_helper
INFO - 2024-10-01 10:06:20 --> Database Driver Class Initialized
INFO - 2024-10-01 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:06:20 --> Controller Class Initialized
DEBUG - 2024-10-01 10:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:06:23 --> Final output sent to browser
DEBUG - 2024-10-01 10:06:23 --> Total execution time: 3.2656
INFO - 2024-10-01 10:06:29 --> Config Class Initialized
INFO - 2024-10-01 10:06:29 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:06:29 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:06:29 --> Utf8 Class Initialized
INFO - 2024-10-01 10:06:29 --> URI Class Initialized
INFO - 2024-10-01 10:06:29 --> Router Class Initialized
INFO - 2024-10-01 10:06:29 --> Output Class Initialized
INFO - 2024-10-01 10:06:29 --> Security Class Initialized
DEBUG - 2024-10-01 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:06:29 --> Input Class Initialized
INFO - 2024-10-01 10:06:29 --> Language Class Initialized
INFO - 2024-10-01 10:06:29 --> Language Class Initialized
INFO - 2024-10-01 10:06:29 --> Config Class Initialized
INFO - 2024-10-01 10:06:29 --> Loader Class Initialized
INFO - 2024-10-01 10:06:29 --> Helper loaded: url_helper
INFO - 2024-10-01 10:06:29 --> Helper loaded: file_helper
INFO - 2024-10-01 10:06:29 --> Helper loaded: form_helper
INFO - 2024-10-01 10:06:29 --> Helper loaded: my_helper
INFO - 2024-10-01 10:06:29 --> Database Driver Class Initialized
INFO - 2024-10-01 10:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:06:29 --> Controller Class Initialized
DEBUG - 2024-10-01 10:06:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/list.php
DEBUG - 2024-10-01 10:06:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:06:30 --> Final output sent to browser
DEBUG - 2024-10-01 10:06:30 --> Total execution time: 0.8647
INFO - 2024-10-01 10:06:33 --> Config Class Initialized
INFO - 2024-10-01 10:06:33 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:06:33 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:06:33 --> Utf8 Class Initialized
INFO - 2024-10-01 10:06:33 --> URI Class Initialized
INFO - 2024-10-01 10:06:33 --> Router Class Initialized
INFO - 2024-10-01 10:06:33 --> Output Class Initialized
INFO - 2024-10-01 10:06:33 --> Security Class Initialized
DEBUG - 2024-10-01 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:06:33 --> Input Class Initialized
INFO - 2024-10-01 10:06:33 --> Language Class Initialized
INFO - 2024-10-01 10:06:34 --> Language Class Initialized
INFO - 2024-10-01 10:06:34 --> Config Class Initialized
INFO - 2024-10-01 10:06:34 --> Loader Class Initialized
INFO - 2024-10-01 10:06:34 --> Helper loaded: url_helper
INFO - 2024-10-01 10:06:34 --> Helper loaded: file_helper
INFO - 2024-10-01 10:06:34 --> Helper loaded: form_helper
INFO - 2024-10-01 10:06:34 --> Helper loaded: my_helper
INFO - 2024-10-01 10:06:34 --> Database Driver Class Initialized
INFO - 2024-10-01 10:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:06:36 --> Controller Class Initialized
DEBUG - 2024-10-01 10:06:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:06:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:06:36 --> Final output sent to browser
DEBUG - 2024-10-01 10:06:36 --> Total execution time: 2.6359
INFO - 2024-10-01 10:07:13 --> Config Class Initialized
INFO - 2024-10-01 10:07:13 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:07:13 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:07:13 --> Utf8 Class Initialized
INFO - 2024-10-01 10:07:13 --> URI Class Initialized
INFO - 2024-10-01 10:07:13 --> Router Class Initialized
INFO - 2024-10-01 10:07:13 --> Output Class Initialized
INFO - 2024-10-01 10:07:13 --> Security Class Initialized
DEBUG - 2024-10-01 10:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:07:13 --> Input Class Initialized
INFO - 2024-10-01 10:07:13 --> Language Class Initialized
INFO - 2024-10-01 10:07:13 --> Language Class Initialized
INFO - 2024-10-01 10:07:13 --> Config Class Initialized
INFO - 2024-10-01 10:07:13 --> Loader Class Initialized
INFO - 2024-10-01 10:07:13 --> Helper loaded: url_helper
INFO - 2024-10-01 10:07:13 --> Helper loaded: file_helper
INFO - 2024-10-01 10:07:13 --> Helper loaded: form_helper
INFO - 2024-10-01 10:07:13 --> Helper loaded: my_helper
INFO - 2024-10-01 10:07:13 --> Database Driver Class Initialized
INFO - 2024-10-01 10:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:07:13 --> Controller Class Initialized
DEBUG - 2024-10-01 10:07:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:07:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:07:13 --> Final output sent to browser
DEBUG - 2024-10-01 10:07:13 --> Total execution time: 0.3522
INFO - 2024-10-01 10:07:17 --> Config Class Initialized
INFO - 2024-10-01 10:07:17 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:07:17 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:07:17 --> Utf8 Class Initialized
INFO - 2024-10-01 10:07:17 --> URI Class Initialized
INFO - 2024-10-01 10:07:17 --> Router Class Initialized
INFO - 2024-10-01 10:07:17 --> Output Class Initialized
INFO - 2024-10-01 10:07:17 --> Security Class Initialized
DEBUG - 2024-10-01 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:07:17 --> Input Class Initialized
INFO - 2024-10-01 10:07:17 --> Language Class Initialized
INFO - 2024-10-01 10:07:17 --> Language Class Initialized
INFO - 2024-10-01 10:07:17 --> Config Class Initialized
INFO - 2024-10-01 10:07:17 --> Loader Class Initialized
INFO - 2024-10-01 10:07:17 --> Helper loaded: url_helper
INFO - 2024-10-01 10:07:17 --> Helper loaded: file_helper
INFO - 2024-10-01 10:07:17 --> Helper loaded: form_helper
INFO - 2024-10-01 10:07:17 --> Helper loaded: my_helper
INFO - 2024-10-01 10:07:17 --> Database Driver Class Initialized
INFO - 2024-10-01 10:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:07:17 --> Controller Class Initialized
INFO - 2024-10-01 10:09:24 --> Config Class Initialized
INFO - 2024-10-01 10:09:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:24 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:24 --> URI Class Initialized
INFO - 2024-10-01 10:09:24 --> Router Class Initialized
INFO - 2024-10-01 10:09:24 --> Output Class Initialized
INFO - 2024-10-01 10:09:24 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:24 --> Input Class Initialized
INFO - 2024-10-01 10:09:24 --> Language Class Initialized
INFO - 2024-10-01 10:09:24 --> Language Class Initialized
INFO - 2024-10-01 10:09:24 --> Config Class Initialized
INFO - 2024-10-01 10:09:24 --> Loader Class Initialized
INFO - 2024-10-01 10:09:24 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:24 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:24 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:24 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:24 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:24 --> Controller Class Initialized
DEBUG - 2024-10-01 10:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-01 10:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:09:24 --> Final output sent to browser
DEBUG - 2024-10-01 10:09:24 --> Total execution time: 0.0649
INFO - 2024-10-01 10:09:30 --> Config Class Initialized
INFO - 2024-10-01 10:09:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:30 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:30 --> URI Class Initialized
INFO - 2024-10-01 10:09:30 --> Router Class Initialized
INFO - 2024-10-01 10:09:30 --> Output Class Initialized
INFO - 2024-10-01 10:09:30 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:30 --> Input Class Initialized
INFO - 2024-10-01 10:09:30 --> Language Class Initialized
INFO - 2024-10-01 10:09:30 --> Language Class Initialized
INFO - 2024-10-01 10:09:30 --> Config Class Initialized
INFO - 2024-10-01 10:09:30 --> Loader Class Initialized
INFO - 2024-10-01 10:09:30 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:30 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:30 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:30 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:30 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:30 --> Controller Class Initialized
INFO - 2024-10-01 10:09:30 --> Config Class Initialized
INFO - 2024-10-01 10:09:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:30 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:30 --> URI Class Initialized
INFO - 2024-10-01 10:09:30 --> Router Class Initialized
INFO - 2024-10-01 10:09:30 --> Output Class Initialized
INFO - 2024-10-01 10:09:30 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:30 --> Input Class Initialized
INFO - 2024-10-01 10:09:30 --> Language Class Initialized
INFO - 2024-10-01 10:09:30 --> Language Class Initialized
INFO - 2024-10-01 10:09:30 --> Config Class Initialized
INFO - 2024-10-01 10:09:30 --> Loader Class Initialized
INFO - 2024-10-01 10:09:30 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:30 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:30 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:30 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:30 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:30 --> Controller Class Initialized
DEBUG - 2024-10-01 10:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:09:30 --> Final output sent to browser
DEBUG - 2024-10-01 10:09:30 --> Total execution time: 0.0406
INFO - 2024-10-01 10:09:31 --> Config Class Initialized
INFO - 2024-10-01 10:09:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:31 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:31 --> URI Class Initialized
INFO - 2024-10-01 10:09:31 --> Router Class Initialized
INFO - 2024-10-01 10:09:31 --> Output Class Initialized
INFO - 2024-10-01 10:09:31 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:31 --> Input Class Initialized
INFO - 2024-10-01 10:09:31 --> Language Class Initialized
INFO - 2024-10-01 10:09:31 --> Language Class Initialized
INFO - 2024-10-01 10:09:31 --> Config Class Initialized
INFO - 2024-10-01 10:09:31 --> Loader Class Initialized
INFO - 2024-10-01 10:09:31 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:31 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:31 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:31 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:32 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:32 --> Controller Class Initialized
INFO - 2024-10-01 10:09:32 --> Final output sent to browser
DEBUG - 2024-10-01 10:09:32 --> Total execution time: 0.5356
INFO - 2024-10-01 10:09:41 --> Config Class Initialized
INFO - 2024-10-01 10:09:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:41 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:41 --> URI Class Initialized
INFO - 2024-10-01 10:09:41 --> Router Class Initialized
INFO - 2024-10-01 10:09:41 --> Output Class Initialized
INFO - 2024-10-01 10:09:41 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:41 --> Input Class Initialized
INFO - 2024-10-01 10:09:41 --> Language Class Initialized
INFO - 2024-10-01 10:09:41 --> Language Class Initialized
INFO - 2024-10-01 10:09:41 --> Config Class Initialized
INFO - 2024-10-01 10:09:41 --> Loader Class Initialized
INFO - 2024-10-01 10:09:41 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:41 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:41 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:41 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:41 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:41 --> Controller Class Initialized
DEBUG - 2024-10-01 10:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:09:41 --> Final output sent to browser
DEBUG - 2024-10-01 10:09:41 --> Total execution time: 0.0351
INFO - 2024-10-01 10:09:44 --> Config Class Initialized
INFO - 2024-10-01 10:09:44 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:44 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:44 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:44 --> URI Class Initialized
INFO - 2024-10-01 10:09:44 --> Router Class Initialized
INFO - 2024-10-01 10:09:44 --> Output Class Initialized
INFO - 2024-10-01 10:09:44 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:44 --> Input Class Initialized
INFO - 2024-10-01 10:09:44 --> Language Class Initialized
INFO - 2024-10-01 10:09:44 --> Language Class Initialized
INFO - 2024-10-01 10:09:44 --> Config Class Initialized
INFO - 2024-10-01 10:09:44 --> Loader Class Initialized
INFO - 2024-10-01 10:09:44 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:44 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:44 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:44 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:44 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:44 --> Controller Class Initialized
DEBUG - 2024-10-01 10:09:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:09:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:09:44 --> Final output sent to browser
DEBUG - 2024-10-01 10:09:44 --> Total execution time: 0.0424
INFO - 2024-10-01 10:09:46 --> Config Class Initialized
INFO - 2024-10-01 10:09:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:09:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:09:46 --> Utf8 Class Initialized
INFO - 2024-10-01 10:09:46 --> URI Class Initialized
INFO - 2024-10-01 10:09:46 --> Router Class Initialized
INFO - 2024-10-01 10:09:46 --> Output Class Initialized
INFO - 2024-10-01 10:09:46 --> Security Class Initialized
DEBUG - 2024-10-01 10:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:09:46 --> Input Class Initialized
INFO - 2024-10-01 10:09:46 --> Language Class Initialized
INFO - 2024-10-01 10:09:46 --> Language Class Initialized
INFO - 2024-10-01 10:09:46 --> Config Class Initialized
INFO - 2024-10-01 10:09:46 --> Loader Class Initialized
INFO - 2024-10-01 10:09:46 --> Helper loaded: url_helper
INFO - 2024-10-01 10:09:46 --> Helper loaded: file_helper
INFO - 2024-10-01 10:09:46 --> Helper loaded: form_helper
INFO - 2024-10-01 10:09:46 --> Helper loaded: my_helper
INFO - 2024-10-01 10:09:46 --> Database Driver Class Initialized
INFO - 2024-10-01 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:09:46 --> Controller Class Initialized
INFO - 2024-10-01 10:13:43 --> Config Class Initialized
INFO - 2024-10-01 10:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:13:43 --> Utf8 Class Initialized
INFO - 2024-10-01 10:13:43 --> URI Class Initialized
INFO - 2024-10-01 10:13:43 --> Router Class Initialized
INFO - 2024-10-01 10:13:43 --> Output Class Initialized
INFO - 2024-10-01 10:13:43 --> Security Class Initialized
DEBUG - 2024-10-01 10:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:13:43 --> Input Class Initialized
INFO - 2024-10-01 10:13:43 --> Language Class Initialized
INFO - 2024-10-01 10:13:43 --> Language Class Initialized
INFO - 2024-10-01 10:13:43 --> Config Class Initialized
INFO - 2024-10-01 10:13:43 --> Loader Class Initialized
INFO - 2024-10-01 10:13:43 --> Helper loaded: url_helper
INFO - 2024-10-01 10:13:43 --> Helper loaded: file_helper
INFO - 2024-10-01 10:13:43 --> Helper loaded: form_helper
INFO - 2024-10-01 10:13:43 --> Helper loaded: my_helper
INFO - 2024-10-01 10:13:43 --> Database Driver Class Initialized
INFO - 2024-10-01 10:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:13:43 --> Controller Class Initialized
DEBUG - 2024-10-01 10:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-01 10:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:13:43 --> Final output sent to browser
DEBUG - 2024-10-01 10:13:43 --> Total execution time: 0.1989
INFO - 2024-10-01 10:13:49 --> Config Class Initialized
INFO - 2024-10-01 10:13:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:13:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:13:49 --> Utf8 Class Initialized
INFO - 2024-10-01 10:13:49 --> URI Class Initialized
INFO - 2024-10-01 10:13:49 --> Router Class Initialized
INFO - 2024-10-01 10:13:49 --> Output Class Initialized
INFO - 2024-10-01 10:13:49 --> Security Class Initialized
DEBUG - 2024-10-01 10:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:13:49 --> Input Class Initialized
INFO - 2024-10-01 10:13:49 --> Language Class Initialized
INFO - 2024-10-01 10:13:49 --> Language Class Initialized
INFO - 2024-10-01 10:13:49 --> Config Class Initialized
INFO - 2024-10-01 10:13:49 --> Loader Class Initialized
INFO - 2024-10-01 10:13:49 --> Helper loaded: url_helper
INFO - 2024-10-01 10:13:49 --> Helper loaded: file_helper
INFO - 2024-10-01 10:13:49 --> Helper loaded: form_helper
INFO - 2024-10-01 10:13:49 --> Helper loaded: my_helper
INFO - 2024-10-01 10:13:49 --> Database Driver Class Initialized
INFO - 2024-10-01 10:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:13:49 --> Controller Class Initialized
INFO - 2024-10-01 10:13:49 --> Config Class Initialized
INFO - 2024-10-01 10:13:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:13:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:13:49 --> Utf8 Class Initialized
INFO - 2024-10-01 10:13:49 --> URI Class Initialized
INFO - 2024-10-01 10:13:49 --> Router Class Initialized
INFO - 2024-10-01 10:13:49 --> Output Class Initialized
INFO - 2024-10-01 10:13:49 --> Security Class Initialized
DEBUG - 2024-10-01 10:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:13:49 --> Input Class Initialized
INFO - 2024-10-01 10:13:49 --> Language Class Initialized
INFO - 2024-10-01 10:13:49 --> Language Class Initialized
INFO - 2024-10-01 10:13:49 --> Config Class Initialized
INFO - 2024-10-01 10:13:49 --> Loader Class Initialized
INFO - 2024-10-01 10:13:49 --> Helper loaded: url_helper
INFO - 2024-10-01 10:13:49 --> Helper loaded: file_helper
INFO - 2024-10-01 10:13:49 --> Helper loaded: form_helper
INFO - 2024-10-01 10:13:49 --> Helper loaded: my_helper
INFO - 2024-10-01 10:13:49 --> Database Driver Class Initialized
INFO - 2024-10-01 10:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:13:49 --> Controller Class Initialized
DEBUG - 2024-10-01 10:13:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:13:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:13:49 --> Final output sent to browser
DEBUG - 2024-10-01 10:13:49 --> Total execution time: 0.0310
INFO - 2024-10-01 10:13:52 --> Config Class Initialized
INFO - 2024-10-01 10:13:52 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:13:52 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:13:52 --> Utf8 Class Initialized
INFO - 2024-10-01 10:13:52 --> URI Class Initialized
INFO - 2024-10-01 10:13:52 --> Router Class Initialized
INFO - 2024-10-01 10:13:52 --> Output Class Initialized
INFO - 2024-10-01 10:13:52 --> Security Class Initialized
DEBUG - 2024-10-01 10:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:13:52 --> Input Class Initialized
INFO - 2024-10-01 10:13:52 --> Language Class Initialized
INFO - 2024-10-01 10:13:52 --> Language Class Initialized
INFO - 2024-10-01 10:13:52 --> Config Class Initialized
INFO - 2024-10-01 10:13:52 --> Loader Class Initialized
INFO - 2024-10-01 10:13:52 --> Helper loaded: url_helper
INFO - 2024-10-01 10:13:52 --> Helper loaded: file_helper
INFO - 2024-10-01 10:13:52 --> Helper loaded: form_helper
INFO - 2024-10-01 10:13:52 --> Helper loaded: my_helper
INFO - 2024-10-01 10:13:52 --> Database Driver Class Initialized
INFO - 2024-10-01 10:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:13:52 --> Controller Class Initialized
INFO - 2024-10-01 10:13:52 --> Final output sent to browser
DEBUG - 2024-10-01 10:13:52 --> Total execution time: 0.0566
INFO - 2024-10-01 10:14:01 --> Config Class Initialized
INFO - 2024-10-01 10:14:01 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:14:01 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:14:01 --> Utf8 Class Initialized
INFO - 2024-10-01 10:14:01 --> URI Class Initialized
INFO - 2024-10-01 10:14:01 --> Router Class Initialized
INFO - 2024-10-01 10:14:01 --> Output Class Initialized
INFO - 2024-10-01 10:14:01 --> Security Class Initialized
DEBUG - 2024-10-01 10:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:14:01 --> Input Class Initialized
INFO - 2024-10-01 10:14:01 --> Language Class Initialized
INFO - 2024-10-01 10:14:01 --> Language Class Initialized
INFO - 2024-10-01 10:14:01 --> Config Class Initialized
INFO - 2024-10-01 10:14:01 --> Loader Class Initialized
INFO - 2024-10-01 10:14:01 --> Helper loaded: url_helper
INFO - 2024-10-01 10:14:01 --> Helper loaded: file_helper
INFO - 2024-10-01 10:14:01 --> Helper loaded: form_helper
INFO - 2024-10-01 10:14:01 --> Helper loaded: my_helper
INFO - 2024-10-01 10:14:01 --> Database Driver Class Initialized
INFO - 2024-10-01 10:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:14:01 --> Controller Class Initialized
DEBUG - 2024-10-01 10:14:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:14:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:14:01 --> Final output sent to browser
DEBUG - 2024-10-01 10:14:01 --> Total execution time: 0.2053
INFO - 2024-10-01 10:14:03 --> Config Class Initialized
INFO - 2024-10-01 10:14:03 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:14:03 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:14:03 --> Utf8 Class Initialized
INFO - 2024-10-01 10:14:03 --> URI Class Initialized
INFO - 2024-10-01 10:14:03 --> Router Class Initialized
INFO - 2024-10-01 10:14:03 --> Output Class Initialized
INFO - 2024-10-01 10:14:03 --> Security Class Initialized
DEBUG - 2024-10-01 10:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:14:03 --> Input Class Initialized
INFO - 2024-10-01 10:14:03 --> Language Class Initialized
INFO - 2024-10-01 10:14:03 --> Language Class Initialized
INFO - 2024-10-01 10:14:03 --> Config Class Initialized
INFO - 2024-10-01 10:14:03 --> Loader Class Initialized
INFO - 2024-10-01 10:14:03 --> Helper loaded: url_helper
INFO - 2024-10-01 10:14:03 --> Helper loaded: file_helper
INFO - 2024-10-01 10:14:03 --> Helper loaded: form_helper
INFO - 2024-10-01 10:14:03 --> Helper loaded: my_helper
INFO - 2024-10-01 10:14:03 --> Database Driver Class Initialized
INFO - 2024-10-01 10:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:14:03 --> Controller Class Initialized
DEBUG - 2024-10-01 10:14:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:14:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:14:03 --> Final output sent to browser
DEBUG - 2024-10-01 10:14:03 --> Total execution time: 0.1012
INFO - 2024-10-01 10:14:05 --> Config Class Initialized
INFO - 2024-10-01 10:14:05 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:14:05 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:14:05 --> Utf8 Class Initialized
INFO - 2024-10-01 10:14:05 --> URI Class Initialized
INFO - 2024-10-01 10:14:05 --> Router Class Initialized
INFO - 2024-10-01 10:14:05 --> Output Class Initialized
INFO - 2024-10-01 10:14:05 --> Security Class Initialized
DEBUG - 2024-10-01 10:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:14:05 --> Input Class Initialized
INFO - 2024-10-01 10:14:05 --> Language Class Initialized
INFO - 2024-10-01 10:14:05 --> Language Class Initialized
INFO - 2024-10-01 10:14:05 --> Config Class Initialized
INFO - 2024-10-01 10:14:05 --> Loader Class Initialized
INFO - 2024-10-01 10:14:05 --> Helper loaded: url_helper
INFO - 2024-10-01 10:14:05 --> Helper loaded: file_helper
INFO - 2024-10-01 10:14:05 --> Helper loaded: form_helper
INFO - 2024-10-01 10:14:05 --> Helper loaded: my_helper
INFO - 2024-10-01 10:14:05 --> Database Driver Class Initialized
INFO - 2024-10-01 10:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:14:05 --> Controller Class Initialized
INFO - 2024-10-01 10:16:24 --> Config Class Initialized
INFO - 2024-10-01 10:16:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:16:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:16:24 --> Utf8 Class Initialized
INFO - 2024-10-01 10:16:24 --> URI Class Initialized
INFO - 2024-10-01 10:16:25 --> Router Class Initialized
INFO - 2024-10-01 10:16:25 --> Output Class Initialized
INFO - 2024-10-01 10:16:25 --> Security Class Initialized
DEBUG - 2024-10-01 10:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:16:25 --> Input Class Initialized
INFO - 2024-10-01 10:16:25 --> Language Class Initialized
INFO - 2024-10-01 10:16:25 --> Language Class Initialized
INFO - 2024-10-01 10:16:25 --> Config Class Initialized
INFO - 2024-10-01 10:16:25 --> Loader Class Initialized
INFO - 2024-10-01 10:16:25 --> Helper loaded: url_helper
INFO - 2024-10-01 10:16:25 --> Helper loaded: file_helper
INFO - 2024-10-01 10:16:25 --> Helper loaded: form_helper
INFO - 2024-10-01 10:16:25 --> Helper loaded: my_helper
INFO - 2024-10-01 10:16:25 --> Database Driver Class Initialized
INFO - 2024-10-01 10:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:16:25 --> Controller Class Initialized
DEBUG - 2024-10-01 10:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-01 10:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:16:25 --> Final output sent to browser
DEBUG - 2024-10-01 10:16:25 --> Total execution time: 0.7189
INFO - 2024-10-01 10:16:31 --> Config Class Initialized
INFO - 2024-10-01 10:16:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:16:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:16:31 --> Utf8 Class Initialized
INFO - 2024-10-01 10:16:31 --> URI Class Initialized
INFO - 2024-10-01 10:16:31 --> Router Class Initialized
INFO - 2024-10-01 10:16:31 --> Output Class Initialized
INFO - 2024-10-01 10:16:31 --> Security Class Initialized
DEBUG - 2024-10-01 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:16:31 --> Input Class Initialized
INFO - 2024-10-01 10:16:31 --> Language Class Initialized
INFO - 2024-10-01 10:16:31 --> Language Class Initialized
INFO - 2024-10-01 10:16:31 --> Config Class Initialized
INFO - 2024-10-01 10:16:31 --> Loader Class Initialized
INFO - 2024-10-01 10:16:31 --> Helper loaded: url_helper
INFO - 2024-10-01 10:16:31 --> Helper loaded: file_helper
INFO - 2024-10-01 10:16:31 --> Helper loaded: form_helper
INFO - 2024-10-01 10:16:31 --> Helper loaded: my_helper
INFO - 2024-10-01 10:16:31 --> Database Driver Class Initialized
INFO - 2024-10-01 10:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:16:31 --> Controller Class Initialized
INFO - 2024-10-01 10:16:32 --> Config Class Initialized
INFO - 2024-10-01 10:16:32 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:16:32 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:16:32 --> Utf8 Class Initialized
INFO - 2024-10-01 10:16:32 --> URI Class Initialized
INFO - 2024-10-01 10:16:32 --> Router Class Initialized
INFO - 2024-10-01 10:16:32 --> Output Class Initialized
INFO - 2024-10-01 10:16:32 --> Security Class Initialized
DEBUG - 2024-10-01 10:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:16:32 --> Input Class Initialized
INFO - 2024-10-01 10:16:32 --> Language Class Initialized
INFO - 2024-10-01 10:16:32 --> Language Class Initialized
INFO - 2024-10-01 10:16:32 --> Config Class Initialized
INFO - 2024-10-01 10:16:32 --> Loader Class Initialized
INFO - 2024-10-01 10:16:32 --> Helper loaded: url_helper
INFO - 2024-10-01 10:16:32 --> Helper loaded: file_helper
INFO - 2024-10-01 10:16:32 --> Helper loaded: form_helper
INFO - 2024-10-01 10:16:32 --> Helper loaded: my_helper
INFO - 2024-10-01 10:16:32 --> Database Driver Class Initialized
INFO - 2024-10-01 10:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:16:32 --> Controller Class Initialized
DEBUG - 2024-10-01 10:16:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:16:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:16:32 --> Final output sent to browser
DEBUG - 2024-10-01 10:16:32 --> Total execution time: 0.3078
INFO - 2024-10-01 10:16:42 --> Config Class Initialized
INFO - 2024-10-01 10:16:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:16:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:16:42 --> Utf8 Class Initialized
INFO - 2024-10-01 10:16:42 --> URI Class Initialized
INFO - 2024-10-01 10:16:42 --> Router Class Initialized
INFO - 2024-10-01 10:16:42 --> Output Class Initialized
INFO - 2024-10-01 10:16:42 --> Security Class Initialized
DEBUG - 2024-10-01 10:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:16:42 --> Input Class Initialized
INFO - 2024-10-01 10:16:42 --> Language Class Initialized
INFO - 2024-10-01 10:16:42 --> Language Class Initialized
INFO - 2024-10-01 10:16:42 --> Config Class Initialized
INFO - 2024-10-01 10:16:42 --> Loader Class Initialized
INFO - 2024-10-01 10:16:42 --> Helper loaded: url_helper
INFO - 2024-10-01 10:16:42 --> Helper loaded: file_helper
INFO - 2024-10-01 10:16:42 --> Helper loaded: form_helper
INFO - 2024-10-01 10:16:42 --> Helper loaded: my_helper
INFO - 2024-10-01 10:16:42 --> Database Driver Class Initialized
INFO - 2024-10-01 10:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:16:43 --> Controller Class Initialized
DEBUG - 2024-10-01 10:16:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:16:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:16:43 --> Final output sent to browser
DEBUG - 2024-10-01 10:16:43 --> Total execution time: 0.3378
INFO - 2024-10-01 10:16:44 --> Config Class Initialized
INFO - 2024-10-01 10:16:44 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:16:44 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:16:44 --> Utf8 Class Initialized
INFO - 2024-10-01 10:16:44 --> URI Class Initialized
INFO - 2024-10-01 10:16:44 --> Router Class Initialized
INFO - 2024-10-01 10:16:44 --> Output Class Initialized
INFO - 2024-10-01 10:16:44 --> Security Class Initialized
DEBUG - 2024-10-01 10:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:16:44 --> Input Class Initialized
INFO - 2024-10-01 10:16:44 --> Language Class Initialized
INFO - 2024-10-01 10:16:44 --> Language Class Initialized
INFO - 2024-10-01 10:16:44 --> Config Class Initialized
INFO - 2024-10-01 10:16:44 --> Loader Class Initialized
INFO - 2024-10-01 10:16:44 --> Helper loaded: url_helper
INFO - 2024-10-01 10:16:44 --> Helper loaded: file_helper
INFO - 2024-10-01 10:16:44 --> Helper loaded: form_helper
INFO - 2024-10-01 10:16:44 --> Helper loaded: my_helper
INFO - 2024-10-01 10:16:44 --> Database Driver Class Initialized
INFO - 2024-10-01 10:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:16:44 --> Controller Class Initialized
DEBUG - 2024-10-01 10:16:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:16:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:16:44 --> Final output sent to browser
DEBUG - 2024-10-01 10:16:44 --> Total execution time: 0.0562
INFO - 2024-10-01 10:16:51 --> Config Class Initialized
INFO - 2024-10-01 10:16:51 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:16:51 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:16:51 --> Utf8 Class Initialized
INFO - 2024-10-01 10:16:51 --> URI Class Initialized
INFO - 2024-10-01 10:16:51 --> Router Class Initialized
INFO - 2024-10-01 10:16:51 --> Output Class Initialized
INFO - 2024-10-01 10:16:51 --> Security Class Initialized
DEBUG - 2024-10-01 10:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:16:51 --> Input Class Initialized
INFO - 2024-10-01 10:16:51 --> Language Class Initialized
INFO - 2024-10-01 10:16:51 --> Language Class Initialized
INFO - 2024-10-01 10:16:51 --> Config Class Initialized
INFO - 2024-10-01 10:16:51 --> Loader Class Initialized
INFO - 2024-10-01 10:16:51 --> Helper loaded: url_helper
INFO - 2024-10-01 10:16:51 --> Helper loaded: file_helper
INFO - 2024-10-01 10:16:51 --> Helper loaded: form_helper
INFO - 2024-10-01 10:16:51 --> Helper loaded: my_helper
INFO - 2024-10-01 10:16:51 --> Database Driver Class Initialized
INFO - 2024-10-01 10:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:16:51 --> Controller Class Initialized
INFO - 2024-10-01 10:19:55 --> Config Class Initialized
INFO - 2024-10-01 10:19:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:19:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:19:55 --> Utf8 Class Initialized
INFO - 2024-10-01 10:19:56 --> URI Class Initialized
INFO - 2024-10-01 10:19:56 --> Router Class Initialized
INFO - 2024-10-01 10:19:56 --> Output Class Initialized
INFO - 2024-10-01 10:19:56 --> Security Class Initialized
DEBUG - 2024-10-01 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:19:56 --> Input Class Initialized
INFO - 2024-10-01 10:19:56 --> Language Class Initialized
INFO - 2024-10-01 10:19:56 --> Language Class Initialized
INFO - 2024-10-01 10:19:56 --> Config Class Initialized
INFO - 2024-10-01 10:19:56 --> Loader Class Initialized
INFO - 2024-10-01 10:19:56 --> Helper loaded: url_helper
INFO - 2024-10-01 10:19:56 --> Helper loaded: file_helper
INFO - 2024-10-01 10:19:56 --> Helper loaded: form_helper
INFO - 2024-10-01 10:19:56 --> Helper loaded: my_helper
INFO - 2024-10-01 10:19:56 --> Database Driver Class Initialized
INFO - 2024-10-01 10:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:19:56 --> Controller Class Initialized
DEBUG - 2024-10-01 10:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-01 10:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:19:56 --> Final output sent to browser
DEBUG - 2024-10-01 10:19:56 --> Total execution time: 0.4932
INFO - 2024-10-01 10:20:01 --> Config Class Initialized
INFO - 2024-10-01 10:20:01 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:20:01 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:01 --> Utf8 Class Initialized
INFO - 2024-10-01 10:20:01 --> URI Class Initialized
INFO - 2024-10-01 10:20:01 --> Router Class Initialized
INFO - 2024-10-01 10:20:01 --> Output Class Initialized
INFO - 2024-10-01 10:20:01 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:01 --> Input Class Initialized
INFO - 2024-10-01 10:20:01 --> Language Class Initialized
INFO - 2024-10-01 10:20:01 --> Language Class Initialized
INFO - 2024-10-01 10:20:01 --> Config Class Initialized
INFO - 2024-10-01 10:20:01 --> Loader Class Initialized
INFO - 2024-10-01 10:20:01 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:01 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:01 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:01 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:01 --> Database Driver Class Initialized
INFO - 2024-10-01 10:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:20:01 --> Controller Class Initialized
INFO - 2024-10-01 10:20:03 --> Config Class Initialized
INFO - 2024-10-01 10:20:03 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:20:03 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:03 --> Utf8 Class Initialized
INFO - 2024-10-01 10:20:03 --> URI Class Initialized
INFO - 2024-10-01 10:20:03 --> Router Class Initialized
INFO - 2024-10-01 10:20:03 --> Output Class Initialized
INFO - 2024-10-01 10:20:03 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:03 --> Input Class Initialized
INFO - 2024-10-01 10:20:03 --> Language Class Initialized
INFO - 2024-10-01 10:20:04 --> Language Class Initialized
INFO - 2024-10-01 10:20:04 --> Config Class Initialized
INFO - 2024-10-01 10:20:04 --> Loader Class Initialized
INFO - 2024-10-01 10:20:04 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:04 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:04 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:04 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:04 --> Database Driver Class Initialized
INFO - 2024-10-01 10:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:20:04 --> Controller Class Initialized
DEBUG - 2024-10-01 10:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:20:04 --> Final output sent to browser
DEBUG - 2024-10-01 10:20:04 --> Total execution time: 0.7505
INFO - 2024-10-01 10:20:10 --> Config Class Initialized
INFO - 2024-10-01 10:20:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:20:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:10 --> Utf8 Class Initialized
INFO - 2024-10-01 10:20:10 --> URI Class Initialized
INFO - 2024-10-01 10:20:10 --> Router Class Initialized
INFO - 2024-10-01 10:20:10 --> Output Class Initialized
INFO - 2024-10-01 10:20:10 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:10 --> Input Class Initialized
INFO - 2024-10-01 10:20:10 --> Language Class Initialized
INFO - 2024-10-01 10:20:11 --> Language Class Initialized
INFO - 2024-10-01 10:20:11 --> Config Class Initialized
INFO - 2024-10-01 10:20:11 --> Loader Class Initialized
INFO - 2024-10-01 10:20:11 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:11 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:11 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:11 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:11 --> Database Driver Class Initialized
INFO - 2024-10-01 10:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:20:11 --> Controller Class Initialized
INFO - 2024-10-01 10:20:12 --> Final output sent to browser
DEBUG - 2024-10-01 10:20:12 --> Total execution time: 1.7867
ERROR - 2024-10-01 10:20:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library 'exif' (tried: /www/server/php/74/lib/php/extensions/no-debug-non-zts-20190902/exif (/www/server/php/74/lib/php/extensions/no-debug-non-zts-20190902/exif: cannot open shared object file: No such file or directory), /www/server/php/74/lib/php/extensions/no-debug-non-zts-20190902/exif.so (/www/server/php/74/lib/php/extensions/no-debug-non-zts-20190902/exif.so: cannot open shared object file: No such file or directory)) Unknown 0
INFO - 2024-10-01 10:20:35 --> Config Class Initialized
INFO - 2024-10-01 10:20:35 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:20:35 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:35 --> Utf8 Class Initialized
INFO - 2024-10-01 10:20:35 --> URI Class Initialized
INFO - 2024-10-01 10:20:35 --> Router Class Initialized
INFO - 2024-10-01 10:20:35 --> Output Class Initialized
INFO - 2024-10-01 10:20:35 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:35 --> Input Class Initialized
INFO - 2024-10-01 10:20:35 --> Language Class Initialized
INFO - 2024-10-01 10:20:36 --> Language Class Initialized
INFO - 2024-10-01 10:20:36 --> Config Class Initialized
INFO - 2024-10-01 10:20:36 --> Loader Class Initialized
INFO - 2024-10-01 10:20:36 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:36 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:36 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:36 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:36 --> Database Driver Class Initialized
INFO - 2024-10-01 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:20:36 --> Controller Class Initialized
DEBUG - 2024-10-01 10:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:20:36 --> Final output sent to browser
DEBUG - 2024-10-01 10:20:36 --> Total execution time: 1.6870
INFO - 2024-10-01 10:20:41 --> Config Class Initialized
INFO - 2024-10-01 10:20:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:20:45 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:45 --> Utf8 Class Initialized
INFO - 2024-10-01 10:20:46 --> URI Class Initialized
INFO - 2024-10-01 10:20:46 --> Router Class Initialized
INFO - 2024-10-01 10:20:46 --> Output Class Initialized
INFO - 2024-10-01 10:20:46 --> Config Class Initialized
INFO - 2024-10-01 10:20:46 --> Hooks Class Initialized
INFO - 2024-10-01 10:20:46 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:46 --> Utf8 Class Initialized
DEBUG - 2024-10-01 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:46 --> Input Class Initialized
INFO - 2024-10-01 10:20:46 --> URI Class Initialized
INFO - 2024-10-01 10:20:46 --> Language Class Initialized
INFO - 2024-10-01 10:20:46 --> Router Class Initialized
INFO - 2024-10-01 10:20:46 --> Output Class Initialized
INFO - 2024-10-01 10:20:46 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:46 --> Input Class Initialized
INFO - 2024-10-01 10:20:46 --> Language Class Initialized
INFO - 2024-10-01 10:20:46 --> Language Class Initialized
INFO - 2024-10-01 10:20:46 --> Config Class Initialized
INFO - 2024-10-01 10:20:46 --> Loader Class Initialized
INFO - 2024-10-01 10:20:46 --> Language Class Initialized
INFO - 2024-10-01 10:20:46 --> Config Class Initialized
INFO - 2024-10-01 10:20:46 --> Loader Class Initialized
INFO - 2024-10-01 10:20:46 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:46 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:46 --> Database Driver Class Initialized
INFO - 2024-10-01 10:20:46 --> Database Driver Class Initialized
ERROR - 2024-10-01 10:20:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-10-01 10:20:46 --> Unable to connect to the database
ERROR - 2024-10-01 10:20:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-10-01 10:20:46 --> Unable to connect to the database
INFO - 2024-10-01 10:20:46 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-01 10:20:46 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-01 10:20:48 --> Config Class Initialized
INFO - 2024-10-01 10:20:48 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:20:48 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:20:48 --> Utf8 Class Initialized
INFO - 2024-10-01 10:20:48 --> URI Class Initialized
INFO - 2024-10-01 10:20:48 --> Router Class Initialized
INFO - 2024-10-01 10:20:48 --> Output Class Initialized
INFO - 2024-10-01 10:20:48 --> Security Class Initialized
DEBUG - 2024-10-01 10:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:20:48 --> Input Class Initialized
INFO - 2024-10-01 10:20:48 --> Language Class Initialized
INFO - 2024-10-01 10:20:48 --> Language Class Initialized
INFO - 2024-10-01 10:20:48 --> Config Class Initialized
INFO - 2024-10-01 10:20:48 --> Loader Class Initialized
INFO - 2024-10-01 10:20:48 --> Helper loaded: url_helper
INFO - 2024-10-01 10:20:48 --> Helper loaded: file_helper
INFO - 2024-10-01 10:20:48 --> Helper loaded: form_helper
INFO - 2024-10-01 10:20:48 --> Helper loaded: my_helper
INFO - 2024-10-01 10:20:48 --> Database Driver Class Initialized
ERROR - 2024-10-01 10:20:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-10-01 10:20:49 --> Unable to connect to the database
INFO - 2024-10-01 10:20:49 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-01 10:34:31 --> Config Class Initialized
INFO - 2024-10-01 10:34:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:34:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:34:31 --> Utf8 Class Initialized
INFO - 2024-10-01 10:34:31 --> URI Class Initialized
INFO - 2024-10-01 10:34:31 --> Router Class Initialized
INFO - 2024-10-01 10:34:31 --> Output Class Initialized
INFO - 2024-10-01 10:34:31 --> Security Class Initialized
DEBUG - 2024-10-01 10:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:34:31 --> Input Class Initialized
INFO - 2024-10-01 10:34:31 --> Language Class Initialized
INFO - 2024-10-01 10:34:31 --> Language Class Initialized
INFO - 2024-10-01 10:34:31 --> Config Class Initialized
INFO - 2024-10-01 10:34:31 --> Loader Class Initialized
INFO - 2024-10-01 10:34:31 --> Helper loaded: url_helper
INFO - 2024-10-01 10:34:31 --> Helper loaded: file_helper
INFO - 2024-10-01 10:34:31 --> Helper loaded: form_helper
INFO - 2024-10-01 10:34:31 --> Helper loaded: my_helper
INFO - 2024-10-01 10:34:31 --> Database Driver Class Initialized
INFO - 2024-10-01 10:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:34:31 --> Controller Class Initialized
DEBUG - 2024-10-01 10:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-01 10:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:34:31 --> Final output sent to browser
DEBUG - 2024-10-01 10:34:31 --> Total execution time: 0.1023
INFO - 2024-10-01 10:34:34 --> Config Class Initialized
INFO - 2024-10-01 10:34:34 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:34:34 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:34:34 --> Utf8 Class Initialized
INFO - 2024-10-01 10:34:35 --> URI Class Initialized
DEBUG - 2024-10-01 10:34:35 --> No URI present. Default controller set.
INFO - 2024-10-01 10:34:35 --> Router Class Initialized
INFO - 2024-10-01 10:34:35 --> Output Class Initialized
INFO - 2024-10-01 10:34:35 --> Security Class Initialized
DEBUG - 2024-10-01 10:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:34:35 --> Input Class Initialized
INFO - 2024-10-01 10:34:35 --> Language Class Initialized
INFO - 2024-10-01 10:34:35 --> Language Class Initialized
INFO - 2024-10-01 10:34:35 --> Config Class Initialized
INFO - 2024-10-01 10:34:35 --> Loader Class Initialized
INFO - 2024-10-01 10:34:35 --> Helper loaded: url_helper
INFO - 2024-10-01 10:34:35 --> Helper loaded: file_helper
INFO - 2024-10-01 10:34:35 --> Helper loaded: form_helper
INFO - 2024-10-01 10:34:35 --> Helper loaded: my_helper
INFO - 2024-10-01 10:34:35 --> Database Driver Class Initialized
INFO - 2024-10-01 10:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:34:35 --> Controller Class Initialized
DEBUG - 2024-10-01 10:34:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-01 10:34:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:34:35 --> Final output sent to browser
DEBUG - 2024-10-01 10:34:35 --> Total execution time: 0.0557
INFO - 2024-10-01 10:34:35 --> Config Class Initialized
INFO - 2024-10-01 10:34:35 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:34:35 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:34:35 --> Utf8 Class Initialized
INFO - 2024-10-01 10:34:35 --> URI Class Initialized
INFO - 2024-10-01 10:34:35 --> Router Class Initialized
INFO - 2024-10-01 10:34:35 --> Output Class Initialized
INFO - 2024-10-01 10:34:35 --> Security Class Initialized
DEBUG - 2024-10-01 10:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:34:35 --> Input Class Initialized
INFO - 2024-10-01 10:34:35 --> Language Class Initialized
INFO - 2024-10-01 10:34:35 --> Language Class Initialized
INFO - 2024-10-01 10:34:35 --> Config Class Initialized
INFO - 2024-10-01 10:34:35 --> Loader Class Initialized
INFO - 2024-10-01 10:34:35 --> Helper loaded: url_helper
INFO - 2024-10-01 10:34:35 --> Helper loaded: file_helper
INFO - 2024-10-01 10:34:35 --> Helper loaded: form_helper
INFO - 2024-10-01 10:34:35 --> Helper loaded: my_helper
INFO - 2024-10-01 10:34:35 --> Database Driver Class Initialized
INFO - 2024-10-01 10:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:34:35 --> Controller Class Initialized
DEBUG - 2024-10-01 10:34:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:34:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:34:35 --> Final output sent to browser
DEBUG - 2024-10-01 10:34:35 --> Total execution time: 0.0348
INFO - 2024-10-01 10:34:36 --> Config Class Initialized
INFO - 2024-10-01 10:34:36 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:34:36 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:34:36 --> Utf8 Class Initialized
INFO - 2024-10-01 10:34:36 --> URI Class Initialized
INFO - 2024-10-01 10:34:36 --> Router Class Initialized
INFO - 2024-10-01 10:34:36 --> Output Class Initialized
INFO - 2024-10-01 10:34:36 --> Security Class Initialized
DEBUG - 2024-10-01 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:34:36 --> Input Class Initialized
INFO - 2024-10-01 10:34:36 --> Language Class Initialized
INFO - 2024-10-01 10:34:36 --> Language Class Initialized
INFO - 2024-10-01 10:34:36 --> Config Class Initialized
INFO - 2024-10-01 10:34:36 --> Loader Class Initialized
INFO - 2024-10-01 10:34:36 --> Helper loaded: url_helper
INFO - 2024-10-01 10:34:36 --> Helper loaded: file_helper
INFO - 2024-10-01 10:34:36 --> Helper loaded: form_helper
INFO - 2024-10-01 10:34:36 --> Helper loaded: my_helper
INFO - 2024-10-01 10:34:36 --> Database Driver Class Initialized
INFO - 2024-10-01 10:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:34:36 --> Controller Class Initialized
DEBUG - 2024-10-01 10:34:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-01 10:34:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:34:36 --> Final output sent to browser
DEBUG - 2024-10-01 10:34:36 --> Total execution time: 0.0419
INFO - 2024-10-01 10:34:37 --> Config Class Initialized
INFO - 2024-10-01 10:34:37 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:34:37 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:34:37 --> Utf8 Class Initialized
INFO - 2024-10-01 10:34:37 --> URI Class Initialized
INFO - 2024-10-01 10:34:37 --> Router Class Initialized
INFO - 2024-10-01 10:34:37 --> Output Class Initialized
INFO - 2024-10-01 10:34:37 --> Security Class Initialized
DEBUG - 2024-10-01 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:34:37 --> Input Class Initialized
INFO - 2024-10-01 10:34:37 --> Language Class Initialized
INFO - 2024-10-01 10:34:37 --> Language Class Initialized
INFO - 2024-10-01 10:34:37 --> Config Class Initialized
INFO - 2024-10-01 10:34:37 --> Loader Class Initialized
INFO - 2024-10-01 10:34:37 --> Helper loaded: url_helper
INFO - 2024-10-01 10:34:37 --> Helper loaded: file_helper
INFO - 2024-10-01 10:34:37 --> Helper loaded: form_helper
INFO - 2024-10-01 10:34:37 --> Helper loaded: my_helper
INFO - 2024-10-01 10:34:37 --> Database Driver Class Initialized
INFO - 2024-10-01 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:34:37 --> Controller Class Initialized
INFO - 2024-10-01 10:34:37 --> Final output sent to browser
DEBUG - 2024-10-01 10:34:37 --> Total execution time: 0.0486
INFO - 2024-10-01 10:34:39 --> Config Class Initialized
INFO - 2024-10-01 10:34:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:34:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:34:39 --> Utf8 Class Initialized
INFO - 2024-10-01 10:34:39 --> URI Class Initialized
INFO - 2024-10-01 10:34:39 --> Router Class Initialized
INFO - 2024-10-01 10:34:39 --> Output Class Initialized
INFO - 2024-10-01 10:34:39 --> Security Class Initialized
DEBUG - 2024-10-01 10:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:34:39 --> Input Class Initialized
INFO - 2024-10-01 10:34:39 --> Language Class Initialized
INFO - 2024-10-01 10:34:40 --> Language Class Initialized
INFO - 2024-10-01 10:34:40 --> Config Class Initialized
INFO - 2024-10-01 10:34:40 --> Loader Class Initialized
INFO - 2024-10-01 10:34:40 --> Helper loaded: url_helper
INFO - 2024-10-01 10:34:40 --> Helper loaded: file_helper
INFO - 2024-10-01 10:34:40 --> Helper loaded: form_helper
INFO - 2024-10-01 10:34:40 --> Helper loaded: my_helper
INFO - 2024-10-01 10:34:40 --> Database Driver Class Initialized
INFO - 2024-10-01 10:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:34:40 --> Controller Class Initialized
DEBUG - 2024-10-01 10:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:34:40 --> Final output sent to browser
DEBUG - 2024-10-01 10:34:40 --> Total execution time: 0.0279
INFO - 2024-10-01 10:37:15 --> Config Class Initialized
INFO - 2024-10-01 10:37:15 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:15 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:15 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:15 --> URI Class Initialized
INFO - 2024-10-01 10:37:15 --> Router Class Initialized
INFO - 2024-10-01 10:37:15 --> Output Class Initialized
INFO - 2024-10-01 10:37:15 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:15 --> Input Class Initialized
INFO - 2024-10-01 10:37:15 --> Language Class Initialized
INFO - 2024-10-01 10:37:15 --> Language Class Initialized
INFO - 2024-10-01 10:37:15 --> Config Class Initialized
INFO - 2024-10-01 10:37:15 --> Loader Class Initialized
INFO - 2024-10-01 10:37:15 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:15 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:15 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:15 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:16 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:16 --> Controller Class Initialized
DEBUG - 2024-10-01 10:37:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:37:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:37:16 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:16 --> Total execution time: 0.8671
INFO - 2024-10-01 10:37:16 --> Config Class Initialized
INFO - 2024-10-01 10:37:16 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:16 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:16 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:16 --> URI Class Initialized
INFO - 2024-10-01 10:37:16 --> Router Class Initialized
INFO - 2024-10-01 10:37:16 --> Output Class Initialized
INFO - 2024-10-01 10:37:16 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:16 --> Input Class Initialized
INFO - 2024-10-01 10:37:16 --> Language Class Initialized
INFO - 2024-10-01 10:37:16 --> Language Class Initialized
INFO - 2024-10-01 10:37:16 --> Config Class Initialized
INFO - 2024-10-01 10:37:16 --> Loader Class Initialized
INFO - 2024-10-01 10:37:16 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:16 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:16 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:16 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:16 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:16 --> Controller Class Initialized
INFO - 2024-10-01 10:37:17 --> Config Class Initialized
INFO - 2024-10-01 10:37:17 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:17 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:17 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:17 --> URI Class Initialized
INFO - 2024-10-01 10:37:17 --> Router Class Initialized
INFO - 2024-10-01 10:37:17 --> Output Class Initialized
INFO - 2024-10-01 10:37:17 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:17 --> Input Class Initialized
INFO - 2024-10-01 10:37:17 --> Language Class Initialized
INFO - 2024-10-01 10:37:17 --> Language Class Initialized
INFO - 2024-10-01 10:37:17 --> Config Class Initialized
INFO - 2024-10-01 10:37:17 --> Loader Class Initialized
INFO - 2024-10-01 10:37:17 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:17 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:17 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:17 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:17 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:17 --> Controller Class Initialized
INFO - 2024-10-01 10:37:39 --> Config Class Initialized
INFO - 2024-10-01 10:37:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:39 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:39 --> URI Class Initialized
INFO - 2024-10-01 10:37:39 --> Router Class Initialized
INFO - 2024-10-01 10:37:39 --> Output Class Initialized
INFO - 2024-10-01 10:37:39 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:39 --> Input Class Initialized
INFO - 2024-10-01 10:37:39 --> Language Class Initialized
INFO - 2024-10-01 10:37:39 --> Language Class Initialized
INFO - 2024-10-01 10:37:39 --> Config Class Initialized
INFO - 2024-10-01 10:37:39 --> Loader Class Initialized
INFO - 2024-10-01 10:37:39 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:39 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:39 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:39 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:39 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:39 --> Controller Class Initialized
INFO - 2024-10-01 10:37:39 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:39 --> Total execution time: 0.0623
INFO - 2024-10-01 10:37:39 --> Config Class Initialized
INFO - 2024-10-01 10:37:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:39 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:39 --> URI Class Initialized
INFO - 2024-10-01 10:37:39 --> Router Class Initialized
INFO - 2024-10-01 10:37:39 --> Output Class Initialized
INFO - 2024-10-01 10:37:39 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:39 --> Input Class Initialized
INFO - 2024-10-01 10:37:39 --> Language Class Initialized
INFO - 2024-10-01 10:37:39 --> Language Class Initialized
INFO - 2024-10-01 10:37:39 --> Config Class Initialized
INFO - 2024-10-01 10:37:39 --> Loader Class Initialized
INFO - 2024-10-01 10:37:39 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:39 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:39 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:39 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:39 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:39 --> Controller Class Initialized
INFO - 2024-10-01 10:37:43 --> Config Class Initialized
INFO - 2024-10-01 10:37:43 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:43 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:43 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:43 --> URI Class Initialized
INFO - 2024-10-01 10:37:43 --> Router Class Initialized
INFO - 2024-10-01 10:37:43 --> Output Class Initialized
INFO - 2024-10-01 10:37:43 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:43 --> Input Class Initialized
INFO - 2024-10-01 10:37:43 --> Language Class Initialized
INFO - 2024-10-01 10:37:43 --> Language Class Initialized
INFO - 2024-10-01 10:37:43 --> Config Class Initialized
INFO - 2024-10-01 10:37:43 --> Loader Class Initialized
INFO - 2024-10-01 10:37:43 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:43 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:43 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:43 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:43 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:43 --> Controller Class Initialized
INFO - 2024-10-01 10:37:43 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:43 --> Total execution time: 0.0844
INFO - 2024-10-01 10:37:44 --> Config Class Initialized
INFO - 2024-10-01 10:37:44 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:44 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:44 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:44 --> URI Class Initialized
INFO - 2024-10-01 10:37:44 --> Router Class Initialized
INFO - 2024-10-01 10:37:44 --> Output Class Initialized
INFO - 2024-10-01 10:37:44 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:44 --> Input Class Initialized
INFO - 2024-10-01 10:37:44 --> Language Class Initialized
INFO - 2024-10-01 10:37:44 --> Language Class Initialized
INFO - 2024-10-01 10:37:44 --> Config Class Initialized
INFO - 2024-10-01 10:37:44 --> Loader Class Initialized
INFO - 2024-10-01 10:37:44 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:44 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:44 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:44 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:44 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:44 --> Controller Class Initialized
INFO - 2024-10-01 10:37:46 --> Config Class Initialized
INFO - 2024-10-01 10:37:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:46 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:46 --> URI Class Initialized
INFO - 2024-10-01 10:37:46 --> Router Class Initialized
INFO - 2024-10-01 10:37:46 --> Output Class Initialized
INFO - 2024-10-01 10:37:46 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:46 --> Input Class Initialized
INFO - 2024-10-01 10:37:46 --> Language Class Initialized
INFO - 2024-10-01 10:37:46 --> Language Class Initialized
INFO - 2024-10-01 10:37:46 --> Config Class Initialized
INFO - 2024-10-01 10:37:46 --> Loader Class Initialized
INFO - 2024-10-01 10:37:46 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:46 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:46 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:46 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:46 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:46 --> Controller Class Initialized
INFO - 2024-10-01 10:37:46 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:46 --> Total execution time: 0.0453
INFO - 2024-10-01 10:37:46 --> Config Class Initialized
INFO - 2024-10-01 10:37:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:46 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:46 --> URI Class Initialized
INFO - 2024-10-01 10:37:46 --> Router Class Initialized
INFO - 2024-10-01 10:37:46 --> Output Class Initialized
INFO - 2024-10-01 10:37:46 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:46 --> Input Class Initialized
INFO - 2024-10-01 10:37:46 --> Language Class Initialized
INFO - 2024-10-01 10:37:46 --> Language Class Initialized
INFO - 2024-10-01 10:37:46 --> Config Class Initialized
INFO - 2024-10-01 10:37:46 --> Loader Class Initialized
INFO - 2024-10-01 10:37:46 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:46 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:46 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:46 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:46 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:46 --> Controller Class Initialized
INFO - 2024-10-01 10:37:48 --> Config Class Initialized
INFO - 2024-10-01 10:37:48 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:48 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:48 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:48 --> URI Class Initialized
INFO - 2024-10-01 10:37:48 --> Router Class Initialized
INFO - 2024-10-01 10:37:48 --> Output Class Initialized
INFO - 2024-10-01 10:37:48 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:48 --> Input Class Initialized
INFO - 2024-10-01 10:37:48 --> Language Class Initialized
INFO - 2024-10-01 10:37:48 --> Language Class Initialized
INFO - 2024-10-01 10:37:48 --> Config Class Initialized
INFO - 2024-10-01 10:37:48 --> Loader Class Initialized
INFO - 2024-10-01 10:37:48 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:48 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:48 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:48 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:48 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:48 --> Controller Class Initialized
INFO - 2024-10-01 10:37:48 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:48 --> Total execution time: 0.1215
INFO - 2024-10-01 10:37:48 --> Config Class Initialized
INFO - 2024-10-01 10:37:48 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:48 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:48 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:48 --> URI Class Initialized
INFO - 2024-10-01 10:37:48 --> Router Class Initialized
INFO - 2024-10-01 10:37:48 --> Output Class Initialized
INFO - 2024-10-01 10:37:48 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:48 --> Input Class Initialized
INFO - 2024-10-01 10:37:48 --> Language Class Initialized
INFO - 2024-10-01 10:37:48 --> Language Class Initialized
INFO - 2024-10-01 10:37:48 --> Config Class Initialized
INFO - 2024-10-01 10:37:48 --> Loader Class Initialized
INFO - 2024-10-01 10:37:48 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:48 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:48 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:48 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:48 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:48 --> Controller Class Initialized
INFO - 2024-10-01 10:37:51 --> Config Class Initialized
INFO - 2024-10-01 10:37:51 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:51 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:51 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:51 --> URI Class Initialized
INFO - 2024-10-01 10:37:51 --> Router Class Initialized
INFO - 2024-10-01 10:37:51 --> Output Class Initialized
INFO - 2024-10-01 10:37:51 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:51 --> Input Class Initialized
INFO - 2024-10-01 10:37:51 --> Language Class Initialized
INFO - 2024-10-01 10:37:51 --> Language Class Initialized
INFO - 2024-10-01 10:37:51 --> Config Class Initialized
INFO - 2024-10-01 10:37:51 --> Loader Class Initialized
INFO - 2024-10-01 10:37:51 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:51 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:51 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:51 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:51 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:51 --> Controller Class Initialized
INFO - 2024-10-01 10:37:51 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:51 --> Total execution time: 0.0335
INFO - 2024-10-01 10:37:56 --> Config Class Initialized
INFO - 2024-10-01 10:37:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:56 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:56 --> URI Class Initialized
INFO - 2024-10-01 10:37:56 --> Router Class Initialized
INFO - 2024-10-01 10:37:56 --> Output Class Initialized
INFO - 2024-10-01 10:37:56 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:56 --> Input Class Initialized
INFO - 2024-10-01 10:37:56 --> Language Class Initialized
INFO - 2024-10-01 10:37:56 --> Language Class Initialized
INFO - 2024-10-01 10:37:56 --> Config Class Initialized
INFO - 2024-10-01 10:37:56 --> Loader Class Initialized
INFO - 2024-10-01 10:37:56 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:56 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:56 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:56 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:56 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:56 --> Controller Class Initialized
INFO - 2024-10-01 10:37:59 --> Config Class Initialized
INFO - 2024-10-01 10:37:59 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:59 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:59 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:59 --> URI Class Initialized
INFO - 2024-10-01 10:37:59 --> Router Class Initialized
INFO - 2024-10-01 10:37:59 --> Output Class Initialized
INFO - 2024-10-01 10:37:59 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:59 --> Input Class Initialized
INFO - 2024-10-01 10:37:59 --> Language Class Initialized
INFO - 2024-10-01 10:37:59 --> Language Class Initialized
INFO - 2024-10-01 10:37:59 --> Config Class Initialized
INFO - 2024-10-01 10:37:59 --> Loader Class Initialized
INFO - 2024-10-01 10:37:59 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:59 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:59 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:59 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:59 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:59 --> Controller Class Initialized
DEBUG - 2024-10-01 10:37:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:37:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:37:59 --> Final output sent to browser
DEBUG - 2024-10-01 10:37:59 --> Total execution time: 0.3349
INFO - 2024-10-01 10:37:59 --> Config Class Initialized
INFO - 2024-10-01 10:37:59 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:37:59 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:37:59 --> Utf8 Class Initialized
INFO - 2024-10-01 10:37:59 --> URI Class Initialized
INFO - 2024-10-01 10:37:59 --> Router Class Initialized
INFO - 2024-10-01 10:37:59 --> Output Class Initialized
INFO - 2024-10-01 10:37:59 --> Security Class Initialized
DEBUG - 2024-10-01 10:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:37:59 --> Input Class Initialized
INFO - 2024-10-01 10:37:59 --> Language Class Initialized
INFO - 2024-10-01 10:37:59 --> Language Class Initialized
INFO - 2024-10-01 10:37:59 --> Config Class Initialized
INFO - 2024-10-01 10:37:59 --> Loader Class Initialized
INFO - 2024-10-01 10:37:59 --> Helper loaded: url_helper
INFO - 2024-10-01 10:37:59 --> Helper loaded: file_helper
INFO - 2024-10-01 10:37:59 --> Helper loaded: form_helper
INFO - 2024-10-01 10:37:59 --> Helper loaded: my_helper
INFO - 2024-10-01 10:37:59 --> Database Driver Class Initialized
INFO - 2024-10-01 10:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:37:59 --> Controller Class Initialized
INFO - 2024-10-01 10:38:05 --> Config Class Initialized
INFO - 2024-10-01 10:38:05 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:38:05 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:38:05 --> Utf8 Class Initialized
INFO - 2024-10-01 10:38:05 --> URI Class Initialized
INFO - 2024-10-01 10:38:05 --> Router Class Initialized
INFO - 2024-10-01 10:38:05 --> Output Class Initialized
INFO - 2024-10-01 10:38:05 --> Security Class Initialized
DEBUG - 2024-10-01 10:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:38:05 --> Input Class Initialized
INFO - 2024-10-01 10:38:05 --> Language Class Initialized
INFO - 2024-10-01 10:38:05 --> Language Class Initialized
INFO - 2024-10-01 10:38:05 --> Config Class Initialized
INFO - 2024-10-01 10:38:05 --> Loader Class Initialized
INFO - 2024-10-01 10:38:05 --> Helper loaded: url_helper
INFO - 2024-10-01 10:38:05 --> Helper loaded: file_helper
INFO - 2024-10-01 10:38:05 --> Helper loaded: form_helper
INFO - 2024-10-01 10:38:05 --> Helper loaded: my_helper
INFO - 2024-10-01 10:38:05 --> Database Driver Class Initialized
INFO - 2024-10-01 10:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:38:05 --> Controller Class Initialized
INFO - 2024-10-01 10:38:05 --> Final output sent to browser
DEBUG - 2024-10-01 10:38:05 --> Total execution time: 0.0327
INFO - 2024-10-01 10:38:26 --> Config Class Initialized
INFO - 2024-10-01 10:38:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:38:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:38:26 --> Utf8 Class Initialized
INFO - 2024-10-01 10:38:26 --> URI Class Initialized
INFO - 2024-10-01 10:38:26 --> Router Class Initialized
INFO - 2024-10-01 10:38:26 --> Output Class Initialized
INFO - 2024-10-01 10:38:26 --> Security Class Initialized
DEBUG - 2024-10-01 10:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:38:26 --> Input Class Initialized
INFO - 2024-10-01 10:38:26 --> Language Class Initialized
INFO - 2024-10-01 10:38:26 --> Language Class Initialized
INFO - 2024-10-01 10:38:26 --> Config Class Initialized
INFO - 2024-10-01 10:38:26 --> Loader Class Initialized
INFO - 2024-10-01 10:38:26 --> Helper loaded: url_helper
INFO - 2024-10-01 10:38:26 --> Helper loaded: file_helper
INFO - 2024-10-01 10:38:26 --> Helper loaded: form_helper
INFO - 2024-10-01 10:38:26 --> Helper loaded: my_helper
INFO - 2024-10-01 10:38:26 --> Database Driver Class Initialized
INFO - 2024-10-01 10:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:38:26 --> Controller Class Initialized
INFO - 2024-10-01 10:38:26 --> Final output sent to browser
DEBUG - 2024-10-01 10:38:26 --> Total execution time: 0.0349
INFO - 2024-10-01 10:38:26 --> Config Class Initialized
INFO - 2024-10-01 10:38:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:38:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:38:26 --> Utf8 Class Initialized
INFO - 2024-10-01 10:38:26 --> URI Class Initialized
INFO - 2024-10-01 10:38:26 --> Router Class Initialized
INFO - 2024-10-01 10:38:26 --> Output Class Initialized
INFO - 2024-10-01 10:38:26 --> Security Class Initialized
DEBUG - 2024-10-01 10:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:38:26 --> Input Class Initialized
INFO - 2024-10-01 10:38:26 --> Language Class Initialized
INFO - 2024-10-01 10:38:26 --> Language Class Initialized
INFO - 2024-10-01 10:38:26 --> Config Class Initialized
INFO - 2024-10-01 10:38:26 --> Loader Class Initialized
INFO - 2024-10-01 10:38:26 --> Helper loaded: url_helper
INFO - 2024-10-01 10:38:26 --> Helper loaded: file_helper
INFO - 2024-10-01 10:38:26 --> Helper loaded: form_helper
INFO - 2024-10-01 10:38:26 --> Helper loaded: my_helper
INFO - 2024-10-01 10:38:26 --> Database Driver Class Initialized
INFO - 2024-10-01 10:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:38:26 --> Controller Class Initialized
INFO - 2024-10-01 10:38:30 --> Config Class Initialized
INFO - 2024-10-01 10:38:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:38:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:38:30 --> Utf8 Class Initialized
INFO - 2024-10-01 10:38:30 --> URI Class Initialized
INFO - 2024-10-01 10:38:30 --> Router Class Initialized
INFO - 2024-10-01 10:38:30 --> Output Class Initialized
INFO - 2024-10-01 10:38:30 --> Security Class Initialized
DEBUG - 2024-10-01 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:38:30 --> Input Class Initialized
INFO - 2024-10-01 10:38:30 --> Language Class Initialized
INFO - 2024-10-01 10:38:30 --> Language Class Initialized
INFO - 2024-10-01 10:38:30 --> Config Class Initialized
INFO - 2024-10-01 10:38:30 --> Loader Class Initialized
INFO - 2024-10-01 10:38:30 --> Helper loaded: url_helper
INFO - 2024-10-01 10:38:30 --> Helper loaded: file_helper
INFO - 2024-10-01 10:38:30 --> Helper loaded: form_helper
INFO - 2024-10-01 10:38:30 --> Helper loaded: my_helper
INFO - 2024-10-01 10:38:30 --> Database Driver Class Initialized
INFO - 2024-10-01 10:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:38:30 --> Controller Class Initialized
INFO - 2024-10-01 10:49:00 --> Config Class Initialized
INFO - 2024-10-01 10:49:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:00 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:00 --> URI Class Initialized
DEBUG - 2024-10-01 10:49:00 --> No URI present. Default controller set.
INFO - 2024-10-01 10:49:00 --> Router Class Initialized
INFO - 2024-10-01 10:49:00 --> Output Class Initialized
INFO - 2024-10-01 10:49:00 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:00 --> Input Class Initialized
INFO - 2024-10-01 10:49:00 --> Language Class Initialized
INFO - 2024-10-01 10:49:00 --> Language Class Initialized
INFO - 2024-10-01 10:49:00 --> Config Class Initialized
INFO - 2024-10-01 10:49:00 --> Loader Class Initialized
INFO - 2024-10-01 10:49:00 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:00 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:00 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:00 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:00 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:00 --> Controller Class Initialized
INFO - 2024-10-01 10:49:00 --> Config Class Initialized
INFO - 2024-10-01 10:49:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:00 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:00 --> URI Class Initialized
INFO - 2024-10-01 10:49:00 --> Router Class Initialized
INFO - 2024-10-01 10:49:00 --> Output Class Initialized
INFO - 2024-10-01 10:49:00 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:00 --> Input Class Initialized
INFO - 2024-10-01 10:49:00 --> Language Class Initialized
INFO - 2024-10-01 10:49:00 --> Language Class Initialized
INFO - 2024-10-01 10:49:00 --> Config Class Initialized
INFO - 2024-10-01 10:49:00 --> Loader Class Initialized
INFO - 2024-10-01 10:49:00 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:00 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:00 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:00 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:00 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:00 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 10:49:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:00 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:00 --> Total execution time: 0.0296
INFO - 2024-10-01 10:49:06 --> Config Class Initialized
INFO - 2024-10-01 10:49:06 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:06 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:06 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:06 --> URI Class Initialized
INFO - 2024-10-01 10:49:06 --> Router Class Initialized
INFO - 2024-10-01 10:49:06 --> Output Class Initialized
INFO - 2024-10-01 10:49:06 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:06 --> Input Class Initialized
INFO - 2024-10-01 10:49:06 --> Language Class Initialized
INFO - 2024-10-01 10:49:06 --> Language Class Initialized
INFO - 2024-10-01 10:49:06 --> Config Class Initialized
INFO - 2024-10-01 10:49:06 --> Loader Class Initialized
INFO - 2024-10-01 10:49:06 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:06 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:06 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:06 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:06 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:06 --> Controller Class Initialized
INFO - 2024-10-01 10:49:07 --> Helper loaded: cookie_helper
INFO - 2024-10-01 10:49:07 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:07 --> Total execution time: 0.7925
INFO - 2024-10-01 10:49:07 --> Config Class Initialized
INFO - 2024-10-01 10:49:07 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:07 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:07 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:07 --> URI Class Initialized
INFO - 2024-10-01 10:49:07 --> Router Class Initialized
INFO - 2024-10-01 10:49:07 --> Output Class Initialized
INFO - 2024-10-01 10:49:07 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:07 --> Input Class Initialized
INFO - 2024-10-01 10:49:07 --> Language Class Initialized
INFO - 2024-10-01 10:49:07 --> Language Class Initialized
INFO - 2024-10-01 10:49:07 --> Config Class Initialized
INFO - 2024-10-01 10:49:07 --> Loader Class Initialized
INFO - 2024-10-01 10:49:07 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:07 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:07 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:07 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:07 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:07 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-01 10:49:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:07 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:07 --> Total execution time: 0.2881
INFO - 2024-10-01 10:49:10 --> Config Class Initialized
INFO - 2024-10-01 10:49:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:10 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:10 --> URI Class Initialized
INFO - 2024-10-01 10:49:10 --> Router Class Initialized
INFO - 2024-10-01 10:49:10 --> Output Class Initialized
INFO - 2024-10-01 10:49:10 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:10 --> Input Class Initialized
INFO - 2024-10-01 10:49:10 --> Language Class Initialized
INFO - 2024-10-01 10:49:10 --> Language Class Initialized
INFO - 2024-10-01 10:49:10 --> Config Class Initialized
INFO - 2024-10-01 10:49:10 --> Loader Class Initialized
INFO - 2024-10-01 10:49:10 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:10 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:10 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:10 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:10 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:10 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-01 10:49:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:10 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:10 --> Total execution time: 0.0292
INFO - 2024-10-01 10:49:10 --> Config Class Initialized
INFO - 2024-10-01 10:49:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:10 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:10 --> URI Class Initialized
INFO - 2024-10-01 10:49:10 --> Router Class Initialized
INFO - 2024-10-01 10:49:10 --> Output Class Initialized
INFO - 2024-10-01 10:49:10 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:10 --> Input Class Initialized
INFO - 2024-10-01 10:49:10 --> Language Class Initialized
ERROR - 2024-10-01 10:49:10 --> 404 Page Not Found: /index
INFO - 2024-10-01 10:49:10 --> Config Class Initialized
INFO - 2024-10-01 10:49:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:10 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:10 --> URI Class Initialized
INFO - 2024-10-01 10:49:10 --> Router Class Initialized
INFO - 2024-10-01 10:49:10 --> Output Class Initialized
INFO - 2024-10-01 10:49:10 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:10 --> Input Class Initialized
INFO - 2024-10-01 10:49:10 --> Language Class Initialized
INFO - 2024-10-01 10:49:10 --> Language Class Initialized
INFO - 2024-10-01 10:49:10 --> Config Class Initialized
INFO - 2024-10-01 10:49:10 --> Loader Class Initialized
INFO - 2024-10-01 10:49:10 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:10 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:10 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:10 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:10 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:10 --> Controller Class Initialized
INFO - 2024-10-01 10:49:18 --> Config Class Initialized
INFO - 2024-10-01 10:49:18 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:18 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:18 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:18 --> URI Class Initialized
INFO - 2024-10-01 10:49:18 --> Router Class Initialized
INFO - 2024-10-01 10:49:18 --> Output Class Initialized
INFO - 2024-10-01 10:49:18 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:18 --> Input Class Initialized
INFO - 2024-10-01 10:49:18 --> Language Class Initialized
INFO - 2024-10-01 10:49:18 --> Language Class Initialized
INFO - 2024-10-01 10:49:18 --> Config Class Initialized
INFO - 2024-10-01 10:49:18 --> Loader Class Initialized
INFO - 2024-10-01 10:49:18 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:18 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:18 --> Controller Class Initialized
INFO - 2024-10-01 10:49:18 --> Helper loaded: cookie_helper
INFO - 2024-10-01 10:49:18 --> Config Class Initialized
INFO - 2024-10-01 10:49:18 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:18 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:18 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:18 --> URI Class Initialized
INFO - 2024-10-01 10:49:18 --> Router Class Initialized
INFO - 2024-10-01 10:49:18 --> Output Class Initialized
INFO - 2024-10-01 10:49:18 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:18 --> Input Class Initialized
INFO - 2024-10-01 10:49:18 --> Language Class Initialized
INFO - 2024-10-01 10:49:18 --> Language Class Initialized
INFO - 2024-10-01 10:49:18 --> Config Class Initialized
INFO - 2024-10-01 10:49:18 --> Loader Class Initialized
INFO - 2024-10-01 10:49:18 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:18 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:18 --> Controller Class Initialized
INFO - 2024-10-01 10:49:18 --> Config Class Initialized
INFO - 2024-10-01 10:49:18 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:18 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:18 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:18 --> URI Class Initialized
INFO - 2024-10-01 10:49:18 --> Router Class Initialized
INFO - 2024-10-01 10:49:18 --> Output Class Initialized
INFO - 2024-10-01 10:49:18 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:18 --> Input Class Initialized
INFO - 2024-10-01 10:49:18 --> Language Class Initialized
INFO - 2024-10-01 10:49:18 --> Language Class Initialized
INFO - 2024-10-01 10:49:18 --> Config Class Initialized
INFO - 2024-10-01 10:49:18 --> Loader Class Initialized
INFO - 2024-10-01 10:49:18 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:18 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:18 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:18 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 10:49:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:18 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:18 --> Total execution time: 0.1568
INFO - 2024-10-01 10:49:21 --> Config Class Initialized
INFO - 2024-10-01 10:49:21 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:21 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:21 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:21 --> URI Class Initialized
INFO - 2024-10-01 10:49:21 --> Router Class Initialized
INFO - 2024-10-01 10:49:21 --> Output Class Initialized
INFO - 2024-10-01 10:49:21 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:21 --> Input Class Initialized
INFO - 2024-10-01 10:49:21 --> Language Class Initialized
INFO - 2024-10-01 10:49:21 --> Language Class Initialized
INFO - 2024-10-01 10:49:21 --> Config Class Initialized
INFO - 2024-10-01 10:49:21 --> Loader Class Initialized
INFO - 2024-10-01 10:49:21 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:21 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:21 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:21 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:21 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:21 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-01 10:49:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:21 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:21 --> Total execution time: 0.3208
INFO - 2024-10-01 10:49:24 --> Config Class Initialized
INFO - 2024-10-01 10:49:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:24 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:24 --> URI Class Initialized
INFO - 2024-10-01 10:49:24 --> Router Class Initialized
INFO - 2024-10-01 10:49:24 --> Output Class Initialized
INFO - 2024-10-01 10:49:24 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:24 --> Input Class Initialized
INFO - 2024-10-01 10:49:24 --> Language Class Initialized
INFO - 2024-10-01 10:49:24 --> Language Class Initialized
INFO - 2024-10-01 10:49:24 --> Config Class Initialized
INFO - 2024-10-01 10:49:24 --> Loader Class Initialized
INFO - 2024-10-01 10:49:24 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:24 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:24 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:24 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:24 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:24 --> Controller Class Initialized
INFO - 2024-10-01 10:49:25 --> Helper loaded: cookie_helper
INFO - 2024-10-01 10:49:25 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:25 --> Total execution time: 0.2642
INFO - 2024-10-01 10:49:25 --> Config Class Initialized
INFO - 2024-10-01 10:49:25 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:25 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:25 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:25 --> URI Class Initialized
INFO - 2024-10-01 10:49:25 --> Router Class Initialized
INFO - 2024-10-01 10:49:25 --> Output Class Initialized
INFO - 2024-10-01 10:49:25 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:25 --> Input Class Initialized
INFO - 2024-10-01 10:49:25 --> Language Class Initialized
INFO - 2024-10-01 10:49:25 --> Language Class Initialized
INFO - 2024-10-01 10:49:25 --> Config Class Initialized
INFO - 2024-10-01 10:49:25 --> Loader Class Initialized
INFO - 2024-10-01 10:49:25 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:25 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:25 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:25 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:25 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:25 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-01 10:49:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:25 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:25 --> Total execution time: 0.1846
INFO - 2024-10-01 10:49:26 --> Config Class Initialized
INFO - 2024-10-01 10:49:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:26 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:26 --> URI Class Initialized
INFO - 2024-10-01 10:49:26 --> Router Class Initialized
INFO - 2024-10-01 10:49:26 --> Output Class Initialized
INFO - 2024-10-01 10:49:26 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:26 --> Input Class Initialized
INFO - 2024-10-01 10:49:26 --> Language Class Initialized
INFO - 2024-10-01 10:49:26 --> Language Class Initialized
INFO - 2024-10-01 10:49:26 --> Config Class Initialized
INFO - 2024-10-01 10:49:26 --> Loader Class Initialized
INFO - 2024-10-01 10:49:26 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:26 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:26 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:26 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:26 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:26 --> Controller Class Initialized
INFO - 2024-10-01 10:49:27 --> Config Class Initialized
INFO - 2024-10-01 10:49:27 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:27 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:27 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:27 --> URI Class Initialized
INFO - 2024-10-01 10:49:27 --> Router Class Initialized
INFO - 2024-10-01 10:49:27 --> Output Class Initialized
INFO - 2024-10-01 10:49:27 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:27 --> Input Class Initialized
INFO - 2024-10-01 10:49:27 --> Language Class Initialized
INFO - 2024-10-01 10:49:27 --> Language Class Initialized
INFO - 2024-10-01 10:49:27 --> Config Class Initialized
INFO - 2024-10-01 10:49:27 --> Loader Class Initialized
INFO - 2024-10-01 10:49:27 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:27 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:27 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:49:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:27 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:27 --> Total execution time: 0.0522
INFO - 2024-10-01 10:49:27 --> Config Class Initialized
INFO - 2024-10-01 10:49:27 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:27 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:27 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:27 --> URI Class Initialized
INFO - 2024-10-01 10:49:27 --> Router Class Initialized
INFO - 2024-10-01 10:49:27 --> Output Class Initialized
INFO - 2024-10-01 10:49:27 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:27 --> Input Class Initialized
INFO - 2024-10-01 10:49:27 --> Language Class Initialized
INFO - 2024-10-01 10:49:27 --> Language Class Initialized
INFO - 2024-10-01 10:49:27 --> Config Class Initialized
INFO - 2024-10-01 10:49:27 --> Loader Class Initialized
INFO - 2024-10-01 10:49:27 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:27 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:27 --> Config Class Initialized
INFO - 2024-10-01 10:49:27 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:27 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:27 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:27 --> Controller Class Initialized
INFO - 2024-10-01 10:49:27 --> URI Class Initialized
INFO - 2024-10-01 10:49:27 --> Router Class Initialized
INFO - 2024-10-01 10:49:27 --> Output Class Initialized
INFO - 2024-10-01 10:49:27 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:27 --> Input Class Initialized
INFO - 2024-10-01 10:49:27 --> Language Class Initialized
INFO - 2024-10-01 10:49:27 --> Language Class Initialized
INFO - 2024-10-01 10:49:27 --> Config Class Initialized
INFO - 2024-10-01 10:49:27 --> Loader Class Initialized
INFO - 2024-10-01 10:49:27 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:27 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:27 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:27 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:49:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:27 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:27 --> Total execution time: 0.0335
INFO - 2024-10-01 10:49:30 --> Config Class Initialized
INFO - 2024-10-01 10:49:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:30 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:30 --> URI Class Initialized
INFO - 2024-10-01 10:49:30 --> Router Class Initialized
INFO - 2024-10-01 10:49:30 --> Output Class Initialized
INFO - 2024-10-01 10:49:30 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:30 --> Input Class Initialized
INFO - 2024-10-01 10:49:30 --> Language Class Initialized
INFO - 2024-10-01 10:49:30 --> Language Class Initialized
INFO - 2024-10-01 10:49:30 --> Config Class Initialized
INFO - 2024-10-01 10:49:30 --> Loader Class Initialized
INFO - 2024-10-01 10:49:30 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:30 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:30 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:30 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:30 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:30 --> Controller Class Initialized
INFO - 2024-10-01 10:49:30 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:30 --> Total execution time: 0.0381
INFO - 2024-10-01 10:49:32 --> Config Class Initialized
INFO - 2024-10-01 10:49:32 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:32 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:32 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:32 --> URI Class Initialized
INFO - 2024-10-01 10:49:32 --> Router Class Initialized
INFO - 2024-10-01 10:49:32 --> Output Class Initialized
INFO - 2024-10-01 10:49:32 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:32 --> Input Class Initialized
INFO - 2024-10-01 10:49:32 --> Language Class Initialized
INFO - 2024-10-01 10:49:32 --> Language Class Initialized
INFO - 2024-10-01 10:49:32 --> Config Class Initialized
INFO - 2024-10-01 10:49:32 --> Loader Class Initialized
INFO - 2024-10-01 10:49:32 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:32 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:32 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:49:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:32 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:32 --> Total execution time: 0.0338
INFO - 2024-10-01 10:49:32 --> Config Class Initialized
INFO - 2024-10-01 10:49:32 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:32 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:32 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:32 --> URI Class Initialized
INFO - 2024-10-01 10:49:32 --> Router Class Initialized
INFO - 2024-10-01 10:49:32 --> Output Class Initialized
INFO - 2024-10-01 10:49:32 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:32 --> Input Class Initialized
INFO - 2024-10-01 10:49:32 --> Language Class Initialized
INFO - 2024-10-01 10:49:32 --> Language Class Initialized
INFO - 2024-10-01 10:49:32 --> Config Class Initialized
INFO - 2024-10-01 10:49:32 --> Loader Class Initialized
INFO - 2024-10-01 10:49:32 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:32 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:32 --> Controller Class Initialized
INFO - 2024-10-01 10:49:32 --> Config Class Initialized
INFO - 2024-10-01 10:49:32 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:32 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:32 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:32 --> URI Class Initialized
INFO - 2024-10-01 10:49:32 --> Router Class Initialized
INFO - 2024-10-01 10:49:32 --> Output Class Initialized
INFO - 2024-10-01 10:49:32 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:32 --> Input Class Initialized
INFO - 2024-10-01 10:49:32 --> Language Class Initialized
INFO - 2024-10-01 10:49:32 --> Language Class Initialized
INFO - 2024-10-01 10:49:32 --> Config Class Initialized
INFO - 2024-10-01 10:49:32 --> Loader Class Initialized
INFO - 2024-10-01 10:49:32 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:32 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:33 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:33 --> Controller Class Initialized
INFO - 2024-10-01 10:49:33 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:33 --> Total execution time: 0.0369
INFO - 2024-10-01 10:49:37 --> Config Class Initialized
INFO - 2024-10-01 10:49:37 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:37 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:37 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:37 --> URI Class Initialized
INFO - 2024-10-01 10:49:37 --> Router Class Initialized
INFO - 2024-10-01 10:49:37 --> Output Class Initialized
INFO - 2024-10-01 10:49:37 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:37 --> Input Class Initialized
INFO - 2024-10-01 10:49:37 --> Language Class Initialized
INFO - 2024-10-01 10:49:37 --> Config Class Initialized
INFO - 2024-10-01 10:49:37 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:37 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:37 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:37 --> URI Class Initialized
INFO - 2024-10-01 10:49:37 --> Router Class Initialized
INFO - 2024-10-01 10:49:37 --> Output Class Initialized
INFO - 2024-10-01 10:49:37 --> Language Class Initialized
INFO - 2024-10-01 10:49:37 --> Config Class Initialized
INFO - 2024-10-01 10:49:37 --> Loader Class Initialized
INFO - 2024-10-01 10:49:37 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:37 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:37 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:37 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:37 --> Input Class Initialized
INFO - 2024-10-01 10:49:37 --> Language Class Initialized
INFO - 2024-10-01 10:49:37 --> Language Class Initialized
INFO - 2024-10-01 10:49:37 --> Config Class Initialized
INFO - 2024-10-01 10:49:37 --> Loader Class Initialized
INFO - 2024-10-01 10:49:37 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:37 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:37 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:37 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:37 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:37 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:37 --> Controller Class Initialized
INFO - 2024-10-01 10:49:37 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:37 --> Controller Class Initialized
DEBUG - 2024-10-01 10:49:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:49:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:37 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:37 --> Total execution time: 0.1105
DEBUG - 2024-10-01 10:49:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-01 10:49:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:49:37 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:37 --> Total execution time: 0.1827
INFO - 2024-10-01 10:49:40 --> Config Class Initialized
INFO - 2024-10-01 10:49:40 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:49:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:49:40 --> Utf8 Class Initialized
INFO - 2024-10-01 10:49:40 --> URI Class Initialized
INFO - 2024-10-01 10:49:40 --> Router Class Initialized
INFO - 2024-10-01 10:49:40 --> Output Class Initialized
INFO - 2024-10-01 10:49:40 --> Security Class Initialized
DEBUG - 2024-10-01 10:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:49:40 --> Input Class Initialized
INFO - 2024-10-01 10:49:40 --> Language Class Initialized
INFO - 2024-10-01 10:49:40 --> Language Class Initialized
INFO - 2024-10-01 10:49:40 --> Config Class Initialized
INFO - 2024-10-01 10:49:40 --> Loader Class Initialized
INFO - 2024-10-01 10:49:40 --> Helper loaded: url_helper
INFO - 2024-10-01 10:49:40 --> Helper loaded: file_helper
INFO - 2024-10-01 10:49:40 --> Helper loaded: form_helper
INFO - 2024-10-01 10:49:40 --> Helper loaded: my_helper
INFO - 2024-10-01 10:49:40 --> Database Driver Class Initialized
INFO - 2024-10-01 10:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:49:40 --> Controller Class Initialized
ERROR - 2024-10-01 10:49:41 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:49:41 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:49:41 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-01 10:49:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-01 10:49:45 --> Final output sent to browser
DEBUG - 2024-10-01 10:49:45 --> Total execution time: 5.1358
INFO - 2024-10-01 10:50:01 --> Config Class Initialized
INFO - 2024-10-01 10:50:01 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:50:01 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:50:01 --> Utf8 Class Initialized
INFO - 2024-10-01 10:50:01 --> URI Class Initialized
INFO - 2024-10-01 10:50:01 --> Router Class Initialized
INFO - 2024-10-01 10:50:01 --> Output Class Initialized
INFO - 2024-10-01 10:50:01 --> Security Class Initialized
DEBUG - 2024-10-01 10:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:50:01 --> Input Class Initialized
INFO - 2024-10-01 10:50:01 --> Language Class Initialized
INFO - 2024-10-01 10:50:01 --> Language Class Initialized
INFO - 2024-10-01 10:50:01 --> Config Class Initialized
INFO - 2024-10-01 10:50:01 --> Loader Class Initialized
INFO - 2024-10-01 10:50:01 --> Helper loaded: url_helper
INFO - 2024-10-01 10:50:01 --> Helper loaded: file_helper
INFO - 2024-10-01 10:50:01 --> Helper loaded: form_helper
INFO - 2024-10-01 10:50:01 --> Helper loaded: my_helper
INFO - 2024-10-01 10:50:01 --> Database Driver Class Initialized
INFO - 2024-10-01 10:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:50:01 --> Controller Class Initialized
ERROR - 2024-10-01 10:50:01 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:50:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:50:01 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:50:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:50:01 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:50:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-01 10:50:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-01 10:50:09 --> Final output sent to browser
DEBUG - 2024-10-01 10:50:09 --> Total execution time: 8.4293
INFO - 2024-10-01 10:51:20 --> Config Class Initialized
INFO - 2024-10-01 10:51:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:20 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:20 --> URI Class Initialized
INFO - 2024-10-01 10:51:20 --> Router Class Initialized
INFO - 2024-10-01 10:51:20 --> Output Class Initialized
INFO - 2024-10-01 10:51:20 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:20 --> Input Class Initialized
INFO - 2024-10-01 10:51:20 --> Language Class Initialized
INFO - 2024-10-01 10:51:20 --> Language Class Initialized
INFO - 2024-10-01 10:51:20 --> Config Class Initialized
INFO - 2024-10-01 10:51:20 --> Loader Class Initialized
INFO - 2024-10-01 10:51:20 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:20 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:20 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:20 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:20 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:20 --> Controller Class Initialized
DEBUG - 2024-10-01 10:51:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:51:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:51:20 --> Final output sent to browser
DEBUG - 2024-10-01 10:51:20 --> Total execution time: 0.7548
INFO - 2024-10-01 10:51:23 --> Config Class Initialized
INFO - 2024-10-01 10:51:23 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:23 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:23 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:23 --> URI Class Initialized
INFO - 2024-10-01 10:51:23 --> Router Class Initialized
INFO - 2024-10-01 10:51:23 --> Output Class Initialized
INFO - 2024-10-01 10:51:23 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:23 --> Input Class Initialized
INFO - 2024-10-01 10:51:23 --> Language Class Initialized
INFO - 2024-10-01 10:51:23 --> Language Class Initialized
INFO - 2024-10-01 10:51:23 --> Config Class Initialized
INFO - 2024-10-01 10:51:23 --> Loader Class Initialized
INFO - 2024-10-01 10:51:23 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:23 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:23 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:23 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:23 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:23 --> Controller Class Initialized
DEBUG - 2024-10-01 10:51:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:51:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:51:23 --> Final output sent to browser
DEBUG - 2024-10-01 10:51:23 --> Total execution time: 0.6829
INFO - 2024-10-01 10:51:24 --> Config Class Initialized
INFO - 2024-10-01 10:51:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:24 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:24 --> URI Class Initialized
INFO - 2024-10-01 10:51:24 --> Router Class Initialized
INFO - 2024-10-01 10:51:24 --> Output Class Initialized
INFO - 2024-10-01 10:51:24 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:24 --> Input Class Initialized
INFO - 2024-10-01 10:51:24 --> Language Class Initialized
INFO - 2024-10-01 10:51:24 --> Language Class Initialized
INFO - 2024-10-01 10:51:24 --> Config Class Initialized
INFO - 2024-10-01 10:51:24 --> Loader Class Initialized
INFO - 2024-10-01 10:51:24 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:24 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:24 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:24 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:24 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:24 --> Controller Class Initialized
INFO - 2024-10-01 10:51:25 --> Config Class Initialized
INFO - 2024-10-01 10:51:25 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:25 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:25 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:25 --> URI Class Initialized
INFO - 2024-10-01 10:51:25 --> Router Class Initialized
INFO - 2024-10-01 10:51:25 --> Output Class Initialized
INFO - 2024-10-01 10:51:25 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:25 --> Input Class Initialized
INFO - 2024-10-01 10:51:25 --> Language Class Initialized
INFO - 2024-10-01 10:51:25 --> Language Class Initialized
INFO - 2024-10-01 10:51:25 --> Config Class Initialized
INFO - 2024-10-01 10:51:25 --> Loader Class Initialized
INFO - 2024-10-01 10:51:25 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:25 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:25 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:25 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:26 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:26 --> Controller Class Initialized
DEBUG - 2024-10-01 10:51:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-01 10:51:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:51:26 --> Final output sent to browser
DEBUG - 2024-10-01 10:51:26 --> Total execution time: 0.4346
INFO - 2024-10-01 10:51:38 --> Config Class Initialized
INFO - 2024-10-01 10:51:38 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:38 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:38 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:38 --> URI Class Initialized
INFO - 2024-10-01 10:51:38 --> Router Class Initialized
INFO - 2024-10-01 10:51:38 --> Output Class Initialized
INFO - 2024-10-01 10:51:38 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:38 --> Input Class Initialized
INFO - 2024-10-01 10:51:38 --> Language Class Initialized
INFO - 2024-10-01 10:51:38 --> Language Class Initialized
INFO - 2024-10-01 10:51:38 --> Config Class Initialized
INFO - 2024-10-01 10:51:38 --> Loader Class Initialized
INFO - 2024-10-01 10:51:38 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:38 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:38 --> Controller Class Initialized
INFO - 2024-10-01 10:51:38 --> Config Class Initialized
INFO - 2024-10-01 10:51:38 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:38 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:38 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:38 --> URI Class Initialized
INFO - 2024-10-01 10:51:38 --> Router Class Initialized
INFO - 2024-10-01 10:51:38 --> Output Class Initialized
INFO - 2024-10-01 10:51:38 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:38 --> Input Class Initialized
INFO - 2024-10-01 10:51:38 --> Language Class Initialized
INFO - 2024-10-01 10:51:38 --> Language Class Initialized
INFO - 2024-10-01 10:51:38 --> Config Class Initialized
INFO - 2024-10-01 10:51:38 --> Loader Class Initialized
INFO - 2024-10-01 10:51:38 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:38 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:38 --> Controller Class Initialized
DEBUG - 2024-10-01 10:51:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:51:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:51:38 --> Final output sent to browser
DEBUG - 2024-10-01 10:51:38 --> Total execution time: 0.0469
INFO - 2024-10-01 10:51:38 --> Config Class Initialized
INFO - 2024-10-01 10:51:38 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:51:38 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:51:38 --> Utf8 Class Initialized
INFO - 2024-10-01 10:51:38 --> URI Class Initialized
INFO - 2024-10-01 10:51:38 --> Router Class Initialized
INFO - 2024-10-01 10:51:38 --> Output Class Initialized
INFO - 2024-10-01 10:51:38 --> Security Class Initialized
DEBUG - 2024-10-01 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:51:38 --> Input Class Initialized
INFO - 2024-10-01 10:51:38 --> Language Class Initialized
INFO - 2024-10-01 10:51:38 --> Language Class Initialized
INFO - 2024-10-01 10:51:38 --> Config Class Initialized
INFO - 2024-10-01 10:51:38 --> Loader Class Initialized
INFO - 2024-10-01 10:51:38 --> Helper loaded: url_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: file_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: form_helper
INFO - 2024-10-01 10:51:38 --> Helper loaded: my_helper
INFO - 2024-10-01 10:51:38 --> Database Driver Class Initialized
INFO - 2024-10-01 10:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:51:38 --> Controller Class Initialized
INFO - 2024-10-01 10:53:35 --> Config Class Initialized
INFO - 2024-10-01 10:53:35 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:53:35 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:53:35 --> Utf8 Class Initialized
INFO - 2024-10-01 10:53:35 --> URI Class Initialized
INFO - 2024-10-01 10:53:35 --> Router Class Initialized
INFO - 2024-10-01 10:53:35 --> Output Class Initialized
INFO - 2024-10-01 10:53:35 --> Security Class Initialized
DEBUG - 2024-10-01 10:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:53:35 --> Input Class Initialized
INFO - 2024-10-01 10:53:35 --> Language Class Initialized
INFO - 2024-10-01 10:53:35 --> Language Class Initialized
INFO - 2024-10-01 10:53:35 --> Config Class Initialized
INFO - 2024-10-01 10:53:35 --> Loader Class Initialized
INFO - 2024-10-01 10:53:35 --> Helper loaded: url_helper
INFO - 2024-10-01 10:53:35 --> Helper loaded: file_helper
INFO - 2024-10-01 10:53:35 --> Helper loaded: form_helper
INFO - 2024-10-01 10:53:35 --> Helper loaded: my_helper
INFO - 2024-10-01 10:53:35 --> Database Driver Class Initialized
INFO - 2024-10-01 10:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:53:35 --> Controller Class Initialized
INFO - 2024-10-01 10:53:35 --> Final output sent to browser
DEBUG - 2024-10-01 10:53:35 --> Total execution time: 0.2361
INFO - 2024-10-01 10:57:26 --> Config Class Initialized
INFO - 2024-10-01 10:57:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:57:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:57:26 --> Utf8 Class Initialized
INFO - 2024-10-01 10:57:26 --> URI Class Initialized
INFO - 2024-10-01 10:57:26 --> Router Class Initialized
INFO - 2024-10-01 10:57:26 --> Output Class Initialized
INFO - 2024-10-01 10:57:26 --> Security Class Initialized
DEBUG - 2024-10-01 10:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:57:26 --> Input Class Initialized
INFO - 2024-10-01 10:57:26 --> Language Class Initialized
INFO - 2024-10-01 10:57:26 --> Language Class Initialized
INFO - 2024-10-01 10:57:26 --> Config Class Initialized
INFO - 2024-10-01 10:57:26 --> Loader Class Initialized
INFO - 2024-10-01 10:57:26 --> Helper loaded: url_helper
INFO - 2024-10-01 10:57:26 --> Helper loaded: file_helper
INFO - 2024-10-01 10:57:26 --> Helper loaded: form_helper
INFO - 2024-10-01 10:57:26 --> Helper loaded: my_helper
INFO - 2024-10-01 10:57:26 --> Database Driver Class Initialized
INFO - 2024-10-01 10:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:57:26 --> Controller Class Initialized
DEBUG - 2024-10-01 10:57:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-01 10:57:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:57:26 --> Final output sent to browser
DEBUG - 2024-10-01 10:57:26 --> Total execution time: 0.0492
INFO - 2024-10-01 10:57:30 --> Config Class Initialized
INFO - 2024-10-01 10:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:57:30 --> Utf8 Class Initialized
INFO - 2024-10-01 10:57:30 --> URI Class Initialized
INFO - 2024-10-01 10:57:30 --> Router Class Initialized
INFO - 2024-10-01 10:57:30 --> Output Class Initialized
INFO - 2024-10-01 10:57:30 --> Security Class Initialized
DEBUG - 2024-10-01 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:57:30 --> Input Class Initialized
INFO - 2024-10-01 10:57:30 --> Language Class Initialized
INFO - 2024-10-01 10:57:30 --> Language Class Initialized
INFO - 2024-10-01 10:57:30 --> Config Class Initialized
INFO - 2024-10-01 10:57:30 --> Loader Class Initialized
INFO - 2024-10-01 10:57:30 --> Helper loaded: url_helper
INFO - 2024-10-01 10:57:30 --> Helper loaded: file_helper
INFO - 2024-10-01 10:57:30 --> Helper loaded: form_helper
INFO - 2024-10-01 10:57:30 --> Helper loaded: my_helper
INFO - 2024-10-01 10:57:30 --> Database Driver Class Initialized
INFO - 2024-10-01 10:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:57:30 --> Controller Class Initialized
ERROR - 2024-10-01 10:57:30 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:57:30 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:57:30 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:57:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-01 10:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-01 10:57:33 --> Final output sent to browser
DEBUG - 2024-10-01 10:57:33 --> Total execution time: 2.6738
INFO - 2024-10-01 10:57:56 --> Config Class Initialized
INFO - 2024-10-01 10:57:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:57:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:57:56 --> Utf8 Class Initialized
INFO - 2024-10-01 10:57:56 --> URI Class Initialized
INFO - 2024-10-01 10:57:56 --> Router Class Initialized
INFO - 2024-10-01 10:57:56 --> Output Class Initialized
INFO - 2024-10-01 10:57:56 --> Security Class Initialized
DEBUG - 2024-10-01 10:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:57:56 --> Input Class Initialized
INFO - 2024-10-01 10:57:56 --> Language Class Initialized
INFO - 2024-10-01 10:57:56 --> Language Class Initialized
INFO - 2024-10-01 10:57:56 --> Config Class Initialized
INFO - 2024-10-01 10:57:56 --> Loader Class Initialized
INFO - 2024-10-01 10:57:56 --> Helper loaded: url_helper
INFO - 2024-10-01 10:57:56 --> Helper loaded: file_helper
INFO - 2024-10-01 10:57:56 --> Helper loaded: form_helper
INFO - 2024-10-01 10:57:56 --> Helper loaded: my_helper
INFO - 2024-10-01 10:57:56 --> Database Driver Class Initialized
INFO - 2024-10-01 10:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:57:56 --> Controller Class Initialized
DEBUG - 2024-10-01 10:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:57:56 --> Final output sent to browser
DEBUG - 2024-10-01 10:57:56 --> Total execution time: 0.0298
INFO - 2024-10-01 10:57:59 --> Config Class Initialized
INFO - 2024-10-01 10:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:57:59 --> Utf8 Class Initialized
INFO - 2024-10-01 10:57:59 --> URI Class Initialized
INFO - 2024-10-01 10:57:59 --> Router Class Initialized
INFO - 2024-10-01 10:57:59 --> Output Class Initialized
INFO - 2024-10-01 10:57:59 --> Security Class Initialized
DEBUG - 2024-10-01 10:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:57:59 --> Input Class Initialized
INFO - 2024-10-01 10:57:59 --> Language Class Initialized
INFO - 2024-10-01 10:57:59 --> Language Class Initialized
INFO - 2024-10-01 10:57:59 --> Config Class Initialized
INFO - 2024-10-01 10:57:59 --> Loader Class Initialized
INFO - 2024-10-01 10:57:59 --> Helper loaded: url_helper
INFO - 2024-10-01 10:57:59 --> Helper loaded: file_helper
INFO - 2024-10-01 10:57:59 --> Helper loaded: form_helper
INFO - 2024-10-01 10:57:59 --> Helper loaded: my_helper
INFO - 2024-10-01 10:57:59 --> Database Driver Class Initialized
INFO - 2024-10-01 10:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:57:59 --> Controller Class Initialized
DEBUG - 2024-10-01 10:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:57:59 --> Final output sent to browser
DEBUG - 2024-10-01 10:57:59 --> Total execution time: 0.0306
INFO - 2024-10-01 10:57:59 --> Config Class Initialized
INFO - 2024-10-01 10:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:57:59 --> Utf8 Class Initialized
INFO - 2024-10-01 10:57:59 --> URI Class Initialized
INFO - 2024-10-01 10:57:59 --> Router Class Initialized
INFO - 2024-10-01 10:57:59 --> Output Class Initialized
INFO - 2024-10-01 10:57:59 --> Security Class Initialized
DEBUG - 2024-10-01 10:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:57:59 --> Input Class Initialized
INFO - 2024-10-01 10:57:59 --> Language Class Initialized
INFO - 2024-10-01 10:57:59 --> Language Class Initialized
INFO - 2024-10-01 10:57:59 --> Config Class Initialized
INFO - 2024-10-01 10:57:59 --> Loader Class Initialized
INFO - 2024-10-01 10:57:59 --> Helper loaded: url_helper
INFO - 2024-10-01 10:57:59 --> Helper loaded: file_helper
INFO - 2024-10-01 10:57:59 --> Helper loaded: form_helper
INFO - 2024-10-01 10:57:59 --> Helper loaded: my_helper
INFO - 2024-10-01 10:57:59 --> Database Driver Class Initialized
INFO - 2024-10-01 10:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:57:59 --> Controller Class Initialized
INFO - 2024-10-01 10:58:00 --> Config Class Initialized
INFO - 2024-10-01 10:58:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:00 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:00 --> URI Class Initialized
INFO - 2024-10-01 10:58:00 --> Router Class Initialized
INFO - 2024-10-01 10:58:00 --> Output Class Initialized
INFO - 2024-10-01 10:58:00 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:00 --> Input Class Initialized
INFO - 2024-10-01 10:58:00 --> Language Class Initialized
INFO - 2024-10-01 10:58:00 --> Language Class Initialized
INFO - 2024-10-01 10:58:00 --> Config Class Initialized
INFO - 2024-10-01 10:58:00 --> Loader Class Initialized
INFO - 2024-10-01 10:58:00 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:00 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:00 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:00 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:00 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:00 --> Controller Class Initialized
DEBUG - 2024-10-01 10:58:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-01 10:58:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:58:00 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:00 --> Total execution time: 0.0329
INFO - 2024-10-01 10:58:09 --> Config Class Initialized
INFO - 2024-10-01 10:58:09 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:09 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:09 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:09 --> URI Class Initialized
INFO - 2024-10-01 10:58:09 --> Router Class Initialized
INFO - 2024-10-01 10:58:09 --> Output Class Initialized
INFO - 2024-10-01 10:58:09 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:09 --> Input Class Initialized
INFO - 2024-10-01 10:58:09 --> Language Class Initialized
INFO - 2024-10-01 10:58:09 --> Language Class Initialized
INFO - 2024-10-01 10:58:09 --> Config Class Initialized
INFO - 2024-10-01 10:58:09 --> Loader Class Initialized
INFO - 2024-10-01 10:58:09 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:09 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:09 --> Controller Class Initialized
INFO - 2024-10-01 10:58:09 --> Config Class Initialized
INFO - 2024-10-01 10:58:09 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:09 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:09 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:09 --> URI Class Initialized
INFO - 2024-10-01 10:58:09 --> Router Class Initialized
INFO - 2024-10-01 10:58:09 --> Output Class Initialized
INFO - 2024-10-01 10:58:09 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:09 --> Input Class Initialized
INFO - 2024-10-01 10:58:09 --> Language Class Initialized
INFO - 2024-10-01 10:58:09 --> Language Class Initialized
INFO - 2024-10-01 10:58:09 --> Config Class Initialized
INFO - 2024-10-01 10:58:09 --> Loader Class Initialized
INFO - 2024-10-01 10:58:09 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:09 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:09 --> Controller Class Initialized
DEBUG - 2024-10-01 10:58:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:58:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:58:09 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:09 --> Total execution time: 0.0313
INFO - 2024-10-01 10:58:09 --> Config Class Initialized
INFO - 2024-10-01 10:58:09 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:09 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:09 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:09 --> URI Class Initialized
INFO - 2024-10-01 10:58:09 --> Router Class Initialized
INFO - 2024-10-01 10:58:09 --> Output Class Initialized
INFO - 2024-10-01 10:58:09 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:09 --> Input Class Initialized
INFO - 2024-10-01 10:58:09 --> Language Class Initialized
INFO - 2024-10-01 10:58:09 --> Language Class Initialized
INFO - 2024-10-01 10:58:09 --> Config Class Initialized
INFO - 2024-10-01 10:58:09 --> Loader Class Initialized
INFO - 2024-10-01 10:58:09 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:09 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:09 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:09 --> Controller Class Initialized
INFO - 2024-10-01 10:58:14 --> Config Class Initialized
INFO - 2024-10-01 10:58:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:14 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:14 --> URI Class Initialized
INFO - 2024-10-01 10:58:14 --> Router Class Initialized
INFO - 2024-10-01 10:58:14 --> Output Class Initialized
INFO - 2024-10-01 10:58:14 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:14 --> Input Class Initialized
INFO - 2024-10-01 10:58:14 --> Language Class Initialized
INFO - 2024-10-01 10:58:14 --> Language Class Initialized
INFO - 2024-10-01 10:58:14 --> Config Class Initialized
INFO - 2024-10-01 10:58:14 --> Loader Class Initialized
INFO - 2024-10-01 10:58:14 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:14 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:14 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:14 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:14 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:14 --> Controller Class Initialized
INFO - 2024-10-01 10:58:14 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:14 --> Total execution time: 0.0339
INFO - 2024-10-01 10:58:26 --> Config Class Initialized
INFO - 2024-10-01 10:58:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:26 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:26 --> URI Class Initialized
INFO - 2024-10-01 10:58:26 --> Router Class Initialized
INFO - 2024-10-01 10:58:26 --> Output Class Initialized
INFO - 2024-10-01 10:58:26 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:26 --> Input Class Initialized
INFO - 2024-10-01 10:58:26 --> Language Class Initialized
INFO - 2024-10-01 10:58:26 --> Language Class Initialized
INFO - 2024-10-01 10:58:26 --> Config Class Initialized
INFO - 2024-10-01 10:58:26 --> Loader Class Initialized
INFO - 2024-10-01 10:58:26 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:26 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:26 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:26 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:26 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:26 --> Controller Class Initialized
DEBUG - 2024-10-01 10:58:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-01 10:58:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:58:26 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:26 --> Total execution time: 0.0352
INFO - 2024-10-01 10:58:28 --> Config Class Initialized
INFO - 2024-10-01 10:58:28 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:28 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:28 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:28 --> URI Class Initialized
INFO - 2024-10-01 10:58:28 --> Router Class Initialized
INFO - 2024-10-01 10:58:28 --> Output Class Initialized
INFO - 2024-10-01 10:58:28 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:28 --> Input Class Initialized
INFO - 2024-10-01 10:58:28 --> Language Class Initialized
INFO - 2024-10-01 10:58:28 --> Language Class Initialized
INFO - 2024-10-01 10:58:28 --> Config Class Initialized
INFO - 2024-10-01 10:58:28 --> Loader Class Initialized
INFO - 2024-10-01 10:58:28 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:28 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:28 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:28 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:28 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:28 --> Controller Class Initialized
ERROR - 2024-10-01 10:58:28 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:58:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:58:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-01 10:58:28 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:58:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:58:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-01 10:58:28 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:58:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-01 10:58:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-01 10:58:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-01 10:58:32 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:32 --> Total execution time: 4.0931
INFO - 2024-10-01 10:58:51 --> Config Class Initialized
INFO - 2024-10-01 10:58:51 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:51 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:51 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:51 --> URI Class Initialized
INFO - 2024-10-01 10:58:51 --> Router Class Initialized
INFO - 2024-10-01 10:58:51 --> Output Class Initialized
INFO - 2024-10-01 10:58:51 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:51 --> Input Class Initialized
INFO - 2024-10-01 10:58:51 --> Language Class Initialized
INFO - 2024-10-01 10:58:51 --> Language Class Initialized
INFO - 2024-10-01 10:58:51 --> Config Class Initialized
INFO - 2024-10-01 10:58:51 --> Loader Class Initialized
INFO - 2024-10-01 10:58:51 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:51 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:51 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:51 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:52 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:52 --> Controller Class Initialized
DEBUG - 2024-10-01 10:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 10:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:58:52 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:52 --> Total execution time: 0.0280
INFO - 2024-10-01 10:58:53 --> Config Class Initialized
INFO - 2024-10-01 10:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:53 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:53 --> URI Class Initialized
INFO - 2024-10-01 10:58:53 --> Router Class Initialized
INFO - 2024-10-01 10:58:53 --> Output Class Initialized
INFO - 2024-10-01 10:58:53 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:53 --> Input Class Initialized
INFO - 2024-10-01 10:58:53 --> Language Class Initialized
INFO - 2024-10-01 10:58:53 --> Language Class Initialized
INFO - 2024-10-01 10:58:53 --> Config Class Initialized
INFO - 2024-10-01 10:58:53 --> Loader Class Initialized
INFO - 2024-10-01 10:58:53 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:53 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:53 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:53 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:53 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:53 --> Controller Class Initialized
DEBUG - 2024-10-01 10:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 10:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 10:58:53 --> Final output sent to browser
DEBUG - 2024-10-01 10:58:53 --> Total execution time: 0.0368
INFO - 2024-10-01 10:58:53 --> Config Class Initialized
INFO - 2024-10-01 10:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-01 10:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-01 10:58:53 --> Utf8 Class Initialized
INFO - 2024-10-01 10:58:53 --> URI Class Initialized
INFO - 2024-10-01 10:58:53 --> Router Class Initialized
INFO - 2024-10-01 10:58:53 --> Output Class Initialized
INFO - 2024-10-01 10:58:53 --> Security Class Initialized
DEBUG - 2024-10-01 10:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 10:58:53 --> Input Class Initialized
INFO - 2024-10-01 10:58:53 --> Language Class Initialized
INFO - 2024-10-01 10:58:53 --> Language Class Initialized
INFO - 2024-10-01 10:58:53 --> Config Class Initialized
INFO - 2024-10-01 10:58:53 --> Loader Class Initialized
INFO - 2024-10-01 10:58:53 --> Helper loaded: url_helper
INFO - 2024-10-01 10:58:53 --> Helper loaded: file_helper
INFO - 2024-10-01 10:58:53 --> Helper loaded: form_helper
INFO - 2024-10-01 10:58:53 --> Helper loaded: my_helper
INFO - 2024-10-01 10:58:53 --> Database Driver Class Initialized
INFO - 2024-10-01 10:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 10:58:53 --> Controller Class Initialized
INFO - 2024-10-01 12:00:49 --> Config Class Initialized
INFO - 2024-10-01 12:00:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:00:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:00:49 --> Utf8 Class Initialized
INFO - 2024-10-01 12:00:49 --> URI Class Initialized
INFO - 2024-10-01 12:00:49 --> Router Class Initialized
INFO - 2024-10-01 12:00:49 --> Output Class Initialized
INFO - 2024-10-01 12:00:49 --> Security Class Initialized
DEBUG - 2024-10-01 12:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:00:49 --> Input Class Initialized
INFO - 2024-10-01 12:00:49 --> Language Class Initialized
INFO - 2024-10-01 12:00:49 --> Language Class Initialized
INFO - 2024-10-01 12:00:49 --> Config Class Initialized
INFO - 2024-10-01 12:00:49 --> Loader Class Initialized
INFO - 2024-10-01 12:00:49 --> Helper loaded: url_helper
INFO - 2024-10-01 12:00:49 --> Helper loaded: file_helper
INFO - 2024-10-01 12:00:49 --> Helper loaded: form_helper
INFO - 2024-10-01 12:00:49 --> Helper loaded: my_helper
INFO - 2024-10-01 12:00:49 --> Database Driver Class Initialized
INFO - 2024-10-01 12:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:00:49 --> Controller Class Initialized
INFO - 2024-10-01 12:00:49 --> Helper loaded: cookie_helper
INFO - 2024-10-01 12:00:49 --> Final output sent to browser
DEBUG - 2024-10-01 12:00:49 --> Total execution time: 0.7437
INFO - 2024-10-01 12:00:50 --> Config Class Initialized
INFO - 2024-10-01 12:00:50 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:00:50 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:00:50 --> Utf8 Class Initialized
INFO - 2024-10-01 12:00:50 --> URI Class Initialized
INFO - 2024-10-01 12:00:50 --> Router Class Initialized
INFO - 2024-10-01 12:00:50 --> Output Class Initialized
INFO - 2024-10-01 12:00:50 --> Security Class Initialized
DEBUG - 2024-10-01 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:00:50 --> Input Class Initialized
INFO - 2024-10-01 12:00:50 --> Language Class Initialized
INFO - 2024-10-01 12:00:50 --> Language Class Initialized
INFO - 2024-10-01 12:00:50 --> Config Class Initialized
INFO - 2024-10-01 12:00:50 --> Loader Class Initialized
INFO - 2024-10-01 12:00:50 --> Helper loaded: url_helper
INFO - 2024-10-01 12:00:50 --> Helper loaded: file_helper
INFO - 2024-10-01 12:00:50 --> Helper loaded: form_helper
INFO - 2024-10-01 12:00:50 --> Helper loaded: my_helper
INFO - 2024-10-01 12:00:50 --> Database Driver Class Initialized
INFO - 2024-10-01 12:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:00:50 --> Controller Class Initialized
INFO - 2024-10-01 12:00:50 --> Helper loaded: cookie_helper
INFO - 2024-10-01 12:00:50 --> Config Class Initialized
INFO - 2024-10-01 12:00:50 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:00:50 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:00:50 --> Utf8 Class Initialized
INFO - 2024-10-01 12:00:50 --> URI Class Initialized
INFO - 2024-10-01 12:00:51 --> Router Class Initialized
INFO - 2024-10-01 12:00:51 --> Output Class Initialized
INFO - 2024-10-01 12:00:51 --> Security Class Initialized
DEBUG - 2024-10-01 12:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:00:51 --> Input Class Initialized
INFO - 2024-10-01 12:00:51 --> Language Class Initialized
INFO - 2024-10-01 12:00:51 --> Language Class Initialized
INFO - 2024-10-01 12:00:51 --> Config Class Initialized
INFO - 2024-10-01 12:00:51 --> Loader Class Initialized
INFO - 2024-10-01 12:00:51 --> Helper loaded: url_helper
INFO - 2024-10-01 12:00:51 --> Helper loaded: file_helper
INFO - 2024-10-01 12:00:51 --> Helper loaded: form_helper
INFO - 2024-10-01 12:00:51 --> Helper loaded: my_helper
INFO - 2024-10-01 12:00:51 --> Database Driver Class Initialized
INFO - 2024-10-01 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:00:51 --> Controller Class Initialized
DEBUG - 2024-10-01 12:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-01 12:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 12:00:51 --> Final output sent to browser
DEBUG - 2024-10-01 12:00:51 --> Total execution time: 0.2800
INFO - 2024-10-01 12:01:02 --> Config Class Initialized
INFO - 2024-10-01 12:01:02 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:01:02 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:01:02 --> Utf8 Class Initialized
INFO - 2024-10-01 12:01:02 --> URI Class Initialized
INFO - 2024-10-01 12:01:02 --> Router Class Initialized
INFO - 2024-10-01 12:01:02 --> Output Class Initialized
INFO - 2024-10-01 12:01:02 --> Security Class Initialized
DEBUG - 2024-10-01 12:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:01:02 --> Input Class Initialized
INFO - 2024-10-01 12:01:02 --> Language Class Initialized
INFO - 2024-10-01 12:01:02 --> Language Class Initialized
INFO - 2024-10-01 12:01:02 --> Config Class Initialized
INFO - 2024-10-01 12:01:02 --> Loader Class Initialized
INFO - 2024-10-01 12:01:02 --> Helper loaded: url_helper
INFO - 2024-10-01 12:01:02 --> Helper loaded: file_helper
INFO - 2024-10-01 12:01:02 --> Helper loaded: form_helper
INFO - 2024-10-01 12:01:02 --> Helper loaded: my_helper
INFO - 2024-10-01 12:01:02 --> Database Driver Class Initialized
INFO - 2024-10-01 12:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:01:02 --> Controller Class Initialized
ERROR - 2024-10-01 12:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-01 12:01:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-01 12:01:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-01 12:01:07 --> Final output sent to browser
DEBUG - 2024-10-01 12:01:07 --> Total execution time: 4.8791
INFO - 2024-10-01 12:01:43 --> Config Class Initialized
INFO - 2024-10-01 12:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:01:43 --> Utf8 Class Initialized
INFO - 2024-10-01 12:01:43 --> URI Class Initialized
INFO - 2024-10-01 12:01:43 --> Router Class Initialized
INFO - 2024-10-01 12:01:43 --> Output Class Initialized
INFO - 2024-10-01 12:01:43 --> Security Class Initialized
DEBUG - 2024-10-01 12:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:01:43 --> Input Class Initialized
INFO - 2024-10-01 12:01:43 --> Language Class Initialized
INFO - 2024-10-01 12:01:43 --> Language Class Initialized
INFO - 2024-10-01 12:01:43 --> Config Class Initialized
INFO - 2024-10-01 12:01:43 --> Loader Class Initialized
INFO - 2024-10-01 12:01:43 --> Helper loaded: url_helper
INFO - 2024-10-01 12:01:43 --> Helper loaded: file_helper
INFO - 2024-10-01 12:01:43 --> Helper loaded: form_helper
INFO - 2024-10-01 12:01:43 --> Helper loaded: my_helper
INFO - 2024-10-01 12:01:43 --> Database Driver Class Initialized
INFO - 2024-10-01 12:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:01:43 --> Controller Class Initialized
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-01 12:01:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-01 12:01:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-01 12:01:49 --> Final output sent to browser
DEBUG - 2024-10-01 12:01:49 --> Total execution time: 5.9510
INFO - 2024-10-01 12:28:18 --> Config Class Initialized
INFO - 2024-10-01 12:28:18 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:28:18 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:28:18 --> Utf8 Class Initialized
INFO - 2024-10-01 12:28:18 --> URI Class Initialized
DEBUG - 2024-10-01 12:28:18 --> No URI present. Default controller set.
INFO - 2024-10-01 12:28:18 --> Router Class Initialized
INFO - 2024-10-01 12:28:18 --> Output Class Initialized
INFO - 2024-10-01 12:28:18 --> Security Class Initialized
DEBUG - 2024-10-01 12:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:28:18 --> Input Class Initialized
INFO - 2024-10-01 12:28:18 --> Language Class Initialized
INFO - 2024-10-01 12:28:18 --> Language Class Initialized
INFO - 2024-10-01 12:28:18 --> Config Class Initialized
INFO - 2024-10-01 12:28:18 --> Loader Class Initialized
INFO - 2024-10-01 12:28:18 --> Helper loaded: url_helper
INFO - 2024-10-01 12:28:18 --> Helper loaded: file_helper
INFO - 2024-10-01 12:28:18 --> Helper loaded: form_helper
INFO - 2024-10-01 12:28:18 --> Helper loaded: my_helper
INFO - 2024-10-01 12:28:18 --> Database Driver Class Initialized
INFO - 2024-10-01 12:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:28:18 --> Controller Class Initialized
INFO - 2024-10-01 12:28:18 --> Config Class Initialized
INFO - 2024-10-01 12:28:18 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:28:18 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:28:18 --> Utf8 Class Initialized
INFO - 2024-10-01 12:28:18 --> URI Class Initialized
INFO - 2024-10-01 12:28:18 --> Router Class Initialized
INFO - 2024-10-01 12:28:18 --> Output Class Initialized
INFO - 2024-10-01 12:28:18 --> Security Class Initialized
DEBUG - 2024-10-01 12:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:28:18 --> Input Class Initialized
INFO - 2024-10-01 12:28:18 --> Language Class Initialized
INFO - 2024-10-01 12:28:18 --> Language Class Initialized
INFO - 2024-10-01 12:28:18 --> Config Class Initialized
INFO - 2024-10-01 12:28:18 --> Loader Class Initialized
INFO - 2024-10-01 12:28:18 --> Helper loaded: url_helper
INFO - 2024-10-01 12:28:18 --> Helper loaded: file_helper
INFO - 2024-10-01 12:28:18 --> Helper loaded: form_helper
INFO - 2024-10-01 12:28:18 --> Helper loaded: my_helper
INFO - 2024-10-01 12:28:19 --> Database Driver Class Initialized
INFO - 2024-10-01 12:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 12:28:19 --> Controller Class Initialized
DEBUG - 2024-10-01 12:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 12:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 12:28:19 --> Final output sent to browser
DEBUG - 2024-10-01 12:28:19 --> Total execution time: 0.7064
INFO - 2024-10-01 12:28:45 --> Config Class Initialized
INFO - 2024-10-01 12:28:45 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:28:45 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:28:45 --> Utf8 Class Initialized
INFO - 2024-10-01 12:28:46 --> URI Class Initialized
INFO - 2024-10-01 12:28:46 --> Router Class Initialized
INFO - 2024-10-01 12:28:46 --> Output Class Initialized
INFO - 2024-10-01 12:28:46 --> Security Class Initialized
DEBUG - 2024-10-01 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:28:46 --> Input Class Initialized
INFO - 2024-10-01 12:28:46 --> Language Class Initialized
INFO - 2024-10-01 12:28:46 --> Language Class Initialized
INFO - 2024-10-01 12:28:46 --> Config Class Initialized
INFO - 2024-10-01 12:28:46 --> Loader Class Initialized
INFO - 2024-10-01 12:28:46 --> Helper loaded: url_helper
INFO - 2024-10-01 12:28:46 --> Helper loaded: file_helper
INFO - 2024-10-01 12:28:46 --> Helper loaded: form_helper
INFO - 2024-10-01 12:28:46 --> Helper loaded: my_helper
INFO - 2024-10-01 12:28:46 --> Database Driver Class Initialized
ERROR - 2024-10-01 12:28:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-10-01 12:28:46 --> Unable to connect to the database
INFO - 2024-10-01 12:28:46 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-01 12:28:57 --> Config Class Initialized
INFO - 2024-10-01 12:28:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 12:28:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 12:28:57 --> Utf8 Class Initialized
INFO - 2024-10-01 12:28:57 --> URI Class Initialized
INFO - 2024-10-01 12:28:57 --> Router Class Initialized
INFO - 2024-10-01 12:28:57 --> Output Class Initialized
INFO - 2024-10-01 12:28:57 --> Security Class Initialized
DEBUG - 2024-10-01 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 12:28:57 --> Input Class Initialized
INFO - 2024-10-01 12:28:57 --> Language Class Initialized
INFO - 2024-10-01 12:28:57 --> Language Class Initialized
INFO - 2024-10-01 12:28:57 --> Config Class Initialized
INFO - 2024-10-01 12:28:57 --> Loader Class Initialized
INFO - 2024-10-01 12:28:57 --> Helper loaded: url_helper
INFO - 2024-10-01 12:28:57 --> Helper loaded: file_helper
INFO - 2024-10-01 12:28:57 --> Helper loaded: form_helper
INFO - 2024-10-01 12:28:57 --> Helper loaded: my_helper
INFO - 2024-10-01 12:28:57 --> Database Driver Class Initialized
ERROR - 2024-10-01 12:28:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-10-01 12:28:57 --> Unable to connect to the database
INFO - 2024-10-01 12:28:57 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-01 13:54:50 --> Config Class Initialized
INFO - 2024-10-01 13:54:50 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:54:50 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:54:50 --> Utf8 Class Initialized
INFO - 2024-10-01 13:54:50 --> URI Class Initialized
DEBUG - 2024-10-01 13:54:50 --> No URI present. Default controller set.
INFO - 2024-10-01 13:54:50 --> Router Class Initialized
INFO - 2024-10-01 13:54:50 --> Output Class Initialized
INFO - 2024-10-01 13:54:50 --> Security Class Initialized
DEBUG - 2024-10-01 13:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:54:50 --> Input Class Initialized
INFO - 2024-10-01 13:54:50 --> Language Class Initialized
INFO - 2024-10-01 13:54:50 --> Language Class Initialized
INFO - 2024-10-01 13:54:50 --> Config Class Initialized
INFO - 2024-10-01 13:54:50 --> Loader Class Initialized
INFO - 2024-10-01 13:54:50 --> Helper loaded: url_helper
INFO - 2024-10-01 13:54:50 --> Helper loaded: file_helper
INFO - 2024-10-01 13:54:50 --> Helper loaded: form_helper
INFO - 2024-10-01 13:54:50 --> Helper loaded: my_helper
INFO - 2024-10-01 13:54:50 --> Database Driver Class Initialized
INFO - 2024-10-01 13:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:54:50 --> Controller Class Initialized
INFO - 2024-10-01 13:54:50 --> Config Class Initialized
INFO - 2024-10-01 13:54:50 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:54:50 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:54:50 --> Utf8 Class Initialized
INFO - 2024-10-01 13:54:50 --> URI Class Initialized
INFO - 2024-10-01 13:54:50 --> Router Class Initialized
INFO - 2024-10-01 13:54:50 --> Output Class Initialized
INFO - 2024-10-01 13:54:50 --> Security Class Initialized
DEBUG - 2024-10-01 13:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:54:50 --> Input Class Initialized
INFO - 2024-10-01 13:54:50 --> Language Class Initialized
INFO - 2024-10-01 13:54:50 --> Language Class Initialized
INFO - 2024-10-01 13:54:50 --> Config Class Initialized
INFO - 2024-10-01 13:54:50 --> Loader Class Initialized
INFO - 2024-10-01 13:54:50 --> Helper loaded: url_helper
INFO - 2024-10-01 13:54:50 --> Helper loaded: file_helper
INFO - 2024-10-01 13:54:50 --> Helper loaded: form_helper
INFO - 2024-10-01 13:54:50 --> Helper loaded: my_helper
INFO - 2024-10-01 13:54:50 --> Database Driver Class Initialized
INFO - 2024-10-01 13:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:54:50 --> Controller Class Initialized
DEBUG - 2024-10-01 13:54:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 13:54:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:54:50 --> Final output sent to browser
DEBUG - 2024-10-01 13:54:50 --> Total execution time: 0.0306
INFO - 2024-10-01 13:54:58 --> Config Class Initialized
INFO - 2024-10-01 13:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:54:58 --> Utf8 Class Initialized
INFO - 2024-10-01 13:54:58 --> URI Class Initialized
INFO - 2024-10-01 13:54:58 --> Router Class Initialized
INFO - 2024-10-01 13:54:58 --> Output Class Initialized
INFO - 2024-10-01 13:54:58 --> Security Class Initialized
DEBUG - 2024-10-01 13:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:54:58 --> Input Class Initialized
INFO - 2024-10-01 13:54:58 --> Language Class Initialized
INFO - 2024-10-01 13:54:58 --> Language Class Initialized
INFO - 2024-10-01 13:54:58 --> Config Class Initialized
INFO - 2024-10-01 13:54:58 --> Loader Class Initialized
INFO - 2024-10-01 13:54:58 --> Helper loaded: url_helper
INFO - 2024-10-01 13:54:58 --> Helper loaded: file_helper
INFO - 2024-10-01 13:54:58 --> Helper loaded: form_helper
INFO - 2024-10-01 13:54:58 --> Helper loaded: my_helper
INFO - 2024-10-01 13:54:58 --> Database Driver Class Initialized
INFO - 2024-10-01 13:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:54:58 --> Controller Class Initialized
INFO - 2024-10-01 13:54:58 --> Helper loaded: cookie_helper
INFO - 2024-10-01 13:54:58 --> Final output sent to browser
DEBUG - 2024-10-01 13:54:58 --> Total execution time: 0.0291
INFO - 2024-10-01 13:54:58 --> Config Class Initialized
INFO - 2024-10-01 13:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:54:58 --> Utf8 Class Initialized
INFO - 2024-10-01 13:54:58 --> URI Class Initialized
INFO - 2024-10-01 13:54:58 --> Router Class Initialized
INFO - 2024-10-01 13:54:58 --> Output Class Initialized
INFO - 2024-10-01 13:54:58 --> Security Class Initialized
DEBUG - 2024-10-01 13:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:54:58 --> Input Class Initialized
INFO - 2024-10-01 13:54:58 --> Language Class Initialized
INFO - 2024-10-01 13:54:58 --> Language Class Initialized
INFO - 2024-10-01 13:54:58 --> Config Class Initialized
INFO - 2024-10-01 13:54:58 --> Loader Class Initialized
INFO - 2024-10-01 13:54:58 --> Helper loaded: url_helper
INFO - 2024-10-01 13:54:58 --> Helper loaded: file_helper
INFO - 2024-10-01 13:54:58 --> Helper loaded: form_helper
INFO - 2024-10-01 13:54:58 --> Helper loaded: my_helper
INFO - 2024-10-01 13:54:58 --> Database Driver Class Initialized
INFO - 2024-10-01 13:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:54:58 --> Controller Class Initialized
DEBUG - 2024-10-01 13:54:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-01 13:54:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:54:58 --> Final output sent to browser
DEBUG - 2024-10-01 13:54:58 --> Total execution time: 0.0379
INFO - 2024-10-01 13:55:00 --> Config Class Initialized
INFO - 2024-10-01 13:55:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:00 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:00 --> URI Class Initialized
INFO - 2024-10-01 13:55:00 --> Router Class Initialized
INFO - 2024-10-01 13:55:00 --> Output Class Initialized
INFO - 2024-10-01 13:55:00 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:00 --> Input Class Initialized
INFO - 2024-10-01 13:55:00 --> Language Class Initialized
INFO - 2024-10-01 13:55:00 --> Language Class Initialized
INFO - 2024-10-01 13:55:00 --> Config Class Initialized
INFO - 2024-10-01 13:55:00 --> Loader Class Initialized
INFO - 2024-10-01 13:55:00 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:00 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:00 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:00 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:00 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:00 --> Controller Class Initialized
DEBUG - 2024-10-01 13:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-01 13:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:55:00 --> Final output sent to browser
DEBUG - 2024-10-01 13:55:00 --> Total execution time: 0.0293
INFO - 2024-10-01 13:55:00 --> Config Class Initialized
INFO - 2024-10-01 13:55:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:00 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:00 --> URI Class Initialized
INFO - 2024-10-01 13:55:00 --> Router Class Initialized
INFO - 2024-10-01 13:55:00 --> Output Class Initialized
INFO - 2024-10-01 13:55:00 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:00 --> Input Class Initialized
INFO - 2024-10-01 13:55:00 --> Language Class Initialized
ERROR - 2024-10-01 13:55:00 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:55:00 --> Config Class Initialized
INFO - 2024-10-01 13:55:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:00 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:00 --> URI Class Initialized
INFO - 2024-10-01 13:55:00 --> Router Class Initialized
INFO - 2024-10-01 13:55:00 --> Output Class Initialized
INFO - 2024-10-01 13:55:00 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:00 --> Input Class Initialized
INFO - 2024-10-01 13:55:00 --> Language Class Initialized
INFO - 2024-10-01 13:55:00 --> Language Class Initialized
INFO - 2024-10-01 13:55:00 --> Config Class Initialized
INFO - 2024-10-01 13:55:00 --> Loader Class Initialized
INFO - 2024-10-01 13:55:00 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:00 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:00 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:00 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:01 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:01 --> Controller Class Initialized
INFO - 2024-10-01 13:55:26 --> Config Class Initialized
INFO - 2024-10-01 13:55:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:26 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:26 --> URI Class Initialized
INFO - 2024-10-01 13:55:26 --> Router Class Initialized
INFO - 2024-10-01 13:55:26 --> Output Class Initialized
INFO - 2024-10-01 13:55:26 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:26 --> Input Class Initialized
INFO - 2024-10-01 13:55:26 --> Language Class Initialized
INFO - 2024-10-01 13:55:26 --> Language Class Initialized
INFO - 2024-10-01 13:55:26 --> Config Class Initialized
INFO - 2024-10-01 13:55:26 --> Loader Class Initialized
INFO - 2024-10-01 13:55:26 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:26 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:26 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:26 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:26 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:26 --> Controller Class Initialized
DEBUG - 2024-10-01 13:55:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-01 13:55:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:55:26 --> Final output sent to browser
DEBUG - 2024-10-01 13:55:26 --> Total execution time: 0.0272
INFO - 2024-10-01 13:55:26 --> Config Class Initialized
INFO - 2024-10-01 13:55:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:26 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:26 --> URI Class Initialized
INFO - 2024-10-01 13:55:26 --> Router Class Initialized
INFO - 2024-10-01 13:55:26 --> Output Class Initialized
INFO - 2024-10-01 13:55:26 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:26 --> Input Class Initialized
INFO - 2024-10-01 13:55:26 --> Language Class Initialized
ERROR - 2024-10-01 13:55:26 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:55:26 --> Config Class Initialized
INFO - 2024-10-01 13:55:26 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:26 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:26 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:26 --> URI Class Initialized
INFO - 2024-10-01 13:55:26 --> Router Class Initialized
INFO - 2024-10-01 13:55:26 --> Output Class Initialized
INFO - 2024-10-01 13:55:26 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:26 --> Input Class Initialized
INFO - 2024-10-01 13:55:26 --> Language Class Initialized
INFO - 2024-10-01 13:55:26 --> Language Class Initialized
INFO - 2024-10-01 13:55:26 --> Config Class Initialized
INFO - 2024-10-01 13:55:26 --> Loader Class Initialized
INFO - 2024-10-01 13:55:26 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:26 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:26 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:26 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:26 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:26 --> Controller Class Initialized
INFO - 2024-10-01 13:55:43 --> Config Class Initialized
INFO - 2024-10-01 13:55:43 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:43 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:43 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:43 --> URI Class Initialized
INFO - 2024-10-01 13:55:43 --> Router Class Initialized
INFO - 2024-10-01 13:55:43 --> Output Class Initialized
INFO - 2024-10-01 13:55:43 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:43 --> Input Class Initialized
INFO - 2024-10-01 13:55:43 --> Language Class Initialized
INFO - 2024-10-01 13:55:43 --> Language Class Initialized
INFO - 2024-10-01 13:55:43 --> Config Class Initialized
INFO - 2024-10-01 13:55:43 --> Loader Class Initialized
INFO - 2024-10-01 13:55:43 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:43 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:43 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:43 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:43 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:43 --> Controller Class Initialized
INFO - 2024-10-01 13:55:43 --> Config Class Initialized
INFO - 2024-10-01 13:55:43 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:43 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:43 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:43 --> URI Class Initialized
INFO - 2024-10-01 13:55:43 --> Router Class Initialized
INFO - 2024-10-01 13:55:43 --> Output Class Initialized
INFO - 2024-10-01 13:55:43 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:43 --> Input Class Initialized
INFO - 2024-10-01 13:55:43 --> Language Class Initialized
INFO - 2024-10-01 13:55:43 --> Language Class Initialized
INFO - 2024-10-01 13:55:43 --> Config Class Initialized
INFO - 2024-10-01 13:55:43 --> Loader Class Initialized
INFO - 2024-10-01 13:55:43 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:43 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:43 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:43 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:43 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:43 --> Controller Class Initialized
INFO - 2024-10-01 13:55:49 --> Config Class Initialized
INFO - 2024-10-01 13:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:49 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:49 --> URI Class Initialized
INFO - 2024-10-01 13:55:49 --> Router Class Initialized
INFO - 2024-10-01 13:55:49 --> Output Class Initialized
INFO - 2024-10-01 13:55:49 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:49 --> Input Class Initialized
INFO - 2024-10-01 13:55:49 --> Language Class Initialized
INFO - 2024-10-01 13:55:49 --> Language Class Initialized
INFO - 2024-10-01 13:55:49 --> Config Class Initialized
INFO - 2024-10-01 13:55:49 --> Loader Class Initialized
INFO - 2024-10-01 13:55:49 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:49 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:49 --> Controller Class Initialized
INFO - 2024-10-01 13:55:49 --> Helper loaded: cookie_helper
INFO - 2024-10-01 13:55:49 --> Config Class Initialized
INFO - 2024-10-01 13:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:49 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:49 --> URI Class Initialized
INFO - 2024-10-01 13:55:49 --> Router Class Initialized
INFO - 2024-10-01 13:55:49 --> Output Class Initialized
INFO - 2024-10-01 13:55:49 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:49 --> Input Class Initialized
INFO - 2024-10-01 13:55:49 --> Language Class Initialized
INFO - 2024-10-01 13:55:49 --> Language Class Initialized
INFO - 2024-10-01 13:55:49 --> Config Class Initialized
INFO - 2024-10-01 13:55:49 --> Loader Class Initialized
INFO - 2024-10-01 13:55:49 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:49 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:49 --> Controller Class Initialized
INFO - 2024-10-01 13:55:49 --> Config Class Initialized
INFO - 2024-10-01 13:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:49 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:49 --> URI Class Initialized
INFO - 2024-10-01 13:55:49 --> Router Class Initialized
INFO - 2024-10-01 13:55:49 --> Output Class Initialized
INFO - 2024-10-01 13:55:49 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:49 --> Input Class Initialized
INFO - 2024-10-01 13:55:49 --> Language Class Initialized
INFO - 2024-10-01 13:55:49 --> Language Class Initialized
INFO - 2024-10-01 13:55:49 --> Config Class Initialized
INFO - 2024-10-01 13:55:49 --> Loader Class Initialized
INFO - 2024-10-01 13:55:49 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:49 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:49 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:49 --> Controller Class Initialized
DEBUG - 2024-10-01 13:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 13:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:55:49 --> Final output sent to browser
DEBUG - 2024-10-01 13:55:49 --> Total execution time: 0.0298
INFO - 2024-10-01 13:55:55 --> Config Class Initialized
INFO - 2024-10-01 13:55:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:55 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:55 --> URI Class Initialized
INFO - 2024-10-01 13:55:55 --> Router Class Initialized
INFO - 2024-10-01 13:55:55 --> Output Class Initialized
INFO - 2024-10-01 13:55:55 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:55 --> Input Class Initialized
INFO - 2024-10-01 13:55:55 --> Language Class Initialized
INFO - 2024-10-01 13:55:55 --> Language Class Initialized
INFO - 2024-10-01 13:55:55 --> Config Class Initialized
INFO - 2024-10-01 13:55:55 --> Loader Class Initialized
INFO - 2024-10-01 13:55:55 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:55 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:55 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:55 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:55 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:55 --> Controller Class Initialized
INFO - 2024-10-01 13:55:55 --> Helper loaded: cookie_helper
INFO - 2024-10-01 13:55:55 --> Final output sent to browser
DEBUG - 2024-10-01 13:55:55 --> Total execution time: 0.1128
INFO - 2024-10-01 13:55:55 --> Config Class Initialized
INFO - 2024-10-01 13:55:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:55:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:55:55 --> Utf8 Class Initialized
INFO - 2024-10-01 13:55:55 --> URI Class Initialized
INFO - 2024-10-01 13:55:55 --> Router Class Initialized
INFO - 2024-10-01 13:55:55 --> Output Class Initialized
INFO - 2024-10-01 13:55:55 --> Security Class Initialized
DEBUG - 2024-10-01 13:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:55:55 --> Input Class Initialized
INFO - 2024-10-01 13:55:55 --> Language Class Initialized
INFO - 2024-10-01 13:55:55 --> Language Class Initialized
INFO - 2024-10-01 13:55:55 --> Config Class Initialized
INFO - 2024-10-01 13:55:55 --> Loader Class Initialized
INFO - 2024-10-01 13:55:55 --> Helper loaded: url_helper
INFO - 2024-10-01 13:55:55 --> Helper loaded: file_helper
INFO - 2024-10-01 13:55:55 --> Helper loaded: form_helper
INFO - 2024-10-01 13:55:55 --> Helper loaded: my_helper
INFO - 2024-10-01 13:55:55 --> Database Driver Class Initialized
INFO - 2024-10-01 13:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:55:55 --> Controller Class Initialized
DEBUG - 2024-10-01 13:55:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-01 13:55:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:55:55 --> Final output sent to browser
DEBUG - 2024-10-01 13:55:55 --> Total execution time: 0.0597
INFO - 2024-10-01 13:56:01 --> Config Class Initialized
INFO - 2024-10-01 13:56:01 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:01 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:01 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:01 --> URI Class Initialized
INFO - 2024-10-01 13:56:01 --> Router Class Initialized
INFO - 2024-10-01 13:56:01 --> Output Class Initialized
INFO - 2024-10-01 13:56:01 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:01 --> Input Class Initialized
INFO - 2024-10-01 13:56:01 --> Language Class Initialized
INFO - 2024-10-01 13:56:01 --> Language Class Initialized
INFO - 2024-10-01 13:56:01 --> Config Class Initialized
INFO - 2024-10-01 13:56:01 --> Loader Class Initialized
INFO - 2024-10-01 13:56:01 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:01 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:01 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:01 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:01 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:01 --> Controller Class Initialized
DEBUG - 2024-10-01 13:56:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 13:56:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:56:01 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:01 --> Total execution time: 0.1335
INFO - 2024-10-01 13:56:21 --> Config Class Initialized
INFO - 2024-10-01 13:56:21 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:21 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:21 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:21 --> URI Class Initialized
INFO - 2024-10-01 13:56:21 --> Router Class Initialized
INFO - 2024-10-01 13:56:21 --> Output Class Initialized
INFO - 2024-10-01 13:56:21 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:21 --> Input Class Initialized
INFO - 2024-10-01 13:56:21 --> Language Class Initialized
INFO - 2024-10-01 13:56:21 --> Language Class Initialized
INFO - 2024-10-01 13:56:21 --> Config Class Initialized
INFO - 2024-10-01 13:56:21 --> Loader Class Initialized
INFO - 2024-10-01 13:56:21 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:21 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:21 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:21 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:21 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:21 --> Controller Class Initialized
DEBUG - 2024-10-01 13:56:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-10-01 13:56:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:56:21 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:21 --> Total execution time: 0.0376
INFO - 2024-10-01 13:56:23 --> Config Class Initialized
INFO - 2024-10-01 13:56:23 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:23 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:23 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:23 --> URI Class Initialized
INFO - 2024-10-01 13:56:23 --> Router Class Initialized
INFO - 2024-10-01 13:56:23 --> Output Class Initialized
INFO - 2024-10-01 13:56:23 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:23 --> Input Class Initialized
INFO - 2024-10-01 13:56:23 --> Language Class Initialized
INFO - 2024-10-01 13:56:23 --> Language Class Initialized
INFO - 2024-10-01 13:56:23 --> Config Class Initialized
INFO - 2024-10-01 13:56:23 --> Loader Class Initialized
INFO - 2024-10-01 13:56:23 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:23 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:23 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:23 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:23 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:23 --> Controller Class Initialized
DEBUG - 2024-10-01 13:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 13:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:56:23 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:23 --> Total execution time: 0.0275
INFO - 2024-10-01 13:56:40 --> Config Class Initialized
INFO - 2024-10-01 13:56:40 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:40 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:40 --> URI Class Initialized
INFO - 2024-10-01 13:56:40 --> Router Class Initialized
INFO - 2024-10-01 13:56:40 --> Output Class Initialized
INFO - 2024-10-01 13:56:40 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:40 --> Input Class Initialized
INFO - 2024-10-01 13:56:40 --> Language Class Initialized
INFO - 2024-10-01 13:56:40 --> Language Class Initialized
INFO - 2024-10-01 13:56:40 --> Config Class Initialized
INFO - 2024-10-01 13:56:40 --> Loader Class Initialized
INFO - 2024-10-01 13:56:40 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:40 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:40 --> Controller Class Initialized
INFO - 2024-10-01 13:56:40 --> Helper loaded: cookie_helper
INFO - 2024-10-01 13:56:40 --> Config Class Initialized
INFO - 2024-10-01 13:56:40 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:40 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:40 --> URI Class Initialized
INFO - 2024-10-01 13:56:40 --> Router Class Initialized
INFO - 2024-10-01 13:56:40 --> Output Class Initialized
INFO - 2024-10-01 13:56:40 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:40 --> Input Class Initialized
INFO - 2024-10-01 13:56:40 --> Language Class Initialized
INFO - 2024-10-01 13:56:40 --> Language Class Initialized
INFO - 2024-10-01 13:56:40 --> Config Class Initialized
INFO - 2024-10-01 13:56:40 --> Loader Class Initialized
INFO - 2024-10-01 13:56:40 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:40 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:40 --> Controller Class Initialized
INFO - 2024-10-01 13:56:40 --> Config Class Initialized
INFO - 2024-10-01 13:56:40 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:40 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:40 --> URI Class Initialized
INFO - 2024-10-01 13:56:40 --> Router Class Initialized
INFO - 2024-10-01 13:56:40 --> Output Class Initialized
INFO - 2024-10-01 13:56:40 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:40 --> Input Class Initialized
INFO - 2024-10-01 13:56:40 --> Language Class Initialized
INFO - 2024-10-01 13:56:40 --> Language Class Initialized
INFO - 2024-10-01 13:56:40 --> Config Class Initialized
INFO - 2024-10-01 13:56:40 --> Loader Class Initialized
INFO - 2024-10-01 13:56:40 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:40 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:40 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:40 --> Controller Class Initialized
DEBUG - 2024-10-01 13:56:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 13:56:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:56:40 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:40 --> Total execution time: 0.0286
INFO - 2024-10-01 13:56:45 --> Config Class Initialized
INFO - 2024-10-01 13:56:45 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:45 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:45 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:45 --> URI Class Initialized
INFO - 2024-10-01 13:56:45 --> Router Class Initialized
INFO - 2024-10-01 13:56:45 --> Output Class Initialized
INFO - 2024-10-01 13:56:45 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:45 --> Input Class Initialized
INFO - 2024-10-01 13:56:45 --> Language Class Initialized
INFO - 2024-10-01 13:56:45 --> Language Class Initialized
INFO - 2024-10-01 13:56:45 --> Config Class Initialized
INFO - 2024-10-01 13:56:45 --> Loader Class Initialized
INFO - 2024-10-01 13:56:45 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:45 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:45 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:45 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:45 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:45 --> Controller Class Initialized
INFO - 2024-10-01 13:56:45 --> Helper loaded: cookie_helper
INFO - 2024-10-01 13:56:45 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:45 --> Total execution time: 0.0312
INFO - 2024-10-01 13:56:45 --> Config Class Initialized
INFO - 2024-10-01 13:56:45 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:45 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:45 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:45 --> URI Class Initialized
INFO - 2024-10-01 13:56:45 --> Router Class Initialized
INFO - 2024-10-01 13:56:45 --> Output Class Initialized
INFO - 2024-10-01 13:56:45 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:45 --> Input Class Initialized
INFO - 2024-10-01 13:56:45 --> Language Class Initialized
INFO - 2024-10-01 13:56:45 --> Language Class Initialized
INFO - 2024-10-01 13:56:45 --> Config Class Initialized
INFO - 2024-10-01 13:56:45 --> Loader Class Initialized
INFO - 2024-10-01 13:56:45 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:45 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:45 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:45 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:45 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:45 --> Controller Class Initialized
DEBUG - 2024-10-01 13:56:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-01 13:56:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:56:45 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:45 --> Total execution time: 0.0258
INFO - 2024-10-01 13:56:56 --> Config Class Initialized
INFO - 2024-10-01 13:56:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:56 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:56 --> URI Class Initialized
INFO - 2024-10-01 13:56:56 --> Router Class Initialized
INFO - 2024-10-01 13:56:56 --> Output Class Initialized
INFO - 2024-10-01 13:56:56 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:56 --> Input Class Initialized
INFO - 2024-10-01 13:56:56 --> Language Class Initialized
INFO - 2024-10-01 13:56:56 --> Language Class Initialized
INFO - 2024-10-01 13:56:56 --> Config Class Initialized
INFO - 2024-10-01 13:56:56 --> Loader Class Initialized
INFO - 2024-10-01 13:56:56 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:56 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:56 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:56 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:56 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:56 --> Controller Class Initialized
DEBUG - 2024-10-01 13:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-10-01 13:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:56:56 --> Final output sent to browser
DEBUG - 2024-10-01 13:56:56 --> Total execution time: 0.0288
INFO - 2024-10-01 13:56:56 --> Config Class Initialized
INFO - 2024-10-01 13:56:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:56 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:56 --> URI Class Initialized
INFO - 2024-10-01 13:56:56 --> Router Class Initialized
INFO - 2024-10-01 13:56:56 --> Output Class Initialized
INFO - 2024-10-01 13:56:56 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:56 --> Input Class Initialized
INFO - 2024-10-01 13:56:56 --> Language Class Initialized
ERROR - 2024-10-01 13:56:56 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:56:56 --> Config Class Initialized
INFO - 2024-10-01 13:56:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:56:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:56:56 --> Utf8 Class Initialized
INFO - 2024-10-01 13:56:56 --> URI Class Initialized
INFO - 2024-10-01 13:56:56 --> Router Class Initialized
INFO - 2024-10-01 13:56:56 --> Output Class Initialized
INFO - 2024-10-01 13:56:56 --> Security Class Initialized
DEBUG - 2024-10-01 13:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:56:56 --> Input Class Initialized
INFO - 2024-10-01 13:56:56 --> Language Class Initialized
INFO - 2024-10-01 13:56:56 --> Language Class Initialized
INFO - 2024-10-01 13:56:56 --> Config Class Initialized
INFO - 2024-10-01 13:56:56 --> Loader Class Initialized
INFO - 2024-10-01 13:56:56 --> Helper loaded: url_helper
INFO - 2024-10-01 13:56:56 --> Helper loaded: file_helper
INFO - 2024-10-01 13:56:56 --> Helper loaded: form_helper
INFO - 2024-10-01 13:56:56 --> Helper loaded: my_helper
INFO - 2024-10-01 13:56:56 --> Database Driver Class Initialized
INFO - 2024-10-01 13:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:56:56 --> Controller Class Initialized
INFO - 2024-10-01 13:57:09 --> Config Class Initialized
INFO - 2024-10-01 13:57:09 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:09 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:09 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:09 --> URI Class Initialized
INFO - 2024-10-01 13:57:09 --> Router Class Initialized
INFO - 2024-10-01 13:57:09 --> Output Class Initialized
INFO - 2024-10-01 13:57:09 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:09 --> Input Class Initialized
INFO - 2024-10-01 13:57:09 --> Language Class Initialized
INFO - 2024-10-01 13:57:09 --> Language Class Initialized
INFO - 2024-10-01 13:57:09 --> Config Class Initialized
INFO - 2024-10-01 13:57:09 --> Loader Class Initialized
INFO - 2024-10-01 13:57:09 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:09 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:09 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:09 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:09 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:09 --> Controller Class Initialized
DEBUG - 2024-10-01 13:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-10-01 13:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:57:09 --> Final output sent to browser
DEBUG - 2024-10-01 13:57:09 --> Total execution time: 0.0283
INFO - 2024-10-01 13:57:09 --> Config Class Initialized
INFO - 2024-10-01 13:57:09 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:09 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:09 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:09 --> URI Class Initialized
INFO - 2024-10-01 13:57:09 --> Router Class Initialized
INFO - 2024-10-01 13:57:09 --> Output Class Initialized
INFO - 2024-10-01 13:57:09 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:09 --> Input Class Initialized
INFO - 2024-10-01 13:57:09 --> Language Class Initialized
ERROR - 2024-10-01 13:57:09 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:57:09 --> Config Class Initialized
INFO - 2024-10-01 13:57:09 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:09 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:09 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:09 --> URI Class Initialized
INFO - 2024-10-01 13:57:09 --> Router Class Initialized
INFO - 2024-10-01 13:57:09 --> Output Class Initialized
INFO - 2024-10-01 13:57:09 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:09 --> Input Class Initialized
INFO - 2024-10-01 13:57:09 --> Language Class Initialized
INFO - 2024-10-01 13:57:09 --> Language Class Initialized
INFO - 2024-10-01 13:57:09 --> Config Class Initialized
INFO - 2024-10-01 13:57:09 --> Loader Class Initialized
INFO - 2024-10-01 13:57:09 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:09 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:09 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:09 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:09 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:09 --> Controller Class Initialized
INFO - 2024-10-01 13:57:20 --> Config Class Initialized
INFO - 2024-10-01 13:57:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:20 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:20 --> URI Class Initialized
INFO - 2024-10-01 13:57:20 --> Router Class Initialized
INFO - 2024-10-01 13:57:20 --> Output Class Initialized
INFO - 2024-10-01 13:57:20 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:20 --> Input Class Initialized
INFO - 2024-10-01 13:57:20 --> Language Class Initialized
INFO - 2024-10-01 13:57:20 --> Language Class Initialized
INFO - 2024-10-01 13:57:20 --> Config Class Initialized
INFO - 2024-10-01 13:57:20 --> Loader Class Initialized
INFO - 2024-10-01 13:57:20 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:20 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:20 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:20 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:20 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:20 --> Controller Class Initialized
DEBUG - 2024-10-01 13:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-10-01 13:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:57:20 --> Final output sent to browser
DEBUG - 2024-10-01 13:57:20 --> Total execution time: 0.0305
INFO - 2024-10-01 13:57:20 --> Config Class Initialized
INFO - 2024-10-01 13:57:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:20 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:20 --> URI Class Initialized
INFO - 2024-10-01 13:57:20 --> Router Class Initialized
INFO - 2024-10-01 13:57:20 --> Output Class Initialized
INFO - 2024-10-01 13:57:20 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:20 --> Input Class Initialized
INFO - 2024-10-01 13:57:20 --> Language Class Initialized
ERROR - 2024-10-01 13:57:20 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:57:20 --> Config Class Initialized
INFO - 2024-10-01 13:57:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:20 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:20 --> URI Class Initialized
INFO - 2024-10-01 13:57:20 --> Router Class Initialized
INFO - 2024-10-01 13:57:20 --> Output Class Initialized
INFO - 2024-10-01 13:57:20 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:20 --> Input Class Initialized
INFO - 2024-10-01 13:57:20 --> Language Class Initialized
INFO - 2024-10-01 13:57:20 --> Language Class Initialized
INFO - 2024-10-01 13:57:20 --> Config Class Initialized
INFO - 2024-10-01 13:57:20 --> Loader Class Initialized
INFO - 2024-10-01 13:57:20 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:20 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:20 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:20 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:20 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:20 --> Controller Class Initialized
INFO - 2024-10-01 13:57:24 --> Config Class Initialized
INFO - 2024-10-01 13:57:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:24 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:24 --> URI Class Initialized
INFO - 2024-10-01 13:57:24 --> Router Class Initialized
INFO - 2024-10-01 13:57:24 --> Output Class Initialized
INFO - 2024-10-01 13:57:24 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:24 --> Input Class Initialized
INFO - 2024-10-01 13:57:24 --> Language Class Initialized
INFO - 2024-10-01 13:57:24 --> Language Class Initialized
INFO - 2024-10-01 13:57:24 --> Config Class Initialized
INFO - 2024-10-01 13:57:24 --> Loader Class Initialized
INFO - 2024-10-01 13:57:24 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:24 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:24 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:24 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:24 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:24 --> Controller Class Initialized
DEBUG - 2024-10-01 13:57:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-10-01 13:57:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:57:24 --> Final output sent to browser
DEBUG - 2024-10-01 13:57:24 --> Total execution time: 0.0290
INFO - 2024-10-01 13:57:24 --> Config Class Initialized
INFO - 2024-10-01 13:57:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:24 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:24 --> URI Class Initialized
INFO - 2024-10-01 13:57:24 --> Router Class Initialized
INFO - 2024-10-01 13:57:24 --> Output Class Initialized
INFO - 2024-10-01 13:57:24 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:24 --> Input Class Initialized
INFO - 2024-10-01 13:57:24 --> Language Class Initialized
ERROR - 2024-10-01 13:57:24 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:57:24 --> Config Class Initialized
INFO - 2024-10-01 13:57:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:24 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:24 --> URI Class Initialized
INFO - 2024-10-01 13:57:24 --> Router Class Initialized
INFO - 2024-10-01 13:57:24 --> Output Class Initialized
INFO - 2024-10-01 13:57:24 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:24 --> Input Class Initialized
INFO - 2024-10-01 13:57:24 --> Language Class Initialized
INFO - 2024-10-01 13:57:24 --> Language Class Initialized
INFO - 2024-10-01 13:57:24 --> Config Class Initialized
INFO - 2024-10-01 13:57:24 --> Loader Class Initialized
INFO - 2024-10-01 13:57:24 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:24 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:24 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:24 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:24 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:24 --> Controller Class Initialized
INFO - 2024-10-01 13:57:42 --> Config Class Initialized
INFO - 2024-10-01 13:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:42 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:42 --> URI Class Initialized
INFO - 2024-10-01 13:57:42 --> Router Class Initialized
INFO - 2024-10-01 13:57:42 --> Output Class Initialized
INFO - 2024-10-01 13:57:42 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:42 --> Input Class Initialized
INFO - 2024-10-01 13:57:42 --> Language Class Initialized
INFO - 2024-10-01 13:57:42 --> Language Class Initialized
INFO - 2024-10-01 13:57:42 --> Config Class Initialized
INFO - 2024-10-01 13:57:42 --> Loader Class Initialized
INFO - 2024-10-01 13:57:42 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:42 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:42 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:42 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:42 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:42 --> Controller Class Initialized
DEBUG - 2024-10-01 13:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-10-01 13:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:57:42 --> Final output sent to browser
DEBUG - 2024-10-01 13:57:42 --> Total execution time: 0.0371
INFO - 2024-10-01 13:57:42 --> Config Class Initialized
INFO - 2024-10-01 13:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:42 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:42 --> URI Class Initialized
INFO - 2024-10-01 13:57:42 --> Router Class Initialized
INFO - 2024-10-01 13:57:42 --> Output Class Initialized
INFO - 2024-10-01 13:57:42 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:42 --> Input Class Initialized
INFO - 2024-10-01 13:57:42 --> Language Class Initialized
ERROR - 2024-10-01 13:57:42 --> 404 Page Not Found: /index
INFO - 2024-10-01 13:57:42 --> Config Class Initialized
INFO - 2024-10-01 13:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:42 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:42 --> URI Class Initialized
INFO - 2024-10-01 13:57:42 --> Router Class Initialized
INFO - 2024-10-01 13:57:42 --> Output Class Initialized
INFO - 2024-10-01 13:57:42 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:42 --> Input Class Initialized
INFO - 2024-10-01 13:57:42 --> Language Class Initialized
INFO - 2024-10-01 13:57:42 --> Language Class Initialized
INFO - 2024-10-01 13:57:42 --> Config Class Initialized
INFO - 2024-10-01 13:57:42 --> Loader Class Initialized
INFO - 2024-10-01 13:57:42 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:42 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:42 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:42 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:42 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:42 --> Controller Class Initialized
INFO - 2024-10-01 13:57:57 --> Config Class Initialized
INFO - 2024-10-01 13:57:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:57 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:57 --> URI Class Initialized
INFO - 2024-10-01 13:57:57 --> Router Class Initialized
INFO - 2024-10-01 13:57:57 --> Output Class Initialized
INFO - 2024-10-01 13:57:57 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:57 --> Input Class Initialized
INFO - 2024-10-01 13:57:57 --> Language Class Initialized
INFO - 2024-10-01 13:57:57 --> Language Class Initialized
INFO - 2024-10-01 13:57:57 --> Config Class Initialized
INFO - 2024-10-01 13:57:57 --> Loader Class Initialized
INFO - 2024-10-01 13:57:57 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:57 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:57 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:57 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:57 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:57 --> Controller Class Initialized
INFO - 2024-10-01 13:57:57 --> Helper loaded: cookie_helper
INFO - 2024-10-01 13:57:57 --> Config Class Initialized
INFO - 2024-10-01 13:57:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:57 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:57 --> URI Class Initialized
INFO - 2024-10-01 13:57:57 --> Router Class Initialized
INFO - 2024-10-01 13:57:57 --> Output Class Initialized
INFO - 2024-10-01 13:57:57 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:57 --> Input Class Initialized
INFO - 2024-10-01 13:57:57 --> Language Class Initialized
INFO - 2024-10-01 13:57:57 --> Language Class Initialized
INFO - 2024-10-01 13:57:57 --> Config Class Initialized
INFO - 2024-10-01 13:57:57 --> Loader Class Initialized
INFO - 2024-10-01 13:57:57 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:57 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:57 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:57 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:57 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:57 --> Controller Class Initialized
INFO - 2024-10-01 13:57:58 --> Config Class Initialized
INFO - 2024-10-01 13:57:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 13:57:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 13:57:58 --> Utf8 Class Initialized
INFO - 2024-10-01 13:57:58 --> URI Class Initialized
INFO - 2024-10-01 13:57:58 --> Router Class Initialized
INFO - 2024-10-01 13:57:58 --> Output Class Initialized
INFO - 2024-10-01 13:57:58 --> Security Class Initialized
DEBUG - 2024-10-01 13:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 13:57:58 --> Input Class Initialized
INFO - 2024-10-01 13:57:58 --> Language Class Initialized
INFO - 2024-10-01 13:57:58 --> Language Class Initialized
INFO - 2024-10-01 13:57:58 --> Config Class Initialized
INFO - 2024-10-01 13:57:58 --> Loader Class Initialized
INFO - 2024-10-01 13:57:58 --> Helper loaded: url_helper
INFO - 2024-10-01 13:57:58 --> Helper loaded: file_helper
INFO - 2024-10-01 13:57:58 --> Helper loaded: form_helper
INFO - 2024-10-01 13:57:58 --> Helper loaded: my_helper
INFO - 2024-10-01 13:57:58 --> Database Driver Class Initialized
INFO - 2024-10-01 13:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 13:57:58 --> Controller Class Initialized
DEBUG - 2024-10-01 13:57:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 13:57:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 13:57:58 --> Final output sent to browser
DEBUG - 2024-10-01 13:57:58 --> Total execution time: 0.0309
INFO - 2024-10-01 14:50:30 --> Config Class Initialized
INFO - 2024-10-01 14:50:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:30 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:30 --> URI Class Initialized
DEBUG - 2024-10-01 14:50:30 --> No URI present. Default controller set.
INFO - 2024-10-01 14:50:30 --> Router Class Initialized
INFO - 2024-10-01 14:50:30 --> Output Class Initialized
INFO - 2024-10-01 14:50:30 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:30 --> Input Class Initialized
INFO - 2024-10-01 14:50:30 --> Language Class Initialized
INFO - 2024-10-01 14:50:30 --> Language Class Initialized
INFO - 2024-10-01 14:50:30 --> Config Class Initialized
INFO - 2024-10-01 14:50:30 --> Loader Class Initialized
INFO - 2024-10-01 14:50:30 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:30 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:30 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:30 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:31 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:31 --> Controller Class Initialized
INFO - 2024-10-01 14:50:31 --> Config Class Initialized
INFO - 2024-10-01 14:50:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:31 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:31 --> URI Class Initialized
INFO - 2024-10-01 14:50:31 --> Router Class Initialized
INFO - 2024-10-01 14:50:31 --> Output Class Initialized
INFO - 2024-10-01 14:50:31 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:31 --> Input Class Initialized
INFO - 2024-10-01 14:50:31 --> Language Class Initialized
INFO - 2024-10-01 14:50:31 --> Language Class Initialized
INFO - 2024-10-01 14:50:31 --> Config Class Initialized
INFO - 2024-10-01 14:50:31 --> Loader Class Initialized
INFO - 2024-10-01 14:50:31 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:31 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:31 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:31 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:31 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:31 --> Controller Class Initialized
DEBUG - 2024-10-01 14:50:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 14:50:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:50:31 --> Final output sent to browser
DEBUG - 2024-10-01 14:50:31 --> Total execution time: 0.0483
INFO - 2024-10-01 14:50:31 --> Config Class Initialized
INFO - 2024-10-01 14:50:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:31 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:31 --> URI Class Initialized
INFO - 2024-10-01 14:50:31 --> Router Class Initialized
INFO - 2024-10-01 14:50:31 --> Output Class Initialized
INFO - 2024-10-01 14:50:31 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:31 --> Input Class Initialized
INFO - 2024-10-01 14:50:31 --> Language Class Initialized
ERROR - 2024-10-01 14:50:31 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:50:39 --> Config Class Initialized
INFO - 2024-10-01 14:50:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:39 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:39 --> URI Class Initialized
INFO - 2024-10-01 14:50:39 --> Router Class Initialized
INFO - 2024-10-01 14:50:39 --> Output Class Initialized
INFO - 2024-10-01 14:50:39 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:39 --> Input Class Initialized
INFO - 2024-10-01 14:50:39 --> Language Class Initialized
INFO - 2024-10-01 14:50:39 --> Language Class Initialized
INFO - 2024-10-01 14:50:39 --> Config Class Initialized
INFO - 2024-10-01 14:50:39 --> Loader Class Initialized
INFO - 2024-10-01 14:50:39 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:39 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:39 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:39 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:39 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:39 --> Controller Class Initialized
INFO - 2024-10-01 14:50:39 --> Helper loaded: cookie_helper
INFO - 2024-10-01 14:50:39 --> Final output sent to browser
DEBUG - 2024-10-01 14:50:39 --> Total execution time: 0.0309
INFO - 2024-10-01 14:50:39 --> Config Class Initialized
INFO - 2024-10-01 14:50:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:39 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:39 --> URI Class Initialized
INFO - 2024-10-01 14:50:39 --> Router Class Initialized
INFO - 2024-10-01 14:50:39 --> Output Class Initialized
INFO - 2024-10-01 14:50:39 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:39 --> Input Class Initialized
INFO - 2024-10-01 14:50:39 --> Language Class Initialized
INFO - 2024-10-01 14:50:39 --> Language Class Initialized
INFO - 2024-10-01 14:50:39 --> Config Class Initialized
INFO - 2024-10-01 14:50:39 --> Loader Class Initialized
INFO - 2024-10-01 14:50:39 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:39 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:39 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:39 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:39 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:39 --> Controller Class Initialized
DEBUG - 2024-10-01 14:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-01 14:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:50:39 --> Final output sent to browser
DEBUG - 2024-10-01 14:50:39 --> Total execution time: 0.0273
INFO - 2024-10-01 14:50:39 --> Config Class Initialized
INFO - 2024-10-01 14:50:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:39 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:39 --> URI Class Initialized
INFO - 2024-10-01 14:50:39 --> Router Class Initialized
INFO - 2024-10-01 14:50:39 --> Output Class Initialized
INFO - 2024-10-01 14:50:39 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:39 --> Input Class Initialized
INFO - 2024-10-01 14:50:39 --> Language Class Initialized
ERROR - 2024-10-01 14:50:39 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:50:56 --> Config Class Initialized
INFO - 2024-10-01 14:50:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:56 --> URI Class Initialized
INFO - 2024-10-01 14:50:56 --> Router Class Initialized
INFO - 2024-10-01 14:50:56 --> Output Class Initialized
INFO - 2024-10-01 14:50:56 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:56 --> Input Class Initialized
INFO - 2024-10-01 14:50:56 --> Language Class Initialized
INFO - 2024-10-01 14:50:56 --> Language Class Initialized
INFO - 2024-10-01 14:50:56 --> Config Class Initialized
INFO - 2024-10-01 14:50:56 --> Loader Class Initialized
INFO - 2024-10-01 14:50:56 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:56 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:56 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:56 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:56 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:56 --> Controller Class Initialized
DEBUG - 2024-10-01 14:50:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-10-01 14:50:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:50:56 --> Final output sent to browser
DEBUG - 2024-10-01 14:50:56 --> Total execution time: 0.1060
INFO - 2024-10-01 14:50:56 --> Config Class Initialized
INFO - 2024-10-01 14:50:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:56 --> URI Class Initialized
INFO - 2024-10-01 14:50:56 --> Router Class Initialized
INFO - 2024-10-01 14:50:56 --> Output Class Initialized
INFO - 2024-10-01 14:50:56 --> Security Class Initialized
INFO - 2024-10-01 14:50:56 --> Config Class Initialized
INFO - 2024-10-01 14:50:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:56 --> URI Class Initialized
INFO - 2024-10-01 14:50:56 --> Router Class Initialized
INFO - 2024-10-01 14:50:56 --> Output Class Initialized
INFO - 2024-10-01 14:50:56 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:56 --> Input Class Initialized
INFO - 2024-10-01 14:50:56 --> Language Class Initialized
ERROR - 2024-10-01 14:50:56 --> 404 Page Not Found: /index
DEBUG - 2024-10-01 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:56 --> Input Class Initialized
INFO - 2024-10-01 14:50:56 --> Language Class Initialized
ERROR - 2024-10-01 14:50:56 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:50:56 --> Config Class Initialized
INFO - 2024-10-01 14:50:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:56 --> URI Class Initialized
INFO - 2024-10-01 14:50:56 --> Router Class Initialized
INFO - 2024-10-01 14:50:56 --> Output Class Initialized
INFO - 2024-10-01 14:50:56 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:56 --> Input Class Initialized
INFO - 2024-10-01 14:50:56 --> Language Class Initialized
INFO - 2024-10-01 14:50:56 --> Language Class Initialized
INFO - 2024-10-01 14:50:56 --> Config Class Initialized
INFO - 2024-10-01 14:50:56 --> Loader Class Initialized
INFO - 2024-10-01 14:50:56 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:56 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:56 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:56 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:56 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:56 --> Controller Class Initialized
INFO - 2024-10-01 14:50:59 --> Config Class Initialized
INFO - 2024-10-01 14:50:59 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:50:59 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:50:59 --> Utf8 Class Initialized
INFO - 2024-10-01 14:50:59 --> URI Class Initialized
INFO - 2024-10-01 14:50:59 --> Router Class Initialized
INFO - 2024-10-01 14:50:59 --> Output Class Initialized
INFO - 2024-10-01 14:50:59 --> Security Class Initialized
DEBUG - 2024-10-01 14:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:50:59 --> Input Class Initialized
INFO - 2024-10-01 14:50:59 --> Language Class Initialized
INFO - 2024-10-01 14:50:59 --> Language Class Initialized
INFO - 2024-10-01 14:50:59 --> Config Class Initialized
INFO - 2024-10-01 14:50:59 --> Loader Class Initialized
INFO - 2024-10-01 14:50:59 --> Helper loaded: url_helper
INFO - 2024-10-01 14:50:59 --> Helper loaded: file_helper
INFO - 2024-10-01 14:50:59 --> Helper loaded: form_helper
INFO - 2024-10-01 14:50:59 --> Helper loaded: my_helper
INFO - 2024-10-01 14:50:59 --> Database Driver Class Initialized
INFO - 2024-10-01 14:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:50:59 --> Controller Class Initialized
DEBUG - 2024-10-01 14:50:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-10-01 14:50:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:50:59 --> Final output sent to browser
DEBUG - 2024-10-01 14:50:59 --> Total execution time: 0.0297
INFO - 2024-10-01 14:51:00 --> Config Class Initialized
INFO - 2024-10-01 14:51:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:00 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:00 --> URI Class Initialized
INFO - 2024-10-01 14:51:00 --> Router Class Initialized
INFO - 2024-10-01 14:51:00 --> Output Class Initialized
INFO - 2024-10-01 14:51:00 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:00 --> Input Class Initialized
INFO - 2024-10-01 14:51:00 --> Language Class Initialized
ERROR - 2024-10-01 14:51:00 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:51:07 --> Config Class Initialized
INFO - 2024-10-01 14:51:07 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:07 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:07 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:07 --> URI Class Initialized
INFO - 2024-10-01 14:51:07 --> Router Class Initialized
INFO - 2024-10-01 14:51:07 --> Output Class Initialized
INFO - 2024-10-01 14:51:07 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:07 --> Input Class Initialized
INFO - 2024-10-01 14:51:07 --> Language Class Initialized
INFO - 2024-10-01 14:51:07 --> Language Class Initialized
INFO - 2024-10-01 14:51:07 --> Config Class Initialized
INFO - 2024-10-01 14:51:07 --> Loader Class Initialized
INFO - 2024-10-01 14:51:07 --> Helper loaded: url_helper
INFO - 2024-10-01 14:51:07 --> Helper loaded: file_helper
INFO - 2024-10-01 14:51:07 --> Helper loaded: form_helper
INFO - 2024-10-01 14:51:07 --> Helper loaded: my_helper
INFO - 2024-10-01 14:51:07 --> Database Driver Class Initialized
INFO - 2024-10-01 14:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:51:07 --> Controller Class Initialized
DEBUG - 2024-10-01 14:51:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-10-01 14:51:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:51:07 --> Final output sent to browser
DEBUG - 2024-10-01 14:51:07 --> Total execution time: 0.0336
INFO - 2024-10-01 14:51:08 --> Config Class Initialized
INFO - 2024-10-01 14:51:08 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:08 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:08 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:08 --> URI Class Initialized
INFO - 2024-10-01 14:51:08 --> Router Class Initialized
INFO - 2024-10-01 14:51:08 --> Output Class Initialized
INFO - 2024-10-01 14:51:08 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:08 --> Input Class Initialized
INFO - 2024-10-01 14:51:08 --> Language Class Initialized
ERROR - 2024-10-01 14:51:08 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:51:08 --> Config Class Initialized
INFO - 2024-10-01 14:51:08 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:08 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:08 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:08 --> URI Class Initialized
INFO - 2024-10-01 14:51:08 --> Router Class Initialized
INFO - 2024-10-01 14:51:08 --> Output Class Initialized
INFO - 2024-10-01 14:51:08 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:08 --> Input Class Initialized
INFO - 2024-10-01 14:51:08 --> Language Class Initialized
INFO - 2024-10-01 14:51:08 --> Language Class Initialized
INFO - 2024-10-01 14:51:08 --> Config Class Initialized
INFO - 2024-10-01 14:51:08 --> Loader Class Initialized
INFO - 2024-10-01 14:51:08 --> Helper loaded: url_helper
INFO - 2024-10-01 14:51:08 --> Helper loaded: file_helper
INFO - 2024-10-01 14:51:08 --> Helper loaded: form_helper
INFO - 2024-10-01 14:51:08 --> Helper loaded: my_helper
INFO - 2024-10-01 14:51:08 --> Database Driver Class Initialized
INFO - 2024-10-01 14:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:51:08 --> Controller Class Initialized
INFO - 2024-10-01 14:51:31 --> Config Class Initialized
INFO - 2024-10-01 14:51:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:31 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:31 --> URI Class Initialized
INFO - 2024-10-01 14:51:31 --> Router Class Initialized
INFO - 2024-10-01 14:51:31 --> Output Class Initialized
INFO - 2024-10-01 14:51:31 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:31 --> Input Class Initialized
INFO - 2024-10-01 14:51:31 --> Language Class Initialized
INFO - 2024-10-01 14:51:31 --> Language Class Initialized
INFO - 2024-10-01 14:51:31 --> Config Class Initialized
INFO - 2024-10-01 14:51:31 --> Loader Class Initialized
INFO - 2024-10-01 14:51:31 --> Helper loaded: url_helper
INFO - 2024-10-01 14:51:31 --> Helper loaded: file_helper
INFO - 2024-10-01 14:51:31 --> Helper loaded: form_helper
INFO - 2024-10-01 14:51:31 --> Helper loaded: my_helper
INFO - 2024-10-01 14:51:31 --> Database Driver Class Initialized
INFO - 2024-10-01 14:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:51:31 --> Controller Class Initialized
DEBUG - 2024-10-01 14:51:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-10-01 14:51:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:51:31 --> Final output sent to browser
DEBUG - 2024-10-01 14:51:31 --> Total execution time: 0.0331
INFO - 2024-10-01 14:51:31 --> Config Class Initialized
INFO - 2024-10-01 14:51:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:31 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:31 --> URI Class Initialized
INFO - 2024-10-01 14:51:31 --> Router Class Initialized
INFO - 2024-10-01 14:51:31 --> Output Class Initialized
INFO - 2024-10-01 14:51:31 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:31 --> Input Class Initialized
INFO - 2024-10-01 14:51:31 --> Language Class Initialized
ERROR - 2024-10-01 14:51:31 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:51:31 --> Config Class Initialized
INFO - 2024-10-01 14:51:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:31 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:31 --> URI Class Initialized
INFO - 2024-10-01 14:51:31 --> Router Class Initialized
INFO - 2024-10-01 14:51:31 --> Output Class Initialized
INFO - 2024-10-01 14:51:31 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:31 --> Input Class Initialized
INFO - 2024-10-01 14:51:31 --> Language Class Initialized
ERROR - 2024-10-01 14:51:31 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:51:32 --> Config Class Initialized
INFO - 2024-10-01 14:51:32 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:51:32 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:51:32 --> Utf8 Class Initialized
INFO - 2024-10-01 14:51:32 --> URI Class Initialized
INFO - 2024-10-01 14:51:32 --> Router Class Initialized
INFO - 2024-10-01 14:51:32 --> Output Class Initialized
INFO - 2024-10-01 14:51:32 --> Security Class Initialized
DEBUG - 2024-10-01 14:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:51:32 --> Input Class Initialized
INFO - 2024-10-01 14:51:32 --> Language Class Initialized
INFO - 2024-10-01 14:51:32 --> Language Class Initialized
INFO - 2024-10-01 14:51:32 --> Config Class Initialized
INFO - 2024-10-01 14:51:32 --> Loader Class Initialized
INFO - 2024-10-01 14:51:32 --> Helper loaded: url_helper
INFO - 2024-10-01 14:51:32 --> Helper loaded: file_helper
INFO - 2024-10-01 14:51:32 --> Helper loaded: form_helper
INFO - 2024-10-01 14:51:32 --> Helper loaded: my_helper
INFO - 2024-10-01 14:51:32 --> Database Driver Class Initialized
INFO - 2024-10-01 14:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:51:32 --> Controller Class Initialized
INFO - 2024-10-01 14:52:31 --> Config Class Initialized
INFO - 2024-10-01 14:52:31 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:52:31 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:52:31 --> Utf8 Class Initialized
INFO - 2024-10-01 14:52:31 --> URI Class Initialized
INFO - 2024-10-01 14:52:31 --> Router Class Initialized
INFO - 2024-10-01 14:52:31 --> Output Class Initialized
INFO - 2024-10-01 14:52:31 --> Security Class Initialized
DEBUG - 2024-10-01 14:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:52:31 --> Input Class Initialized
INFO - 2024-10-01 14:52:31 --> Language Class Initialized
INFO - 2024-10-01 14:52:31 --> Language Class Initialized
INFO - 2024-10-01 14:52:31 --> Config Class Initialized
INFO - 2024-10-01 14:52:31 --> Loader Class Initialized
INFO - 2024-10-01 14:52:31 --> Helper loaded: url_helper
INFO - 2024-10-01 14:52:31 --> Helper loaded: file_helper
INFO - 2024-10-01 14:52:31 --> Helper loaded: form_helper
INFO - 2024-10-01 14:52:31 --> Helper loaded: my_helper
INFO - 2024-10-01 14:52:31 --> Database Driver Class Initialized
INFO - 2024-10-01 14:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:52:31 --> Controller Class Initialized
INFO - 2024-10-01 14:52:36 --> Config Class Initialized
INFO - 2024-10-01 14:52:36 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:52:36 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:52:36 --> Utf8 Class Initialized
INFO - 2024-10-01 14:52:36 --> URI Class Initialized
INFO - 2024-10-01 14:52:36 --> Router Class Initialized
INFO - 2024-10-01 14:52:36 --> Output Class Initialized
INFO - 2024-10-01 14:52:36 --> Security Class Initialized
DEBUG - 2024-10-01 14:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:52:36 --> Input Class Initialized
INFO - 2024-10-01 14:52:36 --> Language Class Initialized
INFO - 2024-10-01 14:52:36 --> Language Class Initialized
INFO - 2024-10-01 14:52:36 --> Config Class Initialized
INFO - 2024-10-01 14:52:36 --> Loader Class Initialized
INFO - 2024-10-01 14:52:36 --> Helper loaded: url_helper
INFO - 2024-10-01 14:52:36 --> Helper loaded: file_helper
INFO - 2024-10-01 14:52:36 --> Helper loaded: form_helper
INFO - 2024-10-01 14:52:36 --> Helper loaded: my_helper
INFO - 2024-10-01 14:52:36 --> Database Driver Class Initialized
INFO - 2024-10-01 14:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:52:36 --> Controller Class Initialized
INFO - 2024-10-01 14:52:41 --> Config Class Initialized
INFO - 2024-10-01 14:52:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:52:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:52:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:52:41 --> URI Class Initialized
INFO - 2024-10-01 14:52:41 --> Router Class Initialized
INFO - 2024-10-01 14:52:41 --> Output Class Initialized
INFO - 2024-10-01 14:52:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:52:41 --> Input Class Initialized
INFO - 2024-10-01 14:52:41 --> Language Class Initialized
INFO - 2024-10-01 14:52:41 --> Language Class Initialized
INFO - 2024-10-01 14:52:41 --> Config Class Initialized
INFO - 2024-10-01 14:52:41 --> Loader Class Initialized
INFO - 2024-10-01 14:52:41 --> Helper loaded: url_helper
INFO - 2024-10-01 14:52:41 --> Helper loaded: file_helper
INFO - 2024-10-01 14:52:41 --> Helper loaded: form_helper
INFO - 2024-10-01 14:52:41 --> Helper loaded: my_helper
INFO - 2024-10-01 14:52:41 --> Database Driver Class Initialized
INFO - 2024-10-01 14:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:52:41 --> Controller Class Initialized
INFO - 2024-10-01 14:52:56 --> Config Class Initialized
INFO - 2024-10-01 14:52:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:52:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:52:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:52:56 --> URI Class Initialized
INFO - 2024-10-01 14:52:56 --> Router Class Initialized
INFO - 2024-10-01 14:52:56 --> Output Class Initialized
INFO - 2024-10-01 14:52:56 --> Security Class Initialized
DEBUG - 2024-10-01 14:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:52:56 --> Input Class Initialized
INFO - 2024-10-01 14:52:56 --> Language Class Initialized
INFO - 2024-10-01 14:52:56 --> Language Class Initialized
INFO - 2024-10-01 14:52:56 --> Config Class Initialized
INFO - 2024-10-01 14:52:56 --> Loader Class Initialized
INFO - 2024-10-01 14:52:56 --> Helper loaded: url_helper
INFO - 2024-10-01 14:52:56 --> Helper loaded: file_helper
INFO - 2024-10-01 14:52:56 --> Helper loaded: form_helper
INFO - 2024-10-01 14:52:56 --> Helper loaded: my_helper
INFO - 2024-10-01 14:52:56 --> Database Driver Class Initialized
INFO - 2024-10-01 14:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:52:56 --> Controller Class Initialized
INFO - 2024-10-01 14:53:01 --> Config Class Initialized
INFO - 2024-10-01 14:53:01 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:01 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:01 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:01 --> URI Class Initialized
INFO - 2024-10-01 14:53:01 --> Router Class Initialized
INFO - 2024-10-01 14:53:01 --> Output Class Initialized
INFO - 2024-10-01 14:53:01 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:01 --> Input Class Initialized
INFO - 2024-10-01 14:53:01 --> Language Class Initialized
INFO - 2024-10-01 14:53:01 --> Language Class Initialized
INFO - 2024-10-01 14:53:01 --> Config Class Initialized
INFO - 2024-10-01 14:53:01 --> Loader Class Initialized
INFO - 2024-10-01 14:53:01 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:01 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:01 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:01 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:01 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:01 --> Controller Class Initialized
INFO - 2024-10-01 14:53:01 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:01 --> Total execution time: 0.0398
INFO - 2024-10-01 14:53:24 --> Config Class Initialized
INFO - 2024-10-01 14:53:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:24 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:24 --> URI Class Initialized
INFO - 2024-10-01 14:53:24 --> Router Class Initialized
INFO - 2024-10-01 14:53:24 --> Output Class Initialized
INFO - 2024-10-01 14:53:24 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:24 --> Input Class Initialized
INFO - 2024-10-01 14:53:24 --> Language Class Initialized
INFO - 2024-10-01 14:53:24 --> Language Class Initialized
INFO - 2024-10-01 14:53:24 --> Config Class Initialized
INFO - 2024-10-01 14:53:24 --> Loader Class Initialized
INFO - 2024-10-01 14:53:24 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:24 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:24 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:24 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:24 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:24 --> Controller Class Initialized
DEBUG - 2024-10-01 14:53:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-10-01 14:53:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:53:24 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:24 --> Total execution time: 0.0290
INFO - 2024-10-01 14:53:24 --> Config Class Initialized
INFO - 2024-10-01 14:53:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:24 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:24 --> URI Class Initialized
INFO - 2024-10-01 14:53:24 --> Router Class Initialized
INFO - 2024-10-01 14:53:24 --> Output Class Initialized
INFO - 2024-10-01 14:53:24 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:24 --> Input Class Initialized
INFO - 2024-10-01 14:53:24 --> Language Class Initialized
ERROR - 2024-10-01 14:53:24 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:24 --> Config Class Initialized
INFO - 2024-10-01 14:53:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:24 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:24 --> URI Class Initialized
INFO - 2024-10-01 14:53:24 --> Router Class Initialized
INFO - 2024-10-01 14:53:24 --> Output Class Initialized
INFO - 2024-10-01 14:53:24 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:24 --> Input Class Initialized
INFO - 2024-10-01 14:53:24 --> Language Class Initialized
ERROR - 2024-10-01 14:53:24 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:24 --> Config Class Initialized
INFO - 2024-10-01 14:53:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:24 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:24 --> URI Class Initialized
INFO - 2024-10-01 14:53:24 --> Router Class Initialized
INFO - 2024-10-01 14:53:24 --> Output Class Initialized
INFO - 2024-10-01 14:53:24 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:24 --> Input Class Initialized
INFO - 2024-10-01 14:53:24 --> Language Class Initialized
INFO - 2024-10-01 14:53:24 --> Language Class Initialized
INFO - 2024-10-01 14:53:24 --> Config Class Initialized
INFO - 2024-10-01 14:53:24 --> Loader Class Initialized
INFO - 2024-10-01 14:53:24 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:24 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:24 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:24 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:24 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:24 --> Controller Class Initialized
INFO - 2024-10-01 14:53:33 --> Config Class Initialized
INFO - 2024-10-01 14:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:33 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:33 --> URI Class Initialized
INFO - 2024-10-01 14:53:33 --> Router Class Initialized
INFO - 2024-10-01 14:53:33 --> Output Class Initialized
INFO - 2024-10-01 14:53:33 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:33 --> Input Class Initialized
INFO - 2024-10-01 14:53:33 --> Language Class Initialized
INFO - 2024-10-01 14:53:33 --> Language Class Initialized
INFO - 2024-10-01 14:53:33 --> Config Class Initialized
INFO - 2024-10-01 14:53:33 --> Loader Class Initialized
INFO - 2024-10-01 14:53:33 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:33 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:33 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:33 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:33 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:33 --> Controller Class Initialized
DEBUG - 2024-10-01 14:53:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-01 14:53:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:53:33 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:33 --> Total execution time: 0.0314
INFO - 2024-10-01 14:53:33 --> Config Class Initialized
INFO - 2024-10-01 14:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:33 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:33 --> URI Class Initialized
INFO - 2024-10-01 14:53:33 --> Router Class Initialized
INFO - 2024-10-01 14:53:33 --> Output Class Initialized
INFO - 2024-10-01 14:53:33 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:33 --> Input Class Initialized
INFO - 2024-10-01 14:53:33 --> Language Class Initialized
ERROR - 2024-10-01 14:53:33 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:33 --> Config Class Initialized
INFO - 2024-10-01 14:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:33 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:33 --> URI Class Initialized
INFO - 2024-10-01 14:53:33 --> Router Class Initialized
INFO - 2024-10-01 14:53:33 --> Output Class Initialized
INFO - 2024-10-01 14:53:33 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:33 --> Input Class Initialized
INFO - 2024-10-01 14:53:33 --> Language Class Initialized
ERROR - 2024-10-01 14:53:33 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:33 --> Config Class Initialized
INFO - 2024-10-01 14:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:33 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:33 --> URI Class Initialized
INFO - 2024-10-01 14:53:33 --> Router Class Initialized
INFO - 2024-10-01 14:53:33 --> Output Class Initialized
INFO - 2024-10-01 14:53:33 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:33 --> Input Class Initialized
INFO - 2024-10-01 14:53:33 --> Language Class Initialized
INFO - 2024-10-01 14:53:33 --> Language Class Initialized
INFO - 2024-10-01 14:53:33 --> Config Class Initialized
INFO - 2024-10-01 14:53:33 --> Loader Class Initialized
INFO - 2024-10-01 14:53:33 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:33 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:33 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:33 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:33 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:33 --> Controller Class Initialized
INFO - 2024-10-01 14:53:41 --> Config Class Initialized
INFO - 2024-10-01 14:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:41 --> URI Class Initialized
INFO - 2024-10-01 14:53:41 --> Router Class Initialized
INFO - 2024-10-01 14:53:41 --> Output Class Initialized
INFO - 2024-10-01 14:53:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:41 --> Input Class Initialized
INFO - 2024-10-01 14:53:41 --> Language Class Initialized
INFO - 2024-10-01 14:53:41 --> Language Class Initialized
INFO - 2024-10-01 14:53:41 --> Config Class Initialized
INFO - 2024-10-01 14:53:41 --> Loader Class Initialized
INFO - 2024-10-01 14:53:41 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:41 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:41 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:41 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:41 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:41 --> Controller Class Initialized
DEBUG - 2024-10-01 14:53:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-10-01 14:53:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:53:41 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:41 --> Total execution time: 0.0267
INFO - 2024-10-01 14:53:41 --> Config Class Initialized
INFO - 2024-10-01 14:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:41 --> URI Class Initialized
INFO - 2024-10-01 14:53:41 --> Router Class Initialized
INFO - 2024-10-01 14:53:41 --> Output Class Initialized
INFO - 2024-10-01 14:53:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:41 --> Input Class Initialized
INFO - 2024-10-01 14:53:41 --> Language Class Initialized
ERROR - 2024-10-01 14:53:41 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:41 --> Config Class Initialized
INFO - 2024-10-01 14:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:41 --> URI Class Initialized
INFO - 2024-10-01 14:53:41 --> Router Class Initialized
INFO - 2024-10-01 14:53:41 --> Output Class Initialized
INFO - 2024-10-01 14:53:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:41 --> Input Class Initialized
INFO - 2024-10-01 14:53:41 --> Language Class Initialized
ERROR - 2024-10-01 14:53:41 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:41 --> Config Class Initialized
INFO - 2024-10-01 14:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:41 --> URI Class Initialized
INFO - 2024-10-01 14:53:41 --> Router Class Initialized
INFO - 2024-10-01 14:53:41 --> Output Class Initialized
INFO - 2024-10-01 14:53:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:41 --> Input Class Initialized
INFO - 2024-10-01 14:53:41 --> Language Class Initialized
INFO - 2024-10-01 14:53:41 --> Language Class Initialized
INFO - 2024-10-01 14:53:41 --> Config Class Initialized
INFO - 2024-10-01 14:53:41 --> Loader Class Initialized
INFO - 2024-10-01 14:53:41 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:41 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:41 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:41 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:41 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:41 --> Controller Class Initialized
INFO - 2024-10-01 14:53:45 --> Config Class Initialized
INFO - 2024-10-01 14:53:45 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:45 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:45 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:45 --> URI Class Initialized
INFO - 2024-10-01 14:53:45 --> Router Class Initialized
INFO - 2024-10-01 14:53:45 --> Output Class Initialized
INFO - 2024-10-01 14:53:45 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:45 --> Input Class Initialized
INFO - 2024-10-01 14:53:45 --> Language Class Initialized
INFO - 2024-10-01 14:53:45 --> Language Class Initialized
INFO - 2024-10-01 14:53:45 --> Config Class Initialized
INFO - 2024-10-01 14:53:45 --> Loader Class Initialized
INFO - 2024-10-01 14:53:45 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:45 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:45 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:45 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:45 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:45 --> Controller Class Initialized
INFO - 2024-10-01 14:53:45 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:45 --> Total execution time: 0.0393
INFO - 2024-10-01 14:53:54 --> Config Class Initialized
INFO - 2024-10-01 14:53:54 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:54 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:54 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:54 --> URI Class Initialized
INFO - 2024-10-01 14:53:54 --> Router Class Initialized
INFO - 2024-10-01 14:53:54 --> Output Class Initialized
INFO - 2024-10-01 14:53:54 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:54 --> Input Class Initialized
INFO - 2024-10-01 14:53:54 --> Language Class Initialized
INFO - 2024-10-01 14:53:54 --> Language Class Initialized
INFO - 2024-10-01 14:53:54 --> Config Class Initialized
INFO - 2024-10-01 14:53:54 --> Loader Class Initialized
INFO - 2024-10-01 14:53:54 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:54 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:54 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:54 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:54 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:54 --> Controller Class Initialized
DEBUG - 2024-10-01 14:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-01 14:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:53:54 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:54 --> Total execution time: 0.0476
INFO - 2024-10-01 14:53:54 --> Config Class Initialized
INFO - 2024-10-01 14:53:54 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:54 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:54 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:54 --> URI Class Initialized
INFO - 2024-10-01 14:53:54 --> Router Class Initialized
INFO - 2024-10-01 14:53:54 --> Output Class Initialized
INFO - 2024-10-01 14:53:54 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:54 --> Input Class Initialized
INFO - 2024-10-01 14:53:54 --> Language Class Initialized
ERROR - 2024-10-01 14:53:54 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:54 --> Config Class Initialized
INFO - 2024-10-01 14:53:54 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:54 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:54 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:54 --> URI Class Initialized
INFO - 2024-10-01 14:53:54 --> Router Class Initialized
INFO - 2024-10-01 14:53:54 --> Output Class Initialized
INFO - 2024-10-01 14:53:54 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:54 --> Input Class Initialized
INFO - 2024-10-01 14:53:54 --> Language Class Initialized
ERROR - 2024-10-01 14:53:54 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:54 --> Config Class Initialized
INFO - 2024-10-01 14:53:54 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:54 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:54 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:54 --> URI Class Initialized
INFO - 2024-10-01 14:53:54 --> Router Class Initialized
INFO - 2024-10-01 14:53:54 --> Output Class Initialized
INFO - 2024-10-01 14:53:54 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:54 --> Input Class Initialized
INFO - 2024-10-01 14:53:54 --> Language Class Initialized
INFO - 2024-10-01 14:53:54 --> Language Class Initialized
INFO - 2024-10-01 14:53:54 --> Config Class Initialized
INFO - 2024-10-01 14:53:54 --> Loader Class Initialized
INFO - 2024-10-01 14:53:54 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:54 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:54 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:54 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:54 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:54 --> Controller Class Initialized
INFO - 2024-10-01 14:53:57 --> Config Class Initialized
INFO - 2024-10-01 14:53:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:57 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:57 --> URI Class Initialized
INFO - 2024-10-01 14:53:57 --> Router Class Initialized
INFO - 2024-10-01 14:53:57 --> Output Class Initialized
INFO - 2024-10-01 14:53:57 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:57 --> Input Class Initialized
INFO - 2024-10-01 14:53:57 --> Language Class Initialized
INFO - 2024-10-01 14:53:57 --> Language Class Initialized
INFO - 2024-10-01 14:53:57 --> Config Class Initialized
INFO - 2024-10-01 14:53:57 --> Loader Class Initialized
INFO - 2024-10-01 14:53:57 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:57 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:57 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:57 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:57 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:57 --> Controller Class Initialized
DEBUG - 2024-10-01 14:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-10-01 14:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:53:57 --> Final output sent to browser
DEBUG - 2024-10-01 14:53:57 --> Total execution time: 0.0288
INFO - 2024-10-01 14:53:57 --> Config Class Initialized
INFO - 2024-10-01 14:53:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:57 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:57 --> URI Class Initialized
INFO - 2024-10-01 14:53:57 --> Router Class Initialized
INFO - 2024-10-01 14:53:57 --> Output Class Initialized
INFO - 2024-10-01 14:53:57 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:57 --> Input Class Initialized
INFO - 2024-10-01 14:53:57 --> Language Class Initialized
ERROR - 2024-10-01 14:53:57 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:57 --> Config Class Initialized
INFO - 2024-10-01 14:53:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:57 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:57 --> URI Class Initialized
INFO - 2024-10-01 14:53:57 --> Router Class Initialized
INFO - 2024-10-01 14:53:57 --> Output Class Initialized
INFO - 2024-10-01 14:53:57 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:57 --> Input Class Initialized
INFO - 2024-10-01 14:53:57 --> Language Class Initialized
ERROR - 2024-10-01 14:53:57 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:53:57 --> Config Class Initialized
INFO - 2024-10-01 14:53:57 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:53:57 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:53:57 --> Utf8 Class Initialized
INFO - 2024-10-01 14:53:57 --> URI Class Initialized
INFO - 2024-10-01 14:53:57 --> Router Class Initialized
INFO - 2024-10-01 14:53:57 --> Output Class Initialized
INFO - 2024-10-01 14:53:57 --> Security Class Initialized
DEBUG - 2024-10-01 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:53:57 --> Input Class Initialized
INFO - 2024-10-01 14:53:57 --> Language Class Initialized
INFO - 2024-10-01 14:53:57 --> Language Class Initialized
INFO - 2024-10-01 14:53:57 --> Config Class Initialized
INFO - 2024-10-01 14:53:57 --> Loader Class Initialized
INFO - 2024-10-01 14:53:57 --> Helper loaded: url_helper
INFO - 2024-10-01 14:53:57 --> Helper loaded: file_helper
INFO - 2024-10-01 14:53:57 --> Helper loaded: form_helper
INFO - 2024-10-01 14:53:57 --> Helper loaded: my_helper
INFO - 2024-10-01 14:53:57 --> Database Driver Class Initialized
INFO - 2024-10-01 14:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:53:57 --> Controller Class Initialized
INFO - 2024-10-01 14:54:04 --> Config Class Initialized
INFO - 2024-10-01 14:54:04 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:04 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:04 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:04 --> URI Class Initialized
INFO - 2024-10-01 14:54:04 --> Router Class Initialized
INFO - 2024-10-01 14:54:04 --> Output Class Initialized
INFO - 2024-10-01 14:54:04 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:04 --> Input Class Initialized
INFO - 2024-10-01 14:54:04 --> Language Class Initialized
INFO - 2024-10-01 14:54:04 --> Language Class Initialized
INFO - 2024-10-01 14:54:04 --> Config Class Initialized
INFO - 2024-10-01 14:54:04 --> Loader Class Initialized
INFO - 2024-10-01 14:54:04 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:04 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:04 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:04 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:04 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:04 --> Controller Class Initialized
INFO - 2024-10-01 14:54:07 --> Config Class Initialized
INFO - 2024-10-01 14:54:07 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:07 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:07 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:07 --> URI Class Initialized
INFO - 2024-10-01 14:54:07 --> Router Class Initialized
INFO - 2024-10-01 14:54:07 --> Output Class Initialized
INFO - 2024-10-01 14:54:07 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:07 --> Input Class Initialized
INFO - 2024-10-01 14:54:07 --> Language Class Initialized
INFO - 2024-10-01 14:54:07 --> Language Class Initialized
INFO - 2024-10-01 14:54:07 --> Config Class Initialized
INFO - 2024-10-01 14:54:07 --> Loader Class Initialized
INFO - 2024-10-01 14:54:07 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:07 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:07 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:07 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:07 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:07 --> Controller Class Initialized
INFO - 2024-10-01 14:54:10 --> Config Class Initialized
INFO - 2024-10-01 14:54:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:10 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:10 --> URI Class Initialized
INFO - 2024-10-01 14:54:10 --> Router Class Initialized
INFO - 2024-10-01 14:54:10 --> Output Class Initialized
INFO - 2024-10-01 14:54:10 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:10 --> Input Class Initialized
INFO - 2024-10-01 14:54:10 --> Language Class Initialized
INFO - 2024-10-01 14:54:10 --> Language Class Initialized
INFO - 2024-10-01 14:54:10 --> Config Class Initialized
INFO - 2024-10-01 14:54:10 --> Loader Class Initialized
INFO - 2024-10-01 14:54:10 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:10 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:10 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:10 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:10 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:10 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-10-01 14:54:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:10 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:10 --> Total execution time: 0.0318
INFO - 2024-10-01 14:54:10 --> Config Class Initialized
INFO - 2024-10-01 14:54:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:10 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:10 --> URI Class Initialized
INFO - 2024-10-01 14:54:10 --> Router Class Initialized
INFO - 2024-10-01 14:54:10 --> Output Class Initialized
INFO - 2024-10-01 14:54:10 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:10 --> Input Class Initialized
INFO - 2024-10-01 14:54:10 --> Language Class Initialized
ERROR - 2024-10-01 14:54:10 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:10 --> Config Class Initialized
INFO - 2024-10-01 14:54:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:10 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:10 --> URI Class Initialized
INFO - 2024-10-01 14:54:10 --> Router Class Initialized
INFO - 2024-10-01 14:54:10 --> Output Class Initialized
INFO - 2024-10-01 14:54:10 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:10 --> Input Class Initialized
INFO - 2024-10-01 14:54:10 --> Language Class Initialized
ERROR - 2024-10-01 14:54:10 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:10 --> Config Class Initialized
INFO - 2024-10-01 14:54:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:10 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:10 --> URI Class Initialized
INFO - 2024-10-01 14:54:10 --> Router Class Initialized
INFO - 2024-10-01 14:54:10 --> Output Class Initialized
INFO - 2024-10-01 14:54:10 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:10 --> Input Class Initialized
INFO - 2024-10-01 14:54:10 --> Language Class Initialized
INFO - 2024-10-01 14:54:10 --> Language Class Initialized
INFO - 2024-10-01 14:54:10 --> Config Class Initialized
INFO - 2024-10-01 14:54:10 --> Loader Class Initialized
INFO - 2024-10-01 14:54:10 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:10 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:10 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:10 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:10 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:10 --> Controller Class Initialized
INFO - 2024-10-01 14:54:13 --> Config Class Initialized
INFO - 2024-10-01 14:54:13 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:13 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:13 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:13 --> URI Class Initialized
INFO - 2024-10-01 14:54:13 --> Router Class Initialized
INFO - 2024-10-01 14:54:13 --> Output Class Initialized
INFO - 2024-10-01 14:54:13 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:13 --> Input Class Initialized
INFO - 2024-10-01 14:54:13 --> Language Class Initialized
INFO - 2024-10-01 14:54:13 --> Language Class Initialized
INFO - 2024-10-01 14:54:13 --> Config Class Initialized
INFO - 2024-10-01 14:54:13 --> Loader Class Initialized
INFO - 2024-10-01 14:54:13 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:13 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:13 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:13 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:13 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:13 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-10-01 14:54:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:13 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:13 --> Total execution time: 0.0362
INFO - 2024-10-01 14:54:13 --> Config Class Initialized
INFO - 2024-10-01 14:54:13 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:13 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:13 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:13 --> URI Class Initialized
INFO - 2024-10-01 14:54:13 --> Router Class Initialized
INFO - 2024-10-01 14:54:13 --> Output Class Initialized
INFO - 2024-10-01 14:54:13 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:13 --> Input Class Initialized
INFO - 2024-10-01 14:54:13 --> Language Class Initialized
ERROR - 2024-10-01 14:54:13 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:13 --> Config Class Initialized
INFO - 2024-10-01 14:54:13 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:13 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:13 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:13 --> URI Class Initialized
INFO - 2024-10-01 14:54:13 --> Router Class Initialized
INFO - 2024-10-01 14:54:13 --> Output Class Initialized
INFO - 2024-10-01 14:54:13 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:13 --> Input Class Initialized
INFO - 2024-10-01 14:54:13 --> Language Class Initialized
ERROR - 2024-10-01 14:54:13 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:13 --> Config Class Initialized
INFO - 2024-10-01 14:54:13 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:13 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:13 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:13 --> URI Class Initialized
INFO - 2024-10-01 14:54:13 --> Router Class Initialized
INFO - 2024-10-01 14:54:13 --> Output Class Initialized
INFO - 2024-10-01 14:54:13 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:13 --> Input Class Initialized
INFO - 2024-10-01 14:54:13 --> Language Class Initialized
INFO - 2024-10-01 14:54:13 --> Language Class Initialized
INFO - 2024-10-01 14:54:13 --> Config Class Initialized
INFO - 2024-10-01 14:54:13 --> Loader Class Initialized
INFO - 2024-10-01 14:54:13 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:13 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:13 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:13 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:14 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:14 --> Controller Class Initialized
INFO - 2024-10-01 14:54:41 --> Config Class Initialized
INFO - 2024-10-01 14:54:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:41 --> URI Class Initialized
INFO - 2024-10-01 14:54:41 --> Router Class Initialized
INFO - 2024-10-01 14:54:41 --> Output Class Initialized
INFO - 2024-10-01 14:54:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:41 --> Input Class Initialized
INFO - 2024-10-01 14:54:41 --> Language Class Initialized
INFO - 2024-10-01 14:54:41 --> Language Class Initialized
INFO - 2024-10-01 14:54:41 --> Config Class Initialized
INFO - 2024-10-01 14:54:41 --> Loader Class Initialized
INFO - 2024-10-01 14:54:41 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:41 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:41 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:41 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:41 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:41 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-10-01 14:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:41 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:41 --> Total execution time: 0.0273
INFO - 2024-10-01 14:54:41 --> Config Class Initialized
INFO - 2024-10-01 14:54:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:41 --> URI Class Initialized
INFO - 2024-10-01 14:54:41 --> Router Class Initialized
INFO - 2024-10-01 14:54:41 --> Output Class Initialized
INFO - 2024-10-01 14:54:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:41 --> Input Class Initialized
INFO - 2024-10-01 14:54:41 --> Language Class Initialized
ERROR - 2024-10-01 14:54:41 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:41 --> Config Class Initialized
INFO - 2024-10-01 14:54:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:41 --> URI Class Initialized
INFO - 2024-10-01 14:54:41 --> Router Class Initialized
INFO - 2024-10-01 14:54:41 --> Output Class Initialized
INFO - 2024-10-01 14:54:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:41 --> Input Class Initialized
INFO - 2024-10-01 14:54:41 --> Language Class Initialized
ERROR - 2024-10-01 14:54:41 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:41 --> Config Class Initialized
INFO - 2024-10-01 14:54:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:41 --> URI Class Initialized
INFO - 2024-10-01 14:54:41 --> Router Class Initialized
INFO - 2024-10-01 14:54:41 --> Output Class Initialized
INFO - 2024-10-01 14:54:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:41 --> Input Class Initialized
INFO - 2024-10-01 14:54:41 --> Language Class Initialized
INFO - 2024-10-01 14:54:41 --> Language Class Initialized
INFO - 2024-10-01 14:54:41 --> Config Class Initialized
INFO - 2024-10-01 14:54:41 --> Loader Class Initialized
INFO - 2024-10-01 14:54:41 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:41 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:41 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:41 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:41 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:41 --> Controller Class Initialized
INFO - 2024-10-01 14:54:42 --> Config Class Initialized
INFO - 2024-10-01 14:54:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:42 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:42 --> URI Class Initialized
INFO - 2024-10-01 14:54:42 --> Router Class Initialized
INFO - 2024-10-01 14:54:42 --> Output Class Initialized
INFO - 2024-10-01 14:54:42 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:42 --> Input Class Initialized
INFO - 2024-10-01 14:54:42 --> Language Class Initialized
INFO - 2024-10-01 14:54:42 --> Language Class Initialized
INFO - 2024-10-01 14:54:42 --> Config Class Initialized
INFO - 2024-10-01 14:54:42 --> Loader Class Initialized
INFO - 2024-10-01 14:54:42 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:42 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:42 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:42 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:42 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:42 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-10-01 14:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:42 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:42 --> Total execution time: 0.0269
INFO - 2024-10-01 14:54:42 --> Config Class Initialized
INFO - 2024-10-01 14:54:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:42 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:42 --> URI Class Initialized
INFO - 2024-10-01 14:54:42 --> Router Class Initialized
INFO - 2024-10-01 14:54:42 --> Output Class Initialized
INFO - 2024-10-01 14:54:42 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:42 --> Input Class Initialized
INFO - 2024-10-01 14:54:42 --> Language Class Initialized
ERROR - 2024-10-01 14:54:42 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:42 --> Config Class Initialized
INFO - 2024-10-01 14:54:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:42 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:42 --> URI Class Initialized
INFO - 2024-10-01 14:54:42 --> Router Class Initialized
INFO - 2024-10-01 14:54:42 --> Output Class Initialized
INFO - 2024-10-01 14:54:42 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:42 --> Input Class Initialized
INFO - 2024-10-01 14:54:42 --> Language Class Initialized
ERROR - 2024-10-01 14:54:42 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:42 --> Config Class Initialized
INFO - 2024-10-01 14:54:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:42 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:42 --> URI Class Initialized
INFO - 2024-10-01 14:54:42 --> Router Class Initialized
INFO - 2024-10-01 14:54:42 --> Output Class Initialized
INFO - 2024-10-01 14:54:42 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:42 --> Input Class Initialized
INFO - 2024-10-01 14:54:42 --> Language Class Initialized
INFO - 2024-10-01 14:54:42 --> Language Class Initialized
INFO - 2024-10-01 14:54:42 --> Config Class Initialized
INFO - 2024-10-01 14:54:42 --> Loader Class Initialized
INFO - 2024-10-01 14:54:42 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:42 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:42 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:42 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:42 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:42 --> Controller Class Initialized
INFO - 2024-10-01 14:54:46 --> Config Class Initialized
INFO - 2024-10-01 14:54:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:46 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:46 --> URI Class Initialized
INFO - 2024-10-01 14:54:46 --> Router Class Initialized
INFO - 2024-10-01 14:54:46 --> Output Class Initialized
INFO - 2024-10-01 14:54:46 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:46 --> Input Class Initialized
INFO - 2024-10-01 14:54:46 --> Language Class Initialized
INFO - 2024-10-01 14:54:46 --> Language Class Initialized
INFO - 2024-10-01 14:54:46 --> Config Class Initialized
INFO - 2024-10-01 14:54:46 --> Loader Class Initialized
INFO - 2024-10-01 14:54:46 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:46 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:46 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:46 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:46 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:46 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-10-01 14:54:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:46 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:46 --> Total execution time: 0.0278
INFO - 2024-10-01 14:54:46 --> Config Class Initialized
INFO - 2024-10-01 14:54:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:46 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:46 --> URI Class Initialized
INFO - 2024-10-01 14:54:46 --> Router Class Initialized
INFO - 2024-10-01 14:54:46 --> Output Class Initialized
INFO - 2024-10-01 14:54:46 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:46 --> Input Class Initialized
INFO - 2024-10-01 14:54:46 --> Language Class Initialized
ERROR - 2024-10-01 14:54:46 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:46 --> Config Class Initialized
INFO - 2024-10-01 14:54:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:46 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:46 --> URI Class Initialized
INFO - 2024-10-01 14:54:46 --> Router Class Initialized
INFO - 2024-10-01 14:54:46 --> Output Class Initialized
INFO - 2024-10-01 14:54:46 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:46 --> Input Class Initialized
INFO - 2024-10-01 14:54:46 --> Language Class Initialized
ERROR - 2024-10-01 14:54:46 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:46 --> Config Class Initialized
INFO - 2024-10-01 14:54:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:46 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:46 --> URI Class Initialized
INFO - 2024-10-01 14:54:46 --> Router Class Initialized
INFO - 2024-10-01 14:54:46 --> Output Class Initialized
INFO - 2024-10-01 14:54:46 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:46 --> Input Class Initialized
INFO - 2024-10-01 14:54:46 --> Language Class Initialized
INFO - 2024-10-01 14:54:46 --> Language Class Initialized
INFO - 2024-10-01 14:54:46 --> Config Class Initialized
INFO - 2024-10-01 14:54:46 --> Loader Class Initialized
INFO - 2024-10-01 14:54:46 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:46 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:46 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:46 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:46 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:46 --> Controller Class Initialized
INFO - 2024-10-01 14:54:49 --> Config Class Initialized
INFO - 2024-10-01 14:54:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:49 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:49 --> URI Class Initialized
INFO - 2024-10-01 14:54:49 --> Router Class Initialized
INFO - 2024-10-01 14:54:49 --> Output Class Initialized
INFO - 2024-10-01 14:54:49 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:49 --> Input Class Initialized
INFO - 2024-10-01 14:54:49 --> Language Class Initialized
INFO - 2024-10-01 14:54:49 --> Language Class Initialized
INFO - 2024-10-01 14:54:49 --> Config Class Initialized
INFO - 2024-10-01 14:54:49 --> Loader Class Initialized
INFO - 2024-10-01 14:54:49 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:49 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:49 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:49 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:49 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:49 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-01 14:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:49 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:49 --> Total execution time: 0.0266
INFO - 2024-10-01 14:54:49 --> Config Class Initialized
INFO - 2024-10-01 14:54:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:49 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:49 --> URI Class Initialized
INFO - 2024-10-01 14:54:49 --> Router Class Initialized
INFO - 2024-10-01 14:54:49 --> Output Class Initialized
INFO - 2024-10-01 14:54:49 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:49 --> Input Class Initialized
INFO - 2024-10-01 14:54:49 --> Language Class Initialized
ERROR - 2024-10-01 14:54:49 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:49 --> Config Class Initialized
INFO - 2024-10-01 14:54:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:49 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:49 --> URI Class Initialized
INFO - 2024-10-01 14:54:49 --> Router Class Initialized
INFO - 2024-10-01 14:54:49 --> Output Class Initialized
INFO - 2024-10-01 14:54:49 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:49 --> Input Class Initialized
INFO - 2024-10-01 14:54:49 --> Language Class Initialized
ERROR - 2024-10-01 14:54:49 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:49 --> Config Class Initialized
INFO - 2024-10-01 14:54:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:49 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:49 --> URI Class Initialized
INFO - 2024-10-01 14:54:49 --> Router Class Initialized
INFO - 2024-10-01 14:54:49 --> Output Class Initialized
INFO - 2024-10-01 14:54:49 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:49 --> Input Class Initialized
INFO - 2024-10-01 14:54:49 --> Language Class Initialized
INFO - 2024-10-01 14:54:49 --> Language Class Initialized
INFO - 2024-10-01 14:54:49 --> Config Class Initialized
INFO - 2024-10-01 14:54:49 --> Loader Class Initialized
INFO - 2024-10-01 14:54:49 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:49 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:49 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:49 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:49 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:49 --> Controller Class Initialized
INFO - 2024-10-01 14:54:55 --> Config Class Initialized
INFO - 2024-10-01 14:54:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:55 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:55 --> URI Class Initialized
INFO - 2024-10-01 14:54:55 --> Router Class Initialized
INFO - 2024-10-01 14:54:55 --> Output Class Initialized
INFO - 2024-10-01 14:54:55 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:55 --> Input Class Initialized
INFO - 2024-10-01 14:54:55 --> Language Class Initialized
INFO - 2024-10-01 14:54:55 --> Language Class Initialized
INFO - 2024-10-01 14:54:55 --> Config Class Initialized
INFO - 2024-10-01 14:54:55 --> Loader Class Initialized
INFO - 2024-10-01 14:54:55 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:55 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:55 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:55 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:55 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:55 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-01 14:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:55 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:55 --> Total execution time: 0.0285
INFO - 2024-10-01 14:54:55 --> Config Class Initialized
INFO - 2024-10-01 14:54:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:55 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:55 --> URI Class Initialized
INFO - 2024-10-01 14:54:55 --> Router Class Initialized
INFO - 2024-10-01 14:54:55 --> Output Class Initialized
INFO - 2024-10-01 14:54:55 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:55 --> Input Class Initialized
INFO - 2024-10-01 14:54:55 --> Language Class Initialized
ERROR - 2024-10-01 14:54:55 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:55 --> Config Class Initialized
INFO - 2024-10-01 14:54:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:55 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:55 --> URI Class Initialized
INFO - 2024-10-01 14:54:55 --> Router Class Initialized
INFO - 2024-10-01 14:54:55 --> Output Class Initialized
INFO - 2024-10-01 14:54:55 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:55 --> Input Class Initialized
INFO - 2024-10-01 14:54:55 --> Language Class Initialized
ERROR - 2024-10-01 14:54:55 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:55 --> Config Class Initialized
INFO - 2024-10-01 14:54:55 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:55 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:55 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:55 --> URI Class Initialized
INFO - 2024-10-01 14:54:55 --> Router Class Initialized
INFO - 2024-10-01 14:54:55 --> Output Class Initialized
INFO - 2024-10-01 14:54:55 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:55 --> Input Class Initialized
INFO - 2024-10-01 14:54:55 --> Language Class Initialized
INFO - 2024-10-01 14:54:55 --> Language Class Initialized
INFO - 2024-10-01 14:54:55 --> Config Class Initialized
INFO - 2024-10-01 14:54:55 --> Loader Class Initialized
INFO - 2024-10-01 14:54:55 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:55 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:55 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:55 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:55 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:55 --> Controller Class Initialized
INFO - 2024-10-01 14:54:58 --> Config Class Initialized
INFO - 2024-10-01 14:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:58 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:58 --> URI Class Initialized
INFO - 2024-10-01 14:54:58 --> Router Class Initialized
INFO - 2024-10-01 14:54:58 --> Output Class Initialized
INFO - 2024-10-01 14:54:58 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:58 --> Input Class Initialized
INFO - 2024-10-01 14:54:58 --> Language Class Initialized
INFO - 2024-10-01 14:54:58 --> Language Class Initialized
INFO - 2024-10-01 14:54:58 --> Config Class Initialized
INFO - 2024-10-01 14:54:58 --> Loader Class Initialized
INFO - 2024-10-01 14:54:58 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:58 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:58 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:58 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:58 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:58 --> Controller Class Initialized
DEBUG - 2024-10-01 14:54:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-01 14:54:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:54:58 --> Final output sent to browser
DEBUG - 2024-10-01 14:54:58 --> Total execution time: 0.0301
INFO - 2024-10-01 14:54:58 --> Config Class Initialized
INFO - 2024-10-01 14:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:58 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:58 --> URI Class Initialized
INFO - 2024-10-01 14:54:58 --> Router Class Initialized
INFO - 2024-10-01 14:54:58 --> Output Class Initialized
INFO - 2024-10-01 14:54:58 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:58 --> Input Class Initialized
INFO - 2024-10-01 14:54:58 --> Language Class Initialized
ERROR - 2024-10-01 14:54:58 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:58 --> Config Class Initialized
INFO - 2024-10-01 14:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:58 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:58 --> URI Class Initialized
INFO - 2024-10-01 14:54:58 --> Router Class Initialized
INFO - 2024-10-01 14:54:58 --> Output Class Initialized
INFO - 2024-10-01 14:54:58 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:58 --> Input Class Initialized
INFO - 2024-10-01 14:54:58 --> Language Class Initialized
ERROR - 2024-10-01 14:54:58 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:54:58 --> Config Class Initialized
INFO - 2024-10-01 14:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:58 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:58 --> URI Class Initialized
INFO - 2024-10-01 14:54:58 --> Router Class Initialized
INFO - 2024-10-01 14:54:58 --> Output Class Initialized
INFO - 2024-10-01 14:54:58 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:58 --> Input Class Initialized
INFO - 2024-10-01 14:54:58 --> Language Class Initialized
INFO - 2024-10-01 14:54:58 --> Language Class Initialized
INFO - 2024-10-01 14:54:58 --> Config Class Initialized
INFO - 2024-10-01 14:54:58 --> Loader Class Initialized
INFO - 2024-10-01 14:54:58 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:58 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:58 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:58 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:58 --> Database Driver Class Initialized
INFO - 2024-10-01 14:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:54:58 --> Controller Class Initialized
INFO - 2024-10-01 14:54:59 --> Config Class Initialized
INFO - 2024-10-01 14:54:59 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:54:59 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:54:59 --> Utf8 Class Initialized
INFO - 2024-10-01 14:54:59 --> URI Class Initialized
INFO - 2024-10-01 14:54:59 --> Router Class Initialized
INFO - 2024-10-01 14:54:59 --> Output Class Initialized
INFO - 2024-10-01 14:54:59 --> Security Class Initialized
DEBUG - 2024-10-01 14:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:54:59 --> Input Class Initialized
INFO - 2024-10-01 14:54:59 --> Language Class Initialized
INFO - 2024-10-01 14:54:59 --> Language Class Initialized
INFO - 2024-10-01 14:54:59 --> Config Class Initialized
INFO - 2024-10-01 14:54:59 --> Loader Class Initialized
INFO - 2024-10-01 14:54:59 --> Helper loaded: url_helper
INFO - 2024-10-01 14:54:59 --> Helper loaded: file_helper
INFO - 2024-10-01 14:54:59 --> Helper loaded: form_helper
INFO - 2024-10-01 14:54:59 --> Helper loaded: my_helper
INFO - 2024-10-01 14:54:59 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:00 --> Controller Class Initialized
DEBUG - 2024-10-01 14:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-01 14:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:55:00 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:00 --> Total execution time: 0.0347
INFO - 2024-10-01 14:55:00 --> Config Class Initialized
INFO - 2024-10-01 14:55:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:00 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:00 --> URI Class Initialized
INFO - 2024-10-01 14:55:00 --> Router Class Initialized
INFO - 2024-10-01 14:55:00 --> Output Class Initialized
INFO - 2024-10-01 14:55:00 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:00 --> Input Class Initialized
INFO - 2024-10-01 14:55:00 --> Language Class Initialized
ERROR - 2024-10-01 14:55:00 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:55:00 --> Config Class Initialized
INFO - 2024-10-01 14:55:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:00 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:00 --> URI Class Initialized
INFO - 2024-10-01 14:55:00 --> Router Class Initialized
INFO - 2024-10-01 14:55:00 --> Output Class Initialized
INFO - 2024-10-01 14:55:00 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:00 --> Input Class Initialized
INFO - 2024-10-01 14:55:00 --> Language Class Initialized
ERROR - 2024-10-01 14:55:00 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:55:00 --> Config Class Initialized
INFO - 2024-10-01 14:55:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:00 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:00 --> URI Class Initialized
INFO - 2024-10-01 14:55:00 --> Router Class Initialized
INFO - 2024-10-01 14:55:00 --> Output Class Initialized
INFO - 2024-10-01 14:55:00 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:00 --> Input Class Initialized
INFO - 2024-10-01 14:55:00 --> Language Class Initialized
INFO - 2024-10-01 14:55:00 --> Language Class Initialized
INFO - 2024-10-01 14:55:00 --> Config Class Initialized
INFO - 2024-10-01 14:55:00 --> Loader Class Initialized
INFO - 2024-10-01 14:55:00 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:00 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:00 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:00 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:00 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:00 --> Controller Class Initialized
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:03 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:03 --> URI Class Initialized
INFO - 2024-10-01 14:55:03 --> Router Class Initialized
INFO - 2024-10-01 14:55:03 --> Output Class Initialized
INFO - 2024-10-01 14:55:03 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:03 --> Input Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Loader Class Initialized
INFO - 2024-10-01 14:55:03 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:03 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:03 --> Controller Class Initialized
INFO - 2024-10-01 14:55:03 --> Helper loaded: cookie_helper
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:03 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:03 --> URI Class Initialized
INFO - 2024-10-01 14:55:03 --> Router Class Initialized
INFO - 2024-10-01 14:55:03 --> Output Class Initialized
INFO - 2024-10-01 14:55:03 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:03 --> Input Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Loader Class Initialized
INFO - 2024-10-01 14:55:03 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:03 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:03 --> Controller Class Initialized
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:03 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:03 --> URI Class Initialized
INFO - 2024-10-01 14:55:03 --> Router Class Initialized
INFO - 2024-10-01 14:55:03 --> Output Class Initialized
INFO - 2024-10-01 14:55:03 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:03 --> Input Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Loader Class Initialized
INFO - 2024-10-01 14:55:03 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:03 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:03 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:03 --> Controller Class Initialized
DEBUG - 2024-10-01 14:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 14:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:55:03 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:03 --> Total execution time: 0.0352
INFO - 2024-10-01 14:55:03 --> Config Class Initialized
INFO - 2024-10-01 14:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:03 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:03 --> URI Class Initialized
INFO - 2024-10-01 14:55:03 --> Router Class Initialized
INFO - 2024-10-01 14:55:03 --> Output Class Initialized
INFO - 2024-10-01 14:55:03 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:03 --> Input Class Initialized
INFO - 2024-10-01 14:55:03 --> Language Class Initialized
ERROR - 2024-10-01 14:55:03 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:55:10 --> Config Class Initialized
INFO - 2024-10-01 14:55:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:10 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:10 --> URI Class Initialized
INFO - 2024-10-01 14:55:10 --> Router Class Initialized
INFO - 2024-10-01 14:55:10 --> Output Class Initialized
INFO - 2024-10-01 14:55:10 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:10 --> Input Class Initialized
INFO - 2024-10-01 14:55:10 --> Language Class Initialized
INFO - 2024-10-01 14:55:10 --> Language Class Initialized
INFO - 2024-10-01 14:55:10 --> Config Class Initialized
INFO - 2024-10-01 14:55:10 --> Loader Class Initialized
INFO - 2024-10-01 14:55:10 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:10 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:10 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:10 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:10 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:10 --> Controller Class Initialized
INFO - 2024-10-01 14:55:10 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:10 --> Total execution time: 0.0275
INFO - 2024-10-01 14:55:20 --> Config Class Initialized
INFO - 2024-10-01 14:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:20 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:20 --> URI Class Initialized
INFO - 2024-10-01 14:55:20 --> Router Class Initialized
INFO - 2024-10-01 14:55:20 --> Output Class Initialized
INFO - 2024-10-01 14:55:20 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:20 --> Input Class Initialized
INFO - 2024-10-01 14:55:20 --> Language Class Initialized
INFO - 2024-10-01 14:55:20 --> Language Class Initialized
INFO - 2024-10-01 14:55:20 --> Config Class Initialized
INFO - 2024-10-01 14:55:20 --> Loader Class Initialized
INFO - 2024-10-01 14:55:20 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:20 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:20 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:20 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:20 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:20 --> Controller Class Initialized
INFO - 2024-10-01 14:55:20 --> Helper loaded: cookie_helper
INFO - 2024-10-01 14:55:20 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:20 --> Total execution time: 0.0282
INFO - 2024-10-01 14:55:20 --> Config Class Initialized
INFO - 2024-10-01 14:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:20 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:20 --> URI Class Initialized
INFO - 2024-10-01 14:55:20 --> Router Class Initialized
INFO - 2024-10-01 14:55:20 --> Output Class Initialized
INFO - 2024-10-01 14:55:20 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:20 --> Input Class Initialized
INFO - 2024-10-01 14:55:20 --> Language Class Initialized
INFO - 2024-10-01 14:55:20 --> Language Class Initialized
INFO - 2024-10-01 14:55:20 --> Config Class Initialized
INFO - 2024-10-01 14:55:20 --> Loader Class Initialized
INFO - 2024-10-01 14:55:20 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:20 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:20 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:20 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:20 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:20 --> Controller Class Initialized
DEBUG - 2024-10-01 14:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-01 14:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:55:20 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:20 --> Total execution time: 0.0305
INFO - 2024-10-01 14:55:20 --> Config Class Initialized
INFO - 2024-10-01 14:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:20 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:20 --> URI Class Initialized
INFO - 2024-10-01 14:55:20 --> Router Class Initialized
INFO - 2024-10-01 14:55:20 --> Output Class Initialized
INFO - 2024-10-01 14:55:20 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:20 --> Input Class Initialized
INFO - 2024-10-01 14:55:20 --> Language Class Initialized
ERROR - 2024-10-01 14:55:20 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:55:23 --> Config Class Initialized
INFO - 2024-10-01 14:55:23 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:23 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:23 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:23 --> URI Class Initialized
INFO - 2024-10-01 14:55:23 --> Router Class Initialized
INFO - 2024-10-01 14:55:23 --> Output Class Initialized
INFO - 2024-10-01 14:55:23 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:23 --> Input Class Initialized
INFO - 2024-10-01 14:55:23 --> Language Class Initialized
INFO - 2024-10-01 14:55:23 --> Language Class Initialized
INFO - 2024-10-01 14:55:23 --> Config Class Initialized
INFO - 2024-10-01 14:55:23 --> Loader Class Initialized
INFO - 2024-10-01 14:55:23 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:23 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:23 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:23 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:23 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:23 --> Controller Class Initialized
DEBUG - 2024-10-01 14:55:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 14:55:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:55:23 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:23 --> Total execution time: 0.0304
INFO - 2024-10-01 14:55:23 --> Config Class Initialized
INFO - 2024-10-01 14:55:23 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:23 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:23 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:23 --> URI Class Initialized
INFO - 2024-10-01 14:55:23 --> Router Class Initialized
INFO - 2024-10-01 14:55:23 --> Output Class Initialized
INFO - 2024-10-01 14:55:23 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:23 --> Input Class Initialized
INFO - 2024-10-01 14:55:23 --> Language Class Initialized
ERROR - 2024-10-01 14:55:23 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:55:38 --> Config Class Initialized
INFO - 2024-10-01 14:55:38 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:38 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:38 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:38 --> URI Class Initialized
INFO - 2024-10-01 14:55:38 --> Router Class Initialized
INFO - 2024-10-01 14:55:38 --> Output Class Initialized
INFO - 2024-10-01 14:55:38 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:38 --> Input Class Initialized
INFO - 2024-10-01 14:55:38 --> Language Class Initialized
INFO - 2024-10-01 14:55:38 --> Language Class Initialized
INFO - 2024-10-01 14:55:38 --> Config Class Initialized
INFO - 2024-10-01 14:55:38 --> Loader Class Initialized
INFO - 2024-10-01 14:55:38 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:38 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:38 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:38 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:38 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:38 --> Controller Class Initialized
DEBUG - 2024-10-01 14:55:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 14:55:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:55:38 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:38 --> Total execution time: 0.0452
INFO - 2024-10-01 14:55:39 --> Config Class Initialized
INFO - 2024-10-01 14:55:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:39 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:39 --> URI Class Initialized
INFO - 2024-10-01 14:55:39 --> Router Class Initialized
INFO - 2024-10-01 14:55:39 --> Output Class Initialized
INFO - 2024-10-01 14:55:39 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:39 --> Input Class Initialized
INFO - 2024-10-01 14:55:39 --> Language Class Initialized
ERROR - 2024-10-01 14:55:39 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:55:39 --> Config Class Initialized
INFO - 2024-10-01 14:55:39 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:39 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:39 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:39 --> URI Class Initialized
INFO - 2024-10-01 14:55:39 --> Router Class Initialized
INFO - 2024-10-01 14:55:39 --> Output Class Initialized
INFO - 2024-10-01 14:55:39 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:39 --> Input Class Initialized
INFO - 2024-10-01 14:55:39 --> Language Class Initialized
INFO - 2024-10-01 14:55:39 --> Language Class Initialized
INFO - 2024-10-01 14:55:39 --> Config Class Initialized
INFO - 2024-10-01 14:55:39 --> Loader Class Initialized
INFO - 2024-10-01 14:55:39 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:39 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:39 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:39 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:39 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:39 --> Controller Class Initialized
INFO - 2024-10-01 14:55:41 --> Config Class Initialized
INFO - 2024-10-01 14:55:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:41 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:41 --> URI Class Initialized
INFO - 2024-10-01 14:55:41 --> Router Class Initialized
INFO - 2024-10-01 14:55:41 --> Output Class Initialized
INFO - 2024-10-01 14:55:41 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:41 --> Input Class Initialized
INFO - 2024-10-01 14:55:41 --> Language Class Initialized
INFO - 2024-10-01 14:55:41 --> Language Class Initialized
INFO - 2024-10-01 14:55:41 --> Config Class Initialized
INFO - 2024-10-01 14:55:41 --> Loader Class Initialized
INFO - 2024-10-01 14:55:41 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:41 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:41 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:41 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:41 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:41 --> Controller Class Initialized
INFO - 2024-10-01 14:55:41 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:41 --> Total execution time: 0.0428
INFO - 2024-10-01 14:55:46 --> Config Class Initialized
INFO - 2024-10-01 14:55:46 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:46 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:46 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:46 --> URI Class Initialized
INFO - 2024-10-01 14:55:46 --> Router Class Initialized
INFO - 2024-10-01 14:55:46 --> Output Class Initialized
INFO - 2024-10-01 14:55:46 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:46 --> Input Class Initialized
INFO - 2024-10-01 14:55:46 --> Language Class Initialized
INFO - 2024-10-01 14:55:46 --> Language Class Initialized
INFO - 2024-10-01 14:55:46 --> Config Class Initialized
INFO - 2024-10-01 14:55:46 --> Loader Class Initialized
INFO - 2024-10-01 14:55:46 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:46 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:46 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:46 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:46 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:46 --> Controller Class Initialized
INFO - 2024-10-01 14:55:46 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:46 --> Total execution time: 0.0361
INFO - 2024-10-01 14:55:49 --> Config Class Initialized
INFO - 2024-10-01 14:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:49 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:49 --> URI Class Initialized
INFO - 2024-10-01 14:55:49 --> Router Class Initialized
INFO - 2024-10-01 14:55:49 --> Output Class Initialized
INFO - 2024-10-01 14:55:49 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:49 --> Input Class Initialized
INFO - 2024-10-01 14:55:49 --> Language Class Initialized
INFO - 2024-10-01 14:55:49 --> Language Class Initialized
INFO - 2024-10-01 14:55:49 --> Config Class Initialized
INFO - 2024-10-01 14:55:49 --> Loader Class Initialized
INFO - 2024-10-01 14:55:49 --> Helper loaded: url_helper
INFO - 2024-10-01 14:55:49 --> Helper loaded: file_helper
INFO - 2024-10-01 14:55:49 --> Helper loaded: form_helper
INFO - 2024-10-01 14:55:49 --> Helper loaded: my_helper
INFO - 2024-10-01 14:55:49 --> Database Driver Class Initialized
INFO - 2024-10-01 14:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:55:49 --> Controller Class Initialized
DEBUG - 2024-10-01 14:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 14:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:55:49 --> Final output sent to browser
DEBUG - 2024-10-01 14:55:49 --> Total execution time: 0.0267
INFO - 2024-10-01 14:55:49 --> Config Class Initialized
INFO - 2024-10-01 14:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:55:49 --> Utf8 Class Initialized
INFO - 2024-10-01 14:55:49 --> URI Class Initialized
INFO - 2024-10-01 14:55:49 --> Router Class Initialized
INFO - 2024-10-01 14:55:49 --> Output Class Initialized
INFO - 2024-10-01 14:55:49 --> Security Class Initialized
DEBUG - 2024-10-01 14:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:55:49 --> Input Class Initialized
INFO - 2024-10-01 14:55:49 --> Language Class Initialized
ERROR - 2024-10-01 14:55:49 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:57:00 --> Config Class Initialized
INFO - 2024-10-01 14:57:00 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:00 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:00 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:00 --> URI Class Initialized
INFO - 2024-10-01 14:57:00 --> Router Class Initialized
INFO - 2024-10-01 14:57:00 --> Output Class Initialized
INFO - 2024-10-01 14:57:00 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:00 --> Input Class Initialized
INFO - 2024-10-01 14:57:00 --> Language Class Initialized
INFO - 2024-10-01 14:57:00 --> Language Class Initialized
INFO - 2024-10-01 14:57:00 --> Config Class Initialized
INFO - 2024-10-01 14:57:00 --> Loader Class Initialized
INFO - 2024-10-01 14:57:00 --> Helper loaded: url_helper
INFO - 2024-10-01 14:57:00 --> Helper loaded: file_helper
INFO - 2024-10-01 14:57:00 --> Helper loaded: form_helper
INFO - 2024-10-01 14:57:00 --> Helper loaded: my_helper
INFO - 2024-10-01 14:57:00 --> Database Driver Class Initialized
INFO - 2024-10-01 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:57:00 --> Controller Class Initialized
DEBUG - 2024-10-01 14:57:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 14:57:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:57:00 --> Final output sent to browser
DEBUG - 2024-10-01 14:57:00 --> Total execution time: 0.0343
INFO - 2024-10-01 14:57:01 --> Config Class Initialized
INFO - 2024-10-01 14:57:01 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:01 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:01 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:01 --> URI Class Initialized
INFO - 2024-10-01 14:57:01 --> Router Class Initialized
INFO - 2024-10-01 14:57:01 --> Output Class Initialized
INFO - 2024-10-01 14:57:01 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:01 --> Input Class Initialized
INFO - 2024-10-01 14:57:01 --> Language Class Initialized
ERROR - 2024-10-01 14:57:01 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:57:14 --> Config Class Initialized
INFO - 2024-10-01 14:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:14 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:14 --> URI Class Initialized
INFO - 2024-10-01 14:57:14 --> Router Class Initialized
INFO - 2024-10-01 14:57:14 --> Output Class Initialized
INFO - 2024-10-01 14:57:14 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:14 --> Input Class Initialized
INFO - 2024-10-01 14:57:14 --> Language Class Initialized
INFO - 2024-10-01 14:57:14 --> Language Class Initialized
INFO - 2024-10-01 14:57:14 --> Config Class Initialized
INFO - 2024-10-01 14:57:14 --> Loader Class Initialized
INFO - 2024-10-01 14:57:14 --> Helper loaded: url_helper
INFO - 2024-10-01 14:57:14 --> Helper loaded: file_helper
INFO - 2024-10-01 14:57:14 --> Helper loaded: form_helper
INFO - 2024-10-01 14:57:14 --> Helper loaded: my_helper
INFO - 2024-10-01 14:57:14 --> Database Driver Class Initialized
INFO - 2024-10-01 14:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:57:14 --> Controller Class Initialized
DEBUG - 2024-10-01 14:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 14:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:57:14 --> Final output sent to browser
DEBUG - 2024-10-01 14:57:14 --> Total execution time: 0.0325
INFO - 2024-10-01 14:57:14 --> Config Class Initialized
INFO - 2024-10-01 14:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:14 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:14 --> URI Class Initialized
INFO - 2024-10-01 14:57:14 --> Router Class Initialized
INFO - 2024-10-01 14:57:14 --> Output Class Initialized
INFO - 2024-10-01 14:57:14 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:14 --> Input Class Initialized
INFO - 2024-10-01 14:57:14 --> Language Class Initialized
ERROR - 2024-10-01 14:57:14 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:57:14 --> Config Class Initialized
INFO - 2024-10-01 14:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:14 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:14 --> URI Class Initialized
INFO - 2024-10-01 14:57:14 --> Router Class Initialized
INFO - 2024-10-01 14:57:14 --> Output Class Initialized
INFO - 2024-10-01 14:57:14 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:14 --> Input Class Initialized
INFO - 2024-10-01 14:57:14 --> Language Class Initialized
INFO - 2024-10-01 14:57:14 --> Language Class Initialized
INFO - 2024-10-01 14:57:14 --> Config Class Initialized
INFO - 2024-10-01 14:57:14 --> Loader Class Initialized
INFO - 2024-10-01 14:57:14 --> Helper loaded: url_helper
INFO - 2024-10-01 14:57:14 --> Helper loaded: file_helper
INFO - 2024-10-01 14:57:14 --> Helper loaded: form_helper
INFO - 2024-10-01 14:57:14 --> Helper loaded: my_helper
INFO - 2024-10-01 14:57:14 --> Database Driver Class Initialized
INFO - 2024-10-01 14:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:57:14 --> Controller Class Initialized
INFO - 2024-10-01 14:57:21 --> Config Class Initialized
INFO - 2024-10-01 14:57:21 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:21 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:21 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:21 --> URI Class Initialized
INFO - 2024-10-01 14:57:21 --> Router Class Initialized
INFO - 2024-10-01 14:57:21 --> Output Class Initialized
INFO - 2024-10-01 14:57:21 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:21 --> Input Class Initialized
INFO - 2024-10-01 14:57:21 --> Language Class Initialized
INFO - 2024-10-01 14:57:21 --> Language Class Initialized
INFO - 2024-10-01 14:57:21 --> Config Class Initialized
INFO - 2024-10-01 14:57:21 --> Loader Class Initialized
INFO - 2024-10-01 14:57:21 --> Helper loaded: url_helper
INFO - 2024-10-01 14:57:21 --> Helper loaded: file_helper
INFO - 2024-10-01 14:57:21 --> Helper loaded: form_helper
INFO - 2024-10-01 14:57:21 --> Helper loaded: my_helper
INFO - 2024-10-01 14:57:21 --> Database Driver Class Initialized
INFO - 2024-10-01 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:57:21 --> Controller Class Initialized
DEBUG - 2024-10-01 14:57:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 14:57:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:57:21 --> Final output sent to browser
DEBUG - 2024-10-01 14:57:21 --> Total execution time: 0.0313
INFO - 2024-10-01 14:57:21 --> Config Class Initialized
INFO - 2024-10-01 14:57:21 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:57:21 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:57:21 --> Utf8 Class Initialized
INFO - 2024-10-01 14:57:21 --> URI Class Initialized
INFO - 2024-10-01 14:57:21 --> Router Class Initialized
INFO - 2024-10-01 14:57:21 --> Output Class Initialized
INFO - 2024-10-01 14:57:21 --> Security Class Initialized
DEBUG - 2024-10-01 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:57:21 --> Input Class Initialized
INFO - 2024-10-01 14:57:21 --> Language Class Initialized
ERROR - 2024-10-01 14:57:21 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:58:56 --> Config Class Initialized
INFO - 2024-10-01 14:58:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:58:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:58:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:58:56 --> URI Class Initialized
INFO - 2024-10-01 14:58:56 --> Router Class Initialized
INFO - 2024-10-01 14:58:56 --> Output Class Initialized
INFO - 2024-10-01 14:58:56 --> Security Class Initialized
DEBUG - 2024-10-01 14:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:58:56 --> Input Class Initialized
INFO - 2024-10-01 14:58:56 --> Language Class Initialized
INFO - 2024-10-01 14:58:56 --> Language Class Initialized
INFO - 2024-10-01 14:58:56 --> Config Class Initialized
INFO - 2024-10-01 14:58:56 --> Loader Class Initialized
INFO - 2024-10-01 14:58:56 --> Helper loaded: url_helper
INFO - 2024-10-01 14:58:56 --> Helper loaded: file_helper
INFO - 2024-10-01 14:58:56 --> Helper loaded: form_helper
INFO - 2024-10-01 14:58:56 --> Helper loaded: my_helper
INFO - 2024-10-01 14:58:56 --> Database Driver Class Initialized
INFO - 2024-10-01 14:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:58:56 --> Controller Class Initialized
DEBUG - 2024-10-01 14:58:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 14:58:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:58:56 --> Final output sent to browser
DEBUG - 2024-10-01 14:58:56 --> Total execution time: 0.0273
INFO - 2024-10-01 14:58:56 --> Config Class Initialized
INFO - 2024-10-01 14:58:56 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:58:56 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:58:56 --> Utf8 Class Initialized
INFO - 2024-10-01 14:58:56 --> URI Class Initialized
INFO - 2024-10-01 14:58:56 --> Router Class Initialized
INFO - 2024-10-01 14:58:56 --> Output Class Initialized
INFO - 2024-10-01 14:58:56 --> Security Class Initialized
DEBUG - 2024-10-01 14:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:58:56 --> Input Class Initialized
INFO - 2024-10-01 14:58:56 --> Language Class Initialized
ERROR - 2024-10-01 14:58:56 --> 404 Page Not Found: /index
INFO - 2024-10-01 14:59:02 --> Config Class Initialized
INFO - 2024-10-01 14:59:02 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:59:02 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:59:02 --> Utf8 Class Initialized
INFO - 2024-10-01 14:59:02 --> URI Class Initialized
INFO - 2024-10-01 14:59:02 --> Router Class Initialized
INFO - 2024-10-01 14:59:02 --> Output Class Initialized
INFO - 2024-10-01 14:59:02 --> Security Class Initialized
DEBUG - 2024-10-01 14:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:59:02 --> Input Class Initialized
INFO - 2024-10-01 14:59:02 --> Language Class Initialized
INFO - 2024-10-01 14:59:02 --> Language Class Initialized
INFO - 2024-10-01 14:59:02 --> Config Class Initialized
INFO - 2024-10-01 14:59:02 --> Loader Class Initialized
INFO - 2024-10-01 14:59:02 --> Helper loaded: url_helper
INFO - 2024-10-01 14:59:02 --> Helper loaded: file_helper
INFO - 2024-10-01 14:59:02 --> Helper loaded: form_helper
INFO - 2024-10-01 14:59:02 --> Helper loaded: my_helper
INFO - 2024-10-01 14:59:02 --> Database Driver Class Initialized
INFO - 2024-10-01 14:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 14:59:02 --> Controller Class Initialized
DEBUG - 2024-10-01 14:59:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 14:59:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 14:59:02 --> Final output sent to browser
DEBUG - 2024-10-01 14:59:02 --> Total execution time: 0.0316
INFO - 2024-10-01 14:59:02 --> Config Class Initialized
INFO - 2024-10-01 14:59:02 --> Hooks Class Initialized
DEBUG - 2024-10-01 14:59:02 --> UTF-8 Support Enabled
INFO - 2024-10-01 14:59:02 --> Utf8 Class Initialized
INFO - 2024-10-01 14:59:02 --> URI Class Initialized
INFO - 2024-10-01 14:59:02 --> Router Class Initialized
INFO - 2024-10-01 14:59:02 --> Output Class Initialized
INFO - 2024-10-01 14:59:02 --> Security Class Initialized
DEBUG - 2024-10-01 14:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 14:59:02 --> Input Class Initialized
INFO - 2024-10-01 14:59:02 --> Language Class Initialized
ERROR - 2024-10-01 14:59:02 --> 404 Page Not Found: /index
INFO - 2024-10-01 15:01:11 --> Config Class Initialized
INFO - 2024-10-01 15:01:11 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:01:11 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:01:11 --> Utf8 Class Initialized
INFO - 2024-10-01 15:01:11 --> URI Class Initialized
INFO - 2024-10-01 15:01:11 --> Router Class Initialized
INFO - 2024-10-01 15:01:11 --> Output Class Initialized
INFO - 2024-10-01 15:01:11 --> Security Class Initialized
DEBUG - 2024-10-01 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:01:11 --> Input Class Initialized
INFO - 2024-10-01 15:01:11 --> Language Class Initialized
INFO - 2024-10-01 15:01:11 --> Language Class Initialized
INFO - 2024-10-01 15:01:11 --> Config Class Initialized
INFO - 2024-10-01 15:01:11 --> Loader Class Initialized
INFO - 2024-10-01 15:01:11 --> Helper loaded: url_helper
INFO - 2024-10-01 15:01:11 --> Helper loaded: file_helper
INFO - 2024-10-01 15:01:11 --> Helper loaded: form_helper
INFO - 2024-10-01 15:01:11 --> Helper loaded: my_helper
INFO - 2024-10-01 15:01:11 --> Database Driver Class Initialized
INFO - 2024-10-01 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:01:11 --> Controller Class Initialized
DEBUG - 2024-10-01 15:01:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 15:01:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 15:01:11 --> Final output sent to browser
DEBUG - 2024-10-01 15:01:11 --> Total execution time: 0.0288
INFO - 2024-10-01 15:01:11 --> Config Class Initialized
INFO - 2024-10-01 15:01:11 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:01:11 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:01:11 --> Utf8 Class Initialized
INFO - 2024-10-01 15:01:11 --> URI Class Initialized
INFO - 2024-10-01 15:01:11 --> Router Class Initialized
INFO - 2024-10-01 15:01:11 --> Output Class Initialized
INFO - 2024-10-01 15:01:11 --> Security Class Initialized
DEBUG - 2024-10-01 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:01:11 --> Input Class Initialized
INFO - 2024-10-01 15:01:11 --> Language Class Initialized
ERROR - 2024-10-01 15:01:11 --> 404 Page Not Found: /index
INFO - 2024-10-01 15:01:11 --> Config Class Initialized
INFO - 2024-10-01 15:01:11 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:01:11 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:01:11 --> Utf8 Class Initialized
INFO - 2024-10-01 15:01:11 --> URI Class Initialized
INFO - 2024-10-01 15:01:11 --> Router Class Initialized
INFO - 2024-10-01 15:01:11 --> Output Class Initialized
INFO - 2024-10-01 15:01:11 --> Security Class Initialized
DEBUG - 2024-10-01 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:01:11 --> Input Class Initialized
INFO - 2024-10-01 15:01:11 --> Language Class Initialized
INFO - 2024-10-01 15:01:11 --> Language Class Initialized
INFO - 2024-10-01 15:01:11 --> Config Class Initialized
INFO - 2024-10-01 15:01:11 --> Loader Class Initialized
INFO - 2024-10-01 15:01:11 --> Helper loaded: url_helper
INFO - 2024-10-01 15:01:11 --> Helper loaded: file_helper
INFO - 2024-10-01 15:01:11 --> Helper loaded: form_helper
INFO - 2024-10-01 15:01:11 --> Helper loaded: my_helper
INFO - 2024-10-01 15:01:11 --> Database Driver Class Initialized
INFO - 2024-10-01 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:01:11 --> Controller Class Initialized
INFO - 2024-10-01 15:01:14 --> Config Class Initialized
INFO - 2024-10-01 15:01:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:01:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:01:14 --> Utf8 Class Initialized
INFO - 2024-10-01 15:01:14 --> URI Class Initialized
INFO - 2024-10-01 15:01:14 --> Router Class Initialized
INFO - 2024-10-01 15:01:14 --> Output Class Initialized
INFO - 2024-10-01 15:01:14 --> Security Class Initialized
DEBUG - 2024-10-01 15:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:01:14 --> Input Class Initialized
INFO - 2024-10-01 15:01:14 --> Language Class Initialized
INFO - 2024-10-01 15:01:14 --> Language Class Initialized
INFO - 2024-10-01 15:01:14 --> Config Class Initialized
INFO - 2024-10-01 15:01:14 --> Loader Class Initialized
INFO - 2024-10-01 15:01:14 --> Helper loaded: url_helper
INFO - 2024-10-01 15:01:14 --> Helper loaded: file_helper
INFO - 2024-10-01 15:01:14 --> Helper loaded: form_helper
INFO - 2024-10-01 15:01:14 --> Helper loaded: my_helper
INFO - 2024-10-01 15:01:14 --> Database Driver Class Initialized
INFO - 2024-10-01 15:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:01:14 --> Controller Class Initialized
DEBUG - 2024-10-01 15:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 15:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 15:01:14 --> Final output sent to browser
DEBUG - 2024-10-01 15:01:14 --> Total execution time: 0.0315
INFO - 2024-10-01 15:01:14 --> Config Class Initialized
INFO - 2024-10-01 15:01:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:01:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:01:14 --> Utf8 Class Initialized
INFO - 2024-10-01 15:01:14 --> URI Class Initialized
INFO - 2024-10-01 15:01:14 --> Router Class Initialized
INFO - 2024-10-01 15:01:14 --> Output Class Initialized
INFO - 2024-10-01 15:01:14 --> Security Class Initialized
DEBUG - 2024-10-01 15:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:01:14 --> Input Class Initialized
INFO - 2024-10-01 15:01:14 --> Language Class Initialized
ERROR - 2024-10-01 15:01:14 --> 404 Page Not Found: /index
INFO - 2024-10-01 15:03:10 --> Config Class Initialized
INFO - 2024-10-01 15:03:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:10 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:10 --> URI Class Initialized
INFO - 2024-10-01 15:03:10 --> Router Class Initialized
INFO - 2024-10-01 15:03:10 --> Output Class Initialized
INFO - 2024-10-01 15:03:10 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:10 --> Input Class Initialized
INFO - 2024-10-01 15:03:10 --> Language Class Initialized
INFO - 2024-10-01 15:03:10 --> Language Class Initialized
INFO - 2024-10-01 15:03:10 --> Config Class Initialized
INFO - 2024-10-01 15:03:10 --> Loader Class Initialized
INFO - 2024-10-01 15:03:10 --> Helper loaded: url_helper
INFO - 2024-10-01 15:03:10 --> Helper loaded: file_helper
INFO - 2024-10-01 15:03:10 --> Helper loaded: form_helper
INFO - 2024-10-01 15:03:10 --> Helper loaded: my_helper
INFO - 2024-10-01 15:03:10 --> Database Driver Class Initialized
INFO - 2024-10-01 15:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:03:10 --> Controller Class Initialized
DEBUG - 2024-10-01 15:03:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 15:03:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 15:03:10 --> Final output sent to browser
DEBUG - 2024-10-01 15:03:10 --> Total execution time: 0.0278
INFO - 2024-10-01 15:03:10 --> Config Class Initialized
INFO - 2024-10-01 15:03:10 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:10 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:10 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:10 --> URI Class Initialized
INFO - 2024-10-01 15:03:10 --> Router Class Initialized
INFO - 2024-10-01 15:03:10 --> Output Class Initialized
INFO - 2024-10-01 15:03:10 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:10 --> Input Class Initialized
INFO - 2024-10-01 15:03:10 --> Language Class Initialized
ERROR - 2024-10-01 15:03:10 --> 404 Page Not Found: /index
INFO - 2024-10-01 15:03:30 --> Config Class Initialized
INFO - 2024-10-01 15:03:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:30 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:30 --> URI Class Initialized
INFO - 2024-10-01 15:03:30 --> Router Class Initialized
INFO - 2024-10-01 15:03:30 --> Output Class Initialized
INFO - 2024-10-01 15:03:30 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:30 --> Input Class Initialized
INFO - 2024-10-01 15:03:30 --> Language Class Initialized
INFO - 2024-10-01 15:03:30 --> Language Class Initialized
INFO - 2024-10-01 15:03:30 --> Config Class Initialized
INFO - 2024-10-01 15:03:30 --> Loader Class Initialized
INFO - 2024-10-01 15:03:30 --> Helper loaded: url_helper
INFO - 2024-10-01 15:03:30 --> Helper loaded: file_helper
INFO - 2024-10-01 15:03:30 --> Helper loaded: form_helper
INFO - 2024-10-01 15:03:30 --> Helper loaded: my_helper
INFO - 2024-10-01 15:03:30 --> Database Driver Class Initialized
INFO - 2024-10-01 15:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:03:30 --> Controller Class Initialized
DEBUG - 2024-10-01 15:03:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-01 15:03:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 15:03:30 --> Final output sent to browser
DEBUG - 2024-10-01 15:03:30 --> Total execution time: 0.0365
INFO - 2024-10-01 15:03:30 --> Config Class Initialized
INFO - 2024-10-01 15:03:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:30 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:30 --> URI Class Initialized
INFO - 2024-10-01 15:03:30 --> Router Class Initialized
INFO - 2024-10-01 15:03:30 --> Output Class Initialized
INFO - 2024-10-01 15:03:30 --> Config Class Initialized
INFO - 2024-10-01 15:03:30 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:30 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:30 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:30 --> URI Class Initialized
INFO - 2024-10-01 15:03:30 --> Router Class Initialized
INFO - 2024-10-01 15:03:30 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:30 --> Input Class Initialized
INFO - 2024-10-01 15:03:30 --> Language Class Initialized
ERROR - 2024-10-01 15:03:30 --> 404 Page Not Found: /index
INFO - 2024-10-01 15:03:30 --> Output Class Initialized
INFO - 2024-10-01 15:03:30 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:30 --> Input Class Initialized
INFO - 2024-10-01 15:03:30 --> Language Class Initialized
INFO - 2024-10-01 15:03:30 --> Language Class Initialized
INFO - 2024-10-01 15:03:30 --> Config Class Initialized
INFO - 2024-10-01 15:03:30 --> Loader Class Initialized
INFO - 2024-10-01 15:03:30 --> Helper loaded: url_helper
INFO - 2024-10-01 15:03:30 --> Helper loaded: file_helper
INFO - 2024-10-01 15:03:30 --> Helper loaded: form_helper
INFO - 2024-10-01 15:03:30 --> Helper loaded: my_helper
INFO - 2024-10-01 15:03:30 --> Database Driver Class Initialized
INFO - 2024-10-01 15:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:03:30 --> Controller Class Initialized
INFO - 2024-10-01 15:03:51 --> Config Class Initialized
INFO - 2024-10-01 15:03:51 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:51 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:51 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:51 --> URI Class Initialized
INFO - 2024-10-01 15:03:51 --> Router Class Initialized
INFO - 2024-10-01 15:03:51 --> Output Class Initialized
INFO - 2024-10-01 15:03:51 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:51 --> Input Class Initialized
INFO - 2024-10-01 15:03:51 --> Language Class Initialized
INFO - 2024-10-01 15:03:51 --> Language Class Initialized
INFO - 2024-10-01 15:03:51 --> Config Class Initialized
INFO - 2024-10-01 15:03:51 --> Loader Class Initialized
INFO - 2024-10-01 15:03:51 --> Helper loaded: url_helper
INFO - 2024-10-01 15:03:51 --> Helper loaded: file_helper
INFO - 2024-10-01 15:03:51 --> Helper loaded: form_helper
INFO - 2024-10-01 15:03:51 --> Helper loaded: my_helper
INFO - 2024-10-01 15:03:51 --> Database Driver Class Initialized
INFO - 2024-10-01 15:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:03:51 --> Controller Class Initialized
INFO - 2024-10-01 15:03:51 --> Final output sent to browser
DEBUG - 2024-10-01 15:03:51 --> Total execution time: 0.0278
INFO - 2024-10-01 15:03:58 --> Config Class Initialized
INFO - 2024-10-01 15:03:58 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:03:58 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:03:58 --> Utf8 Class Initialized
INFO - 2024-10-01 15:03:58 --> URI Class Initialized
INFO - 2024-10-01 15:03:58 --> Router Class Initialized
INFO - 2024-10-01 15:03:58 --> Output Class Initialized
INFO - 2024-10-01 15:03:58 --> Security Class Initialized
DEBUG - 2024-10-01 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:03:58 --> Input Class Initialized
INFO - 2024-10-01 15:03:58 --> Language Class Initialized
INFO - 2024-10-01 15:03:58 --> Language Class Initialized
INFO - 2024-10-01 15:03:58 --> Config Class Initialized
INFO - 2024-10-01 15:03:58 --> Loader Class Initialized
INFO - 2024-10-01 15:03:58 --> Helper loaded: url_helper
INFO - 2024-10-01 15:03:58 --> Helper loaded: file_helper
INFO - 2024-10-01 15:03:58 --> Helper loaded: form_helper
INFO - 2024-10-01 15:03:58 --> Helper loaded: my_helper
INFO - 2024-10-01 15:03:58 --> Database Driver Class Initialized
INFO - 2024-10-01 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:03:58 --> Controller Class Initialized
INFO - 2024-10-01 15:03:58 --> Final output sent to browser
DEBUG - 2024-10-01 15:03:58 --> Total execution time: 0.0285
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:06:24 --> Utf8 Class Initialized
INFO - 2024-10-01 15:06:24 --> URI Class Initialized
INFO - 2024-10-01 15:06:24 --> Router Class Initialized
INFO - 2024-10-01 15:06:24 --> Output Class Initialized
INFO - 2024-10-01 15:06:24 --> Security Class Initialized
DEBUG - 2024-10-01 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:06:24 --> Input Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Loader Class Initialized
INFO - 2024-10-01 15:06:24 --> Helper loaded: url_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: file_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: form_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: my_helper
INFO - 2024-10-01 15:06:24 --> Database Driver Class Initialized
INFO - 2024-10-01 15:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:06:24 --> Controller Class Initialized
INFO - 2024-10-01 15:06:24 --> Helper loaded: cookie_helper
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:06:24 --> Utf8 Class Initialized
INFO - 2024-10-01 15:06:24 --> URI Class Initialized
INFO - 2024-10-01 15:06:24 --> Router Class Initialized
INFO - 2024-10-01 15:06:24 --> Output Class Initialized
INFO - 2024-10-01 15:06:24 --> Security Class Initialized
DEBUG - 2024-10-01 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:06:24 --> Input Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Loader Class Initialized
INFO - 2024-10-01 15:06:24 --> Helper loaded: url_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: file_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: form_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: my_helper
INFO - 2024-10-01 15:06:24 --> Database Driver Class Initialized
INFO - 2024-10-01 15:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:06:24 --> Controller Class Initialized
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:06:24 --> Utf8 Class Initialized
INFO - 2024-10-01 15:06:24 --> URI Class Initialized
INFO - 2024-10-01 15:06:24 --> Router Class Initialized
INFO - 2024-10-01 15:06:24 --> Output Class Initialized
INFO - 2024-10-01 15:06:24 --> Security Class Initialized
DEBUG - 2024-10-01 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:06:24 --> Input Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Loader Class Initialized
INFO - 2024-10-01 15:06:24 --> Helper loaded: url_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: file_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: form_helper
INFO - 2024-10-01 15:06:24 --> Helper loaded: my_helper
INFO - 2024-10-01 15:06:24 --> Database Driver Class Initialized
INFO - 2024-10-01 15:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 15:06:24 --> Controller Class Initialized
DEBUG - 2024-10-01 15:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 15:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 15:06:24 --> Final output sent to browser
DEBUG - 2024-10-01 15:06:24 --> Total execution time: 0.0334
INFO - 2024-10-01 15:06:24 --> Config Class Initialized
INFO - 2024-10-01 15:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-01 15:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-01 15:06:24 --> Utf8 Class Initialized
INFO - 2024-10-01 15:06:24 --> URI Class Initialized
INFO - 2024-10-01 15:06:24 --> Router Class Initialized
INFO - 2024-10-01 15:06:24 --> Output Class Initialized
INFO - 2024-10-01 15:06:24 --> Security Class Initialized
DEBUG - 2024-10-01 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 15:06:24 --> Input Class Initialized
INFO - 2024-10-01 15:06:24 --> Language Class Initialized
ERROR - 2024-10-01 15:06:24 --> 404 Page Not Found: /index
INFO - 2024-10-01 23:25:14 --> Config Class Initialized
INFO - 2024-10-01 23:25:14 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:25:14 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:25:14 --> Utf8 Class Initialized
INFO - 2024-10-01 23:25:14 --> URI Class Initialized
INFO - 2024-10-01 23:25:14 --> Router Class Initialized
INFO - 2024-10-01 23:25:14 --> Output Class Initialized
INFO - 2024-10-01 23:25:14 --> Security Class Initialized
DEBUG - 2024-10-01 23:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:25:14 --> Input Class Initialized
INFO - 2024-10-01 23:25:14 --> Language Class Initialized
INFO - 2024-10-01 23:25:14 --> Language Class Initialized
INFO - 2024-10-01 23:25:14 --> Config Class Initialized
INFO - 2024-10-01 23:25:14 --> Loader Class Initialized
INFO - 2024-10-01 23:25:14 --> Helper loaded: url_helper
INFO - 2024-10-01 23:25:14 --> Helper loaded: file_helper
INFO - 2024-10-01 23:25:14 --> Helper loaded: form_helper
INFO - 2024-10-01 23:25:14 --> Helper loaded: my_helper
INFO - 2024-10-01 23:25:14 --> Database Driver Class Initialized
INFO - 2024-10-01 23:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:25:14 --> Controller Class Initialized
DEBUG - 2024-10-01 23:25:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-01 23:25:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 23:25:14 --> Final output sent to browser
DEBUG - 2024-10-01 23:25:14 --> Total execution time: 0.0498
INFO - 2024-10-01 23:25:23 --> Config Class Initialized
INFO - 2024-10-01 23:25:23 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:25:23 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:25:23 --> Utf8 Class Initialized
INFO - 2024-10-01 23:25:23 --> URI Class Initialized
INFO - 2024-10-01 23:25:23 --> Router Class Initialized
INFO - 2024-10-01 23:25:23 --> Output Class Initialized
INFO - 2024-10-01 23:25:23 --> Security Class Initialized
DEBUG - 2024-10-01 23:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:25:23 --> Input Class Initialized
INFO - 2024-10-01 23:25:23 --> Language Class Initialized
INFO - 2024-10-01 23:25:23 --> Language Class Initialized
INFO - 2024-10-01 23:25:23 --> Config Class Initialized
INFO - 2024-10-01 23:25:23 --> Loader Class Initialized
INFO - 2024-10-01 23:25:23 --> Helper loaded: url_helper
INFO - 2024-10-01 23:25:23 --> Helper loaded: file_helper
INFO - 2024-10-01 23:25:23 --> Helper loaded: form_helper
INFO - 2024-10-01 23:25:23 --> Helper loaded: my_helper
INFO - 2024-10-01 23:25:23 --> Database Driver Class Initialized
INFO - 2024-10-01 23:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:25:23 --> Controller Class Initialized
INFO - 2024-10-01 23:25:23 --> Helper loaded: cookie_helper
INFO - 2024-10-01 23:25:23 --> Final output sent to browser
DEBUG - 2024-10-01 23:25:23 --> Total execution time: 0.0475
INFO - 2024-10-01 23:25:23 --> Config Class Initialized
INFO - 2024-10-01 23:25:23 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:25:23 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:25:23 --> Utf8 Class Initialized
INFO - 2024-10-01 23:25:23 --> URI Class Initialized
INFO - 2024-10-01 23:25:23 --> Router Class Initialized
INFO - 2024-10-01 23:25:23 --> Output Class Initialized
INFO - 2024-10-01 23:25:23 --> Security Class Initialized
DEBUG - 2024-10-01 23:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:25:23 --> Input Class Initialized
INFO - 2024-10-01 23:25:23 --> Language Class Initialized
INFO - 2024-10-01 23:25:23 --> Language Class Initialized
INFO - 2024-10-01 23:25:23 --> Config Class Initialized
INFO - 2024-10-01 23:25:23 --> Loader Class Initialized
INFO - 2024-10-01 23:25:23 --> Helper loaded: url_helper
INFO - 2024-10-01 23:25:23 --> Helper loaded: file_helper
INFO - 2024-10-01 23:25:23 --> Helper loaded: form_helper
INFO - 2024-10-01 23:25:23 --> Helper loaded: my_helper
INFO - 2024-10-01 23:25:23 --> Database Driver Class Initialized
INFO - 2024-10-01 23:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:25:23 --> Controller Class Initialized
DEBUG - 2024-10-01 23:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-01 23:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 23:25:23 --> Final output sent to browser
DEBUG - 2024-10-01 23:25:23 --> Total execution time: 0.0562
INFO - 2024-10-01 23:26:44 --> Config Class Initialized
INFO - 2024-10-01 23:26:44 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:26:44 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:26:44 --> Utf8 Class Initialized
INFO - 2024-10-01 23:26:44 --> URI Class Initialized
INFO - 2024-10-01 23:26:44 --> Router Class Initialized
INFO - 2024-10-01 23:26:44 --> Output Class Initialized
INFO - 2024-10-01 23:26:44 --> Security Class Initialized
DEBUG - 2024-10-01 23:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:26:44 --> Input Class Initialized
INFO - 2024-10-01 23:26:44 --> Language Class Initialized
INFO - 2024-10-01 23:26:44 --> Language Class Initialized
INFO - 2024-10-01 23:26:44 --> Config Class Initialized
INFO - 2024-10-01 23:26:44 --> Loader Class Initialized
INFO - 2024-10-01 23:26:44 --> Helper loaded: url_helper
INFO - 2024-10-01 23:26:44 --> Helper loaded: file_helper
INFO - 2024-10-01 23:26:44 --> Helper loaded: form_helper
INFO - 2024-10-01 23:26:44 --> Helper loaded: my_helper
INFO - 2024-10-01 23:26:44 --> Database Driver Class Initialized
INFO - 2024-10-01 23:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:26:44 --> Controller Class Initialized
DEBUG - 2024-10-01 23:26:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-01 23:26:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-01 23:26:44 --> Final output sent to browser
DEBUG - 2024-10-01 23:26:44 --> Total execution time: 0.0334
