<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-22 12:33:05 --> Config Class Initialized
INFO - 2024-06-22 12:33:05 --> Hooks Class Initialized
DEBUG - 2024-06-22 12:33:05 --> UTF-8 Support Enabled
INFO - 2024-06-22 12:33:05 --> Utf8 Class Initialized
INFO - 2024-06-22 12:33:05 --> URI Class Initialized
INFO - 2024-06-22 12:33:05 --> Router Class Initialized
INFO - 2024-06-22 12:33:05 --> Output Class Initialized
INFO - 2024-06-22 12:33:05 --> Security Class Initialized
DEBUG - 2024-06-22 12:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 12:33:05 --> Input Class Initialized
INFO - 2024-06-22 12:33:05 --> Language Class Initialized
INFO - 2024-06-22 12:33:05 --> Language Class Initialized
INFO - 2024-06-22 12:33:05 --> Config Class Initialized
INFO - 2024-06-22 12:33:05 --> Loader Class Initialized
INFO - 2024-06-22 12:33:05 --> Helper loaded: url_helper
INFO - 2024-06-22 12:33:05 --> Helper loaded: file_helper
INFO - 2024-06-22 12:33:05 --> Helper loaded: form_helper
INFO - 2024-06-22 12:33:05 --> Helper loaded: my_helper
INFO - 2024-06-22 12:33:05 --> Database Driver Class Initialized
INFO - 2024-06-22 12:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 12:33:05 --> Controller Class Initialized
DEBUG - 2024-06-22 12:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-22 12:33:09 --> Final output sent to browser
DEBUG - 2024-06-22 12:33:09 --> Total execution time: 4.1140
INFO - 2024-06-22 18:18:17 --> Config Class Initialized
INFO - 2024-06-22 18:18:17 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:18:17 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:17 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:17 --> URI Class Initialized
INFO - 2024-06-22 18:18:17 --> Router Class Initialized
INFO - 2024-06-22 18:18:17 --> Output Class Initialized
INFO - 2024-06-22 18:18:17 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:17 --> Input Class Initialized
INFO - 2024-06-22 18:18:17 --> Language Class Initialized
INFO - 2024-06-22 18:18:17 --> Language Class Initialized
INFO - 2024-06-22 18:18:17 --> Config Class Initialized
INFO - 2024-06-22 18:18:17 --> Loader Class Initialized
INFO - 2024-06-22 18:18:17 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:17 --> Helper loaded: file_helper
INFO - 2024-06-22 18:18:17 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:17 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:17 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:17 --> Controller Class Initialized
INFO - 2024-06-22 18:18:17 --> Helper loaded: cookie_helper
INFO - 2024-06-22 18:18:17 --> Final output sent to browser
DEBUG - 2024-06-22 18:18:17 --> Total execution time: 0.4600
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:18:18 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:18 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:18 --> URI Class Initialized
INFO - 2024-06-22 18:18:18 --> Router Class Initialized
INFO - 2024-06-22 18:18:18 --> Output Class Initialized
INFO - 2024-06-22 18:18:18 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:18 --> Input Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Hooks Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Loader Class Initialized
DEBUG - 2024-06-22 18:18:18 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:18 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:18 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:18 --> URI Class Initialized
INFO - 2024-06-22 18:18:18 --> Router Class Initialized
INFO - 2024-06-22 18:18:18 --> Output Class Initialized
INFO - 2024-06-22 18:18:18 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:18 --> Input Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Loader Class Initialized
INFO - 2024-06-22 18:18:18 --> Helper loaded: file_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: file_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:18 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:18 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:18 --> Controller Class Initialized
INFO - 2024-06-22 18:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:18 --> Controller Class Initialized
INFO - 2024-06-22 18:18:18 --> Helper loaded: cookie_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: cookie_helper
INFO - 2024-06-22 18:18:18 --> Final output sent to browser
DEBUG - 2024-06-22 18:18:18 --> Total execution time: 0.1823
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:18:18 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:18 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:18 --> URI Class Initialized
INFO - 2024-06-22 18:18:18 --> Router Class Initialized
INFO - 2024-06-22 18:18:18 --> Output Class Initialized
INFO - 2024-06-22 18:18:18 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:18 --> Input Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Hooks Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Loader Class Initialized
INFO - 2024-06-22 18:18:18 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: file_helper
DEBUG - 2024-06-22 18:18:18 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:18 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:18 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:18 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:18 --> URI Class Initialized
INFO - 2024-06-22 18:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:18 --> Controller Class Initialized
INFO - 2024-06-22 18:18:18 --> Router Class Initialized
INFO - 2024-06-22 18:18:18 --> Output Class Initialized
INFO - 2024-06-22 18:18:18 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-22 18:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-22 18:18:18 --> Final output sent to browser
DEBUG - 2024-06-22 18:18:18 --> Total execution time: 0.3328
DEBUG - 2024-06-22 18:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:18 --> Input Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Language Class Initialized
INFO - 2024-06-22 18:18:18 --> Config Class Initialized
INFO - 2024-06-22 18:18:18 --> Loader Class Initialized
INFO - 2024-06-22 18:18:18 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: file_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:18 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:19 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:19 --> Controller Class Initialized
INFO - 2024-06-22 18:18:19 --> Helper loaded: cookie_helper
INFO - 2024-06-22 18:18:19 --> Config Class Initialized
INFO - 2024-06-22 18:18:19 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:18:19 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:19 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:19 --> URI Class Initialized
INFO - 2024-06-22 18:18:19 --> Router Class Initialized
INFO - 2024-06-22 18:18:19 --> Output Class Initialized
INFO - 2024-06-22 18:18:19 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:19 --> Input Class Initialized
INFO - 2024-06-22 18:18:19 --> Language Class Initialized
INFO - 2024-06-22 18:18:19 --> Language Class Initialized
INFO - 2024-06-22 18:18:19 --> Config Class Initialized
INFO - 2024-06-22 18:18:19 --> Loader Class Initialized
INFO - 2024-06-22 18:18:19 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:19 --> Helper loaded: file_helper
INFO - 2024-06-22 18:18:19 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:19 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:19 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:19 --> Controller Class Initialized
DEBUG - 2024-06-22 18:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-22 18:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-22 18:18:19 --> Final output sent to browser
DEBUG - 2024-06-22 18:18:19 --> Total execution time: 0.1133
INFO - 2024-06-22 18:18:31 --> Config Class Initialized
INFO - 2024-06-22 18:18:31 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:18:31 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:18:31 --> Utf8 Class Initialized
INFO - 2024-06-22 18:18:31 --> URI Class Initialized
INFO - 2024-06-22 18:18:31 --> Router Class Initialized
INFO - 2024-06-22 18:18:31 --> Output Class Initialized
INFO - 2024-06-22 18:18:31 --> Security Class Initialized
DEBUG - 2024-06-22 18:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:18:31 --> Input Class Initialized
INFO - 2024-06-22 18:18:31 --> Language Class Initialized
INFO - 2024-06-22 18:18:31 --> Language Class Initialized
INFO - 2024-06-22 18:18:31 --> Config Class Initialized
INFO - 2024-06-22 18:18:31 --> Loader Class Initialized
INFO - 2024-06-22 18:18:31 --> Helper loaded: url_helper
INFO - 2024-06-22 18:18:31 --> Helper loaded: file_helper
INFO - 2024-06-22 18:18:31 --> Helper loaded: form_helper
INFO - 2024-06-22 18:18:31 --> Helper loaded: my_helper
INFO - 2024-06-22 18:18:31 --> Database Driver Class Initialized
INFO - 2024-06-22 18:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:18:31 --> Controller Class Initialized
DEBUG - 2024-06-22 18:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-22 18:18:35 --> Final output sent to browser
DEBUG - 2024-06-22 18:18:35 --> Total execution time: 4.1886
INFO - 2024-06-22 18:19:02 --> Config Class Initialized
INFO - 2024-06-22 18:19:02 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:19:02 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:19:02 --> Utf8 Class Initialized
INFO - 2024-06-22 18:19:02 --> URI Class Initialized
INFO - 2024-06-22 18:19:02 --> Router Class Initialized
INFO - 2024-06-22 18:19:02 --> Output Class Initialized
INFO - 2024-06-22 18:19:02 --> Security Class Initialized
DEBUG - 2024-06-22 18:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:19:02 --> Input Class Initialized
INFO - 2024-06-22 18:19:02 --> Language Class Initialized
INFO - 2024-06-22 18:19:02 --> Language Class Initialized
INFO - 2024-06-22 18:19:02 --> Config Class Initialized
INFO - 2024-06-22 18:19:02 --> Loader Class Initialized
INFO - 2024-06-22 18:19:02 --> Helper loaded: url_helper
INFO - 2024-06-22 18:19:02 --> Helper loaded: file_helper
INFO - 2024-06-22 18:19:02 --> Helper loaded: form_helper
INFO - 2024-06-22 18:19:02 --> Helper loaded: my_helper
INFO - 2024-06-22 18:19:02 --> Database Driver Class Initialized
INFO - 2024-06-22 18:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:19:02 --> Controller Class Initialized
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-22 18:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-22 18:19:07 --> Config Class Initialized
INFO - 2024-06-22 18:19:07 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:19:07 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:19:07 --> Utf8 Class Initialized
INFO - 2024-06-22 18:19:07 --> URI Class Initialized
INFO - 2024-06-22 18:19:07 --> Router Class Initialized
INFO - 2024-06-22 18:19:07 --> Output Class Initialized
INFO - 2024-06-22 18:19:07 --> Security Class Initialized
DEBUG - 2024-06-22 18:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:19:07 --> Input Class Initialized
INFO - 2024-06-22 18:19:07 --> Language Class Initialized
INFO - 2024-06-22 18:19:07 --> Language Class Initialized
INFO - 2024-06-22 18:19:07 --> Config Class Initialized
INFO - 2024-06-22 18:19:07 --> Loader Class Initialized
INFO - 2024-06-22 18:19:07 --> Helper loaded: url_helper
INFO - 2024-06-22 18:19:07 --> Helper loaded: file_helper
INFO - 2024-06-22 18:19:07 --> Helper loaded: form_helper
INFO - 2024-06-22 18:19:07 --> Helper loaded: my_helper
INFO - 2024-06-22 18:19:07 --> Database Driver Class Initialized
INFO - 2024-06-22 18:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:19:11 --> Controller Class Initialized
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:11 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-22 18:19:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-22 18:19:16 --> Config Class Initialized
INFO - 2024-06-22 18:19:16 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:19:16 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:19:16 --> Utf8 Class Initialized
INFO - 2024-06-22 18:19:16 --> URI Class Initialized
INFO - 2024-06-22 18:19:16 --> Router Class Initialized
INFO - 2024-06-22 18:19:16 --> Output Class Initialized
INFO - 2024-06-22 18:19:16 --> Security Class Initialized
DEBUG - 2024-06-22 18:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:19:16 --> Input Class Initialized
INFO - 2024-06-22 18:19:16 --> Language Class Initialized
INFO - 2024-06-22 18:19:16 --> Language Class Initialized
INFO - 2024-06-22 18:19:16 --> Config Class Initialized
INFO - 2024-06-22 18:19:16 --> Loader Class Initialized
INFO - 2024-06-22 18:19:16 --> Helper loaded: url_helper
INFO - 2024-06-22 18:19:16 --> Helper loaded: file_helper
INFO - 2024-06-22 18:19:16 --> Helper loaded: form_helper
INFO - 2024-06-22 18:19:16 --> Helper loaded: my_helper
INFO - 2024-06-22 18:19:16 --> Database Driver Class Initialized
INFO - 2024-06-22 18:19:18 --> Config Class Initialized
INFO - 2024-06-22 18:19:18 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:19:18 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:19:18 --> Utf8 Class Initialized
INFO - 2024-06-22 18:19:18 --> URI Class Initialized
INFO - 2024-06-22 18:19:18 --> Router Class Initialized
INFO - 2024-06-22 18:19:18 --> Output Class Initialized
INFO - 2024-06-22 18:19:18 --> Security Class Initialized
DEBUG - 2024-06-22 18:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:19:18 --> Input Class Initialized
INFO - 2024-06-22 18:19:18 --> Language Class Initialized
INFO - 2024-06-22 18:19:18 --> Language Class Initialized
INFO - 2024-06-22 18:19:18 --> Config Class Initialized
INFO - 2024-06-22 18:19:18 --> Loader Class Initialized
INFO - 2024-06-22 18:19:18 --> Helper loaded: url_helper
INFO - 2024-06-22 18:19:18 --> Helper loaded: file_helper
INFO - 2024-06-22 18:19:18 --> Helper loaded: form_helper
INFO - 2024-06-22 18:19:18 --> Helper loaded: my_helper
INFO - 2024-06-22 18:19:18 --> Database Driver Class Initialized
INFO - 2024-06-22 18:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:19:21 --> Controller Class Initialized
DEBUG - 2024-06-22 18:19:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-22 18:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:19:26 --> Controller Class Initialized
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-22 18:19:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-22 18:19:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-22 18:19:34 --> Final output sent to browser
DEBUG - 2024-06-22 18:19:34 --> Total execution time: 15.9842
INFO - 2024-06-22 18:20:19 --> Config Class Initialized
INFO - 2024-06-22 18:20:19 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:20:19 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:20:19 --> Utf8 Class Initialized
INFO - 2024-06-22 18:20:19 --> URI Class Initialized
INFO - 2024-06-22 18:20:19 --> Router Class Initialized
INFO - 2024-06-22 18:20:19 --> Output Class Initialized
INFO - 2024-06-22 18:20:19 --> Security Class Initialized
DEBUG - 2024-06-22 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:20:19 --> Input Class Initialized
INFO - 2024-06-22 18:20:19 --> Language Class Initialized
INFO - 2024-06-22 18:20:19 --> Language Class Initialized
INFO - 2024-06-22 18:20:19 --> Config Class Initialized
INFO - 2024-06-22 18:20:19 --> Loader Class Initialized
INFO - 2024-06-22 18:20:19 --> Helper loaded: url_helper
INFO - 2024-06-22 18:20:19 --> Helper loaded: file_helper
INFO - 2024-06-22 18:20:19 --> Helper loaded: form_helper
INFO - 2024-06-22 18:20:19 --> Helper loaded: my_helper
INFO - 2024-06-22 18:20:19 --> Database Driver Class Initialized
INFO - 2024-06-22 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:20:19 --> Controller Class Initialized
DEBUG - 2024-06-22 18:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-22 18:20:24 --> Final output sent to browser
DEBUG - 2024-06-22 18:20:24 --> Total execution time: 5.1525
INFO - 2024-06-22 18:21:17 --> Config Class Initialized
INFO - 2024-06-22 18:21:17 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:21:17 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:21:17 --> Utf8 Class Initialized
INFO - 2024-06-22 18:21:17 --> URI Class Initialized
INFO - 2024-06-22 18:21:17 --> Router Class Initialized
INFO - 2024-06-22 18:21:17 --> Output Class Initialized
INFO - 2024-06-22 18:21:17 --> Security Class Initialized
DEBUG - 2024-06-22 18:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:21:17 --> Input Class Initialized
INFO - 2024-06-22 18:21:17 --> Language Class Initialized
INFO - 2024-06-22 18:21:17 --> Language Class Initialized
INFO - 2024-06-22 18:21:17 --> Config Class Initialized
INFO - 2024-06-22 18:21:17 --> Loader Class Initialized
INFO - 2024-06-22 18:21:17 --> Helper loaded: url_helper
INFO - 2024-06-22 18:21:17 --> Helper loaded: file_helper
INFO - 2024-06-22 18:21:17 --> Helper loaded: form_helper
INFO - 2024-06-22 18:21:17 --> Helper loaded: my_helper
INFO - 2024-06-22 18:21:17 --> Database Driver Class Initialized
INFO - 2024-06-22 18:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:21:17 --> Controller Class Initialized
DEBUG - 2024-06-22 18:21:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-22 18:21:20 --> Final output sent to browser
DEBUG - 2024-06-22 18:21:20 --> Total execution time: 3.5547
INFO - 2024-06-22 18:21:25 --> Config Class Initialized
INFO - 2024-06-22 18:21:25 --> Hooks Class Initialized
DEBUG - 2024-06-22 18:21:25 --> UTF-8 Support Enabled
INFO - 2024-06-22 18:21:25 --> Utf8 Class Initialized
INFO - 2024-06-22 18:21:25 --> URI Class Initialized
INFO - 2024-06-22 18:21:25 --> Router Class Initialized
INFO - 2024-06-22 18:21:25 --> Output Class Initialized
INFO - 2024-06-22 18:21:25 --> Security Class Initialized
DEBUG - 2024-06-22 18:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-22 18:21:25 --> Input Class Initialized
INFO - 2024-06-22 18:21:25 --> Language Class Initialized
INFO - 2024-06-22 18:21:25 --> Language Class Initialized
INFO - 2024-06-22 18:21:25 --> Config Class Initialized
INFO - 2024-06-22 18:21:25 --> Loader Class Initialized
INFO - 2024-06-22 18:21:25 --> Helper loaded: url_helper
INFO - 2024-06-22 18:21:25 --> Helper loaded: file_helper
INFO - 2024-06-22 18:21:25 --> Helper loaded: form_helper
INFO - 2024-06-22 18:21:25 --> Helper loaded: my_helper
INFO - 2024-06-22 18:21:25 --> Database Driver Class Initialized
INFO - 2024-06-22 18:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-22 18:21:25 --> Controller Class Initialized
DEBUG - 2024-06-22 18:21:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-22 18:21:32 --> Final output sent to browser
DEBUG - 2024-06-22 18:21:32 --> Total execution time: 6.7192
