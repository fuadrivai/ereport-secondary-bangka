<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-21 14:56:38 --> Config Class Initialized
INFO - 2024-02-21 14:56:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:38 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:38 --> URI Class Initialized
DEBUG - 2024-02-21 14:56:38 --> No URI present. Default controller set.
INFO - 2024-02-21 14:56:38 --> Router Class Initialized
INFO - 2024-02-21 14:56:38 --> Output Class Initialized
INFO - 2024-02-21 14:56:38 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:38 --> Input Class Initialized
INFO - 2024-02-21 14:56:38 --> Language Class Initialized
INFO - 2024-02-21 14:56:38 --> Language Class Initialized
INFO - 2024-02-21 14:56:38 --> Config Class Initialized
INFO - 2024-02-21 14:56:38 --> Loader Class Initialized
INFO - 2024-02-21 14:56:38 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:38 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:38 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:38 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:38 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:38 --> Controller Class Initialized
INFO - 2024-02-21 14:56:38 --> Config Class Initialized
INFO - 2024-02-21 14:56:38 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:38 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:38 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:38 --> URI Class Initialized
INFO - 2024-02-21 14:56:38 --> Router Class Initialized
INFO - 2024-02-21 14:56:38 --> Output Class Initialized
INFO - 2024-02-21 14:56:38 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:38 --> Input Class Initialized
INFO - 2024-02-21 14:56:38 --> Language Class Initialized
INFO - 2024-02-21 14:56:38 --> Language Class Initialized
INFO - 2024-02-21 14:56:38 --> Config Class Initialized
INFO - 2024-02-21 14:56:38 --> Loader Class Initialized
INFO - 2024-02-21 14:56:38 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:38 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:38 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:38 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:38 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:38 --> Controller Class Initialized
DEBUG - 2024-02-21 14:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-21 14:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:56:38 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:38 --> Total execution time: 0.0358
INFO - 2024-02-21 14:56:42 --> Config Class Initialized
INFO - 2024-02-21 14:56:42 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:42 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:42 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:42 --> URI Class Initialized
INFO - 2024-02-21 14:56:42 --> Router Class Initialized
INFO - 2024-02-21 14:56:42 --> Output Class Initialized
INFO - 2024-02-21 14:56:42 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:42 --> Input Class Initialized
INFO - 2024-02-21 14:56:42 --> Language Class Initialized
INFO - 2024-02-21 14:56:42 --> Language Class Initialized
INFO - 2024-02-21 14:56:42 --> Config Class Initialized
INFO - 2024-02-21 14:56:42 --> Loader Class Initialized
INFO - 2024-02-21 14:56:42 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:42 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:42 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:42 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:42 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:42 --> Controller Class Initialized
INFO - 2024-02-21 14:56:42 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:42 --> Total execution time: 0.0375
INFO - 2024-02-21 14:56:46 --> Config Class Initialized
INFO - 2024-02-21 14:56:46 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:46 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:46 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:46 --> URI Class Initialized
INFO - 2024-02-21 14:56:46 --> Router Class Initialized
INFO - 2024-02-21 14:56:46 --> Output Class Initialized
INFO - 2024-02-21 14:56:46 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:46 --> Input Class Initialized
INFO - 2024-02-21 14:56:46 --> Language Class Initialized
INFO - 2024-02-21 14:56:46 --> Language Class Initialized
INFO - 2024-02-21 14:56:46 --> Config Class Initialized
INFO - 2024-02-21 14:56:46 --> Loader Class Initialized
INFO - 2024-02-21 14:56:46 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:46 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:46 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:46 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:46 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:46 --> Controller Class Initialized
INFO - 2024-02-21 14:56:46 --> Helper loaded: cookie_helper
INFO - 2024-02-21 14:56:46 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:46 --> Total execution time: 0.1054
INFO - 2024-02-21 14:56:46 --> Config Class Initialized
INFO - 2024-02-21 14:56:46 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:46 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:46 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:46 --> URI Class Initialized
INFO - 2024-02-21 14:56:46 --> Router Class Initialized
INFO - 2024-02-21 14:56:46 --> Output Class Initialized
INFO - 2024-02-21 14:56:46 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:46 --> Input Class Initialized
INFO - 2024-02-21 14:56:46 --> Language Class Initialized
INFO - 2024-02-21 14:56:46 --> Language Class Initialized
INFO - 2024-02-21 14:56:46 --> Config Class Initialized
INFO - 2024-02-21 14:56:46 --> Loader Class Initialized
INFO - 2024-02-21 14:56:46 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:46 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:46 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:46 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:46 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:46 --> Controller Class Initialized
DEBUG - 2024-02-21 14:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-02-21 14:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:56:46 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:46 --> Total execution time: 0.0523
INFO - 2024-02-21 14:56:53 --> Config Class Initialized
INFO - 2024-02-21 14:56:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:53 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:53 --> URI Class Initialized
INFO - 2024-02-21 14:56:53 --> Router Class Initialized
INFO - 2024-02-21 14:56:53 --> Output Class Initialized
INFO - 2024-02-21 14:56:53 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:53 --> Input Class Initialized
INFO - 2024-02-21 14:56:53 --> Language Class Initialized
INFO - 2024-02-21 14:56:53 --> Language Class Initialized
INFO - 2024-02-21 14:56:53 --> Config Class Initialized
INFO - 2024-02-21 14:56:53 --> Loader Class Initialized
INFO - 2024-02-21 14:56:53 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:53 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:53 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:53 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:53 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:53 --> Controller Class Initialized
DEBUG - 2024-02-21 14:56:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-02-21 14:56:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:56:53 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:53 --> Total execution time: 0.0345
INFO - 2024-02-21 14:56:53 --> Config Class Initialized
INFO - 2024-02-21 14:56:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:53 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:53 --> URI Class Initialized
INFO - 2024-02-21 14:56:53 --> Router Class Initialized
INFO - 2024-02-21 14:56:53 --> Output Class Initialized
INFO - 2024-02-21 14:56:53 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:53 --> Input Class Initialized
INFO - 2024-02-21 14:56:53 --> Language Class Initialized
ERROR - 2024-02-21 14:56:53 --> 404 Page Not Found: /index
INFO - 2024-02-21 14:56:53 --> Config Class Initialized
INFO - 2024-02-21 14:56:53 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:53 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:53 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:53 --> URI Class Initialized
INFO - 2024-02-21 14:56:53 --> Router Class Initialized
INFO - 2024-02-21 14:56:53 --> Output Class Initialized
INFO - 2024-02-21 14:56:53 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:53 --> Input Class Initialized
INFO - 2024-02-21 14:56:53 --> Language Class Initialized
INFO - 2024-02-21 14:56:53 --> Language Class Initialized
INFO - 2024-02-21 14:56:53 --> Config Class Initialized
INFO - 2024-02-21 14:56:53 --> Loader Class Initialized
INFO - 2024-02-21 14:56:53 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:53 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:53 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:53 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:53 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:53 --> Controller Class Initialized
INFO - 2024-02-21 14:56:56 --> Config Class Initialized
INFO - 2024-02-21 14:56:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:56 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:56 --> URI Class Initialized
INFO - 2024-02-21 14:56:56 --> Router Class Initialized
INFO - 2024-02-21 14:56:56 --> Output Class Initialized
INFO - 2024-02-21 14:56:56 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:56 --> Input Class Initialized
INFO - 2024-02-21 14:56:56 --> Language Class Initialized
INFO - 2024-02-21 14:56:56 --> Language Class Initialized
INFO - 2024-02-21 14:56:56 --> Config Class Initialized
INFO - 2024-02-21 14:56:56 --> Loader Class Initialized
INFO - 2024-02-21 14:56:56 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:56 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:56 --> Controller Class Initialized
INFO - 2024-02-21 14:56:56 --> Helper loaded: cookie_helper
INFO - 2024-02-21 14:56:56 --> Config Class Initialized
INFO - 2024-02-21 14:56:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:56 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:56 --> URI Class Initialized
INFO - 2024-02-21 14:56:56 --> Router Class Initialized
INFO - 2024-02-21 14:56:56 --> Output Class Initialized
INFO - 2024-02-21 14:56:56 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:56 --> Input Class Initialized
INFO - 2024-02-21 14:56:56 --> Language Class Initialized
INFO - 2024-02-21 14:56:56 --> Language Class Initialized
INFO - 2024-02-21 14:56:56 --> Config Class Initialized
INFO - 2024-02-21 14:56:56 --> Loader Class Initialized
INFO - 2024-02-21 14:56:56 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:56 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:56 --> Controller Class Initialized
INFO - 2024-02-21 14:56:56 --> Config Class Initialized
INFO - 2024-02-21 14:56:56 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:56 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:56 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:56 --> URI Class Initialized
INFO - 2024-02-21 14:56:56 --> Router Class Initialized
INFO - 2024-02-21 14:56:56 --> Output Class Initialized
INFO - 2024-02-21 14:56:56 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:56 --> Input Class Initialized
INFO - 2024-02-21 14:56:56 --> Language Class Initialized
INFO - 2024-02-21 14:56:56 --> Language Class Initialized
INFO - 2024-02-21 14:56:56 --> Config Class Initialized
INFO - 2024-02-21 14:56:56 --> Loader Class Initialized
INFO - 2024-02-21 14:56:56 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:56 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:56 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:56 --> Controller Class Initialized
DEBUG - 2024-02-21 14:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-21 14:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:56:56 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:56 --> Total execution time: 0.0344
INFO - 2024-02-21 14:56:58 --> Config Class Initialized
INFO - 2024-02-21 14:56:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:58 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:58 --> URI Class Initialized
INFO - 2024-02-21 14:56:58 --> Router Class Initialized
INFO - 2024-02-21 14:56:58 --> Output Class Initialized
INFO - 2024-02-21 14:56:58 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:58 --> Input Class Initialized
INFO - 2024-02-21 14:56:58 --> Language Class Initialized
INFO - 2024-02-21 14:56:58 --> Language Class Initialized
INFO - 2024-02-21 14:56:58 --> Config Class Initialized
INFO - 2024-02-21 14:56:58 --> Loader Class Initialized
INFO - 2024-02-21 14:56:58 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:58 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:58 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:58 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:58 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:58 --> Controller Class Initialized
INFO - 2024-02-21 14:56:58 --> Helper loaded: cookie_helper
INFO - 2024-02-21 14:56:58 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:58 --> Total execution time: 0.0389
INFO - 2024-02-21 14:56:58 --> Config Class Initialized
INFO - 2024-02-21 14:56:58 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:58 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:58 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:58 --> URI Class Initialized
INFO - 2024-02-21 14:56:58 --> Router Class Initialized
INFO - 2024-02-21 14:56:58 --> Output Class Initialized
INFO - 2024-02-21 14:56:58 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:58 --> Input Class Initialized
INFO - 2024-02-21 14:56:58 --> Language Class Initialized
INFO - 2024-02-21 14:56:58 --> Language Class Initialized
INFO - 2024-02-21 14:56:58 --> Config Class Initialized
INFO - 2024-02-21 14:56:58 --> Loader Class Initialized
INFO - 2024-02-21 14:56:58 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:58 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:58 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:58 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:58 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:58 --> Controller Class Initialized
DEBUG - 2024-02-21 14:56:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-02-21 14:56:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:56:58 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:58 --> Total execution time: 0.0279
INFO - 2024-02-21 14:56:59 --> Config Class Initialized
INFO - 2024-02-21 14:56:59 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:56:59 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:56:59 --> Utf8 Class Initialized
INFO - 2024-02-21 14:56:59 --> URI Class Initialized
INFO - 2024-02-21 14:56:59 --> Router Class Initialized
INFO - 2024-02-21 14:56:59 --> Output Class Initialized
INFO - 2024-02-21 14:56:59 --> Security Class Initialized
DEBUG - 2024-02-21 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:56:59 --> Input Class Initialized
INFO - 2024-02-21 14:56:59 --> Language Class Initialized
INFO - 2024-02-21 14:56:59 --> Language Class Initialized
INFO - 2024-02-21 14:56:59 --> Config Class Initialized
INFO - 2024-02-21 14:56:59 --> Loader Class Initialized
INFO - 2024-02-21 14:56:59 --> Helper loaded: url_helper
INFO - 2024-02-21 14:56:59 --> Helper loaded: file_helper
INFO - 2024-02-21 14:56:59 --> Helper loaded: form_helper
INFO - 2024-02-21 14:56:59 --> Helper loaded: my_helper
INFO - 2024-02-21 14:56:59 --> Database Driver Class Initialized
INFO - 2024-02-21 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:56:59 --> Controller Class Initialized
DEBUG - 2024-02-21 14:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-21 14:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:56:59 --> Final output sent to browser
DEBUG - 2024-02-21 14:56:59 --> Total execution time: 0.0424
INFO - 2024-02-21 14:57:08 --> Config Class Initialized
INFO - 2024-02-21 14:57:08 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:57:08 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:57:08 --> Utf8 Class Initialized
INFO - 2024-02-21 14:57:08 --> URI Class Initialized
INFO - 2024-02-21 14:57:08 --> Router Class Initialized
INFO - 2024-02-21 14:57:08 --> Output Class Initialized
INFO - 2024-02-21 14:57:08 --> Security Class Initialized
DEBUG - 2024-02-21 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:57:08 --> Input Class Initialized
INFO - 2024-02-21 14:57:08 --> Language Class Initialized
INFO - 2024-02-21 14:57:08 --> Language Class Initialized
INFO - 2024-02-21 14:57:08 --> Config Class Initialized
INFO - 2024-02-21 14:57:08 --> Loader Class Initialized
INFO - 2024-02-21 14:57:08 --> Helper loaded: url_helper
INFO - 2024-02-21 14:57:08 --> Helper loaded: file_helper
INFO - 2024-02-21 14:57:08 --> Helper loaded: form_helper
INFO - 2024-02-21 14:57:08 --> Helper loaded: my_helper
INFO - 2024-02-21 14:57:08 --> Database Driver Class Initialized
INFO - 2024-02-21 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:57:08 --> Controller Class Initialized
DEBUG - 2024-02-21 14:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-02-21 14:57:13 --> Final output sent to browser
DEBUG - 2024-02-21 14:57:13 --> Total execution time: 5.2804
INFO - 2024-02-21 14:57:17 --> Config Class Initialized
INFO - 2024-02-21 14:57:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:57:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:57:17 --> Utf8 Class Initialized
INFO - 2024-02-21 14:57:17 --> URI Class Initialized
INFO - 2024-02-21 14:57:17 --> Router Class Initialized
INFO - 2024-02-21 14:57:17 --> Output Class Initialized
INFO - 2024-02-21 14:57:17 --> Security Class Initialized
DEBUG - 2024-02-21 14:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:57:17 --> Input Class Initialized
INFO - 2024-02-21 14:57:17 --> Language Class Initialized
INFO - 2024-02-21 14:57:17 --> Language Class Initialized
INFO - 2024-02-21 14:57:17 --> Config Class Initialized
INFO - 2024-02-21 14:57:17 --> Loader Class Initialized
INFO - 2024-02-21 14:57:17 --> Helper loaded: url_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: file_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: form_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: my_helper
INFO - 2024-02-21 14:57:17 --> Database Driver Class Initialized
INFO - 2024-02-21 14:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:57:17 --> Controller Class Initialized
INFO - 2024-02-21 14:57:17 --> Helper loaded: cookie_helper
INFO - 2024-02-21 14:57:17 --> Config Class Initialized
INFO - 2024-02-21 14:57:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:57:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:57:17 --> Utf8 Class Initialized
INFO - 2024-02-21 14:57:17 --> URI Class Initialized
INFO - 2024-02-21 14:57:17 --> Router Class Initialized
INFO - 2024-02-21 14:57:17 --> Output Class Initialized
INFO - 2024-02-21 14:57:17 --> Security Class Initialized
DEBUG - 2024-02-21 14:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:57:17 --> Input Class Initialized
INFO - 2024-02-21 14:57:17 --> Language Class Initialized
INFO - 2024-02-21 14:57:17 --> Language Class Initialized
INFO - 2024-02-21 14:57:17 --> Config Class Initialized
INFO - 2024-02-21 14:57:17 --> Loader Class Initialized
INFO - 2024-02-21 14:57:17 --> Helper loaded: url_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: file_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: form_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: my_helper
INFO - 2024-02-21 14:57:17 --> Database Driver Class Initialized
INFO - 2024-02-21 14:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:57:17 --> Controller Class Initialized
INFO - 2024-02-21 14:57:17 --> Config Class Initialized
INFO - 2024-02-21 14:57:17 --> Hooks Class Initialized
DEBUG - 2024-02-21 14:57:17 --> UTF-8 Support Enabled
INFO - 2024-02-21 14:57:17 --> Utf8 Class Initialized
INFO - 2024-02-21 14:57:17 --> URI Class Initialized
INFO - 2024-02-21 14:57:17 --> Router Class Initialized
INFO - 2024-02-21 14:57:17 --> Output Class Initialized
INFO - 2024-02-21 14:57:17 --> Security Class Initialized
DEBUG - 2024-02-21 14:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-21 14:57:17 --> Input Class Initialized
INFO - 2024-02-21 14:57:17 --> Language Class Initialized
INFO - 2024-02-21 14:57:17 --> Language Class Initialized
INFO - 2024-02-21 14:57:17 --> Config Class Initialized
INFO - 2024-02-21 14:57:17 --> Loader Class Initialized
INFO - 2024-02-21 14:57:17 --> Helper loaded: url_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: file_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: form_helper
INFO - 2024-02-21 14:57:17 --> Helper loaded: my_helper
INFO - 2024-02-21 14:57:17 --> Database Driver Class Initialized
INFO - 2024-02-21 14:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-21 14:57:17 --> Controller Class Initialized
DEBUG - 2024-02-21 14:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-21 14:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-21 14:57:17 --> Final output sent to browser
DEBUG - 2024-02-21 14:57:17 --> Total execution time: 0.0748
