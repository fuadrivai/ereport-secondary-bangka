<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-20 10:27:18 --> Config Class Initialized
INFO - 2024-01-20 10:27:18 --> Hooks Class Initialized
DEBUG - 2024-01-20 10:27:18 --> UTF-8 Support Enabled
INFO - 2024-01-20 10:27:18 --> Utf8 Class Initialized
INFO - 2024-01-20 10:27:18 --> URI Class Initialized
INFO - 2024-01-20 10:27:18 --> Router Class Initialized
INFO - 2024-01-20 10:27:18 --> Output Class Initialized
INFO - 2024-01-20 10:27:18 --> Security Class Initialized
DEBUG - 2024-01-20 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-20 10:27:18 --> Input Class Initialized
INFO - 2024-01-20 10:27:18 --> Language Class Initialized
INFO - 2024-01-20 10:27:18 --> Language Class Initialized
INFO - 2024-01-20 10:27:18 --> Config Class Initialized
INFO - 2024-01-20 10:27:18 --> Loader Class Initialized
INFO - 2024-01-20 10:27:18 --> Helper loaded: url_helper
INFO - 2024-01-20 10:27:18 --> Helper loaded: file_helper
INFO - 2024-01-20 10:27:18 --> Helper loaded: form_helper
INFO - 2024-01-20 10:27:18 --> Helper loaded: my_helper
INFO - 2024-01-20 10:27:18 --> Database Driver Class Initialized
INFO - 2024-01-20 10:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-20 10:27:18 --> Controller Class Initialized
DEBUG - 2024-01-20 10:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-20 10:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-20 10:27:18 --> Final output sent to browser
DEBUG - 2024-01-20 10:27:18 --> Total execution time: 0.6172
