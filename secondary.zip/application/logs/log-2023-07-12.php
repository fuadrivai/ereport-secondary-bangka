<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-12 08:59:51 --> Config Class Initialized
INFO - 2023-07-12 08:59:51 --> Hooks Class Initialized
DEBUG - 2023-07-12 08:59:51 --> UTF-8 Support Enabled
INFO - 2023-07-12 08:59:51 --> Utf8 Class Initialized
INFO - 2023-07-12 08:59:51 --> URI Class Initialized
DEBUG - 2023-07-12 08:59:51 --> No URI present. Default controller set.
INFO - 2023-07-12 08:59:51 --> Router Class Initialized
INFO - 2023-07-12 08:59:51 --> Output Class Initialized
INFO - 2023-07-12 08:59:51 --> Security Class Initialized
DEBUG - 2023-07-12 08:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 08:59:51 --> Input Class Initialized
INFO - 2023-07-12 08:59:51 --> Language Class Initialized
INFO - 2023-07-12 08:59:52 --> Language Class Initialized
INFO - 2023-07-12 08:59:52 --> Config Class Initialized
INFO - 2023-07-12 08:59:52 --> Loader Class Initialized
INFO - 2023-07-12 08:59:52 --> Helper loaded: url_helper
INFO - 2023-07-12 08:59:52 --> Helper loaded: file_helper
INFO - 2023-07-12 08:59:52 --> Helper loaded: form_helper
INFO - 2023-07-12 08:59:52 --> Helper loaded: my_helper
INFO - 2023-07-12 08:59:52 --> Database Driver Class Initialized
DEBUG - 2023-07-12 08:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 08:59:52 --> Controller Class Initialized
INFO - 2023-07-12 08:59:52 --> Config Class Initialized
INFO - 2023-07-12 08:59:52 --> Hooks Class Initialized
DEBUG - 2023-07-12 08:59:52 --> UTF-8 Support Enabled
INFO - 2023-07-12 08:59:52 --> Utf8 Class Initialized
INFO - 2023-07-12 08:59:52 --> URI Class Initialized
INFO - 2023-07-12 08:59:52 --> Router Class Initialized
INFO - 2023-07-12 08:59:52 --> Output Class Initialized
INFO - 2023-07-12 08:59:52 --> Security Class Initialized
DEBUG - 2023-07-12 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 08:59:52 --> Input Class Initialized
INFO - 2023-07-12 08:59:52 --> Language Class Initialized
INFO - 2023-07-12 08:59:52 --> Language Class Initialized
INFO - 2023-07-12 08:59:52 --> Config Class Initialized
INFO - 2023-07-12 08:59:52 --> Loader Class Initialized
INFO - 2023-07-12 08:59:52 --> Helper loaded: url_helper
INFO - 2023-07-12 08:59:52 --> Helper loaded: file_helper
INFO - 2023-07-12 08:59:52 --> Helper loaded: form_helper
INFO - 2023-07-12 08:59:52 --> Helper loaded: my_helper
INFO - 2023-07-12 08:59:52 --> Database Driver Class Initialized
DEBUG - 2023-07-12 08:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 08:59:52 --> Controller Class Initialized
DEBUG - 2023-07-12 08:59:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-12 08:59:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 08:59:52 --> Final output sent to browser
DEBUG - 2023-07-12 08:59:52 --> Total execution time: 0.1212
INFO - 2023-07-12 09:04:55 --> Config Class Initialized
INFO - 2023-07-12 09:04:55 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:04:55 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:04:55 --> Utf8 Class Initialized
INFO - 2023-07-12 09:04:55 --> URI Class Initialized
INFO - 2023-07-12 09:04:55 --> Router Class Initialized
INFO - 2023-07-12 09:04:55 --> Output Class Initialized
INFO - 2023-07-12 09:04:55 --> Security Class Initialized
DEBUG - 2023-07-12 09:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:04:55 --> Input Class Initialized
INFO - 2023-07-12 09:04:55 --> Language Class Initialized
INFO - 2023-07-12 09:04:55 --> Language Class Initialized
INFO - 2023-07-12 09:04:55 --> Config Class Initialized
INFO - 2023-07-12 09:04:55 --> Loader Class Initialized
INFO - 2023-07-12 09:04:55 --> Helper loaded: url_helper
INFO - 2023-07-12 09:04:55 --> Helper loaded: file_helper
INFO - 2023-07-12 09:04:55 --> Helper loaded: form_helper
INFO - 2023-07-12 09:04:55 --> Helper loaded: my_helper
INFO - 2023-07-12 09:04:55 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:04:55 --> Controller Class Initialized
INFO - 2023-07-12 09:04:55 --> Helper loaded: cookie_helper
INFO - 2023-07-12 09:04:55 --> Final output sent to browser
DEBUG - 2023-07-12 09:04:55 --> Total execution time: 0.1626
INFO - 2023-07-12 09:04:55 --> Config Class Initialized
INFO - 2023-07-12 09:04:55 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:04:55 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:04:55 --> Utf8 Class Initialized
INFO - 2023-07-12 09:04:55 --> URI Class Initialized
INFO - 2023-07-12 09:04:55 --> Router Class Initialized
INFO - 2023-07-12 09:04:55 --> Output Class Initialized
INFO - 2023-07-12 09:04:55 --> Security Class Initialized
DEBUG - 2023-07-12 09:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:04:55 --> Input Class Initialized
INFO - 2023-07-12 09:04:55 --> Language Class Initialized
INFO - 2023-07-12 09:04:55 --> Language Class Initialized
INFO - 2023-07-12 09:04:55 --> Config Class Initialized
INFO - 2023-07-12 09:04:55 --> Loader Class Initialized
INFO - 2023-07-12 09:04:55 --> Helper loaded: url_helper
INFO - 2023-07-12 09:04:55 --> Helper loaded: file_helper
INFO - 2023-07-12 09:04:55 --> Helper loaded: form_helper
INFO - 2023-07-12 09:04:55 --> Helper loaded: my_helper
INFO - 2023-07-12 09:04:55 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:04:55 --> Controller Class Initialized
DEBUG - 2023-07-12 09:04:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-12 09:04:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:04:55 --> Final output sent to browser
DEBUG - 2023-07-12 09:04:55 --> Total execution time: 0.1512
INFO - 2023-07-12 09:06:03 --> Config Class Initialized
INFO - 2023-07-12 09:06:03 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:06:03 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:06:03 --> Utf8 Class Initialized
INFO - 2023-07-12 09:06:03 --> URI Class Initialized
INFO - 2023-07-12 09:06:03 --> Router Class Initialized
INFO - 2023-07-12 09:06:03 --> Output Class Initialized
INFO - 2023-07-12 09:06:03 --> Security Class Initialized
DEBUG - 2023-07-12 09:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:06:03 --> Input Class Initialized
INFO - 2023-07-12 09:06:03 --> Language Class Initialized
INFO - 2023-07-12 09:06:03 --> Language Class Initialized
INFO - 2023-07-12 09:06:03 --> Config Class Initialized
INFO - 2023-07-12 09:06:03 --> Loader Class Initialized
INFO - 2023-07-12 09:06:03 --> Helper loaded: url_helper
INFO - 2023-07-12 09:06:03 --> Helper loaded: file_helper
INFO - 2023-07-12 09:06:03 --> Helper loaded: form_helper
INFO - 2023-07-12 09:06:03 --> Helper loaded: my_helper
INFO - 2023-07-12 09:06:03 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:06:03 --> Controller Class Initialized
DEBUG - 2023-07-12 09:06:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-12 09:06:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:06:03 --> Final output sent to browser
DEBUG - 2023-07-12 09:06:03 --> Total execution time: 0.1597
INFO - 2023-07-12 09:07:21 --> Config Class Initialized
INFO - 2023-07-12 09:07:21 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:07:21 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:07:21 --> Utf8 Class Initialized
INFO - 2023-07-12 09:07:21 --> URI Class Initialized
INFO - 2023-07-12 09:07:21 --> Router Class Initialized
INFO - 2023-07-12 09:07:21 --> Output Class Initialized
INFO - 2023-07-12 09:07:21 --> Security Class Initialized
DEBUG - 2023-07-12 09:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:07:21 --> Input Class Initialized
INFO - 2023-07-12 09:07:21 --> Language Class Initialized
INFO - 2023-07-12 09:07:21 --> Language Class Initialized
INFO - 2023-07-12 09:07:21 --> Config Class Initialized
INFO - 2023-07-12 09:07:21 --> Loader Class Initialized
INFO - 2023-07-12 09:07:21 --> Helper loaded: url_helper
INFO - 2023-07-12 09:07:21 --> Helper loaded: file_helper
INFO - 2023-07-12 09:07:21 --> Helper loaded: form_helper
INFO - 2023-07-12 09:07:21 --> Helper loaded: my_helper
INFO - 2023-07-12 09:07:21 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:07:21 --> Controller Class Initialized
DEBUG - 2023-07-12 09:07:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-12 09:07:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:07:21 --> Final output sent to browser
DEBUG - 2023-07-12 09:07:21 --> Total execution time: 0.1339
INFO - 2023-07-12 09:07:21 --> Config Class Initialized
INFO - 2023-07-12 09:07:21 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:07:21 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:07:21 --> Utf8 Class Initialized
INFO - 2023-07-12 09:07:21 --> URI Class Initialized
INFO - 2023-07-12 09:07:21 --> Router Class Initialized
INFO - 2023-07-12 09:07:21 --> Output Class Initialized
INFO - 2023-07-12 09:07:21 --> Security Class Initialized
DEBUG - 2023-07-12 09:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:07:21 --> Input Class Initialized
INFO - 2023-07-12 09:07:21 --> Language Class Initialized
INFO - 2023-07-12 09:07:21 --> Language Class Initialized
INFO - 2023-07-12 09:07:21 --> Config Class Initialized
INFO - 2023-07-12 09:07:21 --> Loader Class Initialized
INFO - 2023-07-12 09:07:21 --> Helper loaded: url_helper
INFO - 2023-07-12 09:07:21 --> Helper loaded: file_helper
INFO - 2023-07-12 09:07:21 --> Helper loaded: form_helper
INFO - 2023-07-12 09:07:21 --> Helper loaded: my_helper
INFO - 2023-07-12 09:07:21 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:07:22 --> Controller Class Initialized
INFO - 2023-07-12 09:08:59 --> Config Class Initialized
INFO - 2023-07-12 09:08:59 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:08:59 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:08:59 --> Utf8 Class Initialized
INFO - 2023-07-12 09:08:59 --> URI Class Initialized
INFO - 2023-07-12 09:08:59 --> Router Class Initialized
INFO - 2023-07-12 09:08:59 --> Output Class Initialized
INFO - 2023-07-12 09:08:59 --> Security Class Initialized
DEBUG - 2023-07-12 09:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:08:59 --> Input Class Initialized
INFO - 2023-07-12 09:08:59 --> Language Class Initialized
INFO - 2023-07-12 09:08:59 --> Language Class Initialized
INFO - 2023-07-12 09:08:59 --> Config Class Initialized
INFO - 2023-07-12 09:08:59 --> Loader Class Initialized
INFO - 2023-07-12 09:08:59 --> Helper loaded: url_helper
INFO - 2023-07-12 09:08:59 --> Helper loaded: file_helper
INFO - 2023-07-12 09:08:59 --> Helper loaded: form_helper
INFO - 2023-07-12 09:08:59 --> Helper loaded: my_helper
INFO - 2023-07-12 09:08:59 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:08:59 --> Controller Class Initialized
INFO - 2023-07-12 09:08:59 --> Final output sent to browser
DEBUG - 2023-07-12 09:08:59 --> Total execution time: 0.1039
INFO - 2023-07-12 09:10:03 --> Config Class Initialized
INFO - 2023-07-12 09:10:03 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:10:03 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:10:03 --> Utf8 Class Initialized
INFO - 2023-07-12 09:10:03 --> URI Class Initialized
INFO - 2023-07-12 09:10:03 --> Router Class Initialized
INFO - 2023-07-12 09:10:03 --> Output Class Initialized
INFO - 2023-07-12 09:10:03 --> Security Class Initialized
DEBUG - 2023-07-12 09:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:10:03 --> Input Class Initialized
INFO - 2023-07-12 09:10:03 --> Language Class Initialized
INFO - 2023-07-12 09:10:03 --> Language Class Initialized
INFO - 2023-07-12 09:10:03 --> Config Class Initialized
INFO - 2023-07-12 09:10:03 --> Loader Class Initialized
INFO - 2023-07-12 09:10:03 --> Helper loaded: url_helper
INFO - 2023-07-12 09:10:03 --> Helper loaded: file_helper
INFO - 2023-07-12 09:10:03 --> Helper loaded: form_helper
INFO - 2023-07-12 09:10:03 --> Helper loaded: my_helper
INFO - 2023-07-12 09:10:03 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:10:03 --> Controller Class Initialized
INFO - 2023-07-12 09:10:03 --> Final output sent to browser
DEBUG - 2023-07-12 09:10:03 --> Total execution time: 0.0681
INFO - 2023-07-12 09:10:41 --> Config Class Initialized
INFO - 2023-07-12 09:10:41 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:10:41 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:10:41 --> Utf8 Class Initialized
INFO - 2023-07-12 09:10:41 --> URI Class Initialized
INFO - 2023-07-12 09:10:41 --> Router Class Initialized
INFO - 2023-07-12 09:10:41 --> Output Class Initialized
INFO - 2023-07-12 09:10:41 --> Security Class Initialized
DEBUG - 2023-07-12 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:10:41 --> Input Class Initialized
INFO - 2023-07-12 09:10:41 --> Language Class Initialized
INFO - 2023-07-12 09:10:41 --> Language Class Initialized
INFO - 2023-07-12 09:10:41 --> Config Class Initialized
INFO - 2023-07-12 09:10:41 --> Loader Class Initialized
INFO - 2023-07-12 09:10:41 --> Helper loaded: url_helper
INFO - 2023-07-12 09:10:41 --> Helper loaded: file_helper
INFO - 2023-07-12 09:10:41 --> Helper loaded: form_helper
INFO - 2023-07-12 09:10:41 --> Helper loaded: my_helper
INFO - 2023-07-12 09:10:41 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:10:41 --> Controller Class Initialized
INFO - 2023-07-12 09:10:41 --> Final output sent to browser
DEBUG - 2023-07-12 09:10:41 --> Total execution time: 0.0543
INFO - 2023-07-12 09:10:43 --> Config Class Initialized
INFO - 2023-07-12 09:10:43 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:10:43 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:10:43 --> Utf8 Class Initialized
INFO - 2023-07-12 09:10:43 --> URI Class Initialized
INFO - 2023-07-12 09:10:43 --> Router Class Initialized
INFO - 2023-07-12 09:10:43 --> Output Class Initialized
INFO - 2023-07-12 09:10:43 --> Security Class Initialized
DEBUG - 2023-07-12 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:10:43 --> Input Class Initialized
INFO - 2023-07-12 09:10:43 --> Language Class Initialized
INFO - 2023-07-12 09:10:43 --> Language Class Initialized
INFO - 2023-07-12 09:10:43 --> Config Class Initialized
INFO - 2023-07-12 09:10:43 --> Loader Class Initialized
INFO - 2023-07-12 09:10:43 --> Helper loaded: url_helper
INFO - 2023-07-12 09:10:43 --> Helper loaded: file_helper
INFO - 2023-07-12 09:10:43 --> Helper loaded: form_helper
INFO - 2023-07-12 09:10:43 --> Helper loaded: my_helper
INFO - 2023-07-12 09:10:43 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:10:43 --> Controller Class Initialized
INFO - 2023-07-12 09:10:43 --> Final output sent to browser
DEBUG - 2023-07-12 09:10:43 --> Total execution time: 0.0572
INFO - 2023-07-12 09:11:17 --> Config Class Initialized
INFO - 2023-07-12 09:11:17 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:11:17 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:11:17 --> Utf8 Class Initialized
INFO - 2023-07-12 09:11:17 --> URI Class Initialized
INFO - 2023-07-12 09:11:17 --> Router Class Initialized
INFO - 2023-07-12 09:11:17 --> Output Class Initialized
INFO - 2023-07-12 09:11:17 --> Security Class Initialized
DEBUG - 2023-07-12 09:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:11:17 --> Input Class Initialized
INFO - 2023-07-12 09:11:17 --> Language Class Initialized
INFO - 2023-07-12 09:11:17 --> Language Class Initialized
INFO - 2023-07-12 09:11:17 --> Config Class Initialized
INFO - 2023-07-12 09:11:17 --> Loader Class Initialized
INFO - 2023-07-12 09:11:17 --> Helper loaded: url_helper
INFO - 2023-07-12 09:11:17 --> Helper loaded: file_helper
INFO - 2023-07-12 09:11:17 --> Helper loaded: form_helper
INFO - 2023-07-12 09:11:17 --> Helper loaded: my_helper
INFO - 2023-07-12 09:11:17 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:11:17 --> Controller Class Initialized
INFO - 2023-07-12 09:11:17 --> Final output sent to browser
DEBUG - 2023-07-12 09:11:17 --> Total execution time: 0.0747
INFO - 2023-07-12 09:11:21 --> Config Class Initialized
INFO - 2023-07-12 09:11:21 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:11:21 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:11:21 --> Utf8 Class Initialized
INFO - 2023-07-12 09:11:21 --> URI Class Initialized
INFO - 2023-07-12 09:11:21 --> Router Class Initialized
INFO - 2023-07-12 09:11:21 --> Output Class Initialized
INFO - 2023-07-12 09:11:21 --> Security Class Initialized
DEBUG - 2023-07-12 09:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:11:21 --> Input Class Initialized
INFO - 2023-07-12 09:11:21 --> Language Class Initialized
INFO - 2023-07-12 09:11:21 --> Language Class Initialized
INFO - 2023-07-12 09:11:21 --> Config Class Initialized
INFO - 2023-07-12 09:11:21 --> Loader Class Initialized
INFO - 2023-07-12 09:11:21 --> Helper loaded: url_helper
INFO - 2023-07-12 09:11:21 --> Helper loaded: file_helper
INFO - 2023-07-12 09:11:21 --> Helper loaded: form_helper
INFO - 2023-07-12 09:11:21 --> Helper loaded: my_helper
INFO - 2023-07-12 09:11:21 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:11:21 --> Controller Class Initialized
INFO - 2023-07-12 09:11:21 --> Final output sent to browser
DEBUG - 2023-07-12 09:11:21 --> Total execution time: 0.0417
INFO - 2023-07-12 09:11:26 --> Config Class Initialized
INFO - 2023-07-12 09:11:26 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:11:26 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:11:26 --> Utf8 Class Initialized
INFO - 2023-07-12 09:11:26 --> URI Class Initialized
INFO - 2023-07-12 09:11:26 --> Router Class Initialized
INFO - 2023-07-12 09:11:26 --> Output Class Initialized
INFO - 2023-07-12 09:11:26 --> Security Class Initialized
DEBUG - 2023-07-12 09:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:11:26 --> Input Class Initialized
INFO - 2023-07-12 09:11:26 --> Language Class Initialized
INFO - 2023-07-12 09:11:26 --> Language Class Initialized
INFO - 2023-07-12 09:11:26 --> Config Class Initialized
INFO - 2023-07-12 09:11:26 --> Loader Class Initialized
INFO - 2023-07-12 09:11:26 --> Helper loaded: url_helper
INFO - 2023-07-12 09:11:26 --> Helper loaded: file_helper
INFO - 2023-07-12 09:11:26 --> Helper loaded: form_helper
INFO - 2023-07-12 09:11:26 --> Helper loaded: my_helper
INFO - 2023-07-12 09:11:26 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:11:26 --> Controller Class Initialized
INFO - 2023-07-12 09:11:26 --> Final output sent to browser
DEBUG - 2023-07-12 09:11:26 --> Total execution time: 0.0437
INFO - 2023-07-12 09:11:28 --> Config Class Initialized
INFO - 2023-07-12 09:11:28 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:11:28 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:11:28 --> Utf8 Class Initialized
INFO - 2023-07-12 09:11:28 --> URI Class Initialized
INFO - 2023-07-12 09:11:28 --> Router Class Initialized
INFO - 2023-07-12 09:11:28 --> Output Class Initialized
INFO - 2023-07-12 09:11:28 --> Security Class Initialized
DEBUG - 2023-07-12 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:11:28 --> Input Class Initialized
INFO - 2023-07-12 09:11:28 --> Language Class Initialized
INFO - 2023-07-12 09:11:28 --> Language Class Initialized
INFO - 2023-07-12 09:11:28 --> Config Class Initialized
INFO - 2023-07-12 09:11:28 --> Loader Class Initialized
INFO - 2023-07-12 09:11:28 --> Helper loaded: url_helper
INFO - 2023-07-12 09:11:28 --> Helper loaded: file_helper
INFO - 2023-07-12 09:11:28 --> Helper loaded: form_helper
INFO - 2023-07-12 09:11:28 --> Helper loaded: my_helper
INFO - 2023-07-12 09:11:28 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:11:28 --> Controller Class Initialized
INFO - 2023-07-12 09:11:28 --> Final output sent to browser
DEBUG - 2023-07-12 09:11:28 --> Total execution time: 0.0571
INFO - 2023-07-12 09:11:30 --> Config Class Initialized
INFO - 2023-07-12 09:11:30 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:11:30 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:11:30 --> Utf8 Class Initialized
INFO - 2023-07-12 09:11:30 --> URI Class Initialized
INFO - 2023-07-12 09:11:30 --> Router Class Initialized
INFO - 2023-07-12 09:11:30 --> Output Class Initialized
INFO - 2023-07-12 09:11:30 --> Security Class Initialized
DEBUG - 2023-07-12 09:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:11:30 --> Input Class Initialized
INFO - 2023-07-12 09:11:30 --> Language Class Initialized
INFO - 2023-07-12 09:11:30 --> Language Class Initialized
INFO - 2023-07-12 09:11:30 --> Config Class Initialized
INFO - 2023-07-12 09:11:30 --> Loader Class Initialized
INFO - 2023-07-12 09:11:30 --> Helper loaded: url_helper
INFO - 2023-07-12 09:11:30 --> Helper loaded: file_helper
INFO - 2023-07-12 09:11:30 --> Helper loaded: form_helper
INFO - 2023-07-12 09:11:30 --> Helper loaded: my_helper
INFO - 2023-07-12 09:11:30 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:11:30 --> Controller Class Initialized
INFO - 2023-07-12 09:11:30 --> Final output sent to browser
DEBUG - 2023-07-12 09:11:30 --> Total execution time: 0.0590
INFO - 2023-07-12 09:12:14 --> Config Class Initialized
INFO - 2023-07-12 09:12:14 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:12:14 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:12:14 --> Utf8 Class Initialized
INFO - 2023-07-12 09:12:14 --> URI Class Initialized
INFO - 2023-07-12 09:12:14 --> Router Class Initialized
INFO - 2023-07-12 09:12:14 --> Output Class Initialized
INFO - 2023-07-12 09:12:14 --> Security Class Initialized
DEBUG - 2023-07-12 09:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:12:14 --> Input Class Initialized
INFO - 2023-07-12 09:12:14 --> Language Class Initialized
INFO - 2023-07-12 09:12:14 --> Language Class Initialized
INFO - 2023-07-12 09:12:14 --> Config Class Initialized
INFO - 2023-07-12 09:12:14 --> Loader Class Initialized
INFO - 2023-07-12 09:12:14 --> Helper loaded: url_helper
INFO - 2023-07-12 09:12:14 --> Helper loaded: file_helper
INFO - 2023-07-12 09:12:14 --> Helper loaded: form_helper
INFO - 2023-07-12 09:12:14 --> Helper loaded: my_helper
INFO - 2023-07-12 09:12:14 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:12:14 --> Controller Class Initialized
INFO - 2023-07-12 09:18:04 --> Config Class Initialized
INFO - 2023-07-12 09:18:04 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:04 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:04 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:04 --> URI Class Initialized
INFO - 2023-07-12 09:18:04 --> Router Class Initialized
INFO - 2023-07-12 09:18:04 --> Output Class Initialized
INFO - 2023-07-12 09:18:04 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:04 --> Input Class Initialized
INFO - 2023-07-12 09:18:04 --> Language Class Initialized
INFO - 2023-07-12 09:18:04 --> Language Class Initialized
INFO - 2023-07-12 09:18:04 --> Config Class Initialized
INFO - 2023-07-12 09:18:04 --> Loader Class Initialized
INFO - 2023-07-12 09:18:04 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:04 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:04 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:04 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:04 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:04 --> Controller Class Initialized
DEBUG - 2023-07-12 09:18:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-07-12 09:18:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:18:04 --> Final output sent to browser
DEBUG - 2023-07-12 09:18:04 --> Total execution time: 0.0782
INFO - 2023-07-12 09:18:12 --> Config Class Initialized
INFO - 2023-07-12 09:18:12 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:12 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:12 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:12 --> URI Class Initialized
INFO - 2023-07-12 09:18:12 --> Router Class Initialized
INFO - 2023-07-12 09:18:12 --> Output Class Initialized
INFO - 2023-07-12 09:18:12 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:12 --> Input Class Initialized
INFO - 2023-07-12 09:18:12 --> Language Class Initialized
INFO - 2023-07-12 09:18:12 --> Language Class Initialized
INFO - 2023-07-12 09:18:12 --> Config Class Initialized
INFO - 2023-07-12 09:18:12 --> Loader Class Initialized
INFO - 2023-07-12 09:18:12 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:12 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:12 --> Controller Class Initialized
INFO - 2023-07-12 09:18:12 --> Config Class Initialized
INFO - 2023-07-12 09:18:12 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:12 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:12 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:12 --> URI Class Initialized
INFO - 2023-07-12 09:18:12 --> Router Class Initialized
INFO - 2023-07-12 09:18:12 --> Output Class Initialized
INFO - 2023-07-12 09:18:12 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:12 --> Input Class Initialized
INFO - 2023-07-12 09:18:12 --> Language Class Initialized
INFO - 2023-07-12 09:18:12 --> Language Class Initialized
INFO - 2023-07-12 09:18:12 --> Config Class Initialized
INFO - 2023-07-12 09:18:12 --> Loader Class Initialized
INFO - 2023-07-12 09:18:12 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:12 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:12 --> Controller Class Initialized
DEBUG - 2023-07-12 09:18:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-12 09:18:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:18:12 --> Final output sent to browser
DEBUG - 2023-07-12 09:18:12 --> Total execution time: 0.0690
INFO - 2023-07-12 09:18:12 --> Config Class Initialized
INFO - 2023-07-12 09:18:12 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:12 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:12 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:12 --> URI Class Initialized
INFO - 2023-07-12 09:18:12 --> Router Class Initialized
INFO - 2023-07-12 09:18:12 --> Output Class Initialized
INFO - 2023-07-12 09:18:12 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:12 --> Input Class Initialized
INFO - 2023-07-12 09:18:12 --> Language Class Initialized
INFO - 2023-07-12 09:18:12 --> Language Class Initialized
INFO - 2023-07-12 09:18:12 --> Config Class Initialized
INFO - 2023-07-12 09:18:12 --> Loader Class Initialized
INFO - 2023-07-12 09:18:12 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:12 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:12 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:12 --> Controller Class Initialized
INFO - 2023-07-12 09:18:16 --> Config Class Initialized
INFO - 2023-07-12 09:18:16 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:16 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:16 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:16 --> URI Class Initialized
INFO - 2023-07-12 09:18:16 --> Router Class Initialized
INFO - 2023-07-12 09:18:16 --> Output Class Initialized
INFO - 2023-07-12 09:18:16 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:16 --> Input Class Initialized
INFO - 2023-07-12 09:18:16 --> Language Class Initialized
INFO - 2023-07-12 09:18:16 --> Language Class Initialized
INFO - 2023-07-12 09:18:16 --> Config Class Initialized
INFO - 2023-07-12 09:18:16 --> Loader Class Initialized
INFO - 2023-07-12 09:18:16 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:16 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:16 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:16 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:16 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:16 --> Controller Class Initialized
INFO - 2023-07-12 09:18:16 --> Final output sent to browser
DEBUG - 2023-07-12 09:18:16 --> Total execution time: 0.0573
INFO - 2023-07-12 09:18:21 --> Config Class Initialized
INFO - 2023-07-12 09:18:21 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:21 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:21 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:21 --> URI Class Initialized
INFO - 2023-07-12 09:18:21 --> Router Class Initialized
INFO - 2023-07-12 09:18:21 --> Output Class Initialized
INFO - 2023-07-12 09:18:21 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:21 --> Input Class Initialized
INFO - 2023-07-12 09:18:21 --> Language Class Initialized
INFO - 2023-07-12 09:18:21 --> Language Class Initialized
INFO - 2023-07-12 09:18:21 --> Config Class Initialized
INFO - 2023-07-12 09:18:21 --> Loader Class Initialized
INFO - 2023-07-12 09:18:21 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:21 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:21 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:21 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:21 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:21 --> Controller Class Initialized
INFO - 2023-07-12 09:18:21 --> Final output sent to browser
DEBUG - 2023-07-12 09:18:21 --> Total execution time: 0.0576
INFO - 2023-07-12 09:18:36 --> Config Class Initialized
INFO - 2023-07-12 09:18:36 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:36 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:36 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:36 --> URI Class Initialized
INFO - 2023-07-12 09:18:36 --> Router Class Initialized
INFO - 2023-07-12 09:18:36 --> Output Class Initialized
INFO - 2023-07-12 09:18:36 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:36 --> Input Class Initialized
INFO - 2023-07-12 09:18:36 --> Language Class Initialized
INFO - 2023-07-12 09:18:36 --> Language Class Initialized
INFO - 2023-07-12 09:18:36 --> Config Class Initialized
INFO - 2023-07-12 09:18:36 --> Loader Class Initialized
INFO - 2023-07-12 09:18:36 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:36 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:36 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:36 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:36 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:36 --> Controller Class Initialized
INFO - 2023-07-12 09:18:36 --> Final output sent to browser
DEBUG - 2023-07-12 09:18:36 --> Total execution time: 0.0592
INFO - 2023-07-12 09:18:38 --> Config Class Initialized
INFO - 2023-07-12 09:18:38 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:38 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:38 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:38 --> URI Class Initialized
INFO - 2023-07-12 09:18:38 --> Router Class Initialized
INFO - 2023-07-12 09:18:38 --> Output Class Initialized
INFO - 2023-07-12 09:18:38 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:38 --> Input Class Initialized
INFO - 2023-07-12 09:18:38 --> Language Class Initialized
INFO - 2023-07-12 09:18:38 --> Language Class Initialized
INFO - 2023-07-12 09:18:38 --> Config Class Initialized
INFO - 2023-07-12 09:18:38 --> Loader Class Initialized
INFO - 2023-07-12 09:18:38 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:38 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:38 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:38 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:38 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:38 --> Controller Class Initialized
DEBUG - 2023-07-12 09:18:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-12 09:18:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:18:38 --> Final output sent to browser
DEBUG - 2023-07-12 09:18:38 --> Total execution time: 0.0742
INFO - 2023-07-12 09:18:38 --> Config Class Initialized
INFO - 2023-07-12 09:18:38 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:18:38 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:18:38 --> Utf8 Class Initialized
INFO - 2023-07-12 09:18:38 --> URI Class Initialized
INFO - 2023-07-12 09:18:38 --> Router Class Initialized
INFO - 2023-07-12 09:18:38 --> Output Class Initialized
INFO - 2023-07-12 09:18:38 --> Security Class Initialized
DEBUG - 2023-07-12 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:18:38 --> Input Class Initialized
INFO - 2023-07-12 09:18:38 --> Language Class Initialized
INFO - 2023-07-12 09:18:38 --> Language Class Initialized
INFO - 2023-07-12 09:18:38 --> Config Class Initialized
INFO - 2023-07-12 09:18:38 --> Loader Class Initialized
INFO - 2023-07-12 09:18:38 --> Helper loaded: url_helper
INFO - 2023-07-12 09:18:38 --> Helper loaded: file_helper
INFO - 2023-07-12 09:18:38 --> Helper loaded: form_helper
INFO - 2023-07-12 09:18:38 --> Helper loaded: my_helper
INFO - 2023-07-12 09:18:38 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:18:38 --> Controller Class Initialized
INFO - 2023-07-12 09:24:47 --> Config Class Initialized
INFO - 2023-07-12 09:24:47 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:24:47 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:24:47 --> Utf8 Class Initialized
INFO - 2023-07-12 09:24:47 --> URI Class Initialized
INFO - 2023-07-12 09:24:47 --> Router Class Initialized
INFO - 2023-07-12 09:24:47 --> Output Class Initialized
INFO - 2023-07-12 09:24:47 --> Security Class Initialized
DEBUG - 2023-07-12 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:24:47 --> Input Class Initialized
INFO - 2023-07-12 09:24:47 --> Language Class Initialized
INFO - 2023-07-12 09:24:47 --> Language Class Initialized
INFO - 2023-07-12 09:24:47 --> Config Class Initialized
INFO - 2023-07-12 09:24:47 --> Loader Class Initialized
INFO - 2023-07-12 09:24:47 --> Helper loaded: url_helper
INFO - 2023-07-12 09:24:47 --> Helper loaded: file_helper
INFO - 2023-07-12 09:24:47 --> Helper loaded: form_helper
INFO - 2023-07-12 09:24:47 --> Helper loaded: my_helper
INFO - 2023-07-12 09:24:47 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:24:47 --> Controller Class Initialized
DEBUG - 2023-07-12 09:24:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-12 09:24:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:24:47 --> Final output sent to browser
DEBUG - 2023-07-12 09:24:47 --> Total execution time: 0.0511
INFO - 2023-07-12 09:24:48 --> Config Class Initialized
INFO - 2023-07-12 09:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:24:48 --> Utf8 Class Initialized
INFO - 2023-07-12 09:24:48 --> URI Class Initialized
INFO - 2023-07-12 09:24:48 --> Router Class Initialized
INFO - 2023-07-12 09:24:48 --> Output Class Initialized
INFO - 2023-07-12 09:24:48 --> Security Class Initialized
DEBUG - 2023-07-12 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:24:48 --> Input Class Initialized
INFO - 2023-07-12 09:24:48 --> Language Class Initialized
INFO - 2023-07-12 09:24:49 --> Language Class Initialized
INFO - 2023-07-12 09:24:49 --> Config Class Initialized
INFO - 2023-07-12 09:24:49 --> Loader Class Initialized
INFO - 2023-07-12 09:24:49 --> Helper loaded: url_helper
INFO - 2023-07-12 09:24:49 --> Helper loaded: file_helper
INFO - 2023-07-12 09:24:49 --> Helper loaded: form_helper
INFO - 2023-07-12 09:24:49 --> Helper loaded: my_helper
INFO - 2023-07-12 09:24:49 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:24:49 --> Controller Class Initialized
DEBUG - 2023-07-12 09:24:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-12 09:24:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:24:49 --> Final output sent to browser
DEBUG - 2023-07-12 09:24:49 --> Total execution time: 0.1597
INFO - 2023-07-12 09:24:51 --> Config Class Initialized
INFO - 2023-07-12 09:24:51 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:24:51 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:24:51 --> Utf8 Class Initialized
INFO - 2023-07-12 09:24:51 --> URI Class Initialized
INFO - 2023-07-12 09:24:51 --> Router Class Initialized
INFO - 2023-07-12 09:24:51 --> Output Class Initialized
INFO - 2023-07-12 09:24:51 --> Security Class Initialized
DEBUG - 2023-07-12 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:24:51 --> Input Class Initialized
INFO - 2023-07-12 09:24:51 --> Language Class Initialized
INFO - 2023-07-12 09:24:51 --> Language Class Initialized
INFO - 2023-07-12 09:24:51 --> Config Class Initialized
INFO - 2023-07-12 09:24:51 --> Loader Class Initialized
INFO - 2023-07-12 09:24:51 --> Helper loaded: url_helper
INFO - 2023-07-12 09:24:51 --> Helper loaded: file_helper
INFO - 2023-07-12 09:24:51 --> Helper loaded: form_helper
INFO - 2023-07-12 09:24:51 --> Helper loaded: my_helper
INFO - 2023-07-12 09:24:51 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:24:51 --> Controller Class Initialized
INFO - 2023-07-12 09:24:51 --> Final output sent to browser
DEBUG - 2023-07-12 09:24:51 --> Total execution time: 0.0693
INFO - 2023-07-12 09:24:57 --> Config Class Initialized
INFO - 2023-07-12 09:24:57 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:24:57 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:24:57 --> Utf8 Class Initialized
INFO - 2023-07-12 09:24:57 --> URI Class Initialized
INFO - 2023-07-12 09:24:57 --> Router Class Initialized
INFO - 2023-07-12 09:24:57 --> Output Class Initialized
INFO - 2023-07-12 09:24:57 --> Security Class Initialized
DEBUG - 2023-07-12 09:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:24:57 --> Input Class Initialized
INFO - 2023-07-12 09:24:57 --> Language Class Initialized
INFO - 2023-07-12 09:24:57 --> Language Class Initialized
INFO - 2023-07-12 09:24:57 --> Config Class Initialized
INFO - 2023-07-12 09:24:57 --> Loader Class Initialized
INFO - 2023-07-12 09:24:57 --> Helper loaded: url_helper
INFO - 2023-07-12 09:24:57 --> Helper loaded: file_helper
INFO - 2023-07-12 09:24:57 --> Helper loaded: form_helper
INFO - 2023-07-12 09:24:57 --> Helper loaded: my_helper
INFO - 2023-07-12 09:24:58 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:24:58 --> Controller Class Initialized
DEBUG - 2023-07-12 09:24:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-12 09:24:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:24:58 --> Final output sent to browser
DEBUG - 2023-07-12 09:24:58 --> Total execution time: 0.0730
INFO - 2023-07-12 09:25:01 --> Config Class Initialized
INFO - 2023-07-12 09:25:01 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:25:01 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:25:01 --> Utf8 Class Initialized
INFO - 2023-07-12 09:25:01 --> URI Class Initialized
INFO - 2023-07-12 09:25:01 --> Router Class Initialized
INFO - 2023-07-12 09:25:01 --> Output Class Initialized
INFO - 2023-07-12 09:25:01 --> Security Class Initialized
DEBUG - 2023-07-12 09:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:25:01 --> Input Class Initialized
INFO - 2023-07-12 09:25:01 --> Language Class Initialized
INFO - 2023-07-12 09:25:01 --> Language Class Initialized
INFO - 2023-07-12 09:25:01 --> Config Class Initialized
INFO - 2023-07-12 09:25:01 --> Loader Class Initialized
INFO - 2023-07-12 09:25:01 --> Helper loaded: url_helper
INFO - 2023-07-12 09:25:01 --> Helper loaded: file_helper
INFO - 2023-07-12 09:25:01 --> Helper loaded: form_helper
INFO - 2023-07-12 09:25:01 --> Helper loaded: my_helper
INFO - 2023-07-12 09:25:01 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:25:01 --> Controller Class Initialized
DEBUG - 2023-07-12 09:25:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-12 09:25:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:25:01 --> Final output sent to browser
DEBUG - 2023-07-12 09:25:01 --> Total execution time: 0.0473
INFO - 2023-07-12 09:25:01 --> Config Class Initialized
INFO - 2023-07-12 09:25:01 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:25:01 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:25:01 --> Utf8 Class Initialized
INFO - 2023-07-12 09:25:01 --> URI Class Initialized
INFO - 2023-07-12 09:25:01 --> Router Class Initialized
INFO - 2023-07-12 09:25:01 --> Output Class Initialized
INFO - 2023-07-12 09:25:01 --> Security Class Initialized
DEBUG - 2023-07-12 09:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:25:01 --> Input Class Initialized
INFO - 2023-07-12 09:25:01 --> Language Class Initialized
INFO - 2023-07-12 09:25:01 --> Language Class Initialized
INFO - 2023-07-12 09:25:01 --> Config Class Initialized
INFO - 2023-07-12 09:25:01 --> Loader Class Initialized
INFO - 2023-07-12 09:25:01 --> Helper loaded: url_helper
INFO - 2023-07-12 09:25:01 --> Helper loaded: file_helper
INFO - 2023-07-12 09:25:01 --> Helper loaded: form_helper
INFO - 2023-07-12 09:25:01 --> Helper loaded: my_helper
INFO - 2023-07-12 09:25:01 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:25:01 --> Controller Class Initialized
INFO - 2023-07-12 09:27:37 --> Config Class Initialized
INFO - 2023-07-12 09:27:37 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:27:37 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:27:37 --> Utf8 Class Initialized
INFO - 2023-07-12 09:27:37 --> URI Class Initialized
INFO - 2023-07-12 09:27:37 --> Router Class Initialized
INFO - 2023-07-12 09:27:37 --> Output Class Initialized
INFO - 2023-07-12 09:27:37 --> Security Class Initialized
DEBUG - 2023-07-12 09:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:27:37 --> Input Class Initialized
INFO - 2023-07-12 09:27:37 --> Language Class Initialized
INFO - 2023-07-12 09:27:37 --> Language Class Initialized
INFO - 2023-07-12 09:27:37 --> Config Class Initialized
INFO - 2023-07-12 09:27:37 --> Loader Class Initialized
INFO - 2023-07-12 09:27:37 --> Helper loaded: url_helper
INFO - 2023-07-12 09:27:37 --> Helper loaded: file_helper
INFO - 2023-07-12 09:27:37 --> Helper loaded: form_helper
INFO - 2023-07-12 09:27:37 --> Helper loaded: my_helper
INFO - 2023-07-12 09:27:37 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:27:37 --> Controller Class Initialized
DEBUG - 2023-07-12 09:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-12 09:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:27:37 --> Final output sent to browser
DEBUG - 2023-07-12 09:27:37 --> Total execution time: 0.0495
INFO - 2023-07-12 09:28:14 --> Config Class Initialized
INFO - 2023-07-12 09:28:14 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:28:14 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:28:14 --> Utf8 Class Initialized
INFO - 2023-07-12 09:28:14 --> URI Class Initialized
INFO - 2023-07-12 09:28:14 --> Router Class Initialized
INFO - 2023-07-12 09:28:14 --> Output Class Initialized
INFO - 2023-07-12 09:28:14 --> Security Class Initialized
DEBUG - 2023-07-12 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:28:14 --> Input Class Initialized
INFO - 2023-07-12 09:28:14 --> Language Class Initialized
INFO - 2023-07-12 09:28:14 --> Language Class Initialized
INFO - 2023-07-12 09:28:14 --> Config Class Initialized
INFO - 2023-07-12 09:28:14 --> Loader Class Initialized
INFO - 2023-07-12 09:28:14 --> Helper loaded: url_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: file_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: form_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: my_helper
INFO - 2023-07-12 09:28:14 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:28:14 --> Controller Class Initialized
INFO - 2023-07-12 09:28:14 --> Helper loaded: cookie_helper
INFO - 2023-07-12 09:28:14 --> Config Class Initialized
INFO - 2023-07-12 09:28:14 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:28:14 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:28:14 --> Utf8 Class Initialized
INFO - 2023-07-12 09:28:14 --> URI Class Initialized
INFO - 2023-07-12 09:28:14 --> Router Class Initialized
INFO - 2023-07-12 09:28:14 --> Output Class Initialized
INFO - 2023-07-12 09:28:14 --> Security Class Initialized
DEBUG - 2023-07-12 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:28:14 --> Input Class Initialized
INFO - 2023-07-12 09:28:14 --> Language Class Initialized
INFO - 2023-07-12 09:28:14 --> Language Class Initialized
INFO - 2023-07-12 09:28:14 --> Config Class Initialized
INFO - 2023-07-12 09:28:14 --> Loader Class Initialized
INFO - 2023-07-12 09:28:14 --> Helper loaded: url_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: file_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: form_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: my_helper
INFO - 2023-07-12 09:28:14 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:28:14 --> Controller Class Initialized
INFO - 2023-07-12 09:28:14 --> Config Class Initialized
INFO - 2023-07-12 09:28:14 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:28:14 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:28:14 --> Utf8 Class Initialized
INFO - 2023-07-12 09:28:14 --> URI Class Initialized
INFO - 2023-07-12 09:28:14 --> Router Class Initialized
INFO - 2023-07-12 09:28:14 --> Output Class Initialized
INFO - 2023-07-12 09:28:14 --> Security Class Initialized
DEBUG - 2023-07-12 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:28:14 --> Input Class Initialized
INFO - 2023-07-12 09:28:14 --> Language Class Initialized
INFO - 2023-07-12 09:28:14 --> Language Class Initialized
INFO - 2023-07-12 09:28:14 --> Config Class Initialized
INFO - 2023-07-12 09:28:14 --> Loader Class Initialized
INFO - 2023-07-12 09:28:14 --> Helper loaded: url_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: file_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: form_helper
INFO - 2023-07-12 09:28:14 --> Helper loaded: my_helper
INFO - 2023-07-12 09:28:14 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:28:14 --> Controller Class Initialized
DEBUG - 2023-07-12 09:28:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-12 09:28:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:28:14 --> Final output sent to browser
DEBUG - 2023-07-12 09:28:14 --> Total execution time: 0.0605
INFO - 2023-07-12 09:28:19 --> Config Class Initialized
INFO - 2023-07-12 09:28:19 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:28:19 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:28:19 --> Utf8 Class Initialized
INFO - 2023-07-12 09:28:19 --> URI Class Initialized
INFO - 2023-07-12 09:28:19 --> Router Class Initialized
INFO - 2023-07-12 09:28:19 --> Output Class Initialized
INFO - 2023-07-12 09:28:19 --> Security Class Initialized
DEBUG - 2023-07-12 09:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:28:19 --> Input Class Initialized
INFO - 2023-07-12 09:28:19 --> Language Class Initialized
INFO - 2023-07-12 09:28:19 --> Language Class Initialized
INFO - 2023-07-12 09:28:19 --> Config Class Initialized
INFO - 2023-07-12 09:28:19 --> Loader Class Initialized
INFO - 2023-07-12 09:28:19 --> Helper loaded: url_helper
INFO - 2023-07-12 09:28:19 --> Helper loaded: file_helper
INFO - 2023-07-12 09:28:19 --> Helper loaded: form_helper
INFO - 2023-07-12 09:28:19 --> Helper loaded: my_helper
INFO - 2023-07-12 09:28:19 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:28:19 --> Controller Class Initialized
INFO - 2023-07-12 09:28:19 --> Helper loaded: cookie_helper
INFO - 2023-07-12 09:28:19 --> Final output sent to browser
DEBUG - 2023-07-12 09:28:19 --> Total execution time: 0.0484
INFO - 2023-07-12 09:28:19 --> Config Class Initialized
INFO - 2023-07-12 09:28:19 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:28:19 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:28:19 --> Utf8 Class Initialized
INFO - 2023-07-12 09:28:19 --> URI Class Initialized
INFO - 2023-07-12 09:28:19 --> Router Class Initialized
INFO - 2023-07-12 09:28:19 --> Output Class Initialized
INFO - 2023-07-12 09:28:19 --> Security Class Initialized
DEBUG - 2023-07-12 09:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:28:19 --> Input Class Initialized
INFO - 2023-07-12 09:28:19 --> Language Class Initialized
INFO - 2023-07-12 09:28:19 --> Language Class Initialized
INFO - 2023-07-12 09:28:19 --> Config Class Initialized
INFO - 2023-07-12 09:28:19 --> Loader Class Initialized
INFO - 2023-07-12 09:28:19 --> Helper loaded: url_helper
INFO - 2023-07-12 09:28:19 --> Helper loaded: file_helper
INFO - 2023-07-12 09:28:19 --> Helper loaded: form_helper
INFO - 2023-07-12 09:28:19 --> Helper loaded: my_helper
INFO - 2023-07-12 09:28:19 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:28:19 --> Controller Class Initialized
DEBUG - 2023-07-12 09:28:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-12 09:28:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:28:19 --> Final output sent to browser
DEBUG - 2023-07-12 09:28:19 --> Total execution time: 0.0522
INFO - 2023-07-12 09:28:56 --> Config Class Initialized
INFO - 2023-07-12 09:28:56 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:28:56 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:28:56 --> Utf8 Class Initialized
INFO - 2023-07-12 09:28:56 --> URI Class Initialized
INFO - 2023-07-12 09:28:56 --> Router Class Initialized
INFO - 2023-07-12 09:28:56 --> Output Class Initialized
INFO - 2023-07-12 09:28:56 --> Security Class Initialized
DEBUG - 2023-07-12 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:28:56 --> Input Class Initialized
INFO - 2023-07-12 09:28:56 --> Language Class Initialized
INFO - 2023-07-12 09:28:56 --> Language Class Initialized
INFO - 2023-07-12 09:28:56 --> Config Class Initialized
INFO - 2023-07-12 09:28:56 --> Loader Class Initialized
INFO - 2023-07-12 09:28:56 --> Helper loaded: url_helper
INFO - 2023-07-12 09:28:56 --> Helper loaded: file_helper
INFO - 2023-07-12 09:28:56 --> Helper loaded: form_helper
INFO - 2023-07-12 09:28:56 --> Helper loaded: my_helper
INFO - 2023-07-12 09:28:56 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:28:56 --> Controller Class Initialized
DEBUG - 2023-07-12 09:28:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_absensi/views/list.php
DEBUG - 2023-07-12 09:28:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:28:56 --> Final output sent to browser
DEBUG - 2023-07-12 09:28:56 --> Total execution time: 0.1218
INFO - 2023-07-12 09:29:43 --> Config Class Initialized
INFO - 2023-07-12 09:29:43 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:29:43 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:29:43 --> Utf8 Class Initialized
INFO - 2023-07-12 09:29:43 --> URI Class Initialized
INFO - 2023-07-12 09:29:43 --> Router Class Initialized
INFO - 2023-07-12 09:29:43 --> Output Class Initialized
INFO - 2023-07-12 09:29:43 --> Security Class Initialized
DEBUG - 2023-07-12 09:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:29:43 --> Input Class Initialized
INFO - 2023-07-12 09:29:43 --> Language Class Initialized
INFO - 2023-07-12 09:29:43 --> Language Class Initialized
INFO - 2023-07-12 09:29:43 --> Config Class Initialized
INFO - 2023-07-12 09:29:43 --> Loader Class Initialized
INFO - 2023-07-12 09:29:43 --> Helper loaded: url_helper
INFO - 2023-07-12 09:29:43 --> Helper loaded: file_helper
INFO - 2023-07-12 09:29:43 --> Helper loaded: form_helper
INFO - 2023-07-12 09:29:43 --> Helper loaded: my_helper
INFO - 2023-07-12 09:29:43 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:29:43 --> Controller Class Initialized
DEBUG - 2023-07-12 09:29:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-12 09:29:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:29:43 --> Final output sent to browser
DEBUG - 2023-07-12 09:29:43 --> Total execution time: 0.1290
INFO - 2023-07-12 09:31:03 --> Config Class Initialized
INFO - 2023-07-12 09:31:03 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:31:03 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:31:03 --> Utf8 Class Initialized
INFO - 2023-07-12 09:31:03 --> URI Class Initialized
INFO - 2023-07-12 09:31:03 --> Router Class Initialized
INFO - 2023-07-12 09:31:03 --> Output Class Initialized
INFO - 2023-07-12 09:31:03 --> Security Class Initialized
DEBUG - 2023-07-12 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:31:03 --> Input Class Initialized
INFO - 2023-07-12 09:31:03 --> Language Class Initialized
INFO - 2023-07-12 09:31:03 --> Language Class Initialized
INFO - 2023-07-12 09:31:03 --> Config Class Initialized
INFO - 2023-07-12 09:31:03 --> Loader Class Initialized
INFO - 2023-07-12 09:31:03 --> Helper loaded: url_helper
INFO - 2023-07-12 09:31:03 --> Helper loaded: file_helper
INFO - 2023-07-12 09:31:03 --> Helper loaded: form_helper
INFO - 2023-07-12 09:31:03 --> Helper loaded: my_helper
INFO - 2023-07-12 09:31:03 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:31:03 --> Controller Class Initialized
INFO - 2023-07-12 09:31:03 --> Final output sent to browser
DEBUG - 2023-07-12 09:31:03 --> Total execution time: 0.0542
INFO - 2023-07-12 09:31:51 --> Config Class Initialized
INFO - 2023-07-12 09:31:51 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:31:51 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:31:51 --> Utf8 Class Initialized
INFO - 2023-07-12 09:31:51 --> URI Class Initialized
INFO - 2023-07-12 09:31:51 --> Router Class Initialized
INFO - 2023-07-12 09:31:51 --> Output Class Initialized
INFO - 2023-07-12 09:31:51 --> Security Class Initialized
DEBUG - 2023-07-12 09:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:31:51 --> Input Class Initialized
INFO - 2023-07-12 09:31:51 --> Language Class Initialized
INFO - 2023-07-12 09:31:51 --> Language Class Initialized
INFO - 2023-07-12 09:31:51 --> Config Class Initialized
INFO - 2023-07-12 09:31:51 --> Loader Class Initialized
INFO - 2023-07-12 09:31:51 --> Helper loaded: url_helper
INFO - 2023-07-12 09:31:51 --> Helper loaded: file_helper
INFO - 2023-07-12 09:31:51 --> Helper loaded: form_helper
INFO - 2023-07-12 09:31:51 --> Helper loaded: my_helper
INFO - 2023-07-12 09:31:51 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:31:51 --> Controller Class Initialized
DEBUG - 2023-07-12 09:31:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_prestasi/views/list.php
DEBUG - 2023-07-12 09:31:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:31:51 --> Final output sent to browser
DEBUG - 2023-07-12 09:31:51 --> Total execution time: 0.1112
INFO - 2023-07-12 09:31:51 --> Config Class Initialized
INFO - 2023-07-12 09:31:51 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:31:51 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:31:51 --> Utf8 Class Initialized
INFO - 2023-07-12 09:31:51 --> URI Class Initialized
INFO - 2023-07-12 09:31:51 --> Router Class Initialized
INFO - 2023-07-12 09:31:51 --> Output Class Initialized
INFO - 2023-07-12 09:31:51 --> Security Class Initialized
DEBUG - 2023-07-12 09:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:31:51 --> Input Class Initialized
INFO - 2023-07-12 09:31:51 --> Language Class Initialized
INFO - 2023-07-12 09:31:51 --> Language Class Initialized
INFO - 2023-07-12 09:31:51 --> Config Class Initialized
INFO - 2023-07-12 09:31:51 --> Loader Class Initialized
INFO - 2023-07-12 09:31:51 --> Helper loaded: url_helper
INFO - 2023-07-12 09:31:51 --> Helper loaded: file_helper
INFO - 2023-07-12 09:31:51 --> Helper loaded: form_helper
INFO - 2023-07-12 09:31:51 --> Helper loaded: my_helper
INFO - 2023-07-12 09:31:51 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:31:51 --> Controller Class Initialized
INFO - 2023-07-12 09:32:42 --> Config Class Initialized
INFO - 2023-07-12 09:32:42 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:32:42 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:32:42 --> Utf8 Class Initialized
INFO - 2023-07-12 09:32:42 --> URI Class Initialized
INFO - 2023-07-12 09:32:42 --> Router Class Initialized
INFO - 2023-07-12 09:32:42 --> Output Class Initialized
INFO - 2023-07-12 09:32:42 --> Security Class Initialized
DEBUG - 2023-07-12 09:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:32:42 --> Input Class Initialized
INFO - 2023-07-12 09:32:42 --> Language Class Initialized
INFO - 2023-07-12 09:32:42 --> Language Class Initialized
INFO - 2023-07-12 09:32:42 --> Config Class Initialized
INFO - 2023-07-12 09:32:42 --> Loader Class Initialized
INFO - 2023-07-12 09:32:42 --> Helper loaded: url_helper
INFO - 2023-07-12 09:32:42 --> Helper loaded: file_helper
INFO - 2023-07-12 09:32:42 --> Helper loaded: form_helper
INFO - 2023-07-12 09:32:42 --> Helper loaded: my_helper
INFO - 2023-07-12 09:32:42 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:32:42 --> Controller Class Initialized
DEBUG - 2023-07-12 09:32:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan/views/list.php
DEBUG - 2023-07-12 09:32:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:32:42 --> Final output sent to browser
DEBUG - 2023-07-12 09:32:42 --> Total execution time: 0.1435
INFO - 2023-07-12 09:34:06 --> Config Class Initialized
INFO - 2023-07-12 09:34:06 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:34:06 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:34:06 --> Utf8 Class Initialized
INFO - 2023-07-12 09:34:06 --> URI Class Initialized
INFO - 2023-07-12 09:34:06 --> Router Class Initialized
INFO - 2023-07-12 09:34:06 --> Output Class Initialized
INFO - 2023-07-12 09:34:06 --> Security Class Initialized
DEBUG - 2023-07-12 09:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:34:06 --> Input Class Initialized
INFO - 2023-07-12 09:34:06 --> Language Class Initialized
INFO - 2023-07-12 09:34:06 --> Language Class Initialized
INFO - 2023-07-12 09:34:06 --> Config Class Initialized
INFO - 2023-07-12 09:34:06 --> Loader Class Initialized
INFO - 2023-07-12 09:34:06 --> Helper loaded: url_helper
INFO - 2023-07-12 09:34:06 --> Helper loaded: file_helper
INFO - 2023-07-12 09:34:06 --> Helper loaded: form_helper
INFO - 2023-07-12 09:34:06 --> Helper loaded: my_helper
INFO - 2023-07-12 09:34:06 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:34:06 --> Controller Class Initialized
DEBUG - 2023-07-12 09:34:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-07-12 09:34:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:34:06 --> Final output sent to browser
DEBUG - 2023-07-12 09:34:06 --> Total execution time: 0.1460
INFO - 2023-07-12 09:35:39 --> Config Class Initialized
INFO - 2023-07-12 09:35:39 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:35:39 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:35:39 --> Utf8 Class Initialized
INFO - 2023-07-12 09:35:39 --> URI Class Initialized
INFO - 2023-07-12 09:35:39 --> Router Class Initialized
INFO - 2023-07-12 09:35:39 --> Output Class Initialized
INFO - 2023-07-12 09:35:39 --> Security Class Initialized
DEBUG - 2023-07-12 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:35:39 --> Input Class Initialized
INFO - 2023-07-12 09:35:39 --> Language Class Initialized
INFO - 2023-07-12 09:35:39 --> Language Class Initialized
INFO - 2023-07-12 09:35:39 --> Config Class Initialized
INFO - 2023-07-12 09:35:39 --> Loader Class Initialized
INFO - 2023-07-12 09:35:39 --> Helper loaded: url_helper
INFO - 2023-07-12 09:35:39 --> Helper loaded: file_helper
INFO - 2023-07-12 09:35:39 --> Helper loaded: form_helper
INFO - 2023-07-12 09:35:39 --> Helper loaded: my_helper
INFO - 2023-07-12 09:35:39 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:35:39 --> Controller Class Initialized
DEBUG - 2023-07-12 09:35:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-12 09:35:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:35:39 --> Final output sent to browser
DEBUG - 2023-07-12 09:35:39 --> Total execution time: 0.1349
INFO - 2023-07-12 09:35:43 --> Config Class Initialized
INFO - 2023-07-12 09:35:43 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:35:43 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:35:43 --> Utf8 Class Initialized
INFO - 2023-07-12 09:35:43 --> URI Class Initialized
INFO - 2023-07-12 09:35:43 --> Router Class Initialized
INFO - 2023-07-12 09:35:43 --> Output Class Initialized
INFO - 2023-07-12 09:35:43 --> Security Class Initialized
DEBUG - 2023-07-12 09:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:35:43 --> Input Class Initialized
INFO - 2023-07-12 09:35:43 --> Language Class Initialized
INFO - 2023-07-12 09:35:43 --> Language Class Initialized
INFO - 2023-07-12 09:35:43 --> Config Class Initialized
INFO - 2023-07-12 09:35:43 --> Loader Class Initialized
INFO - 2023-07-12 09:35:43 --> Helper loaded: url_helper
INFO - 2023-07-12 09:35:43 --> Helper loaded: file_helper
INFO - 2023-07-12 09:35:43 --> Helper loaded: form_helper
INFO - 2023-07-12 09:35:43 --> Helper loaded: my_helper
INFO - 2023-07-12 09:35:43 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:35:43 --> Controller Class Initialized
DEBUG - 2023-07-12 09:35:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-12 09:35:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:35:43 --> Final output sent to browser
DEBUG - 2023-07-12 09:35:43 --> Total execution time: 0.0511
INFO - 2023-07-12 09:35:59 --> Config Class Initialized
INFO - 2023-07-12 09:35:59 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:35:59 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:35:59 --> Utf8 Class Initialized
INFO - 2023-07-12 09:35:59 --> URI Class Initialized
INFO - 2023-07-12 09:35:59 --> Router Class Initialized
INFO - 2023-07-12 09:35:59 --> Output Class Initialized
INFO - 2023-07-12 09:35:59 --> Security Class Initialized
DEBUG - 2023-07-12 09:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:35:59 --> Input Class Initialized
INFO - 2023-07-12 09:35:59 --> Language Class Initialized
INFO - 2023-07-12 09:35:59 --> Language Class Initialized
INFO - 2023-07-12 09:35:59 --> Config Class Initialized
INFO - 2023-07-12 09:35:59 --> Loader Class Initialized
INFO - 2023-07-12 09:35:59 --> Helper loaded: url_helper
INFO - 2023-07-12 09:35:59 --> Helper loaded: file_helper
INFO - 2023-07-12 09:35:59 --> Helper loaded: form_helper
INFO - 2023-07-12 09:35:59 --> Helper loaded: my_helper
INFO - 2023-07-12 09:35:59 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:35:59 --> Controller Class Initialized
DEBUG - 2023-07-12 09:35:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-12 09:35:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:35:59 --> Final output sent to browser
DEBUG - 2023-07-12 09:35:59 --> Total execution time: 0.0674
INFO - 2023-07-12 09:36:26 --> Config Class Initialized
INFO - 2023-07-12 09:36:26 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:36:26 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:36:26 --> Utf8 Class Initialized
INFO - 2023-07-12 09:36:26 --> URI Class Initialized
INFO - 2023-07-12 09:36:26 --> Router Class Initialized
INFO - 2023-07-12 09:36:26 --> Output Class Initialized
INFO - 2023-07-12 09:36:26 --> Security Class Initialized
DEBUG - 2023-07-12 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:36:26 --> Input Class Initialized
INFO - 2023-07-12 09:36:26 --> Language Class Initialized
INFO - 2023-07-12 09:36:26 --> Language Class Initialized
INFO - 2023-07-12 09:36:26 --> Config Class Initialized
INFO - 2023-07-12 09:36:26 --> Loader Class Initialized
INFO - 2023-07-12 09:36:26 --> Helper loaded: url_helper
INFO - 2023-07-12 09:36:26 --> Helper loaded: file_helper
INFO - 2023-07-12 09:36:26 --> Helper loaded: form_helper
INFO - 2023-07-12 09:36:26 --> Helper loaded: my_helper
INFO - 2023-07-12 09:36:26 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:36:26 --> Controller Class Initialized
INFO - 2023-07-12 09:37:13 --> Config Class Initialized
INFO - 2023-07-12 09:37:13 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:37:13 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:37:13 --> Utf8 Class Initialized
INFO - 2023-07-12 09:37:13 --> URI Class Initialized
INFO - 2023-07-12 09:37:13 --> Router Class Initialized
INFO - 2023-07-12 09:37:13 --> Output Class Initialized
INFO - 2023-07-12 09:37:13 --> Security Class Initialized
DEBUG - 2023-07-12 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:37:13 --> Input Class Initialized
INFO - 2023-07-12 09:37:13 --> Language Class Initialized
INFO - 2023-07-12 09:37:13 --> Language Class Initialized
INFO - 2023-07-12 09:37:13 --> Config Class Initialized
INFO - 2023-07-12 09:37:13 --> Loader Class Initialized
INFO - 2023-07-12 09:37:13 --> Helper loaded: url_helper
INFO - 2023-07-12 09:37:13 --> Helper loaded: file_helper
INFO - 2023-07-12 09:37:13 --> Helper loaded: form_helper
INFO - 2023-07-12 09:37:13 --> Helper loaded: my_helper
INFO - 2023-07-12 09:37:13 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:37:13 --> Controller Class Initialized
DEBUG - 2023-07-12 09:37:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-07-12 09:37:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:37:13 --> Final output sent to browser
DEBUG - 2023-07-12 09:37:13 --> Total execution time: 0.1499
INFO - 2023-07-12 09:37:19 --> Config Class Initialized
INFO - 2023-07-12 09:37:19 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:37:19 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:37:19 --> Utf8 Class Initialized
INFO - 2023-07-12 09:37:19 --> URI Class Initialized
INFO - 2023-07-12 09:37:19 --> Router Class Initialized
INFO - 2023-07-12 09:37:19 --> Output Class Initialized
INFO - 2023-07-12 09:37:19 --> Security Class Initialized
DEBUG - 2023-07-12 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:37:19 --> Input Class Initialized
INFO - 2023-07-12 09:37:19 --> Language Class Initialized
INFO - 2023-07-12 09:37:19 --> Language Class Initialized
INFO - 2023-07-12 09:37:19 --> Config Class Initialized
INFO - 2023-07-12 09:37:19 --> Loader Class Initialized
INFO - 2023-07-12 09:37:19 --> Helper loaded: url_helper
INFO - 2023-07-12 09:37:19 --> Helper loaded: file_helper
INFO - 2023-07-12 09:37:19 --> Helper loaded: form_helper
INFO - 2023-07-12 09:37:19 --> Helper loaded: my_helper
INFO - 2023-07-12 09:37:19 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:37:19 --> Controller Class Initialized
DEBUG - 2023-07-12 09:37:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-07-12 09:37:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:37:19 --> Final output sent to browser
DEBUG - 2023-07-12 09:37:19 --> Total execution time: 0.1245
INFO - 2023-07-12 09:37:32 --> Config Class Initialized
INFO - 2023-07-12 09:37:32 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:37:32 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:37:32 --> Utf8 Class Initialized
INFO - 2023-07-12 09:37:32 --> URI Class Initialized
INFO - 2023-07-12 09:37:32 --> Router Class Initialized
INFO - 2023-07-12 09:37:32 --> Output Class Initialized
INFO - 2023-07-12 09:37:32 --> Security Class Initialized
DEBUG - 2023-07-12 09:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:37:32 --> Input Class Initialized
INFO - 2023-07-12 09:37:32 --> Language Class Initialized
INFO - 2023-07-12 09:37:32 --> Language Class Initialized
INFO - 2023-07-12 09:37:32 --> Config Class Initialized
INFO - 2023-07-12 09:37:32 --> Loader Class Initialized
INFO - 2023-07-12 09:37:32 --> Helper loaded: url_helper
INFO - 2023-07-12 09:37:32 --> Helper loaded: file_helper
INFO - 2023-07-12 09:37:32 --> Helper loaded: form_helper
INFO - 2023-07-12 09:37:32 --> Helper loaded: my_helper
INFO - 2023-07-12 09:37:32 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:37:32 --> Controller Class Initialized
INFO - 2023-07-12 09:37:32 --> Final output sent to browser
DEBUG - 2023-07-12 09:37:32 --> Total execution time: 0.0479
INFO - 2023-07-12 09:37:35 --> Config Class Initialized
INFO - 2023-07-12 09:37:35 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:37:35 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:37:35 --> Utf8 Class Initialized
INFO - 2023-07-12 09:37:35 --> URI Class Initialized
INFO - 2023-07-12 09:37:35 --> Router Class Initialized
INFO - 2023-07-12 09:37:35 --> Output Class Initialized
INFO - 2023-07-12 09:37:35 --> Security Class Initialized
DEBUG - 2023-07-12 09:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:37:35 --> Input Class Initialized
INFO - 2023-07-12 09:37:35 --> Language Class Initialized
INFO - 2023-07-12 09:37:35 --> Language Class Initialized
INFO - 2023-07-12 09:37:35 --> Config Class Initialized
INFO - 2023-07-12 09:37:35 --> Loader Class Initialized
INFO - 2023-07-12 09:37:35 --> Helper loaded: url_helper
INFO - 2023-07-12 09:37:35 --> Helper loaded: file_helper
INFO - 2023-07-12 09:37:35 --> Helper loaded: form_helper
INFO - 2023-07-12 09:37:35 --> Helper loaded: my_helper
INFO - 2023-07-12 09:37:35 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:37:35 --> Controller Class Initialized
DEBUG - 2023-07-12 09:37:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-07-12 09:37:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:37:35 --> Final output sent to browser
DEBUG - 2023-07-12 09:37:35 --> Total execution time: 0.0754
INFO - 2023-07-12 09:38:04 --> Config Class Initialized
INFO - 2023-07-12 09:38:04 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:38:04 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:38:04 --> Utf8 Class Initialized
INFO - 2023-07-12 09:38:04 --> URI Class Initialized
INFO - 2023-07-12 09:38:04 --> Router Class Initialized
INFO - 2023-07-12 09:38:04 --> Output Class Initialized
INFO - 2023-07-12 09:38:04 --> Security Class Initialized
DEBUG - 2023-07-12 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:38:04 --> Input Class Initialized
INFO - 2023-07-12 09:38:04 --> Language Class Initialized
INFO - 2023-07-12 09:38:04 --> Language Class Initialized
INFO - 2023-07-12 09:38:04 --> Config Class Initialized
INFO - 2023-07-12 09:38:04 --> Loader Class Initialized
INFO - 2023-07-12 09:38:04 --> Helper loaded: url_helper
INFO - 2023-07-12 09:38:04 --> Helper loaded: file_helper
INFO - 2023-07-12 09:38:04 --> Helper loaded: form_helper
INFO - 2023-07-12 09:38:04 --> Helper loaded: my_helper
INFO - 2023-07-12 09:38:04 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:38:04 --> Controller Class Initialized
DEBUG - 2023-07-12 09:38:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-07-12 09:38:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:38:04 --> Final output sent to browser
DEBUG - 2023-07-12 09:38:04 --> Total execution time: 0.1180
INFO - 2023-07-12 09:38:11 --> Config Class Initialized
INFO - 2023-07-12 09:38:11 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:38:11 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:38:11 --> Utf8 Class Initialized
INFO - 2023-07-12 09:38:11 --> URI Class Initialized
INFO - 2023-07-12 09:38:11 --> Router Class Initialized
INFO - 2023-07-12 09:38:11 --> Output Class Initialized
INFO - 2023-07-12 09:38:11 --> Security Class Initialized
DEBUG - 2023-07-12 09:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:38:11 --> Input Class Initialized
INFO - 2023-07-12 09:38:11 --> Language Class Initialized
INFO - 2023-07-12 09:38:11 --> Language Class Initialized
INFO - 2023-07-12 09:38:11 --> Config Class Initialized
INFO - 2023-07-12 09:38:11 --> Loader Class Initialized
INFO - 2023-07-12 09:38:11 --> Helper loaded: url_helper
INFO - 2023-07-12 09:38:11 --> Helper loaded: file_helper
INFO - 2023-07-12 09:38:11 --> Helper loaded: form_helper
INFO - 2023-07-12 09:38:11 --> Helper loaded: my_helper
INFO - 2023-07-12 09:38:11 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:38:11 --> Controller Class Initialized
DEBUG - 2023-07-12 09:38:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-07-12 09:38:13 --> Final output sent to browser
DEBUG - 2023-07-12 09:38:13 --> Total execution time: 2.9490
INFO - 2023-07-12 09:38:21 --> Config Class Initialized
INFO - 2023-07-12 09:38:21 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:38:21 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:38:21 --> Utf8 Class Initialized
INFO - 2023-07-12 09:38:21 --> URI Class Initialized
INFO - 2023-07-12 09:38:21 --> Router Class Initialized
INFO - 2023-07-12 09:38:21 --> Output Class Initialized
INFO - 2023-07-12 09:38:21 --> Security Class Initialized
DEBUG - 2023-07-12 09:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:38:21 --> Input Class Initialized
INFO - 2023-07-12 09:38:21 --> Language Class Initialized
INFO - 2023-07-12 09:38:21 --> Language Class Initialized
INFO - 2023-07-12 09:38:21 --> Config Class Initialized
INFO - 2023-07-12 09:38:21 --> Loader Class Initialized
INFO - 2023-07-12 09:38:21 --> Helper loaded: url_helper
INFO - 2023-07-12 09:38:21 --> Helper loaded: file_helper
INFO - 2023-07-12 09:38:21 --> Helper loaded: form_helper
INFO - 2023-07-12 09:38:21 --> Helper loaded: my_helper
INFO - 2023-07-12 09:38:21 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:38:21 --> Controller Class Initialized
DEBUG - 2023-07-12 09:38:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-07-12 09:38:22 --> Final output sent to browser
DEBUG - 2023-07-12 09:38:22 --> Total execution time: 0.8580
INFO - 2023-07-12 09:38:52 --> Config Class Initialized
INFO - 2023-07-12 09:38:52 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:38:52 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:38:52 --> Utf8 Class Initialized
INFO - 2023-07-12 09:38:52 --> URI Class Initialized
INFO - 2023-07-12 09:38:52 --> Router Class Initialized
INFO - 2023-07-12 09:38:52 --> Output Class Initialized
INFO - 2023-07-12 09:38:52 --> Security Class Initialized
DEBUG - 2023-07-12 09:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:38:52 --> Input Class Initialized
INFO - 2023-07-12 09:38:52 --> Language Class Initialized
INFO - 2023-07-12 09:38:52 --> Language Class Initialized
INFO - 2023-07-12 09:38:52 --> Config Class Initialized
INFO - 2023-07-12 09:38:52 --> Loader Class Initialized
INFO - 2023-07-12 09:38:52 --> Helper loaded: url_helper
INFO - 2023-07-12 09:38:52 --> Helper loaded: file_helper
INFO - 2023-07-12 09:38:52 --> Helper loaded: form_helper
INFO - 2023-07-12 09:38:52 --> Helper loaded: my_helper
INFO - 2023-07-12 09:38:52 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:38:52 --> Controller Class Initialized
DEBUG - 2023-07-12 09:38:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-07-12 09:38:53 --> Final output sent to browser
DEBUG - 2023-07-12 09:38:53 --> Total execution time: 1.5710
INFO - 2023-07-12 09:39:41 --> Config Class Initialized
INFO - 2023-07-12 09:39:41 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:39:41 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:39:41 --> Utf8 Class Initialized
INFO - 2023-07-12 09:39:41 --> URI Class Initialized
INFO - 2023-07-12 09:39:41 --> Router Class Initialized
INFO - 2023-07-12 09:39:41 --> Output Class Initialized
INFO - 2023-07-12 09:39:41 --> Security Class Initialized
DEBUG - 2023-07-12 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:39:41 --> Input Class Initialized
INFO - 2023-07-12 09:39:41 --> Language Class Initialized
INFO - 2023-07-12 09:39:41 --> Language Class Initialized
INFO - 2023-07-12 09:39:41 --> Config Class Initialized
INFO - 2023-07-12 09:39:41 --> Loader Class Initialized
INFO - 2023-07-12 09:39:41 --> Helper loaded: url_helper
INFO - 2023-07-12 09:39:41 --> Helper loaded: file_helper
INFO - 2023-07-12 09:39:41 --> Helper loaded: form_helper
INFO - 2023-07-12 09:39:41 --> Helper loaded: my_helper
INFO - 2023-07-12 09:39:41 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:39:41 --> Controller Class Initialized
DEBUG - 2023-07-12 09:39:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-07-12 09:39:42 --> Final output sent to browser
DEBUG - 2023-07-12 09:39:42 --> Total execution time: 0.8187
INFO - 2023-07-12 09:39:59 --> Config Class Initialized
INFO - 2023-07-12 09:39:59 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:39:59 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:39:59 --> Utf8 Class Initialized
INFO - 2023-07-12 09:39:59 --> URI Class Initialized
INFO - 2023-07-12 09:39:59 --> Router Class Initialized
INFO - 2023-07-12 09:39:59 --> Output Class Initialized
INFO - 2023-07-12 09:39:59 --> Security Class Initialized
DEBUG - 2023-07-12 09:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:39:59 --> Input Class Initialized
INFO - 2023-07-12 09:39:59 --> Language Class Initialized
INFO - 2023-07-12 09:39:59 --> Language Class Initialized
INFO - 2023-07-12 09:39:59 --> Config Class Initialized
INFO - 2023-07-12 09:39:59 --> Loader Class Initialized
INFO - 2023-07-12 09:39:59 --> Helper loaded: url_helper
INFO - 2023-07-12 09:39:59 --> Helper loaded: file_helper
INFO - 2023-07-12 09:39:59 --> Helper loaded: form_helper
INFO - 2023-07-12 09:39:59 --> Helper loaded: my_helper
INFO - 2023-07-12 09:39:59 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:39:59 --> Controller Class Initialized
DEBUG - 2023-07-12 09:39:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport/views/list.php
DEBUG - 2023-07-12 09:39:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:39:59 --> Final output sent to browser
DEBUG - 2023-07-12 09:39:59 --> Total execution time: 0.1333
INFO - 2023-07-12 09:40:16 --> Config Class Initialized
INFO - 2023-07-12 09:40:16 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:40:16 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:40:16 --> Utf8 Class Initialized
INFO - 2023-07-12 09:40:16 --> URI Class Initialized
INFO - 2023-07-12 09:40:16 --> Router Class Initialized
INFO - 2023-07-12 09:40:16 --> Output Class Initialized
INFO - 2023-07-12 09:40:16 --> Security Class Initialized
DEBUG - 2023-07-12 09:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:40:16 --> Input Class Initialized
INFO - 2023-07-12 09:40:16 --> Language Class Initialized
INFO - 2023-07-12 09:40:16 --> Language Class Initialized
INFO - 2023-07-12 09:40:16 --> Config Class Initialized
INFO - 2023-07-12 09:40:16 --> Loader Class Initialized
INFO - 2023-07-12 09:40:16 --> Helper loaded: url_helper
INFO - 2023-07-12 09:40:16 --> Helper loaded: file_helper
INFO - 2023-07-12 09:40:16 --> Helper loaded: form_helper
INFO - 2023-07-12 09:40:16 --> Helper loaded: my_helper
INFO - 2023-07-12 09:40:16 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:40:16 --> Controller Class Initialized
DEBUG - 2023-07-12 09:40:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-12 09:40:18 --> Final output sent to browser
DEBUG - 2023-07-12 09:40:18 --> Total execution time: 1.7853
INFO - 2023-07-12 09:47:04 --> Config Class Initialized
INFO - 2023-07-12 09:47:04 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:47:04 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:47:04 --> Utf8 Class Initialized
INFO - 2023-07-12 09:47:04 --> URI Class Initialized
INFO - 2023-07-12 09:47:04 --> Router Class Initialized
INFO - 2023-07-12 09:47:04 --> Output Class Initialized
INFO - 2023-07-12 09:47:04 --> Security Class Initialized
DEBUG - 2023-07-12 09:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:47:04 --> Input Class Initialized
INFO - 2023-07-12 09:47:04 --> Language Class Initialized
INFO - 2023-07-12 09:47:04 --> Language Class Initialized
INFO - 2023-07-12 09:47:04 --> Config Class Initialized
INFO - 2023-07-12 09:47:04 --> Loader Class Initialized
INFO - 2023-07-12 09:47:04 --> Helper loaded: url_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: file_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: form_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: my_helper
INFO - 2023-07-12 09:47:04 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:47:04 --> Controller Class Initialized
INFO - 2023-07-12 09:47:04 --> Helper loaded: cookie_helper
INFO - 2023-07-12 09:47:04 --> Config Class Initialized
INFO - 2023-07-12 09:47:04 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:47:04 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:47:04 --> Utf8 Class Initialized
INFO - 2023-07-12 09:47:04 --> URI Class Initialized
INFO - 2023-07-12 09:47:04 --> Router Class Initialized
INFO - 2023-07-12 09:47:04 --> Output Class Initialized
INFO - 2023-07-12 09:47:04 --> Security Class Initialized
DEBUG - 2023-07-12 09:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:47:04 --> Input Class Initialized
INFO - 2023-07-12 09:47:04 --> Language Class Initialized
INFO - 2023-07-12 09:47:04 --> Language Class Initialized
INFO - 2023-07-12 09:47:04 --> Config Class Initialized
INFO - 2023-07-12 09:47:04 --> Loader Class Initialized
INFO - 2023-07-12 09:47:04 --> Helper loaded: url_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: file_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: form_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: my_helper
INFO - 2023-07-12 09:47:04 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:47:04 --> Controller Class Initialized
INFO - 2023-07-12 09:47:04 --> Config Class Initialized
INFO - 2023-07-12 09:47:04 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:47:04 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:47:04 --> Utf8 Class Initialized
INFO - 2023-07-12 09:47:04 --> URI Class Initialized
INFO - 2023-07-12 09:47:04 --> Router Class Initialized
INFO - 2023-07-12 09:47:04 --> Output Class Initialized
INFO - 2023-07-12 09:47:04 --> Security Class Initialized
DEBUG - 2023-07-12 09:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:47:04 --> Input Class Initialized
INFO - 2023-07-12 09:47:04 --> Language Class Initialized
INFO - 2023-07-12 09:47:04 --> Language Class Initialized
INFO - 2023-07-12 09:47:04 --> Config Class Initialized
INFO - 2023-07-12 09:47:04 --> Loader Class Initialized
INFO - 2023-07-12 09:47:04 --> Helper loaded: url_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: file_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: form_helper
INFO - 2023-07-12 09:47:04 --> Helper loaded: my_helper
INFO - 2023-07-12 09:47:04 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:47:04 --> Controller Class Initialized
DEBUG - 2023-07-12 09:47:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-12 09:47:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:47:04 --> Final output sent to browser
DEBUG - 2023-07-12 09:47:04 --> Total execution time: 0.0466
INFO - 2023-07-12 09:47:32 --> Config Class Initialized
INFO - 2023-07-12 09:47:32 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:47:32 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:47:32 --> Utf8 Class Initialized
INFO - 2023-07-12 09:47:32 --> URI Class Initialized
DEBUG - 2023-07-12 09:47:32 --> No URI present. Default controller set.
INFO - 2023-07-12 09:47:32 --> Router Class Initialized
INFO - 2023-07-12 09:47:32 --> Output Class Initialized
INFO - 2023-07-12 09:47:33 --> Security Class Initialized
DEBUG - 2023-07-12 09:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:47:33 --> Input Class Initialized
INFO - 2023-07-12 09:47:33 --> Language Class Initialized
INFO - 2023-07-12 09:47:33 --> Language Class Initialized
INFO - 2023-07-12 09:47:33 --> Config Class Initialized
INFO - 2023-07-12 09:47:33 --> Loader Class Initialized
INFO - 2023-07-12 09:47:33 --> Helper loaded: url_helper
INFO - 2023-07-12 09:47:33 --> Helper loaded: file_helper
INFO - 2023-07-12 09:47:33 --> Helper loaded: form_helper
INFO - 2023-07-12 09:47:33 --> Helper loaded: my_helper
INFO - 2023-07-12 09:47:33 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:47:33 --> Controller Class Initialized
INFO - 2023-07-12 09:47:33 --> Config Class Initialized
INFO - 2023-07-12 09:47:33 --> Hooks Class Initialized
DEBUG - 2023-07-12 09:47:33 --> UTF-8 Support Enabled
INFO - 2023-07-12 09:47:33 --> Utf8 Class Initialized
INFO - 2023-07-12 09:47:33 --> URI Class Initialized
INFO - 2023-07-12 09:47:33 --> Router Class Initialized
INFO - 2023-07-12 09:47:33 --> Output Class Initialized
INFO - 2023-07-12 09:47:33 --> Security Class Initialized
DEBUG - 2023-07-12 09:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-12 09:47:33 --> Input Class Initialized
INFO - 2023-07-12 09:47:33 --> Language Class Initialized
INFO - 2023-07-12 09:47:33 --> Language Class Initialized
INFO - 2023-07-12 09:47:33 --> Config Class Initialized
INFO - 2023-07-12 09:47:33 --> Loader Class Initialized
INFO - 2023-07-12 09:47:33 --> Helper loaded: url_helper
INFO - 2023-07-12 09:47:33 --> Helper loaded: file_helper
INFO - 2023-07-12 09:47:33 --> Helper loaded: form_helper
INFO - 2023-07-12 09:47:33 --> Helper loaded: my_helper
INFO - 2023-07-12 09:47:33 --> Database Driver Class Initialized
DEBUG - 2023-07-12 09:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-12 09:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-12 09:47:33 --> Controller Class Initialized
DEBUG - 2023-07-12 09:47:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-12 09:47:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-12 09:47:33 --> Final output sent to browser
DEBUG - 2023-07-12 09:47:33 --> Total execution time: 0.0419
