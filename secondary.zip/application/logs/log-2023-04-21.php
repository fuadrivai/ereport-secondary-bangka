<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-21 05:39:17 --> Config Class Initialized
INFO - 2023-04-21 05:39:17 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:39:18 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:39:18 --> Utf8 Class Initialized
INFO - 2023-04-21 05:39:18 --> URI Class Initialized
DEBUG - 2023-04-21 05:39:18 --> No URI present. Default controller set.
INFO - 2023-04-21 05:39:18 --> Router Class Initialized
INFO - 2023-04-21 05:39:18 --> Output Class Initialized
INFO - 2023-04-21 05:39:18 --> Security Class Initialized
DEBUG - 2023-04-21 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:39:18 --> Input Class Initialized
INFO - 2023-04-21 05:39:18 --> Language Class Initialized
INFO - 2023-04-21 05:39:18 --> Language Class Initialized
INFO - 2023-04-21 05:39:18 --> Config Class Initialized
INFO - 2023-04-21 05:39:18 --> Loader Class Initialized
INFO - 2023-04-21 05:39:18 --> Helper loaded: url_helper
INFO - 2023-04-21 05:39:18 --> Helper loaded: file_helper
INFO - 2023-04-21 05:39:18 --> Helper loaded: form_helper
INFO - 2023-04-21 05:39:18 --> Helper loaded: my_helper
INFO - 2023-04-21 05:39:18 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:39:18 --> Controller Class Initialized
INFO - 2023-04-21 05:39:18 --> Config Class Initialized
INFO - 2023-04-21 05:39:18 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:39:18 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:39:18 --> Utf8 Class Initialized
INFO - 2023-04-21 05:39:18 --> URI Class Initialized
INFO - 2023-04-21 05:39:18 --> Router Class Initialized
INFO - 2023-04-21 05:39:18 --> Output Class Initialized
INFO - 2023-04-21 05:39:18 --> Security Class Initialized
DEBUG - 2023-04-21 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:39:18 --> Input Class Initialized
INFO - 2023-04-21 05:39:18 --> Language Class Initialized
INFO - 2023-04-21 05:39:18 --> Language Class Initialized
INFO - 2023-04-21 05:39:18 --> Config Class Initialized
INFO - 2023-04-21 05:39:18 --> Loader Class Initialized
INFO - 2023-04-21 05:39:18 --> Helper loaded: url_helper
INFO - 2023-04-21 05:39:18 --> Helper loaded: file_helper
INFO - 2023-04-21 05:39:18 --> Helper loaded: form_helper
INFO - 2023-04-21 05:39:18 --> Helper loaded: my_helper
INFO - 2023-04-21 05:39:18 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:39:18 --> Controller Class Initialized
DEBUG - 2023-04-21 05:39:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-21 05:39:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:39:18 --> Final output sent to browser
DEBUG - 2023-04-21 05:39:18 --> Total execution time: 0.1088
INFO - 2023-04-21 05:39:27 --> Config Class Initialized
INFO - 2023-04-21 05:39:27 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:39:27 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:39:27 --> Utf8 Class Initialized
INFO - 2023-04-21 05:39:27 --> URI Class Initialized
INFO - 2023-04-21 05:39:27 --> Router Class Initialized
INFO - 2023-04-21 05:39:27 --> Output Class Initialized
INFO - 2023-04-21 05:39:27 --> Security Class Initialized
DEBUG - 2023-04-21 05:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:39:27 --> Input Class Initialized
INFO - 2023-04-21 05:39:27 --> Language Class Initialized
INFO - 2023-04-21 05:39:27 --> Language Class Initialized
INFO - 2023-04-21 05:39:27 --> Config Class Initialized
INFO - 2023-04-21 05:39:27 --> Loader Class Initialized
INFO - 2023-04-21 05:39:27 --> Helper loaded: url_helper
INFO - 2023-04-21 05:39:27 --> Helper loaded: file_helper
INFO - 2023-04-21 05:39:27 --> Helper loaded: form_helper
INFO - 2023-04-21 05:39:27 --> Helper loaded: my_helper
INFO - 2023-04-21 05:39:27 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:39:27 --> Controller Class Initialized
INFO - 2023-04-21 05:39:27 --> Helper loaded: cookie_helper
INFO - 2023-04-21 05:39:27 --> Final output sent to browser
DEBUG - 2023-04-21 05:39:27 --> Total execution time: 0.1637
INFO - 2023-04-21 05:39:27 --> Config Class Initialized
INFO - 2023-04-21 05:39:27 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:39:27 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:39:27 --> Utf8 Class Initialized
INFO - 2023-04-21 05:39:27 --> URI Class Initialized
INFO - 2023-04-21 05:39:27 --> Router Class Initialized
INFO - 2023-04-21 05:39:27 --> Output Class Initialized
INFO - 2023-04-21 05:39:27 --> Security Class Initialized
DEBUG - 2023-04-21 05:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:39:27 --> Input Class Initialized
INFO - 2023-04-21 05:39:27 --> Language Class Initialized
INFO - 2023-04-21 05:39:27 --> Language Class Initialized
INFO - 2023-04-21 05:39:27 --> Config Class Initialized
INFO - 2023-04-21 05:39:27 --> Loader Class Initialized
INFO - 2023-04-21 05:39:27 --> Helper loaded: url_helper
INFO - 2023-04-21 05:39:27 --> Helper loaded: file_helper
INFO - 2023-04-21 05:39:27 --> Helper loaded: form_helper
INFO - 2023-04-21 05:39:27 --> Helper loaded: my_helper
INFO - 2023-04-21 05:39:27 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:39:27 --> Controller Class Initialized
DEBUG - 2023-04-21 05:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-21 05:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:39:27 --> Final output sent to browser
DEBUG - 2023-04-21 05:39:27 --> Total execution time: 0.1434
INFO - 2023-04-21 05:39:30 --> Config Class Initialized
INFO - 2023-04-21 05:39:30 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:39:30 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:39:30 --> Utf8 Class Initialized
INFO - 2023-04-21 05:39:30 --> URI Class Initialized
INFO - 2023-04-21 05:39:30 --> Router Class Initialized
INFO - 2023-04-21 05:39:30 --> Output Class Initialized
INFO - 2023-04-21 05:39:30 --> Security Class Initialized
DEBUG - 2023-04-21 05:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:39:30 --> Input Class Initialized
INFO - 2023-04-21 05:39:30 --> Language Class Initialized
INFO - 2023-04-21 05:39:30 --> Language Class Initialized
INFO - 2023-04-21 05:39:30 --> Config Class Initialized
INFO - 2023-04-21 05:39:30 --> Loader Class Initialized
INFO - 2023-04-21 05:39:30 --> Helper loaded: url_helper
INFO - 2023-04-21 05:39:30 --> Helper loaded: file_helper
INFO - 2023-04-21 05:39:30 --> Helper loaded: form_helper
INFO - 2023-04-21 05:39:30 --> Helper loaded: my_helper
INFO - 2023-04-21 05:39:30 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:39:30 --> Controller Class Initialized
DEBUG - 2023-04-21 05:39:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:39:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:39:30 --> Final output sent to browser
DEBUG - 2023-04-21 05:39:30 --> Total execution time: 0.0746
INFO - 2023-04-21 05:40:04 --> Config Class Initialized
INFO - 2023-04-21 05:40:04 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:40:04 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:40:04 --> Utf8 Class Initialized
INFO - 2023-04-21 05:40:04 --> URI Class Initialized
INFO - 2023-04-21 05:40:04 --> Router Class Initialized
INFO - 2023-04-21 05:40:04 --> Output Class Initialized
INFO - 2023-04-21 05:40:04 --> Security Class Initialized
DEBUG - 2023-04-21 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:40:04 --> Input Class Initialized
INFO - 2023-04-21 05:40:04 --> Language Class Initialized
INFO - 2023-04-21 05:40:04 --> Language Class Initialized
INFO - 2023-04-21 05:40:04 --> Config Class Initialized
INFO - 2023-04-21 05:40:04 --> Loader Class Initialized
INFO - 2023-04-21 05:40:04 --> Helper loaded: url_helper
INFO - 2023-04-21 05:40:04 --> Helper loaded: file_helper
INFO - 2023-04-21 05:40:04 --> Helper loaded: form_helper
INFO - 2023-04-21 05:40:04 --> Helper loaded: my_helper
INFO - 2023-04-21 05:40:04 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:40:04 --> Controller Class Initialized
DEBUG - 2023-04-21 05:40:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:40:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:40:04 --> Final output sent to browser
DEBUG - 2023-04-21 05:40:04 --> Total execution time: 0.0689
INFO - 2023-04-21 05:41:34 --> Config Class Initialized
INFO - 2023-04-21 05:41:34 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:41:34 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:41:34 --> Utf8 Class Initialized
INFO - 2023-04-21 05:41:34 --> URI Class Initialized
INFO - 2023-04-21 05:41:34 --> Router Class Initialized
INFO - 2023-04-21 05:41:34 --> Output Class Initialized
INFO - 2023-04-21 05:41:34 --> Security Class Initialized
DEBUG - 2023-04-21 05:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:41:34 --> Input Class Initialized
INFO - 2023-04-21 05:41:34 --> Language Class Initialized
INFO - 2023-04-21 05:41:34 --> Language Class Initialized
INFO - 2023-04-21 05:41:34 --> Config Class Initialized
INFO - 2023-04-21 05:41:34 --> Loader Class Initialized
INFO - 2023-04-21 05:41:34 --> Helper loaded: url_helper
INFO - 2023-04-21 05:41:34 --> Helper loaded: file_helper
INFO - 2023-04-21 05:41:34 --> Helper loaded: form_helper
INFO - 2023-04-21 05:41:34 --> Helper loaded: my_helper
INFO - 2023-04-21 05:41:34 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:41:34 --> Controller Class Initialized
DEBUG - 2023-04-21 05:41:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:41:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:41:34 --> Final output sent to browser
DEBUG - 2023-04-21 05:41:34 --> Total execution time: 0.0476
INFO - 2023-04-21 05:42:30 --> Config Class Initialized
INFO - 2023-04-21 05:42:30 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:42:30 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:42:30 --> Utf8 Class Initialized
INFO - 2023-04-21 05:42:30 --> URI Class Initialized
INFO - 2023-04-21 05:42:30 --> Router Class Initialized
INFO - 2023-04-21 05:42:30 --> Output Class Initialized
INFO - 2023-04-21 05:42:30 --> Security Class Initialized
DEBUG - 2023-04-21 05:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:42:30 --> Input Class Initialized
INFO - 2023-04-21 05:42:30 --> Language Class Initialized
INFO - 2023-04-21 05:42:30 --> Language Class Initialized
INFO - 2023-04-21 05:42:30 --> Config Class Initialized
INFO - 2023-04-21 05:42:30 --> Loader Class Initialized
INFO - 2023-04-21 05:42:30 --> Helper loaded: url_helper
INFO - 2023-04-21 05:42:30 --> Helper loaded: file_helper
INFO - 2023-04-21 05:42:30 --> Helper loaded: form_helper
INFO - 2023-04-21 05:42:30 --> Helper loaded: my_helper
INFO - 2023-04-21 05:42:30 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:42:30 --> Controller Class Initialized
DEBUG - 2023-04-21 05:42:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:42:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:42:30 --> Final output sent to browser
DEBUG - 2023-04-21 05:42:30 --> Total execution time: 0.0481
INFO - 2023-04-21 05:42:43 --> Config Class Initialized
INFO - 2023-04-21 05:42:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:42:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:42:43 --> Utf8 Class Initialized
INFO - 2023-04-21 05:42:43 --> URI Class Initialized
INFO - 2023-04-21 05:42:43 --> Router Class Initialized
INFO - 2023-04-21 05:42:43 --> Output Class Initialized
INFO - 2023-04-21 05:42:43 --> Security Class Initialized
DEBUG - 2023-04-21 05:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:42:43 --> Input Class Initialized
INFO - 2023-04-21 05:42:43 --> Language Class Initialized
INFO - 2023-04-21 05:42:43 --> Language Class Initialized
INFO - 2023-04-21 05:42:43 --> Config Class Initialized
INFO - 2023-04-21 05:42:43 --> Loader Class Initialized
INFO - 2023-04-21 05:42:43 --> Helper loaded: url_helper
INFO - 2023-04-21 05:42:43 --> Helper loaded: file_helper
INFO - 2023-04-21 05:42:43 --> Helper loaded: form_helper
INFO - 2023-04-21 05:42:43 --> Helper loaded: my_helper
INFO - 2023-04-21 05:42:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:42:43 --> Controller Class Initialized
DEBUG - 2023-04-21 05:42:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:42:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:42:43 --> Final output sent to browser
DEBUG - 2023-04-21 05:42:43 --> Total execution time: 0.0508
INFO - 2023-04-21 05:43:42 --> Config Class Initialized
INFO - 2023-04-21 05:43:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:43:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:43:42 --> Utf8 Class Initialized
INFO - 2023-04-21 05:43:42 --> URI Class Initialized
INFO - 2023-04-21 05:43:42 --> Router Class Initialized
INFO - 2023-04-21 05:43:42 --> Output Class Initialized
INFO - 2023-04-21 05:43:42 --> Security Class Initialized
DEBUG - 2023-04-21 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:43:42 --> Input Class Initialized
INFO - 2023-04-21 05:43:42 --> Language Class Initialized
INFO - 2023-04-21 05:43:42 --> Language Class Initialized
INFO - 2023-04-21 05:43:42 --> Config Class Initialized
INFO - 2023-04-21 05:43:42 --> Loader Class Initialized
INFO - 2023-04-21 05:43:42 --> Helper loaded: url_helper
INFO - 2023-04-21 05:43:42 --> Helper loaded: file_helper
INFO - 2023-04-21 05:43:42 --> Helper loaded: form_helper
INFO - 2023-04-21 05:43:42 --> Helper loaded: my_helper
INFO - 2023-04-21 05:43:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:43:42 --> Controller Class Initialized
DEBUG - 2023-04-21 05:43:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:43:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:43:42 --> Final output sent to browser
DEBUG - 2023-04-21 05:43:42 --> Total execution time: 0.0453
INFO - 2023-04-21 05:44:31 --> Config Class Initialized
INFO - 2023-04-21 05:44:31 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:44:31 --> Utf8 Class Initialized
INFO - 2023-04-21 05:44:31 --> URI Class Initialized
INFO - 2023-04-21 05:44:31 --> Router Class Initialized
INFO - 2023-04-21 05:44:31 --> Output Class Initialized
INFO - 2023-04-21 05:44:31 --> Security Class Initialized
DEBUG - 2023-04-21 05:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:44:31 --> Input Class Initialized
INFO - 2023-04-21 05:44:31 --> Language Class Initialized
INFO - 2023-04-21 05:44:31 --> Language Class Initialized
INFO - 2023-04-21 05:44:31 --> Config Class Initialized
INFO - 2023-04-21 05:44:31 --> Loader Class Initialized
INFO - 2023-04-21 05:44:31 --> Helper loaded: url_helper
INFO - 2023-04-21 05:44:31 --> Helper loaded: file_helper
INFO - 2023-04-21 05:44:31 --> Helper loaded: form_helper
INFO - 2023-04-21 05:44:31 --> Helper loaded: my_helper
INFO - 2023-04-21 05:44:31 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:44:32 --> Controller Class Initialized
DEBUG - 2023-04-21 05:44:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:44:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:44:32 --> Final output sent to browser
DEBUG - 2023-04-21 05:44:32 --> Total execution time: 0.0593
INFO - 2023-04-21 05:44:33 --> Config Class Initialized
INFO - 2023-04-21 05:44:33 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:44:33 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:44:33 --> Utf8 Class Initialized
INFO - 2023-04-21 05:44:33 --> URI Class Initialized
INFO - 2023-04-21 05:44:33 --> Router Class Initialized
INFO - 2023-04-21 05:44:33 --> Output Class Initialized
INFO - 2023-04-21 05:44:33 --> Security Class Initialized
DEBUG - 2023-04-21 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:44:33 --> Input Class Initialized
INFO - 2023-04-21 05:44:33 --> Language Class Initialized
INFO - 2023-04-21 05:44:33 --> Language Class Initialized
INFO - 2023-04-21 05:44:33 --> Config Class Initialized
INFO - 2023-04-21 05:44:33 --> Loader Class Initialized
INFO - 2023-04-21 05:44:33 --> Helper loaded: url_helper
INFO - 2023-04-21 05:44:33 --> Helper loaded: file_helper
INFO - 2023-04-21 05:44:33 --> Helper loaded: form_helper
INFO - 2023-04-21 05:44:33 --> Helper loaded: my_helper
INFO - 2023-04-21 05:44:33 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:44:33 --> Controller Class Initialized
DEBUG - 2023-04-21 05:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:44:33 --> Final output sent to browser
DEBUG - 2023-04-21 05:44:33 --> Total execution time: 0.0599
INFO - 2023-04-21 05:44:58 --> Config Class Initialized
INFO - 2023-04-21 05:44:58 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:44:58 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:44:58 --> Utf8 Class Initialized
INFO - 2023-04-21 05:44:58 --> URI Class Initialized
INFO - 2023-04-21 05:44:58 --> Router Class Initialized
INFO - 2023-04-21 05:44:58 --> Output Class Initialized
INFO - 2023-04-21 05:44:58 --> Security Class Initialized
DEBUG - 2023-04-21 05:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:44:58 --> Input Class Initialized
INFO - 2023-04-21 05:44:58 --> Language Class Initialized
INFO - 2023-04-21 05:44:58 --> Language Class Initialized
INFO - 2023-04-21 05:44:58 --> Config Class Initialized
INFO - 2023-04-21 05:44:58 --> Loader Class Initialized
INFO - 2023-04-21 05:44:58 --> Helper loaded: url_helper
INFO - 2023-04-21 05:44:58 --> Helper loaded: file_helper
INFO - 2023-04-21 05:44:58 --> Helper loaded: form_helper
INFO - 2023-04-21 05:44:58 --> Helper loaded: my_helper
INFO - 2023-04-21 05:44:58 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:44:58 --> Controller Class Initialized
DEBUG - 2023-04-21 05:44:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:44:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:44:58 --> Final output sent to browser
DEBUG - 2023-04-21 05:44:58 --> Total execution time: 0.0535
INFO - 2023-04-21 05:45:19 --> Config Class Initialized
INFO - 2023-04-21 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:45:19 --> Utf8 Class Initialized
INFO - 2023-04-21 05:45:19 --> URI Class Initialized
INFO - 2023-04-21 05:45:19 --> Router Class Initialized
INFO - 2023-04-21 05:45:19 --> Output Class Initialized
INFO - 2023-04-21 05:45:19 --> Security Class Initialized
DEBUG - 2023-04-21 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:45:19 --> Input Class Initialized
INFO - 2023-04-21 05:45:19 --> Language Class Initialized
INFO - 2023-04-21 05:45:19 --> Language Class Initialized
INFO - 2023-04-21 05:45:19 --> Config Class Initialized
INFO - 2023-04-21 05:45:19 --> Loader Class Initialized
INFO - 2023-04-21 05:45:19 --> Helper loaded: url_helper
INFO - 2023-04-21 05:45:19 --> Helper loaded: file_helper
INFO - 2023-04-21 05:45:19 --> Helper loaded: form_helper
INFO - 2023-04-21 05:45:19 --> Helper loaded: my_helper
INFO - 2023-04-21 05:45:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:45:19 --> Controller Class Initialized
DEBUG - 2023-04-21 05:45:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:45:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:45:19 --> Final output sent to browser
DEBUG - 2023-04-21 05:45:19 --> Total execution time: 0.0639
INFO - 2023-04-21 05:49:02 --> Config Class Initialized
INFO - 2023-04-21 05:49:02 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:49:02 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:49:02 --> Utf8 Class Initialized
INFO - 2023-04-21 05:49:02 --> URI Class Initialized
INFO - 2023-04-21 05:49:02 --> Router Class Initialized
INFO - 2023-04-21 05:49:02 --> Output Class Initialized
INFO - 2023-04-21 05:49:02 --> Security Class Initialized
DEBUG - 2023-04-21 05:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:49:02 --> Input Class Initialized
INFO - 2023-04-21 05:49:02 --> Language Class Initialized
ERROR - 2023-04-21 05:49:02 --> 404 Page Not Found: /index
INFO - 2023-04-21 05:54:42 --> Config Class Initialized
INFO - 2023-04-21 05:54:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:54:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:54:42 --> Utf8 Class Initialized
INFO - 2023-04-21 05:54:42 --> URI Class Initialized
INFO - 2023-04-21 05:54:42 --> Router Class Initialized
INFO - 2023-04-21 05:54:42 --> Output Class Initialized
INFO - 2023-04-21 05:54:42 --> Security Class Initialized
DEBUG - 2023-04-21 05:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:54:42 --> Input Class Initialized
INFO - 2023-04-21 05:54:42 --> Language Class Initialized
INFO - 2023-04-21 05:54:42 --> Language Class Initialized
INFO - 2023-04-21 05:54:42 --> Config Class Initialized
INFO - 2023-04-21 05:54:42 --> Loader Class Initialized
INFO - 2023-04-21 05:54:42 --> Helper loaded: url_helper
INFO - 2023-04-21 05:54:42 --> Helper loaded: file_helper
INFO - 2023-04-21 05:54:42 --> Helper loaded: form_helper
INFO - 2023-04-21 05:54:42 --> Helper loaded: my_helper
INFO - 2023-04-21 05:54:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:54:42 --> Controller Class Initialized
ERROR - 2023-04-21 05:54:42 --> Severity: Notice --> Undefined index: capaian_mid C:\xampp\htdocs\myraportk13\application\modules\n_catatan_kl1\views\list.php 38
ERROR - 2023-04-21 05:54:42 --> Severity: Notice --> Undefined index: capaian_final C:\xampp\htdocs\myraportk13\application\modules\n_catatan_kl1\views\list.php 43
ERROR - 2023-04-21 05:54:42 --> Severity: Notice --> Undefined index: capaian_mid C:\xampp\htdocs\myraportk13\application\modules\n_catatan_kl1\views\list.php 38
ERROR - 2023-04-21 05:54:42 --> Severity: Notice --> Undefined index: capaian_final C:\xampp\htdocs\myraportk13\application\modules\n_catatan_kl1\views\list.php 43
DEBUG - 2023-04-21 05:54:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:54:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:54:43 --> Final output sent to browser
DEBUG - 2023-04-21 05:54:43 --> Total execution time: 0.1605
INFO - 2023-04-21 05:54:43 --> Config Class Initialized
INFO - 2023-04-21 05:54:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:54:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:54:43 --> Utf8 Class Initialized
INFO - 2023-04-21 05:54:43 --> URI Class Initialized
INFO - 2023-04-21 05:54:43 --> Router Class Initialized
INFO - 2023-04-21 05:54:43 --> Output Class Initialized
INFO - 2023-04-21 05:54:43 --> Security Class Initialized
DEBUG - 2023-04-21 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:54:43 --> Input Class Initialized
INFO - 2023-04-21 05:54:43 --> Language Class Initialized
ERROR - 2023-04-21 05:54:43 --> 404 Page Not Found: /index
INFO - 2023-04-21 05:57:44 --> Config Class Initialized
INFO - 2023-04-21 05:57:44 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:57:44 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:57:44 --> Utf8 Class Initialized
INFO - 2023-04-21 05:57:44 --> URI Class Initialized
INFO - 2023-04-21 05:57:44 --> Router Class Initialized
INFO - 2023-04-21 05:57:44 --> Output Class Initialized
INFO - 2023-04-21 05:57:44 --> Security Class Initialized
DEBUG - 2023-04-21 05:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:57:44 --> Input Class Initialized
INFO - 2023-04-21 05:57:44 --> Language Class Initialized
INFO - 2023-04-21 05:57:44 --> Language Class Initialized
INFO - 2023-04-21 05:57:44 --> Config Class Initialized
INFO - 2023-04-21 05:57:44 --> Loader Class Initialized
INFO - 2023-04-21 05:57:44 --> Helper loaded: url_helper
INFO - 2023-04-21 05:57:44 --> Helper loaded: file_helper
INFO - 2023-04-21 05:57:44 --> Helper loaded: form_helper
INFO - 2023-04-21 05:57:44 --> Helper loaded: my_helper
INFO - 2023-04-21 05:57:44 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:57:44 --> Controller Class Initialized
DEBUG - 2023-04-21 05:57:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:57:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:57:44 --> Final output sent to browser
DEBUG - 2023-04-21 05:57:44 --> Total execution time: 0.0565
INFO - 2023-04-21 05:57:57 --> Config Class Initialized
INFO - 2023-04-21 05:57:57 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:57:57 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:57:57 --> Utf8 Class Initialized
INFO - 2023-04-21 05:57:57 --> URI Class Initialized
INFO - 2023-04-21 05:57:57 --> Router Class Initialized
INFO - 2023-04-21 05:57:57 --> Output Class Initialized
INFO - 2023-04-21 05:57:57 --> Security Class Initialized
DEBUG - 2023-04-21 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:57:57 --> Input Class Initialized
INFO - 2023-04-21 05:57:57 --> Language Class Initialized
INFO - 2023-04-21 05:57:57 --> Language Class Initialized
INFO - 2023-04-21 05:57:57 --> Config Class Initialized
INFO - 2023-04-21 05:57:57 --> Loader Class Initialized
INFO - 2023-04-21 05:57:57 --> Helper loaded: url_helper
INFO - 2023-04-21 05:57:57 --> Helper loaded: file_helper
INFO - 2023-04-21 05:57:57 --> Helper loaded: form_helper
INFO - 2023-04-21 05:57:57 --> Helper loaded: my_helper
INFO - 2023-04-21 05:57:57 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:57:57 --> Controller Class Initialized
INFO - 2023-04-21 05:57:57 --> Final output sent to browser
DEBUG - 2023-04-21 05:57:57 --> Total execution time: 0.0461
INFO - 2023-04-21 05:57:59 --> Config Class Initialized
INFO - 2023-04-21 05:57:59 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:57:59 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:57:59 --> Utf8 Class Initialized
INFO - 2023-04-21 05:57:59 --> URI Class Initialized
INFO - 2023-04-21 05:57:59 --> Router Class Initialized
INFO - 2023-04-21 05:57:59 --> Output Class Initialized
INFO - 2023-04-21 05:57:59 --> Security Class Initialized
DEBUG - 2023-04-21 05:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:57:59 --> Input Class Initialized
INFO - 2023-04-21 05:57:59 --> Language Class Initialized
INFO - 2023-04-21 05:57:59 --> Language Class Initialized
INFO - 2023-04-21 05:57:59 --> Config Class Initialized
INFO - 2023-04-21 05:57:59 --> Loader Class Initialized
INFO - 2023-04-21 05:57:59 --> Helper loaded: url_helper
INFO - 2023-04-21 05:57:59 --> Helper loaded: file_helper
INFO - 2023-04-21 05:57:59 --> Helper loaded: form_helper
INFO - 2023-04-21 05:57:59 --> Helper loaded: my_helper
INFO - 2023-04-21 05:57:59 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:57:59 --> Controller Class Initialized
DEBUG - 2023-04-21 05:57:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:57:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:57:59 --> Final output sent to browser
DEBUG - 2023-04-21 05:57:59 --> Total execution time: 0.0651
INFO - 2023-04-21 05:58:15 --> Config Class Initialized
INFO - 2023-04-21 05:58:15 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:58:15 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:58:15 --> Utf8 Class Initialized
INFO - 2023-04-21 05:58:15 --> URI Class Initialized
INFO - 2023-04-21 05:58:15 --> Router Class Initialized
INFO - 2023-04-21 05:58:15 --> Output Class Initialized
INFO - 2023-04-21 05:58:15 --> Security Class Initialized
DEBUG - 2023-04-21 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:58:15 --> Input Class Initialized
INFO - 2023-04-21 05:58:15 --> Language Class Initialized
INFO - 2023-04-21 05:58:15 --> Language Class Initialized
INFO - 2023-04-21 05:58:15 --> Config Class Initialized
INFO - 2023-04-21 05:58:15 --> Loader Class Initialized
INFO - 2023-04-21 05:58:15 --> Helper loaded: url_helper
INFO - 2023-04-21 05:58:15 --> Helper loaded: file_helper
INFO - 2023-04-21 05:58:15 --> Helper loaded: form_helper
INFO - 2023-04-21 05:58:15 --> Helper loaded: my_helper
INFO - 2023-04-21 05:58:15 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:58:15 --> Controller Class Initialized
INFO - 2023-04-21 05:58:15 --> Final output sent to browser
DEBUG - 2023-04-21 05:58:15 --> Total execution time: 0.0640
INFO - 2023-04-21 05:58:53 --> Config Class Initialized
INFO - 2023-04-21 05:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:58:53 --> Utf8 Class Initialized
INFO - 2023-04-21 05:58:53 --> URI Class Initialized
INFO - 2023-04-21 05:58:53 --> Router Class Initialized
INFO - 2023-04-21 05:58:53 --> Output Class Initialized
INFO - 2023-04-21 05:58:53 --> Security Class Initialized
DEBUG - 2023-04-21 05:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:58:53 --> Input Class Initialized
INFO - 2023-04-21 05:58:53 --> Language Class Initialized
INFO - 2023-04-21 05:58:53 --> Language Class Initialized
INFO - 2023-04-21 05:58:53 --> Config Class Initialized
INFO - 2023-04-21 05:58:53 --> Loader Class Initialized
INFO - 2023-04-21 05:58:53 --> Helper loaded: url_helper
INFO - 2023-04-21 05:58:53 --> Helper loaded: file_helper
INFO - 2023-04-21 05:58:53 --> Helper loaded: form_helper
INFO - 2023-04-21 05:58:53 --> Helper loaded: my_helper
INFO - 2023-04-21 05:58:53 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:58:53 --> Controller Class Initialized
DEBUG - 2023-04-21 05:58:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 05:58:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 05:58:53 --> Final output sent to browser
DEBUG - 2023-04-21 05:58:53 --> Total execution time: 0.0441
INFO - 2023-04-21 05:59:28 --> Config Class Initialized
INFO - 2023-04-21 05:59:28 --> Hooks Class Initialized
DEBUG - 2023-04-21 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-04-21 05:59:28 --> Utf8 Class Initialized
INFO - 2023-04-21 05:59:28 --> URI Class Initialized
INFO - 2023-04-21 05:59:28 --> Router Class Initialized
INFO - 2023-04-21 05:59:28 --> Output Class Initialized
INFO - 2023-04-21 05:59:28 --> Security Class Initialized
DEBUG - 2023-04-21 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 05:59:28 --> Input Class Initialized
INFO - 2023-04-21 05:59:28 --> Language Class Initialized
INFO - 2023-04-21 05:59:28 --> Language Class Initialized
INFO - 2023-04-21 05:59:28 --> Config Class Initialized
INFO - 2023-04-21 05:59:28 --> Loader Class Initialized
INFO - 2023-04-21 05:59:28 --> Helper loaded: url_helper
INFO - 2023-04-21 05:59:28 --> Helper loaded: file_helper
INFO - 2023-04-21 05:59:28 --> Helper loaded: form_helper
INFO - 2023-04-21 05:59:28 --> Helper loaded: my_helper
INFO - 2023-04-21 05:59:28 --> Database Driver Class Initialized
DEBUG - 2023-04-21 05:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 05:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 05:59:28 --> Controller Class Initialized
INFO - 2023-04-21 05:59:28 --> Final output sent to browser
DEBUG - 2023-04-21 05:59:28 --> Total execution time: 0.0645
INFO - 2023-04-21 06:01:49 --> Config Class Initialized
INFO - 2023-04-21 06:01:49 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:01:49 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:01:49 --> Utf8 Class Initialized
INFO - 2023-04-21 06:01:49 --> URI Class Initialized
INFO - 2023-04-21 06:01:49 --> Router Class Initialized
INFO - 2023-04-21 06:01:49 --> Output Class Initialized
INFO - 2023-04-21 06:01:49 --> Security Class Initialized
DEBUG - 2023-04-21 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:01:49 --> Input Class Initialized
INFO - 2023-04-21 06:01:49 --> Language Class Initialized
INFO - 2023-04-21 06:01:49 --> Language Class Initialized
INFO - 2023-04-21 06:01:49 --> Config Class Initialized
INFO - 2023-04-21 06:01:49 --> Loader Class Initialized
INFO - 2023-04-21 06:01:49 --> Helper loaded: url_helper
INFO - 2023-04-21 06:01:49 --> Helper loaded: file_helper
INFO - 2023-04-21 06:01:49 --> Helper loaded: form_helper
INFO - 2023-04-21 06:01:49 --> Helper loaded: my_helper
INFO - 2023-04-21 06:01:49 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:01:49 --> Controller Class Initialized
DEBUG - 2023-04-21 06:01:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 06:01:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 06:01:49 --> Final output sent to browser
DEBUG - 2023-04-21 06:01:49 --> Total execution time: 0.0430
INFO - 2023-04-21 06:01:54 --> Config Class Initialized
INFO - 2023-04-21 06:01:54 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:01:54 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:01:54 --> Utf8 Class Initialized
INFO - 2023-04-21 06:01:54 --> URI Class Initialized
INFO - 2023-04-21 06:01:54 --> Router Class Initialized
INFO - 2023-04-21 06:01:54 --> Output Class Initialized
INFO - 2023-04-21 06:01:54 --> Security Class Initialized
DEBUG - 2023-04-21 06:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:01:54 --> Input Class Initialized
INFO - 2023-04-21 06:01:54 --> Language Class Initialized
INFO - 2023-04-21 06:01:54 --> Language Class Initialized
INFO - 2023-04-21 06:01:54 --> Config Class Initialized
INFO - 2023-04-21 06:01:54 --> Loader Class Initialized
INFO - 2023-04-21 06:01:54 --> Helper loaded: url_helper
INFO - 2023-04-21 06:01:54 --> Helper loaded: file_helper
INFO - 2023-04-21 06:01:54 --> Helper loaded: form_helper
INFO - 2023-04-21 06:01:54 --> Helper loaded: my_helper
INFO - 2023-04-21 06:01:54 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:01:55 --> Controller Class Initialized
DEBUG - 2023-04-21 06:01:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 06:01:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 06:01:55 --> Final output sent to browser
DEBUG - 2023-04-21 06:01:55 --> Total execution time: 0.0418
INFO - 2023-04-21 06:02:03 --> Config Class Initialized
INFO - 2023-04-21 06:02:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:02:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:02:03 --> Utf8 Class Initialized
INFO - 2023-04-21 06:02:03 --> URI Class Initialized
INFO - 2023-04-21 06:02:03 --> Router Class Initialized
INFO - 2023-04-21 06:02:03 --> Output Class Initialized
INFO - 2023-04-21 06:02:03 --> Security Class Initialized
DEBUG - 2023-04-21 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:02:03 --> Input Class Initialized
INFO - 2023-04-21 06:02:03 --> Language Class Initialized
INFO - 2023-04-21 06:02:03 --> Language Class Initialized
INFO - 2023-04-21 06:02:03 --> Config Class Initialized
INFO - 2023-04-21 06:02:03 --> Loader Class Initialized
INFO - 2023-04-21 06:02:03 --> Helper loaded: url_helper
INFO - 2023-04-21 06:02:03 --> Helper loaded: file_helper
INFO - 2023-04-21 06:02:03 --> Helper loaded: form_helper
INFO - 2023-04-21 06:02:03 --> Helper loaded: my_helper
INFO - 2023-04-21 06:02:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:02:03 --> Controller Class Initialized
DEBUG - 2023-04-21 06:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 06:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 06:02:03 --> Final output sent to browser
DEBUG - 2023-04-21 06:02:03 --> Total execution time: 0.0406
INFO - 2023-04-21 06:02:07 --> Config Class Initialized
INFO - 2023-04-21 06:02:07 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:02:07 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:02:07 --> Utf8 Class Initialized
INFO - 2023-04-21 06:02:07 --> URI Class Initialized
INFO - 2023-04-21 06:02:07 --> Router Class Initialized
INFO - 2023-04-21 06:02:07 --> Output Class Initialized
INFO - 2023-04-21 06:02:07 --> Security Class Initialized
DEBUG - 2023-04-21 06:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:02:07 --> Input Class Initialized
INFO - 2023-04-21 06:02:07 --> Language Class Initialized
INFO - 2023-04-21 06:02:07 --> Language Class Initialized
INFO - 2023-04-21 06:02:07 --> Config Class Initialized
INFO - 2023-04-21 06:02:07 --> Loader Class Initialized
INFO - 2023-04-21 06:02:07 --> Helper loaded: url_helper
INFO - 2023-04-21 06:02:07 --> Helper loaded: file_helper
INFO - 2023-04-21 06:02:07 --> Helper loaded: form_helper
INFO - 2023-04-21 06:02:07 --> Helper loaded: my_helper
INFO - 2023-04-21 06:02:07 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:02:07 --> Controller Class Initialized
DEBUG - 2023-04-21 06:02:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 06:02:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 06:02:07 --> Final output sent to browser
DEBUG - 2023-04-21 06:02:07 --> Total execution time: 0.0414
INFO - 2023-04-21 06:02:16 --> Config Class Initialized
INFO - 2023-04-21 06:02:16 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:02:16 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:02:16 --> Utf8 Class Initialized
INFO - 2023-04-21 06:02:16 --> URI Class Initialized
INFO - 2023-04-21 06:02:16 --> Router Class Initialized
INFO - 2023-04-21 06:02:16 --> Output Class Initialized
INFO - 2023-04-21 06:02:16 --> Security Class Initialized
DEBUG - 2023-04-21 06:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:02:16 --> Input Class Initialized
INFO - 2023-04-21 06:02:16 --> Language Class Initialized
INFO - 2023-04-21 06:02:16 --> Language Class Initialized
INFO - 2023-04-21 06:02:16 --> Config Class Initialized
INFO - 2023-04-21 06:02:16 --> Loader Class Initialized
INFO - 2023-04-21 06:02:16 --> Helper loaded: url_helper
INFO - 2023-04-21 06:02:16 --> Helper loaded: file_helper
INFO - 2023-04-21 06:02:16 --> Helper loaded: form_helper
INFO - 2023-04-21 06:02:16 --> Helper loaded: my_helper
INFO - 2023-04-21 06:02:16 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:02:16 --> Controller Class Initialized
DEBUG - 2023-04-21 06:02:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-21 06:02:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 06:02:16 --> Final output sent to browser
DEBUG - 2023-04-21 06:02:16 --> Total execution time: 0.1110
INFO - 2023-04-21 06:02:18 --> Config Class Initialized
INFO - 2023-04-21 06:02:18 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:02:18 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:02:18 --> Utf8 Class Initialized
INFO - 2023-04-21 06:02:18 --> URI Class Initialized
INFO - 2023-04-21 06:02:18 --> Router Class Initialized
INFO - 2023-04-21 06:02:18 --> Output Class Initialized
INFO - 2023-04-21 06:02:18 --> Security Class Initialized
DEBUG - 2023-04-21 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:02:18 --> Input Class Initialized
INFO - 2023-04-21 06:02:18 --> Language Class Initialized
INFO - 2023-04-21 06:02:18 --> Language Class Initialized
INFO - 2023-04-21 06:02:18 --> Config Class Initialized
INFO - 2023-04-21 06:02:18 --> Loader Class Initialized
INFO - 2023-04-21 06:02:18 --> Helper loaded: url_helper
INFO - 2023-04-21 06:02:18 --> Helper loaded: file_helper
INFO - 2023-04-21 06:02:18 --> Helper loaded: form_helper
INFO - 2023-04-21 06:02:18 --> Helper loaded: my_helper
INFO - 2023-04-21 06:02:18 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:02:18 --> Controller Class Initialized
DEBUG - 2023-04-21 06:02:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 06:02:21 --> Final output sent to browser
DEBUG - 2023-04-21 06:02:21 --> Total execution time: 2.4896
INFO - 2023-04-21 06:05:10 --> Config Class Initialized
INFO - 2023-04-21 06:05:10 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:05:10 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:05:10 --> Utf8 Class Initialized
INFO - 2023-04-21 06:05:10 --> URI Class Initialized
INFO - 2023-04-21 06:05:10 --> Router Class Initialized
INFO - 2023-04-21 06:05:10 --> Output Class Initialized
INFO - 2023-04-21 06:05:10 --> Security Class Initialized
DEBUG - 2023-04-21 06:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:05:10 --> Input Class Initialized
INFO - 2023-04-21 06:05:10 --> Language Class Initialized
INFO - 2023-04-21 06:05:10 --> Language Class Initialized
INFO - 2023-04-21 06:05:10 --> Config Class Initialized
INFO - 2023-04-21 06:05:10 --> Loader Class Initialized
INFO - 2023-04-21 06:05:10 --> Helper loaded: url_helper
INFO - 2023-04-21 06:05:10 --> Helper loaded: file_helper
INFO - 2023-04-21 06:05:10 --> Helper loaded: form_helper
INFO - 2023-04-21 06:05:10 --> Helper loaded: my_helper
INFO - 2023-04-21 06:05:10 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:05:10 --> Controller Class Initialized
DEBUG - 2023-04-21 06:05:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 06:05:11 --> Final output sent to browser
DEBUG - 2023-04-21 06:05:11 --> Total execution time: 1.4626
INFO - 2023-04-21 06:20:10 --> Config Class Initialized
INFO - 2023-04-21 06:20:10 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:20:10 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:20:10 --> Utf8 Class Initialized
INFO - 2023-04-21 06:20:10 --> URI Class Initialized
INFO - 2023-04-21 06:20:10 --> Router Class Initialized
INFO - 2023-04-21 06:20:10 --> Output Class Initialized
INFO - 2023-04-21 06:20:10 --> Security Class Initialized
DEBUG - 2023-04-21 06:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:20:10 --> Input Class Initialized
INFO - 2023-04-21 06:20:10 --> Language Class Initialized
INFO - 2023-04-21 06:20:10 --> Language Class Initialized
INFO - 2023-04-21 06:20:10 --> Config Class Initialized
INFO - 2023-04-21 06:20:10 --> Loader Class Initialized
INFO - 2023-04-21 06:20:10 --> Helper loaded: url_helper
INFO - 2023-04-21 06:20:10 --> Helper loaded: file_helper
INFO - 2023-04-21 06:20:10 --> Helper loaded: form_helper
INFO - 2023-04-21 06:20:10 --> Helper loaded: my_helper
INFO - 2023-04-21 06:20:10 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:20:10 --> Controller Class Initialized
DEBUG - 2023-04-21 06:20:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 06:20:11 --> Final output sent to browser
DEBUG - 2023-04-21 06:20:11 --> Total execution time: 1.4434
INFO - 2023-04-21 06:20:52 --> Config Class Initialized
INFO - 2023-04-21 06:20:52 --> Hooks Class Initialized
DEBUG - 2023-04-21 06:20:52 --> UTF-8 Support Enabled
INFO - 2023-04-21 06:20:52 --> Utf8 Class Initialized
INFO - 2023-04-21 06:20:52 --> URI Class Initialized
INFO - 2023-04-21 06:20:52 --> Router Class Initialized
INFO - 2023-04-21 06:20:52 --> Output Class Initialized
INFO - 2023-04-21 06:20:52 --> Security Class Initialized
DEBUG - 2023-04-21 06:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 06:20:52 --> Input Class Initialized
INFO - 2023-04-21 06:20:52 --> Language Class Initialized
INFO - 2023-04-21 06:20:52 --> Language Class Initialized
INFO - 2023-04-21 06:20:52 --> Config Class Initialized
INFO - 2023-04-21 06:20:52 --> Loader Class Initialized
INFO - 2023-04-21 06:20:52 --> Helper loaded: url_helper
INFO - 2023-04-21 06:20:52 --> Helper loaded: file_helper
INFO - 2023-04-21 06:20:52 --> Helper loaded: form_helper
INFO - 2023-04-21 06:20:52 --> Helper loaded: my_helper
INFO - 2023-04-21 06:20:52 --> Database Driver Class Initialized
DEBUG - 2023-04-21 06:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 06:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 06:20:52 --> Controller Class Initialized
DEBUG - 2023-04-21 06:20:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 06:20:54 --> Final output sent to browser
DEBUG - 2023-04-21 06:20:54 --> Total execution time: 1.3177
INFO - 2023-04-21 07:47:46 --> Config Class Initialized
INFO - 2023-04-21 07:47:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:47:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:47:46 --> Utf8 Class Initialized
INFO - 2023-04-21 07:47:46 --> URI Class Initialized
INFO - 2023-04-21 07:47:46 --> Router Class Initialized
INFO - 2023-04-21 07:47:46 --> Output Class Initialized
INFO - 2023-04-21 07:47:46 --> Security Class Initialized
DEBUG - 2023-04-21 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:47:46 --> Input Class Initialized
INFO - 2023-04-21 07:47:46 --> Language Class Initialized
INFO - 2023-04-21 07:47:46 --> Language Class Initialized
INFO - 2023-04-21 07:47:46 --> Config Class Initialized
INFO - 2023-04-21 07:47:46 --> Loader Class Initialized
INFO - 2023-04-21 07:47:46 --> Helper loaded: url_helper
INFO - 2023-04-21 07:47:46 --> Helper loaded: file_helper
INFO - 2023-04-21 07:47:46 --> Helper loaded: form_helper
INFO - 2023-04-21 07:47:46 --> Helper loaded: my_helper
INFO - 2023-04-21 07:47:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:47:46 --> Controller Class Initialized
DEBUG - 2023-04-21 07:47:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:47:47 --> Final output sent to browser
DEBUG - 2023-04-21 07:47:47 --> Total execution time: 1.1685
INFO - 2023-04-21 07:49:50 --> Config Class Initialized
INFO - 2023-04-21 07:49:50 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:49:50 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:49:50 --> Utf8 Class Initialized
INFO - 2023-04-21 07:49:50 --> URI Class Initialized
INFO - 2023-04-21 07:49:50 --> Router Class Initialized
INFO - 2023-04-21 07:49:50 --> Output Class Initialized
INFO - 2023-04-21 07:49:50 --> Security Class Initialized
DEBUG - 2023-04-21 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:49:50 --> Input Class Initialized
INFO - 2023-04-21 07:49:50 --> Language Class Initialized
INFO - 2023-04-21 07:49:50 --> Language Class Initialized
INFO - 2023-04-21 07:49:50 --> Config Class Initialized
INFO - 2023-04-21 07:49:50 --> Loader Class Initialized
INFO - 2023-04-21 07:49:50 --> Helper loaded: url_helper
INFO - 2023-04-21 07:49:50 --> Helper loaded: file_helper
INFO - 2023-04-21 07:49:50 --> Helper loaded: form_helper
INFO - 2023-04-21 07:49:50 --> Helper loaded: my_helper
INFO - 2023-04-21 07:49:50 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:49:50 --> Controller Class Initialized
DEBUG - 2023-04-21 07:49:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:49:52 --> Final output sent to browser
DEBUG - 2023-04-21 07:49:52 --> Total execution time: 2.0633
INFO - 2023-04-21 07:50:07 --> Config Class Initialized
INFO - 2023-04-21 07:50:07 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:50:07 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:50:07 --> Utf8 Class Initialized
INFO - 2023-04-21 07:50:07 --> URI Class Initialized
INFO - 2023-04-21 07:50:07 --> Router Class Initialized
INFO - 2023-04-21 07:50:07 --> Output Class Initialized
INFO - 2023-04-21 07:50:07 --> Security Class Initialized
DEBUG - 2023-04-21 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:50:07 --> Input Class Initialized
INFO - 2023-04-21 07:50:07 --> Language Class Initialized
INFO - 2023-04-21 07:50:07 --> Language Class Initialized
INFO - 2023-04-21 07:50:07 --> Config Class Initialized
INFO - 2023-04-21 07:50:07 --> Loader Class Initialized
INFO - 2023-04-21 07:50:07 --> Helper loaded: url_helper
INFO - 2023-04-21 07:50:07 --> Helper loaded: file_helper
INFO - 2023-04-21 07:50:07 --> Helper loaded: form_helper
INFO - 2023-04-21 07:50:07 --> Helper loaded: my_helper
INFO - 2023-04-21 07:50:07 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:50:07 --> Controller Class Initialized
DEBUG - 2023-04-21 07:50:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:50:08 --> Final output sent to browser
DEBUG - 2023-04-21 07:50:08 --> Total execution time: 1.2154
INFO - 2023-04-21 07:50:19 --> Config Class Initialized
INFO - 2023-04-21 07:50:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:50:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:50:19 --> Utf8 Class Initialized
INFO - 2023-04-21 07:50:19 --> URI Class Initialized
INFO - 2023-04-21 07:50:19 --> Router Class Initialized
INFO - 2023-04-21 07:50:19 --> Output Class Initialized
INFO - 2023-04-21 07:50:19 --> Security Class Initialized
DEBUG - 2023-04-21 07:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:50:19 --> Input Class Initialized
INFO - 2023-04-21 07:50:19 --> Language Class Initialized
INFO - 2023-04-21 07:50:19 --> Language Class Initialized
INFO - 2023-04-21 07:50:19 --> Config Class Initialized
INFO - 2023-04-21 07:50:19 --> Loader Class Initialized
INFO - 2023-04-21 07:50:19 --> Helper loaded: url_helper
INFO - 2023-04-21 07:50:19 --> Helper loaded: file_helper
INFO - 2023-04-21 07:50:19 --> Helper loaded: form_helper
INFO - 2023-04-21 07:50:19 --> Helper loaded: my_helper
INFO - 2023-04-21 07:50:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:50:19 --> Controller Class Initialized
DEBUG - 2023-04-21 07:50:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:50:20 --> Final output sent to browser
DEBUG - 2023-04-21 07:50:20 --> Total execution time: 1.0944
INFO - 2023-04-21 07:51:26 --> Config Class Initialized
INFO - 2023-04-21 07:51:26 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:51:26 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:51:26 --> Utf8 Class Initialized
INFO - 2023-04-21 07:51:26 --> URI Class Initialized
INFO - 2023-04-21 07:51:26 --> Router Class Initialized
INFO - 2023-04-21 07:51:26 --> Output Class Initialized
INFO - 2023-04-21 07:51:26 --> Security Class Initialized
DEBUG - 2023-04-21 07:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:51:26 --> Input Class Initialized
INFO - 2023-04-21 07:51:26 --> Language Class Initialized
INFO - 2023-04-21 07:51:26 --> Language Class Initialized
INFO - 2023-04-21 07:51:26 --> Config Class Initialized
INFO - 2023-04-21 07:51:26 --> Loader Class Initialized
INFO - 2023-04-21 07:51:26 --> Helper loaded: url_helper
INFO - 2023-04-21 07:51:26 --> Helper loaded: file_helper
INFO - 2023-04-21 07:51:26 --> Helper loaded: form_helper
INFO - 2023-04-21 07:51:26 --> Helper loaded: my_helper
INFO - 2023-04-21 07:51:26 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:51:26 --> Controller Class Initialized
DEBUG - 2023-04-21 07:51:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:51:27 --> Final output sent to browser
DEBUG - 2023-04-21 07:51:27 --> Total execution time: 1.1715
INFO - 2023-04-21 07:51:42 --> Config Class Initialized
INFO - 2023-04-21 07:51:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:51:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:51:42 --> Utf8 Class Initialized
INFO - 2023-04-21 07:51:42 --> URI Class Initialized
INFO - 2023-04-21 07:51:42 --> Router Class Initialized
INFO - 2023-04-21 07:51:42 --> Output Class Initialized
INFO - 2023-04-21 07:51:42 --> Security Class Initialized
DEBUG - 2023-04-21 07:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:51:42 --> Input Class Initialized
INFO - 2023-04-21 07:51:42 --> Language Class Initialized
INFO - 2023-04-21 07:51:42 --> Language Class Initialized
INFO - 2023-04-21 07:51:42 --> Config Class Initialized
INFO - 2023-04-21 07:51:42 --> Loader Class Initialized
INFO - 2023-04-21 07:51:42 --> Helper loaded: url_helper
INFO - 2023-04-21 07:51:42 --> Helper loaded: file_helper
INFO - 2023-04-21 07:51:42 --> Helper loaded: form_helper
INFO - 2023-04-21 07:51:42 --> Helper loaded: my_helper
INFO - 2023-04-21 07:51:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:51:42 --> Controller Class Initialized
DEBUG - 2023-04-21 07:51:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:51:43 --> Final output sent to browser
DEBUG - 2023-04-21 07:51:43 --> Total execution time: 1.1355
INFO - 2023-04-21 07:52:19 --> Config Class Initialized
INFO - 2023-04-21 07:52:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:52:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:52:19 --> Utf8 Class Initialized
INFO - 2023-04-21 07:52:19 --> URI Class Initialized
INFO - 2023-04-21 07:52:19 --> Router Class Initialized
INFO - 2023-04-21 07:52:19 --> Output Class Initialized
INFO - 2023-04-21 07:52:19 --> Security Class Initialized
DEBUG - 2023-04-21 07:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:52:19 --> Input Class Initialized
INFO - 2023-04-21 07:52:19 --> Language Class Initialized
INFO - 2023-04-21 07:52:19 --> Language Class Initialized
INFO - 2023-04-21 07:52:19 --> Config Class Initialized
INFO - 2023-04-21 07:52:19 --> Loader Class Initialized
INFO - 2023-04-21 07:52:19 --> Helper loaded: url_helper
INFO - 2023-04-21 07:52:19 --> Helper loaded: file_helper
INFO - 2023-04-21 07:52:19 --> Helper loaded: form_helper
INFO - 2023-04-21 07:52:19 --> Helper loaded: my_helper
INFO - 2023-04-21 07:52:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:52:19 --> Controller Class Initialized
DEBUG - 2023-04-21 07:52:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:52:20 --> Final output sent to browser
DEBUG - 2023-04-21 07:52:20 --> Total execution time: 1.0703
INFO - 2023-04-21 07:53:02 --> Config Class Initialized
INFO - 2023-04-21 07:53:02 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:53:02 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:53:02 --> Utf8 Class Initialized
INFO - 2023-04-21 07:53:02 --> URI Class Initialized
INFO - 2023-04-21 07:53:02 --> Router Class Initialized
INFO - 2023-04-21 07:53:02 --> Output Class Initialized
INFO - 2023-04-21 07:53:02 --> Security Class Initialized
DEBUG - 2023-04-21 07:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:53:02 --> Input Class Initialized
INFO - 2023-04-21 07:53:02 --> Language Class Initialized
INFO - 2023-04-21 07:53:02 --> Language Class Initialized
INFO - 2023-04-21 07:53:02 --> Config Class Initialized
INFO - 2023-04-21 07:53:02 --> Loader Class Initialized
INFO - 2023-04-21 07:53:02 --> Helper loaded: url_helper
INFO - 2023-04-21 07:53:02 --> Helper loaded: file_helper
INFO - 2023-04-21 07:53:02 --> Helper loaded: form_helper
INFO - 2023-04-21 07:53:02 --> Helper loaded: my_helper
INFO - 2023-04-21 07:53:02 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:53:02 --> Controller Class Initialized
DEBUG - 2023-04-21 07:53:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:53:03 --> Final output sent to browser
DEBUG - 2023-04-21 07:53:03 --> Total execution time: 1.1377
INFO - 2023-04-21 07:55:21 --> Config Class Initialized
INFO - 2023-04-21 07:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:55:21 --> Utf8 Class Initialized
INFO - 2023-04-21 07:55:21 --> URI Class Initialized
INFO - 2023-04-21 07:55:21 --> Router Class Initialized
INFO - 2023-04-21 07:55:21 --> Output Class Initialized
INFO - 2023-04-21 07:55:21 --> Security Class Initialized
DEBUG - 2023-04-21 07:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:55:21 --> Input Class Initialized
INFO - 2023-04-21 07:55:21 --> Language Class Initialized
INFO - 2023-04-21 07:55:21 --> Language Class Initialized
INFO - 2023-04-21 07:55:21 --> Config Class Initialized
INFO - 2023-04-21 07:55:21 --> Loader Class Initialized
INFO - 2023-04-21 07:55:21 --> Helper loaded: url_helper
INFO - 2023-04-21 07:55:21 --> Helper loaded: file_helper
INFO - 2023-04-21 07:55:21 --> Helper loaded: form_helper
INFO - 2023-04-21 07:55:21 --> Helper loaded: my_helper
INFO - 2023-04-21 07:55:21 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:55:21 --> Controller Class Initialized
DEBUG - 2023-04-21 07:55:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:55:22 --> Final output sent to browser
DEBUG - 2023-04-21 07:55:22 --> Total execution time: 1.0815
INFO - 2023-04-21 07:56:00 --> Config Class Initialized
INFO - 2023-04-21 07:56:00 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:56:00 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:56:00 --> Utf8 Class Initialized
INFO - 2023-04-21 07:56:00 --> URI Class Initialized
INFO - 2023-04-21 07:56:00 --> Router Class Initialized
INFO - 2023-04-21 07:56:00 --> Output Class Initialized
INFO - 2023-04-21 07:56:00 --> Security Class Initialized
DEBUG - 2023-04-21 07:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:56:00 --> Input Class Initialized
INFO - 2023-04-21 07:56:00 --> Language Class Initialized
INFO - 2023-04-21 07:56:00 --> Language Class Initialized
INFO - 2023-04-21 07:56:00 --> Config Class Initialized
INFO - 2023-04-21 07:56:00 --> Loader Class Initialized
INFO - 2023-04-21 07:56:00 --> Helper loaded: url_helper
INFO - 2023-04-21 07:56:00 --> Helper loaded: file_helper
INFO - 2023-04-21 07:56:00 --> Helper loaded: form_helper
INFO - 2023-04-21 07:56:00 --> Helper loaded: my_helper
INFO - 2023-04-21 07:56:00 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:56:00 --> Controller Class Initialized
DEBUG - 2023-04-21 07:56:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:56:01 --> Final output sent to browser
DEBUG - 2023-04-21 07:56:01 --> Total execution time: 1.1632
INFO - 2023-04-21 07:56:17 --> Config Class Initialized
INFO - 2023-04-21 07:56:17 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:56:17 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:56:17 --> Utf8 Class Initialized
INFO - 2023-04-21 07:56:17 --> URI Class Initialized
INFO - 2023-04-21 07:56:17 --> Router Class Initialized
INFO - 2023-04-21 07:56:17 --> Output Class Initialized
INFO - 2023-04-21 07:56:17 --> Security Class Initialized
DEBUG - 2023-04-21 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:56:17 --> Input Class Initialized
INFO - 2023-04-21 07:56:17 --> Language Class Initialized
INFO - 2023-04-21 07:56:17 --> Language Class Initialized
INFO - 2023-04-21 07:56:17 --> Config Class Initialized
INFO - 2023-04-21 07:56:17 --> Loader Class Initialized
INFO - 2023-04-21 07:56:17 --> Helper loaded: url_helper
INFO - 2023-04-21 07:56:17 --> Helper loaded: file_helper
INFO - 2023-04-21 07:56:17 --> Helper loaded: form_helper
INFO - 2023-04-21 07:56:17 --> Helper loaded: my_helper
INFO - 2023-04-21 07:56:17 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:56:17 --> Controller Class Initialized
DEBUG - 2023-04-21 07:56:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:56:18 --> Final output sent to browser
DEBUG - 2023-04-21 07:56:18 --> Total execution time: 1.1156
INFO - 2023-04-21 07:56:39 --> Config Class Initialized
INFO - 2023-04-21 07:56:39 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:56:39 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:56:39 --> Utf8 Class Initialized
INFO - 2023-04-21 07:56:39 --> URI Class Initialized
INFO - 2023-04-21 07:56:39 --> Router Class Initialized
INFO - 2023-04-21 07:56:39 --> Output Class Initialized
INFO - 2023-04-21 07:56:39 --> Security Class Initialized
DEBUG - 2023-04-21 07:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:56:39 --> Input Class Initialized
INFO - 2023-04-21 07:56:39 --> Language Class Initialized
INFO - 2023-04-21 07:56:39 --> Language Class Initialized
INFO - 2023-04-21 07:56:39 --> Config Class Initialized
INFO - 2023-04-21 07:56:39 --> Loader Class Initialized
INFO - 2023-04-21 07:56:39 --> Helper loaded: url_helper
INFO - 2023-04-21 07:56:39 --> Helper loaded: file_helper
INFO - 2023-04-21 07:56:39 --> Helper loaded: form_helper
INFO - 2023-04-21 07:56:39 --> Helper loaded: my_helper
INFO - 2023-04-21 07:56:39 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:56:39 --> Controller Class Initialized
DEBUG - 2023-04-21 07:56:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-04-21 07:56:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 07:56:39 --> Final output sent to browser
DEBUG - 2023-04-21 07:56:39 --> Total execution time: 0.0623
INFO - 2023-04-21 07:56:46 --> Config Class Initialized
INFO - 2023-04-21 07:56:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:56:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:56:46 --> Utf8 Class Initialized
INFO - 2023-04-21 07:56:46 --> URI Class Initialized
INFO - 2023-04-21 07:56:46 --> Router Class Initialized
INFO - 2023-04-21 07:56:46 --> Output Class Initialized
INFO - 2023-04-21 07:56:46 --> Security Class Initialized
DEBUG - 2023-04-21 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:56:46 --> Input Class Initialized
INFO - 2023-04-21 07:56:46 --> Language Class Initialized
INFO - 2023-04-21 07:56:46 --> Language Class Initialized
INFO - 2023-04-21 07:56:46 --> Config Class Initialized
INFO - 2023-04-21 07:56:46 --> Loader Class Initialized
INFO - 2023-04-21 07:56:46 --> Helper loaded: url_helper
INFO - 2023-04-21 07:56:46 --> Helper loaded: file_helper
INFO - 2023-04-21 07:56:46 --> Helper loaded: form_helper
INFO - 2023-04-21 07:56:46 --> Helper loaded: my_helper
INFO - 2023-04-21 07:56:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:56:46 --> Controller Class Initialized
INFO - 2023-04-21 07:56:46 --> Final output sent to browser
DEBUG - 2023-04-21 07:56:46 --> Total execution time: 0.0574
INFO - 2023-04-21 07:56:48 --> Config Class Initialized
INFO - 2023-04-21 07:56:48 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:56:48 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:56:48 --> Utf8 Class Initialized
INFO - 2023-04-21 07:56:48 --> URI Class Initialized
INFO - 2023-04-21 07:56:48 --> Router Class Initialized
INFO - 2023-04-21 07:56:48 --> Output Class Initialized
INFO - 2023-04-21 07:56:48 --> Security Class Initialized
DEBUG - 2023-04-21 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:56:48 --> Input Class Initialized
INFO - 2023-04-21 07:56:48 --> Language Class Initialized
INFO - 2023-04-21 07:56:48 --> Language Class Initialized
INFO - 2023-04-21 07:56:48 --> Config Class Initialized
INFO - 2023-04-21 07:56:48 --> Loader Class Initialized
INFO - 2023-04-21 07:56:48 --> Helper loaded: url_helper
INFO - 2023-04-21 07:56:48 --> Helper loaded: file_helper
INFO - 2023-04-21 07:56:48 --> Helper loaded: form_helper
INFO - 2023-04-21 07:56:48 --> Helper loaded: my_helper
INFO - 2023-04-21 07:56:48 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:56:48 --> Controller Class Initialized
DEBUG - 2023-04-21 07:56:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:56:49 --> Final output sent to browser
DEBUG - 2023-04-21 07:56:49 --> Total execution time: 1.1892
INFO - 2023-04-21 07:57:37 --> Config Class Initialized
INFO - 2023-04-21 07:57:37 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:57:37 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:57:37 --> Utf8 Class Initialized
INFO - 2023-04-21 07:57:37 --> URI Class Initialized
INFO - 2023-04-21 07:57:37 --> Router Class Initialized
INFO - 2023-04-21 07:57:37 --> Output Class Initialized
INFO - 2023-04-21 07:57:37 --> Security Class Initialized
DEBUG - 2023-04-21 07:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:57:37 --> Input Class Initialized
INFO - 2023-04-21 07:57:37 --> Language Class Initialized
INFO - 2023-04-21 07:57:37 --> Language Class Initialized
INFO - 2023-04-21 07:57:37 --> Config Class Initialized
INFO - 2023-04-21 07:57:37 --> Loader Class Initialized
INFO - 2023-04-21 07:57:37 --> Helper loaded: url_helper
INFO - 2023-04-21 07:57:37 --> Helper loaded: file_helper
INFO - 2023-04-21 07:57:37 --> Helper loaded: form_helper
INFO - 2023-04-21 07:57:37 --> Helper loaded: my_helper
INFO - 2023-04-21 07:57:37 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:57:37 --> Controller Class Initialized
DEBUG - 2023-04-21 07:57:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:57:38 --> Final output sent to browser
DEBUG - 2023-04-21 07:57:38 --> Total execution time: 1.1179
INFO - 2023-04-21 07:58:23 --> Config Class Initialized
INFO - 2023-04-21 07:58:23 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:58:23 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:58:23 --> Utf8 Class Initialized
INFO - 2023-04-21 07:58:23 --> URI Class Initialized
INFO - 2023-04-21 07:58:23 --> Router Class Initialized
INFO - 2023-04-21 07:58:23 --> Output Class Initialized
INFO - 2023-04-21 07:58:23 --> Security Class Initialized
DEBUG - 2023-04-21 07:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:58:23 --> Input Class Initialized
INFO - 2023-04-21 07:58:23 --> Language Class Initialized
INFO - 2023-04-21 07:58:23 --> Language Class Initialized
INFO - 2023-04-21 07:58:23 --> Config Class Initialized
INFO - 2023-04-21 07:58:23 --> Loader Class Initialized
INFO - 2023-04-21 07:58:23 --> Helper loaded: url_helper
INFO - 2023-04-21 07:58:23 --> Helper loaded: file_helper
INFO - 2023-04-21 07:58:23 --> Helper loaded: form_helper
INFO - 2023-04-21 07:58:23 --> Helper loaded: my_helper
INFO - 2023-04-21 07:58:23 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:58:23 --> Controller Class Initialized
DEBUG - 2023-04-21 07:58:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:58:24 --> Final output sent to browser
DEBUG - 2023-04-21 07:58:24 --> Total execution time: 1.1620
INFO - 2023-04-21 07:58:36 --> Config Class Initialized
INFO - 2023-04-21 07:58:36 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:58:36 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:58:36 --> Utf8 Class Initialized
INFO - 2023-04-21 07:58:36 --> URI Class Initialized
INFO - 2023-04-21 07:58:36 --> Router Class Initialized
INFO - 2023-04-21 07:58:36 --> Output Class Initialized
INFO - 2023-04-21 07:58:36 --> Security Class Initialized
DEBUG - 2023-04-21 07:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:58:36 --> Input Class Initialized
INFO - 2023-04-21 07:58:36 --> Language Class Initialized
INFO - 2023-04-21 07:58:36 --> Language Class Initialized
INFO - 2023-04-21 07:58:36 --> Config Class Initialized
INFO - 2023-04-21 07:58:36 --> Loader Class Initialized
INFO - 2023-04-21 07:58:36 --> Helper loaded: url_helper
INFO - 2023-04-21 07:58:36 --> Helper loaded: file_helper
INFO - 2023-04-21 07:58:36 --> Helper loaded: form_helper
INFO - 2023-04-21 07:58:36 --> Helper loaded: my_helper
INFO - 2023-04-21 07:58:36 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:58:36 --> Controller Class Initialized
DEBUG - 2023-04-21 07:58:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:58:37 --> Final output sent to browser
DEBUG - 2023-04-21 07:58:37 --> Total execution time: 1.0956
INFO - 2023-04-21 07:58:45 --> Config Class Initialized
INFO - 2023-04-21 07:58:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:58:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:58:45 --> Utf8 Class Initialized
INFO - 2023-04-21 07:58:45 --> URI Class Initialized
INFO - 2023-04-21 07:58:45 --> Router Class Initialized
INFO - 2023-04-21 07:58:45 --> Output Class Initialized
INFO - 2023-04-21 07:58:45 --> Security Class Initialized
DEBUG - 2023-04-21 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:58:45 --> Input Class Initialized
INFO - 2023-04-21 07:58:45 --> Language Class Initialized
INFO - 2023-04-21 07:58:45 --> Language Class Initialized
INFO - 2023-04-21 07:58:45 --> Config Class Initialized
INFO - 2023-04-21 07:58:45 --> Loader Class Initialized
INFO - 2023-04-21 07:58:45 --> Helper loaded: url_helper
INFO - 2023-04-21 07:58:45 --> Helper loaded: file_helper
INFO - 2023-04-21 07:58:45 --> Helper loaded: form_helper
INFO - 2023-04-21 07:58:45 --> Helper loaded: my_helper
INFO - 2023-04-21 07:58:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:58:45 --> Controller Class Initialized
DEBUG - 2023-04-21 07:58:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:58:46 --> Final output sent to browser
DEBUG - 2023-04-21 07:58:46 --> Total execution time: 1.1529
INFO - 2023-04-21 07:58:53 --> Config Class Initialized
INFO - 2023-04-21 07:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:58:53 --> Utf8 Class Initialized
INFO - 2023-04-21 07:58:53 --> URI Class Initialized
INFO - 2023-04-21 07:58:53 --> Router Class Initialized
INFO - 2023-04-21 07:58:53 --> Output Class Initialized
INFO - 2023-04-21 07:58:53 --> Security Class Initialized
DEBUG - 2023-04-21 07:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:58:53 --> Input Class Initialized
INFO - 2023-04-21 07:58:53 --> Language Class Initialized
INFO - 2023-04-21 07:58:53 --> Language Class Initialized
INFO - 2023-04-21 07:58:53 --> Config Class Initialized
INFO - 2023-04-21 07:58:53 --> Loader Class Initialized
INFO - 2023-04-21 07:58:53 --> Helper loaded: url_helper
INFO - 2023-04-21 07:58:53 --> Helper loaded: file_helper
INFO - 2023-04-21 07:58:53 --> Helper loaded: form_helper
INFO - 2023-04-21 07:58:53 --> Helper loaded: my_helper
INFO - 2023-04-21 07:58:53 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:58:53 --> Controller Class Initialized
DEBUG - 2023-04-21 07:58:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:58:54 --> Final output sent to browser
DEBUG - 2023-04-21 07:58:54 --> Total execution time: 1.1588
INFO - 2023-04-21 07:59:03 --> Config Class Initialized
INFO - 2023-04-21 07:59:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:59:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:59:03 --> Utf8 Class Initialized
INFO - 2023-04-21 07:59:03 --> URI Class Initialized
INFO - 2023-04-21 07:59:03 --> Router Class Initialized
INFO - 2023-04-21 07:59:03 --> Output Class Initialized
INFO - 2023-04-21 07:59:03 --> Security Class Initialized
DEBUG - 2023-04-21 07:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:59:03 --> Input Class Initialized
INFO - 2023-04-21 07:59:03 --> Language Class Initialized
INFO - 2023-04-21 07:59:03 --> Language Class Initialized
INFO - 2023-04-21 07:59:03 --> Config Class Initialized
INFO - 2023-04-21 07:59:03 --> Loader Class Initialized
INFO - 2023-04-21 07:59:03 --> Helper loaded: url_helper
INFO - 2023-04-21 07:59:03 --> Helper loaded: file_helper
INFO - 2023-04-21 07:59:03 --> Helper loaded: form_helper
INFO - 2023-04-21 07:59:03 --> Helper loaded: my_helper
INFO - 2023-04-21 07:59:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:59:03 --> Controller Class Initialized
DEBUG - 2023-04-21 07:59:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:59:05 --> Final output sent to browser
DEBUG - 2023-04-21 07:59:05 --> Total execution time: 1.1007
INFO - 2023-04-21 07:59:13 --> Config Class Initialized
INFO - 2023-04-21 07:59:13 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:59:13 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:59:13 --> Utf8 Class Initialized
INFO - 2023-04-21 07:59:13 --> URI Class Initialized
INFO - 2023-04-21 07:59:13 --> Router Class Initialized
INFO - 2023-04-21 07:59:13 --> Output Class Initialized
INFO - 2023-04-21 07:59:13 --> Security Class Initialized
DEBUG - 2023-04-21 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:59:13 --> Input Class Initialized
INFO - 2023-04-21 07:59:13 --> Language Class Initialized
INFO - 2023-04-21 07:59:14 --> Language Class Initialized
INFO - 2023-04-21 07:59:14 --> Config Class Initialized
INFO - 2023-04-21 07:59:14 --> Loader Class Initialized
INFO - 2023-04-21 07:59:14 --> Helper loaded: url_helper
INFO - 2023-04-21 07:59:14 --> Helper loaded: file_helper
INFO - 2023-04-21 07:59:14 --> Helper loaded: form_helper
INFO - 2023-04-21 07:59:14 --> Helper loaded: my_helper
INFO - 2023-04-21 07:59:14 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:59:14 --> Controller Class Initialized
DEBUG - 2023-04-21 07:59:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 07:59:15 --> Final output sent to browser
DEBUG - 2023-04-21 07:59:15 --> Total execution time: 1.2076
INFO - 2023-04-21 07:59:56 --> Config Class Initialized
INFO - 2023-04-21 07:59:56 --> Hooks Class Initialized
DEBUG - 2023-04-21 07:59:56 --> UTF-8 Support Enabled
INFO - 2023-04-21 07:59:56 --> Utf8 Class Initialized
INFO - 2023-04-21 07:59:56 --> URI Class Initialized
INFO - 2023-04-21 07:59:56 --> Router Class Initialized
INFO - 2023-04-21 07:59:56 --> Output Class Initialized
INFO - 2023-04-21 07:59:56 --> Security Class Initialized
DEBUG - 2023-04-21 07:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 07:59:56 --> Input Class Initialized
INFO - 2023-04-21 07:59:56 --> Language Class Initialized
INFO - 2023-04-21 07:59:56 --> Language Class Initialized
INFO - 2023-04-21 07:59:56 --> Config Class Initialized
INFO - 2023-04-21 07:59:56 --> Loader Class Initialized
INFO - 2023-04-21 07:59:56 --> Helper loaded: url_helper
INFO - 2023-04-21 07:59:56 --> Helper loaded: file_helper
INFO - 2023-04-21 07:59:56 --> Helper loaded: form_helper
INFO - 2023-04-21 07:59:56 --> Helper loaded: my_helper
INFO - 2023-04-21 07:59:56 --> Database Driver Class Initialized
DEBUG - 2023-04-21 07:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 07:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 07:59:56 --> Controller Class Initialized
DEBUG - 2023-04-21 07:59:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-04-21 07:59:57 --> Severity: error --> Exception: The html tag [center] is not known by Html2Pdf. You can create it and push it on the Html2Pdf GitHub project. C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 1441
ERROR - 2023-04-21 07:59:57 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_fe2c25f6b4abd0647636c775c933a001_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-04-21 07:59:57 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_fe2c25f6b4abd0647636c775c933a001_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-04-21 07:59:57 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_fe2c25f6b4abd0647636c775c933a001_imgmask_alpha_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-04-21 07:59:57 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_fe2c25f6b4abd0647636c775c933a001_imgmask_plain_7de96fd9f6bd1ee181eca7a687e2e5f9): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
INFO - 2023-04-21 08:00:06 --> Config Class Initialized
INFO - 2023-04-21 08:00:06 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:00:06 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:00:06 --> Utf8 Class Initialized
INFO - 2023-04-21 08:00:06 --> URI Class Initialized
INFO - 2023-04-21 08:00:06 --> Router Class Initialized
INFO - 2023-04-21 08:00:06 --> Output Class Initialized
INFO - 2023-04-21 08:00:06 --> Security Class Initialized
DEBUG - 2023-04-21 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:00:06 --> Input Class Initialized
INFO - 2023-04-21 08:00:06 --> Language Class Initialized
INFO - 2023-04-21 08:00:06 --> Language Class Initialized
INFO - 2023-04-21 08:00:06 --> Config Class Initialized
INFO - 2023-04-21 08:00:06 --> Loader Class Initialized
INFO - 2023-04-21 08:00:06 --> Helper loaded: url_helper
INFO - 2023-04-21 08:00:06 --> Helper loaded: file_helper
INFO - 2023-04-21 08:00:06 --> Helper loaded: form_helper
INFO - 2023-04-21 08:00:06 --> Helper loaded: my_helper
INFO - 2023-04-21 08:00:06 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:00:06 --> Controller Class Initialized
DEBUG - 2023-04-21 08:00:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:00:07 --> Final output sent to browser
DEBUG - 2023-04-21 08:00:07 --> Total execution time: 1.1015
INFO - 2023-04-21 08:01:01 --> Config Class Initialized
INFO - 2023-04-21 08:01:01 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:01:01 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:01:01 --> Utf8 Class Initialized
INFO - 2023-04-21 08:01:01 --> URI Class Initialized
INFO - 2023-04-21 08:01:01 --> Router Class Initialized
INFO - 2023-04-21 08:01:01 --> Output Class Initialized
INFO - 2023-04-21 08:01:01 --> Security Class Initialized
DEBUG - 2023-04-21 08:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:01:01 --> Input Class Initialized
INFO - 2023-04-21 08:01:01 --> Language Class Initialized
INFO - 2023-04-21 08:01:01 --> Language Class Initialized
INFO - 2023-04-21 08:01:01 --> Config Class Initialized
INFO - 2023-04-21 08:01:01 --> Loader Class Initialized
INFO - 2023-04-21 08:01:01 --> Helper loaded: url_helper
INFO - 2023-04-21 08:01:01 --> Helper loaded: file_helper
INFO - 2023-04-21 08:01:01 --> Helper loaded: form_helper
INFO - 2023-04-21 08:01:01 --> Helper loaded: my_helper
INFO - 2023-04-21 08:01:01 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:01:01 --> Controller Class Initialized
DEBUG - 2023-04-21 08:01:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:01:02 --> Final output sent to browser
DEBUG - 2023-04-21 08:01:02 --> Total execution time: 1.1936
INFO - 2023-04-21 08:01:20 --> Config Class Initialized
INFO - 2023-04-21 08:01:20 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:01:20 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:01:20 --> Utf8 Class Initialized
INFO - 2023-04-21 08:01:20 --> URI Class Initialized
INFO - 2023-04-21 08:01:20 --> Router Class Initialized
INFO - 2023-04-21 08:01:20 --> Output Class Initialized
INFO - 2023-04-21 08:01:20 --> Security Class Initialized
DEBUG - 2023-04-21 08:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:01:20 --> Input Class Initialized
INFO - 2023-04-21 08:01:20 --> Language Class Initialized
INFO - 2023-04-21 08:01:20 --> Language Class Initialized
INFO - 2023-04-21 08:01:20 --> Config Class Initialized
INFO - 2023-04-21 08:01:20 --> Loader Class Initialized
INFO - 2023-04-21 08:01:20 --> Helper loaded: url_helper
INFO - 2023-04-21 08:01:20 --> Helper loaded: file_helper
INFO - 2023-04-21 08:01:20 --> Helper loaded: form_helper
INFO - 2023-04-21 08:01:20 --> Helper loaded: my_helper
INFO - 2023-04-21 08:01:20 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:01:20 --> Controller Class Initialized
DEBUG - 2023-04-21 08:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:01:21 --> Final output sent to browser
DEBUG - 2023-04-21 08:01:21 --> Total execution time: 1.1542
INFO - 2023-04-21 08:02:42 --> Config Class Initialized
INFO - 2023-04-21 08:02:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:02:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:02:42 --> Utf8 Class Initialized
INFO - 2023-04-21 08:02:42 --> URI Class Initialized
INFO - 2023-04-21 08:02:42 --> Router Class Initialized
INFO - 2023-04-21 08:02:42 --> Output Class Initialized
INFO - 2023-04-21 08:02:42 --> Security Class Initialized
DEBUG - 2023-04-21 08:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:02:42 --> Input Class Initialized
INFO - 2023-04-21 08:02:42 --> Language Class Initialized
INFO - 2023-04-21 08:02:42 --> Language Class Initialized
INFO - 2023-04-21 08:02:42 --> Config Class Initialized
INFO - 2023-04-21 08:02:42 --> Loader Class Initialized
INFO - 2023-04-21 08:02:42 --> Helper loaded: url_helper
INFO - 2023-04-21 08:02:42 --> Helper loaded: file_helper
INFO - 2023-04-21 08:02:42 --> Helper loaded: form_helper
INFO - 2023-04-21 08:02:42 --> Helper loaded: my_helper
INFO - 2023-04-21 08:02:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:02:42 --> Controller Class Initialized
DEBUG - 2023-04-21 08:02:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:02:44 --> Final output sent to browser
DEBUG - 2023-04-21 08:02:44 --> Total execution time: 1.2965
INFO - 2023-04-21 08:02:58 --> Config Class Initialized
INFO - 2023-04-21 08:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:02:58 --> Utf8 Class Initialized
INFO - 2023-04-21 08:02:58 --> URI Class Initialized
INFO - 2023-04-21 08:02:58 --> Router Class Initialized
INFO - 2023-04-21 08:02:58 --> Output Class Initialized
INFO - 2023-04-21 08:02:58 --> Security Class Initialized
DEBUG - 2023-04-21 08:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:02:58 --> Input Class Initialized
INFO - 2023-04-21 08:02:58 --> Language Class Initialized
INFO - 2023-04-21 08:02:58 --> Language Class Initialized
INFO - 2023-04-21 08:02:58 --> Config Class Initialized
INFO - 2023-04-21 08:02:58 --> Loader Class Initialized
INFO - 2023-04-21 08:02:58 --> Helper loaded: url_helper
INFO - 2023-04-21 08:02:58 --> Helper loaded: file_helper
INFO - 2023-04-21 08:02:58 --> Helper loaded: form_helper
INFO - 2023-04-21 08:02:58 --> Helper loaded: my_helper
INFO - 2023-04-21 08:02:58 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:02:58 --> Controller Class Initialized
DEBUG - 2023-04-21 08:02:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:02:59 --> Final output sent to browser
DEBUG - 2023-04-21 08:02:59 --> Total execution time: 1.1562
INFO - 2023-04-21 08:03:06 --> Config Class Initialized
INFO - 2023-04-21 08:03:06 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:03:06 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:03:06 --> Utf8 Class Initialized
INFO - 2023-04-21 08:03:06 --> URI Class Initialized
INFO - 2023-04-21 08:03:06 --> Router Class Initialized
INFO - 2023-04-21 08:03:06 --> Output Class Initialized
INFO - 2023-04-21 08:03:06 --> Security Class Initialized
DEBUG - 2023-04-21 08:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:03:06 --> Input Class Initialized
INFO - 2023-04-21 08:03:06 --> Language Class Initialized
INFO - 2023-04-21 08:03:06 --> Language Class Initialized
INFO - 2023-04-21 08:03:06 --> Config Class Initialized
INFO - 2023-04-21 08:03:06 --> Loader Class Initialized
INFO - 2023-04-21 08:03:06 --> Helper loaded: url_helper
INFO - 2023-04-21 08:03:06 --> Helper loaded: file_helper
INFO - 2023-04-21 08:03:06 --> Helper loaded: form_helper
INFO - 2023-04-21 08:03:06 --> Helper loaded: my_helper
INFO - 2023-04-21 08:03:06 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:03:06 --> Controller Class Initialized
DEBUG - 2023-04-21 08:03:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:03:07 --> Final output sent to browser
DEBUG - 2023-04-21 08:03:07 --> Total execution time: 1.1481
INFO - 2023-04-21 08:11:11 --> Config Class Initialized
INFO - 2023-04-21 08:11:11 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:11:11 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:11:11 --> Utf8 Class Initialized
INFO - 2023-04-21 08:11:11 --> URI Class Initialized
INFO - 2023-04-21 08:11:11 --> Router Class Initialized
INFO - 2023-04-21 08:11:11 --> Output Class Initialized
INFO - 2023-04-21 08:11:11 --> Security Class Initialized
DEBUG - 2023-04-21 08:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:11:11 --> Input Class Initialized
INFO - 2023-04-21 08:11:11 --> Language Class Initialized
INFO - 2023-04-21 08:11:11 --> Language Class Initialized
INFO - 2023-04-21 08:11:11 --> Config Class Initialized
INFO - 2023-04-21 08:11:11 --> Loader Class Initialized
INFO - 2023-04-21 08:11:11 --> Helper loaded: url_helper
INFO - 2023-04-21 08:11:11 --> Helper loaded: file_helper
INFO - 2023-04-21 08:11:11 --> Helper loaded: form_helper
INFO - 2023-04-21 08:11:11 --> Helper loaded: my_helper
INFO - 2023-04-21 08:11:11 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:11:11 --> Controller Class Initialized
DEBUG - 2023-04-21 08:11:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:11:12 --> Final output sent to browser
DEBUG - 2023-04-21 08:11:12 --> Total execution time: 1.2318
INFO - 2023-04-21 08:12:14 --> Config Class Initialized
INFO - 2023-04-21 08:12:14 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:12:14 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:12:14 --> Utf8 Class Initialized
INFO - 2023-04-21 08:12:14 --> URI Class Initialized
INFO - 2023-04-21 08:12:14 --> Router Class Initialized
INFO - 2023-04-21 08:12:14 --> Output Class Initialized
INFO - 2023-04-21 08:12:14 --> Security Class Initialized
DEBUG - 2023-04-21 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:12:14 --> Input Class Initialized
INFO - 2023-04-21 08:12:14 --> Language Class Initialized
INFO - 2023-04-21 08:12:14 --> Language Class Initialized
INFO - 2023-04-21 08:12:14 --> Config Class Initialized
INFO - 2023-04-21 08:12:14 --> Loader Class Initialized
INFO - 2023-04-21 08:12:14 --> Helper loaded: url_helper
INFO - 2023-04-21 08:12:14 --> Helper loaded: file_helper
INFO - 2023-04-21 08:12:14 --> Helper loaded: form_helper
INFO - 2023-04-21 08:12:14 --> Helper loaded: my_helper
INFO - 2023-04-21 08:12:14 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:12:14 --> Controller Class Initialized
DEBUG - 2023-04-21 08:12:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:12:15 --> Final output sent to browser
DEBUG - 2023-04-21 08:12:15 --> Total execution time: 1.2314
INFO - 2023-04-21 08:12:34 --> Config Class Initialized
INFO - 2023-04-21 08:12:34 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:12:34 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:12:34 --> Utf8 Class Initialized
INFO - 2023-04-21 08:12:34 --> URI Class Initialized
INFO - 2023-04-21 08:12:34 --> Router Class Initialized
INFO - 2023-04-21 08:12:34 --> Output Class Initialized
INFO - 2023-04-21 08:12:34 --> Security Class Initialized
DEBUG - 2023-04-21 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:12:34 --> Input Class Initialized
INFO - 2023-04-21 08:12:34 --> Language Class Initialized
INFO - 2023-04-21 08:12:34 --> Language Class Initialized
INFO - 2023-04-21 08:12:34 --> Config Class Initialized
INFO - 2023-04-21 08:12:34 --> Loader Class Initialized
INFO - 2023-04-21 08:12:34 --> Helper loaded: url_helper
INFO - 2023-04-21 08:12:34 --> Helper loaded: file_helper
INFO - 2023-04-21 08:12:34 --> Helper loaded: form_helper
INFO - 2023-04-21 08:12:34 --> Helper loaded: my_helper
INFO - 2023-04-21 08:12:34 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:12:34 --> Controller Class Initialized
DEBUG - 2023-04-21 08:12:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:12:35 --> Final output sent to browser
DEBUG - 2023-04-21 08:12:35 --> Total execution time: 1.2039
INFO - 2023-04-21 08:13:23 --> Config Class Initialized
INFO - 2023-04-21 08:13:23 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:13:23 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:13:23 --> Utf8 Class Initialized
INFO - 2023-04-21 08:13:23 --> URI Class Initialized
INFO - 2023-04-21 08:13:23 --> Router Class Initialized
INFO - 2023-04-21 08:13:23 --> Output Class Initialized
INFO - 2023-04-21 08:13:23 --> Security Class Initialized
DEBUG - 2023-04-21 08:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:13:23 --> Input Class Initialized
INFO - 2023-04-21 08:13:23 --> Language Class Initialized
INFO - 2023-04-21 08:13:23 --> Language Class Initialized
INFO - 2023-04-21 08:13:23 --> Config Class Initialized
INFO - 2023-04-21 08:13:23 --> Loader Class Initialized
INFO - 2023-04-21 08:13:23 --> Helper loaded: url_helper
INFO - 2023-04-21 08:13:23 --> Helper loaded: file_helper
INFO - 2023-04-21 08:13:23 --> Helper loaded: form_helper
INFO - 2023-04-21 08:13:23 --> Helper loaded: my_helper
INFO - 2023-04-21 08:13:23 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:13:23 --> Controller Class Initialized
DEBUG - 2023-04-21 08:13:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:13:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:13:23 --> Final output sent to browser
DEBUG - 2023-04-21 08:13:23 --> Total execution time: 0.0593
INFO - 2023-04-21 08:13:40 --> Config Class Initialized
INFO - 2023-04-21 08:13:40 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:13:40 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:13:40 --> Utf8 Class Initialized
INFO - 2023-04-21 08:13:40 --> URI Class Initialized
INFO - 2023-04-21 08:13:40 --> Router Class Initialized
INFO - 2023-04-21 08:13:40 --> Output Class Initialized
INFO - 2023-04-21 08:13:40 --> Security Class Initialized
DEBUG - 2023-04-21 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:13:40 --> Input Class Initialized
INFO - 2023-04-21 08:13:40 --> Language Class Initialized
INFO - 2023-04-21 08:13:40 --> Language Class Initialized
INFO - 2023-04-21 08:13:40 --> Config Class Initialized
INFO - 2023-04-21 08:13:40 --> Loader Class Initialized
INFO - 2023-04-21 08:13:40 --> Helper loaded: url_helper
INFO - 2023-04-21 08:13:40 --> Helper loaded: file_helper
INFO - 2023-04-21 08:13:40 --> Helper loaded: form_helper
INFO - 2023-04-21 08:13:40 --> Helper loaded: my_helper
INFO - 2023-04-21 08:13:40 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:13:40 --> Controller Class Initialized
INFO - 2023-04-21 08:13:40 --> Final output sent to browser
DEBUG - 2023-04-21 08:13:40 --> Total execution time: 0.0548
INFO - 2023-04-21 08:16:08 --> Config Class Initialized
INFO - 2023-04-21 08:16:08 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:16:08 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:16:08 --> Utf8 Class Initialized
INFO - 2023-04-21 08:16:08 --> URI Class Initialized
INFO - 2023-04-21 08:16:08 --> Router Class Initialized
INFO - 2023-04-21 08:16:08 --> Output Class Initialized
INFO - 2023-04-21 08:16:08 --> Security Class Initialized
DEBUG - 2023-04-21 08:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:16:08 --> Input Class Initialized
INFO - 2023-04-21 08:16:08 --> Language Class Initialized
INFO - 2023-04-21 08:16:08 --> Language Class Initialized
INFO - 2023-04-21 08:16:08 --> Config Class Initialized
INFO - 2023-04-21 08:16:08 --> Loader Class Initialized
INFO - 2023-04-21 08:16:08 --> Helper loaded: url_helper
INFO - 2023-04-21 08:16:08 --> Helper loaded: file_helper
INFO - 2023-04-21 08:16:08 --> Helper loaded: form_helper
INFO - 2023-04-21 08:16:08 --> Helper loaded: my_helper
INFO - 2023-04-21 08:16:08 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:16:08 --> Controller Class Initialized
DEBUG - 2023-04-21 08:16:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:16:09 --> Final output sent to browser
DEBUG - 2023-04-21 08:16:09 --> Total execution time: 1.2057
INFO - 2023-04-21 08:16:34 --> Config Class Initialized
INFO - 2023-04-21 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:16:34 --> Utf8 Class Initialized
INFO - 2023-04-21 08:16:34 --> URI Class Initialized
INFO - 2023-04-21 08:16:34 --> Router Class Initialized
INFO - 2023-04-21 08:16:34 --> Output Class Initialized
INFO - 2023-04-21 08:16:34 --> Security Class Initialized
DEBUG - 2023-04-21 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:16:34 --> Input Class Initialized
INFO - 2023-04-21 08:16:34 --> Language Class Initialized
INFO - 2023-04-21 08:16:35 --> Language Class Initialized
INFO - 2023-04-21 08:16:35 --> Config Class Initialized
INFO - 2023-04-21 08:16:35 --> Loader Class Initialized
INFO - 2023-04-21 08:16:35 --> Helper loaded: url_helper
INFO - 2023-04-21 08:16:35 --> Helper loaded: file_helper
INFO - 2023-04-21 08:16:35 --> Helper loaded: form_helper
INFO - 2023-04-21 08:16:35 --> Helper loaded: my_helper
INFO - 2023-04-21 08:16:35 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:16:35 --> Controller Class Initialized
DEBUG - 2023-04-21 08:16:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:16:36 --> Final output sent to browser
DEBUG - 2023-04-21 08:16:36 --> Total execution time: 1.2386
INFO - 2023-04-21 08:17:24 --> Config Class Initialized
INFO - 2023-04-21 08:17:24 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:17:24 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:17:24 --> Utf8 Class Initialized
INFO - 2023-04-21 08:17:24 --> URI Class Initialized
INFO - 2023-04-21 08:17:24 --> Router Class Initialized
INFO - 2023-04-21 08:17:24 --> Output Class Initialized
INFO - 2023-04-21 08:17:24 --> Security Class Initialized
DEBUG - 2023-04-21 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:17:24 --> Input Class Initialized
INFO - 2023-04-21 08:17:24 --> Language Class Initialized
INFO - 2023-04-21 08:17:24 --> Language Class Initialized
INFO - 2023-04-21 08:17:24 --> Config Class Initialized
INFO - 2023-04-21 08:17:24 --> Loader Class Initialized
INFO - 2023-04-21 08:17:24 --> Helper loaded: url_helper
INFO - 2023-04-21 08:17:24 --> Helper loaded: file_helper
INFO - 2023-04-21 08:17:24 --> Helper loaded: form_helper
INFO - 2023-04-21 08:17:24 --> Helper loaded: my_helper
INFO - 2023-04-21 08:17:24 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:17:24 --> Controller Class Initialized
DEBUG - 2023-04-21 08:17:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:17:25 --> Final output sent to browser
DEBUG - 2023-04-21 08:17:25 --> Total execution time: 1.2172
INFO - 2023-04-21 08:17:46 --> Config Class Initialized
INFO - 2023-04-21 08:17:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:17:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:17:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:17:46 --> URI Class Initialized
INFO - 2023-04-21 08:17:46 --> Router Class Initialized
INFO - 2023-04-21 08:17:46 --> Output Class Initialized
INFO - 2023-04-21 08:17:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:17:46 --> Input Class Initialized
INFO - 2023-04-21 08:17:46 --> Language Class Initialized
INFO - 2023-04-21 08:17:46 --> Language Class Initialized
INFO - 2023-04-21 08:17:46 --> Config Class Initialized
INFO - 2023-04-21 08:17:46 --> Loader Class Initialized
INFO - 2023-04-21 08:17:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:17:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:17:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:17:46 --> Helper loaded: my_helper
INFO - 2023-04-21 08:17:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:17:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:17:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:17:47 --> Final output sent to browser
DEBUG - 2023-04-21 08:17:47 --> Total execution time: 1.2058
INFO - 2023-04-21 08:18:49 --> Config Class Initialized
INFO - 2023-04-21 08:18:49 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:18:49 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:18:49 --> Utf8 Class Initialized
INFO - 2023-04-21 08:18:49 --> URI Class Initialized
INFO - 2023-04-21 08:18:49 --> Router Class Initialized
INFO - 2023-04-21 08:18:49 --> Output Class Initialized
INFO - 2023-04-21 08:18:49 --> Security Class Initialized
DEBUG - 2023-04-21 08:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:18:49 --> Input Class Initialized
INFO - 2023-04-21 08:18:49 --> Language Class Initialized
INFO - 2023-04-21 08:18:49 --> Language Class Initialized
INFO - 2023-04-21 08:18:49 --> Config Class Initialized
INFO - 2023-04-21 08:18:49 --> Loader Class Initialized
INFO - 2023-04-21 08:18:49 --> Helper loaded: url_helper
INFO - 2023-04-21 08:18:49 --> Helper loaded: file_helper
INFO - 2023-04-21 08:18:49 --> Helper loaded: form_helper
INFO - 2023-04-21 08:18:49 --> Helper loaded: my_helper
INFO - 2023-04-21 08:18:49 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:18:49 --> Controller Class Initialized
INFO - 2023-04-21 08:18:49 --> Final output sent to browser
DEBUG - 2023-04-21 08:18:49 --> Total execution time: 0.0569
INFO - 2023-04-21 08:18:52 --> Config Class Initialized
INFO - 2023-04-21 08:18:52 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:18:52 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:18:52 --> Utf8 Class Initialized
INFO - 2023-04-21 08:18:52 --> URI Class Initialized
INFO - 2023-04-21 08:18:52 --> Router Class Initialized
INFO - 2023-04-21 08:18:52 --> Output Class Initialized
INFO - 2023-04-21 08:18:52 --> Security Class Initialized
DEBUG - 2023-04-21 08:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:18:52 --> Input Class Initialized
INFO - 2023-04-21 08:18:52 --> Language Class Initialized
INFO - 2023-04-21 08:18:52 --> Language Class Initialized
INFO - 2023-04-21 08:18:52 --> Config Class Initialized
INFO - 2023-04-21 08:18:52 --> Loader Class Initialized
INFO - 2023-04-21 08:18:52 --> Helper loaded: url_helper
INFO - 2023-04-21 08:18:52 --> Helper loaded: file_helper
INFO - 2023-04-21 08:18:52 --> Helper loaded: form_helper
INFO - 2023-04-21 08:18:52 --> Helper loaded: my_helper
INFO - 2023-04-21 08:18:52 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:18:52 --> Controller Class Initialized
DEBUG - 2023-04-21 08:18:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:18:53 --> Final output sent to browser
DEBUG - 2023-04-21 08:18:53 --> Total execution time: 1.1324
INFO - 2023-04-21 08:19:00 --> Config Class Initialized
INFO - 2023-04-21 08:19:00 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:00 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:00 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:00 --> URI Class Initialized
INFO - 2023-04-21 08:19:00 --> Router Class Initialized
INFO - 2023-04-21 08:19:00 --> Output Class Initialized
INFO - 2023-04-21 08:19:00 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:00 --> Input Class Initialized
INFO - 2023-04-21 08:19:00 --> Language Class Initialized
INFO - 2023-04-21 08:19:00 --> Language Class Initialized
INFO - 2023-04-21 08:19:00 --> Config Class Initialized
INFO - 2023-04-21 08:19:00 --> Loader Class Initialized
INFO - 2023-04-21 08:19:00 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:00 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:00 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:00 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:00 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:00 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:19:02 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:02 --> Total execution time: 1.2026
INFO - 2023-04-21 08:19:41 --> Config Class Initialized
INFO - 2023-04-21 08:19:41 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:41 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:41 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:41 --> URI Class Initialized
INFO - 2023-04-21 08:19:41 --> Router Class Initialized
INFO - 2023-04-21 08:19:41 --> Output Class Initialized
INFO - 2023-04-21 08:19:41 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:41 --> Input Class Initialized
INFO - 2023-04-21 08:19:41 --> Language Class Initialized
INFO - 2023-04-21 08:19:41 --> Language Class Initialized
INFO - 2023-04-21 08:19:41 --> Config Class Initialized
INFO - 2023-04-21 08:19:41 --> Loader Class Initialized
INFO - 2023-04-21 08:19:41 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:41 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:41 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:41 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:41 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:41 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:41 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:41 --> Total execution time: 0.0299
INFO - 2023-04-21 08:19:42 --> Config Class Initialized
INFO - 2023-04-21 08:19:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:42 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:42 --> URI Class Initialized
INFO - 2023-04-21 08:19:42 --> Router Class Initialized
INFO - 2023-04-21 08:19:42 --> Output Class Initialized
INFO - 2023-04-21 08:19:42 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:42 --> Input Class Initialized
INFO - 2023-04-21 08:19:42 --> Language Class Initialized
INFO - 2023-04-21 08:19:42 --> Language Class Initialized
INFO - 2023-04-21 08:19:42 --> Config Class Initialized
INFO - 2023-04-21 08:19:42 --> Loader Class Initialized
INFO - 2023-04-21 08:19:42 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:42 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:42 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:42 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:42 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:42 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:42 --> Total execution time: 0.0317
INFO - 2023-04-21 08:19:43 --> Config Class Initialized
INFO - 2023-04-21 08:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:43 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:43 --> URI Class Initialized
INFO - 2023-04-21 08:19:43 --> Router Class Initialized
INFO - 2023-04-21 08:19:43 --> Output Class Initialized
INFO - 2023-04-21 08:19:43 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:43 --> Input Class Initialized
INFO - 2023-04-21 08:19:43 --> Language Class Initialized
INFO - 2023-04-21 08:19:43 --> Language Class Initialized
INFO - 2023-04-21 08:19:43 --> Config Class Initialized
INFO - 2023-04-21 08:19:43 --> Loader Class Initialized
INFO - 2023-04-21 08:19:43 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:43 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:43 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:43 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:43 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:43 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:43 --> Total execution time: 0.0302
INFO - 2023-04-21 08:19:43 --> Config Class Initialized
INFO - 2023-04-21 08:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:43 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:43 --> URI Class Initialized
INFO - 2023-04-21 08:19:43 --> Router Class Initialized
INFO - 2023-04-21 08:19:43 --> Output Class Initialized
INFO - 2023-04-21 08:19:43 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:43 --> Input Class Initialized
INFO - 2023-04-21 08:19:43 --> Language Class Initialized
INFO - 2023-04-21 08:19:43 --> Language Class Initialized
INFO - 2023-04-21 08:19:43 --> Config Class Initialized
INFO - 2023-04-21 08:19:43 --> Loader Class Initialized
INFO - 2023-04-21 08:19:43 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:43 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:43 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:43 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:43 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:43 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:43 --> Total execution time: 0.0529
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:44 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:44 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:44 --> URI Class Initialized
INFO - 2023-04-21 08:19:44 --> Router Class Initialized
INFO - 2023-04-21 08:19:44 --> Output Class Initialized
INFO - 2023-04-21 08:19:44 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:44 --> Input Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Loader Class Initialized
INFO - 2023-04-21 08:19:44 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:44 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:44 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:44 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:44 --> Total execution time: 0.0536
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:44 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:44 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:44 --> URI Class Initialized
INFO - 2023-04-21 08:19:44 --> Router Class Initialized
INFO - 2023-04-21 08:19:44 --> Output Class Initialized
INFO - 2023-04-21 08:19:44 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:44 --> Input Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Loader Class Initialized
INFO - 2023-04-21 08:19:44 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:44 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:44 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:44 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:44 --> Total execution time: 0.0471
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:44 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:44 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:44 --> URI Class Initialized
INFO - 2023-04-21 08:19:44 --> Router Class Initialized
INFO - 2023-04-21 08:19:44 --> Output Class Initialized
INFO - 2023-04-21 08:19:44 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:44 --> Input Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Loader Class Initialized
INFO - 2023-04-21 08:19:44 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:44 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:44 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:44 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:44 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:44 --> Total execution time: 0.0379
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:44 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:44 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:44 --> URI Class Initialized
INFO - 2023-04-21 08:19:44 --> Router Class Initialized
INFO - 2023-04-21 08:19:44 --> Output Class Initialized
INFO - 2023-04-21 08:19:44 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:44 --> Input Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Language Class Initialized
INFO - 2023-04-21 08:19:44 --> Config Class Initialized
INFO - 2023-04-21 08:19:44 --> Loader Class Initialized
INFO - 2023-04-21 08:19:44 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:45 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:45 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:45 --> Total execution time: 0.0478
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:45 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:45 --> URI Class Initialized
INFO - 2023-04-21 08:19:45 --> Router Class Initialized
INFO - 2023-04-21 08:19:45 --> Output Class Initialized
INFO - 2023-04-21 08:19:45 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:45 --> Input Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Loader Class Initialized
INFO - 2023-04-21 08:19:45 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:45 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:45 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:45 --> Total execution time: 0.0432
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:45 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:45 --> URI Class Initialized
INFO - 2023-04-21 08:19:45 --> Router Class Initialized
INFO - 2023-04-21 08:19:45 --> Output Class Initialized
INFO - 2023-04-21 08:19:45 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:45 --> Input Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Loader Class Initialized
INFO - 2023-04-21 08:19:45 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:45 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:45 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:45 --> Total execution time: 0.0299
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:45 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:45 --> URI Class Initialized
INFO - 2023-04-21 08:19:45 --> Router Class Initialized
INFO - 2023-04-21 08:19:45 --> Output Class Initialized
INFO - 2023-04-21 08:19:45 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:45 --> Input Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Loader Class Initialized
INFO - 2023-04-21 08:19:45 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:45 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:45 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:45 --> Total execution time: 0.0427
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:45 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:45 --> URI Class Initialized
INFO - 2023-04-21 08:19:45 --> Router Class Initialized
INFO - 2023-04-21 08:19:45 --> Output Class Initialized
INFO - 2023-04-21 08:19:45 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:45 --> Input Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Language Class Initialized
INFO - 2023-04-21 08:19:45 --> Config Class Initialized
INFO - 2023-04-21 08:19:45 --> Loader Class Initialized
INFO - 2023-04-21 08:19:45 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:45 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:45 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:45 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:45 --> Total execution time: 0.0408
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:46 --> URI Class Initialized
INFO - 2023-04-21 08:19:46 --> Router Class Initialized
INFO - 2023-04-21 08:19:46 --> Output Class Initialized
INFO - 2023-04-21 08:19:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:46 --> Input Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Loader Class Initialized
INFO - 2023-04-21 08:19:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: my_helper
DEBUG - 2023-04-21 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:46 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:46 --> Total execution time: 0.0281
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:46 --> URI Class Initialized
INFO - 2023-04-21 08:19:46 --> Router Class Initialized
INFO - 2023-04-21 08:19:46 --> Output Class Initialized
INFO - 2023-04-21 08:19:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:46 --> Input Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Loader Class Initialized
INFO - 2023-04-21 08:19:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:46 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:46 --> Total execution time: 0.0517
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:46 --> URI Class Initialized
INFO - 2023-04-21 08:19:46 --> Router Class Initialized
INFO - 2023-04-21 08:19:46 --> Output Class Initialized
INFO - 2023-04-21 08:19:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:46 --> Input Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Loader Class Initialized
INFO - 2023-04-21 08:19:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:46 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:46 --> Total execution time: 0.0303
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:46 --> URI Class Initialized
INFO - 2023-04-21 08:19:46 --> Router Class Initialized
INFO - 2023-04-21 08:19:46 --> Output Class Initialized
INFO - 2023-04-21 08:19:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:46 --> Input Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Loader Class Initialized
INFO - 2023-04-21 08:19:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:46 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:46 --> Total execution time: 0.0379
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:46 --> URI Class Initialized
INFO - 2023-04-21 08:19:46 --> Router Class Initialized
INFO - 2023-04-21 08:19:46 --> Output Class Initialized
INFO - 2023-04-21 08:19:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:46 --> Input Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Language Class Initialized
INFO - 2023-04-21 08:19:46 --> Config Class Initialized
INFO - 2023-04-21 08:19:46 --> Loader Class Initialized
INFO - 2023-04-21 08:19:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:46 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:46 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:46 --> Total execution time: 0.0298
INFO - 2023-04-21 08:19:55 --> Config Class Initialized
INFO - 2023-04-21 08:19:55 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:19:55 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:19:55 --> Utf8 Class Initialized
INFO - 2023-04-21 08:19:55 --> URI Class Initialized
INFO - 2023-04-21 08:19:55 --> Router Class Initialized
INFO - 2023-04-21 08:19:55 --> Output Class Initialized
INFO - 2023-04-21 08:19:55 --> Security Class Initialized
DEBUG - 2023-04-21 08:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:19:55 --> Input Class Initialized
INFO - 2023-04-21 08:19:55 --> Language Class Initialized
INFO - 2023-04-21 08:19:55 --> Language Class Initialized
INFO - 2023-04-21 08:19:55 --> Config Class Initialized
INFO - 2023-04-21 08:19:55 --> Loader Class Initialized
INFO - 2023-04-21 08:19:55 --> Helper loaded: url_helper
INFO - 2023-04-21 08:19:55 --> Helper loaded: file_helper
INFO - 2023-04-21 08:19:55 --> Helper loaded: form_helper
INFO - 2023-04-21 08:19:55 --> Helper loaded: my_helper
INFO - 2023-04-21 08:19:55 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:19:55 --> Controller Class Initialized
DEBUG - 2023-04-21 08:19:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:19:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:19:55 --> Final output sent to browser
DEBUG - 2023-04-21 08:19:55 --> Total execution time: 0.0407
INFO - 2023-04-21 08:20:01 --> Config Class Initialized
INFO - 2023-04-21 08:20:01 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:01 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:01 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:01 --> URI Class Initialized
INFO - 2023-04-21 08:20:01 --> Router Class Initialized
INFO - 2023-04-21 08:20:01 --> Output Class Initialized
INFO - 2023-04-21 08:20:01 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:01 --> Input Class Initialized
INFO - 2023-04-21 08:20:01 --> Language Class Initialized
INFO - 2023-04-21 08:20:01 --> Language Class Initialized
INFO - 2023-04-21 08:20:01 --> Config Class Initialized
INFO - 2023-04-21 08:20:01 --> Loader Class Initialized
INFO - 2023-04-21 08:20:01 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:01 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:01 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:01 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:01 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:01 --> Controller Class Initialized
INFO - 2023-04-21 08:20:01 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:01 --> Total execution time: 0.0321
INFO - 2023-04-21 08:20:03 --> Config Class Initialized
INFO - 2023-04-21 08:20:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:03 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:03 --> URI Class Initialized
INFO - 2023-04-21 08:20:03 --> Router Class Initialized
INFO - 2023-04-21 08:20:03 --> Output Class Initialized
INFO - 2023-04-21 08:20:03 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:03 --> Input Class Initialized
INFO - 2023-04-21 08:20:03 --> Language Class Initialized
INFO - 2023-04-21 08:20:03 --> Language Class Initialized
INFO - 2023-04-21 08:20:03 --> Config Class Initialized
INFO - 2023-04-21 08:20:03 --> Loader Class Initialized
INFO - 2023-04-21 08:20:03 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:03 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:03 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:03 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:03 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:03 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:03 --> Total execution time: 0.0313
INFO - 2023-04-21 08:20:11 --> Config Class Initialized
INFO - 2023-04-21 08:20:11 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:11 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:11 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:11 --> URI Class Initialized
INFO - 2023-04-21 08:20:11 --> Router Class Initialized
INFO - 2023-04-21 08:20:11 --> Output Class Initialized
INFO - 2023-04-21 08:20:11 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:11 --> Input Class Initialized
INFO - 2023-04-21 08:20:11 --> Language Class Initialized
INFO - 2023-04-21 08:20:11 --> Language Class Initialized
INFO - 2023-04-21 08:20:11 --> Config Class Initialized
INFO - 2023-04-21 08:20:11 --> Loader Class Initialized
INFO - 2023-04-21 08:20:11 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:11 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:11 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:11 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:11 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:11 --> Controller Class Initialized
INFO - 2023-04-21 08:20:11 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:11 --> Total execution time: 0.0305
INFO - 2023-04-21 08:20:12 --> Config Class Initialized
INFO - 2023-04-21 08:20:12 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:12 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:12 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:12 --> URI Class Initialized
INFO - 2023-04-21 08:20:12 --> Router Class Initialized
INFO - 2023-04-21 08:20:12 --> Output Class Initialized
INFO - 2023-04-21 08:20:12 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:12 --> Input Class Initialized
INFO - 2023-04-21 08:20:12 --> Language Class Initialized
INFO - 2023-04-21 08:20:12 --> Language Class Initialized
INFO - 2023-04-21 08:20:12 --> Config Class Initialized
INFO - 2023-04-21 08:20:12 --> Loader Class Initialized
INFO - 2023-04-21 08:20:12 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:12 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:12 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:12 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:12 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:12 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:12 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:12 --> Total execution time: 0.0321
INFO - 2023-04-21 08:20:13 --> Config Class Initialized
INFO - 2023-04-21 08:20:13 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:13 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:13 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:13 --> URI Class Initialized
INFO - 2023-04-21 08:20:13 --> Router Class Initialized
INFO - 2023-04-21 08:20:13 --> Output Class Initialized
INFO - 2023-04-21 08:20:13 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:13 --> Input Class Initialized
INFO - 2023-04-21 08:20:13 --> Language Class Initialized
INFO - 2023-04-21 08:20:13 --> Language Class Initialized
INFO - 2023-04-21 08:20:13 --> Config Class Initialized
INFO - 2023-04-21 08:20:13 --> Loader Class Initialized
INFO - 2023-04-21 08:20:13 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:13 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:13 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:13 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:13 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:13 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:13 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:13 --> Total execution time: 0.0480
INFO - 2023-04-21 08:20:17 --> Config Class Initialized
INFO - 2023-04-21 08:20:17 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:17 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:17 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:17 --> URI Class Initialized
INFO - 2023-04-21 08:20:17 --> Router Class Initialized
INFO - 2023-04-21 08:20:17 --> Output Class Initialized
INFO - 2023-04-21 08:20:17 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:17 --> Input Class Initialized
INFO - 2023-04-21 08:20:17 --> Language Class Initialized
INFO - 2023-04-21 08:20:17 --> Language Class Initialized
INFO - 2023-04-21 08:20:17 --> Config Class Initialized
INFO - 2023-04-21 08:20:17 --> Loader Class Initialized
INFO - 2023-04-21 08:20:17 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:17 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:17 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:17 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:17 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:17 --> Controller Class Initialized
INFO - 2023-04-21 08:20:17 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:17 --> Total execution time: 0.0306
INFO - 2023-04-21 08:20:19 --> Config Class Initialized
INFO - 2023-04-21 08:20:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:19 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:19 --> URI Class Initialized
INFO - 2023-04-21 08:20:19 --> Router Class Initialized
INFO - 2023-04-21 08:20:19 --> Output Class Initialized
INFO - 2023-04-21 08:20:19 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:19 --> Input Class Initialized
INFO - 2023-04-21 08:20:19 --> Language Class Initialized
INFO - 2023-04-21 08:20:19 --> Language Class Initialized
INFO - 2023-04-21 08:20:19 --> Config Class Initialized
INFO - 2023-04-21 08:20:19 --> Loader Class Initialized
INFO - 2023-04-21 08:20:19 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:19 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:19 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:19 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:19 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:19 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:19 --> Total execution time: 0.0310
INFO - 2023-04-21 08:20:28 --> Config Class Initialized
INFO - 2023-04-21 08:20:28 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:28 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:28 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:28 --> URI Class Initialized
INFO - 2023-04-21 08:20:28 --> Router Class Initialized
INFO - 2023-04-21 08:20:28 --> Output Class Initialized
INFO - 2023-04-21 08:20:28 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:28 --> Input Class Initialized
INFO - 2023-04-21 08:20:28 --> Language Class Initialized
INFO - 2023-04-21 08:20:28 --> Language Class Initialized
INFO - 2023-04-21 08:20:28 --> Config Class Initialized
INFO - 2023-04-21 08:20:28 --> Loader Class Initialized
INFO - 2023-04-21 08:20:28 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:28 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:28 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:28 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:28 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:28 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:28 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:28 --> Total execution time: 0.0306
INFO - 2023-04-21 08:20:32 --> Config Class Initialized
INFO - 2023-04-21 08:20:32 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:32 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:32 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:32 --> URI Class Initialized
INFO - 2023-04-21 08:20:32 --> Router Class Initialized
INFO - 2023-04-21 08:20:32 --> Output Class Initialized
INFO - 2023-04-21 08:20:32 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:32 --> Input Class Initialized
INFO - 2023-04-21 08:20:32 --> Language Class Initialized
INFO - 2023-04-21 08:20:32 --> Language Class Initialized
INFO - 2023-04-21 08:20:32 --> Config Class Initialized
INFO - 2023-04-21 08:20:32 --> Loader Class Initialized
INFO - 2023-04-21 08:20:32 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:32 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:32 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:32 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:32 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:32 --> Controller Class Initialized
INFO - 2023-04-21 08:20:32 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:32 --> Total execution time: 0.0314
INFO - 2023-04-21 08:20:34 --> Config Class Initialized
INFO - 2023-04-21 08:20:34 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:34 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:34 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:34 --> URI Class Initialized
INFO - 2023-04-21 08:20:34 --> Router Class Initialized
INFO - 2023-04-21 08:20:34 --> Output Class Initialized
INFO - 2023-04-21 08:20:34 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:34 --> Input Class Initialized
INFO - 2023-04-21 08:20:34 --> Language Class Initialized
INFO - 2023-04-21 08:20:34 --> Language Class Initialized
INFO - 2023-04-21 08:20:34 --> Config Class Initialized
INFO - 2023-04-21 08:20:34 --> Loader Class Initialized
INFO - 2023-04-21 08:20:34 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:34 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:34 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:34 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:34 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:34 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:34 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:34 --> Total execution time: 0.0398
INFO - 2023-04-21 08:20:38 --> Config Class Initialized
INFO - 2023-04-21 08:20:38 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:38 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:38 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:38 --> URI Class Initialized
INFO - 2023-04-21 08:20:38 --> Router Class Initialized
INFO - 2023-04-21 08:20:38 --> Output Class Initialized
INFO - 2023-04-21 08:20:38 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:38 --> Input Class Initialized
INFO - 2023-04-21 08:20:38 --> Language Class Initialized
INFO - 2023-04-21 08:20:38 --> Language Class Initialized
INFO - 2023-04-21 08:20:38 --> Config Class Initialized
INFO - 2023-04-21 08:20:38 --> Loader Class Initialized
INFO - 2023-04-21 08:20:38 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:38 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:38 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:38 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:38 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:38 --> Controller Class Initialized
INFO - 2023-04-21 08:20:38 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:38 --> Total execution time: 0.0269
INFO - 2023-04-21 08:20:40 --> Config Class Initialized
INFO - 2023-04-21 08:20:40 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:40 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:40 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:40 --> URI Class Initialized
INFO - 2023-04-21 08:20:40 --> Router Class Initialized
INFO - 2023-04-21 08:20:40 --> Output Class Initialized
INFO - 2023-04-21 08:20:40 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:40 --> Input Class Initialized
INFO - 2023-04-21 08:20:40 --> Language Class Initialized
INFO - 2023-04-21 08:20:40 --> Language Class Initialized
INFO - 2023-04-21 08:20:40 --> Config Class Initialized
INFO - 2023-04-21 08:20:40 --> Loader Class Initialized
INFO - 2023-04-21 08:20:40 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:40 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:40 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:40 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:40 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:40 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:40 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:40 --> Total execution time: 0.0265
INFO - 2023-04-21 08:20:42 --> Config Class Initialized
INFO - 2023-04-21 08:20:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:42 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:42 --> URI Class Initialized
INFO - 2023-04-21 08:20:42 --> Router Class Initialized
INFO - 2023-04-21 08:20:42 --> Output Class Initialized
INFO - 2023-04-21 08:20:42 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:42 --> Input Class Initialized
INFO - 2023-04-21 08:20:42 --> Language Class Initialized
INFO - 2023-04-21 08:20:42 --> Language Class Initialized
INFO - 2023-04-21 08:20:42 --> Config Class Initialized
INFO - 2023-04-21 08:20:42 --> Loader Class Initialized
INFO - 2023-04-21 08:20:42 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:42 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:42 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:42 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:42 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-04-21 08:20:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:20:42 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:42 --> Total execution time: 0.0486
INFO - 2023-04-21 08:20:46 --> Config Class Initialized
INFO - 2023-04-21 08:20:46 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:20:46 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:20:46 --> Utf8 Class Initialized
INFO - 2023-04-21 08:20:46 --> URI Class Initialized
INFO - 2023-04-21 08:20:46 --> Router Class Initialized
INFO - 2023-04-21 08:20:46 --> Output Class Initialized
INFO - 2023-04-21 08:20:46 --> Security Class Initialized
DEBUG - 2023-04-21 08:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:20:46 --> Input Class Initialized
INFO - 2023-04-21 08:20:46 --> Language Class Initialized
INFO - 2023-04-21 08:20:46 --> Language Class Initialized
INFO - 2023-04-21 08:20:46 --> Config Class Initialized
INFO - 2023-04-21 08:20:46 --> Loader Class Initialized
INFO - 2023-04-21 08:20:46 --> Helper loaded: url_helper
INFO - 2023-04-21 08:20:46 --> Helper loaded: file_helper
INFO - 2023-04-21 08:20:46 --> Helper loaded: form_helper
INFO - 2023-04-21 08:20:46 --> Helper loaded: my_helper
INFO - 2023-04-21 08:20:46 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:20:46 --> Controller Class Initialized
DEBUG - 2023-04-21 08:20:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:20:47 --> Final output sent to browser
DEBUG - 2023-04-21 08:20:47 --> Total execution time: 1.1089
INFO - 2023-04-21 08:29:21 --> Config Class Initialized
INFO - 2023-04-21 08:29:21 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:29:21 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:29:21 --> Utf8 Class Initialized
INFO - 2023-04-21 08:29:21 --> URI Class Initialized
INFO - 2023-04-21 08:29:21 --> Router Class Initialized
INFO - 2023-04-21 08:29:21 --> Output Class Initialized
INFO - 2023-04-21 08:29:21 --> Security Class Initialized
DEBUG - 2023-04-21 08:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:29:21 --> Input Class Initialized
INFO - 2023-04-21 08:29:21 --> Language Class Initialized
INFO - 2023-04-21 08:29:21 --> Language Class Initialized
INFO - 2023-04-21 08:29:21 --> Config Class Initialized
INFO - 2023-04-21 08:29:21 --> Loader Class Initialized
INFO - 2023-04-21 08:29:21 --> Helper loaded: url_helper
INFO - 2023-04-21 08:29:21 --> Helper loaded: file_helper
INFO - 2023-04-21 08:29:21 --> Helper loaded: form_helper
INFO - 2023-04-21 08:29:21 --> Helper loaded: my_helper
INFO - 2023-04-21 08:29:21 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:29:21 --> Controller Class Initialized
DEBUG - 2023-04-21 08:29:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:29:22 --> Final output sent to browser
DEBUG - 2023-04-21 08:29:22 --> Total execution time: 1.0914
INFO - 2023-04-21 08:31:38 --> Config Class Initialized
INFO - 2023-04-21 08:31:38 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:31:38 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:31:38 --> Utf8 Class Initialized
INFO - 2023-04-21 08:31:38 --> URI Class Initialized
INFO - 2023-04-21 08:31:38 --> Router Class Initialized
INFO - 2023-04-21 08:31:38 --> Output Class Initialized
INFO - 2023-04-21 08:31:38 --> Security Class Initialized
DEBUG - 2023-04-21 08:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:31:38 --> Input Class Initialized
INFO - 2023-04-21 08:31:38 --> Language Class Initialized
INFO - 2023-04-21 08:31:38 --> Language Class Initialized
INFO - 2023-04-21 08:31:38 --> Config Class Initialized
INFO - 2023-04-21 08:31:38 --> Loader Class Initialized
INFO - 2023-04-21 08:31:38 --> Helper loaded: url_helper
INFO - 2023-04-21 08:31:38 --> Helper loaded: file_helper
INFO - 2023-04-21 08:31:38 --> Helper loaded: form_helper
INFO - 2023-04-21 08:31:38 --> Helper loaded: my_helper
INFO - 2023-04-21 08:31:38 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:31:38 --> Controller Class Initialized
DEBUG - 2023-04-21 08:31:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 4673
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 4673
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 4673
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 4673
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 4673
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: tr_curr C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 4673
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: tfoot C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5279
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5279
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: marge C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: new_page C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5335
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellpadding C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5431
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5432
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: corr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5461
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: border C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5523
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5560
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5561
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5562
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5563
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5610
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5666
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5667
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5668
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5669
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellpadding C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5431
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5432
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: corr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5461
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: border C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5523
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5560
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5561
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5562
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5563
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5610
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5666
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5667
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5668
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5669
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellpadding C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5431
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5432
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: corr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5461
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: border C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5523
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5560
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5561
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5562
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5563
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5610
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5666
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5667
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5668
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5669
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellpadding C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5431
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5432
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: corr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5461
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: border C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5523
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5560
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5561
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5562
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5563
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5610
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5666
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5667
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5668
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cellspacing C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5669
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: curr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5404
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: marge C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5404
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5404
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5405
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: tfoot C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5134
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5134
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5134
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: curr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5155
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: width C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5155
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: height C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5156
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5156
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: height C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5158
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5158
ERROR - 2023-04-21 08:31:39 --> Severity: Notice --> Undefined index: curr_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5161
ERROR - 2023-04-21 08:31:39 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 08:31:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 08:33:13 --> Config Class Initialized
INFO - 2023-04-21 08:33:13 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:33:13 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:33:13 --> Utf8 Class Initialized
INFO - 2023-04-21 08:33:13 --> URI Class Initialized
INFO - 2023-04-21 08:33:13 --> Router Class Initialized
INFO - 2023-04-21 08:33:13 --> Output Class Initialized
INFO - 2023-04-21 08:33:13 --> Security Class Initialized
DEBUG - 2023-04-21 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:33:13 --> Input Class Initialized
INFO - 2023-04-21 08:33:13 --> Language Class Initialized
INFO - 2023-04-21 08:33:13 --> Language Class Initialized
INFO - 2023-04-21 08:33:13 --> Config Class Initialized
INFO - 2023-04-21 08:33:13 --> Loader Class Initialized
INFO - 2023-04-21 08:33:13 --> Helper loaded: url_helper
INFO - 2023-04-21 08:33:13 --> Helper loaded: file_helper
INFO - 2023-04-21 08:33:13 --> Helper loaded: form_helper
INFO - 2023-04-21 08:33:13 --> Helper loaded: my_helper
INFO - 2023-04-21 08:33:13 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:33:13 --> Controller Class Initialized
DEBUG - 2023-04-21 08:33:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:33:14 --> Final output sent to browser
DEBUG - 2023-04-21 08:33:14 --> Total execution time: 1.1383
INFO - 2023-04-21 08:33:42 --> Config Class Initialized
INFO - 2023-04-21 08:33:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:33:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:33:42 --> Utf8 Class Initialized
INFO - 2023-04-21 08:33:42 --> URI Class Initialized
INFO - 2023-04-21 08:33:42 --> Router Class Initialized
INFO - 2023-04-21 08:33:42 --> Output Class Initialized
INFO - 2023-04-21 08:33:42 --> Security Class Initialized
DEBUG - 2023-04-21 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:33:42 --> Input Class Initialized
INFO - 2023-04-21 08:33:42 --> Language Class Initialized
INFO - 2023-04-21 08:33:42 --> Language Class Initialized
INFO - 2023-04-21 08:33:42 --> Config Class Initialized
INFO - 2023-04-21 08:33:42 --> Loader Class Initialized
INFO - 2023-04-21 08:33:42 --> Helper loaded: url_helper
INFO - 2023-04-21 08:33:42 --> Helper loaded: file_helper
INFO - 2023-04-21 08:33:42 --> Helper loaded: form_helper
INFO - 2023-04-21 08:33:42 --> Helper loaded: my_helper
INFO - 2023-04-21 08:33:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:33:42 --> Controller Class Initialized
DEBUG - 2023-04-21 08:33:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:33:43 --> Final output sent to browser
DEBUG - 2023-04-21 08:33:43 --> Total execution time: 1.1212
INFO - 2023-04-21 08:34:26 --> Config Class Initialized
INFO - 2023-04-21 08:34:26 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:34:26 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:34:26 --> Utf8 Class Initialized
INFO - 2023-04-21 08:34:26 --> URI Class Initialized
INFO - 2023-04-21 08:34:26 --> Router Class Initialized
INFO - 2023-04-21 08:34:26 --> Output Class Initialized
INFO - 2023-04-21 08:34:26 --> Security Class Initialized
DEBUG - 2023-04-21 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:34:26 --> Input Class Initialized
INFO - 2023-04-21 08:34:26 --> Language Class Initialized
INFO - 2023-04-21 08:34:26 --> Language Class Initialized
INFO - 2023-04-21 08:34:26 --> Config Class Initialized
INFO - 2023-04-21 08:34:26 --> Loader Class Initialized
INFO - 2023-04-21 08:34:26 --> Helper loaded: url_helper
INFO - 2023-04-21 08:34:26 --> Helper loaded: file_helper
INFO - 2023-04-21 08:34:26 --> Helper loaded: form_helper
INFO - 2023-04-21 08:34:26 --> Helper loaded: my_helper
INFO - 2023-04-21 08:34:26 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:34:26 --> Controller Class Initialized
DEBUG - 2023-04-21 08:34:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:34:27 --> Final output sent to browser
DEBUG - 2023-04-21 08:34:27 --> Total execution time: 1.0448
INFO - 2023-04-21 08:35:19 --> Config Class Initialized
INFO - 2023-04-21 08:35:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:35:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:35:19 --> Utf8 Class Initialized
INFO - 2023-04-21 08:35:19 --> URI Class Initialized
INFO - 2023-04-21 08:35:19 --> Router Class Initialized
INFO - 2023-04-21 08:35:19 --> Output Class Initialized
INFO - 2023-04-21 08:35:19 --> Security Class Initialized
DEBUG - 2023-04-21 08:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:35:19 --> Input Class Initialized
INFO - 2023-04-21 08:35:19 --> Language Class Initialized
INFO - 2023-04-21 08:35:19 --> Language Class Initialized
INFO - 2023-04-21 08:35:19 --> Config Class Initialized
INFO - 2023-04-21 08:35:19 --> Loader Class Initialized
INFO - 2023-04-21 08:35:19 --> Helper loaded: url_helper
INFO - 2023-04-21 08:35:19 --> Helper loaded: file_helper
INFO - 2023-04-21 08:35:19 --> Helper loaded: form_helper
INFO - 2023-04-21 08:35:19 --> Helper loaded: my_helper
INFO - 2023-04-21 08:35:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:35:19 --> Controller Class Initialized
DEBUG - 2023-04-21 08:35:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:35:20 --> Final output sent to browser
DEBUG - 2023-04-21 08:35:20 --> Total execution time: 1.0334
INFO - 2023-04-21 08:35:30 --> Config Class Initialized
INFO - 2023-04-21 08:35:30 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:35:30 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:35:30 --> Utf8 Class Initialized
INFO - 2023-04-21 08:35:30 --> URI Class Initialized
INFO - 2023-04-21 08:35:30 --> Router Class Initialized
INFO - 2023-04-21 08:35:30 --> Output Class Initialized
INFO - 2023-04-21 08:35:30 --> Security Class Initialized
DEBUG - 2023-04-21 08:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:35:30 --> Input Class Initialized
INFO - 2023-04-21 08:35:30 --> Language Class Initialized
INFO - 2023-04-21 08:35:30 --> Language Class Initialized
INFO - 2023-04-21 08:35:30 --> Config Class Initialized
INFO - 2023-04-21 08:35:30 --> Loader Class Initialized
INFO - 2023-04-21 08:35:30 --> Helper loaded: url_helper
INFO - 2023-04-21 08:35:30 --> Helper loaded: file_helper
INFO - 2023-04-21 08:35:30 --> Helper loaded: form_helper
INFO - 2023-04-21 08:35:30 --> Helper loaded: my_helper
INFO - 2023-04-21 08:35:30 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:35:30 --> Controller Class Initialized
DEBUG - 2023-04-21 08:35:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:35:31 --> Final output sent to browser
DEBUG - 2023-04-21 08:35:31 --> Total execution time: 1.1115
INFO - 2023-04-21 08:35:41 --> Config Class Initialized
INFO - 2023-04-21 08:35:41 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:35:41 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:35:41 --> Utf8 Class Initialized
INFO - 2023-04-21 08:35:41 --> URI Class Initialized
INFO - 2023-04-21 08:35:41 --> Router Class Initialized
INFO - 2023-04-21 08:35:41 --> Output Class Initialized
INFO - 2023-04-21 08:35:41 --> Security Class Initialized
DEBUG - 2023-04-21 08:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:35:41 --> Input Class Initialized
INFO - 2023-04-21 08:35:41 --> Language Class Initialized
INFO - 2023-04-21 08:35:41 --> Language Class Initialized
INFO - 2023-04-21 08:35:41 --> Config Class Initialized
INFO - 2023-04-21 08:35:41 --> Loader Class Initialized
INFO - 2023-04-21 08:35:41 --> Helper loaded: url_helper
INFO - 2023-04-21 08:35:41 --> Helper loaded: file_helper
INFO - 2023-04-21 08:35:41 --> Helper loaded: form_helper
INFO - 2023-04-21 08:35:41 --> Helper loaded: my_helper
INFO - 2023-04-21 08:35:41 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:35:41 --> Controller Class Initialized
DEBUG - 2023-04-21 08:35:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:35:42 --> Final output sent to browser
DEBUG - 2023-04-21 08:35:42 --> Total execution time: 1.1408
INFO - 2023-04-21 08:36:32 --> Config Class Initialized
INFO - 2023-04-21 08:36:32 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:36:32 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:36:32 --> Utf8 Class Initialized
INFO - 2023-04-21 08:36:32 --> URI Class Initialized
INFO - 2023-04-21 08:36:32 --> Router Class Initialized
INFO - 2023-04-21 08:36:32 --> Output Class Initialized
INFO - 2023-04-21 08:36:32 --> Security Class Initialized
DEBUG - 2023-04-21 08:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:36:32 --> Input Class Initialized
INFO - 2023-04-21 08:36:32 --> Language Class Initialized
INFO - 2023-04-21 08:36:32 --> Language Class Initialized
INFO - 2023-04-21 08:36:32 --> Config Class Initialized
INFO - 2023-04-21 08:36:32 --> Loader Class Initialized
INFO - 2023-04-21 08:36:32 --> Helper loaded: url_helper
INFO - 2023-04-21 08:36:32 --> Helper loaded: file_helper
INFO - 2023-04-21 08:36:32 --> Helper loaded: form_helper
INFO - 2023-04-21 08:36:32 --> Helper loaded: my_helper
INFO - 2023-04-21 08:36:32 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:36:33 --> Controller Class Initialized
DEBUG - 2023-04-21 08:36:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:36:34 --> Final output sent to browser
DEBUG - 2023-04-21 08:36:34 --> Total execution time: 1.0865
INFO - 2023-04-21 08:37:33 --> Config Class Initialized
INFO - 2023-04-21 08:37:33 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:37:33 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:37:33 --> Utf8 Class Initialized
INFO - 2023-04-21 08:37:33 --> URI Class Initialized
INFO - 2023-04-21 08:37:33 --> Router Class Initialized
INFO - 2023-04-21 08:37:33 --> Output Class Initialized
INFO - 2023-04-21 08:37:33 --> Security Class Initialized
DEBUG - 2023-04-21 08:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:37:33 --> Input Class Initialized
INFO - 2023-04-21 08:37:33 --> Language Class Initialized
INFO - 2023-04-21 08:37:33 --> Language Class Initialized
INFO - 2023-04-21 08:37:33 --> Config Class Initialized
INFO - 2023-04-21 08:37:33 --> Loader Class Initialized
INFO - 2023-04-21 08:37:33 --> Helper loaded: url_helper
INFO - 2023-04-21 08:37:33 --> Helper loaded: file_helper
INFO - 2023-04-21 08:37:33 --> Helper loaded: form_helper
INFO - 2023-04-21 08:37:33 --> Helper loaded: my_helper
INFO - 2023-04-21 08:37:33 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:37:33 --> Controller Class Initialized
DEBUG - 2023-04-21 08:37:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:37:34 --> Final output sent to browser
DEBUG - 2023-04-21 08:37:34 --> Total execution time: 1.1151
INFO - 2023-04-21 08:38:24 --> Config Class Initialized
INFO - 2023-04-21 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:38:24 --> Utf8 Class Initialized
INFO - 2023-04-21 08:38:24 --> URI Class Initialized
INFO - 2023-04-21 08:38:24 --> Router Class Initialized
INFO - 2023-04-21 08:38:24 --> Output Class Initialized
INFO - 2023-04-21 08:38:24 --> Security Class Initialized
DEBUG - 2023-04-21 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:38:24 --> Input Class Initialized
INFO - 2023-04-21 08:38:24 --> Language Class Initialized
INFO - 2023-04-21 08:38:24 --> Language Class Initialized
INFO - 2023-04-21 08:38:24 --> Config Class Initialized
INFO - 2023-04-21 08:38:24 --> Loader Class Initialized
INFO - 2023-04-21 08:38:24 --> Helper loaded: url_helper
INFO - 2023-04-21 08:38:24 --> Helper loaded: file_helper
INFO - 2023-04-21 08:38:24 --> Helper loaded: form_helper
INFO - 2023-04-21 08:38:24 --> Helper loaded: my_helper
INFO - 2023-04-21 08:38:24 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:38:24 --> Controller Class Initialized
DEBUG - 2023-04-21 08:38:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:38:26 --> Final output sent to browser
DEBUG - 2023-04-21 08:38:26 --> Total execution time: 1.1384
INFO - 2023-04-21 08:38:38 --> Config Class Initialized
INFO - 2023-04-21 08:38:38 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:38:38 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:38:38 --> Utf8 Class Initialized
INFO - 2023-04-21 08:38:38 --> URI Class Initialized
INFO - 2023-04-21 08:38:38 --> Router Class Initialized
INFO - 2023-04-21 08:38:38 --> Output Class Initialized
INFO - 2023-04-21 08:38:38 --> Security Class Initialized
DEBUG - 2023-04-21 08:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:38:38 --> Input Class Initialized
INFO - 2023-04-21 08:38:38 --> Language Class Initialized
INFO - 2023-04-21 08:38:38 --> Language Class Initialized
INFO - 2023-04-21 08:38:38 --> Config Class Initialized
INFO - 2023-04-21 08:38:38 --> Loader Class Initialized
INFO - 2023-04-21 08:38:38 --> Helper loaded: url_helper
INFO - 2023-04-21 08:38:38 --> Helper loaded: file_helper
INFO - 2023-04-21 08:38:38 --> Helper loaded: form_helper
INFO - 2023-04-21 08:38:38 --> Helper loaded: my_helper
INFO - 2023-04-21 08:38:38 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:38:38 --> Controller Class Initialized
DEBUG - 2023-04-21 08:38:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:38:40 --> Final output sent to browser
DEBUG - 2023-04-21 08:38:40 --> Total execution time: 1.1286
INFO - 2023-04-21 08:39:09 --> Config Class Initialized
INFO - 2023-04-21 08:39:09 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:39:09 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:39:09 --> Utf8 Class Initialized
INFO - 2023-04-21 08:39:09 --> URI Class Initialized
INFO - 2023-04-21 08:39:09 --> Router Class Initialized
INFO - 2023-04-21 08:39:09 --> Output Class Initialized
INFO - 2023-04-21 08:39:09 --> Security Class Initialized
DEBUG - 2023-04-21 08:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:39:09 --> Input Class Initialized
INFO - 2023-04-21 08:39:09 --> Language Class Initialized
INFO - 2023-04-21 08:39:09 --> Language Class Initialized
INFO - 2023-04-21 08:39:09 --> Config Class Initialized
INFO - 2023-04-21 08:39:09 --> Loader Class Initialized
INFO - 2023-04-21 08:39:09 --> Helper loaded: url_helper
INFO - 2023-04-21 08:39:09 --> Helper loaded: file_helper
INFO - 2023-04-21 08:39:09 --> Helper loaded: form_helper
INFO - 2023-04-21 08:39:09 --> Helper loaded: my_helper
INFO - 2023-04-21 08:39:09 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:39:09 --> Controller Class Initialized
DEBUG - 2023-04-21 08:39:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:39:10 --> Final output sent to browser
DEBUG - 2023-04-21 08:39:10 --> Total execution time: 1.1198
INFO - 2023-04-21 08:39:29 --> Config Class Initialized
INFO - 2023-04-21 08:39:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:39:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:39:29 --> Utf8 Class Initialized
INFO - 2023-04-21 08:39:29 --> URI Class Initialized
INFO - 2023-04-21 08:39:29 --> Router Class Initialized
INFO - 2023-04-21 08:39:29 --> Output Class Initialized
INFO - 2023-04-21 08:39:29 --> Security Class Initialized
DEBUG - 2023-04-21 08:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:39:29 --> Input Class Initialized
INFO - 2023-04-21 08:39:29 --> Language Class Initialized
INFO - 2023-04-21 08:39:29 --> Language Class Initialized
INFO - 2023-04-21 08:39:29 --> Config Class Initialized
INFO - 2023-04-21 08:39:29 --> Loader Class Initialized
INFO - 2023-04-21 08:39:29 --> Helper loaded: url_helper
INFO - 2023-04-21 08:39:29 --> Helper loaded: file_helper
INFO - 2023-04-21 08:39:29 --> Helper loaded: form_helper
INFO - 2023-04-21 08:39:29 --> Helper loaded: my_helper
INFO - 2023-04-21 08:39:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:39:29 --> Controller Class Initialized
DEBUG - 2023-04-21 08:39:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:39:30 --> Final output sent to browser
DEBUG - 2023-04-21 08:39:30 --> Total execution time: 1.1128
INFO - 2023-04-21 08:39:42 --> Config Class Initialized
INFO - 2023-04-21 08:39:42 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:39:42 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:39:42 --> Utf8 Class Initialized
INFO - 2023-04-21 08:39:42 --> URI Class Initialized
INFO - 2023-04-21 08:39:42 --> Router Class Initialized
INFO - 2023-04-21 08:39:42 --> Output Class Initialized
INFO - 2023-04-21 08:39:42 --> Security Class Initialized
DEBUG - 2023-04-21 08:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:39:42 --> Input Class Initialized
INFO - 2023-04-21 08:39:42 --> Language Class Initialized
INFO - 2023-04-21 08:39:42 --> Language Class Initialized
INFO - 2023-04-21 08:39:42 --> Config Class Initialized
INFO - 2023-04-21 08:39:42 --> Loader Class Initialized
INFO - 2023-04-21 08:39:42 --> Helper loaded: url_helper
INFO - 2023-04-21 08:39:42 --> Helper loaded: file_helper
INFO - 2023-04-21 08:39:42 --> Helper loaded: form_helper
INFO - 2023-04-21 08:39:42 --> Helper loaded: my_helper
INFO - 2023-04-21 08:39:42 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:39:42 --> Controller Class Initialized
DEBUG - 2023-04-21 08:39:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:39:43 --> Final output sent to browser
DEBUG - 2023-04-21 08:39:43 --> Total execution time: 1.0875
INFO - 2023-04-21 08:40:08 --> Config Class Initialized
INFO - 2023-04-21 08:40:08 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:40:08 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:40:08 --> Utf8 Class Initialized
INFO - 2023-04-21 08:40:08 --> URI Class Initialized
INFO - 2023-04-21 08:40:08 --> Router Class Initialized
INFO - 2023-04-21 08:40:08 --> Output Class Initialized
INFO - 2023-04-21 08:40:08 --> Security Class Initialized
DEBUG - 2023-04-21 08:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:40:08 --> Input Class Initialized
INFO - 2023-04-21 08:40:08 --> Language Class Initialized
INFO - 2023-04-21 08:40:08 --> Language Class Initialized
INFO - 2023-04-21 08:40:08 --> Config Class Initialized
INFO - 2023-04-21 08:40:08 --> Loader Class Initialized
INFO - 2023-04-21 08:40:08 --> Helper loaded: url_helper
INFO - 2023-04-21 08:40:08 --> Helper loaded: file_helper
INFO - 2023-04-21 08:40:08 --> Helper loaded: form_helper
INFO - 2023-04-21 08:40:08 --> Helper loaded: my_helper
INFO - 2023-04-21 08:40:08 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:40:08 --> Controller Class Initialized
DEBUG - 2023-04-21 08:40:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:40:09 --> Final output sent to browser
DEBUG - 2023-04-21 08:40:09 --> Total execution time: 1.1279
INFO - 2023-04-21 08:40:29 --> Config Class Initialized
INFO - 2023-04-21 08:40:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:40:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:40:29 --> Utf8 Class Initialized
INFO - 2023-04-21 08:40:29 --> URI Class Initialized
INFO - 2023-04-21 08:40:29 --> Router Class Initialized
INFO - 2023-04-21 08:40:29 --> Output Class Initialized
INFO - 2023-04-21 08:40:29 --> Security Class Initialized
DEBUG - 2023-04-21 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:40:29 --> Input Class Initialized
INFO - 2023-04-21 08:40:29 --> Language Class Initialized
INFO - 2023-04-21 08:40:29 --> Language Class Initialized
INFO - 2023-04-21 08:40:29 --> Config Class Initialized
INFO - 2023-04-21 08:40:29 --> Loader Class Initialized
INFO - 2023-04-21 08:40:29 --> Helper loaded: url_helper
INFO - 2023-04-21 08:40:29 --> Helper loaded: file_helper
INFO - 2023-04-21 08:40:29 --> Helper loaded: form_helper
INFO - 2023-04-21 08:40:29 --> Helper loaded: my_helper
INFO - 2023-04-21 08:40:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:40:29 --> Controller Class Initialized
DEBUG - 2023-04-21 08:40:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:40:30 --> Final output sent to browser
DEBUG - 2023-04-21 08:40:30 --> Total execution time: 1.1107
INFO - 2023-04-21 08:41:00 --> Config Class Initialized
INFO - 2023-04-21 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:41:00 --> Utf8 Class Initialized
INFO - 2023-04-21 08:41:00 --> URI Class Initialized
INFO - 2023-04-21 08:41:00 --> Router Class Initialized
INFO - 2023-04-21 08:41:00 --> Output Class Initialized
INFO - 2023-04-21 08:41:00 --> Security Class Initialized
DEBUG - 2023-04-21 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:41:00 --> Input Class Initialized
INFO - 2023-04-21 08:41:00 --> Language Class Initialized
INFO - 2023-04-21 08:41:00 --> Language Class Initialized
INFO - 2023-04-21 08:41:00 --> Config Class Initialized
INFO - 2023-04-21 08:41:00 --> Loader Class Initialized
INFO - 2023-04-21 08:41:00 --> Helper loaded: url_helper
INFO - 2023-04-21 08:41:00 --> Helper loaded: file_helper
INFO - 2023-04-21 08:41:00 --> Helper loaded: form_helper
INFO - 2023-04-21 08:41:00 --> Helper loaded: my_helper
INFO - 2023-04-21 08:41:00 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:41:00 --> Controller Class Initialized
DEBUG - 2023-04-21 08:41:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:41:01 --> Final output sent to browser
DEBUG - 2023-04-21 08:41:01 --> Total execution time: 1.1347
INFO - 2023-04-21 08:41:17 --> Config Class Initialized
INFO - 2023-04-21 08:41:17 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:41:17 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:41:17 --> Utf8 Class Initialized
INFO - 2023-04-21 08:41:17 --> URI Class Initialized
INFO - 2023-04-21 08:41:17 --> Router Class Initialized
INFO - 2023-04-21 08:41:17 --> Output Class Initialized
INFO - 2023-04-21 08:41:17 --> Security Class Initialized
DEBUG - 2023-04-21 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:41:17 --> Input Class Initialized
INFO - 2023-04-21 08:41:17 --> Language Class Initialized
INFO - 2023-04-21 08:41:17 --> Language Class Initialized
INFO - 2023-04-21 08:41:17 --> Config Class Initialized
INFO - 2023-04-21 08:41:17 --> Loader Class Initialized
INFO - 2023-04-21 08:41:17 --> Helper loaded: url_helper
INFO - 2023-04-21 08:41:17 --> Helper loaded: file_helper
INFO - 2023-04-21 08:41:17 --> Helper loaded: form_helper
INFO - 2023-04-21 08:41:17 --> Helper loaded: my_helper
INFO - 2023-04-21 08:41:17 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:41:17 --> Controller Class Initialized
DEBUG - 2023-04-21 08:41:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:41:18 --> Final output sent to browser
DEBUG - 2023-04-21 08:41:18 --> Total execution time: 1.1371
INFO - 2023-04-21 08:42:05 --> Config Class Initialized
INFO - 2023-04-21 08:42:05 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:42:05 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:42:05 --> Utf8 Class Initialized
INFO - 2023-04-21 08:42:05 --> URI Class Initialized
INFO - 2023-04-21 08:42:05 --> Router Class Initialized
INFO - 2023-04-21 08:42:05 --> Output Class Initialized
INFO - 2023-04-21 08:42:05 --> Security Class Initialized
DEBUG - 2023-04-21 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:42:05 --> Input Class Initialized
INFO - 2023-04-21 08:42:05 --> Language Class Initialized
INFO - 2023-04-21 08:42:05 --> Language Class Initialized
INFO - 2023-04-21 08:42:05 --> Config Class Initialized
INFO - 2023-04-21 08:42:05 --> Loader Class Initialized
INFO - 2023-04-21 08:42:05 --> Helper loaded: url_helper
INFO - 2023-04-21 08:42:05 --> Helper loaded: file_helper
INFO - 2023-04-21 08:42:05 --> Helper loaded: form_helper
INFO - 2023-04-21 08:42:05 --> Helper loaded: my_helper
INFO - 2023-04-21 08:42:05 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:42:05 --> Controller Class Initialized
DEBUG - 2023-04-21 08:42:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:42:07 --> Final output sent to browser
DEBUG - 2023-04-21 08:42:07 --> Total execution time: 1.1074
INFO - 2023-04-21 08:42:18 --> Config Class Initialized
INFO - 2023-04-21 08:42:18 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:42:18 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:42:18 --> Utf8 Class Initialized
INFO - 2023-04-21 08:42:18 --> URI Class Initialized
INFO - 2023-04-21 08:42:18 --> Router Class Initialized
INFO - 2023-04-21 08:42:18 --> Output Class Initialized
INFO - 2023-04-21 08:42:18 --> Security Class Initialized
DEBUG - 2023-04-21 08:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:42:18 --> Input Class Initialized
INFO - 2023-04-21 08:42:18 --> Language Class Initialized
INFO - 2023-04-21 08:42:18 --> Language Class Initialized
INFO - 2023-04-21 08:42:18 --> Config Class Initialized
INFO - 2023-04-21 08:42:18 --> Loader Class Initialized
INFO - 2023-04-21 08:42:18 --> Helper loaded: url_helper
INFO - 2023-04-21 08:42:18 --> Helper loaded: file_helper
INFO - 2023-04-21 08:42:18 --> Helper loaded: form_helper
INFO - 2023-04-21 08:42:18 --> Helper loaded: my_helper
INFO - 2023-04-21 08:42:18 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:42:18 --> Controller Class Initialized
DEBUG - 2023-04-21 08:42:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:42:19 --> Final output sent to browser
DEBUG - 2023-04-21 08:42:19 --> Total execution time: 1.1073
INFO - 2023-04-21 08:42:30 --> Config Class Initialized
INFO - 2023-04-21 08:42:30 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:42:30 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:42:30 --> Utf8 Class Initialized
INFO - 2023-04-21 08:42:30 --> URI Class Initialized
INFO - 2023-04-21 08:42:30 --> Router Class Initialized
INFO - 2023-04-21 08:42:30 --> Output Class Initialized
INFO - 2023-04-21 08:42:30 --> Security Class Initialized
DEBUG - 2023-04-21 08:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:42:30 --> Input Class Initialized
INFO - 2023-04-21 08:42:30 --> Language Class Initialized
INFO - 2023-04-21 08:42:30 --> Language Class Initialized
INFO - 2023-04-21 08:42:30 --> Config Class Initialized
INFO - 2023-04-21 08:42:30 --> Loader Class Initialized
INFO - 2023-04-21 08:42:30 --> Helper loaded: url_helper
INFO - 2023-04-21 08:42:30 --> Helper loaded: file_helper
INFO - 2023-04-21 08:42:30 --> Helper loaded: form_helper
INFO - 2023-04-21 08:42:30 --> Helper loaded: my_helper
INFO - 2023-04-21 08:42:30 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:42:30 --> Controller Class Initialized
DEBUG - 2023-04-21 08:42:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:42:31 --> Final output sent to browser
DEBUG - 2023-04-21 08:42:31 --> Total execution time: 1.1166
INFO - 2023-04-21 08:42:51 --> Config Class Initialized
INFO - 2023-04-21 08:42:51 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:42:51 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:42:51 --> Utf8 Class Initialized
INFO - 2023-04-21 08:42:51 --> URI Class Initialized
INFO - 2023-04-21 08:42:51 --> Router Class Initialized
INFO - 2023-04-21 08:42:51 --> Output Class Initialized
INFO - 2023-04-21 08:42:51 --> Security Class Initialized
DEBUG - 2023-04-21 08:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:42:51 --> Input Class Initialized
INFO - 2023-04-21 08:42:51 --> Language Class Initialized
INFO - 2023-04-21 08:42:51 --> Language Class Initialized
INFO - 2023-04-21 08:42:51 --> Config Class Initialized
INFO - 2023-04-21 08:42:51 --> Loader Class Initialized
INFO - 2023-04-21 08:42:51 --> Helper loaded: url_helper
INFO - 2023-04-21 08:42:51 --> Helper loaded: file_helper
INFO - 2023-04-21 08:42:51 --> Helper loaded: form_helper
INFO - 2023-04-21 08:42:51 --> Helper loaded: my_helper
INFO - 2023-04-21 08:42:51 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:42:51 --> Controller Class Initialized
DEBUG - 2023-04-21 08:42:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 08:42:52 --> Final output sent to browser
DEBUG - 2023-04-21 08:42:52 --> Total execution time: 1.1058
INFO - 2023-04-21 08:45:23 --> Config Class Initialized
INFO - 2023-04-21 08:45:23 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:45:23 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:45:23 --> Utf8 Class Initialized
INFO - 2023-04-21 08:45:23 --> URI Class Initialized
INFO - 2023-04-21 08:45:23 --> Router Class Initialized
INFO - 2023-04-21 08:45:23 --> Output Class Initialized
INFO - 2023-04-21 08:45:23 --> Security Class Initialized
DEBUG - 2023-04-21 08:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:45:23 --> Input Class Initialized
INFO - 2023-04-21 08:45:23 --> Language Class Initialized
INFO - 2023-04-21 08:45:23 --> Language Class Initialized
INFO - 2023-04-21 08:45:23 --> Config Class Initialized
INFO - 2023-04-21 08:45:23 --> Loader Class Initialized
INFO - 2023-04-21 08:45:23 --> Helper loaded: url_helper
INFO - 2023-04-21 08:45:23 --> Helper loaded: file_helper
INFO - 2023-04-21 08:45:23 --> Helper loaded: form_helper
INFO - 2023-04-21 08:45:23 --> Helper loaded: my_helper
INFO - 2023-04-21 08:45:23 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:45:23 --> Controller Class Initialized
DEBUG - 2023-04-21 08:45:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-21 08:45:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:45:23 --> Final output sent to browser
DEBUG - 2023-04-21 08:45:23 --> Total execution time: 0.0334
INFO - 2023-04-21 08:45:26 --> Config Class Initialized
INFO - 2023-04-21 08:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:45:26 --> Utf8 Class Initialized
INFO - 2023-04-21 08:45:26 --> URI Class Initialized
INFO - 2023-04-21 08:45:26 --> Router Class Initialized
INFO - 2023-04-21 08:45:26 --> Output Class Initialized
INFO - 2023-04-21 08:45:26 --> Security Class Initialized
DEBUG - 2023-04-21 08:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:45:26 --> Input Class Initialized
INFO - 2023-04-21 08:45:26 --> Language Class Initialized
INFO - 2023-04-21 08:45:26 --> Language Class Initialized
INFO - 2023-04-21 08:45:26 --> Config Class Initialized
INFO - 2023-04-21 08:45:26 --> Loader Class Initialized
INFO - 2023-04-21 08:45:26 --> Helper loaded: url_helper
INFO - 2023-04-21 08:45:26 --> Helper loaded: file_helper
INFO - 2023-04-21 08:45:26 --> Helper loaded: form_helper
INFO - 2023-04-21 08:45:26 --> Helper loaded: my_helper
INFO - 2023-04-21 08:45:26 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:45:26 --> Controller Class Initialized
DEBUG - 2023-04-21 08:45:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-04-21 08:45:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:45:26 --> Final output sent to browser
DEBUG - 2023-04-21 08:45:26 --> Total execution time: 0.0343
INFO - 2023-04-21 08:45:26 --> Config Class Initialized
INFO - 2023-04-21 08:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:45:26 --> Utf8 Class Initialized
INFO - 2023-04-21 08:45:26 --> URI Class Initialized
INFO - 2023-04-21 08:45:26 --> Router Class Initialized
INFO - 2023-04-21 08:45:26 --> Output Class Initialized
INFO - 2023-04-21 08:45:26 --> Security Class Initialized
DEBUG - 2023-04-21 08:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:45:26 --> Input Class Initialized
INFO - 2023-04-21 08:45:26 --> Language Class Initialized
INFO - 2023-04-21 08:45:26 --> Language Class Initialized
INFO - 2023-04-21 08:45:26 --> Config Class Initialized
INFO - 2023-04-21 08:45:26 --> Loader Class Initialized
INFO - 2023-04-21 08:45:26 --> Helper loaded: url_helper
INFO - 2023-04-21 08:45:26 --> Helper loaded: file_helper
INFO - 2023-04-21 08:45:26 --> Helper loaded: form_helper
INFO - 2023-04-21 08:45:26 --> Helper loaded: my_helper
INFO - 2023-04-21 08:45:26 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:45:26 --> Controller Class Initialized
INFO - 2023-04-21 08:45:27 --> Config Class Initialized
INFO - 2023-04-21 08:45:27 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:45:27 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:45:27 --> Utf8 Class Initialized
INFO - 2023-04-21 08:45:27 --> URI Class Initialized
INFO - 2023-04-21 08:45:27 --> Router Class Initialized
INFO - 2023-04-21 08:45:27 --> Output Class Initialized
INFO - 2023-04-21 08:45:27 --> Security Class Initialized
DEBUG - 2023-04-21 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:45:27 --> Input Class Initialized
INFO - 2023-04-21 08:45:27 --> Language Class Initialized
INFO - 2023-04-21 08:45:27 --> Language Class Initialized
INFO - 2023-04-21 08:45:27 --> Config Class Initialized
INFO - 2023-04-21 08:45:27 --> Loader Class Initialized
INFO - 2023-04-21 08:45:27 --> Helper loaded: url_helper
INFO - 2023-04-21 08:45:27 --> Helper loaded: file_helper
INFO - 2023-04-21 08:45:27 --> Helper loaded: form_helper
INFO - 2023-04-21 08:45:27 --> Helper loaded: my_helper
INFO - 2023-04-21 08:45:27 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:45:27 --> Controller Class Initialized
INFO - 2023-04-21 08:45:27 --> Final output sent to browser
DEBUG - 2023-04-21 08:45:27 --> Total execution time: 0.0391
INFO - 2023-04-21 08:45:29 --> Config Class Initialized
INFO - 2023-04-21 08:45:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:45:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:45:29 --> Utf8 Class Initialized
INFO - 2023-04-21 08:45:29 --> URI Class Initialized
INFO - 2023-04-21 08:45:29 --> Router Class Initialized
INFO - 2023-04-21 08:45:29 --> Output Class Initialized
INFO - 2023-04-21 08:45:29 --> Security Class Initialized
DEBUG - 2023-04-21 08:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:45:29 --> Input Class Initialized
INFO - 2023-04-21 08:45:29 --> Language Class Initialized
INFO - 2023-04-21 08:45:29 --> Language Class Initialized
INFO - 2023-04-21 08:45:29 --> Config Class Initialized
INFO - 2023-04-21 08:45:29 --> Loader Class Initialized
INFO - 2023-04-21 08:45:29 --> Helper loaded: url_helper
INFO - 2023-04-21 08:45:29 --> Helper loaded: file_helper
INFO - 2023-04-21 08:45:29 --> Helper loaded: form_helper
INFO - 2023-04-21 08:45:29 --> Helper loaded: my_helper
INFO - 2023-04-21 08:45:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:45:29 --> Controller Class Initialized
INFO - 2023-04-21 08:45:29 --> Final output sent to browser
DEBUG - 2023-04-21 08:45:29 --> Total execution time: 0.0237
INFO - 2023-04-21 08:45:31 --> Config Class Initialized
INFO - 2023-04-21 08:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-21 08:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-21 08:45:31 --> Utf8 Class Initialized
INFO - 2023-04-21 08:45:31 --> URI Class Initialized
INFO - 2023-04-21 08:45:31 --> Router Class Initialized
INFO - 2023-04-21 08:45:31 --> Output Class Initialized
INFO - 2023-04-21 08:45:31 --> Security Class Initialized
DEBUG - 2023-04-21 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 08:45:31 --> Input Class Initialized
INFO - 2023-04-21 08:45:31 --> Language Class Initialized
INFO - 2023-04-21 08:45:31 --> Language Class Initialized
INFO - 2023-04-21 08:45:31 --> Config Class Initialized
INFO - 2023-04-21 08:45:31 --> Loader Class Initialized
INFO - 2023-04-21 08:45:31 --> Helper loaded: url_helper
INFO - 2023-04-21 08:45:31 --> Helper loaded: file_helper
INFO - 2023-04-21 08:45:31 --> Helper loaded: form_helper
INFO - 2023-04-21 08:45:31 --> Helper loaded: my_helper
INFO - 2023-04-21 08:45:31 --> Database Driver Class Initialized
DEBUG - 2023-04-21 08:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 08:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 08:45:31 --> Controller Class Initialized
DEBUG - 2023-04-21 08:45:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-21 08:45:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 08:45:31 --> Final output sent to browser
DEBUG - 2023-04-21 08:45:31 --> Total execution time: 0.0262
INFO - 2023-04-21 09:03:19 --> Config Class Initialized
INFO - 2023-04-21 09:03:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:19 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:19 --> URI Class Initialized
INFO - 2023-04-21 09:03:19 --> Router Class Initialized
INFO - 2023-04-21 09:03:19 --> Output Class Initialized
INFO - 2023-04-21 09:03:19 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:19 --> Input Class Initialized
INFO - 2023-04-21 09:03:19 --> Language Class Initialized
INFO - 2023-04-21 09:03:19 --> Language Class Initialized
INFO - 2023-04-21 09:03:19 --> Config Class Initialized
INFO - 2023-04-21 09:03:19 --> Loader Class Initialized
INFO - 2023-04-21 09:03:19 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:19 --> Controller Class Initialized
INFO - 2023-04-21 09:03:19 --> Helper loaded: cookie_helper
INFO - 2023-04-21 09:03:19 --> Config Class Initialized
INFO - 2023-04-21 09:03:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:19 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:19 --> URI Class Initialized
INFO - 2023-04-21 09:03:19 --> Router Class Initialized
INFO - 2023-04-21 09:03:19 --> Output Class Initialized
INFO - 2023-04-21 09:03:19 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:19 --> Input Class Initialized
INFO - 2023-04-21 09:03:19 --> Language Class Initialized
INFO - 2023-04-21 09:03:19 --> Language Class Initialized
INFO - 2023-04-21 09:03:19 --> Config Class Initialized
INFO - 2023-04-21 09:03:19 --> Loader Class Initialized
INFO - 2023-04-21 09:03:19 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:19 --> Controller Class Initialized
INFO - 2023-04-21 09:03:19 --> Config Class Initialized
INFO - 2023-04-21 09:03:19 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:19 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:19 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:19 --> URI Class Initialized
INFO - 2023-04-21 09:03:19 --> Router Class Initialized
INFO - 2023-04-21 09:03:19 --> Output Class Initialized
INFO - 2023-04-21 09:03:19 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:19 --> Input Class Initialized
INFO - 2023-04-21 09:03:19 --> Language Class Initialized
INFO - 2023-04-21 09:03:19 --> Language Class Initialized
INFO - 2023-04-21 09:03:19 --> Config Class Initialized
INFO - 2023-04-21 09:03:19 --> Loader Class Initialized
INFO - 2023-04-21 09:03:19 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:19 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:19 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:19 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-21 09:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:19 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:19 --> Total execution time: 0.0262
INFO - 2023-04-21 09:03:29 --> Config Class Initialized
INFO - 2023-04-21 09:03:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:29 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:29 --> URI Class Initialized
INFO - 2023-04-21 09:03:29 --> Router Class Initialized
INFO - 2023-04-21 09:03:29 --> Output Class Initialized
INFO - 2023-04-21 09:03:29 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:29 --> Input Class Initialized
INFO - 2023-04-21 09:03:29 --> Language Class Initialized
INFO - 2023-04-21 09:03:29 --> Language Class Initialized
INFO - 2023-04-21 09:03:29 --> Config Class Initialized
INFO - 2023-04-21 09:03:29 --> Loader Class Initialized
INFO - 2023-04-21 09:03:29 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:29 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:29 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:29 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:29 --> Controller Class Initialized
INFO - 2023-04-21 09:03:29 --> Helper loaded: cookie_helper
INFO - 2023-04-21 09:03:29 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:29 --> Total execution time: 0.0378
INFO - 2023-04-21 09:03:29 --> Config Class Initialized
INFO - 2023-04-21 09:03:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:29 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:29 --> URI Class Initialized
INFO - 2023-04-21 09:03:29 --> Router Class Initialized
INFO - 2023-04-21 09:03:29 --> Output Class Initialized
INFO - 2023-04-21 09:03:29 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:29 --> Input Class Initialized
INFO - 2023-04-21 09:03:29 --> Language Class Initialized
INFO - 2023-04-21 09:03:29 --> Language Class Initialized
INFO - 2023-04-21 09:03:29 --> Config Class Initialized
INFO - 2023-04-21 09:03:29 --> Loader Class Initialized
INFO - 2023-04-21 09:03:29 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:29 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:29 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:29 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:29 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-21 09:03:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:29 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:29 --> Total execution time: 0.0472
INFO - 2023-04-21 09:03:34 --> Config Class Initialized
INFO - 2023-04-21 09:03:34 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:34 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:34 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:34 --> URI Class Initialized
INFO - 2023-04-21 09:03:34 --> Router Class Initialized
INFO - 2023-04-21 09:03:34 --> Output Class Initialized
INFO - 2023-04-21 09:03:34 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:34 --> Input Class Initialized
INFO - 2023-04-21 09:03:34 --> Language Class Initialized
INFO - 2023-04-21 09:03:34 --> Language Class Initialized
INFO - 2023-04-21 09:03:34 --> Config Class Initialized
INFO - 2023-04-21 09:03:34 --> Loader Class Initialized
INFO - 2023-04-21 09:03:34 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:34 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:34 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:34 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:34 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:34 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-21 09:03:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:34 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:34 --> Total execution time: 0.0273
INFO - 2023-04-21 09:03:35 --> Config Class Initialized
INFO - 2023-04-21 09:03:35 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:35 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:35 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:35 --> URI Class Initialized
INFO - 2023-04-21 09:03:35 --> Router Class Initialized
INFO - 2023-04-21 09:03:35 --> Output Class Initialized
INFO - 2023-04-21 09:03:35 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:35 --> Input Class Initialized
INFO - 2023-04-21 09:03:35 --> Language Class Initialized
INFO - 2023-04-21 09:03:35 --> Language Class Initialized
INFO - 2023-04-21 09:03:35 --> Config Class Initialized
INFO - 2023-04-21 09:03:35 --> Loader Class Initialized
INFO - 2023-04-21 09:03:35 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:35 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:35 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:35 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:35 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:35 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-04-21 09:03:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:35 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:35 --> Total execution time: 0.0461
INFO - 2023-04-21 09:03:39 --> Config Class Initialized
INFO - 2023-04-21 09:03:39 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:39 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:39 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:39 --> URI Class Initialized
INFO - 2023-04-21 09:03:39 --> Router Class Initialized
INFO - 2023-04-21 09:03:39 --> Output Class Initialized
INFO - 2023-04-21 09:03:39 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:39 --> Input Class Initialized
INFO - 2023-04-21 09:03:39 --> Language Class Initialized
INFO - 2023-04-21 09:03:39 --> Language Class Initialized
INFO - 2023-04-21 09:03:39 --> Config Class Initialized
INFO - 2023-04-21 09:03:39 --> Loader Class Initialized
INFO - 2023-04-21 09:03:39 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:39 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:39 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:39 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:39 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:39 --> Controller Class Initialized
INFO - 2023-04-21 09:03:39 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:39 --> Total execution time: 0.0446
INFO - 2023-04-21 09:03:50 --> Config Class Initialized
INFO - 2023-04-21 09:03:50 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:50 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:50 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:50 --> URI Class Initialized
INFO - 2023-04-21 09:03:50 --> Router Class Initialized
INFO - 2023-04-21 09:03:50 --> Output Class Initialized
INFO - 2023-04-21 09:03:50 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:50 --> Input Class Initialized
INFO - 2023-04-21 09:03:50 --> Language Class Initialized
INFO - 2023-04-21 09:03:50 --> Language Class Initialized
INFO - 2023-04-21 09:03:50 --> Config Class Initialized
INFO - 2023-04-21 09:03:50 --> Loader Class Initialized
INFO - 2023-04-21 09:03:50 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:50 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:50 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:50 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:50 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:50 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-21 09:03:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:50 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:50 --> Total execution time: 0.0271
INFO - 2023-04-21 09:03:51 --> Config Class Initialized
INFO - 2023-04-21 09:03:51 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:51 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:51 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:51 --> URI Class Initialized
INFO - 2023-04-21 09:03:51 --> Router Class Initialized
INFO - 2023-04-21 09:03:51 --> Output Class Initialized
INFO - 2023-04-21 09:03:51 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:51 --> Input Class Initialized
INFO - 2023-04-21 09:03:51 --> Language Class Initialized
INFO - 2023-04-21 09:03:51 --> Language Class Initialized
INFO - 2023-04-21 09:03:51 --> Config Class Initialized
INFO - 2023-04-21 09:03:51 --> Loader Class Initialized
INFO - 2023-04-21 09:03:51 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:51 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:51 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:51 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:51 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:51 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-04-21 09:03:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:51 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:51 --> Total execution time: 0.0269
INFO - 2023-04-21 09:03:51 --> Config Class Initialized
INFO - 2023-04-21 09:03:51 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:51 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:51 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:51 --> URI Class Initialized
INFO - 2023-04-21 09:03:51 --> Router Class Initialized
INFO - 2023-04-21 09:03:51 --> Output Class Initialized
INFO - 2023-04-21 09:03:51 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:51 --> Input Class Initialized
INFO - 2023-04-21 09:03:51 --> Language Class Initialized
INFO - 2023-04-21 09:03:51 --> Language Class Initialized
INFO - 2023-04-21 09:03:51 --> Config Class Initialized
INFO - 2023-04-21 09:03:51 --> Loader Class Initialized
INFO - 2023-04-21 09:03:51 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:51 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:51 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:51 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:51 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:51 --> Controller Class Initialized
INFO - 2023-04-21 09:03:53 --> Config Class Initialized
INFO - 2023-04-21 09:03:53 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:03:53 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:03:53 --> Utf8 Class Initialized
INFO - 2023-04-21 09:03:53 --> URI Class Initialized
INFO - 2023-04-21 09:03:53 --> Router Class Initialized
INFO - 2023-04-21 09:03:53 --> Output Class Initialized
INFO - 2023-04-21 09:03:53 --> Security Class Initialized
DEBUG - 2023-04-21 09:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:03:53 --> Input Class Initialized
INFO - 2023-04-21 09:03:53 --> Language Class Initialized
INFO - 2023-04-21 09:03:53 --> Language Class Initialized
INFO - 2023-04-21 09:03:53 --> Config Class Initialized
INFO - 2023-04-21 09:03:53 --> Loader Class Initialized
INFO - 2023-04-21 09:03:53 --> Helper loaded: url_helper
INFO - 2023-04-21 09:03:53 --> Helper loaded: file_helper
INFO - 2023-04-21 09:03:53 --> Helper loaded: form_helper
INFO - 2023-04-21 09:03:53 --> Helper loaded: my_helper
INFO - 2023-04-21 09:03:53 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:03:53 --> Controller Class Initialized
DEBUG - 2023-04-21 09:03:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-21 09:03:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:03:53 --> Final output sent to browser
DEBUG - 2023-04-21 09:03:53 --> Total execution time: 0.0274
INFO - 2023-04-21 09:07:03 --> Config Class Initialized
INFO - 2023-04-21 09:07:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:07:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:07:03 --> Utf8 Class Initialized
INFO - 2023-04-21 09:07:03 --> URI Class Initialized
INFO - 2023-04-21 09:07:03 --> Router Class Initialized
INFO - 2023-04-21 09:07:03 --> Output Class Initialized
INFO - 2023-04-21 09:07:03 --> Security Class Initialized
DEBUG - 2023-04-21 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:07:03 --> Input Class Initialized
INFO - 2023-04-21 09:07:03 --> Language Class Initialized
INFO - 2023-04-21 09:07:03 --> Language Class Initialized
INFO - 2023-04-21 09:07:03 --> Config Class Initialized
INFO - 2023-04-21 09:07:03 --> Loader Class Initialized
INFO - 2023-04-21 09:07:03 --> Helper loaded: url_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: file_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: form_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: my_helper
INFO - 2023-04-21 09:07:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:07:03 --> Controller Class Initialized
INFO - 2023-04-21 09:07:03 --> Helper loaded: cookie_helper
INFO - 2023-04-21 09:07:03 --> Config Class Initialized
INFO - 2023-04-21 09:07:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:07:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:07:03 --> Utf8 Class Initialized
INFO - 2023-04-21 09:07:03 --> URI Class Initialized
INFO - 2023-04-21 09:07:03 --> Router Class Initialized
INFO - 2023-04-21 09:07:03 --> Output Class Initialized
INFO - 2023-04-21 09:07:03 --> Security Class Initialized
DEBUG - 2023-04-21 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:07:03 --> Input Class Initialized
INFO - 2023-04-21 09:07:03 --> Language Class Initialized
INFO - 2023-04-21 09:07:03 --> Language Class Initialized
INFO - 2023-04-21 09:07:03 --> Config Class Initialized
INFO - 2023-04-21 09:07:03 --> Loader Class Initialized
INFO - 2023-04-21 09:07:03 --> Helper loaded: url_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: file_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: form_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: my_helper
INFO - 2023-04-21 09:07:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:07:03 --> Controller Class Initialized
INFO - 2023-04-21 09:07:03 --> Config Class Initialized
INFO - 2023-04-21 09:07:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:07:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:07:03 --> Utf8 Class Initialized
INFO - 2023-04-21 09:07:03 --> URI Class Initialized
INFO - 2023-04-21 09:07:03 --> Router Class Initialized
INFO - 2023-04-21 09:07:03 --> Output Class Initialized
INFO - 2023-04-21 09:07:03 --> Security Class Initialized
DEBUG - 2023-04-21 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:07:03 --> Input Class Initialized
INFO - 2023-04-21 09:07:03 --> Language Class Initialized
INFO - 2023-04-21 09:07:03 --> Language Class Initialized
INFO - 2023-04-21 09:07:03 --> Config Class Initialized
INFO - 2023-04-21 09:07:03 --> Loader Class Initialized
INFO - 2023-04-21 09:07:03 --> Helper loaded: url_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: file_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: form_helper
INFO - 2023-04-21 09:07:03 --> Helper loaded: my_helper
INFO - 2023-04-21 09:07:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:07:03 --> Controller Class Initialized
DEBUG - 2023-04-21 09:07:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-21 09:07:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-21 09:07:03 --> Final output sent to browser
DEBUG - 2023-04-21 09:07:03 --> Total execution time: 0.0229
INFO - 2023-04-21 09:15:43 --> Config Class Initialized
INFO - 2023-04-21 09:15:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:15:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:15:43 --> Utf8 Class Initialized
INFO - 2023-04-21 09:15:43 --> URI Class Initialized
INFO - 2023-04-21 09:15:43 --> Router Class Initialized
INFO - 2023-04-21 09:15:43 --> Output Class Initialized
INFO - 2023-04-21 09:15:43 --> Security Class Initialized
DEBUG - 2023-04-21 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:15:43 --> Input Class Initialized
INFO - 2023-04-21 09:15:43 --> Language Class Initialized
INFO - 2023-04-21 09:15:43 --> Language Class Initialized
INFO - 2023-04-21 09:15:43 --> Config Class Initialized
INFO - 2023-04-21 09:15:43 --> Loader Class Initialized
INFO - 2023-04-21 09:15:43 --> Helper loaded: url_helper
INFO - 2023-04-21 09:15:43 --> Helper loaded: file_helper
INFO - 2023-04-21 09:15:43 --> Helper loaded: form_helper
INFO - 2023-04-21 09:15:43 --> Helper loaded: my_helper
INFO - 2023-04-21 09:15:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:15:43 --> Controller Class Initialized
INFO - 2023-04-21 09:16:04 --> Config Class Initialized
INFO - 2023-04-21 09:16:04 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:16:04 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:16:04 --> Utf8 Class Initialized
INFO - 2023-04-21 09:16:04 --> URI Class Initialized
INFO - 2023-04-21 09:16:04 --> Router Class Initialized
INFO - 2023-04-21 09:16:04 --> Output Class Initialized
INFO - 2023-04-21 09:16:04 --> Security Class Initialized
DEBUG - 2023-04-21 09:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:16:04 --> Input Class Initialized
INFO - 2023-04-21 09:16:04 --> Language Class Initialized
INFO - 2023-04-21 09:16:04 --> Language Class Initialized
INFO - 2023-04-21 09:16:04 --> Config Class Initialized
INFO - 2023-04-21 09:16:04 --> Loader Class Initialized
INFO - 2023-04-21 09:16:04 --> Helper loaded: url_helper
INFO - 2023-04-21 09:16:04 --> Helper loaded: file_helper
INFO - 2023-04-21 09:16:04 --> Helper loaded: form_helper
INFO - 2023-04-21 09:16:04 --> Helper loaded: my_helper
INFO - 2023-04-21 09:16:04 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:16:04 --> Controller Class Initialized
DEBUG - 2023-04-21 09:16:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:16:05 --> Final output sent to browser
DEBUG - 2023-04-21 09:16:05 --> Total execution time: 1.1638
INFO - 2023-04-21 09:17:17 --> Config Class Initialized
INFO - 2023-04-21 09:17:17 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:17:17 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:17:17 --> Utf8 Class Initialized
INFO - 2023-04-21 09:17:17 --> URI Class Initialized
INFO - 2023-04-21 09:17:17 --> Router Class Initialized
INFO - 2023-04-21 09:17:17 --> Output Class Initialized
INFO - 2023-04-21 09:17:17 --> Security Class Initialized
DEBUG - 2023-04-21 09:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:17:17 --> Input Class Initialized
INFO - 2023-04-21 09:17:17 --> Language Class Initialized
INFO - 2023-04-21 09:17:17 --> Language Class Initialized
INFO - 2023-04-21 09:17:17 --> Config Class Initialized
INFO - 2023-04-21 09:17:17 --> Loader Class Initialized
INFO - 2023-04-21 09:17:17 --> Helper loaded: url_helper
INFO - 2023-04-21 09:17:17 --> Helper loaded: file_helper
INFO - 2023-04-21 09:17:17 --> Helper loaded: form_helper
INFO - 2023-04-21 09:17:17 --> Helper loaded: my_helper
INFO - 2023-04-21 09:17:17 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:17:17 --> Controller Class Initialized
DEBUG - 2023-04-21 09:17:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:17:18 --> Final output sent to browser
DEBUG - 2023-04-21 09:17:18 --> Total execution time: 1.1634
INFO - 2023-04-21 09:17:53 --> Config Class Initialized
INFO - 2023-04-21 09:17:53 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:17:53 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:17:53 --> Utf8 Class Initialized
INFO - 2023-04-21 09:17:53 --> URI Class Initialized
INFO - 2023-04-21 09:17:53 --> Router Class Initialized
INFO - 2023-04-21 09:17:53 --> Output Class Initialized
INFO - 2023-04-21 09:17:53 --> Security Class Initialized
DEBUG - 2023-04-21 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:17:53 --> Input Class Initialized
INFO - 2023-04-21 09:17:53 --> Language Class Initialized
INFO - 2023-04-21 09:17:53 --> Language Class Initialized
INFO - 2023-04-21 09:17:53 --> Config Class Initialized
INFO - 2023-04-21 09:17:53 --> Loader Class Initialized
INFO - 2023-04-21 09:17:53 --> Helper loaded: url_helper
INFO - 2023-04-21 09:17:53 --> Helper loaded: file_helper
INFO - 2023-04-21 09:17:53 --> Helper loaded: form_helper
INFO - 2023-04-21 09:17:53 --> Helper loaded: my_helper
INFO - 2023-04-21 09:17:53 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:17:53 --> Controller Class Initialized
DEBUG - 2023-04-21 09:17:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:17:54 --> Final output sent to browser
DEBUG - 2023-04-21 09:17:54 --> Total execution time: 1.1224
INFO - 2023-04-21 09:30:39 --> Config Class Initialized
INFO - 2023-04-21 09:30:39 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:30:39 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:30:39 --> Utf8 Class Initialized
INFO - 2023-04-21 09:30:39 --> URI Class Initialized
INFO - 2023-04-21 09:30:39 --> Router Class Initialized
INFO - 2023-04-21 09:30:39 --> Output Class Initialized
INFO - 2023-04-21 09:30:39 --> Security Class Initialized
DEBUG - 2023-04-21 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:30:39 --> Input Class Initialized
INFO - 2023-04-21 09:30:39 --> Language Class Initialized
INFO - 2023-04-21 09:30:39 --> Language Class Initialized
INFO - 2023-04-21 09:30:39 --> Config Class Initialized
INFO - 2023-04-21 09:30:39 --> Loader Class Initialized
INFO - 2023-04-21 09:30:39 --> Helper loaded: url_helper
INFO - 2023-04-21 09:30:39 --> Helper loaded: file_helper
INFO - 2023-04-21 09:30:39 --> Helper loaded: form_helper
INFO - 2023-04-21 09:30:39 --> Helper loaded: my_helper
INFO - 2023-04-21 09:30:39 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:30:39 --> Controller Class Initialized
DEBUG - 2023-04-21 09:30:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
ERROR - 2023-04-21 09:30:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:30:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:30:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:30:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:30:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:30:40 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2489
ERROR - 2023-04-21 09:30:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7657
ERROR - 2023-04-21 09:30:40 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output to browser, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 09:30:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 09:31:15 --> Config Class Initialized
INFO - 2023-04-21 09:31:15 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:31:15 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:31:15 --> Utf8 Class Initialized
INFO - 2023-04-21 09:31:15 --> URI Class Initialized
INFO - 2023-04-21 09:31:15 --> Router Class Initialized
INFO - 2023-04-21 09:31:15 --> Output Class Initialized
INFO - 2023-04-21 09:31:15 --> Security Class Initialized
DEBUG - 2023-04-21 09:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:31:15 --> Input Class Initialized
INFO - 2023-04-21 09:31:15 --> Language Class Initialized
INFO - 2023-04-21 09:31:15 --> Language Class Initialized
INFO - 2023-04-21 09:31:15 --> Config Class Initialized
INFO - 2023-04-21 09:31:15 --> Loader Class Initialized
INFO - 2023-04-21 09:31:15 --> Helper loaded: url_helper
INFO - 2023-04-21 09:31:15 --> Helper loaded: file_helper
INFO - 2023-04-21 09:31:15 --> Helper loaded: form_helper
INFO - 2023-04-21 09:31:15 --> Helper loaded: my_helper
INFO - 2023-04-21 09:31:15 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:31:15 --> Controller Class Initialized
DEBUG - 2023-04-21 09:31:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
ERROR - 2023-04-21 09:31:16 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:16 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:16 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:16 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:16 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:16 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2489
ERROR - 2023-04-21 09:31:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7657
ERROR - 2023-04-21 09:31:16 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output to browser, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 09:31:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 09:31:37 --> Config Class Initialized
INFO - 2023-04-21 09:31:37 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:31:37 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:31:37 --> Utf8 Class Initialized
INFO - 2023-04-21 09:31:37 --> URI Class Initialized
INFO - 2023-04-21 09:31:37 --> Router Class Initialized
INFO - 2023-04-21 09:31:37 --> Output Class Initialized
INFO - 2023-04-21 09:31:37 --> Security Class Initialized
DEBUG - 2023-04-21 09:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:31:37 --> Input Class Initialized
INFO - 2023-04-21 09:31:37 --> Language Class Initialized
INFO - 2023-04-21 09:31:37 --> Language Class Initialized
INFO - 2023-04-21 09:31:37 --> Config Class Initialized
INFO - 2023-04-21 09:31:37 --> Loader Class Initialized
INFO - 2023-04-21 09:31:37 --> Helper loaded: url_helper
INFO - 2023-04-21 09:31:37 --> Helper loaded: file_helper
INFO - 2023-04-21 09:31:37 --> Helper loaded: form_helper
INFO - 2023-04-21 09:31:37 --> Helper loaded: my_helper
INFO - 2023-04-21 09:31:37 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:31:37 --> Controller Class Initialized
DEBUG - 2023-04-21 09:31:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
ERROR - 2023-04-21 09:31:38 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:38 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:38 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:38 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:38 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:31:38 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2489
ERROR - 2023-04-21 09:31:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7657
ERROR - 2023-04-21 09:31:38 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output to browser, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 09:31:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 09:32:07 --> Config Class Initialized
INFO - 2023-04-21 09:32:07 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:32:07 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:32:07 --> Utf8 Class Initialized
INFO - 2023-04-21 09:32:07 --> URI Class Initialized
INFO - 2023-04-21 09:32:07 --> Router Class Initialized
INFO - 2023-04-21 09:32:07 --> Output Class Initialized
INFO - 2023-04-21 09:32:07 --> Security Class Initialized
DEBUG - 2023-04-21 09:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:32:07 --> Input Class Initialized
INFO - 2023-04-21 09:32:07 --> Language Class Initialized
INFO - 2023-04-21 09:32:07 --> Language Class Initialized
INFO - 2023-04-21 09:32:07 --> Config Class Initialized
INFO - 2023-04-21 09:32:07 --> Loader Class Initialized
INFO - 2023-04-21 09:32:07 --> Helper loaded: url_helper
INFO - 2023-04-21 09:32:07 --> Helper loaded: file_helper
INFO - 2023-04-21 09:32:07 --> Helper loaded: form_helper
INFO - 2023-04-21 09:32:07 --> Helper loaded: my_helper
INFO - 2023-04-21 09:32:07 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:32:07 --> Controller Class Initialized
DEBUG - 2023-04-21 09:32:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 09:32:08 --> Final output sent to browser
DEBUG - 2023-04-21 09:32:08 --> Total execution time: 1.1011
INFO - 2023-04-21 09:33:15 --> Config Class Initialized
INFO - 2023-04-21 09:33:15 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:33:15 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:33:15 --> Utf8 Class Initialized
INFO - 2023-04-21 09:33:15 --> URI Class Initialized
INFO - 2023-04-21 09:33:15 --> Router Class Initialized
INFO - 2023-04-21 09:33:15 --> Output Class Initialized
INFO - 2023-04-21 09:33:15 --> Security Class Initialized
DEBUG - 2023-04-21 09:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:33:15 --> Input Class Initialized
INFO - 2023-04-21 09:33:15 --> Language Class Initialized
INFO - 2023-04-21 09:33:15 --> Language Class Initialized
INFO - 2023-04-21 09:33:15 --> Config Class Initialized
INFO - 2023-04-21 09:33:15 --> Loader Class Initialized
INFO - 2023-04-21 09:33:15 --> Helper loaded: url_helper
INFO - 2023-04-21 09:33:15 --> Helper loaded: file_helper
INFO - 2023-04-21 09:33:15 --> Helper loaded: form_helper
INFO - 2023-04-21 09:33:15 --> Helper loaded: my_helper
INFO - 2023-04-21 09:33:15 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:33:15 --> Controller Class Initialized
DEBUG - 2023-04-21 09:33:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 09:33:16 --> Final output sent to browser
DEBUG - 2023-04-21 09:33:16 --> Total execution time: 1.0949
INFO - 2023-04-21 09:34:01 --> Config Class Initialized
INFO - 2023-04-21 09:34:01 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:34:01 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:34:01 --> Utf8 Class Initialized
INFO - 2023-04-21 09:34:01 --> URI Class Initialized
INFO - 2023-04-21 09:34:01 --> Router Class Initialized
INFO - 2023-04-21 09:34:01 --> Output Class Initialized
INFO - 2023-04-21 09:34:01 --> Security Class Initialized
DEBUG - 2023-04-21 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:34:01 --> Input Class Initialized
INFO - 2023-04-21 09:34:01 --> Language Class Initialized
INFO - 2023-04-21 09:34:01 --> Language Class Initialized
INFO - 2023-04-21 09:34:01 --> Config Class Initialized
INFO - 2023-04-21 09:34:01 --> Loader Class Initialized
INFO - 2023-04-21 09:34:01 --> Helper loaded: url_helper
INFO - 2023-04-21 09:34:01 --> Helper loaded: file_helper
INFO - 2023-04-21 09:34:01 --> Helper loaded: form_helper
INFO - 2023-04-21 09:34:01 --> Helper loaded: my_helper
INFO - 2023-04-21 09:34:01 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:34:01 --> Controller Class Initialized
DEBUG - 2023-04-21 09:34:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:02 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:02 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 09:34:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 09:34:58 --> Config Class Initialized
INFO - 2023-04-21 09:34:58 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:34:58 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:34:58 --> Utf8 Class Initialized
INFO - 2023-04-21 09:34:58 --> URI Class Initialized
INFO - 2023-04-21 09:34:58 --> Router Class Initialized
INFO - 2023-04-21 09:34:58 --> Output Class Initialized
INFO - 2023-04-21 09:34:58 --> Security Class Initialized
DEBUG - 2023-04-21 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:34:58 --> Input Class Initialized
INFO - 2023-04-21 09:34:58 --> Language Class Initialized
INFO - 2023-04-21 09:34:58 --> Language Class Initialized
INFO - 2023-04-21 09:34:58 --> Config Class Initialized
INFO - 2023-04-21 09:34:58 --> Loader Class Initialized
INFO - 2023-04-21 09:34:58 --> Helper loaded: url_helper
INFO - 2023-04-21 09:34:58 --> Helper loaded: file_helper
INFO - 2023-04-21 09:34:58 --> Helper loaded: form_helper
INFO - 2023-04-21 09:34:58 --> Helper loaded: my_helper
INFO - 2023-04-21 09:34:58 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:34:58 --> Controller Class Initialized
DEBUG - 2023-04-21 09:34:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:59 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:34:59 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 09:34:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 09:35:10 --> Config Class Initialized
INFO - 2023-04-21 09:35:10 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:35:10 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:35:10 --> Utf8 Class Initialized
INFO - 2023-04-21 09:35:10 --> URI Class Initialized
INFO - 2023-04-21 09:35:10 --> Router Class Initialized
INFO - 2023-04-21 09:35:10 --> Output Class Initialized
INFO - 2023-04-21 09:35:10 --> Security Class Initialized
DEBUG - 2023-04-21 09:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:35:10 --> Input Class Initialized
INFO - 2023-04-21 09:35:10 --> Language Class Initialized
INFO - 2023-04-21 09:35:10 --> Language Class Initialized
INFO - 2023-04-21 09:35:10 --> Config Class Initialized
INFO - 2023-04-21 09:35:10 --> Loader Class Initialized
INFO - 2023-04-21 09:35:10 --> Helper loaded: url_helper
INFO - 2023-04-21 09:35:10 --> Helper loaded: file_helper
INFO - 2023-04-21 09:35:10 --> Helper loaded: form_helper
INFO - 2023-04-21 09:35:10 --> Helper loaded: my_helper
INFO - 2023-04-21 09:35:10 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:35:10 --> Controller Class Initialized
DEBUG - 2023-04-21 09:35:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2483
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:35:11 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 2507
ERROR - 2023-04-21 09:35:11 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-04-21 09:35:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-04-21 09:35:21 --> Config Class Initialized
INFO - 2023-04-21 09:35:21 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:35:21 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:35:21 --> Utf8 Class Initialized
INFO - 2023-04-21 09:35:21 --> URI Class Initialized
INFO - 2023-04-21 09:35:21 --> Router Class Initialized
INFO - 2023-04-21 09:35:21 --> Output Class Initialized
INFO - 2023-04-21 09:35:21 --> Security Class Initialized
DEBUG - 2023-04-21 09:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:35:21 --> Input Class Initialized
INFO - 2023-04-21 09:35:21 --> Language Class Initialized
INFO - 2023-04-21 09:35:21 --> Language Class Initialized
INFO - 2023-04-21 09:35:21 --> Config Class Initialized
INFO - 2023-04-21 09:35:21 --> Loader Class Initialized
INFO - 2023-04-21 09:35:21 --> Helper loaded: url_helper
INFO - 2023-04-21 09:35:21 --> Helper loaded: file_helper
INFO - 2023-04-21 09:35:21 --> Helper loaded: form_helper
INFO - 2023-04-21 09:35:21 --> Helper loaded: my_helper
INFO - 2023-04-21 09:35:21 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:35:21 --> Controller Class Initialized
DEBUG - 2023-04-21 09:35:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:35:22 --> Final output sent to browser
DEBUG - 2023-04-21 09:35:22 --> Total execution time: 1.1283
INFO - 2023-04-21 09:36:59 --> Config Class Initialized
INFO - 2023-04-21 09:36:59 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:36:59 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:36:59 --> Utf8 Class Initialized
INFO - 2023-04-21 09:36:59 --> URI Class Initialized
INFO - 2023-04-21 09:36:59 --> Router Class Initialized
INFO - 2023-04-21 09:36:59 --> Output Class Initialized
INFO - 2023-04-21 09:36:59 --> Security Class Initialized
DEBUG - 2023-04-21 09:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:36:59 --> Input Class Initialized
INFO - 2023-04-21 09:36:59 --> Language Class Initialized
INFO - 2023-04-21 09:36:59 --> Language Class Initialized
INFO - 2023-04-21 09:36:59 --> Config Class Initialized
INFO - 2023-04-21 09:36:59 --> Loader Class Initialized
INFO - 2023-04-21 09:36:59 --> Helper loaded: url_helper
INFO - 2023-04-21 09:36:59 --> Helper loaded: file_helper
INFO - 2023-04-21 09:36:59 --> Helper loaded: form_helper
INFO - 2023-04-21 09:36:59 --> Helper loaded: my_helper
INFO - 2023-04-21 09:36:59 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:36:59 --> Controller Class Initialized
DEBUG - 2023-04-21 09:36:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:37:00 --> Final output sent to browser
DEBUG - 2023-04-21 09:37:00 --> Total execution time: 1.1800
INFO - 2023-04-21 09:37:18 --> Config Class Initialized
INFO - 2023-04-21 09:37:18 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:37:18 --> Utf8 Class Initialized
INFO - 2023-04-21 09:37:18 --> URI Class Initialized
INFO - 2023-04-21 09:37:18 --> Router Class Initialized
INFO - 2023-04-21 09:37:18 --> Output Class Initialized
INFO - 2023-04-21 09:37:18 --> Security Class Initialized
DEBUG - 2023-04-21 09:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:37:18 --> Input Class Initialized
INFO - 2023-04-21 09:37:18 --> Language Class Initialized
INFO - 2023-04-21 09:37:18 --> Language Class Initialized
INFO - 2023-04-21 09:37:18 --> Config Class Initialized
INFO - 2023-04-21 09:37:18 --> Loader Class Initialized
INFO - 2023-04-21 09:37:18 --> Helper loaded: url_helper
INFO - 2023-04-21 09:37:18 --> Helper loaded: file_helper
INFO - 2023-04-21 09:37:18 --> Helper loaded: form_helper
INFO - 2023-04-21 09:37:18 --> Helper loaded: my_helper
INFO - 2023-04-21 09:37:18 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:37:18 --> Controller Class Initialized
DEBUG - 2023-04-21 09:37:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:37:19 --> Final output sent to browser
DEBUG - 2023-04-21 09:37:19 --> Total execution time: 1.1023
INFO - 2023-04-21 09:39:48 --> Config Class Initialized
INFO - 2023-04-21 09:39:48 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:39:48 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:39:48 --> Utf8 Class Initialized
INFO - 2023-04-21 09:39:48 --> URI Class Initialized
INFO - 2023-04-21 09:39:48 --> Router Class Initialized
INFO - 2023-04-21 09:39:48 --> Output Class Initialized
INFO - 2023-04-21 09:39:48 --> Security Class Initialized
DEBUG - 2023-04-21 09:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:39:48 --> Input Class Initialized
INFO - 2023-04-21 09:39:48 --> Language Class Initialized
INFO - 2023-04-21 09:39:48 --> Language Class Initialized
INFO - 2023-04-21 09:39:48 --> Config Class Initialized
INFO - 2023-04-21 09:39:48 --> Loader Class Initialized
INFO - 2023-04-21 09:39:48 --> Helper loaded: url_helper
INFO - 2023-04-21 09:39:48 --> Helper loaded: file_helper
INFO - 2023-04-21 09:39:48 --> Helper loaded: form_helper
INFO - 2023-04-21 09:39:48 --> Helper loaded: my_helper
INFO - 2023-04-21 09:39:48 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:39:48 --> Controller Class Initialized
DEBUG - 2023-04-21 09:39:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:39:49 --> Final output sent to browser
DEBUG - 2023-04-21 09:39:49 --> Total execution time: 1.1865
INFO - 2023-04-21 09:40:29 --> Config Class Initialized
INFO - 2023-04-21 09:40:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:40:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:40:29 --> Utf8 Class Initialized
INFO - 2023-04-21 09:40:29 --> URI Class Initialized
INFO - 2023-04-21 09:40:29 --> Router Class Initialized
INFO - 2023-04-21 09:40:29 --> Output Class Initialized
INFO - 2023-04-21 09:40:29 --> Security Class Initialized
DEBUG - 2023-04-21 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:40:29 --> Input Class Initialized
INFO - 2023-04-21 09:40:29 --> Language Class Initialized
INFO - 2023-04-21 09:40:29 --> Language Class Initialized
INFO - 2023-04-21 09:40:29 --> Config Class Initialized
INFO - 2023-04-21 09:40:29 --> Loader Class Initialized
INFO - 2023-04-21 09:40:29 --> Helper loaded: url_helper
INFO - 2023-04-21 09:40:29 --> Helper loaded: file_helper
INFO - 2023-04-21 09:40:29 --> Helper loaded: form_helper
INFO - 2023-04-21 09:40:29 --> Helper loaded: my_helper
INFO - 2023-04-21 09:40:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:40:29 --> Controller Class Initialized
DEBUG - 2023-04-21 09:40:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:40:30 --> Final output sent to browser
DEBUG - 2023-04-21 09:40:30 --> Total execution time: 1.1184
INFO - 2023-04-21 09:40:49 --> Config Class Initialized
INFO - 2023-04-21 09:40:49 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:40:49 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:40:49 --> Utf8 Class Initialized
INFO - 2023-04-21 09:40:49 --> URI Class Initialized
INFO - 2023-04-21 09:40:49 --> Router Class Initialized
INFO - 2023-04-21 09:40:49 --> Output Class Initialized
INFO - 2023-04-21 09:40:49 --> Security Class Initialized
DEBUG - 2023-04-21 09:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:40:49 --> Input Class Initialized
INFO - 2023-04-21 09:40:49 --> Language Class Initialized
INFO - 2023-04-21 09:40:49 --> Language Class Initialized
INFO - 2023-04-21 09:40:49 --> Config Class Initialized
INFO - 2023-04-21 09:40:49 --> Loader Class Initialized
INFO - 2023-04-21 09:40:49 --> Helper loaded: url_helper
INFO - 2023-04-21 09:40:49 --> Helper loaded: file_helper
INFO - 2023-04-21 09:40:49 --> Helper loaded: form_helper
INFO - 2023-04-21 09:40:49 --> Helper loaded: my_helper
INFO - 2023-04-21 09:40:49 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:40:49 --> Controller Class Initialized
DEBUG - 2023-04-21 09:40:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:40:51 --> Final output sent to browser
DEBUG - 2023-04-21 09:40:51 --> Total execution time: 1.1234
INFO - 2023-04-21 09:41:14 --> Config Class Initialized
INFO - 2023-04-21 09:41:14 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:41:14 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:41:14 --> Utf8 Class Initialized
INFO - 2023-04-21 09:41:14 --> URI Class Initialized
INFO - 2023-04-21 09:41:14 --> Router Class Initialized
INFO - 2023-04-21 09:41:14 --> Output Class Initialized
INFO - 2023-04-21 09:41:14 --> Security Class Initialized
DEBUG - 2023-04-21 09:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:41:14 --> Input Class Initialized
INFO - 2023-04-21 09:41:14 --> Language Class Initialized
INFO - 2023-04-21 09:41:14 --> Language Class Initialized
INFO - 2023-04-21 09:41:14 --> Config Class Initialized
INFO - 2023-04-21 09:41:14 --> Loader Class Initialized
INFO - 2023-04-21 09:41:14 --> Helper loaded: url_helper
INFO - 2023-04-21 09:41:14 --> Helper loaded: file_helper
INFO - 2023-04-21 09:41:14 --> Helper loaded: form_helper
INFO - 2023-04-21 09:41:14 --> Helper loaded: my_helper
INFO - 2023-04-21 09:41:14 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:41:14 --> Controller Class Initialized
DEBUG - 2023-04-21 09:41:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:41:15 --> Final output sent to browser
DEBUG - 2023-04-21 09:41:15 --> Total execution time: 1.1149
INFO - 2023-04-21 09:42:08 --> Config Class Initialized
INFO - 2023-04-21 09:42:08 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:42:08 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:42:08 --> Utf8 Class Initialized
INFO - 2023-04-21 09:42:08 --> URI Class Initialized
INFO - 2023-04-21 09:42:08 --> Router Class Initialized
INFO - 2023-04-21 09:42:08 --> Output Class Initialized
INFO - 2023-04-21 09:42:08 --> Security Class Initialized
DEBUG - 2023-04-21 09:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:42:08 --> Input Class Initialized
INFO - 2023-04-21 09:42:08 --> Language Class Initialized
INFO - 2023-04-21 09:42:08 --> Language Class Initialized
INFO - 2023-04-21 09:42:08 --> Config Class Initialized
INFO - 2023-04-21 09:42:08 --> Loader Class Initialized
INFO - 2023-04-21 09:42:08 --> Helper loaded: url_helper
INFO - 2023-04-21 09:42:08 --> Helper loaded: file_helper
INFO - 2023-04-21 09:42:08 --> Helper loaded: form_helper
INFO - 2023-04-21 09:42:08 --> Helper loaded: my_helper
INFO - 2023-04-21 09:42:08 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:42:08 --> Controller Class Initialized
DEBUG - 2023-04-21 09:42:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:42:09 --> Final output sent to browser
DEBUG - 2023-04-21 09:42:09 --> Total execution time: 1.0583
INFO - 2023-04-21 09:42:36 --> Config Class Initialized
INFO - 2023-04-21 09:42:36 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:42:36 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:42:36 --> Utf8 Class Initialized
INFO - 2023-04-21 09:42:36 --> URI Class Initialized
INFO - 2023-04-21 09:42:36 --> Router Class Initialized
INFO - 2023-04-21 09:42:36 --> Output Class Initialized
INFO - 2023-04-21 09:42:36 --> Security Class Initialized
DEBUG - 2023-04-21 09:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:42:36 --> Input Class Initialized
INFO - 2023-04-21 09:42:36 --> Language Class Initialized
INFO - 2023-04-21 09:42:37 --> Language Class Initialized
INFO - 2023-04-21 09:42:37 --> Config Class Initialized
INFO - 2023-04-21 09:42:37 --> Loader Class Initialized
INFO - 2023-04-21 09:42:37 --> Helper loaded: url_helper
INFO - 2023-04-21 09:42:37 --> Helper loaded: file_helper
INFO - 2023-04-21 09:42:37 --> Helper loaded: form_helper
INFO - 2023-04-21 09:42:37 --> Helper loaded: my_helper
INFO - 2023-04-21 09:42:37 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:42:37 --> Controller Class Initialized
DEBUG - 2023-04-21 09:42:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:42:38 --> Final output sent to browser
DEBUG - 2023-04-21 09:42:38 --> Total execution time: 1.1044
INFO - 2023-04-21 09:42:54 --> Config Class Initialized
INFO - 2023-04-21 09:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:42:54 --> Utf8 Class Initialized
INFO - 2023-04-21 09:42:54 --> URI Class Initialized
INFO - 2023-04-21 09:42:54 --> Router Class Initialized
INFO - 2023-04-21 09:42:54 --> Output Class Initialized
INFO - 2023-04-21 09:42:54 --> Security Class Initialized
DEBUG - 2023-04-21 09:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:42:54 --> Input Class Initialized
INFO - 2023-04-21 09:42:54 --> Language Class Initialized
INFO - 2023-04-21 09:42:54 --> Language Class Initialized
INFO - 2023-04-21 09:42:54 --> Config Class Initialized
INFO - 2023-04-21 09:42:54 --> Loader Class Initialized
INFO - 2023-04-21 09:42:54 --> Helper loaded: url_helper
INFO - 2023-04-21 09:42:54 --> Helper loaded: file_helper
INFO - 2023-04-21 09:42:54 --> Helper loaded: form_helper
INFO - 2023-04-21 09:42:54 --> Helper loaded: my_helper
INFO - 2023-04-21 09:42:54 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:42:54 --> Controller Class Initialized
DEBUG - 2023-04-21 09:42:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:42:55 --> Final output sent to browser
DEBUG - 2023-04-21 09:42:55 --> Total execution time: 1.0957
INFO - 2023-04-21 09:43:15 --> Config Class Initialized
INFO - 2023-04-21 09:43:15 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:43:15 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:43:15 --> Utf8 Class Initialized
INFO - 2023-04-21 09:43:15 --> URI Class Initialized
INFO - 2023-04-21 09:43:15 --> Router Class Initialized
INFO - 2023-04-21 09:43:15 --> Output Class Initialized
INFO - 2023-04-21 09:43:15 --> Security Class Initialized
DEBUG - 2023-04-21 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:43:15 --> Input Class Initialized
INFO - 2023-04-21 09:43:15 --> Language Class Initialized
INFO - 2023-04-21 09:43:15 --> Language Class Initialized
INFO - 2023-04-21 09:43:15 --> Config Class Initialized
INFO - 2023-04-21 09:43:15 --> Loader Class Initialized
INFO - 2023-04-21 09:43:15 --> Helper loaded: url_helper
INFO - 2023-04-21 09:43:15 --> Helper loaded: file_helper
INFO - 2023-04-21 09:43:15 --> Helper loaded: form_helper
INFO - 2023-04-21 09:43:15 --> Helper loaded: my_helper
INFO - 2023-04-21 09:43:15 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:43:15 --> Controller Class Initialized
DEBUG - 2023-04-21 09:43:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:43:17 --> Final output sent to browser
DEBUG - 2023-04-21 09:43:17 --> Total execution time: 1.1298
INFO - 2023-04-21 09:43:43 --> Config Class Initialized
INFO - 2023-04-21 09:43:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:43:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:43:43 --> Utf8 Class Initialized
INFO - 2023-04-21 09:43:43 --> URI Class Initialized
INFO - 2023-04-21 09:43:43 --> Router Class Initialized
INFO - 2023-04-21 09:43:43 --> Output Class Initialized
INFO - 2023-04-21 09:43:43 --> Security Class Initialized
DEBUG - 2023-04-21 09:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:43:43 --> Input Class Initialized
INFO - 2023-04-21 09:43:43 --> Language Class Initialized
INFO - 2023-04-21 09:43:43 --> Language Class Initialized
INFO - 2023-04-21 09:43:43 --> Config Class Initialized
INFO - 2023-04-21 09:43:43 --> Loader Class Initialized
INFO - 2023-04-21 09:43:43 --> Helper loaded: url_helper
INFO - 2023-04-21 09:43:43 --> Helper loaded: file_helper
INFO - 2023-04-21 09:43:43 --> Helper loaded: form_helper
INFO - 2023-04-21 09:43:43 --> Helper loaded: my_helper
INFO - 2023-04-21 09:43:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:43:43 --> Controller Class Initialized
DEBUG - 2023-04-21 09:43:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:43:44 --> Final output sent to browser
DEBUG - 2023-04-21 09:43:44 --> Total execution time: 1.1161
INFO - 2023-04-21 09:44:10 --> Config Class Initialized
INFO - 2023-04-21 09:44:10 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:44:10 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:44:10 --> Utf8 Class Initialized
INFO - 2023-04-21 09:44:10 --> URI Class Initialized
INFO - 2023-04-21 09:44:10 --> Router Class Initialized
INFO - 2023-04-21 09:44:10 --> Output Class Initialized
INFO - 2023-04-21 09:44:10 --> Security Class Initialized
DEBUG - 2023-04-21 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:44:10 --> Input Class Initialized
INFO - 2023-04-21 09:44:10 --> Language Class Initialized
INFO - 2023-04-21 09:44:10 --> Language Class Initialized
INFO - 2023-04-21 09:44:10 --> Config Class Initialized
INFO - 2023-04-21 09:44:10 --> Loader Class Initialized
INFO - 2023-04-21 09:44:10 --> Helper loaded: url_helper
INFO - 2023-04-21 09:44:10 --> Helper loaded: file_helper
INFO - 2023-04-21 09:44:10 --> Helper loaded: form_helper
INFO - 2023-04-21 09:44:10 --> Helper loaded: my_helper
INFO - 2023-04-21 09:44:10 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:44:10 --> Controller Class Initialized
DEBUG - 2023-04-21 09:44:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:44:11 --> Final output sent to browser
DEBUG - 2023-04-21 09:44:11 --> Total execution time: 1.1354
INFO - 2023-04-21 09:44:22 --> Config Class Initialized
INFO - 2023-04-21 09:44:22 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:44:22 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:44:22 --> Utf8 Class Initialized
INFO - 2023-04-21 09:44:22 --> URI Class Initialized
INFO - 2023-04-21 09:44:22 --> Router Class Initialized
INFO - 2023-04-21 09:44:22 --> Output Class Initialized
INFO - 2023-04-21 09:44:22 --> Security Class Initialized
DEBUG - 2023-04-21 09:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:44:22 --> Input Class Initialized
INFO - 2023-04-21 09:44:22 --> Language Class Initialized
INFO - 2023-04-21 09:44:22 --> Language Class Initialized
INFO - 2023-04-21 09:44:22 --> Config Class Initialized
INFO - 2023-04-21 09:44:22 --> Loader Class Initialized
INFO - 2023-04-21 09:44:22 --> Helper loaded: url_helper
INFO - 2023-04-21 09:44:22 --> Helper loaded: file_helper
INFO - 2023-04-21 09:44:22 --> Helper loaded: form_helper
INFO - 2023-04-21 09:44:22 --> Helper loaded: my_helper
INFO - 2023-04-21 09:44:22 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:44:22 --> Controller Class Initialized
DEBUG - 2023-04-21 09:44:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:44:23 --> Final output sent to browser
DEBUG - 2023-04-21 09:44:23 --> Total execution time: 1.1131
INFO - 2023-04-21 09:44:43 --> Config Class Initialized
INFO - 2023-04-21 09:44:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:44:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:44:43 --> Utf8 Class Initialized
INFO - 2023-04-21 09:44:43 --> URI Class Initialized
INFO - 2023-04-21 09:44:43 --> Router Class Initialized
INFO - 2023-04-21 09:44:43 --> Output Class Initialized
INFO - 2023-04-21 09:44:43 --> Security Class Initialized
DEBUG - 2023-04-21 09:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:44:43 --> Input Class Initialized
INFO - 2023-04-21 09:44:43 --> Language Class Initialized
INFO - 2023-04-21 09:44:43 --> Language Class Initialized
INFO - 2023-04-21 09:44:43 --> Config Class Initialized
INFO - 2023-04-21 09:44:43 --> Loader Class Initialized
INFO - 2023-04-21 09:44:43 --> Helper loaded: url_helper
INFO - 2023-04-21 09:44:43 --> Helper loaded: file_helper
INFO - 2023-04-21 09:44:43 --> Helper loaded: form_helper
INFO - 2023-04-21 09:44:43 --> Helper loaded: my_helper
INFO - 2023-04-21 09:44:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:44:43 --> Controller Class Initialized
DEBUG - 2023-04-21 09:44:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:44:44 --> Final output sent to browser
DEBUG - 2023-04-21 09:44:44 --> Total execution time: 1.0992
INFO - 2023-04-21 09:45:02 --> Config Class Initialized
INFO - 2023-04-21 09:45:02 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:45:02 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:45:02 --> Utf8 Class Initialized
INFO - 2023-04-21 09:45:02 --> URI Class Initialized
INFO - 2023-04-21 09:45:02 --> Router Class Initialized
INFO - 2023-04-21 09:45:02 --> Output Class Initialized
INFO - 2023-04-21 09:45:02 --> Security Class Initialized
DEBUG - 2023-04-21 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:45:02 --> Input Class Initialized
INFO - 2023-04-21 09:45:02 --> Language Class Initialized
INFO - 2023-04-21 09:45:02 --> Language Class Initialized
INFO - 2023-04-21 09:45:02 --> Config Class Initialized
INFO - 2023-04-21 09:45:02 --> Loader Class Initialized
INFO - 2023-04-21 09:45:02 --> Helper loaded: url_helper
INFO - 2023-04-21 09:45:02 --> Helper loaded: file_helper
INFO - 2023-04-21 09:45:02 --> Helper loaded: form_helper
INFO - 2023-04-21 09:45:02 --> Helper loaded: my_helper
INFO - 2023-04-21 09:45:02 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:45:02 --> Controller Class Initialized
DEBUG - 2023-04-21 09:45:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:45:03 --> Final output sent to browser
DEBUG - 2023-04-21 09:45:03 --> Total execution time: 1.1030
INFO - 2023-04-21 09:46:10 --> Config Class Initialized
INFO - 2023-04-21 09:46:10 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:46:10 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:46:10 --> Utf8 Class Initialized
INFO - 2023-04-21 09:46:10 --> URI Class Initialized
INFO - 2023-04-21 09:46:10 --> Router Class Initialized
INFO - 2023-04-21 09:46:10 --> Output Class Initialized
INFO - 2023-04-21 09:46:10 --> Security Class Initialized
DEBUG - 2023-04-21 09:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:46:10 --> Input Class Initialized
INFO - 2023-04-21 09:46:10 --> Language Class Initialized
INFO - 2023-04-21 09:46:10 --> Language Class Initialized
INFO - 2023-04-21 09:46:10 --> Config Class Initialized
INFO - 2023-04-21 09:46:10 --> Loader Class Initialized
INFO - 2023-04-21 09:46:10 --> Helper loaded: url_helper
INFO - 2023-04-21 09:46:10 --> Helper loaded: file_helper
INFO - 2023-04-21 09:46:10 --> Helper loaded: form_helper
INFO - 2023-04-21 09:46:10 --> Helper loaded: my_helper
INFO - 2023-04-21 09:46:10 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:46:10 --> Controller Class Initialized
DEBUG - 2023-04-21 09:46:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:46:11 --> Final output sent to browser
DEBUG - 2023-04-21 09:46:11 --> Total execution time: 1.0914
INFO - 2023-04-21 09:46:38 --> Config Class Initialized
INFO - 2023-04-21 09:46:38 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:46:38 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:46:38 --> Utf8 Class Initialized
INFO - 2023-04-21 09:46:38 --> URI Class Initialized
INFO - 2023-04-21 09:46:38 --> Router Class Initialized
INFO - 2023-04-21 09:46:38 --> Output Class Initialized
INFO - 2023-04-21 09:46:38 --> Security Class Initialized
DEBUG - 2023-04-21 09:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:46:38 --> Input Class Initialized
INFO - 2023-04-21 09:46:38 --> Language Class Initialized
INFO - 2023-04-21 09:46:38 --> Language Class Initialized
INFO - 2023-04-21 09:46:38 --> Config Class Initialized
INFO - 2023-04-21 09:46:38 --> Loader Class Initialized
INFO - 2023-04-21 09:46:38 --> Helper loaded: url_helper
INFO - 2023-04-21 09:46:38 --> Helper loaded: file_helper
INFO - 2023-04-21 09:46:38 --> Helper loaded: form_helper
INFO - 2023-04-21 09:46:38 --> Helper loaded: my_helper
INFO - 2023-04-21 09:46:38 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:46:38 --> Controller Class Initialized
DEBUG - 2023-04-21 09:46:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:46:39 --> Final output sent to browser
DEBUG - 2023-04-21 09:46:39 --> Total execution time: 1.1262
INFO - 2023-04-21 09:47:29 --> Config Class Initialized
INFO - 2023-04-21 09:47:29 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:47:29 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:47:29 --> Utf8 Class Initialized
INFO - 2023-04-21 09:47:29 --> URI Class Initialized
INFO - 2023-04-21 09:47:29 --> Router Class Initialized
INFO - 2023-04-21 09:47:29 --> Output Class Initialized
INFO - 2023-04-21 09:47:29 --> Security Class Initialized
DEBUG - 2023-04-21 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:47:29 --> Input Class Initialized
INFO - 2023-04-21 09:47:29 --> Language Class Initialized
INFO - 2023-04-21 09:47:29 --> Language Class Initialized
INFO - 2023-04-21 09:47:29 --> Config Class Initialized
INFO - 2023-04-21 09:47:29 --> Loader Class Initialized
INFO - 2023-04-21 09:47:29 --> Helper loaded: url_helper
INFO - 2023-04-21 09:47:29 --> Helper loaded: file_helper
INFO - 2023-04-21 09:47:29 --> Helper loaded: form_helper
INFO - 2023-04-21 09:47:29 --> Helper loaded: my_helper
INFO - 2023-04-21 09:47:29 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:47:29 --> Controller Class Initialized
DEBUG - 2023-04-21 09:47:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 09:47:30 --> Final output sent to browser
DEBUG - 2023-04-21 09:47:30 --> Total execution time: 1.0932
INFO - 2023-04-21 09:47:36 --> Config Class Initialized
INFO - 2023-04-21 09:47:36 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:47:36 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:47:36 --> Utf8 Class Initialized
INFO - 2023-04-21 09:47:36 --> URI Class Initialized
INFO - 2023-04-21 09:47:36 --> Router Class Initialized
INFO - 2023-04-21 09:47:36 --> Output Class Initialized
INFO - 2023-04-21 09:47:36 --> Security Class Initialized
DEBUG - 2023-04-21 09:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:47:36 --> Input Class Initialized
INFO - 2023-04-21 09:47:36 --> Language Class Initialized
INFO - 2023-04-21 09:47:36 --> Language Class Initialized
INFO - 2023-04-21 09:47:36 --> Config Class Initialized
INFO - 2023-04-21 09:47:36 --> Loader Class Initialized
INFO - 2023-04-21 09:47:36 --> Helper loaded: url_helper
INFO - 2023-04-21 09:47:36 --> Helper loaded: file_helper
INFO - 2023-04-21 09:47:36 --> Helper loaded: form_helper
INFO - 2023-04-21 09:47:36 --> Helper loaded: my_helper
INFO - 2023-04-21 09:47:36 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:47:36 --> Controller Class Initialized
DEBUG - 2023-04-21 09:47:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:47:37 --> Final output sent to browser
DEBUG - 2023-04-21 09:47:37 --> Total execution time: 1.1592
INFO - 2023-04-21 09:47:56 --> Config Class Initialized
INFO - 2023-04-21 09:47:56 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:47:56 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:47:56 --> Utf8 Class Initialized
INFO - 2023-04-21 09:47:56 --> URI Class Initialized
INFO - 2023-04-21 09:47:56 --> Router Class Initialized
INFO - 2023-04-21 09:47:56 --> Output Class Initialized
INFO - 2023-04-21 09:47:56 --> Security Class Initialized
DEBUG - 2023-04-21 09:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:47:56 --> Input Class Initialized
INFO - 2023-04-21 09:47:56 --> Language Class Initialized
INFO - 2023-04-21 09:47:56 --> Language Class Initialized
INFO - 2023-04-21 09:47:56 --> Config Class Initialized
INFO - 2023-04-21 09:47:56 --> Loader Class Initialized
INFO - 2023-04-21 09:47:56 --> Helper loaded: url_helper
INFO - 2023-04-21 09:47:56 --> Helper loaded: file_helper
INFO - 2023-04-21 09:47:56 --> Helper loaded: form_helper
INFO - 2023-04-21 09:47:56 --> Helper loaded: my_helper
INFO - 2023-04-21 09:47:56 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:47:56 --> Controller Class Initialized
DEBUG - 2023-04-21 09:47:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:47:57 --> Final output sent to browser
DEBUG - 2023-04-21 09:47:57 --> Total execution time: 1.1340
INFO - 2023-04-21 09:49:06 --> Config Class Initialized
INFO - 2023-04-21 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:49:06 --> Utf8 Class Initialized
INFO - 2023-04-21 09:49:06 --> URI Class Initialized
INFO - 2023-04-21 09:49:06 --> Router Class Initialized
INFO - 2023-04-21 09:49:06 --> Output Class Initialized
INFO - 2023-04-21 09:49:06 --> Security Class Initialized
DEBUG - 2023-04-21 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:49:06 --> Input Class Initialized
INFO - 2023-04-21 09:49:06 --> Language Class Initialized
INFO - 2023-04-21 09:49:06 --> Language Class Initialized
INFO - 2023-04-21 09:49:06 --> Config Class Initialized
INFO - 2023-04-21 09:49:06 --> Loader Class Initialized
INFO - 2023-04-21 09:49:06 --> Helper loaded: url_helper
INFO - 2023-04-21 09:49:06 --> Helper loaded: file_helper
INFO - 2023-04-21 09:49:06 --> Helper loaded: form_helper
INFO - 2023-04-21 09:49:06 --> Helper loaded: my_helper
INFO - 2023-04-21 09:49:06 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:49:06 --> Controller Class Initialized
DEBUG - 2023-04-21 09:49:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:49:07 --> Final output sent to browser
DEBUG - 2023-04-21 09:49:07 --> Total execution time: 1.1028
INFO - 2023-04-21 09:50:57 --> Config Class Initialized
INFO - 2023-04-21 09:50:57 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:50:57 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:50:57 --> Utf8 Class Initialized
INFO - 2023-04-21 09:50:57 --> URI Class Initialized
INFO - 2023-04-21 09:50:57 --> Router Class Initialized
INFO - 2023-04-21 09:50:57 --> Output Class Initialized
INFO - 2023-04-21 09:50:57 --> Security Class Initialized
DEBUG - 2023-04-21 09:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:50:57 --> Input Class Initialized
INFO - 2023-04-21 09:50:57 --> Language Class Initialized
INFO - 2023-04-21 09:50:57 --> Language Class Initialized
INFO - 2023-04-21 09:50:57 --> Config Class Initialized
INFO - 2023-04-21 09:50:57 --> Loader Class Initialized
INFO - 2023-04-21 09:50:57 --> Helper loaded: url_helper
INFO - 2023-04-21 09:50:57 --> Helper loaded: file_helper
INFO - 2023-04-21 09:50:57 --> Helper loaded: form_helper
INFO - 2023-04-21 09:50:57 --> Helper loaded: my_helper
INFO - 2023-04-21 09:50:57 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:50:57 --> Controller Class Initialized
DEBUG - 2023-04-21 09:50:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:50:58 --> Final output sent to browser
DEBUG - 2023-04-21 09:50:58 --> Total execution time: 1.1438
INFO - 2023-04-21 09:52:35 --> Config Class Initialized
INFO - 2023-04-21 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:52:35 --> Utf8 Class Initialized
INFO - 2023-04-21 09:52:35 --> URI Class Initialized
INFO - 2023-04-21 09:52:35 --> Router Class Initialized
INFO - 2023-04-21 09:52:35 --> Output Class Initialized
INFO - 2023-04-21 09:52:35 --> Security Class Initialized
DEBUG - 2023-04-21 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:52:35 --> Input Class Initialized
INFO - 2023-04-21 09:52:35 --> Language Class Initialized
INFO - 2023-04-21 09:52:35 --> Language Class Initialized
INFO - 2023-04-21 09:52:35 --> Config Class Initialized
INFO - 2023-04-21 09:52:35 --> Loader Class Initialized
INFO - 2023-04-21 09:52:35 --> Helper loaded: url_helper
INFO - 2023-04-21 09:52:35 --> Helper loaded: file_helper
INFO - 2023-04-21 09:52:35 --> Helper loaded: form_helper
INFO - 2023-04-21 09:52:35 --> Helper loaded: my_helper
INFO - 2023-04-21 09:52:35 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:52:35 --> Controller Class Initialized
DEBUG - 2023-04-21 09:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:52:36 --> Final output sent to browser
DEBUG - 2023-04-21 09:52:36 --> Total execution time: 1.1671
INFO - 2023-04-21 09:52:48 --> Config Class Initialized
INFO - 2023-04-21 09:52:48 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:52:48 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:52:48 --> Utf8 Class Initialized
INFO - 2023-04-21 09:52:48 --> URI Class Initialized
INFO - 2023-04-21 09:52:48 --> Router Class Initialized
INFO - 2023-04-21 09:52:48 --> Output Class Initialized
INFO - 2023-04-21 09:52:48 --> Security Class Initialized
DEBUG - 2023-04-21 09:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:52:48 --> Input Class Initialized
INFO - 2023-04-21 09:52:48 --> Language Class Initialized
INFO - 2023-04-21 09:52:48 --> Language Class Initialized
INFO - 2023-04-21 09:52:48 --> Config Class Initialized
INFO - 2023-04-21 09:52:48 --> Loader Class Initialized
INFO - 2023-04-21 09:52:48 --> Helper loaded: url_helper
INFO - 2023-04-21 09:52:48 --> Helper loaded: file_helper
INFO - 2023-04-21 09:52:48 --> Helper loaded: form_helper
INFO - 2023-04-21 09:52:48 --> Helper loaded: my_helper
INFO - 2023-04-21 09:52:48 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:52:48 --> Controller Class Initialized
DEBUG - 2023-04-21 09:52:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:52:49 --> Final output sent to browser
DEBUG - 2023-04-21 09:52:49 --> Total execution time: 1.1082
INFO - 2023-04-21 09:53:04 --> Config Class Initialized
INFO - 2023-04-21 09:53:04 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:53:04 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:53:04 --> Utf8 Class Initialized
INFO - 2023-04-21 09:53:04 --> URI Class Initialized
INFO - 2023-04-21 09:53:04 --> Router Class Initialized
INFO - 2023-04-21 09:53:04 --> Output Class Initialized
INFO - 2023-04-21 09:53:04 --> Security Class Initialized
DEBUG - 2023-04-21 09:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:53:04 --> Input Class Initialized
INFO - 2023-04-21 09:53:04 --> Language Class Initialized
INFO - 2023-04-21 09:53:04 --> Language Class Initialized
INFO - 2023-04-21 09:53:04 --> Config Class Initialized
INFO - 2023-04-21 09:53:04 --> Loader Class Initialized
INFO - 2023-04-21 09:53:04 --> Helper loaded: url_helper
INFO - 2023-04-21 09:53:04 --> Helper loaded: file_helper
INFO - 2023-04-21 09:53:04 --> Helper loaded: form_helper
INFO - 2023-04-21 09:53:04 --> Helper loaded: my_helper
INFO - 2023-04-21 09:53:04 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:53:04 --> Controller Class Initialized
DEBUG - 2023-04-21 09:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-21 09:53:06 --> Final output sent to browser
DEBUG - 2023-04-21 09:53:06 --> Total execution time: 1.0802
INFO - 2023-04-21 09:53:15 --> Config Class Initialized
INFO - 2023-04-21 09:53:15 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:53:15 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:53:15 --> Utf8 Class Initialized
INFO - 2023-04-21 09:53:15 --> URI Class Initialized
INFO - 2023-04-21 09:53:15 --> Router Class Initialized
INFO - 2023-04-21 09:53:15 --> Output Class Initialized
INFO - 2023-04-21 09:53:15 --> Security Class Initialized
DEBUG - 2023-04-21 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:53:15 --> Input Class Initialized
INFO - 2023-04-21 09:53:15 --> Language Class Initialized
INFO - 2023-04-21 09:53:15 --> Language Class Initialized
INFO - 2023-04-21 09:53:15 --> Config Class Initialized
INFO - 2023-04-21 09:53:15 --> Loader Class Initialized
INFO - 2023-04-21 09:53:15 --> Helper loaded: url_helper
INFO - 2023-04-21 09:53:15 --> Helper loaded: file_helper
INFO - 2023-04-21 09:53:15 --> Helper loaded: form_helper
INFO - 2023-04-21 09:53:15 --> Helper loaded: my_helper
INFO - 2023-04-21 09:53:15 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:53:15 --> Controller Class Initialized
DEBUG - 2023-04-21 09:53:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:53:16 --> Final output sent to browser
DEBUG - 2023-04-21 09:53:16 --> Total execution time: 1.0953
INFO - 2023-04-21 09:53:43 --> Config Class Initialized
INFO - 2023-04-21 09:53:43 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:53:43 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:53:43 --> Utf8 Class Initialized
INFO - 2023-04-21 09:53:43 --> URI Class Initialized
INFO - 2023-04-21 09:53:43 --> Router Class Initialized
INFO - 2023-04-21 09:53:43 --> Output Class Initialized
INFO - 2023-04-21 09:53:43 --> Security Class Initialized
DEBUG - 2023-04-21 09:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:53:43 --> Input Class Initialized
INFO - 2023-04-21 09:53:43 --> Language Class Initialized
INFO - 2023-04-21 09:53:43 --> Language Class Initialized
INFO - 2023-04-21 09:53:43 --> Config Class Initialized
INFO - 2023-04-21 09:53:43 --> Loader Class Initialized
INFO - 2023-04-21 09:53:43 --> Helper loaded: url_helper
INFO - 2023-04-21 09:53:43 --> Helper loaded: file_helper
INFO - 2023-04-21 09:53:43 --> Helper loaded: form_helper
INFO - 2023-04-21 09:53:43 --> Helper loaded: my_helper
INFO - 2023-04-21 09:53:43 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:53:43 --> Controller Class Initialized
DEBUG - 2023-04-21 09:53:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:53:44 --> Final output sent to browser
DEBUG - 2023-04-21 09:53:44 --> Total execution time: 1.1173
INFO - 2023-04-21 09:54:24 --> Config Class Initialized
INFO - 2023-04-21 09:54:24 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:54:24 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:54:24 --> Utf8 Class Initialized
INFO - 2023-04-21 09:54:24 --> URI Class Initialized
INFO - 2023-04-21 09:54:24 --> Router Class Initialized
INFO - 2023-04-21 09:54:24 --> Output Class Initialized
INFO - 2023-04-21 09:54:24 --> Security Class Initialized
DEBUG - 2023-04-21 09:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:54:24 --> Input Class Initialized
INFO - 2023-04-21 09:54:24 --> Language Class Initialized
INFO - 2023-04-21 09:54:24 --> Language Class Initialized
INFO - 2023-04-21 09:54:24 --> Config Class Initialized
INFO - 2023-04-21 09:54:24 --> Loader Class Initialized
INFO - 2023-04-21 09:54:24 --> Helper loaded: url_helper
INFO - 2023-04-21 09:54:24 --> Helper loaded: file_helper
INFO - 2023-04-21 09:54:24 --> Helper loaded: form_helper
INFO - 2023-04-21 09:54:24 --> Helper loaded: my_helper
INFO - 2023-04-21 09:54:24 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:54:24 --> Controller Class Initialized
DEBUG - 2023-04-21 09:54:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:54:25 --> Final output sent to browser
DEBUG - 2023-04-21 09:54:25 --> Total execution time: 1.1220
INFO - 2023-04-21 09:54:54 --> Config Class Initialized
INFO - 2023-04-21 09:54:54 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:54:54 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:54:54 --> Utf8 Class Initialized
INFO - 2023-04-21 09:54:54 --> URI Class Initialized
INFO - 2023-04-21 09:54:54 --> Router Class Initialized
INFO - 2023-04-21 09:54:54 --> Output Class Initialized
INFO - 2023-04-21 09:54:54 --> Security Class Initialized
DEBUG - 2023-04-21 09:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:54:54 --> Input Class Initialized
INFO - 2023-04-21 09:54:54 --> Language Class Initialized
INFO - 2023-04-21 09:54:54 --> Language Class Initialized
INFO - 2023-04-21 09:54:54 --> Config Class Initialized
INFO - 2023-04-21 09:54:54 --> Loader Class Initialized
INFO - 2023-04-21 09:54:54 --> Helper loaded: url_helper
INFO - 2023-04-21 09:54:54 --> Helper loaded: file_helper
INFO - 2023-04-21 09:54:54 --> Helper loaded: form_helper
INFO - 2023-04-21 09:54:54 --> Helper loaded: my_helper
INFO - 2023-04-21 09:54:54 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:54:54 --> Controller Class Initialized
DEBUG - 2023-04-21 09:54:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:54:55 --> Final output sent to browser
DEBUG - 2023-04-21 09:54:55 --> Total execution time: 1.0869
INFO - 2023-04-21 09:55:45 --> Config Class Initialized
INFO - 2023-04-21 09:55:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:55:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:55:45 --> Utf8 Class Initialized
INFO - 2023-04-21 09:55:45 --> URI Class Initialized
INFO - 2023-04-21 09:55:45 --> Router Class Initialized
INFO - 2023-04-21 09:55:45 --> Output Class Initialized
INFO - 2023-04-21 09:55:45 --> Security Class Initialized
DEBUG - 2023-04-21 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:55:45 --> Input Class Initialized
INFO - 2023-04-21 09:55:45 --> Language Class Initialized
INFO - 2023-04-21 09:55:45 --> Language Class Initialized
INFO - 2023-04-21 09:55:45 --> Config Class Initialized
INFO - 2023-04-21 09:55:45 --> Loader Class Initialized
INFO - 2023-04-21 09:55:45 --> Helper loaded: url_helper
INFO - 2023-04-21 09:55:45 --> Helper loaded: file_helper
INFO - 2023-04-21 09:55:45 --> Helper loaded: form_helper
INFO - 2023-04-21 09:55:45 --> Helper loaded: my_helper
INFO - 2023-04-21 09:55:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:55:45 --> Controller Class Initialized
DEBUG - 2023-04-21 09:55:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:55:46 --> Final output sent to browser
DEBUG - 2023-04-21 09:55:46 --> Total execution time: 1.1292
INFO - 2023-04-21 09:56:03 --> Config Class Initialized
INFO - 2023-04-21 09:56:03 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:56:03 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:56:03 --> Utf8 Class Initialized
INFO - 2023-04-21 09:56:03 --> URI Class Initialized
INFO - 2023-04-21 09:56:03 --> Router Class Initialized
INFO - 2023-04-21 09:56:03 --> Output Class Initialized
INFO - 2023-04-21 09:56:03 --> Security Class Initialized
DEBUG - 2023-04-21 09:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:56:03 --> Input Class Initialized
INFO - 2023-04-21 09:56:03 --> Language Class Initialized
INFO - 2023-04-21 09:56:03 --> Language Class Initialized
INFO - 2023-04-21 09:56:03 --> Config Class Initialized
INFO - 2023-04-21 09:56:03 --> Loader Class Initialized
INFO - 2023-04-21 09:56:03 --> Helper loaded: url_helper
INFO - 2023-04-21 09:56:03 --> Helper loaded: file_helper
INFO - 2023-04-21 09:56:03 --> Helper loaded: form_helper
INFO - 2023-04-21 09:56:03 --> Helper loaded: my_helper
INFO - 2023-04-21 09:56:03 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:56:03 --> Controller Class Initialized
DEBUG - 2023-04-21 09:56:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:56:04 --> Final output sent to browser
DEBUG - 2023-04-21 09:56:04 --> Total execution time: 1.1103
INFO - 2023-04-21 09:56:37 --> Config Class Initialized
INFO - 2023-04-21 09:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:56:37 --> Utf8 Class Initialized
INFO - 2023-04-21 09:56:37 --> URI Class Initialized
INFO - 2023-04-21 09:56:37 --> Router Class Initialized
INFO - 2023-04-21 09:56:37 --> Output Class Initialized
INFO - 2023-04-21 09:56:37 --> Security Class Initialized
DEBUG - 2023-04-21 09:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:56:37 --> Input Class Initialized
INFO - 2023-04-21 09:56:37 --> Language Class Initialized
INFO - 2023-04-21 09:56:37 --> Language Class Initialized
INFO - 2023-04-21 09:56:37 --> Config Class Initialized
INFO - 2023-04-21 09:56:37 --> Loader Class Initialized
INFO - 2023-04-21 09:56:37 --> Helper loaded: url_helper
INFO - 2023-04-21 09:56:37 --> Helper loaded: file_helper
INFO - 2023-04-21 09:56:37 --> Helper loaded: form_helper
INFO - 2023-04-21 09:56:37 --> Helper loaded: my_helper
INFO - 2023-04-21 09:56:37 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:56:37 --> Controller Class Initialized
DEBUG - 2023-04-21 09:56:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:56:38 --> Final output sent to browser
DEBUG - 2023-04-21 09:56:38 --> Total execution time: 1.0651
INFO - 2023-04-21 09:56:59 --> Config Class Initialized
INFO - 2023-04-21 09:56:59 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:56:59 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:56:59 --> Utf8 Class Initialized
INFO - 2023-04-21 09:56:59 --> URI Class Initialized
INFO - 2023-04-21 09:56:59 --> Router Class Initialized
INFO - 2023-04-21 09:56:59 --> Output Class Initialized
INFO - 2023-04-21 09:56:59 --> Security Class Initialized
DEBUG - 2023-04-21 09:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:56:59 --> Input Class Initialized
INFO - 2023-04-21 09:56:59 --> Language Class Initialized
INFO - 2023-04-21 09:56:59 --> Language Class Initialized
INFO - 2023-04-21 09:56:59 --> Config Class Initialized
INFO - 2023-04-21 09:56:59 --> Loader Class Initialized
INFO - 2023-04-21 09:56:59 --> Helper loaded: url_helper
INFO - 2023-04-21 09:56:59 --> Helper loaded: file_helper
INFO - 2023-04-21 09:56:59 --> Helper loaded: form_helper
INFO - 2023-04-21 09:56:59 --> Helper loaded: my_helper
INFO - 2023-04-21 09:56:59 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:56:59 --> Controller Class Initialized
DEBUG - 2023-04-21 09:56:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:57:00 --> Final output sent to browser
DEBUG - 2023-04-21 09:57:00 --> Total execution time: 1.1035
INFO - 2023-04-21 09:57:08 --> Config Class Initialized
INFO - 2023-04-21 09:57:08 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:57:08 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:57:08 --> Utf8 Class Initialized
INFO - 2023-04-21 09:57:08 --> URI Class Initialized
INFO - 2023-04-21 09:57:08 --> Router Class Initialized
INFO - 2023-04-21 09:57:08 --> Output Class Initialized
INFO - 2023-04-21 09:57:08 --> Security Class Initialized
DEBUG - 2023-04-21 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:57:08 --> Input Class Initialized
INFO - 2023-04-21 09:57:08 --> Language Class Initialized
INFO - 2023-04-21 09:57:08 --> Language Class Initialized
INFO - 2023-04-21 09:57:08 --> Config Class Initialized
INFO - 2023-04-21 09:57:08 --> Loader Class Initialized
INFO - 2023-04-21 09:57:08 --> Helper loaded: url_helper
INFO - 2023-04-21 09:57:08 --> Helper loaded: file_helper
INFO - 2023-04-21 09:57:08 --> Helper loaded: form_helper
INFO - 2023-04-21 09:57:08 --> Helper loaded: my_helper
INFO - 2023-04-21 09:57:08 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:57:08 --> Controller Class Initialized
DEBUG - 2023-04-21 09:57:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:57:09 --> Final output sent to browser
DEBUG - 2023-04-21 09:57:09 --> Total execution time: 1.1030
INFO - 2023-04-21 09:57:30 --> Config Class Initialized
INFO - 2023-04-21 09:57:30 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:57:30 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:57:30 --> Utf8 Class Initialized
INFO - 2023-04-21 09:57:30 --> URI Class Initialized
INFO - 2023-04-21 09:57:30 --> Router Class Initialized
INFO - 2023-04-21 09:57:30 --> Output Class Initialized
INFO - 2023-04-21 09:57:30 --> Security Class Initialized
DEBUG - 2023-04-21 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:57:30 --> Input Class Initialized
INFO - 2023-04-21 09:57:30 --> Language Class Initialized
INFO - 2023-04-21 09:57:30 --> Language Class Initialized
INFO - 2023-04-21 09:57:30 --> Config Class Initialized
INFO - 2023-04-21 09:57:30 --> Loader Class Initialized
INFO - 2023-04-21 09:57:30 --> Helper loaded: url_helper
INFO - 2023-04-21 09:57:30 --> Helper loaded: file_helper
INFO - 2023-04-21 09:57:30 --> Helper loaded: form_helper
INFO - 2023-04-21 09:57:30 --> Helper loaded: my_helper
INFO - 2023-04-21 09:57:30 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:57:30 --> Controller Class Initialized
DEBUG - 2023-04-21 09:57:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:57:31 --> Final output sent to browser
DEBUG - 2023-04-21 09:57:31 --> Total execution time: 1.1297
INFO - 2023-04-21 09:57:51 --> Config Class Initialized
INFO - 2023-04-21 09:57:51 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:57:51 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:57:51 --> Utf8 Class Initialized
INFO - 2023-04-21 09:57:51 --> URI Class Initialized
INFO - 2023-04-21 09:57:51 --> Router Class Initialized
INFO - 2023-04-21 09:57:51 --> Output Class Initialized
INFO - 2023-04-21 09:57:51 --> Security Class Initialized
DEBUG - 2023-04-21 09:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:57:51 --> Input Class Initialized
INFO - 2023-04-21 09:57:51 --> Language Class Initialized
INFO - 2023-04-21 09:57:51 --> Language Class Initialized
INFO - 2023-04-21 09:57:51 --> Config Class Initialized
INFO - 2023-04-21 09:57:51 --> Loader Class Initialized
INFO - 2023-04-21 09:57:51 --> Helper loaded: url_helper
INFO - 2023-04-21 09:57:51 --> Helper loaded: file_helper
INFO - 2023-04-21 09:57:51 --> Helper loaded: form_helper
INFO - 2023-04-21 09:57:51 --> Helper loaded: my_helper
INFO - 2023-04-21 09:57:51 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:57:52 --> Controller Class Initialized
DEBUG - 2023-04-21 09:57:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:57:53 --> Final output sent to browser
DEBUG - 2023-04-21 09:57:53 --> Total execution time: 1.1157
INFO - 2023-04-21 09:58:44 --> Config Class Initialized
INFO - 2023-04-21 09:58:44 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:58:44 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:58:44 --> Utf8 Class Initialized
INFO - 2023-04-21 09:58:44 --> URI Class Initialized
INFO - 2023-04-21 09:58:44 --> Router Class Initialized
INFO - 2023-04-21 09:58:44 --> Output Class Initialized
INFO - 2023-04-21 09:58:44 --> Security Class Initialized
DEBUG - 2023-04-21 09:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:58:44 --> Input Class Initialized
INFO - 2023-04-21 09:58:44 --> Language Class Initialized
INFO - 2023-04-21 09:58:44 --> Language Class Initialized
INFO - 2023-04-21 09:58:44 --> Config Class Initialized
INFO - 2023-04-21 09:58:44 --> Loader Class Initialized
INFO - 2023-04-21 09:58:44 --> Helper loaded: url_helper
INFO - 2023-04-21 09:58:44 --> Helper loaded: file_helper
INFO - 2023-04-21 09:58:44 --> Helper loaded: form_helper
INFO - 2023-04-21 09:58:44 --> Helper loaded: my_helper
INFO - 2023-04-21 09:58:44 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:58:44 --> Controller Class Initialized
DEBUG - 2023-04-21 09:58:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:58:45 --> Final output sent to browser
DEBUG - 2023-04-21 09:58:45 --> Total execution time: 1.1435
INFO - 2023-04-21 09:59:06 --> Config Class Initialized
INFO - 2023-04-21 09:59:06 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:59:06 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:59:06 --> Utf8 Class Initialized
INFO - 2023-04-21 09:59:06 --> URI Class Initialized
INFO - 2023-04-21 09:59:06 --> Router Class Initialized
INFO - 2023-04-21 09:59:06 --> Output Class Initialized
INFO - 2023-04-21 09:59:06 --> Security Class Initialized
DEBUG - 2023-04-21 09:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:59:06 --> Input Class Initialized
INFO - 2023-04-21 09:59:06 --> Language Class Initialized
INFO - 2023-04-21 09:59:06 --> Language Class Initialized
INFO - 2023-04-21 09:59:06 --> Config Class Initialized
INFO - 2023-04-21 09:59:06 --> Loader Class Initialized
INFO - 2023-04-21 09:59:06 --> Helper loaded: url_helper
INFO - 2023-04-21 09:59:06 --> Helper loaded: file_helper
INFO - 2023-04-21 09:59:06 --> Helper loaded: form_helper
INFO - 2023-04-21 09:59:06 --> Helper loaded: my_helper
INFO - 2023-04-21 09:59:06 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:59:06 --> Controller Class Initialized
DEBUG - 2023-04-21 09:59:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:59:07 --> Final output sent to browser
DEBUG - 2023-04-21 09:59:07 --> Total execution time: 1.1269
INFO - 2023-04-21 09:59:24 --> Config Class Initialized
INFO - 2023-04-21 09:59:24 --> Hooks Class Initialized
DEBUG - 2023-04-21 09:59:24 --> UTF-8 Support Enabled
INFO - 2023-04-21 09:59:24 --> Utf8 Class Initialized
INFO - 2023-04-21 09:59:24 --> URI Class Initialized
INFO - 2023-04-21 09:59:24 --> Router Class Initialized
INFO - 2023-04-21 09:59:24 --> Output Class Initialized
INFO - 2023-04-21 09:59:24 --> Security Class Initialized
DEBUG - 2023-04-21 09:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 09:59:24 --> Input Class Initialized
INFO - 2023-04-21 09:59:24 --> Language Class Initialized
INFO - 2023-04-21 09:59:24 --> Language Class Initialized
INFO - 2023-04-21 09:59:24 --> Config Class Initialized
INFO - 2023-04-21 09:59:24 --> Loader Class Initialized
INFO - 2023-04-21 09:59:24 --> Helper loaded: url_helper
INFO - 2023-04-21 09:59:24 --> Helper loaded: file_helper
INFO - 2023-04-21 09:59:24 --> Helper loaded: form_helper
INFO - 2023-04-21 09:59:24 --> Helper loaded: my_helper
INFO - 2023-04-21 09:59:24 --> Database Driver Class Initialized
DEBUG - 2023-04-21 09:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 09:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 09:59:24 --> Controller Class Initialized
DEBUG - 2023-04-21 09:59:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 09:59:26 --> Final output sent to browser
DEBUG - 2023-04-21 09:59:26 --> Total execution time: 1.1270
INFO - 2023-04-21 10:00:02 --> Config Class Initialized
INFO - 2023-04-21 10:00:02 --> Hooks Class Initialized
DEBUG - 2023-04-21 10:00:02 --> UTF-8 Support Enabled
INFO - 2023-04-21 10:00:02 --> Utf8 Class Initialized
INFO - 2023-04-21 10:00:02 --> URI Class Initialized
INFO - 2023-04-21 10:00:02 --> Router Class Initialized
INFO - 2023-04-21 10:00:02 --> Output Class Initialized
INFO - 2023-04-21 10:00:02 --> Security Class Initialized
DEBUG - 2023-04-21 10:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 10:00:02 --> Input Class Initialized
INFO - 2023-04-21 10:00:02 --> Language Class Initialized
INFO - 2023-04-21 10:00:02 --> Language Class Initialized
INFO - 2023-04-21 10:00:02 --> Config Class Initialized
INFO - 2023-04-21 10:00:02 --> Loader Class Initialized
INFO - 2023-04-21 10:00:02 --> Helper loaded: url_helper
INFO - 2023-04-21 10:00:02 --> Helper loaded: file_helper
INFO - 2023-04-21 10:00:02 --> Helper loaded: form_helper
INFO - 2023-04-21 10:00:02 --> Helper loaded: my_helper
INFO - 2023-04-21 10:00:02 --> Database Driver Class Initialized
DEBUG - 2023-04-21 10:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 10:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 10:00:02 --> Controller Class Initialized
DEBUG - 2023-04-21 10:00:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 10:00:03 --> Final output sent to browser
DEBUG - 2023-04-21 10:00:03 --> Total execution time: 1.1234
INFO - 2023-04-21 10:00:16 --> Config Class Initialized
INFO - 2023-04-21 10:00:16 --> Hooks Class Initialized
DEBUG - 2023-04-21 10:00:16 --> UTF-8 Support Enabled
INFO - 2023-04-21 10:00:16 --> Utf8 Class Initialized
INFO - 2023-04-21 10:00:16 --> URI Class Initialized
INFO - 2023-04-21 10:00:16 --> Router Class Initialized
INFO - 2023-04-21 10:00:16 --> Output Class Initialized
INFO - 2023-04-21 10:00:16 --> Security Class Initialized
DEBUG - 2023-04-21 10:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 10:00:16 --> Input Class Initialized
INFO - 2023-04-21 10:00:16 --> Language Class Initialized
INFO - 2023-04-21 10:00:16 --> Language Class Initialized
INFO - 2023-04-21 10:00:16 --> Config Class Initialized
INFO - 2023-04-21 10:00:16 --> Loader Class Initialized
INFO - 2023-04-21 10:00:16 --> Helper loaded: url_helper
INFO - 2023-04-21 10:00:16 --> Helper loaded: file_helper
INFO - 2023-04-21 10:00:16 --> Helper loaded: form_helper
INFO - 2023-04-21 10:00:16 --> Helper loaded: my_helper
INFO - 2023-04-21 10:00:16 --> Database Driver Class Initialized
DEBUG - 2023-04-21 10:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 10:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 10:00:16 --> Controller Class Initialized
DEBUG - 2023-04-21 10:00:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 10:00:18 --> Final output sent to browser
DEBUG - 2023-04-21 10:00:18 --> Total execution time: 1.1063
INFO - 2023-04-21 10:00:45 --> Config Class Initialized
INFO - 2023-04-21 10:00:45 --> Hooks Class Initialized
DEBUG - 2023-04-21 10:00:45 --> UTF-8 Support Enabled
INFO - 2023-04-21 10:00:45 --> Utf8 Class Initialized
INFO - 2023-04-21 10:00:45 --> URI Class Initialized
INFO - 2023-04-21 10:00:45 --> Router Class Initialized
INFO - 2023-04-21 10:00:45 --> Output Class Initialized
INFO - 2023-04-21 10:00:45 --> Security Class Initialized
DEBUG - 2023-04-21 10:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 10:00:45 --> Input Class Initialized
INFO - 2023-04-21 10:00:45 --> Language Class Initialized
INFO - 2023-04-21 10:00:45 --> Language Class Initialized
INFO - 2023-04-21 10:00:45 --> Config Class Initialized
INFO - 2023-04-21 10:00:45 --> Loader Class Initialized
INFO - 2023-04-21 10:00:45 --> Helper loaded: url_helper
INFO - 2023-04-21 10:00:45 --> Helper loaded: file_helper
INFO - 2023-04-21 10:00:45 --> Helper loaded: form_helper
INFO - 2023-04-21 10:00:45 --> Helper loaded: my_helper
INFO - 2023-04-21 10:00:45 --> Database Driver Class Initialized
DEBUG - 2023-04-21 10:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 10:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 10:00:45 --> Controller Class Initialized
DEBUG - 2023-04-21 10:00:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 10:00:46 --> Final output sent to browser
DEBUG - 2023-04-21 10:00:46 --> Total execution time: 1.1475
INFO - 2023-04-21 10:01:08 --> Config Class Initialized
INFO - 2023-04-21 10:01:08 --> Hooks Class Initialized
DEBUG - 2023-04-21 10:01:08 --> UTF-8 Support Enabled
INFO - 2023-04-21 10:01:08 --> Utf8 Class Initialized
INFO - 2023-04-21 10:01:08 --> URI Class Initialized
INFO - 2023-04-21 10:01:08 --> Router Class Initialized
INFO - 2023-04-21 10:01:08 --> Output Class Initialized
INFO - 2023-04-21 10:01:08 --> Security Class Initialized
DEBUG - 2023-04-21 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 10:01:08 --> Input Class Initialized
INFO - 2023-04-21 10:01:08 --> Language Class Initialized
INFO - 2023-04-21 10:01:08 --> Language Class Initialized
INFO - 2023-04-21 10:01:08 --> Config Class Initialized
INFO - 2023-04-21 10:01:08 --> Loader Class Initialized
INFO - 2023-04-21 10:01:08 --> Helper loaded: url_helper
INFO - 2023-04-21 10:01:08 --> Helper loaded: file_helper
INFO - 2023-04-21 10:01:08 --> Helper loaded: form_helper
INFO - 2023-04-21 10:01:08 --> Helper loaded: my_helper
INFO - 2023-04-21 10:01:08 --> Database Driver Class Initialized
DEBUG - 2023-04-21 10:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 10:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 10:01:08 --> Controller Class Initialized
DEBUG - 2023-04-21 10:01:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-21 10:01:10 --> Total execution time: 1.0828
INFO - 2023-04-21 10:01:27 --> Config Class Initialized
INFO - 2023-04-21 10:01:27 --> Hooks Class Initialized
DEBUG - 2023-04-21 10:01:27 --> UTF-8 Support Enabled
INFO - 2023-04-21 10:01:27 --> Utf8 Class Initialized
INFO - 2023-04-21 10:01:27 --> URI Class Initialized
INFO - 2023-04-21 10:01:27 --> Router Class Initialized
INFO - 2023-04-21 10:01:27 --> Output Class Initialized
INFO - 2023-04-21 10:01:27 --> Security Class Initialized
DEBUG - 2023-04-21 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-21 10:01:27 --> Input Class Initialized
INFO - 2023-04-21 10:01:27 --> Language Class Initialized
INFO - 2023-04-21 10:01:27 --> Language Class Initialized
INFO - 2023-04-21 10:01:27 --> Config Class Initialized
INFO - 2023-04-21 10:01:27 --> Loader Class Initialized
INFO - 2023-04-21 10:01:27 --> Helper loaded: url_helper
INFO - 2023-04-21 10:01:27 --> Helper loaded: file_helper
INFO - 2023-04-21 10:01:27 --> Helper loaded: form_helper
INFO - 2023-04-21 10:01:27 --> Helper loaded: my_helper
INFO - 2023-04-21 10:01:27 --> Database Driver Class Initialized
DEBUG - 2023-04-21 10:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-21 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-21 10:01:28 --> Controller Class Initialized
DEBUG - 2023-04-21 10:01:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-21 10:01:29 --> Final output sent to browser
DEBUG - 2023-04-21 10:01:29 --> Total execution time: 1.1096
