<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-12 10:57:02 --> Config Class Initialized
INFO - 2023-09-12 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:02 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:02 --> URI Class Initialized
INFO - 2023-09-12 10:57:03 --> Router Class Initialized
INFO - 2023-09-12 10:57:03 --> Output Class Initialized
INFO - 2023-09-12 10:57:03 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:03 --> Input Class Initialized
INFO - 2023-09-12 10:57:03 --> Language Class Initialized
INFO - 2023-09-12 10:57:03 --> Language Class Initialized
INFO - 2023-09-12 10:57:03 --> Config Class Initialized
INFO - 2023-09-12 10:57:03 --> Loader Class Initialized
INFO - 2023-09-12 10:57:03 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:03 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:03 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:03 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:03 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:03 --> Controller Class Initialized
DEBUG - 2023-09-12 10:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-12 10:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 10:57:03 --> Final output sent to browser
DEBUG - 2023-09-12 10:57:03 --> Total execution time: 0.1298
INFO - 2023-09-12 10:57:06 --> Config Class Initialized
INFO - 2023-09-12 10:57:06 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:06 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:06 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:06 --> URI Class Initialized
INFO - 2023-09-12 10:57:06 --> Router Class Initialized
INFO - 2023-09-12 10:57:06 --> Output Class Initialized
INFO - 2023-09-12 10:57:06 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:06 --> Input Class Initialized
INFO - 2023-09-12 10:57:06 --> Language Class Initialized
INFO - 2023-09-12 10:57:06 --> Language Class Initialized
INFO - 2023-09-12 10:57:06 --> Config Class Initialized
INFO - 2023-09-12 10:57:06 --> Loader Class Initialized
INFO - 2023-09-12 10:57:06 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:06 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:06 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:06 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:06 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:06 --> Controller Class Initialized
INFO - 2023-09-12 10:57:06 --> Helper loaded: cookie_helper
INFO - 2023-09-12 10:57:06 --> Final output sent to browser
DEBUG - 2023-09-12 10:57:06 --> Total execution time: 0.0433
INFO - 2023-09-12 10:57:06 --> Config Class Initialized
INFO - 2023-09-12 10:57:06 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:06 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:06 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:06 --> URI Class Initialized
INFO - 2023-09-12 10:57:06 --> Router Class Initialized
INFO - 2023-09-12 10:57:06 --> Output Class Initialized
INFO - 2023-09-12 10:57:06 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:06 --> Input Class Initialized
INFO - 2023-09-12 10:57:06 --> Language Class Initialized
INFO - 2023-09-12 10:57:06 --> Language Class Initialized
INFO - 2023-09-12 10:57:06 --> Config Class Initialized
INFO - 2023-09-12 10:57:06 --> Loader Class Initialized
INFO - 2023-09-12 10:57:06 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:06 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:06 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:06 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:06 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:06 --> Controller Class Initialized
DEBUG - 2023-09-12 10:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-12 10:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 10:57:06 --> Final output sent to browser
DEBUG - 2023-09-12 10:57:06 --> Total execution time: 0.0801
INFO - 2023-09-12 10:57:19 --> Config Class Initialized
INFO - 2023-09-12 10:57:19 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:19 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:19 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:19 --> URI Class Initialized
INFO - 2023-09-12 10:57:19 --> Router Class Initialized
INFO - 2023-09-12 10:57:19 --> Output Class Initialized
INFO - 2023-09-12 10:57:19 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:19 --> Input Class Initialized
INFO - 2023-09-12 10:57:19 --> Language Class Initialized
INFO - 2023-09-12 10:57:19 --> Language Class Initialized
INFO - 2023-09-12 10:57:19 --> Config Class Initialized
INFO - 2023-09-12 10:57:19 --> Loader Class Initialized
INFO - 2023-09-12 10:57:19 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:19 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:19 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:20 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:20 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:20 --> Controller Class Initialized
DEBUG - 2023-09-12 10:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-12 10:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 10:57:20 --> Final output sent to browser
DEBUG - 2023-09-12 10:57:20 --> Total execution time: 0.0772
INFO - 2023-09-12 10:57:20 --> Config Class Initialized
INFO - 2023-09-12 10:57:20 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:20 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:20 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:20 --> URI Class Initialized
INFO - 2023-09-12 10:57:20 --> Router Class Initialized
INFO - 2023-09-12 10:57:20 --> Output Class Initialized
INFO - 2023-09-12 10:57:20 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:20 --> Input Class Initialized
INFO - 2023-09-12 10:57:20 --> Language Class Initialized
ERROR - 2023-09-12 10:57:20 --> 404 Page Not Found: /index
INFO - 2023-09-12 10:57:20 --> Config Class Initialized
INFO - 2023-09-12 10:57:20 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:20 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:20 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:20 --> URI Class Initialized
INFO - 2023-09-12 10:57:20 --> Router Class Initialized
INFO - 2023-09-12 10:57:20 --> Output Class Initialized
INFO - 2023-09-12 10:57:20 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:20 --> Input Class Initialized
INFO - 2023-09-12 10:57:20 --> Language Class Initialized
INFO - 2023-09-12 10:57:20 --> Language Class Initialized
INFO - 2023-09-12 10:57:20 --> Config Class Initialized
INFO - 2023-09-12 10:57:20 --> Loader Class Initialized
INFO - 2023-09-12 10:57:20 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:20 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:20 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:20 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:20 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:20 --> Controller Class Initialized
INFO - 2023-09-12 10:57:36 --> Config Class Initialized
INFO - 2023-09-12 10:57:36 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:36 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:36 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:36 --> URI Class Initialized
INFO - 2023-09-12 10:57:36 --> Router Class Initialized
INFO - 2023-09-12 10:57:36 --> Output Class Initialized
INFO - 2023-09-12 10:57:36 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:36 --> Input Class Initialized
INFO - 2023-09-12 10:57:36 --> Language Class Initialized
INFO - 2023-09-12 10:57:36 --> Language Class Initialized
INFO - 2023-09-12 10:57:36 --> Config Class Initialized
INFO - 2023-09-12 10:57:36 --> Loader Class Initialized
INFO - 2023-09-12 10:57:36 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:36 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:36 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:36 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:36 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:36 --> Controller Class Initialized
INFO - 2023-09-12 10:57:36 --> Final output sent to browser
DEBUG - 2023-09-12 10:57:36 --> Total execution time: 0.0308
INFO - 2023-09-12 10:57:56 --> Config Class Initialized
INFO - 2023-09-12 10:57:56 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:56 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:56 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:56 --> URI Class Initialized
INFO - 2023-09-12 10:57:56 --> Router Class Initialized
INFO - 2023-09-12 10:57:56 --> Output Class Initialized
INFO - 2023-09-12 10:57:56 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:56 --> Input Class Initialized
INFO - 2023-09-12 10:57:56 --> Language Class Initialized
INFO - 2023-09-12 10:57:56 --> Language Class Initialized
INFO - 2023-09-12 10:57:56 --> Config Class Initialized
INFO - 2023-09-12 10:57:56 --> Loader Class Initialized
INFO - 2023-09-12 10:57:56 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:56 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:56 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:56 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:56 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:56 --> Controller Class Initialized
INFO - 2023-09-12 10:57:56 --> Final output sent to browser
DEBUG - 2023-09-12 10:57:56 --> Total execution time: 0.0357
INFO - 2023-09-12 10:57:56 --> Config Class Initialized
INFO - 2023-09-12 10:57:56 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:56 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:56 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:56 --> URI Class Initialized
INFO - 2023-09-12 10:57:56 --> Router Class Initialized
INFO - 2023-09-12 10:57:56 --> Output Class Initialized
INFO - 2023-09-12 10:57:56 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:56 --> Input Class Initialized
INFO - 2023-09-12 10:57:56 --> Language Class Initialized
ERROR - 2023-09-12 10:57:56 --> 404 Page Not Found: /index
INFO - 2023-09-12 10:57:56 --> Config Class Initialized
INFO - 2023-09-12 10:57:56 --> Hooks Class Initialized
DEBUG - 2023-09-12 10:57:56 --> UTF-8 Support Enabled
INFO - 2023-09-12 10:57:56 --> Utf8 Class Initialized
INFO - 2023-09-12 10:57:56 --> URI Class Initialized
INFO - 2023-09-12 10:57:56 --> Router Class Initialized
INFO - 2023-09-12 10:57:56 --> Output Class Initialized
INFO - 2023-09-12 10:57:56 --> Security Class Initialized
DEBUG - 2023-09-12 10:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 10:57:56 --> Input Class Initialized
INFO - 2023-09-12 10:57:56 --> Language Class Initialized
INFO - 2023-09-12 10:57:56 --> Language Class Initialized
INFO - 2023-09-12 10:57:56 --> Config Class Initialized
INFO - 2023-09-12 10:57:56 --> Loader Class Initialized
INFO - 2023-09-12 10:57:56 --> Helper loaded: url_helper
INFO - 2023-09-12 10:57:56 --> Helper loaded: file_helper
INFO - 2023-09-12 10:57:56 --> Helper loaded: form_helper
INFO - 2023-09-12 10:57:56 --> Helper loaded: my_helper
INFO - 2023-09-12 10:57:56 --> Database Driver Class Initialized
INFO - 2023-09-12 10:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 10:57:56 --> Controller Class Initialized
INFO - 2023-09-12 11:25:46 --> Config Class Initialized
INFO - 2023-09-12 11:25:46 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:25:46 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:25:46 --> Utf8 Class Initialized
INFO - 2023-09-12 11:25:46 --> URI Class Initialized
INFO - 2023-09-12 11:25:46 --> Router Class Initialized
INFO - 2023-09-12 11:25:46 --> Output Class Initialized
INFO - 2023-09-12 11:25:46 --> Security Class Initialized
DEBUG - 2023-09-12 11:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:25:46 --> Input Class Initialized
INFO - 2023-09-12 11:25:46 --> Language Class Initialized
INFO - 2023-09-12 11:25:46 --> Language Class Initialized
INFO - 2023-09-12 11:25:46 --> Config Class Initialized
INFO - 2023-09-12 11:25:46 --> Loader Class Initialized
INFO - 2023-09-12 11:25:46 --> Helper loaded: url_helper
INFO - 2023-09-12 11:25:46 --> Helper loaded: file_helper
INFO - 2023-09-12 11:25:46 --> Helper loaded: form_helper
INFO - 2023-09-12 11:25:46 --> Helper loaded: my_helper
INFO - 2023-09-12 11:25:46 --> Database Driver Class Initialized
INFO - 2023-09-12 11:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:25:46 --> Controller Class Initialized
DEBUG - 2023-09-12 11:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-12 11:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:25:46 --> Final output sent to browser
DEBUG - 2023-09-12 11:25:46 --> Total execution time: 0.0516
INFO - 2023-09-12 11:26:23 --> Config Class Initialized
INFO - 2023-09-12 11:26:23 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:26:23 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:26:23 --> Utf8 Class Initialized
INFO - 2023-09-12 11:26:23 --> URI Class Initialized
INFO - 2023-09-12 11:26:23 --> Router Class Initialized
INFO - 2023-09-12 11:26:23 --> Output Class Initialized
INFO - 2023-09-12 11:26:23 --> Security Class Initialized
DEBUG - 2023-09-12 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:26:23 --> Input Class Initialized
INFO - 2023-09-12 11:26:23 --> Language Class Initialized
INFO - 2023-09-12 11:26:23 --> Language Class Initialized
INFO - 2023-09-12 11:26:23 --> Config Class Initialized
INFO - 2023-09-12 11:26:23 --> Loader Class Initialized
INFO - 2023-09-12 11:26:23 --> Helper loaded: url_helper
INFO - 2023-09-12 11:26:23 --> Helper loaded: file_helper
INFO - 2023-09-12 11:26:23 --> Helper loaded: form_helper
INFO - 2023-09-12 11:26:23 --> Helper loaded: my_helper
INFO - 2023-09-12 11:26:23 --> Database Driver Class Initialized
INFO - 2023-09-12 11:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:26:23 --> Controller Class Initialized
DEBUG - 2023-09-12 11:26:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-12 11:26:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:26:23 --> Final output sent to browser
DEBUG - 2023-09-12 11:26:23 --> Total execution time: 0.0712
INFO - 2023-09-12 11:27:09 --> Config Class Initialized
INFO - 2023-09-12 11:27:09 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:09 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:09 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:09 --> URI Class Initialized
INFO - 2023-09-12 11:27:09 --> Router Class Initialized
INFO - 2023-09-12 11:27:09 --> Output Class Initialized
INFO - 2023-09-12 11:27:09 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:09 --> Input Class Initialized
INFO - 2023-09-12 11:27:09 --> Language Class Initialized
INFO - 2023-09-12 11:27:09 --> Language Class Initialized
INFO - 2023-09-12 11:27:09 --> Config Class Initialized
INFO - 2023-09-12 11:27:09 --> Loader Class Initialized
INFO - 2023-09-12 11:27:09 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:09 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:09 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:09 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:09 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:09 --> Controller Class Initialized
DEBUG - 2023-09-12 11:27:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-12 11:27:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:27:09 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:09 --> Total execution time: 0.0329
INFO - 2023-09-12 11:27:28 --> Config Class Initialized
INFO - 2023-09-12 11:27:28 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:28 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:28 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:28 --> URI Class Initialized
INFO - 2023-09-12 11:27:28 --> Router Class Initialized
INFO - 2023-09-12 11:27:28 --> Output Class Initialized
INFO - 2023-09-12 11:27:28 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:28 --> Input Class Initialized
INFO - 2023-09-12 11:27:28 --> Language Class Initialized
INFO - 2023-09-12 11:27:28 --> Language Class Initialized
INFO - 2023-09-12 11:27:28 --> Config Class Initialized
INFO - 2023-09-12 11:27:28 --> Loader Class Initialized
INFO - 2023-09-12 11:27:28 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:28 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:28 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:28 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:28 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:28 --> Controller Class Initialized
INFO - 2023-09-12 11:27:28 --> Helper loaded: cookie_helper
INFO - 2023-09-12 11:27:28 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:28 --> Total execution time: 0.0427
INFO - 2023-09-12 11:27:29 --> Config Class Initialized
INFO - 2023-09-12 11:27:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:29 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:29 --> URI Class Initialized
INFO - 2023-09-12 11:27:29 --> Router Class Initialized
INFO - 2023-09-12 11:27:29 --> Output Class Initialized
INFO - 2023-09-12 11:27:29 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:29 --> Input Class Initialized
INFO - 2023-09-12 11:27:29 --> Language Class Initialized
INFO - 2023-09-12 11:27:29 --> Language Class Initialized
INFO - 2023-09-12 11:27:29 --> Config Class Initialized
INFO - 2023-09-12 11:27:29 --> Loader Class Initialized
INFO - 2023-09-12 11:27:29 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:29 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:29 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:29 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:29 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:29 --> Controller Class Initialized
DEBUG - 2023-09-12 11:27:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-12 11:27:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:27:29 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:29 --> Total execution time: 0.2548
INFO - 2023-09-12 11:27:41 --> Config Class Initialized
INFO - 2023-09-12 11:27:41 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:41 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:41 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:41 --> URI Class Initialized
INFO - 2023-09-12 11:27:41 --> Router Class Initialized
INFO - 2023-09-12 11:27:41 --> Output Class Initialized
INFO - 2023-09-12 11:27:41 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:41 --> Input Class Initialized
INFO - 2023-09-12 11:27:41 --> Language Class Initialized
INFO - 2023-09-12 11:27:41 --> Language Class Initialized
INFO - 2023-09-12 11:27:41 --> Config Class Initialized
INFO - 2023-09-12 11:27:41 --> Loader Class Initialized
INFO - 2023-09-12 11:27:41 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:41 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:41 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:41 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:41 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:41 --> Controller Class Initialized
DEBUG - 2023-09-12 11:27:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:27:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:27:41 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:41 --> Total execution time: 0.0351
INFO - 2023-09-12 11:27:44 --> Config Class Initialized
INFO - 2023-09-12 11:27:44 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:44 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:44 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:44 --> URI Class Initialized
INFO - 2023-09-12 11:27:44 --> Router Class Initialized
INFO - 2023-09-12 11:27:44 --> Output Class Initialized
INFO - 2023-09-12 11:27:44 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:44 --> Input Class Initialized
INFO - 2023-09-12 11:27:44 --> Language Class Initialized
INFO - 2023-09-12 11:27:44 --> Language Class Initialized
INFO - 2023-09-12 11:27:44 --> Config Class Initialized
INFO - 2023-09-12 11:27:44 --> Loader Class Initialized
INFO - 2023-09-12 11:27:44 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:44 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:44 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:44 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:44 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:44 --> Controller Class Initialized
DEBUG - 2023-09-12 11:27:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-12 11:27:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:27:44 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:44 --> Total execution time: 0.0300
INFO - 2023-09-12 11:27:52 --> Config Class Initialized
INFO - 2023-09-12 11:27:52 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:52 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:52 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:52 --> URI Class Initialized
INFO - 2023-09-12 11:27:52 --> Router Class Initialized
INFO - 2023-09-12 11:27:52 --> Output Class Initialized
INFO - 2023-09-12 11:27:52 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:52 --> Input Class Initialized
INFO - 2023-09-12 11:27:52 --> Language Class Initialized
INFO - 2023-09-12 11:27:52 --> Language Class Initialized
INFO - 2023-09-12 11:27:52 --> Config Class Initialized
INFO - 2023-09-12 11:27:52 --> Loader Class Initialized
INFO - 2023-09-12 11:27:52 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:52 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:52 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:52 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:52 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:52 --> Controller Class Initialized
DEBUG - 2023-09-12 11:27:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_ubah_password.php
DEBUG - 2023-09-12 11:27:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:27:52 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:52 --> Total execution time: 0.0318
INFO - 2023-09-12 11:27:53 --> Config Class Initialized
INFO - 2023-09-12 11:27:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:27:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:27:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:27:53 --> URI Class Initialized
DEBUG - 2023-09-12 11:27:53 --> No URI present. Default controller set.
INFO - 2023-09-12 11:27:53 --> Router Class Initialized
INFO - 2023-09-12 11:27:53 --> Output Class Initialized
INFO - 2023-09-12 11:27:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:27:53 --> Input Class Initialized
INFO - 2023-09-12 11:27:53 --> Language Class Initialized
INFO - 2023-09-12 11:27:53 --> Language Class Initialized
INFO - 2023-09-12 11:27:53 --> Config Class Initialized
INFO - 2023-09-12 11:27:53 --> Loader Class Initialized
INFO - 2023-09-12 11:27:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:27:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:27:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:27:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:27:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:27:53 --> Controller Class Initialized
DEBUG - 2023-09-12 11:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-12 11:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:27:53 --> Final output sent to browser
DEBUG - 2023-09-12 11:27:53 --> Total execution time: 0.0310
INFO - 2023-09-12 11:28:29 --> Config Class Initialized
INFO - 2023-09-12 11:28:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:29 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:29 --> URI Class Initialized
DEBUG - 2023-09-12 11:28:29 --> No URI present. Default controller set.
INFO - 2023-09-12 11:28:29 --> Router Class Initialized
INFO - 2023-09-12 11:28:29 --> Output Class Initialized
INFO - 2023-09-12 11:28:29 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:29 --> Input Class Initialized
INFO - 2023-09-12 11:28:29 --> Language Class Initialized
INFO - 2023-09-12 11:28:29 --> Language Class Initialized
INFO - 2023-09-12 11:28:29 --> Config Class Initialized
INFO - 2023-09-12 11:28:29 --> Loader Class Initialized
INFO - 2023-09-12 11:28:29 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:29 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:29 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:29 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:29 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:29 --> Controller Class Initialized
DEBUG - 2023-09-12 11:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-12 11:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:28:29 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:29 --> Total execution time: 0.0313
INFO - 2023-09-12 11:28:32 --> Config Class Initialized
INFO - 2023-09-12 11:28:32 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:32 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:32 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:32 --> URI Class Initialized
INFO - 2023-09-12 11:28:32 --> Router Class Initialized
INFO - 2023-09-12 11:28:32 --> Output Class Initialized
INFO - 2023-09-12 11:28:32 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:32 --> Input Class Initialized
INFO - 2023-09-12 11:28:32 --> Language Class Initialized
INFO - 2023-09-12 11:28:32 --> Language Class Initialized
INFO - 2023-09-12 11:28:32 --> Config Class Initialized
INFO - 2023-09-12 11:28:32 --> Loader Class Initialized
INFO - 2023-09-12 11:28:32 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:32 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:32 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:32 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:32 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:32 --> Controller Class Initialized
DEBUG - 2023-09-12 11:28:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:28:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:28:32 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:32 --> Total execution time: 0.0845
INFO - 2023-09-12 11:28:37 --> Config Class Initialized
INFO - 2023-09-12 11:28:37 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:37 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:37 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:37 --> URI Class Initialized
INFO - 2023-09-12 11:28:37 --> Router Class Initialized
INFO - 2023-09-12 11:28:37 --> Output Class Initialized
INFO - 2023-09-12 11:28:37 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:37 --> Input Class Initialized
INFO - 2023-09-12 11:28:37 --> Language Class Initialized
INFO - 2023-09-12 11:28:37 --> Language Class Initialized
INFO - 2023-09-12 11:28:37 --> Config Class Initialized
INFO - 2023-09-12 11:28:37 --> Loader Class Initialized
INFO - 2023-09-12 11:28:37 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:37 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:37 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:37 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:37 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:37 --> Controller Class Initialized
DEBUG - 2023-09-12 11:28:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-12 11:28:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:28:37 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:37 --> Total execution time: 0.0378
INFO - 2023-09-12 11:28:37 --> Config Class Initialized
INFO - 2023-09-12 11:28:37 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:37 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:37 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:37 --> URI Class Initialized
INFO - 2023-09-12 11:28:37 --> Router Class Initialized
INFO - 2023-09-12 11:28:37 --> Output Class Initialized
INFO - 2023-09-12 11:28:37 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:37 --> Input Class Initialized
INFO - 2023-09-12 11:28:37 --> Language Class Initialized
INFO - 2023-09-12 11:28:37 --> Language Class Initialized
INFO - 2023-09-12 11:28:37 --> Config Class Initialized
INFO - 2023-09-12 11:28:37 --> Loader Class Initialized
INFO - 2023-09-12 11:28:37 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:37 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:37 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:37 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:37 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:37 --> Controller Class Initialized
INFO - 2023-09-12 11:28:51 --> Config Class Initialized
INFO - 2023-09-12 11:28:51 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:51 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:51 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:51 --> URI Class Initialized
INFO - 2023-09-12 11:28:51 --> Router Class Initialized
INFO - 2023-09-12 11:28:51 --> Output Class Initialized
INFO - 2023-09-12 11:28:51 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:51 --> Input Class Initialized
INFO - 2023-09-12 11:28:51 --> Language Class Initialized
INFO - 2023-09-12 11:28:51 --> Language Class Initialized
INFO - 2023-09-12 11:28:51 --> Config Class Initialized
INFO - 2023-09-12 11:28:51 --> Loader Class Initialized
INFO - 2023-09-12 11:28:51 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:51 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:51 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:51 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:51 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:51 --> Controller Class Initialized
INFO - 2023-09-12 11:28:51 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:51 --> Total execution time: 0.0407
INFO - 2023-09-12 11:28:53 --> Config Class Initialized
INFO - 2023-09-12 11:28:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:53 --> URI Class Initialized
INFO - 2023-09-12 11:28:53 --> Router Class Initialized
INFO - 2023-09-12 11:28:53 --> Output Class Initialized
INFO - 2023-09-12 11:28:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:53 --> Input Class Initialized
INFO - 2023-09-12 11:28:53 --> Language Class Initialized
INFO - 2023-09-12 11:28:53 --> Language Class Initialized
INFO - 2023-09-12 11:28:53 --> Config Class Initialized
INFO - 2023-09-12 11:28:53 --> Loader Class Initialized
INFO - 2023-09-12 11:28:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:53 --> Controller Class Initialized
INFO - 2023-09-12 11:28:53 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:53 --> Total execution time: 0.0345
INFO - 2023-09-12 11:28:53 --> Config Class Initialized
INFO - 2023-09-12 11:28:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:53 --> URI Class Initialized
INFO - 2023-09-12 11:28:53 --> Router Class Initialized
INFO - 2023-09-12 11:28:53 --> Output Class Initialized
INFO - 2023-09-12 11:28:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:53 --> Input Class Initialized
INFO - 2023-09-12 11:28:53 --> Language Class Initialized
INFO - 2023-09-12 11:28:53 --> Language Class Initialized
INFO - 2023-09-12 11:28:53 --> Config Class Initialized
INFO - 2023-09-12 11:28:53 --> Loader Class Initialized
INFO - 2023-09-12 11:28:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:53 --> Controller Class Initialized
INFO - 2023-09-12 11:28:53 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:53 --> Total execution time: 0.0325
INFO - 2023-09-12 11:28:54 --> Config Class Initialized
INFO - 2023-09-12 11:28:54 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:54 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:54 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:54 --> URI Class Initialized
INFO - 2023-09-12 11:28:54 --> Router Class Initialized
INFO - 2023-09-12 11:28:54 --> Output Class Initialized
INFO - 2023-09-12 11:28:54 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:54 --> Input Class Initialized
INFO - 2023-09-12 11:28:54 --> Language Class Initialized
INFO - 2023-09-12 11:28:54 --> Language Class Initialized
INFO - 2023-09-12 11:28:54 --> Config Class Initialized
INFO - 2023-09-12 11:28:54 --> Loader Class Initialized
INFO - 2023-09-12 11:28:54 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:54 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:54 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:54 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:54 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:54 --> Controller Class Initialized
INFO - 2023-09-12 11:28:54 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:54 --> Total execution time: 0.0311
INFO - 2023-09-12 11:28:55 --> Config Class Initialized
INFO - 2023-09-12 11:28:55 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:55 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:55 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:55 --> URI Class Initialized
INFO - 2023-09-12 11:28:55 --> Router Class Initialized
INFO - 2023-09-12 11:28:55 --> Output Class Initialized
INFO - 2023-09-12 11:28:55 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:55 --> Input Class Initialized
INFO - 2023-09-12 11:28:55 --> Language Class Initialized
INFO - 2023-09-12 11:28:55 --> Language Class Initialized
INFO - 2023-09-12 11:28:55 --> Config Class Initialized
INFO - 2023-09-12 11:28:55 --> Loader Class Initialized
INFO - 2023-09-12 11:28:55 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:55 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:55 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:55 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:55 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:55 --> Controller Class Initialized
INFO - 2023-09-12 11:28:55 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:55 --> Total execution time: 0.0391
INFO - 2023-09-12 11:28:56 --> Config Class Initialized
INFO - 2023-09-12 11:28:56 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:56 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:56 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:56 --> URI Class Initialized
INFO - 2023-09-12 11:28:56 --> Router Class Initialized
INFO - 2023-09-12 11:28:56 --> Output Class Initialized
INFO - 2023-09-12 11:28:56 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:56 --> Input Class Initialized
INFO - 2023-09-12 11:28:56 --> Language Class Initialized
INFO - 2023-09-12 11:28:56 --> Language Class Initialized
INFO - 2023-09-12 11:28:56 --> Config Class Initialized
INFO - 2023-09-12 11:28:56 --> Loader Class Initialized
INFO - 2023-09-12 11:28:56 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:56 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:56 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:56 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:56 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:56 --> Controller Class Initialized
INFO - 2023-09-12 11:28:56 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:56 --> Total execution time: 0.0337
INFO - 2023-09-12 11:28:56 --> Config Class Initialized
INFO - 2023-09-12 11:28:56 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:28:56 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:28:56 --> Utf8 Class Initialized
INFO - 2023-09-12 11:28:56 --> URI Class Initialized
INFO - 2023-09-12 11:28:56 --> Router Class Initialized
INFO - 2023-09-12 11:28:56 --> Output Class Initialized
INFO - 2023-09-12 11:28:56 --> Security Class Initialized
DEBUG - 2023-09-12 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:28:56 --> Input Class Initialized
INFO - 2023-09-12 11:28:56 --> Language Class Initialized
INFO - 2023-09-12 11:28:56 --> Language Class Initialized
INFO - 2023-09-12 11:28:56 --> Config Class Initialized
INFO - 2023-09-12 11:28:56 --> Loader Class Initialized
INFO - 2023-09-12 11:28:56 --> Helper loaded: url_helper
INFO - 2023-09-12 11:28:56 --> Helper loaded: file_helper
INFO - 2023-09-12 11:28:56 --> Helper loaded: form_helper
INFO - 2023-09-12 11:28:56 --> Helper loaded: my_helper
INFO - 2023-09-12 11:28:56 --> Database Driver Class Initialized
INFO - 2023-09-12 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:28:56 --> Controller Class Initialized
INFO - 2023-09-12 11:28:56 --> Final output sent to browser
DEBUG - 2023-09-12 11:28:56 --> Total execution time: 0.0412
INFO - 2023-09-12 11:29:00 --> Config Class Initialized
INFO - 2023-09-12 11:29:00 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:29:00 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:29:00 --> Utf8 Class Initialized
INFO - 2023-09-12 11:29:00 --> URI Class Initialized
INFO - 2023-09-12 11:29:00 --> Router Class Initialized
INFO - 2023-09-12 11:29:00 --> Output Class Initialized
INFO - 2023-09-12 11:29:00 --> Security Class Initialized
DEBUG - 2023-09-12 11:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:29:00 --> Input Class Initialized
INFO - 2023-09-12 11:29:00 --> Language Class Initialized
INFO - 2023-09-12 11:29:00 --> Language Class Initialized
INFO - 2023-09-12 11:29:00 --> Config Class Initialized
INFO - 2023-09-12 11:29:00 --> Loader Class Initialized
INFO - 2023-09-12 11:29:00 --> Helper loaded: url_helper
INFO - 2023-09-12 11:29:00 --> Helper loaded: file_helper
INFO - 2023-09-12 11:29:00 --> Helper loaded: form_helper
INFO - 2023-09-12 11:29:00 --> Helper loaded: my_helper
INFO - 2023-09-12 11:29:00 --> Database Driver Class Initialized
INFO - 2023-09-12 11:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:29:00 --> Controller Class Initialized
DEBUG - 2023-09-12 11:29:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:29:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:29:00 --> Final output sent to browser
DEBUG - 2023-09-12 11:29:00 --> Total execution time: 0.0749
INFO - 2023-09-12 11:29:04 --> Config Class Initialized
INFO - 2023-09-12 11:29:04 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:29:04 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:29:04 --> Utf8 Class Initialized
INFO - 2023-09-12 11:29:04 --> URI Class Initialized
INFO - 2023-09-12 11:29:04 --> Router Class Initialized
INFO - 2023-09-12 11:29:04 --> Output Class Initialized
INFO - 2023-09-12 11:29:04 --> Security Class Initialized
DEBUG - 2023-09-12 11:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:29:04 --> Input Class Initialized
INFO - 2023-09-12 11:29:04 --> Language Class Initialized
INFO - 2023-09-12 11:29:04 --> Language Class Initialized
INFO - 2023-09-12 11:29:04 --> Config Class Initialized
INFO - 2023-09-12 11:29:04 --> Loader Class Initialized
INFO - 2023-09-12 11:29:04 --> Helper loaded: url_helper
INFO - 2023-09-12 11:29:04 --> Helper loaded: file_helper
INFO - 2023-09-12 11:29:04 --> Helper loaded: form_helper
INFO - 2023-09-12 11:29:04 --> Helper loaded: my_helper
INFO - 2023-09-12 11:29:04 --> Database Driver Class Initialized
INFO - 2023-09-12 11:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:29:04 --> Controller Class Initialized
DEBUG - 2023-09-12 11:29:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-12 11:29:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:29:04 --> Final output sent to browser
DEBUG - 2023-09-12 11:29:04 --> Total execution time: 0.1170
INFO - 2023-09-12 11:30:13 --> Config Class Initialized
INFO - 2023-09-12 11:30:13 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:13 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:13 --> URI Class Initialized
INFO - 2023-09-12 11:30:13 --> Router Class Initialized
INFO - 2023-09-12 11:30:13 --> Output Class Initialized
INFO - 2023-09-12 11:30:13 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:13 --> Input Class Initialized
INFO - 2023-09-12 11:30:13 --> Language Class Initialized
INFO - 2023-09-12 11:30:13 --> Language Class Initialized
INFO - 2023-09-12 11:30:13 --> Config Class Initialized
INFO - 2023-09-12 11:30:13 --> Loader Class Initialized
INFO - 2023-09-12 11:30:13 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:13 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:13 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:13 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:13 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:13 --> Controller Class Initialized
DEBUG - 2023-09-12 11:30:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:30:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:30:13 --> Final output sent to browser
DEBUG - 2023-09-12 11:30:13 --> Total execution time: 0.0292
INFO - 2023-09-12 11:30:30 --> Config Class Initialized
INFO - 2023-09-12 11:30:30 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:30 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:30 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:30 --> URI Class Initialized
INFO - 2023-09-12 11:30:30 --> Router Class Initialized
INFO - 2023-09-12 11:30:30 --> Output Class Initialized
INFO - 2023-09-12 11:30:30 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:30 --> Input Class Initialized
INFO - 2023-09-12 11:30:30 --> Language Class Initialized
INFO - 2023-09-12 11:30:30 --> Language Class Initialized
INFO - 2023-09-12 11:30:30 --> Config Class Initialized
INFO - 2023-09-12 11:30:30 --> Loader Class Initialized
INFO - 2023-09-12 11:30:30 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:30 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:30 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:30 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:31 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:31 --> Controller Class Initialized
DEBUG - 2023-09-12 11:30:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-12 11:30:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:30:31 --> Final output sent to browser
DEBUG - 2023-09-12 11:30:31 --> Total execution time: 0.0745
INFO - 2023-09-12 11:30:31 --> Config Class Initialized
INFO - 2023-09-12 11:30:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:31 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:31 --> URI Class Initialized
INFO - 2023-09-12 11:30:31 --> Router Class Initialized
INFO - 2023-09-12 11:30:31 --> Output Class Initialized
INFO - 2023-09-12 11:30:31 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:31 --> Input Class Initialized
INFO - 2023-09-12 11:30:31 --> Language Class Initialized
INFO - 2023-09-12 11:30:31 --> Language Class Initialized
INFO - 2023-09-12 11:30:31 --> Config Class Initialized
INFO - 2023-09-12 11:30:31 --> Loader Class Initialized
INFO - 2023-09-12 11:30:31 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:31 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:31 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:31 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:31 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:31 --> Controller Class Initialized
INFO - 2023-09-12 11:30:39 --> Config Class Initialized
INFO - 2023-09-12 11:30:39 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:39 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:39 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:39 --> URI Class Initialized
INFO - 2023-09-12 11:30:39 --> Router Class Initialized
INFO - 2023-09-12 11:30:39 --> Output Class Initialized
INFO - 2023-09-12 11:30:39 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:39 --> Input Class Initialized
INFO - 2023-09-12 11:30:39 --> Language Class Initialized
INFO - 2023-09-12 11:30:39 --> Language Class Initialized
INFO - 2023-09-12 11:30:39 --> Config Class Initialized
INFO - 2023-09-12 11:30:39 --> Loader Class Initialized
INFO - 2023-09-12 11:30:39 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:39 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:39 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:39 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:39 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:39 --> Controller Class Initialized
INFO - 2023-09-12 11:30:39 --> Final output sent to browser
DEBUG - 2023-09-12 11:30:39 --> Total execution time: 0.0374
INFO - 2023-09-12 11:30:41 --> Config Class Initialized
INFO - 2023-09-12 11:30:41 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:41 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:41 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:41 --> URI Class Initialized
INFO - 2023-09-12 11:30:41 --> Router Class Initialized
INFO - 2023-09-12 11:30:41 --> Output Class Initialized
INFO - 2023-09-12 11:30:41 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:41 --> Input Class Initialized
INFO - 2023-09-12 11:30:41 --> Language Class Initialized
INFO - 2023-09-12 11:30:41 --> Language Class Initialized
INFO - 2023-09-12 11:30:41 --> Config Class Initialized
INFO - 2023-09-12 11:30:41 --> Loader Class Initialized
INFO - 2023-09-12 11:30:41 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:41 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:41 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:41 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:41 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:41 --> Controller Class Initialized
INFO - 2023-09-12 11:30:41 --> Final output sent to browser
DEBUG - 2023-09-12 11:30:41 --> Total execution time: 0.0322
INFO - 2023-09-12 11:30:51 --> Config Class Initialized
INFO - 2023-09-12 11:30:51 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:51 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:51 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:51 --> URI Class Initialized
INFO - 2023-09-12 11:30:51 --> Router Class Initialized
INFO - 2023-09-12 11:30:51 --> Output Class Initialized
INFO - 2023-09-12 11:30:51 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:51 --> Input Class Initialized
INFO - 2023-09-12 11:30:51 --> Language Class Initialized
INFO - 2023-09-12 11:30:51 --> Language Class Initialized
INFO - 2023-09-12 11:30:51 --> Config Class Initialized
INFO - 2023-09-12 11:30:51 --> Loader Class Initialized
INFO - 2023-09-12 11:30:51 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:51 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:51 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:51 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:51 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:51 --> Controller Class Initialized
INFO - 2023-09-12 11:30:51 --> Final output sent to browser
DEBUG - 2023-09-12 11:30:51 --> Total execution time: 0.0352
INFO - 2023-09-12 11:30:53 --> Config Class Initialized
INFO - 2023-09-12 11:30:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:30:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:30:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:30:53 --> URI Class Initialized
INFO - 2023-09-12 11:30:53 --> Router Class Initialized
INFO - 2023-09-12 11:30:53 --> Output Class Initialized
INFO - 2023-09-12 11:30:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:30:53 --> Input Class Initialized
INFO - 2023-09-12 11:30:53 --> Language Class Initialized
INFO - 2023-09-12 11:30:53 --> Language Class Initialized
INFO - 2023-09-12 11:30:53 --> Config Class Initialized
INFO - 2023-09-12 11:30:53 --> Loader Class Initialized
INFO - 2023-09-12 11:30:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:30:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:30:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:30:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:30:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:30:53 --> Controller Class Initialized
INFO - 2023-09-12 11:30:53 --> Final output sent to browser
DEBUG - 2023-09-12 11:30:53 --> Total execution time: 0.0321
INFO - 2023-09-12 11:31:10 --> Config Class Initialized
INFO - 2023-09-12 11:31:10 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:10 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:10 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:10 --> URI Class Initialized
INFO - 2023-09-12 11:31:10 --> Router Class Initialized
INFO - 2023-09-12 11:31:10 --> Output Class Initialized
INFO - 2023-09-12 11:31:10 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:10 --> Input Class Initialized
INFO - 2023-09-12 11:31:10 --> Language Class Initialized
INFO - 2023-09-12 11:31:10 --> Language Class Initialized
INFO - 2023-09-12 11:31:10 --> Config Class Initialized
INFO - 2023-09-12 11:31:10 --> Loader Class Initialized
INFO - 2023-09-12 11:31:10 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:10 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:10 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:10 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:10 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:10 --> Controller Class Initialized
INFO - 2023-09-12 11:31:10 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:10 --> Total execution time: 0.0719
INFO - 2023-09-12 11:31:12 --> Config Class Initialized
INFO - 2023-09-12 11:31:12 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:12 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:12 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:12 --> URI Class Initialized
INFO - 2023-09-12 11:31:12 --> Router Class Initialized
INFO - 2023-09-12 11:31:12 --> Output Class Initialized
INFO - 2023-09-12 11:31:12 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:12 --> Input Class Initialized
INFO - 2023-09-12 11:31:12 --> Language Class Initialized
INFO - 2023-09-12 11:31:12 --> Language Class Initialized
INFO - 2023-09-12 11:31:12 --> Config Class Initialized
INFO - 2023-09-12 11:31:12 --> Loader Class Initialized
INFO - 2023-09-12 11:31:12 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:12 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:12 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:12 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:12 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:12 --> Controller Class Initialized
INFO - 2023-09-12 11:31:12 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:12 --> Total execution time: 0.0472
INFO - 2023-09-12 11:31:29 --> Config Class Initialized
INFO - 2023-09-12 11:31:29 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:29 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:29 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:29 --> URI Class Initialized
INFO - 2023-09-12 11:31:29 --> Router Class Initialized
INFO - 2023-09-12 11:31:29 --> Output Class Initialized
INFO - 2023-09-12 11:31:29 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:29 --> Input Class Initialized
INFO - 2023-09-12 11:31:29 --> Language Class Initialized
INFO - 2023-09-12 11:31:29 --> Language Class Initialized
INFO - 2023-09-12 11:31:29 --> Config Class Initialized
INFO - 2023-09-12 11:31:29 --> Loader Class Initialized
INFO - 2023-09-12 11:31:29 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:29 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:29 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:29 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:29 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:29 --> Controller Class Initialized
INFO - 2023-09-12 11:31:29 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:29 --> Total execution time: 0.0354
INFO - 2023-09-12 11:31:33 --> Config Class Initialized
INFO - 2023-09-12 11:31:33 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:33 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:33 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:33 --> URI Class Initialized
INFO - 2023-09-12 11:31:33 --> Router Class Initialized
INFO - 2023-09-12 11:31:33 --> Output Class Initialized
INFO - 2023-09-12 11:31:33 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:33 --> Input Class Initialized
INFO - 2023-09-12 11:31:33 --> Language Class Initialized
INFO - 2023-09-12 11:31:33 --> Language Class Initialized
INFO - 2023-09-12 11:31:33 --> Config Class Initialized
INFO - 2023-09-12 11:31:33 --> Loader Class Initialized
INFO - 2023-09-12 11:31:33 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:33 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:33 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:33 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:33 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:33 --> Controller Class Initialized
INFO - 2023-09-12 11:31:33 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:33 --> Total execution time: 0.0335
INFO - 2023-09-12 11:31:35 --> Config Class Initialized
INFO - 2023-09-12 11:31:35 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:35 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:35 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:35 --> URI Class Initialized
INFO - 2023-09-12 11:31:35 --> Router Class Initialized
INFO - 2023-09-12 11:31:35 --> Output Class Initialized
INFO - 2023-09-12 11:31:35 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:35 --> Input Class Initialized
INFO - 2023-09-12 11:31:35 --> Language Class Initialized
INFO - 2023-09-12 11:31:35 --> Language Class Initialized
INFO - 2023-09-12 11:31:35 --> Config Class Initialized
INFO - 2023-09-12 11:31:35 --> Loader Class Initialized
INFO - 2023-09-12 11:31:35 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:35 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:35 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:35 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:35 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:35 --> Controller Class Initialized
INFO - 2023-09-12 11:31:35 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:35 --> Total execution time: 0.0359
INFO - 2023-09-12 11:31:50 --> Config Class Initialized
INFO - 2023-09-12 11:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:50 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:50 --> URI Class Initialized
INFO - 2023-09-12 11:31:50 --> Router Class Initialized
INFO - 2023-09-12 11:31:50 --> Output Class Initialized
INFO - 2023-09-12 11:31:50 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:50 --> Input Class Initialized
INFO - 2023-09-12 11:31:50 --> Language Class Initialized
INFO - 2023-09-12 11:31:50 --> Language Class Initialized
INFO - 2023-09-12 11:31:50 --> Config Class Initialized
INFO - 2023-09-12 11:31:50 --> Loader Class Initialized
INFO - 2023-09-12 11:31:50 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:50 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:50 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:50 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:50 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:50 --> Controller Class Initialized
INFO - 2023-09-12 11:31:50 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:50 --> Total execution time: 0.1217
INFO - 2023-09-12 11:31:50 --> Config Class Initialized
INFO - 2023-09-12 11:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:50 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:50 --> URI Class Initialized
INFO - 2023-09-12 11:31:50 --> Router Class Initialized
INFO - 2023-09-12 11:31:50 --> Output Class Initialized
INFO - 2023-09-12 11:31:50 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:50 --> Input Class Initialized
INFO - 2023-09-12 11:31:50 --> Language Class Initialized
INFO - 2023-09-12 11:31:50 --> Language Class Initialized
INFO - 2023-09-12 11:31:50 --> Config Class Initialized
INFO - 2023-09-12 11:31:50 --> Loader Class Initialized
INFO - 2023-09-12 11:31:50 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:50 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:50 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:50 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:50 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:50 --> Controller Class Initialized
INFO - 2023-09-12 11:31:57 --> Config Class Initialized
INFO - 2023-09-12 11:31:57 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:57 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:57 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:57 --> URI Class Initialized
INFO - 2023-09-12 11:31:57 --> Router Class Initialized
INFO - 2023-09-12 11:31:57 --> Output Class Initialized
INFO - 2023-09-12 11:31:57 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:57 --> Input Class Initialized
INFO - 2023-09-12 11:31:57 --> Language Class Initialized
INFO - 2023-09-12 11:31:57 --> Language Class Initialized
INFO - 2023-09-12 11:31:57 --> Config Class Initialized
INFO - 2023-09-12 11:31:57 --> Loader Class Initialized
INFO - 2023-09-12 11:31:57 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:57 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:57 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:57 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:57 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:57 --> Controller Class Initialized
INFO - 2023-09-12 11:31:57 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:57 --> Total execution time: 0.1345
INFO - 2023-09-12 11:31:57 --> Config Class Initialized
INFO - 2023-09-12 11:31:57 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:31:57 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:31:57 --> Utf8 Class Initialized
INFO - 2023-09-12 11:31:57 --> URI Class Initialized
INFO - 2023-09-12 11:31:57 --> Router Class Initialized
INFO - 2023-09-12 11:31:57 --> Output Class Initialized
INFO - 2023-09-12 11:31:57 --> Security Class Initialized
DEBUG - 2023-09-12 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:31:57 --> Input Class Initialized
INFO - 2023-09-12 11:31:57 --> Language Class Initialized
INFO - 2023-09-12 11:31:57 --> Language Class Initialized
INFO - 2023-09-12 11:31:57 --> Config Class Initialized
INFO - 2023-09-12 11:31:57 --> Loader Class Initialized
INFO - 2023-09-12 11:31:57 --> Helper loaded: url_helper
INFO - 2023-09-12 11:31:57 --> Helper loaded: file_helper
INFO - 2023-09-12 11:31:57 --> Helper loaded: form_helper
INFO - 2023-09-12 11:31:57 --> Helper loaded: my_helper
INFO - 2023-09-12 11:31:57 --> Database Driver Class Initialized
INFO - 2023-09-12 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:31:57 --> Controller Class Initialized
INFO - 2023-09-12 11:31:57 --> Final output sent to browser
DEBUG - 2023-09-12 11:31:57 --> Total execution time: 0.0320
INFO - 2023-09-12 11:32:39 --> Config Class Initialized
INFO - 2023-09-12 11:32:39 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:32:39 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:32:39 --> Utf8 Class Initialized
INFO - 2023-09-12 11:32:39 --> URI Class Initialized
INFO - 2023-09-12 11:32:39 --> Router Class Initialized
INFO - 2023-09-12 11:32:39 --> Output Class Initialized
INFO - 2023-09-12 11:32:39 --> Security Class Initialized
DEBUG - 2023-09-12 11:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:32:39 --> Input Class Initialized
INFO - 2023-09-12 11:32:39 --> Language Class Initialized
INFO - 2023-09-12 11:32:39 --> Language Class Initialized
INFO - 2023-09-12 11:32:39 --> Config Class Initialized
INFO - 2023-09-12 11:32:39 --> Loader Class Initialized
INFO - 2023-09-12 11:32:39 --> Helper loaded: url_helper
INFO - 2023-09-12 11:32:39 --> Helper loaded: file_helper
INFO - 2023-09-12 11:32:39 --> Helper loaded: form_helper
INFO - 2023-09-12 11:32:39 --> Helper loaded: my_helper
INFO - 2023-09-12 11:32:39 --> Database Driver Class Initialized
INFO - 2023-09-12 11:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:32:39 --> Controller Class Initialized
INFO - 2023-09-12 11:32:39 --> Final output sent to browser
DEBUG - 2023-09-12 11:32:39 --> Total execution time: 0.0385
INFO - 2023-09-12 11:32:40 --> Config Class Initialized
INFO - 2023-09-12 11:32:40 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:32:40 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:32:40 --> Utf8 Class Initialized
INFO - 2023-09-12 11:32:40 --> URI Class Initialized
INFO - 2023-09-12 11:32:40 --> Router Class Initialized
INFO - 2023-09-12 11:32:40 --> Output Class Initialized
INFO - 2023-09-12 11:32:40 --> Security Class Initialized
DEBUG - 2023-09-12 11:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:32:40 --> Input Class Initialized
INFO - 2023-09-12 11:32:40 --> Language Class Initialized
INFO - 2023-09-12 11:32:40 --> Language Class Initialized
INFO - 2023-09-12 11:32:40 --> Config Class Initialized
INFO - 2023-09-12 11:32:40 --> Loader Class Initialized
INFO - 2023-09-12 11:32:40 --> Helper loaded: url_helper
INFO - 2023-09-12 11:32:40 --> Helper loaded: file_helper
INFO - 2023-09-12 11:32:40 --> Helper loaded: form_helper
INFO - 2023-09-12 11:32:40 --> Helper loaded: my_helper
INFO - 2023-09-12 11:32:40 --> Database Driver Class Initialized
INFO - 2023-09-12 11:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:32:40 --> Controller Class Initialized
INFO - 2023-09-12 11:32:47 --> Config Class Initialized
INFO - 2023-09-12 11:32:47 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:32:47 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:32:47 --> Utf8 Class Initialized
INFO - 2023-09-12 11:32:47 --> URI Class Initialized
INFO - 2023-09-12 11:32:47 --> Router Class Initialized
INFO - 2023-09-12 11:32:47 --> Output Class Initialized
INFO - 2023-09-12 11:32:47 --> Security Class Initialized
DEBUG - 2023-09-12 11:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:32:47 --> Input Class Initialized
INFO - 2023-09-12 11:32:47 --> Language Class Initialized
INFO - 2023-09-12 11:32:47 --> Language Class Initialized
INFO - 2023-09-12 11:32:47 --> Config Class Initialized
INFO - 2023-09-12 11:32:47 --> Loader Class Initialized
INFO - 2023-09-12 11:32:47 --> Helper loaded: url_helper
INFO - 2023-09-12 11:32:47 --> Helper loaded: file_helper
INFO - 2023-09-12 11:32:47 --> Helper loaded: form_helper
INFO - 2023-09-12 11:32:47 --> Helper loaded: my_helper
INFO - 2023-09-12 11:32:47 --> Database Driver Class Initialized
INFO - 2023-09-12 11:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:32:47 --> Controller Class Initialized
INFO - 2023-09-12 11:32:47 --> Final output sent to browser
DEBUG - 2023-09-12 11:32:47 --> Total execution time: 0.0784
INFO - 2023-09-12 11:32:55 --> Config Class Initialized
INFO - 2023-09-12 11:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:32:55 --> Utf8 Class Initialized
INFO - 2023-09-12 11:32:55 --> URI Class Initialized
INFO - 2023-09-12 11:32:55 --> Router Class Initialized
INFO - 2023-09-12 11:32:55 --> Output Class Initialized
INFO - 2023-09-12 11:32:55 --> Security Class Initialized
DEBUG - 2023-09-12 11:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:32:55 --> Input Class Initialized
INFO - 2023-09-12 11:32:55 --> Language Class Initialized
INFO - 2023-09-12 11:32:55 --> Language Class Initialized
INFO - 2023-09-12 11:32:55 --> Config Class Initialized
INFO - 2023-09-12 11:32:55 --> Loader Class Initialized
INFO - 2023-09-12 11:32:55 --> Helper loaded: url_helper
INFO - 2023-09-12 11:32:55 --> Helper loaded: file_helper
INFO - 2023-09-12 11:32:55 --> Helper loaded: form_helper
INFO - 2023-09-12 11:32:55 --> Helper loaded: my_helper
INFO - 2023-09-12 11:32:55 --> Database Driver Class Initialized
INFO - 2023-09-12 11:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:32:55 --> Controller Class Initialized
INFO - 2023-09-12 11:32:55 --> Final output sent to browser
DEBUG - 2023-09-12 11:32:55 --> Total execution time: 0.0357
INFO - 2023-09-12 11:33:03 --> Config Class Initialized
INFO - 2023-09-12 11:33:03 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:03 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:03 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:03 --> URI Class Initialized
INFO - 2023-09-12 11:33:03 --> Router Class Initialized
INFO - 2023-09-12 11:33:03 --> Output Class Initialized
INFO - 2023-09-12 11:33:03 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:03 --> Input Class Initialized
INFO - 2023-09-12 11:33:03 --> Language Class Initialized
INFO - 2023-09-12 11:33:03 --> Language Class Initialized
INFO - 2023-09-12 11:33:03 --> Config Class Initialized
INFO - 2023-09-12 11:33:03 --> Loader Class Initialized
INFO - 2023-09-12 11:33:03 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:03 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:03 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:03 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:03 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:03 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-12 11:33:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:03 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:03 --> Total execution time: 0.0306
INFO - 2023-09-12 11:33:26 --> Config Class Initialized
INFO - 2023-09-12 11:33:26 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:26 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:26 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:26 --> URI Class Initialized
INFO - 2023-09-12 11:33:26 --> Router Class Initialized
INFO - 2023-09-12 11:33:26 --> Output Class Initialized
INFO - 2023-09-12 11:33:26 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:26 --> Input Class Initialized
INFO - 2023-09-12 11:33:26 --> Language Class Initialized
INFO - 2023-09-12 11:33:26 --> Language Class Initialized
INFO - 2023-09-12 11:33:26 --> Config Class Initialized
INFO - 2023-09-12 11:33:26 --> Loader Class Initialized
INFO - 2023-09-12 11:33:26 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:26 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:26 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:26 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:26 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:26 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:33:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:26 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:26 --> Total execution time: 0.0313
INFO - 2023-09-12 11:33:28 --> Config Class Initialized
INFO - 2023-09-12 11:33:28 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:28 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:28 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:28 --> URI Class Initialized
INFO - 2023-09-12 11:33:28 --> Router Class Initialized
INFO - 2023-09-12 11:33:28 --> Output Class Initialized
INFO - 2023-09-12 11:33:28 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:28 --> Input Class Initialized
INFO - 2023-09-12 11:33:28 --> Language Class Initialized
INFO - 2023-09-12 11:33:28 --> Language Class Initialized
INFO - 2023-09-12 11:33:28 --> Config Class Initialized
INFO - 2023-09-12 11:33:28 --> Loader Class Initialized
INFO - 2023-09-12 11:33:28 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:28 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:28 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:28 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:28 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:28 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-12 11:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:28 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:28 --> Total execution time: 0.0290
INFO - 2023-09-12 11:33:31 --> Config Class Initialized
INFO - 2023-09-12 11:33:31 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:31 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:31 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:32 --> URI Class Initialized
INFO - 2023-09-12 11:33:32 --> Router Class Initialized
INFO - 2023-09-12 11:33:32 --> Output Class Initialized
INFO - 2023-09-12 11:33:32 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:32 --> Input Class Initialized
INFO - 2023-09-12 11:33:32 --> Language Class Initialized
INFO - 2023-09-12 11:33:32 --> Language Class Initialized
INFO - 2023-09-12 11:33:32 --> Config Class Initialized
INFO - 2023-09-12 11:33:32 --> Loader Class Initialized
INFO - 2023-09-12 11:33:32 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:32 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:32 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:32 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:32 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:32 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:33:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:32 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:32 --> Total execution time: 0.0315
INFO - 2023-09-12 11:33:35 --> Config Class Initialized
INFO - 2023-09-12 11:33:35 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:35 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:35 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:35 --> URI Class Initialized
INFO - 2023-09-12 11:33:35 --> Router Class Initialized
INFO - 2023-09-12 11:33:35 --> Output Class Initialized
INFO - 2023-09-12 11:33:35 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:35 --> Input Class Initialized
INFO - 2023-09-12 11:33:35 --> Language Class Initialized
INFO - 2023-09-12 11:33:35 --> Language Class Initialized
INFO - 2023-09-12 11:33:35 --> Config Class Initialized
INFO - 2023-09-12 11:33:35 --> Loader Class Initialized
INFO - 2023-09-12 11:33:35 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:35 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:35 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:35 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:35 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:35 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-12 11:33:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:35 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:35 --> Total execution time: 0.0366
INFO - 2023-09-12 11:33:35 --> Config Class Initialized
INFO - 2023-09-12 11:33:35 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:35 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:35 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:35 --> URI Class Initialized
INFO - 2023-09-12 11:33:35 --> Router Class Initialized
INFO - 2023-09-12 11:33:35 --> Output Class Initialized
INFO - 2023-09-12 11:33:35 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:35 --> Input Class Initialized
INFO - 2023-09-12 11:33:35 --> Language Class Initialized
INFO - 2023-09-12 11:33:35 --> Language Class Initialized
INFO - 2023-09-12 11:33:35 --> Config Class Initialized
INFO - 2023-09-12 11:33:35 --> Loader Class Initialized
INFO - 2023-09-12 11:33:35 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:35 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:35 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:35 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:35 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:35 --> Controller Class Initialized
INFO - 2023-09-12 11:33:52 --> Config Class Initialized
INFO - 2023-09-12 11:33:52 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:52 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:52 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:52 --> URI Class Initialized
INFO - 2023-09-12 11:33:52 --> Router Class Initialized
INFO - 2023-09-12 11:33:52 --> Output Class Initialized
INFO - 2023-09-12 11:33:52 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:52 --> Input Class Initialized
INFO - 2023-09-12 11:33:52 --> Language Class Initialized
INFO - 2023-09-12 11:33:52 --> Language Class Initialized
INFO - 2023-09-12 11:33:52 --> Config Class Initialized
INFO - 2023-09-12 11:33:52 --> Loader Class Initialized
INFO - 2023-09-12 11:33:52 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:52 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:52 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:52 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:52 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:52 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:52 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:52 --> Total execution time: 0.0317
INFO - 2023-09-12 11:33:55 --> Config Class Initialized
INFO - 2023-09-12 11:33:55 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:55 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:55 --> URI Class Initialized
INFO - 2023-09-12 11:33:55 --> Router Class Initialized
INFO - 2023-09-12 11:33:55 --> Output Class Initialized
INFO - 2023-09-12 11:33:55 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:55 --> Input Class Initialized
INFO - 2023-09-12 11:33:55 --> Language Class Initialized
INFO - 2023-09-12 11:33:55 --> Language Class Initialized
INFO - 2023-09-12 11:33:55 --> Config Class Initialized
INFO - 2023-09-12 11:33:55 --> Loader Class Initialized
INFO - 2023-09-12 11:33:55 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:55 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:55 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:55 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:55 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:55 --> Controller Class Initialized
DEBUG - 2023-09-12 11:33:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-12 11:33:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:33:55 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:55 --> Total execution time: 0.0424
INFO - 2023-09-12 11:33:59 --> Config Class Initialized
INFO - 2023-09-12 11:33:59 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:33:59 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:33:59 --> Utf8 Class Initialized
INFO - 2023-09-12 11:33:59 --> URI Class Initialized
INFO - 2023-09-12 11:33:59 --> Router Class Initialized
INFO - 2023-09-12 11:33:59 --> Output Class Initialized
INFO - 2023-09-12 11:33:59 --> Security Class Initialized
DEBUG - 2023-09-12 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:33:59 --> Input Class Initialized
INFO - 2023-09-12 11:33:59 --> Language Class Initialized
INFO - 2023-09-12 11:33:59 --> Language Class Initialized
INFO - 2023-09-12 11:33:59 --> Config Class Initialized
INFO - 2023-09-12 11:33:59 --> Loader Class Initialized
INFO - 2023-09-12 11:33:59 --> Helper loaded: url_helper
INFO - 2023-09-12 11:33:59 --> Helper loaded: file_helper
INFO - 2023-09-12 11:33:59 --> Helper loaded: form_helper
INFO - 2023-09-12 11:33:59 --> Helper loaded: my_helper
INFO - 2023-09-12 11:33:59 --> Database Driver Class Initialized
INFO - 2023-09-12 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:33:59 --> Controller Class Initialized
INFO - 2023-09-12 11:33:59 --> Final output sent to browser
DEBUG - 2023-09-12 11:33:59 --> Total execution time: 0.0415
INFO - 2023-09-12 11:34:16 --> Config Class Initialized
INFO - 2023-09-12 11:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:34:16 --> Utf8 Class Initialized
INFO - 2023-09-12 11:34:16 --> URI Class Initialized
INFO - 2023-09-12 11:34:17 --> Router Class Initialized
INFO - 2023-09-12 11:34:17 --> Output Class Initialized
INFO - 2023-09-12 11:34:17 --> Security Class Initialized
DEBUG - 2023-09-12 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:34:17 --> Input Class Initialized
INFO - 2023-09-12 11:34:17 --> Language Class Initialized
INFO - 2023-09-12 11:34:17 --> Language Class Initialized
INFO - 2023-09-12 11:34:17 --> Config Class Initialized
INFO - 2023-09-12 11:34:17 --> Loader Class Initialized
INFO - 2023-09-12 11:34:17 --> Helper loaded: url_helper
INFO - 2023-09-12 11:34:17 --> Helper loaded: file_helper
INFO - 2023-09-12 11:34:17 --> Helper loaded: form_helper
INFO - 2023-09-12 11:34:17 --> Helper loaded: my_helper
INFO - 2023-09-12 11:34:17 --> Database Driver Class Initialized
INFO - 2023-09-12 11:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:34:17 --> Controller Class Initialized
DEBUG - 2023-09-12 11:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-12 11:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:34:17 --> Final output sent to browser
DEBUG - 2023-09-12 11:34:17 --> Total execution time: 0.0313
INFO - 2023-09-12 11:34:46 --> Config Class Initialized
INFO - 2023-09-12 11:34:46 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:34:46 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:34:46 --> Utf8 Class Initialized
INFO - 2023-09-12 11:34:46 --> URI Class Initialized
DEBUG - 2023-09-12 11:34:46 --> No URI present. Default controller set.
INFO - 2023-09-12 11:34:46 --> Router Class Initialized
INFO - 2023-09-12 11:34:46 --> Output Class Initialized
INFO - 2023-09-12 11:34:46 --> Security Class Initialized
DEBUG - 2023-09-12 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:34:46 --> Input Class Initialized
INFO - 2023-09-12 11:34:46 --> Language Class Initialized
INFO - 2023-09-12 11:34:46 --> Language Class Initialized
INFO - 2023-09-12 11:34:46 --> Config Class Initialized
INFO - 2023-09-12 11:34:46 --> Loader Class Initialized
INFO - 2023-09-12 11:34:46 --> Helper loaded: url_helper
INFO - 2023-09-12 11:34:46 --> Helper loaded: file_helper
INFO - 2023-09-12 11:34:46 --> Helper loaded: form_helper
INFO - 2023-09-12 11:34:46 --> Helper loaded: my_helper
INFO - 2023-09-12 11:34:46 --> Database Driver Class Initialized
INFO - 2023-09-12 11:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:34:46 --> Controller Class Initialized
DEBUG - 2023-09-12 11:34:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-12 11:34:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:34:46 --> Final output sent to browser
DEBUG - 2023-09-12 11:34:46 --> Total execution time: 0.0317
INFO - 2023-09-12 11:34:53 --> Config Class Initialized
INFO - 2023-09-12 11:34:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:34:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:34:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:34:53 --> URI Class Initialized
INFO - 2023-09-12 11:34:53 --> Router Class Initialized
INFO - 2023-09-12 11:34:53 --> Output Class Initialized
INFO - 2023-09-12 11:34:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:34:53 --> Input Class Initialized
INFO - 2023-09-12 11:34:53 --> Language Class Initialized
INFO - 2023-09-12 11:34:53 --> Language Class Initialized
INFO - 2023-09-12 11:34:53 --> Config Class Initialized
INFO - 2023-09-12 11:34:53 --> Loader Class Initialized
INFO - 2023-09-12 11:34:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:34:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:34:53 --> Controller Class Initialized
INFO - 2023-09-12 11:34:53 --> Helper loaded: cookie_helper
INFO - 2023-09-12 11:34:53 --> Config Class Initialized
INFO - 2023-09-12 11:34:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:34:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:34:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:34:53 --> URI Class Initialized
INFO - 2023-09-12 11:34:53 --> Router Class Initialized
INFO - 2023-09-12 11:34:53 --> Output Class Initialized
INFO - 2023-09-12 11:34:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:34:53 --> Input Class Initialized
INFO - 2023-09-12 11:34:53 --> Language Class Initialized
INFO - 2023-09-12 11:34:53 --> Language Class Initialized
INFO - 2023-09-12 11:34:53 --> Config Class Initialized
INFO - 2023-09-12 11:34:53 --> Loader Class Initialized
INFO - 2023-09-12 11:34:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:34:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:34:53 --> Controller Class Initialized
INFO - 2023-09-12 11:34:53 --> Config Class Initialized
INFO - 2023-09-12 11:34:53 --> Hooks Class Initialized
DEBUG - 2023-09-12 11:34:53 --> UTF-8 Support Enabled
INFO - 2023-09-12 11:34:53 --> Utf8 Class Initialized
INFO - 2023-09-12 11:34:53 --> URI Class Initialized
INFO - 2023-09-12 11:34:53 --> Router Class Initialized
INFO - 2023-09-12 11:34:53 --> Output Class Initialized
INFO - 2023-09-12 11:34:53 --> Security Class Initialized
DEBUG - 2023-09-12 11:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-12 11:34:53 --> Input Class Initialized
INFO - 2023-09-12 11:34:53 --> Language Class Initialized
INFO - 2023-09-12 11:34:53 --> Language Class Initialized
INFO - 2023-09-12 11:34:53 --> Config Class Initialized
INFO - 2023-09-12 11:34:53 --> Loader Class Initialized
INFO - 2023-09-12 11:34:53 --> Helper loaded: url_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: file_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: form_helper
INFO - 2023-09-12 11:34:53 --> Helper loaded: my_helper
INFO - 2023-09-12 11:34:53 --> Database Driver Class Initialized
INFO - 2023-09-12 11:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-12 11:34:53 --> Controller Class Initialized
DEBUG - 2023-09-12 11:34:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-12 11:34:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-12 11:34:53 --> Final output sent to browser
DEBUG - 2023-09-12 11:34:53 --> Total execution time: 0.0279
