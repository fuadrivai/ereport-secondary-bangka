<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-02 08:20:45 --> Config Class Initialized
INFO - 2023-11-02 08:20:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:20:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:20:45 --> Utf8 Class Initialized
INFO - 2023-11-02 08:20:45 --> URI Class Initialized
INFO - 2023-11-02 08:20:45 --> Router Class Initialized
INFO - 2023-11-02 08:20:45 --> Output Class Initialized
INFO - 2023-11-02 08:20:45 --> Security Class Initialized
DEBUG - 2023-11-02 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:20:45 --> Input Class Initialized
INFO - 2023-11-02 08:20:45 --> Language Class Initialized
INFO - 2023-11-02 08:20:45 --> Language Class Initialized
INFO - 2023-11-02 08:20:45 --> Config Class Initialized
INFO - 2023-11-02 08:20:45 --> Loader Class Initialized
INFO - 2023-11-02 08:20:45 --> Helper loaded: url_helper
INFO - 2023-11-02 08:20:45 --> Helper loaded: file_helper
INFO - 2023-11-02 08:20:45 --> Helper loaded: form_helper
INFO - 2023-11-02 08:20:45 --> Helper loaded: my_helper
INFO - 2023-11-02 08:20:45 --> Database Driver Class Initialized
INFO - 2023-11-02 08:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:20:45 --> Controller Class Initialized
DEBUG - 2023-11-02 08:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 08:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 08:20:45 --> Final output sent to browser
DEBUG - 2023-11-02 08:20:45 --> Total execution time: 0.0737
INFO - 2023-11-02 08:20:46 --> Config Class Initialized
INFO - 2023-11-02 08:20:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:20:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:20:46 --> Utf8 Class Initialized
INFO - 2023-11-02 08:20:46 --> URI Class Initialized
INFO - 2023-11-02 08:20:46 --> Router Class Initialized
INFO - 2023-11-02 08:20:46 --> Output Class Initialized
INFO - 2023-11-02 08:20:46 --> Security Class Initialized
DEBUG - 2023-11-02 08:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:20:46 --> Input Class Initialized
INFO - 2023-11-02 08:20:46 --> Language Class Initialized
INFO - 2023-11-02 08:20:46 --> Language Class Initialized
INFO - 2023-11-02 08:20:46 --> Config Class Initialized
INFO - 2023-11-02 08:20:46 --> Loader Class Initialized
INFO - 2023-11-02 08:20:46 --> Helper loaded: url_helper
INFO - 2023-11-02 08:20:46 --> Helper loaded: file_helper
INFO - 2023-11-02 08:20:46 --> Helper loaded: form_helper
INFO - 2023-11-02 08:20:46 --> Helper loaded: my_helper
INFO - 2023-11-02 08:20:46 --> Database Driver Class Initialized
INFO - 2023-11-02 08:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:20:46 --> Controller Class Initialized
DEBUG - 2023-11-02 08:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 08:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 08:20:46 --> Final output sent to browser
DEBUG - 2023-11-02 08:20:46 --> Total execution time: 0.0339
INFO - 2023-11-02 08:20:51 --> Config Class Initialized
INFO - 2023-11-02 08:20:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:20:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:20:51 --> Utf8 Class Initialized
INFO - 2023-11-02 08:20:51 --> URI Class Initialized
INFO - 2023-11-02 08:20:51 --> Router Class Initialized
INFO - 2023-11-02 08:20:51 --> Output Class Initialized
INFO - 2023-11-02 08:20:51 --> Security Class Initialized
DEBUG - 2023-11-02 08:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:20:51 --> Input Class Initialized
INFO - 2023-11-02 08:20:51 --> Language Class Initialized
INFO - 2023-11-02 08:20:51 --> Language Class Initialized
INFO - 2023-11-02 08:20:51 --> Config Class Initialized
INFO - 2023-11-02 08:20:51 --> Loader Class Initialized
INFO - 2023-11-02 08:20:51 --> Helper loaded: url_helper
INFO - 2023-11-02 08:20:51 --> Helper loaded: file_helper
INFO - 2023-11-02 08:20:51 --> Helper loaded: form_helper
INFO - 2023-11-02 08:20:51 --> Helper loaded: my_helper
INFO - 2023-11-02 08:20:51 --> Database Driver Class Initialized
INFO - 2023-11-02 08:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:20:51 --> Controller Class Initialized
INFO - 2023-11-02 08:20:51 --> Helper loaded: cookie_helper
INFO - 2023-11-02 08:20:51 --> Final output sent to browser
DEBUG - 2023-11-02 08:20:51 --> Total execution time: 0.1391
INFO - 2023-11-02 08:20:51 --> Config Class Initialized
INFO - 2023-11-02 08:20:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:20:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:20:51 --> Utf8 Class Initialized
INFO - 2023-11-02 08:20:51 --> URI Class Initialized
INFO - 2023-11-02 08:20:51 --> Router Class Initialized
INFO - 2023-11-02 08:20:51 --> Output Class Initialized
INFO - 2023-11-02 08:20:51 --> Security Class Initialized
DEBUG - 2023-11-02 08:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:20:51 --> Input Class Initialized
INFO - 2023-11-02 08:20:51 --> Language Class Initialized
INFO - 2023-11-02 08:20:51 --> Language Class Initialized
INFO - 2023-11-02 08:20:51 --> Config Class Initialized
INFO - 2023-11-02 08:20:51 --> Loader Class Initialized
INFO - 2023-11-02 08:20:51 --> Helper loaded: url_helper
INFO - 2023-11-02 08:20:51 --> Helper loaded: file_helper
INFO - 2023-11-02 08:20:51 --> Helper loaded: form_helper
INFO - 2023-11-02 08:20:51 --> Helper loaded: my_helper
INFO - 2023-11-02 08:20:51 --> Database Driver Class Initialized
INFO - 2023-11-02 08:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:20:51 --> Controller Class Initialized
DEBUG - 2023-11-02 08:20:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 08:20:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 08:20:51 --> Final output sent to browser
DEBUG - 2023-11-02 08:20:51 --> Total execution time: 0.0320
INFO - 2023-11-02 08:21:01 --> Config Class Initialized
INFO - 2023-11-02 08:21:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:21:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:21:01 --> Utf8 Class Initialized
INFO - 2023-11-02 08:21:01 --> URI Class Initialized
INFO - 2023-11-02 08:21:01 --> Router Class Initialized
INFO - 2023-11-02 08:21:01 --> Output Class Initialized
INFO - 2023-11-02 08:21:01 --> Security Class Initialized
DEBUG - 2023-11-02 08:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:21:01 --> Input Class Initialized
INFO - 2023-11-02 08:21:01 --> Language Class Initialized
INFO - 2023-11-02 08:21:01 --> Language Class Initialized
INFO - 2023-11-02 08:21:01 --> Config Class Initialized
INFO - 2023-11-02 08:21:01 --> Loader Class Initialized
INFO - 2023-11-02 08:21:01 --> Helper loaded: url_helper
INFO - 2023-11-02 08:21:01 --> Helper loaded: file_helper
INFO - 2023-11-02 08:21:01 --> Helper loaded: form_helper
INFO - 2023-11-02 08:21:01 --> Helper loaded: my_helper
INFO - 2023-11-02 08:21:01 --> Database Driver Class Initialized
INFO - 2023-11-02 08:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:21:01 --> Controller Class Initialized
DEBUG - 2023-11-02 08:21:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-02 08:21:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 08:21:01 --> Final output sent to browser
DEBUG - 2023-11-02 08:21:01 --> Total execution time: 0.0458
INFO - 2023-11-02 08:21:03 --> Config Class Initialized
INFO - 2023-11-02 08:21:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:21:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:21:03 --> Utf8 Class Initialized
INFO - 2023-11-02 08:21:03 --> URI Class Initialized
INFO - 2023-11-02 08:21:03 --> Router Class Initialized
INFO - 2023-11-02 08:21:03 --> Output Class Initialized
INFO - 2023-11-02 08:21:03 --> Security Class Initialized
DEBUG - 2023-11-02 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:21:03 --> Input Class Initialized
INFO - 2023-11-02 08:21:03 --> Language Class Initialized
INFO - 2023-11-02 08:21:03 --> Language Class Initialized
INFO - 2023-11-02 08:21:03 --> Config Class Initialized
INFO - 2023-11-02 08:21:03 --> Loader Class Initialized
INFO - 2023-11-02 08:21:03 --> Helper loaded: url_helper
INFO - 2023-11-02 08:21:03 --> Helper loaded: file_helper
INFO - 2023-11-02 08:21:03 --> Helper loaded: form_helper
INFO - 2023-11-02 08:21:03 --> Helper loaded: my_helper
INFO - 2023-11-02 08:21:03 --> Database Driver Class Initialized
INFO - 2023-11-02 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:21:03 --> Controller Class Initialized
DEBUG - 2023-11-02 08:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-11-02 08:21:03 --> Final output sent to browser
DEBUG - 2023-11-02 08:21:03 --> Total execution time: 0.0412
INFO - 2023-11-02 08:29:02 --> Config Class Initialized
INFO - 2023-11-02 08:29:02 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:29:02 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:29:02 --> Utf8 Class Initialized
INFO - 2023-11-02 08:29:02 --> URI Class Initialized
INFO - 2023-11-02 08:29:02 --> Router Class Initialized
INFO - 2023-11-02 08:29:02 --> Output Class Initialized
INFO - 2023-11-02 08:29:02 --> Security Class Initialized
DEBUG - 2023-11-02 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:29:02 --> Input Class Initialized
INFO - 2023-11-02 08:29:02 --> Language Class Initialized
INFO - 2023-11-02 08:29:02 --> Language Class Initialized
INFO - 2023-11-02 08:29:02 --> Config Class Initialized
INFO - 2023-11-02 08:29:02 --> Loader Class Initialized
INFO - 2023-11-02 08:29:02 --> Helper loaded: url_helper
INFO - 2023-11-02 08:29:02 --> Helper loaded: file_helper
INFO - 2023-11-02 08:29:02 --> Helper loaded: form_helper
INFO - 2023-11-02 08:29:02 --> Helper loaded: my_helper
INFO - 2023-11-02 08:29:02 --> Database Driver Class Initialized
INFO - 2023-11-02 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:29:02 --> Controller Class Initialized
DEBUG - 2023-11-02 08:29:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul2.php
INFO - 2023-11-02 08:29:02 --> Final output sent to browser
DEBUG - 2023-11-02 08:29:02 --> Total execution time: 0.1391
INFO - 2023-11-02 08:29:28 --> Config Class Initialized
INFO - 2023-11-02 08:29:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 08:29:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 08:29:28 --> Utf8 Class Initialized
INFO - 2023-11-02 08:29:28 --> URI Class Initialized
INFO - 2023-11-02 08:29:28 --> Router Class Initialized
INFO - 2023-11-02 08:29:28 --> Output Class Initialized
INFO - 2023-11-02 08:29:28 --> Security Class Initialized
DEBUG - 2023-11-02 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 08:29:28 --> Input Class Initialized
INFO - 2023-11-02 08:29:28 --> Language Class Initialized
INFO - 2023-11-02 08:29:28 --> Language Class Initialized
INFO - 2023-11-02 08:29:28 --> Config Class Initialized
INFO - 2023-11-02 08:29:28 --> Loader Class Initialized
INFO - 2023-11-02 08:29:28 --> Helper loaded: url_helper
INFO - 2023-11-02 08:29:28 --> Helper loaded: file_helper
INFO - 2023-11-02 08:29:28 --> Helper loaded: form_helper
INFO - 2023-11-02 08:29:28 --> Helper loaded: my_helper
INFO - 2023-11-02 08:29:28 --> Database Driver Class Initialized
INFO - 2023-11-02 08:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 08:29:28 --> Controller Class Initialized
DEBUG - 2023-11-02 08:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul4.php
INFO - 2023-11-02 08:29:28 --> Final output sent to browser
DEBUG - 2023-11-02 08:29:28 --> Total execution time: 0.0497
INFO - 2023-11-02 09:26:50 --> Config Class Initialized
INFO - 2023-11-02 09:26:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:26:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:26:50 --> Utf8 Class Initialized
INFO - 2023-11-02 09:26:50 --> URI Class Initialized
INFO - 2023-11-02 09:26:50 --> Router Class Initialized
INFO - 2023-11-02 09:26:50 --> Output Class Initialized
INFO - 2023-11-02 09:26:50 --> Security Class Initialized
DEBUG - 2023-11-02 09:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:26:50 --> Input Class Initialized
INFO - 2023-11-02 09:26:50 --> Language Class Initialized
INFO - 2023-11-02 09:26:50 --> Language Class Initialized
INFO - 2023-11-02 09:26:50 --> Config Class Initialized
INFO - 2023-11-02 09:26:50 --> Loader Class Initialized
INFO - 2023-11-02 09:26:50 --> Helper loaded: url_helper
INFO - 2023-11-02 09:26:50 --> Helper loaded: file_helper
INFO - 2023-11-02 09:26:50 --> Helper loaded: form_helper
INFO - 2023-11-02 09:26:50 --> Helper loaded: my_helper
INFO - 2023-11-02 09:26:50 --> Database Driver Class Initialized
INFO - 2023-11-02 09:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:26:50 --> Controller Class Initialized
DEBUG - 2023-11-02 09:26:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 09:26:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:26:50 --> Final output sent to browser
DEBUG - 2023-11-02 09:26:50 --> Total execution time: 0.0345
INFO - 2023-11-02 09:43:07 --> Config Class Initialized
INFO - 2023-11-02 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:07 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:07 --> URI Class Initialized
INFO - 2023-11-02 09:43:07 --> Router Class Initialized
INFO - 2023-11-02 09:43:07 --> Output Class Initialized
INFO - 2023-11-02 09:43:07 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:07 --> Input Class Initialized
INFO - 2023-11-02 09:43:07 --> Language Class Initialized
INFO - 2023-11-02 09:43:07 --> Language Class Initialized
INFO - 2023-11-02 09:43:07 --> Config Class Initialized
INFO - 2023-11-02 09:43:07 --> Loader Class Initialized
INFO - 2023-11-02 09:43:07 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:07 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:07 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:07 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:07 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:07 --> Controller Class Initialized
INFO - 2023-11-02 09:43:07 --> Config Class Initialized
INFO - 2023-11-02 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:07 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:07 --> URI Class Initialized
INFO - 2023-11-02 09:43:07 --> Router Class Initialized
INFO - 2023-11-02 09:43:07 --> Output Class Initialized
INFO - 2023-11-02 09:43:07 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:07 --> Input Class Initialized
INFO - 2023-11-02 09:43:07 --> Language Class Initialized
INFO - 2023-11-02 09:43:07 --> Language Class Initialized
INFO - 2023-11-02 09:43:07 --> Config Class Initialized
INFO - 2023-11-02 09:43:07 --> Loader Class Initialized
INFO - 2023-11-02 09:43:07 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:07 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:07 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:07 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:07 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:07 --> Controller Class Initialized
DEBUG - 2023-11-02 09:43:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 09:43:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:43:07 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:07 --> Total execution time: 0.0380
INFO - 2023-11-02 09:43:11 --> Config Class Initialized
INFO - 2023-11-02 09:43:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:11 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:11 --> URI Class Initialized
INFO - 2023-11-02 09:43:12 --> Router Class Initialized
INFO - 2023-11-02 09:43:12 --> Output Class Initialized
INFO - 2023-11-02 09:43:12 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:12 --> Input Class Initialized
INFO - 2023-11-02 09:43:12 --> Language Class Initialized
INFO - 2023-11-02 09:43:12 --> Language Class Initialized
INFO - 2023-11-02 09:43:12 --> Config Class Initialized
INFO - 2023-11-02 09:43:12 --> Loader Class Initialized
INFO - 2023-11-02 09:43:12 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:12 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:12 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:12 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:12 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:12 --> Controller Class Initialized
INFO - 2023-11-02 09:43:12 --> Helper loaded: cookie_helper
INFO - 2023-11-02 09:43:12 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:12 --> Total execution time: 0.0522
INFO - 2023-11-02 09:43:12 --> Config Class Initialized
INFO - 2023-11-02 09:43:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:12 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:12 --> URI Class Initialized
INFO - 2023-11-02 09:43:12 --> Router Class Initialized
INFO - 2023-11-02 09:43:12 --> Output Class Initialized
INFO - 2023-11-02 09:43:12 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:12 --> Input Class Initialized
INFO - 2023-11-02 09:43:12 --> Language Class Initialized
INFO - 2023-11-02 09:43:12 --> Language Class Initialized
INFO - 2023-11-02 09:43:12 --> Config Class Initialized
INFO - 2023-11-02 09:43:12 --> Loader Class Initialized
INFO - 2023-11-02 09:43:12 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:12 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:12 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:12 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:12 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:12 --> Controller Class Initialized
DEBUG - 2023-11-02 09:43:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 09:43:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:43:12 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:12 --> Total execution time: 0.0436
INFO - 2023-11-02 09:43:15 --> Config Class Initialized
INFO - 2023-11-02 09:43:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:15 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:15 --> URI Class Initialized
INFO - 2023-11-02 09:43:15 --> Router Class Initialized
INFO - 2023-11-02 09:43:15 --> Output Class Initialized
INFO - 2023-11-02 09:43:15 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:15 --> Input Class Initialized
INFO - 2023-11-02 09:43:15 --> Language Class Initialized
INFO - 2023-11-02 09:43:15 --> Language Class Initialized
INFO - 2023-11-02 09:43:15 --> Config Class Initialized
INFO - 2023-11-02 09:43:15 --> Loader Class Initialized
INFO - 2023-11-02 09:43:15 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:15 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:15 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:15 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:15 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:15 --> Controller Class Initialized
DEBUG - 2023-11-02 09:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-02 09:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:43:15 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:15 --> Total execution time: 0.1220
INFO - 2023-11-02 09:43:18 --> Config Class Initialized
INFO - 2023-11-02 09:43:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:18 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:18 --> URI Class Initialized
INFO - 2023-11-02 09:43:18 --> Router Class Initialized
INFO - 2023-11-02 09:43:18 --> Output Class Initialized
INFO - 2023-11-02 09:43:18 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:18 --> Input Class Initialized
INFO - 2023-11-02 09:43:18 --> Language Class Initialized
INFO - 2023-11-02 09:43:18 --> Language Class Initialized
INFO - 2023-11-02 09:43:18 --> Config Class Initialized
INFO - 2023-11-02 09:43:18 --> Loader Class Initialized
INFO - 2023-11-02 09:43:18 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:18 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:18 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:18 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:18 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:18 --> Controller Class Initialized
DEBUG - 2023-11-02 09:43:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-02 09:43:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:43:18 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:18 --> Total execution time: 0.0486
INFO - 2023-11-02 09:43:19 --> Config Class Initialized
INFO - 2023-11-02 09:43:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:19 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:19 --> URI Class Initialized
INFO - 2023-11-02 09:43:19 --> Router Class Initialized
INFO - 2023-11-02 09:43:19 --> Output Class Initialized
INFO - 2023-11-02 09:43:19 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:19 --> Input Class Initialized
INFO - 2023-11-02 09:43:19 --> Language Class Initialized
INFO - 2023-11-02 09:43:19 --> Language Class Initialized
INFO - 2023-11-02 09:43:19 --> Config Class Initialized
INFO - 2023-11-02 09:43:19 --> Loader Class Initialized
INFO - 2023-11-02 09:43:19 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:19 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:19 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:19 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:19 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:19 --> Controller Class Initialized
INFO - 2023-11-02 09:43:25 --> Config Class Initialized
INFO - 2023-11-02 09:43:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:25 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:25 --> URI Class Initialized
INFO - 2023-11-02 09:43:25 --> Router Class Initialized
INFO - 2023-11-02 09:43:25 --> Output Class Initialized
INFO - 2023-11-02 09:43:25 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:25 --> Input Class Initialized
INFO - 2023-11-02 09:43:25 --> Language Class Initialized
INFO - 2023-11-02 09:43:25 --> Language Class Initialized
INFO - 2023-11-02 09:43:25 --> Config Class Initialized
INFO - 2023-11-02 09:43:25 --> Loader Class Initialized
INFO - 2023-11-02 09:43:25 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:25 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:25 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:25 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:25 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:25 --> Controller Class Initialized
INFO - 2023-11-02 09:43:25 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:25 --> Total execution time: 0.2007
INFO - 2023-11-02 09:43:35 --> Config Class Initialized
INFO - 2023-11-02 09:43:35 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:35 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:35 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:35 --> URI Class Initialized
INFO - 2023-11-02 09:43:35 --> Router Class Initialized
INFO - 2023-11-02 09:43:35 --> Output Class Initialized
INFO - 2023-11-02 09:43:35 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:35 --> Input Class Initialized
INFO - 2023-11-02 09:43:35 --> Language Class Initialized
INFO - 2023-11-02 09:43:35 --> Language Class Initialized
INFO - 2023-11-02 09:43:35 --> Config Class Initialized
INFO - 2023-11-02 09:43:35 --> Loader Class Initialized
INFO - 2023-11-02 09:43:35 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:35 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:35 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:35 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:35 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:35 --> Controller Class Initialized
INFO - 2023-11-02 09:43:35 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:35 --> Total execution time: 0.2711
INFO - 2023-11-02 09:43:39 --> Config Class Initialized
INFO - 2023-11-02 09:43:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:39 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:39 --> URI Class Initialized
INFO - 2023-11-02 09:43:39 --> Router Class Initialized
INFO - 2023-11-02 09:43:39 --> Output Class Initialized
INFO - 2023-11-02 09:43:39 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:39 --> Input Class Initialized
INFO - 2023-11-02 09:43:39 --> Language Class Initialized
INFO - 2023-11-02 09:43:39 --> Language Class Initialized
INFO - 2023-11-02 09:43:39 --> Config Class Initialized
INFO - 2023-11-02 09:43:39 --> Loader Class Initialized
INFO - 2023-11-02 09:43:39 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:39 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:39 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:39 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:39 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:39 --> Controller Class Initialized
INFO - 2023-11-02 09:43:39 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:39 --> Total execution time: 0.1237
INFO - 2023-11-02 09:43:47 --> Config Class Initialized
INFO - 2023-11-02 09:43:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:47 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:47 --> URI Class Initialized
INFO - 2023-11-02 09:43:47 --> Router Class Initialized
INFO - 2023-11-02 09:43:47 --> Output Class Initialized
INFO - 2023-11-02 09:43:47 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:47 --> Input Class Initialized
INFO - 2023-11-02 09:43:47 --> Language Class Initialized
INFO - 2023-11-02 09:43:47 --> Language Class Initialized
INFO - 2023-11-02 09:43:47 --> Config Class Initialized
INFO - 2023-11-02 09:43:47 --> Loader Class Initialized
INFO - 2023-11-02 09:43:47 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:47 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:47 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:47 --> Helper loaded: my_helper
INFO - 2023-11-02 09:43:47 --> Database Driver Class Initialized
INFO - 2023-11-02 09:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:47 --> Controller Class Initialized
INFO - 2023-11-02 09:43:47 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:47 --> Total execution time: 0.0405
INFO - 2023-11-02 09:44:26 --> Config Class Initialized
INFO - 2023-11-02 09:44:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:44:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:44:26 --> Utf8 Class Initialized
INFO - 2023-11-02 09:44:26 --> URI Class Initialized
INFO - 2023-11-02 09:44:26 --> Router Class Initialized
INFO - 2023-11-02 09:44:26 --> Output Class Initialized
INFO - 2023-11-02 09:44:26 --> Security Class Initialized
DEBUG - 2023-11-02 09:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:44:26 --> Input Class Initialized
INFO - 2023-11-02 09:44:26 --> Language Class Initialized
INFO - 2023-11-02 09:44:26 --> Language Class Initialized
INFO - 2023-11-02 09:44:26 --> Config Class Initialized
INFO - 2023-11-02 09:44:26 --> Loader Class Initialized
INFO - 2023-11-02 09:44:26 --> Helper loaded: url_helper
INFO - 2023-11-02 09:44:26 --> Helper loaded: file_helper
INFO - 2023-11-02 09:44:26 --> Helper loaded: form_helper
INFO - 2023-11-02 09:44:26 --> Helper loaded: my_helper
INFO - 2023-11-02 09:44:26 --> Database Driver Class Initialized
INFO - 2023-11-02 09:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:44:26 --> Controller Class Initialized
INFO - 2023-11-02 09:44:26 --> Final output sent to browser
DEBUG - 2023-11-02 09:44:26 --> Total execution time: 0.0375
INFO - 2023-11-02 09:44:33 --> Config Class Initialized
INFO - 2023-11-02 09:44:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:44:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:44:33 --> Utf8 Class Initialized
INFO - 2023-11-02 09:44:33 --> URI Class Initialized
INFO - 2023-11-02 09:44:33 --> Router Class Initialized
INFO - 2023-11-02 09:44:33 --> Output Class Initialized
INFO - 2023-11-02 09:44:33 --> Security Class Initialized
DEBUG - 2023-11-02 09:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:44:33 --> Input Class Initialized
INFO - 2023-11-02 09:44:33 --> Language Class Initialized
INFO - 2023-11-02 09:44:33 --> Language Class Initialized
INFO - 2023-11-02 09:44:33 --> Config Class Initialized
INFO - 2023-11-02 09:44:33 --> Loader Class Initialized
INFO - 2023-11-02 09:44:33 --> Helper loaded: url_helper
INFO - 2023-11-02 09:44:33 --> Helper loaded: file_helper
INFO - 2023-11-02 09:44:33 --> Helper loaded: form_helper
INFO - 2023-11-02 09:44:33 --> Helper loaded: my_helper
INFO - 2023-11-02 09:44:33 --> Database Driver Class Initialized
INFO - 2023-11-02 09:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:44:33 --> Controller Class Initialized
INFO - 2023-11-02 09:44:33 --> Final output sent to browser
DEBUG - 2023-11-02 09:44:33 --> Total execution time: 0.0826
INFO - 2023-11-02 09:44:40 --> Config Class Initialized
INFO - 2023-11-02 09:44:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:44:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:44:40 --> Utf8 Class Initialized
INFO - 2023-11-02 09:44:40 --> URI Class Initialized
INFO - 2023-11-02 09:44:40 --> Router Class Initialized
INFO - 2023-11-02 09:44:40 --> Output Class Initialized
INFO - 2023-11-02 09:44:40 --> Security Class Initialized
DEBUG - 2023-11-02 09:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:44:40 --> Input Class Initialized
INFO - 2023-11-02 09:44:40 --> Language Class Initialized
INFO - 2023-11-02 09:44:40 --> Language Class Initialized
INFO - 2023-11-02 09:44:40 --> Config Class Initialized
INFO - 2023-11-02 09:44:40 --> Loader Class Initialized
INFO - 2023-11-02 09:44:40 --> Helper loaded: url_helper
INFO - 2023-11-02 09:44:40 --> Helper loaded: file_helper
INFO - 2023-11-02 09:44:40 --> Helper loaded: form_helper
INFO - 2023-11-02 09:44:40 --> Helper loaded: my_helper
INFO - 2023-11-02 09:44:40 --> Database Driver Class Initialized
INFO - 2023-11-02 09:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:44:40 --> Controller Class Initialized
INFO - 2023-11-02 09:44:40 --> Final output sent to browser
DEBUG - 2023-11-02 09:44:40 --> Total execution time: 0.0361
INFO - 2023-11-02 09:47:00 --> Config Class Initialized
INFO - 2023-11-02 09:47:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:00 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:00 --> URI Class Initialized
INFO - 2023-11-02 09:47:00 --> Router Class Initialized
INFO - 2023-11-02 09:47:00 --> Output Class Initialized
INFO - 2023-11-02 09:47:00 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:00 --> Input Class Initialized
INFO - 2023-11-02 09:47:00 --> Language Class Initialized
INFO - 2023-11-02 09:47:00 --> Language Class Initialized
INFO - 2023-11-02 09:47:00 --> Config Class Initialized
INFO - 2023-11-02 09:47:00 --> Loader Class Initialized
INFO - 2023-11-02 09:47:00 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:00 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:00 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:00 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:00 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:00 --> Controller Class Initialized
INFO - 2023-11-02 09:47:01 --> Final output sent to browser
DEBUG - 2023-11-02 09:47:01 --> Total execution time: 0.1811
INFO - 2023-11-02 09:47:05 --> Config Class Initialized
INFO - 2023-11-02 09:47:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:05 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:05 --> URI Class Initialized
DEBUG - 2023-11-02 09:47:05 --> No URI present. Default controller set.
INFO - 2023-11-02 09:47:05 --> Router Class Initialized
INFO - 2023-11-02 09:47:05 --> Output Class Initialized
INFO - 2023-11-02 09:47:05 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:05 --> Input Class Initialized
INFO - 2023-11-02 09:47:05 --> Language Class Initialized
INFO - 2023-11-02 09:47:05 --> Language Class Initialized
INFO - 2023-11-02 09:47:05 --> Config Class Initialized
INFO - 2023-11-02 09:47:05 --> Loader Class Initialized
INFO - 2023-11-02 09:47:05 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:05 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:05 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:05 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:05 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:05 --> Controller Class Initialized
DEBUG - 2023-11-02 09:47:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 09:47:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:47:05 --> Final output sent to browser
DEBUG - 2023-11-02 09:47:05 --> Total execution time: 0.0482
INFO - 2023-11-02 09:47:07 --> Config Class Initialized
INFO - 2023-11-02 09:47:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:07 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:07 --> URI Class Initialized
INFO - 2023-11-02 09:47:07 --> Router Class Initialized
INFO - 2023-11-02 09:47:07 --> Output Class Initialized
INFO - 2023-11-02 09:47:07 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:07 --> Input Class Initialized
INFO - 2023-11-02 09:47:07 --> Language Class Initialized
INFO - 2023-11-02 09:47:07 --> Language Class Initialized
INFO - 2023-11-02 09:47:07 --> Config Class Initialized
INFO - 2023-11-02 09:47:07 --> Loader Class Initialized
INFO - 2023-11-02 09:47:07 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:07 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:07 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:07 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:07 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:07 --> Controller Class Initialized
DEBUG - 2023-11-02 09:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-02 09:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:47:07 --> Final output sent to browser
DEBUG - 2023-11-02 09:47:07 --> Total execution time: 0.1083
INFO - 2023-11-02 09:47:09 --> Config Class Initialized
INFO - 2023-11-02 09:47:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:09 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:09 --> URI Class Initialized
INFO - 2023-11-02 09:47:09 --> Router Class Initialized
INFO - 2023-11-02 09:47:09 --> Output Class Initialized
INFO - 2023-11-02 09:47:09 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:09 --> Input Class Initialized
INFO - 2023-11-02 09:47:09 --> Language Class Initialized
INFO - 2023-11-02 09:47:09 --> Language Class Initialized
INFO - 2023-11-02 09:47:09 --> Config Class Initialized
INFO - 2023-11-02 09:47:09 --> Loader Class Initialized
INFO - 2023-11-02 09:47:09 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:09 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:09 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:09 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:09 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:09 --> Controller Class Initialized
DEBUG - 2023-11-02 09:47:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-02 09:47:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:47:09 --> Final output sent to browser
DEBUG - 2023-11-02 09:47:09 --> Total execution time: 0.0464
INFO - 2023-11-02 09:47:09 --> Config Class Initialized
INFO - 2023-11-02 09:47:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:09 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:09 --> URI Class Initialized
INFO - 2023-11-02 09:47:09 --> Router Class Initialized
INFO - 2023-11-02 09:47:09 --> Output Class Initialized
INFO - 2023-11-02 09:47:09 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:09 --> Input Class Initialized
INFO - 2023-11-02 09:47:09 --> Language Class Initialized
INFO - 2023-11-02 09:47:09 --> Language Class Initialized
INFO - 2023-11-02 09:47:09 --> Config Class Initialized
INFO - 2023-11-02 09:47:09 --> Loader Class Initialized
INFO - 2023-11-02 09:47:09 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:09 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:09 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:09 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:09 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:09 --> Controller Class Initialized
INFO - 2023-11-02 09:47:12 --> Config Class Initialized
INFO - 2023-11-02 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:12 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:12 --> URI Class Initialized
INFO - 2023-11-02 09:47:12 --> Router Class Initialized
INFO - 2023-11-02 09:47:12 --> Output Class Initialized
INFO - 2023-11-02 09:47:12 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:12 --> Input Class Initialized
INFO - 2023-11-02 09:47:12 --> Language Class Initialized
INFO - 2023-11-02 09:47:12 --> Language Class Initialized
INFO - 2023-11-02 09:47:12 --> Config Class Initialized
INFO - 2023-11-02 09:47:12 --> Loader Class Initialized
INFO - 2023-11-02 09:47:12 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:12 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:12 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:12 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:12 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:12 --> Controller Class Initialized
INFO - 2023-11-02 09:47:12 --> Final output sent to browser
DEBUG - 2023-11-02 09:47:12 --> Total execution time: 0.0421
INFO - 2023-11-02 09:47:26 --> Config Class Initialized
INFO - 2023-11-02 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:47:26 --> Utf8 Class Initialized
INFO - 2023-11-02 09:47:26 --> URI Class Initialized
INFO - 2023-11-02 09:47:26 --> Router Class Initialized
INFO - 2023-11-02 09:47:26 --> Output Class Initialized
INFO - 2023-11-02 09:47:26 --> Security Class Initialized
DEBUG - 2023-11-02 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:47:26 --> Input Class Initialized
INFO - 2023-11-02 09:47:26 --> Language Class Initialized
INFO - 2023-11-02 09:47:26 --> Language Class Initialized
INFO - 2023-11-02 09:47:26 --> Config Class Initialized
INFO - 2023-11-02 09:47:26 --> Loader Class Initialized
INFO - 2023-11-02 09:47:26 --> Helper loaded: url_helper
INFO - 2023-11-02 09:47:26 --> Helper loaded: file_helper
INFO - 2023-11-02 09:47:26 --> Helper loaded: form_helper
INFO - 2023-11-02 09:47:26 --> Helper loaded: my_helper
INFO - 2023-11-02 09:47:26 --> Database Driver Class Initialized
INFO - 2023-11-02 09:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:47:26 --> Controller Class Initialized
INFO - 2023-11-02 09:47:26 --> Final output sent to browser
DEBUG - 2023-11-02 09:47:26 --> Total execution time: 0.0382
INFO - 2023-11-02 09:48:19 --> Config Class Initialized
INFO - 2023-11-02 09:48:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:19 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:19 --> URI Class Initialized
INFO - 2023-11-02 09:48:19 --> Router Class Initialized
INFO - 2023-11-02 09:48:19 --> Output Class Initialized
INFO - 2023-11-02 09:48:19 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:19 --> Input Class Initialized
INFO - 2023-11-02 09:48:19 --> Language Class Initialized
INFO - 2023-11-02 09:48:19 --> Language Class Initialized
INFO - 2023-11-02 09:48:19 --> Config Class Initialized
INFO - 2023-11-02 09:48:19 --> Loader Class Initialized
INFO - 2023-11-02 09:48:19 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:19 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:19 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:19 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:19 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:19 --> Controller Class Initialized
INFO - 2023-11-02 09:48:19 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:19 --> Total execution time: 0.0857
INFO - 2023-11-02 09:48:20 --> Config Class Initialized
INFO - 2023-11-02 09:48:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:20 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:20 --> URI Class Initialized
INFO - 2023-11-02 09:48:20 --> Router Class Initialized
INFO - 2023-11-02 09:48:20 --> Output Class Initialized
INFO - 2023-11-02 09:48:20 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:20 --> Input Class Initialized
INFO - 2023-11-02 09:48:20 --> Language Class Initialized
INFO - 2023-11-02 09:48:20 --> Language Class Initialized
INFO - 2023-11-02 09:48:20 --> Config Class Initialized
INFO - 2023-11-02 09:48:20 --> Loader Class Initialized
INFO - 2023-11-02 09:48:20 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:20 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:20 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:20 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:20 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:20 --> Controller Class Initialized
DEBUG - 2023-11-02 09:48:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-02 09:48:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:48:20 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:20 --> Total execution time: 0.0341
INFO - 2023-11-02 09:48:22 --> Config Class Initialized
INFO - 2023-11-02 09:48:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:22 --> URI Class Initialized
INFO - 2023-11-02 09:48:22 --> Router Class Initialized
INFO - 2023-11-02 09:48:22 --> Output Class Initialized
INFO - 2023-11-02 09:48:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:22 --> Input Class Initialized
INFO - 2023-11-02 09:48:22 --> Language Class Initialized
INFO - 2023-11-02 09:48:22 --> Language Class Initialized
INFO - 2023-11-02 09:48:22 --> Config Class Initialized
INFO - 2023-11-02 09:48:22 --> Loader Class Initialized
INFO - 2023-11-02 09:48:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:22 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:22 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:22 --> Controller Class Initialized
DEBUG - 2023-11-02 09:48:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-02 09:48:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:48:22 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:22 --> Total execution time: 0.0416
INFO - 2023-11-02 09:48:22 --> Config Class Initialized
INFO - 2023-11-02 09:48:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:22 --> URI Class Initialized
INFO - 2023-11-02 09:48:22 --> Router Class Initialized
INFO - 2023-11-02 09:48:22 --> Output Class Initialized
INFO - 2023-11-02 09:48:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:22 --> Input Class Initialized
INFO - 2023-11-02 09:48:22 --> Language Class Initialized
INFO - 2023-11-02 09:48:22 --> Language Class Initialized
INFO - 2023-11-02 09:48:22 --> Config Class Initialized
INFO - 2023-11-02 09:48:22 --> Loader Class Initialized
INFO - 2023-11-02 09:48:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:22 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:22 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:22 --> Controller Class Initialized
INFO - 2023-11-02 09:48:26 --> Config Class Initialized
INFO - 2023-11-02 09:48:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:26 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:26 --> URI Class Initialized
INFO - 2023-11-02 09:48:26 --> Router Class Initialized
INFO - 2023-11-02 09:48:26 --> Output Class Initialized
INFO - 2023-11-02 09:48:26 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:26 --> Input Class Initialized
INFO - 2023-11-02 09:48:26 --> Language Class Initialized
INFO - 2023-11-02 09:48:26 --> Language Class Initialized
INFO - 2023-11-02 09:48:26 --> Config Class Initialized
INFO - 2023-11-02 09:48:26 --> Loader Class Initialized
INFO - 2023-11-02 09:48:26 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:26 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:26 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:26 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:26 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:26 --> Controller Class Initialized
INFO - 2023-11-02 09:48:26 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:26 --> Total execution time: 0.0418
INFO - 2023-11-02 09:48:34 --> Config Class Initialized
INFO - 2023-11-02 09:48:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:34 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:34 --> URI Class Initialized
INFO - 2023-11-02 09:48:34 --> Router Class Initialized
INFO - 2023-11-02 09:48:34 --> Output Class Initialized
INFO - 2023-11-02 09:48:34 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:34 --> Input Class Initialized
INFO - 2023-11-02 09:48:34 --> Language Class Initialized
INFO - 2023-11-02 09:48:34 --> Language Class Initialized
INFO - 2023-11-02 09:48:34 --> Config Class Initialized
INFO - 2023-11-02 09:48:34 --> Loader Class Initialized
INFO - 2023-11-02 09:48:34 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:34 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:34 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:34 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:34 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:34 --> Controller Class Initialized
INFO - 2023-11-02 09:48:34 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:34 --> Total execution time: 0.0941
INFO - 2023-11-02 09:48:41 --> Config Class Initialized
INFO - 2023-11-02 09:48:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:41 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:41 --> URI Class Initialized
INFO - 2023-11-02 09:48:41 --> Router Class Initialized
INFO - 2023-11-02 09:48:41 --> Output Class Initialized
INFO - 2023-11-02 09:48:41 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:41 --> Input Class Initialized
INFO - 2023-11-02 09:48:41 --> Language Class Initialized
INFO - 2023-11-02 09:48:41 --> Language Class Initialized
INFO - 2023-11-02 09:48:41 --> Config Class Initialized
INFO - 2023-11-02 09:48:41 --> Loader Class Initialized
INFO - 2023-11-02 09:48:41 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:41 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:41 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:41 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:41 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:41 --> Controller Class Initialized
INFO - 2023-11-02 09:48:41 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:41 --> Total execution time: 0.0430
INFO - 2023-11-02 09:48:44 --> Config Class Initialized
INFO - 2023-11-02 09:48:44 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:48:44 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:48:44 --> Utf8 Class Initialized
INFO - 2023-11-02 09:48:44 --> URI Class Initialized
INFO - 2023-11-02 09:48:44 --> Router Class Initialized
INFO - 2023-11-02 09:48:44 --> Output Class Initialized
INFO - 2023-11-02 09:48:44 --> Security Class Initialized
DEBUG - 2023-11-02 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:48:44 --> Input Class Initialized
INFO - 2023-11-02 09:48:44 --> Language Class Initialized
INFO - 2023-11-02 09:48:44 --> Language Class Initialized
INFO - 2023-11-02 09:48:44 --> Config Class Initialized
INFO - 2023-11-02 09:48:44 --> Loader Class Initialized
INFO - 2023-11-02 09:48:44 --> Helper loaded: url_helper
INFO - 2023-11-02 09:48:44 --> Helper loaded: file_helper
INFO - 2023-11-02 09:48:44 --> Helper loaded: form_helper
INFO - 2023-11-02 09:48:44 --> Helper loaded: my_helper
INFO - 2023-11-02 09:48:44 --> Database Driver Class Initialized
INFO - 2023-11-02 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:48:44 --> Controller Class Initialized
INFO - 2023-11-02 09:48:44 --> Final output sent to browser
DEBUG - 2023-11-02 09:48:44 --> Total execution time: 0.0348
INFO - 2023-11-02 09:49:05 --> Config Class Initialized
INFO - 2023-11-02 09:49:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:49:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:49:05 --> Utf8 Class Initialized
INFO - 2023-11-02 09:49:05 --> URI Class Initialized
INFO - 2023-11-02 09:49:05 --> Router Class Initialized
INFO - 2023-11-02 09:49:05 --> Output Class Initialized
INFO - 2023-11-02 09:49:05 --> Security Class Initialized
DEBUG - 2023-11-02 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:49:05 --> Input Class Initialized
INFO - 2023-11-02 09:49:05 --> Language Class Initialized
INFO - 2023-11-02 09:49:05 --> Language Class Initialized
INFO - 2023-11-02 09:49:05 --> Config Class Initialized
INFO - 2023-11-02 09:49:05 --> Loader Class Initialized
INFO - 2023-11-02 09:49:05 --> Helper loaded: url_helper
INFO - 2023-11-02 09:49:05 --> Helper loaded: file_helper
INFO - 2023-11-02 09:49:05 --> Helper loaded: form_helper
INFO - 2023-11-02 09:49:05 --> Helper loaded: my_helper
INFO - 2023-11-02 09:49:06 --> Database Driver Class Initialized
INFO - 2023-11-02 09:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:49:06 --> Controller Class Initialized
INFO - 2023-11-02 09:49:06 --> Final output sent to browser
DEBUG - 2023-11-02 09:49:06 --> Total execution time: 0.0394
INFO - 2023-11-02 09:49:29 --> Config Class Initialized
INFO - 2023-11-02 09:49:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:49:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:49:29 --> Utf8 Class Initialized
INFO - 2023-11-02 09:49:29 --> URI Class Initialized
INFO - 2023-11-02 09:49:29 --> Router Class Initialized
INFO - 2023-11-02 09:49:29 --> Output Class Initialized
INFO - 2023-11-02 09:49:29 --> Security Class Initialized
DEBUG - 2023-11-02 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:49:29 --> Input Class Initialized
INFO - 2023-11-02 09:49:29 --> Language Class Initialized
INFO - 2023-11-02 09:49:29 --> Language Class Initialized
INFO - 2023-11-02 09:49:29 --> Config Class Initialized
INFO - 2023-11-02 09:49:29 --> Loader Class Initialized
INFO - 2023-11-02 09:49:29 --> Helper loaded: url_helper
INFO - 2023-11-02 09:49:29 --> Helper loaded: file_helper
INFO - 2023-11-02 09:49:29 --> Helper loaded: form_helper
INFO - 2023-11-02 09:49:29 --> Helper loaded: my_helper
INFO - 2023-11-02 09:49:29 --> Database Driver Class Initialized
INFO - 2023-11-02 09:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:49:29 --> Controller Class Initialized
INFO - 2023-11-02 09:49:29 --> Final output sent to browser
DEBUG - 2023-11-02 09:49:29 --> Total execution time: 0.0787
INFO - 2023-11-02 09:50:10 --> Config Class Initialized
INFO - 2023-11-02 09:50:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:50:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:50:10 --> Utf8 Class Initialized
INFO - 2023-11-02 09:50:10 --> URI Class Initialized
INFO - 2023-11-02 09:50:10 --> Router Class Initialized
INFO - 2023-11-02 09:50:10 --> Output Class Initialized
INFO - 2023-11-02 09:50:10 --> Security Class Initialized
DEBUG - 2023-11-02 09:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:50:10 --> Input Class Initialized
INFO - 2023-11-02 09:50:10 --> Language Class Initialized
INFO - 2023-11-02 09:50:10 --> Language Class Initialized
INFO - 2023-11-02 09:50:10 --> Config Class Initialized
INFO - 2023-11-02 09:50:10 --> Loader Class Initialized
INFO - 2023-11-02 09:50:10 --> Helper loaded: url_helper
INFO - 2023-11-02 09:50:10 --> Helper loaded: file_helper
INFO - 2023-11-02 09:50:10 --> Helper loaded: form_helper
INFO - 2023-11-02 09:50:10 --> Helper loaded: my_helper
INFO - 2023-11-02 09:50:10 --> Database Driver Class Initialized
INFO - 2023-11-02 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:50:10 --> Controller Class Initialized
INFO - 2023-11-02 09:50:10 --> Final output sent to browser
DEBUG - 2023-11-02 09:50:10 --> Total execution time: 0.0619
INFO - 2023-11-02 09:50:13 --> Config Class Initialized
INFO - 2023-11-02 09:50:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:50:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:50:13 --> Utf8 Class Initialized
INFO - 2023-11-02 09:50:13 --> URI Class Initialized
INFO - 2023-11-02 09:50:13 --> Router Class Initialized
INFO - 2023-11-02 09:50:13 --> Output Class Initialized
INFO - 2023-11-02 09:50:13 --> Security Class Initialized
DEBUG - 2023-11-02 09:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:50:13 --> Input Class Initialized
INFO - 2023-11-02 09:50:13 --> Language Class Initialized
INFO - 2023-11-02 09:50:13 --> Language Class Initialized
INFO - 2023-11-02 09:50:13 --> Config Class Initialized
INFO - 2023-11-02 09:50:13 --> Loader Class Initialized
INFO - 2023-11-02 09:50:13 --> Helper loaded: url_helper
INFO - 2023-11-02 09:50:13 --> Helper loaded: file_helper
INFO - 2023-11-02 09:50:13 --> Helper loaded: form_helper
INFO - 2023-11-02 09:50:13 --> Helper loaded: my_helper
INFO - 2023-11-02 09:50:13 --> Database Driver Class Initialized
INFO - 2023-11-02 09:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:50:13 --> Controller Class Initialized
INFO - 2023-11-02 09:50:13 --> Final output sent to browser
DEBUG - 2023-11-02 09:50:13 --> Total execution time: 0.0404
INFO - 2023-11-02 09:50:34 --> Config Class Initialized
INFO - 2023-11-02 09:50:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:50:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:50:34 --> Utf8 Class Initialized
INFO - 2023-11-02 09:50:34 --> URI Class Initialized
INFO - 2023-11-02 09:50:34 --> Router Class Initialized
INFO - 2023-11-02 09:50:34 --> Output Class Initialized
INFO - 2023-11-02 09:50:34 --> Security Class Initialized
DEBUG - 2023-11-02 09:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:50:34 --> Input Class Initialized
INFO - 2023-11-02 09:50:34 --> Language Class Initialized
INFO - 2023-11-02 09:50:34 --> Language Class Initialized
INFO - 2023-11-02 09:50:34 --> Config Class Initialized
INFO - 2023-11-02 09:50:34 --> Loader Class Initialized
INFO - 2023-11-02 09:50:34 --> Helper loaded: url_helper
INFO - 2023-11-02 09:50:34 --> Helper loaded: file_helper
INFO - 2023-11-02 09:50:34 --> Helper loaded: form_helper
INFO - 2023-11-02 09:50:34 --> Helper loaded: my_helper
INFO - 2023-11-02 09:50:34 --> Database Driver Class Initialized
INFO - 2023-11-02 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:50:34 --> Controller Class Initialized
INFO - 2023-11-02 09:50:34 --> Final output sent to browser
DEBUG - 2023-11-02 09:50:34 --> Total execution time: 0.0372
INFO - 2023-11-02 09:51:35 --> Config Class Initialized
INFO - 2023-11-02 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:35 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:35 --> URI Class Initialized
INFO - 2023-11-02 09:51:35 --> Router Class Initialized
INFO - 2023-11-02 09:51:35 --> Output Class Initialized
INFO - 2023-11-02 09:51:35 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:35 --> Input Class Initialized
INFO - 2023-11-02 09:51:35 --> Language Class Initialized
INFO - 2023-11-02 09:51:35 --> Language Class Initialized
INFO - 2023-11-02 09:51:35 --> Config Class Initialized
INFO - 2023-11-02 09:51:35 --> Loader Class Initialized
INFO - 2023-11-02 09:51:35 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:35 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:35 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:35 --> Helper loaded: my_helper
INFO - 2023-11-02 09:51:35 --> Database Driver Class Initialized
INFO - 2023-11-02 09:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:35 --> Controller Class Initialized
INFO - 2023-11-02 09:51:35 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:35 --> Total execution time: 0.0869
INFO - 2023-11-02 09:59:12 --> Config Class Initialized
INFO - 2023-11-02 09:59:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:12 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:12 --> URI Class Initialized
INFO - 2023-11-02 09:59:12 --> Router Class Initialized
INFO - 2023-11-02 09:59:12 --> Output Class Initialized
INFO - 2023-11-02 09:59:13 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:13 --> Input Class Initialized
INFO - 2023-11-02 09:59:13 --> Language Class Initialized
INFO - 2023-11-02 09:59:13 --> Language Class Initialized
INFO - 2023-11-02 09:59:13 --> Config Class Initialized
INFO - 2023-11-02 09:59:13 --> Loader Class Initialized
INFO - 2023-11-02 09:59:13 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:13 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:13 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:13 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:13 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:13 --> Controller Class Initialized
DEBUG - 2023-11-02 09:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 09:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:59:13 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:13 --> Total execution time: 0.0587
INFO - 2023-11-02 09:59:14 --> Config Class Initialized
INFO - 2023-11-02 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:14 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:14 --> URI Class Initialized
INFO - 2023-11-02 09:59:14 --> Router Class Initialized
INFO - 2023-11-02 09:59:14 --> Output Class Initialized
INFO - 2023-11-02 09:59:14 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:14 --> Input Class Initialized
INFO - 2023-11-02 09:59:14 --> Language Class Initialized
INFO - 2023-11-02 09:59:15 --> Language Class Initialized
INFO - 2023-11-02 09:59:15 --> Config Class Initialized
INFO - 2023-11-02 09:59:15 --> Loader Class Initialized
INFO - 2023-11-02 09:59:15 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:15 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:15 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:15 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:15 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:15 --> Controller Class Initialized
INFO - 2023-11-02 09:59:15 --> Helper loaded: cookie_helper
INFO - 2023-11-02 09:59:15 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:15 --> Total execution time: 0.1828
INFO - 2023-11-02 09:59:15 --> Config Class Initialized
INFO - 2023-11-02 09:59:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:15 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:15 --> URI Class Initialized
INFO - 2023-11-02 09:59:15 --> Router Class Initialized
INFO - 2023-11-02 09:59:15 --> Output Class Initialized
INFO - 2023-11-02 09:59:15 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:15 --> Input Class Initialized
INFO - 2023-11-02 09:59:15 --> Language Class Initialized
INFO - 2023-11-02 09:59:15 --> Language Class Initialized
INFO - 2023-11-02 09:59:15 --> Config Class Initialized
INFO - 2023-11-02 09:59:15 --> Loader Class Initialized
INFO - 2023-11-02 09:59:15 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:15 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:15 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:15 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:15 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:15 --> Controller Class Initialized
DEBUG - 2023-11-02 09:59:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 09:59:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:59:15 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:15 --> Total execution time: 0.1346
INFO - 2023-11-02 09:59:19 --> Config Class Initialized
INFO - 2023-11-02 09:59:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:19 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:19 --> URI Class Initialized
INFO - 2023-11-02 09:59:19 --> Router Class Initialized
INFO - 2023-11-02 09:59:19 --> Output Class Initialized
INFO - 2023-11-02 09:59:19 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:19 --> Input Class Initialized
INFO - 2023-11-02 09:59:19 --> Language Class Initialized
INFO - 2023-11-02 09:59:19 --> Language Class Initialized
INFO - 2023-11-02 09:59:19 --> Config Class Initialized
INFO - 2023-11-02 09:59:19 --> Loader Class Initialized
INFO - 2023-11-02 09:59:19 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:19 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:19 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:19 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:19 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:19 --> Controller Class Initialized
DEBUG - 2023-11-02 09:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-02 09:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 09:59:19 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:19 --> Total execution time: 0.0521
INFO - 2023-11-02 09:59:21 --> Config Class Initialized
INFO - 2023-11-02 09:59:21 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:21 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:21 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:21 --> URI Class Initialized
INFO - 2023-11-02 09:59:21 --> Router Class Initialized
INFO - 2023-11-02 09:59:21 --> Output Class Initialized
INFO - 2023-11-02 09:59:21 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:21 --> Input Class Initialized
INFO - 2023-11-02 09:59:21 --> Language Class Initialized
INFO - 2023-11-02 09:59:21 --> Language Class Initialized
INFO - 2023-11-02 09:59:21 --> Config Class Initialized
INFO - 2023-11-02 09:59:21 --> Loader Class Initialized
INFO - 2023-11-02 09:59:21 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:21 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:21 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:21 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:21 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:21 --> Controller Class Initialized
DEBUG - 2023-11-02 09:59:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul2.php
INFO - 2023-11-02 09:59:21 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:21 --> Total execution time: 0.0867
INFO - 2023-11-02 09:59:33 --> Config Class Initialized
INFO - 2023-11-02 09:59:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:33 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:33 --> URI Class Initialized
INFO - 2023-11-02 09:59:33 --> Router Class Initialized
INFO - 2023-11-02 09:59:33 --> Output Class Initialized
INFO - 2023-11-02 09:59:33 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:33 --> Input Class Initialized
INFO - 2023-11-02 09:59:33 --> Language Class Initialized
INFO - 2023-11-02 09:59:33 --> Language Class Initialized
INFO - 2023-11-02 09:59:33 --> Config Class Initialized
INFO - 2023-11-02 09:59:33 --> Loader Class Initialized
INFO - 2023-11-02 09:59:33 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:33 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:33 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:33 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:33 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:33 --> Controller Class Initialized
DEBUG - 2023-11-02 09:59:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul4.php
INFO - 2023-11-02 09:59:33 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:33 --> Total execution time: 0.0432
INFO - 2023-11-02 09:59:43 --> Config Class Initialized
INFO - 2023-11-02 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:43 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:43 --> URI Class Initialized
INFO - 2023-11-02 09:59:43 --> Router Class Initialized
INFO - 2023-11-02 09:59:43 --> Output Class Initialized
INFO - 2023-11-02 09:59:43 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:43 --> Input Class Initialized
INFO - 2023-11-02 09:59:43 --> Language Class Initialized
INFO - 2023-11-02 09:59:43 --> Language Class Initialized
INFO - 2023-11-02 09:59:43 --> Config Class Initialized
INFO - 2023-11-02 09:59:43 --> Loader Class Initialized
INFO - 2023-11-02 09:59:43 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:43 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:43 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:43 --> Helper loaded: my_helper
INFO - 2023-11-02 09:59:43 --> Database Driver Class Initialized
INFO - 2023-11-02 09:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:43 --> Controller Class Initialized
DEBUG - 2023-11-02 09:59:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-11-02 09:59:43 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:43 --> Total execution time: 0.0573
INFO - 2023-11-02 10:41:43 --> Config Class Initialized
INFO - 2023-11-02 10:41:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:41:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:41:43 --> Utf8 Class Initialized
INFO - 2023-11-02 10:41:43 --> URI Class Initialized
INFO - 2023-11-02 10:41:43 --> Router Class Initialized
INFO - 2023-11-02 10:41:43 --> Output Class Initialized
INFO - 2023-11-02 10:41:43 --> Security Class Initialized
DEBUG - 2023-11-02 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:41:43 --> Input Class Initialized
INFO - 2023-11-02 10:41:43 --> Language Class Initialized
INFO - 2023-11-02 10:41:43 --> Language Class Initialized
INFO - 2023-11-02 10:41:43 --> Config Class Initialized
INFO - 2023-11-02 10:41:43 --> Loader Class Initialized
INFO - 2023-11-02 10:41:43 --> Helper loaded: url_helper
INFO - 2023-11-02 10:41:43 --> Helper loaded: file_helper
INFO - 2023-11-02 10:41:43 --> Helper loaded: form_helper
INFO - 2023-11-02 10:41:43 --> Helper loaded: my_helper
INFO - 2023-11-02 10:41:43 --> Database Driver Class Initialized
INFO - 2023-11-02 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:41:43 --> Controller Class Initialized
DEBUG - 2023-11-02 10:41:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 10:41:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:41:43 --> Final output sent to browser
DEBUG - 2023-11-02 10:41:43 --> Total execution time: 0.1803
INFO - 2023-11-02 10:41:46 --> Config Class Initialized
INFO - 2023-11-02 10:41:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:41:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:41:46 --> Utf8 Class Initialized
INFO - 2023-11-02 10:41:46 --> URI Class Initialized
INFO - 2023-11-02 10:41:46 --> Router Class Initialized
INFO - 2023-11-02 10:41:46 --> Output Class Initialized
INFO - 2023-11-02 10:41:46 --> Security Class Initialized
DEBUG - 2023-11-02 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:41:46 --> Input Class Initialized
INFO - 2023-11-02 10:41:46 --> Language Class Initialized
INFO - 2023-11-02 10:41:46 --> Language Class Initialized
INFO - 2023-11-02 10:41:46 --> Config Class Initialized
INFO - 2023-11-02 10:41:46 --> Loader Class Initialized
INFO - 2023-11-02 10:41:46 --> Helper loaded: url_helper
INFO - 2023-11-02 10:41:46 --> Helper loaded: file_helper
INFO - 2023-11-02 10:41:46 --> Helper loaded: form_helper
INFO - 2023-11-02 10:41:46 --> Helper loaded: my_helper
INFO - 2023-11-02 10:41:46 --> Database Driver Class Initialized
INFO - 2023-11-02 10:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:41:46 --> Controller Class Initialized
INFO - 2023-11-02 10:41:46 --> Helper loaded: cookie_helper
INFO - 2023-11-02 10:41:46 --> Final output sent to browser
DEBUG - 2023-11-02 10:41:46 --> Total execution time: 0.0424
INFO - 2023-11-02 10:41:46 --> Config Class Initialized
INFO - 2023-11-02 10:41:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:41:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:41:46 --> Utf8 Class Initialized
INFO - 2023-11-02 10:41:46 --> URI Class Initialized
INFO - 2023-11-02 10:41:46 --> Router Class Initialized
INFO - 2023-11-02 10:41:46 --> Output Class Initialized
INFO - 2023-11-02 10:41:46 --> Security Class Initialized
DEBUG - 2023-11-02 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:41:46 --> Input Class Initialized
INFO - 2023-11-02 10:41:46 --> Language Class Initialized
INFO - 2023-11-02 10:41:46 --> Language Class Initialized
INFO - 2023-11-02 10:41:46 --> Config Class Initialized
INFO - 2023-11-02 10:41:46 --> Loader Class Initialized
INFO - 2023-11-02 10:41:46 --> Helper loaded: url_helper
INFO - 2023-11-02 10:41:46 --> Helper loaded: file_helper
INFO - 2023-11-02 10:41:46 --> Helper loaded: form_helper
INFO - 2023-11-02 10:41:46 --> Helper loaded: my_helper
INFO - 2023-11-02 10:41:46 --> Database Driver Class Initialized
INFO - 2023-11-02 10:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:41:46 --> Controller Class Initialized
DEBUG - 2023-11-02 10:41:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 10:41:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:41:46 --> Final output sent to browser
DEBUG - 2023-11-02 10:41:46 --> Total execution time: 0.0353
INFO - 2023-11-02 10:41:50 --> Config Class Initialized
INFO - 2023-11-02 10:41:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:41:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:41:50 --> Utf8 Class Initialized
INFO - 2023-11-02 10:41:50 --> URI Class Initialized
INFO - 2023-11-02 10:41:50 --> Router Class Initialized
INFO - 2023-11-02 10:41:50 --> Output Class Initialized
INFO - 2023-11-02 10:41:50 --> Security Class Initialized
DEBUG - 2023-11-02 10:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:41:50 --> Input Class Initialized
INFO - 2023-11-02 10:41:50 --> Language Class Initialized
INFO - 2023-11-02 10:41:50 --> Language Class Initialized
INFO - 2023-11-02 10:41:50 --> Config Class Initialized
INFO - 2023-11-02 10:41:50 --> Loader Class Initialized
INFO - 2023-11-02 10:41:50 --> Helper loaded: url_helper
INFO - 2023-11-02 10:41:50 --> Helper loaded: file_helper
INFO - 2023-11-02 10:41:50 --> Helper loaded: form_helper
INFO - 2023-11-02 10:41:50 --> Helper loaded: my_helper
INFO - 2023-11-02 10:41:50 --> Database Driver Class Initialized
INFO - 2023-11-02 10:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:41:50 --> Controller Class Initialized
DEBUG - 2023-11-02 10:41:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-02 10:41:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:41:50 --> Final output sent to browser
DEBUG - 2023-11-02 10:41:50 --> Total execution time: 0.0444
INFO - 2023-11-02 10:41:52 --> Config Class Initialized
INFO - 2023-11-02 10:41:52 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:41:52 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:41:52 --> Utf8 Class Initialized
INFO - 2023-11-02 10:41:52 --> URI Class Initialized
INFO - 2023-11-02 10:41:52 --> Router Class Initialized
INFO - 2023-11-02 10:41:52 --> Output Class Initialized
INFO - 2023-11-02 10:41:52 --> Security Class Initialized
DEBUG - 2023-11-02 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:41:52 --> Input Class Initialized
INFO - 2023-11-02 10:41:52 --> Language Class Initialized
INFO - 2023-11-02 10:41:52 --> Language Class Initialized
INFO - 2023-11-02 10:41:52 --> Config Class Initialized
INFO - 2023-11-02 10:41:52 --> Loader Class Initialized
INFO - 2023-11-02 10:41:52 --> Helper loaded: url_helper
INFO - 2023-11-02 10:41:52 --> Helper loaded: file_helper
INFO - 2023-11-02 10:41:52 --> Helper loaded: form_helper
INFO - 2023-11-02 10:41:52 --> Helper loaded: my_helper
INFO - 2023-11-02 10:41:52 --> Database Driver Class Initialized
INFO - 2023-11-02 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:41:52 --> Controller Class Initialized
DEBUG - 2023-11-02 10:41:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-11-02 10:41:52 --> Final output sent to browser
DEBUG - 2023-11-02 10:41:52 --> Total execution time: 0.0385
INFO - 2023-11-02 10:57:38 --> Config Class Initialized
INFO - 2023-11-02 10:57:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:38 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:38 --> URI Class Initialized
INFO - 2023-11-02 10:57:38 --> Router Class Initialized
INFO - 2023-11-02 10:57:38 --> Output Class Initialized
INFO - 2023-11-02 10:57:38 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:38 --> Input Class Initialized
INFO - 2023-11-02 10:57:38 --> Language Class Initialized
INFO - 2023-11-02 10:57:38 --> Language Class Initialized
INFO - 2023-11-02 10:57:38 --> Config Class Initialized
INFO - 2023-11-02 10:57:38 --> Loader Class Initialized
INFO - 2023-11-02 10:57:38 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:38 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:38 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:38 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:38 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:38 --> Controller Class Initialized
INFO - 2023-11-02 10:57:39 --> Config Class Initialized
INFO - 2023-11-02 10:57:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:39 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:39 --> URI Class Initialized
INFO - 2023-11-02 10:57:39 --> Router Class Initialized
INFO - 2023-11-02 10:57:39 --> Output Class Initialized
INFO - 2023-11-02 10:57:39 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:39 --> Input Class Initialized
INFO - 2023-11-02 10:57:39 --> Language Class Initialized
INFO - 2023-11-02 10:57:39 --> Language Class Initialized
INFO - 2023-11-02 10:57:39 --> Config Class Initialized
INFO - 2023-11-02 10:57:39 --> Loader Class Initialized
INFO - 2023-11-02 10:57:39 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:39 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:39 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:39 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:39 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:39 --> Controller Class Initialized
DEBUG - 2023-11-02 10:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-02 10:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:57:39 --> Final output sent to browser
DEBUG - 2023-11-02 10:57:39 --> Total execution time: 0.0412
INFO - 2023-11-02 10:57:43 --> Config Class Initialized
INFO - 2023-11-02 10:57:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:43 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:43 --> URI Class Initialized
INFO - 2023-11-02 10:57:43 --> Router Class Initialized
INFO - 2023-11-02 10:57:43 --> Output Class Initialized
INFO - 2023-11-02 10:57:43 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:43 --> Input Class Initialized
INFO - 2023-11-02 10:57:43 --> Language Class Initialized
INFO - 2023-11-02 10:57:43 --> Language Class Initialized
INFO - 2023-11-02 10:57:43 --> Config Class Initialized
INFO - 2023-11-02 10:57:43 --> Loader Class Initialized
INFO - 2023-11-02 10:57:43 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:43 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:43 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:43 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:43 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:43 --> Controller Class Initialized
INFO - 2023-11-02 10:57:43 --> Helper loaded: cookie_helper
INFO - 2023-11-02 10:57:43 --> Final output sent to browser
DEBUG - 2023-11-02 10:57:43 --> Total execution time: 0.0606
INFO - 2023-11-02 10:57:43 --> Config Class Initialized
INFO - 2023-11-02 10:57:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:43 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:43 --> URI Class Initialized
INFO - 2023-11-02 10:57:43 --> Router Class Initialized
INFO - 2023-11-02 10:57:43 --> Output Class Initialized
INFO - 2023-11-02 10:57:43 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:43 --> Input Class Initialized
INFO - 2023-11-02 10:57:43 --> Language Class Initialized
INFO - 2023-11-02 10:57:43 --> Language Class Initialized
INFO - 2023-11-02 10:57:43 --> Config Class Initialized
INFO - 2023-11-02 10:57:43 --> Loader Class Initialized
INFO - 2023-11-02 10:57:43 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:43 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:43 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:43 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:43 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:43 --> Controller Class Initialized
DEBUG - 2023-11-02 10:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 10:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:57:43 --> Final output sent to browser
DEBUG - 2023-11-02 10:57:43 --> Total execution time: 0.0522
INFO - 2023-11-02 10:57:53 --> Config Class Initialized
INFO - 2023-11-02 10:57:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:53 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:53 --> URI Class Initialized
INFO - 2023-11-02 10:57:53 --> Router Class Initialized
INFO - 2023-11-02 10:57:53 --> Output Class Initialized
INFO - 2023-11-02 10:57:53 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:53 --> Input Class Initialized
INFO - 2023-11-02 10:57:53 --> Language Class Initialized
INFO - 2023-11-02 10:57:53 --> Language Class Initialized
INFO - 2023-11-02 10:57:53 --> Config Class Initialized
INFO - 2023-11-02 10:57:53 --> Loader Class Initialized
INFO - 2023-11-02 10:57:53 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:53 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:53 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:53 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:53 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:53 --> Controller Class Initialized
DEBUG - 2023-11-02 10:57:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-02 10:57:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:57:53 --> Final output sent to browser
DEBUG - 2023-11-02 10:57:53 --> Total execution time: 0.1393
INFO - 2023-11-02 10:57:56 --> Config Class Initialized
INFO - 2023-11-02 10:57:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:56 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:56 --> URI Class Initialized
INFO - 2023-11-02 10:57:56 --> Router Class Initialized
INFO - 2023-11-02 10:57:56 --> Output Class Initialized
INFO - 2023-11-02 10:57:56 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:56 --> Input Class Initialized
INFO - 2023-11-02 10:57:56 --> Language Class Initialized
INFO - 2023-11-02 10:57:56 --> Language Class Initialized
INFO - 2023-11-02 10:57:56 --> Config Class Initialized
INFO - 2023-11-02 10:57:56 --> Loader Class Initialized
INFO - 2023-11-02 10:57:56 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:56 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:56 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:56 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:56 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:56 --> Controller Class Initialized
DEBUG - 2023-11-02 10:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-02 10:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 10:57:56 --> Final output sent to browser
DEBUG - 2023-11-02 10:57:56 --> Total execution time: 0.0534
INFO - 2023-11-02 10:57:56 --> Config Class Initialized
INFO - 2023-11-02 10:57:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:57:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:57:56 --> Utf8 Class Initialized
INFO - 2023-11-02 10:57:56 --> URI Class Initialized
INFO - 2023-11-02 10:57:56 --> Router Class Initialized
INFO - 2023-11-02 10:57:56 --> Output Class Initialized
INFO - 2023-11-02 10:57:56 --> Security Class Initialized
DEBUG - 2023-11-02 10:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:57:56 --> Input Class Initialized
INFO - 2023-11-02 10:57:56 --> Language Class Initialized
INFO - 2023-11-02 10:57:56 --> Language Class Initialized
INFO - 2023-11-02 10:57:56 --> Config Class Initialized
INFO - 2023-11-02 10:57:56 --> Loader Class Initialized
INFO - 2023-11-02 10:57:56 --> Helper loaded: url_helper
INFO - 2023-11-02 10:57:56 --> Helper loaded: file_helper
INFO - 2023-11-02 10:57:56 --> Helper loaded: form_helper
INFO - 2023-11-02 10:57:56 --> Helper loaded: my_helper
INFO - 2023-11-02 10:57:56 --> Database Driver Class Initialized
INFO - 2023-11-02 10:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:57:56 --> Controller Class Initialized
INFO - 2023-11-02 10:59:00 --> Config Class Initialized
INFO - 2023-11-02 10:59:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:59:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:59:00 --> Utf8 Class Initialized
INFO - 2023-11-02 10:59:00 --> URI Class Initialized
INFO - 2023-11-02 10:59:00 --> Router Class Initialized
INFO - 2023-11-02 10:59:00 --> Output Class Initialized
INFO - 2023-11-02 10:59:00 --> Security Class Initialized
DEBUG - 2023-11-02 10:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:59:00 --> Input Class Initialized
INFO - 2023-11-02 10:59:00 --> Language Class Initialized
INFO - 2023-11-02 10:59:00 --> Language Class Initialized
INFO - 2023-11-02 10:59:00 --> Config Class Initialized
INFO - 2023-11-02 10:59:00 --> Loader Class Initialized
INFO - 2023-11-02 10:59:00 --> Helper loaded: url_helper
INFO - 2023-11-02 10:59:00 --> Helper loaded: file_helper
INFO - 2023-11-02 10:59:00 --> Helper loaded: form_helper
INFO - 2023-11-02 10:59:00 --> Helper loaded: my_helper
INFO - 2023-11-02 10:59:00 --> Database Driver Class Initialized
INFO - 2023-11-02 10:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:59:01 --> Controller Class Initialized
INFO - 2023-11-02 10:59:01 --> Final output sent to browser
DEBUG - 2023-11-02 10:59:01 --> Total execution time: 0.0538
INFO - 2023-11-02 10:59:07 --> Config Class Initialized
INFO - 2023-11-02 10:59:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:59:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:59:07 --> Utf8 Class Initialized
INFO - 2023-11-02 10:59:07 --> URI Class Initialized
INFO - 2023-11-02 10:59:07 --> Router Class Initialized
INFO - 2023-11-02 10:59:07 --> Output Class Initialized
INFO - 2023-11-02 10:59:07 --> Security Class Initialized
DEBUG - 2023-11-02 10:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:59:07 --> Input Class Initialized
INFO - 2023-11-02 10:59:07 --> Language Class Initialized
INFO - 2023-11-02 10:59:07 --> Language Class Initialized
INFO - 2023-11-02 10:59:07 --> Config Class Initialized
INFO - 2023-11-02 10:59:07 --> Loader Class Initialized
INFO - 2023-11-02 10:59:07 --> Helper loaded: url_helper
INFO - 2023-11-02 10:59:07 --> Helper loaded: file_helper
INFO - 2023-11-02 10:59:07 --> Helper loaded: form_helper
INFO - 2023-11-02 10:59:07 --> Helper loaded: my_helper
INFO - 2023-11-02 10:59:08 --> Database Driver Class Initialized
INFO - 2023-11-02 10:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:59:08 --> Controller Class Initialized
INFO - 2023-11-02 10:59:08 --> Final output sent to browser
DEBUG - 2023-11-02 10:59:08 --> Total execution time: 0.0357
INFO - 2023-11-02 10:59:13 --> Config Class Initialized
INFO - 2023-11-02 10:59:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:59:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:59:13 --> Utf8 Class Initialized
INFO - 2023-11-02 10:59:13 --> URI Class Initialized
INFO - 2023-11-02 10:59:13 --> Router Class Initialized
INFO - 2023-11-02 10:59:13 --> Output Class Initialized
INFO - 2023-11-02 10:59:13 --> Security Class Initialized
DEBUG - 2023-11-02 10:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:59:13 --> Input Class Initialized
INFO - 2023-11-02 10:59:13 --> Language Class Initialized
INFO - 2023-11-02 10:59:13 --> Language Class Initialized
INFO - 2023-11-02 10:59:13 --> Config Class Initialized
INFO - 2023-11-02 10:59:13 --> Loader Class Initialized
INFO - 2023-11-02 10:59:13 --> Helper loaded: url_helper
INFO - 2023-11-02 10:59:13 --> Helper loaded: file_helper
INFO - 2023-11-02 10:59:13 --> Helper loaded: form_helper
INFO - 2023-11-02 10:59:13 --> Helper loaded: my_helper
INFO - 2023-11-02 10:59:13 --> Database Driver Class Initialized
INFO - 2023-11-02 10:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:59:13 --> Controller Class Initialized
INFO - 2023-11-02 10:59:13 --> Final output sent to browser
DEBUG - 2023-11-02 10:59:13 --> Total execution time: 0.0328
INFO - 2023-11-02 10:59:15 --> Config Class Initialized
INFO - 2023-11-02 10:59:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:59:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:59:15 --> Utf8 Class Initialized
INFO - 2023-11-02 10:59:15 --> URI Class Initialized
INFO - 2023-11-02 10:59:15 --> Router Class Initialized
INFO - 2023-11-02 10:59:15 --> Output Class Initialized
INFO - 2023-11-02 10:59:15 --> Security Class Initialized
DEBUG - 2023-11-02 10:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:59:15 --> Input Class Initialized
INFO - 2023-11-02 10:59:15 --> Language Class Initialized
INFO - 2023-11-02 10:59:15 --> Language Class Initialized
INFO - 2023-11-02 10:59:15 --> Config Class Initialized
INFO - 2023-11-02 10:59:15 --> Loader Class Initialized
INFO - 2023-11-02 10:59:15 --> Helper loaded: url_helper
INFO - 2023-11-02 10:59:15 --> Helper loaded: file_helper
INFO - 2023-11-02 10:59:15 --> Helper loaded: form_helper
INFO - 2023-11-02 10:59:15 --> Helper loaded: my_helper
INFO - 2023-11-02 10:59:15 --> Database Driver Class Initialized
INFO - 2023-11-02 10:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:59:15 --> Controller Class Initialized
INFO - 2023-11-02 10:59:15 --> Final output sent to browser
DEBUG - 2023-11-02 10:59:15 --> Total execution time: 0.0445
INFO - 2023-11-02 10:59:17 --> Config Class Initialized
INFO - 2023-11-02 10:59:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:59:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:59:17 --> Utf8 Class Initialized
INFO - 2023-11-02 10:59:17 --> URI Class Initialized
INFO - 2023-11-02 10:59:17 --> Router Class Initialized
INFO - 2023-11-02 10:59:17 --> Output Class Initialized
INFO - 2023-11-02 10:59:17 --> Security Class Initialized
DEBUG - 2023-11-02 10:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:59:17 --> Input Class Initialized
INFO - 2023-11-02 10:59:17 --> Language Class Initialized
INFO - 2023-11-02 10:59:17 --> Language Class Initialized
INFO - 2023-11-02 10:59:17 --> Config Class Initialized
INFO - 2023-11-02 10:59:17 --> Loader Class Initialized
INFO - 2023-11-02 10:59:17 --> Helper loaded: url_helper
INFO - 2023-11-02 10:59:17 --> Helper loaded: file_helper
INFO - 2023-11-02 10:59:17 --> Helper loaded: form_helper
INFO - 2023-11-02 10:59:17 --> Helper loaded: my_helper
INFO - 2023-11-02 10:59:17 --> Database Driver Class Initialized
INFO - 2023-11-02 10:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:59:17 --> Controller Class Initialized
INFO - 2023-11-02 10:59:17 --> Final output sent to browser
DEBUG - 2023-11-02 10:59:17 --> Total execution time: 0.0444
INFO - 2023-11-02 11:04:15 --> Config Class Initialized
INFO - 2023-11-02 11:04:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:04:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:04:15 --> Utf8 Class Initialized
INFO - 2023-11-02 11:04:15 --> URI Class Initialized
INFO - 2023-11-02 11:04:15 --> Router Class Initialized
INFO - 2023-11-02 11:04:15 --> Output Class Initialized
INFO - 2023-11-02 11:04:15 --> Security Class Initialized
DEBUG - 2023-11-02 11:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:04:15 --> Input Class Initialized
INFO - 2023-11-02 11:04:15 --> Language Class Initialized
INFO - 2023-11-02 11:04:15 --> Language Class Initialized
INFO - 2023-11-02 11:04:15 --> Config Class Initialized
INFO - 2023-11-02 11:04:15 --> Loader Class Initialized
INFO - 2023-11-02 11:04:15 --> Helper loaded: url_helper
INFO - 2023-11-02 11:04:15 --> Helper loaded: file_helper
INFO - 2023-11-02 11:04:15 --> Helper loaded: form_helper
INFO - 2023-11-02 11:04:15 --> Helper loaded: my_helper
INFO - 2023-11-02 11:04:15 --> Database Driver Class Initialized
INFO - 2023-11-02 11:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:04:15 --> Controller Class Initialized
INFO - 2023-11-02 11:04:15 --> Final output sent to browser
DEBUG - 2023-11-02 11:04:15 --> Total execution time: 0.0756
INFO - 2023-11-02 11:04:48 --> Config Class Initialized
INFO - 2023-11-02 11:04:48 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:04:48 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:04:48 --> Utf8 Class Initialized
INFO - 2023-11-02 11:04:48 --> URI Class Initialized
INFO - 2023-11-02 11:04:48 --> Router Class Initialized
INFO - 2023-11-02 11:04:48 --> Output Class Initialized
INFO - 2023-11-02 11:04:48 --> Security Class Initialized
DEBUG - 2023-11-02 11:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:04:48 --> Input Class Initialized
INFO - 2023-11-02 11:04:48 --> Language Class Initialized
INFO - 2023-11-02 11:04:48 --> Language Class Initialized
INFO - 2023-11-02 11:04:48 --> Config Class Initialized
INFO - 2023-11-02 11:04:48 --> Loader Class Initialized
INFO - 2023-11-02 11:04:48 --> Helper loaded: url_helper
INFO - 2023-11-02 11:04:48 --> Helper loaded: file_helper
INFO - 2023-11-02 11:04:48 --> Helper loaded: form_helper
INFO - 2023-11-02 11:04:48 --> Helper loaded: my_helper
INFO - 2023-11-02 11:04:48 --> Database Driver Class Initialized
INFO - 2023-11-02 11:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:04:48 --> Controller Class Initialized
INFO - 2023-11-02 11:17:16 --> Config Class Initialized
INFO - 2023-11-02 11:17:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:17:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:17:16 --> Utf8 Class Initialized
INFO - 2023-11-02 11:17:16 --> URI Class Initialized
INFO - 2023-11-02 11:17:16 --> Router Class Initialized
INFO - 2023-11-02 11:17:16 --> Output Class Initialized
INFO - 2023-11-02 11:17:16 --> Security Class Initialized
DEBUG - 2023-11-02 11:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:17:16 --> Input Class Initialized
INFO - 2023-11-02 11:17:16 --> Language Class Initialized
INFO - 2023-11-02 11:17:16 --> Language Class Initialized
INFO - 2023-11-02 11:17:16 --> Config Class Initialized
INFO - 2023-11-02 11:17:16 --> Loader Class Initialized
INFO - 2023-11-02 11:17:16 --> Helper loaded: url_helper
INFO - 2023-11-02 11:17:16 --> Helper loaded: file_helper
INFO - 2023-11-02 11:17:16 --> Helper loaded: form_helper
INFO - 2023-11-02 11:17:16 --> Helper loaded: my_helper
INFO - 2023-11-02 11:17:16 --> Database Driver Class Initialized
INFO - 2023-11-02 11:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:17:16 --> Controller Class Initialized
INFO - 2023-11-02 11:17:16 --> Final output sent to browser
DEBUG - 2023-11-02 11:17:16 --> Total execution time: 0.0450
INFO - 2023-11-02 11:17:19 --> Config Class Initialized
INFO - 2023-11-02 11:17:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:17:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:17:19 --> Utf8 Class Initialized
INFO - 2023-11-02 11:17:19 --> URI Class Initialized
INFO - 2023-11-02 11:17:19 --> Router Class Initialized
INFO - 2023-11-02 11:17:19 --> Output Class Initialized
INFO - 2023-11-02 11:17:19 --> Security Class Initialized
DEBUG - 2023-11-02 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:17:19 --> Input Class Initialized
INFO - 2023-11-02 11:17:19 --> Language Class Initialized
INFO - 2023-11-02 11:17:19 --> Language Class Initialized
INFO - 2023-11-02 11:17:19 --> Config Class Initialized
INFO - 2023-11-02 11:17:19 --> Loader Class Initialized
INFO - 2023-11-02 11:17:19 --> Helper loaded: url_helper
INFO - 2023-11-02 11:17:19 --> Helper loaded: file_helper
INFO - 2023-11-02 11:17:19 --> Helper loaded: form_helper
INFO - 2023-11-02 11:17:19 --> Helper loaded: my_helper
INFO - 2023-11-02 11:17:19 --> Database Driver Class Initialized
INFO - 2023-11-02 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:17:19 --> Controller Class Initialized
INFO - 2023-11-02 11:17:19 --> Final output sent to browser
DEBUG - 2023-11-02 11:17:19 --> Total execution time: 0.0752
INFO - 2023-11-02 11:17:19 --> Config Class Initialized
INFO - 2023-11-02 11:17:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:17:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:17:19 --> Utf8 Class Initialized
INFO - 2023-11-02 11:17:19 --> URI Class Initialized
INFO - 2023-11-02 11:17:19 --> Router Class Initialized
INFO - 2023-11-02 11:17:19 --> Output Class Initialized
INFO - 2023-11-02 11:17:19 --> Security Class Initialized
DEBUG - 2023-11-02 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:17:19 --> Input Class Initialized
INFO - 2023-11-02 11:17:19 --> Language Class Initialized
INFO - 2023-11-02 11:17:19 --> Language Class Initialized
INFO - 2023-11-02 11:17:19 --> Config Class Initialized
INFO - 2023-11-02 11:17:19 --> Loader Class Initialized
INFO - 2023-11-02 11:17:19 --> Helper loaded: url_helper
INFO - 2023-11-02 11:17:19 --> Helper loaded: file_helper
INFO - 2023-11-02 11:17:19 --> Helper loaded: form_helper
INFO - 2023-11-02 11:17:19 --> Helper loaded: my_helper
INFO - 2023-11-02 11:17:19 --> Database Driver Class Initialized
INFO - 2023-11-02 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:17:19 --> Controller Class Initialized
INFO - 2023-11-02 11:17:19 --> Final output sent to browser
DEBUG - 2023-11-02 11:17:19 --> Total execution time: 0.0441
INFO - 2023-11-02 11:17:39 --> Config Class Initialized
INFO - 2023-11-02 11:17:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:17:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:17:39 --> Utf8 Class Initialized
INFO - 2023-11-02 11:17:39 --> URI Class Initialized
INFO - 2023-11-02 11:17:39 --> Router Class Initialized
INFO - 2023-11-02 11:17:39 --> Output Class Initialized
INFO - 2023-11-02 11:17:39 --> Security Class Initialized
DEBUG - 2023-11-02 11:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:17:39 --> Input Class Initialized
INFO - 2023-11-02 11:17:39 --> Language Class Initialized
INFO - 2023-11-02 11:17:39 --> Language Class Initialized
INFO - 2023-11-02 11:17:39 --> Config Class Initialized
INFO - 2023-11-02 11:17:39 --> Loader Class Initialized
INFO - 2023-11-02 11:17:39 --> Helper loaded: url_helper
INFO - 2023-11-02 11:17:39 --> Helper loaded: file_helper
INFO - 2023-11-02 11:17:39 --> Helper loaded: form_helper
INFO - 2023-11-02 11:17:39 --> Helper loaded: my_helper
INFO - 2023-11-02 11:17:39 --> Database Driver Class Initialized
INFO - 2023-11-02 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:17:40 --> Controller Class Initialized
INFO - 2023-11-02 11:17:40 --> Final output sent to browser
DEBUG - 2023-11-02 11:17:40 --> Total execution time: 0.0347
INFO - 2023-11-02 11:19:23 --> Config Class Initialized
INFO - 2023-11-02 11:19:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:23 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:23 --> URI Class Initialized
INFO - 2023-11-02 11:19:23 --> Router Class Initialized
INFO - 2023-11-02 11:19:23 --> Output Class Initialized
INFO - 2023-11-02 11:19:23 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:23 --> Input Class Initialized
INFO - 2023-11-02 11:19:23 --> Language Class Initialized
INFO - 2023-11-02 11:19:23 --> Language Class Initialized
INFO - 2023-11-02 11:19:23 --> Config Class Initialized
INFO - 2023-11-02 11:19:23 --> Loader Class Initialized
INFO - 2023-11-02 11:19:23 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:23 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:23 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:23 --> Helper loaded: my_helper
INFO - 2023-11-02 11:19:23 --> Database Driver Class Initialized
INFO - 2023-11-02 11:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:23 --> Controller Class Initialized
DEBUG - 2023-11-02 11:19:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-02 11:19:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 11:19:23 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:23 --> Total execution time: 0.0381
INFO - 2023-11-02 11:19:25 --> Config Class Initialized
INFO - 2023-11-02 11:19:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:25 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:25 --> URI Class Initialized
INFO - 2023-11-02 11:19:25 --> Router Class Initialized
INFO - 2023-11-02 11:19:25 --> Output Class Initialized
INFO - 2023-11-02 11:19:25 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:25 --> Input Class Initialized
INFO - 2023-11-02 11:19:25 --> Language Class Initialized
INFO - 2023-11-02 11:19:25 --> Language Class Initialized
INFO - 2023-11-02 11:19:25 --> Config Class Initialized
INFO - 2023-11-02 11:19:25 --> Loader Class Initialized
INFO - 2023-11-02 11:19:25 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:25 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:25 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:25 --> Helper loaded: my_helper
INFO - 2023-11-02 11:19:25 --> Database Driver Class Initialized
INFO - 2023-11-02 11:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:25 --> Controller Class Initialized
DEBUG - 2023-11-02 11:19:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-02 11:19:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 11:19:25 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:25 --> Total execution time: 0.0488
INFO - 2023-11-02 11:19:25 --> Config Class Initialized
INFO - 2023-11-02 11:19:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:25 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:25 --> URI Class Initialized
INFO - 2023-11-02 11:19:25 --> Router Class Initialized
INFO - 2023-11-02 11:19:25 --> Output Class Initialized
INFO - 2023-11-02 11:19:25 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:25 --> Input Class Initialized
INFO - 2023-11-02 11:19:25 --> Language Class Initialized
INFO - 2023-11-02 11:19:25 --> Language Class Initialized
INFO - 2023-11-02 11:19:25 --> Config Class Initialized
INFO - 2023-11-02 11:19:25 --> Loader Class Initialized
INFO - 2023-11-02 11:19:25 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:25 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:25 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:25 --> Helper loaded: my_helper
INFO - 2023-11-02 11:19:25 --> Database Driver Class Initialized
INFO - 2023-11-02 11:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:25 --> Controller Class Initialized
INFO - 2023-11-02 11:19:28 --> Config Class Initialized
INFO - 2023-11-02 11:19:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:28 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:28 --> URI Class Initialized
INFO - 2023-11-02 11:19:28 --> Router Class Initialized
INFO - 2023-11-02 11:19:28 --> Output Class Initialized
INFO - 2023-11-02 11:19:28 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:28 --> Input Class Initialized
INFO - 2023-11-02 11:19:28 --> Language Class Initialized
INFO - 2023-11-02 11:19:28 --> Language Class Initialized
INFO - 2023-11-02 11:19:28 --> Config Class Initialized
INFO - 2023-11-02 11:19:28 --> Loader Class Initialized
INFO - 2023-11-02 11:19:28 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: my_helper
INFO - 2023-11-02 11:19:28 --> Database Driver Class Initialized
INFO - 2023-11-02 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:28 --> Controller Class Initialized
INFO - 2023-11-02 11:28:00 --> Config Class Initialized
INFO - 2023-11-02 11:28:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:00 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:00 --> URI Class Initialized
DEBUG - 2023-11-02 11:28:00 --> No URI present. Default controller set.
INFO - 2023-11-02 11:28:00 --> Router Class Initialized
INFO - 2023-11-02 11:28:00 --> Output Class Initialized
INFO - 2023-11-02 11:28:00 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:00 --> Input Class Initialized
INFO - 2023-11-02 11:28:00 --> Language Class Initialized
INFO - 2023-11-02 11:28:00 --> Language Class Initialized
INFO - 2023-11-02 11:28:00 --> Config Class Initialized
INFO - 2023-11-02 11:28:00 --> Loader Class Initialized
INFO - 2023-11-02 11:28:00 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:00 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:00 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:00 --> Helper loaded: my_helper
INFO - 2023-11-02 11:28:00 --> Database Driver Class Initialized
INFO - 2023-11-02 11:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:00 --> Controller Class Initialized
DEBUG - 2023-11-02 11:28:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-02 11:28:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 11:28:00 --> Final output sent to browser
DEBUG - 2023-11-02 11:28:00 --> Total execution time: 0.0460
INFO - 2023-11-02 11:28:13 --> Config Class Initialized
INFO - 2023-11-02 11:28:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:13 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:13 --> URI Class Initialized
INFO - 2023-11-02 11:28:13 --> Router Class Initialized
INFO - 2023-11-02 11:28:13 --> Output Class Initialized
INFO - 2023-11-02 11:28:13 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:13 --> Input Class Initialized
INFO - 2023-11-02 11:28:13 --> Language Class Initialized
INFO - 2023-11-02 11:28:13 --> Language Class Initialized
INFO - 2023-11-02 11:28:13 --> Config Class Initialized
INFO - 2023-11-02 11:28:13 --> Loader Class Initialized
INFO - 2023-11-02 11:28:13 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:13 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:13 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:13 --> Helper loaded: my_helper
INFO - 2023-11-02 11:28:13 --> Database Driver Class Initialized
INFO - 2023-11-02 11:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:13 --> Controller Class Initialized
DEBUG - 2023-11-02 11:28:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-02 11:28:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 11:28:13 --> Final output sent to browser
DEBUG - 2023-11-02 11:28:13 --> Total execution time: 0.0397
INFO - 2023-11-02 11:28:36 --> Config Class Initialized
INFO - 2023-11-02 11:28:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:36 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:36 --> URI Class Initialized
INFO - 2023-11-02 11:28:36 --> Router Class Initialized
INFO - 2023-11-02 11:28:36 --> Output Class Initialized
INFO - 2023-11-02 11:28:36 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:36 --> Input Class Initialized
INFO - 2023-11-02 11:28:36 --> Language Class Initialized
INFO - 2023-11-02 11:28:36 --> Language Class Initialized
INFO - 2023-11-02 11:28:36 --> Config Class Initialized
INFO - 2023-11-02 11:28:36 --> Loader Class Initialized
INFO - 2023-11-02 11:28:36 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:36 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:36 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:36 --> Helper loaded: my_helper
INFO - 2023-11-02 11:28:36 --> Database Driver Class Initialized
INFO - 2023-11-02 11:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:36 --> Controller Class Initialized
DEBUG - 2023-11-02 11:28:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-02 11:28:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-02 11:28:36 --> Final output sent to browser
DEBUG - 2023-11-02 11:28:36 --> Total execution time: 0.1091
INFO - 2023-11-02 11:28:36 --> Config Class Initialized
INFO - 2023-11-02 11:28:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:36 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:36 --> URI Class Initialized
INFO - 2023-11-02 11:28:36 --> Router Class Initialized
INFO - 2023-11-02 11:28:36 --> Output Class Initialized
INFO - 2023-11-02 11:28:36 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:36 --> Input Class Initialized
INFO - 2023-11-02 11:28:36 --> Language Class Initialized
INFO - 2023-11-02 11:28:36 --> Language Class Initialized
INFO - 2023-11-02 11:28:36 --> Config Class Initialized
INFO - 2023-11-02 11:28:36 --> Loader Class Initialized
INFO - 2023-11-02 11:28:36 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:36 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:36 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:36 --> Helper loaded: my_helper
INFO - 2023-11-02 11:28:36 --> Database Driver Class Initialized
INFO - 2023-11-02 11:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:36 --> Controller Class Initialized
INFO - 2023-11-02 11:28:48 --> Config Class Initialized
INFO - 2023-11-02 11:28:48 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:48 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:48 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:48 --> URI Class Initialized
INFO - 2023-11-02 11:28:48 --> Router Class Initialized
INFO - 2023-11-02 11:28:48 --> Output Class Initialized
INFO - 2023-11-02 11:28:48 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:48 --> Input Class Initialized
INFO - 2023-11-02 11:28:48 --> Language Class Initialized
INFO - 2023-11-02 11:28:48 --> Language Class Initialized
INFO - 2023-11-02 11:28:48 --> Config Class Initialized
INFO - 2023-11-02 11:28:48 --> Loader Class Initialized
INFO - 2023-11-02 11:28:48 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:48 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:48 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:48 --> Helper loaded: my_helper
INFO - 2023-11-02 11:28:48 --> Database Driver Class Initialized
INFO - 2023-11-02 11:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:48 --> Controller Class Initialized
