<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-26 09:13:09 --> Config Class Initialized
INFO - 2024-11-26 09:13:09 --> Hooks Class Initialized
DEBUG - 2024-11-26 09:13:09 --> UTF-8 Support Enabled
INFO - 2024-11-26 09:13:09 --> Utf8 Class Initialized
INFO - 2024-11-26 09:13:09 --> URI Class Initialized
INFO - 2024-11-26 09:13:09 --> Router Class Initialized
INFO - 2024-11-26 09:13:09 --> Output Class Initialized
INFO - 2024-11-26 09:13:09 --> Security Class Initialized
DEBUG - 2024-11-26 09:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-26 09:13:09 --> Input Class Initialized
INFO - 2024-11-26 09:13:09 --> Language Class Initialized
INFO - 2024-11-26 09:13:09 --> Language Class Initialized
INFO - 2024-11-26 09:13:09 --> Config Class Initialized
INFO - 2024-11-26 09:13:09 --> Loader Class Initialized
INFO - 2024-11-26 09:13:09 --> Helper loaded: url_helper
INFO - 2024-11-26 09:13:09 --> Helper loaded: file_helper
INFO - 2024-11-26 09:13:09 --> Helper loaded: form_helper
INFO - 2024-11-26 09:13:09 --> Helper loaded: my_helper
INFO - 2024-11-26 09:13:09 --> Database Driver Class Initialized
INFO - 2024-11-26 09:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-26 09:13:09 --> Controller Class Initialized
INFO - 2024-11-26 09:13:09 --> Helper loaded: cookie_helper
INFO - 2024-11-26 09:13:09 --> Final output sent to browser
DEBUG - 2024-11-26 09:13:09 --> Total execution time: 0.1235
INFO - 2024-11-26 09:13:10 --> Config Class Initialized
INFO - 2024-11-26 09:13:10 --> Hooks Class Initialized
DEBUG - 2024-11-26 09:13:10 --> UTF-8 Support Enabled
INFO - 2024-11-26 09:13:10 --> Utf8 Class Initialized
INFO - 2024-11-26 09:13:10 --> URI Class Initialized
INFO - 2024-11-26 09:13:10 --> Router Class Initialized
INFO - 2024-11-26 09:13:10 --> Output Class Initialized
INFO - 2024-11-26 09:13:10 --> Security Class Initialized
DEBUG - 2024-11-26 09:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-26 09:13:10 --> Input Class Initialized
INFO - 2024-11-26 09:13:10 --> Language Class Initialized
INFO - 2024-11-26 09:13:10 --> Language Class Initialized
INFO - 2024-11-26 09:13:10 --> Config Class Initialized
INFO - 2024-11-26 09:13:10 --> Loader Class Initialized
INFO - 2024-11-26 09:13:10 --> Helper loaded: url_helper
INFO - 2024-11-26 09:13:10 --> Helper loaded: file_helper
INFO - 2024-11-26 09:13:10 --> Helper loaded: form_helper
INFO - 2024-11-26 09:13:10 --> Helper loaded: my_helper
INFO - 2024-11-26 09:13:10 --> Database Driver Class Initialized
INFO - 2024-11-26 09:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-26 09:13:10 --> Controller Class Initialized
INFO - 2024-11-26 09:13:10 --> Helper loaded: cookie_helper
INFO - 2024-11-26 09:13:10 --> Config Class Initialized
INFO - 2024-11-26 09:13:10 --> Hooks Class Initialized
DEBUG - 2024-11-26 09:13:10 --> UTF-8 Support Enabled
INFO - 2024-11-26 09:13:10 --> Utf8 Class Initialized
INFO - 2024-11-26 09:13:10 --> URI Class Initialized
INFO - 2024-11-26 09:13:10 --> Router Class Initialized
INFO - 2024-11-26 09:13:10 --> Output Class Initialized
INFO - 2024-11-26 09:13:10 --> Security Class Initialized
DEBUG - 2024-11-26 09:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-26 09:13:10 --> Input Class Initialized
INFO - 2024-11-26 09:13:10 --> Language Class Initialized
INFO - 2024-11-26 09:13:10 --> Language Class Initialized
INFO - 2024-11-26 09:13:10 --> Config Class Initialized
INFO - 2024-11-26 09:13:10 --> Loader Class Initialized
INFO - 2024-11-26 09:13:10 --> Helper loaded: url_helper
INFO - 2024-11-26 09:13:10 --> Helper loaded: file_helper
INFO - 2024-11-26 09:13:10 --> Helper loaded: form_helper
INFO - 2024-11-26 09:13:10 --> Helper loaded: my_helper
INFO - 2024-11-26 09:13:10 --> Database Driver Class Initialized
INFO - 2024-11-26 09:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-26 09:13:10 --> Controller Class Initialized
DEBUG - 2024-11-26 09:13:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-26 09:13:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-26 09:13:10 --> Final output sent to browser
DEBUG - 2024-11-26 09:13:10 --> Total execution time: 0.0421
INFO - 2024-11-26 09:13:13 --> Config Class Initialized
INFO - 2024-11-26 09:13:13 --> Hooks Class Initialized
DEBUG - 2024-11-26 09:13:13 --> UTF-8 Support Enabled
INFO - 2024-11-26 09:13:13 --> Utf8 Class Initialized
INFO - 2024-11-26 09:13:13 --> URI Class Initialized
INFO - 2024-11-26 09:13:13 --> Router Class Initialized
INFO - 2024-11-26 09:13:13 --> Output Class Initialized
INFO - 2024-11-26 09:13:13 --> Security Class Initialized
DEBUG - 2024-11-26 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-26 09:13:13 --> Input Class Initialized
INFO - 2024-11-26 09:13:13 --> Language Class Initialized
INFO - 2024-11-26 09:13:13 --> Language Class Initialized
INFO - 2024-11-26 09:13:13 --> Config Class Initialized
INFO - 2024-11-26 09:13:13 --> Loader Class Initialized
INFO - 2024-11-26 09:13:13 --> Helper loaded: url_helper
INFO - 2024-11-26 09:13:13 --> Helper loaded: file_helper
INFO - 2024-11-26 09:13:13 --> Helper loaded: form_helper
INFO - 2024-11-26 09:13:13 --> Helper loaded: my_helper
INFO - 2024-11-26 09:13:13 --> Database Driver Class Initialized
INFO - 2024-11-26 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-26 09:13:13 --> Controller Class Initialized
DEBUG - 2024-11-26 09:13:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-26 09:13:16 --> Final output sent to browser
DEBUG - 2024-11-26 09:13:16 --> Total execution time: 3.5828
