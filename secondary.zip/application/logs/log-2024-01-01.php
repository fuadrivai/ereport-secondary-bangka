<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-01 11:33:03 --> Config Class Initialized
INFO - 2024-01-01 11:33:03 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:33:03 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:33:03 --> Utf8 Class Initialized
INFO - 2024-01-01 11:33:03 --> URI Class Initialized
INFO - 2024-01-01 11:33:04 --> Router Class Initialized
INFO - 2024-01-01 11:33:04 --> Output Class Initialized
INFO - 2024-01-01 11:33:04 --> Security Class Initialized
DEBUG - 2024-01-01 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:33:04 --> Input Class Initialized
INFO - 2024-01-01 11:33:04 --> Language Class Initialized
INFO - 2024-01-01 11:33:04 --> Language Class Initialized
INFO - 2024-01-01 11:33:04 --> Config Class Initialized
INFO - 2024-01-01 11:33:04 --> Loader Class Initialized
INFO - 2024-01-01 11:33:04 --> Helper loaded: url_helper
INFO - 2024-01-01 11:33:04 --> Helper loaded: file_helper
INFO - 2024-01-01 11:33:04 --> Helper loaded: form_helper
INFO - 2024-01-01 11:33:04 --> Helper loaded: my_helper
INFO - 2024-01-01 11:33:04 --> Database Driver Class Initialized
INFO - 2024-01-01 11:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:33:04 --> Controller Class Initialized
DEBUG - 2024-01-01 11:33:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-01 11:33:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-01 11:33:04 --> Final output sent to browser
DEBUG - 2024-01-01 11:33:04 --> Total execution time: 0.4292
INFO - 2024-01-01 15:53:05 --> Config Class Initialized
INFO - 2024-01-01 15:53:05 --> Hooks Class Initialized
DEBUG - 2024-01-01 15:53:05 --> UTF-8 Support Enabled
INFO - 2024-01-01 15:53:05 --> Utf8 Class Initialized
INFO - 2024-01-01 15:53:05 --> URI Class Initialized
INFO - 2024-01-01 15:53:05 --> Router Class Initialized
INFO - 2024-01-01 15:53:05 --> Output Class Initialized
INFO - 2024-01-01 15:53:05 --> Security Class Initialized
DEBUG - 2024-01-01 15:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 15:53:05 --> Input Class Initialized
INFO - 2024-01-01 15:53:05 --> Language Class Initialized
INFO - 2024-01-01 15:53:05 --> Language Class Initialized
INFO - 2024-01-01 15:53:05 --> Config Class Initialized
INFO - 2024-01-01 15:53:05 --> Loader Class Initialized
INFO - 2024-01-01 15:53:05 --> Helper loaded: url_helper
INFO - 2024-01-01 15:53:05 --> Helper loaded: file_helper
INFO - 2024-01-01 15:53:05 --> Helper loaded: form_helper
INFO - 2024-01-01 15:53:05 --> Helper loaded: my_helper
INFO - 2024-01-01 15:53:05 --> Database Driver Class Initialized
INFO - 2024-01-01 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 15:53:05 --> Controller Class Initialized
INFO - 2024-01-01 15:53:05 --> Helper loaded: cookie_helper
INFO - 2024-01-01 15:53:05 --> Final output sent to browser
DEBUG - 2024-01-01 15:53:05 --> Total execution time: 0.1386
INFO - 2024-01-01 15:53:05 --> Config Class Initialized
INFO - 2024-01-01 15:53:05 --> Hooks Class Initialized
DEBUG - 2024-01-01 15:53:05 --> UTF-8 Support Enabled
INFO - 2024-01-01 15:53:05 --> Utf8 Class Initialized
INFO - 2024-01-01 15:53:05 --> URI Class Initialized
INFO - 2024-01-01 15:53:05 --> Router Class Initialized
INFO - 2024-01-01 15:53:05 --> Output Class Initialized
INFO - 2024-01-01 15:53:05 --> Security Class Initialized
DEBUG - 2024-01-01 15:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 15:53:05 --> Input Class Initialized
INFO - 2024-01-01 15:53:05 --> Language Class Initialized
INFO - 2024-01-01 15:53:05 --> Language Class Initialized
INFO - 2024-01-01 15:53:05 --> Config Class Initialized
INFO - 2024-01-01 15:53:05 --> Loader Class Initialized
INFO - 2024-01-01 15:53:05 --> Helper loaded: url_helper
INFO - 2024-01-01 15:53:05 --> Helper loaded: file_helper
INFO - 2024-01-01 15:53:05 --> Helper loaded: form_helper
INFO - 2024-01-01 15:53:05 --> Helper loaded: my_helper
INFO - 2024-01-01 15:53:05 --> Database Driver Class Initialized
INFO - 2024-01-01 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 15:53:05 --> Controller Class Initialized
INFO - 2024-01-01 15:53:05 --> Helper loaded: cookie_helper
INFO - 2024-01-01 15:53:05 --> Final output sent to browser
DEBUG - 2024-01-01 15:53:05 --> Total execution time: 0.0376
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 15:53:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 15:53:06 --> Utf8 Class Initialized
INFO - 2024-01-01 15:53:06 --> URI Class Initialized
INFO - 2024-01-01 15:53:06 --> Router Class Initialized
INFO - 2024-01-01 15:53:06 --> Output Class Initialized
INFO - 2024-01-01 15:53:06 --> Security Class Initialized
DEBUG - 2024-01-01 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 15:53:06 --> Input Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Loader Class Initialized
INFO - 2024-01-01 15:53:06 --> Helper loaded: url_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: file_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: form_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: my_helper
INFO - 2024-01-01 15:53:06 --> Database Driver Class Initialized
INFO - 2024-01-01 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 15:53:06 --> Controller Class Initialized
INFO - 2024-01-01 15:53:06 --> Helper loaded: cookie_helper
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 15:53:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 15:53:06 --> Utf8 Class Initialized
INFO - 2024-01-01 15:53:06 --> URI Class Initialized
INFO - 2024-01-01 15:53:06 --> Router Class Initialized
INFO - 2024-01-01 15:53:06 --> Output Class Initialized
INFO - 2024-01-01 15:53:06 --> Security Class Initialized
DEBUG - 2024-01-01 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 15:53:06 --> Input Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Loader Class Initialized
INFO - 2024-01-01 15:53:06 --> Helper loaded: url_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: file_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: form_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: my_helper
INFO - 2024-01-01 15:53:06 --> Database Driver Class Initialized
INFO - 2024-01-01 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 15:53:06 --> Controller Class Initialized
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 15:53:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 15:53:06 --> Utf8 Class Initialized
INFO - 2024-01-01 15:53:06 --> URI Class Initialized
INFO - 2024-01-01 15:53:06 --> Router Class Initialized
INFO - 2024-01-01 15:53:06 --> Output Class Initialized
INFO - 2024-01-01 15:53:06 --> Security Class Initialized
DEBUG - 2024-01-01 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 15:53:06 --> Input Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Loader Class Initialized
INFO - 2024-01-01 15:53:06 --> Helper loaded: url_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: file_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: form_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: my_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: cookie_helper
INFO - 2024-01-01 15:53:06 --> Database Driver Class Initialized
INFO - 2024-01-01 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 15:53:06 --> Controller Class Initialized
DEBUG - 2024-01-01 15:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-01 15:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-01 15:53:06 --> Final output sent to browser
DEBUG - 2024-01-01 15:53:06 --> Total execution time: 0.0518
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 15:53:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 15:53:06 --> Utf8 Class Initialized
INFO - 2024-01-01 15:53:06 --> URI Class Initialized
INFO - 2024-01-01 15:53:06 --> Router Class Initialized
INFO - 2024-01-01 15:53:06 --> Output Class Initialized
INFO - 2024-01-01 15:53:06 --> Security Class Initialized
DEBUG - 2024-01-01 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 15:53:06 --> Input Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Language Class Initialized
INFO - 2024-01-01 15:53:06 --> Config Class Initialized
INFO - 2024-01-01 15:53:06 --> Loader Class Initialized
INFO - 2024-01-01 15:53:06 --> Helper loaded: url_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: file_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: form_helper
INFO - 2024-01-01 15:53:06 --> Helper loaded: my_helper
INFO - 2024-01-01 15:53:06 --> Database Driver Class Initialized
INFO - 2024-01-01 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 15:53:06 --> Controller Class Initialized
DEBUG - 2024-01-01 15:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-01 15:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-01 15:53:06 --> Final output sent to browser
DEBUG - 2024-01-01 15:53:06 --> Total execution time: 0.1300
