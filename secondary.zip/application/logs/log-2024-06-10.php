<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-10 08:05:16 --> Config Class Initialized
INFO - 2024-06-10 08:05:16 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:16 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:16 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:16 --> URI Class Initialized
INFO - 2024-06-10 08:05:16 --> Router Class Initialized
INFO - 2024-06-10 08:05:16 --> Output Class Initialized
INFO - 2024-06-10 08:05:16 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:16 --> Input Class Initialized
INFO - 2024-06-10 08:05:16 --> Language Class Initialized
INFO - 2024-06-10 08:05:16 --> Language Class Initialized
INFO - 2024-06-10 08:05:16 --> Config Class Initialized
INFO - 2024-06-10 08:05:16 --> Loader Class Initialized
INFO - 2024-06-10 08:05:16 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:16 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:16 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:16 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:16 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:16 --> Controller Class Initialized
DEBUG - 2024-06-10 08:05:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-10 08:05:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:16 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:16 --> Total execution time: 0.0484
INFO - 2024-06-10 08:05:19 --> Config Class Initialized
INFO - 2024-06-10 08:05:19 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:19 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:19 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:19 --> URI Class Initialized
INFO - 2024-06-10 08:05:19 --> Router Class Initialized
INFO - 2024-06-10 08:05:19 --> Output Class Initialized
INFO - 2024-06-10 08:05:19 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:19 --> Input Class Initialized
INFO - 2024-06-10 08:05:19 --> Language Class Initialized
INFO - 2024-06-10 08:05:19 --> Language Class Initialized
INFO - 2024-06-10 08:05:19 --> Config Class Initialized
INFO - 2024-06-10 08:05:19 --> Loader Class Initialized
INFO - 2024-06-10 08:05:19 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:19 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:19 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:19 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:19 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:19 --> Controller Class Initialized
INFO - 2024-06-10 08:05:19 --> Helper loaded: cookie_helper
INFO - 2024-06-10 08:05:19 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:19 --> Total execution time: 0.0403
INFO - 2024-06-10 08:05:19 --> Config Class Initialized
INFO - 2024-06-10 08:05:19 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:19 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:19 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:19 --> URI Class Initialized
INFO - 2024-06-10 08:05:19 --> Router Class Initialized
INFO - 2024-06-10 08:05:19 --> Output Class Initialized
INFO - 2024-06-10 08:05:19 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:19 --> Input Class Initialized
INFO - 2024-06-10 08:05:19 --> Language Class Initialized
INFO - 2024-06-10 08:05:19 --> Language Class Initialized
INFO - 2024-06-10 08:05:19 --> Config Class Initialized
INFO - 2024-06-10 08:05:19 --> Loader Class Initialized
INFO - 2024-06-10 08:05:19 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:19 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:19 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:19 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:19 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:19 --> Controller Class Initialized
DEBUG - 2024-06-10 08:05:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-10 08:05:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:19 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:19 --> Total execution time: 0.0377
INFO - 2024-06-10 08:05:22 --> Config Class Initialized
INFO - 2024-06-10 08:05:22 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:22 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:22 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:22 --> URI Class Initialized
INFO - 2024-06-10 08:05:22 --> Router Class Initialized
INFO - 2024-06-10 08:05:22 --> Output Class Initialized
INFO - 2024-06-10 08:05:22 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:22 --> Input Class Initialized
INFO - 2024-06-10 08:05:22 --> Language Class Initialized
INFO - 2024-06-10 08:05:22 --> Language Class Initialized
INFO - 2024-06-10 08:05:22 --> Config Class Initialized
INFO - 2024-06-10 08:05:22 --> Loader Class Initialized
INFO - 2024-06-10 08:05:22 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:22 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:22 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:22 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:22 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:22 --> Controller Class Initialized
ERROR - 2024-06-10 08:05:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-10 08:05:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-10 08:05:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:22 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:22 --> Total execution time: 0.0345
INFO - 2024-06-10 08:05:24 --> Config Class Initialized
INFO - 2024-06-10 08:05:24 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:24 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:24 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:24 --> URI Class Initialized
INFO - 2024-06-10 08:05:24 --> Router Class Initialized
INFO - 2024-06-10 08:05:24 --> Output Class Initialized
INFO - 2024-06-10 08:05:24 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:24 --> Input Class Initialized
INFO - 2024-06-10 08:05:24 --> Language Class Initialized
INFO - 2024-06-10 08:05:24 --> Language Class Initialized
INFO - 2024-06-10 08:05:24 --> Config Class Initialized
INFO - 2024-06-10 08:05:24 --> Loader Class Initialized
INFO - 2024-06-10 08:05:24 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:24 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:24 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:24 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:24 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:24 --> Controller Class Initialized
DEBUG - 2024-06-10 08:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-10 08:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:24 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:24 --> Total execution time: 0.0322
INFO - 2024-06-10 08:05:24 --> Config Class Initialized
INFO - 2024-06-10 08:05:24 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:24 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:24 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:24 --> URI Class Initialized
INFO - 2024-06-10 08:05:24 --> Router Class Initialized
INFO - 2024-06-10 08:05:24 --> Output Class Initialized
INFO - 2024-06-10 08:05:24 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:24 --> Input Class Initialized
INFO - 2024-06-10 08:05:24 --> Language Class Initialized
INFO - 2024-06-10 08:05:24 --> Language Class Initialized
INFO - 2024-06-10 08:05:24 --> Config Class Initialized
INFO - 2024-06-10 08:05:24 --> Loader Class Initialized
INFO - 2024-06-10 08:05:24 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:24 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:24 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:24 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:24 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:24 --> Controller Class Initialized
INFO - 2024-06-10 08:05:37 --> Config Class Initialized
INFO - 2024-06-10 08:05:37 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:37 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:37 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:37 --> URI Class Initialized
INFO - 2024-06-10 08:05:37 --> Router Class Initialized
INFO - 2024-06-10 08:05:37 --> Output Class Initialized
INFO - 2024-06-10 08:05:37 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:37 --> Input Class Initialized
INFO - 2024-06-10 08:05:37 --> Language Class Initialized
INFO - 2024-06-10 08:05:37 --> Language Class Initialized
INFO - 2024-06-10 08:05:37 --> Config Class Initialized
INFO - 2024-06-10 08:05:37 --> Loader Class Initialized
INFO - 2024-06-10 08:05:37 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:37 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:37 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:37 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:37 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:37 --> Controller Class Initialized
ERROR - 2024-06-10 08:05:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:05:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-10 08:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-10 08:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:37 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:37 --> Total execution time: 0.0384
INFO - 2024-06-10 08:05:40 --> Config Class Initialized
INFO - 2024-06-10 08:05:40 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:40 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:40 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:40 --> URI Class Initialized
INFO - 2024-06-10 08:05:40 --> Router Class Initialized
INFO - 2024-06-10 08:05:40 --> Output Class Initialized
INFO - 2024-06-10 08:05:40 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:40 --> Input Class Initialized
INFO - 2024-06-10 08:05:40 --> Language Class Initialized
INFO - 2024-06-10 08:05:40 --> Language Class Initialized
INFO - 2024-06-10 08:05:40 --> Config Class Initialized
INFO - 2024-06-10 08:05:40 --> Loader Class Initialized
INFO - 2024-06-10 08:05:40 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:40 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:40 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:40 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:40 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:40 --> Controller Class Initialized
DEBUG - 2024-06-10 08:05:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-10 08:05:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:40 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:40 --> Total execution time: 0.0364
INFO - 2024-06-10 08:05:40 --> Config Class Initialized
INFO - 2024-06-10 08:05:40 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:40 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:40 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:40 --> URI Class Initialized
INFO - 2024-06-10 08:05:41 --> Router Class Initialized
INFO - 2024-06-10 08:05:41 --> Output Class Initialized
INFO - 2024-06-10 08:05:41 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:41 --> Input Class Initialized
INFO - 2024-06-10 08:05:41 --> Language Class Initialized
INFO - 2024-06-10 08:05:41 --> Language Class Initialized
INFO - 2024-06-10 08:05:41 --> Config Class Initialized
INFO - 2024-06-10 08:05:41 --> Loader Class Initialized
INFO - 2024-06-10 08:05:41 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:41 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:41 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:41 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:41 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:41 --> Controller Class Initialized
INFO - 2024-06-10 08:05:45 --> Config Class Initialized
INFO - 2024-06-10 08:05:45 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:45 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:45 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:45 --> URI Class Initialized
INFO - 2024-06-10 08:05:45 --> Router Class Initialized
INFO - 2024-06-10 08:05:45 --> Output Class Initialized
INFO - 2024-06-10 08:05:45 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:45 --> Input Class Initialized
INFO - 2024-06-10 08:05:45 --> Language Class Initialized
INFO - 2024-06-10 08:05:45 --> Language Class Initialized
INFO - 2024-06-10 08:05:45 --> Config Class Initialized
INFO - 2024-06-10 08:05:45 --> Loader Class Initialized
INFO - 2024-06-10 08:05:45 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:45 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:45 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:45 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:45 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:45 --> Controller Class Initialized
INFO - 2024-06-10 08:05:45 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:45 --> Total execution time: 0.0292
INFO - 2024-06-10 08:05:54 --> Config Class Initialized
INFO - 2024-06-10 08:05:54 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:05:54 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:05:54 --> Utf8 Class Initialized
INFO - 2024-06-10 08:05:54 --> URI Class Initialized
INFO - 2024-06-10 08:05:54 --> Router Class Initialized
INFO - 2024-06-10 08:05:54 --> Output Class Initialized
INFO - 2024-06-10 08:05:54 --> Security Class Initialized
DEBUG - 2024-06-10 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:05:54 --> Input Class Initialized
INFO - 2024-06-10 08:05:54 --> Language Class Initialized
INFO - 2024-06-10 08:05:54 --> Language Class Initialized
INFO - 2024-06-10 08:05:54 --> Config Class Initialized
INFO - 2024-06-10 08:05:54 --> Loader Class Initialized
INFO - 2024-06-10 08:05:54 --> Helper loaded: url_helper
INFO - 2024-06-10 08:05:54 --> Helper loaded: file_helper
INFO - 2024-06-10 08:05:54 --> Helper loaded: form_helper
INFO - 2024-06-10 08:05:54 --> Helper loaded: my_helper
INFO - 2024-06-10 08:05:54 --> Database Driver Class Initialized
INFO - 2024-06-10 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:05:54 --> Controller Class Initialized
DEBUG - 2024-06-10 08:05:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-10 08:05:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:05:54 --> Final output sent to browser
DEBUG - 2024-06-10 08:05:54 --> Total execution time: 0.0372
INFO - 2024-06-10 08:06:05 --> Config Class Initialized
INFO - 2024-06-10 08:06:05 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:06:05 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:06:05 --> Utf8 Class Initialized
INFO - 2024-06-10 08:06:05 --> URI Class Initialized
INFO - 2024-06-10 08:06:05 --> Router Class Initialized
INFO - 2024-06-10 08:06:05 --> Output Class Initialized
INFO - 2024-06-10 08:06:05 --> Security Class Initialized
DEBUG - 2024-06-10 08:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:06:05 --> Input Class Initialized
INFO - 2024-06-10 08:06:05 --> Language Class Initialized
INFO - 2024-06-10 08:06:05 --> Language Class Initialized
INFO - 2024-06-10 08:06:05 --> Config Class Initialized
INFO - 2024-06-10 08:06:05 --> Loader Class Initialized
INFO - 2024-06-10 08:06:05 --> Helper loaded: url_helper
INFO - 2024-06-10 08:06:05 --> Helper loaded: file_helper
INFO - 2024-06-10 08:06:05 --> Helper loaded: form_helper
INFO - 2024-06-10 08:06:05 --> Helper loaded: my_helper
INFO - 2024-06-10 08:06:05 --> Database Driver Class Initialized
INFO - 2024-06-10 08:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:06:05 --> Controller Class Initialized
INFO - 2024-06-10 08:06:05 --> Helper loaded: cookie_helper
INFO - 2024-06-10 08:06:05 --> Final output sent to browser
DEBUG - 2024-06-10 08:06:05 --> Total execution time: 0.0384
INFO - 2024-06-10 08:06:05 --> Config Class Initialized
INFO - 2024-06-10 08:06:05 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:06:05 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:06:05 --> Utf8 Class Initialized
INFO - 2024-06-10 08:06:05 --> URI Class Initialized
INFO - 2024-06-10 08:06:05 --> Router Class Initialized
INFO - 2024-06-10 08:06:05 --> Output Class Initialized
INFO - 2024-06-10 08:06:05 --> Security Class Initialized
DEBUG - 2024-06-10 08:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:06:05 --> Input Class Initialized
INFO - 2024-06-10 08:06:05 --> Language Class Initialized
INFO - 2024-06-10 08:06:05 --> Language Class Initialized
INFO - 2024-06-10 08:06:05 --> Config Class Initialized
INFO - 2024-06-10 08:06:05 --> Loader Class Initialized
INFO - 2024-06-10 08:06:05 --> Helper loaded: url_helper
INFO - 2024-06-10 08:06:05 --> Helper loaded: file_helper
INFO - 2024-06-10 08:06:05 --> Helper loaded: form_helper
INFO - 2024-06-10 08:06:05 --> Helper loaded: my_helper
INFO - 2024-06-10 08:06:05 --> Database Driver Class Initialized
INFO - 2024-06-10 08:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:06:05 --> Controller Class Initialized
DEBUG - 2024-06-10 08:06:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-10 08:06:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:06:05 --> Final output sent to browser
DEBUG - 2024-06-10 08:06:05 --> Total execution time: 0.0339
INFO - 2024-06-10 08:06:13 --> Config Class Initialized
INFO - 2024-06-10 08:06:13 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:06:13 --> Utf8 Class Initialized
INFO - 2024-06-10 08:06:13 --> URI Class Initialized
INFO - 2024-06-10 08:06:13 --> Router Class Initialized
INFO - 2024-06-10 08:06:13 --> Output Class Initialized
INFO - 2024-06-10 08:06:13 --> Security Class Initialized
DEBUG - 2024-06-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:06:13 --> Input Class Initialized
INFO - 2024-06-10 08:06:13 --> Language Class Initialized
INFO - 2024-06-10 08:06:13 --> Language Class Initialized
INFO - 2024-06-10 08:06:13 --> Config Class Initialized
INFO - 2024-06-10 08:06:13 --> Loader Class Initialized
INFO - 2024-06-10 08:06:13 --> Helper loaded: url_helper
INFO - 2024-06-10 08:06:13 --> Helper loaded: file_helper
INFO - 2024-06-10 08:06:13 --> Helper loaded: form_helper
INFO - 2024-06-10 08:06:13 --> Helper loaded: my_helper
INFO - 2024-06-10 08:06:13 --> Database Driver Class Initialized
INFO - 2024-06-10 08:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:06:13 --> Controller Class Initialized
ERROR - 2024-06-10 08:06:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:06:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:06:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:06:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:06:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 08:06:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-10 08:06:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-10 08:06:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:06:13 --> Final output sent to browser
DEBUG - 2024-06-10 08:06:13 --> Total execution time: 0.0324
INFO - 2024-06-10 08:12:08 --> Config Class Initialized
INFO - 2024-06-10 08:12:08 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:12:08 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:12:08 --> Utf8 Class Initialized
INFO - 2024-06-10 08:12:08 --> URI Class Initialized
INFO - 2024-06-10 08:12:08 --> Router Class Initialized
INFO - 2024-06-10 08:12:08 --> Output Class Initialized
INFO - 2024-06-10 08:12:08 --> Security Class Initialized
DEBUG - 2024-06-10 08:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:12:08 --> Input Class Initialized
INFO - 2024-06-10 08:12:08 --> Language Class Initialized
INFO - 2024-06-10 08:12:08 --> Language Class Initialized
INFO - 2024-06-10 08:12:08 --> Config Class Initialized
INFO - 2024-06-10 08:12:08 --> Loader Class Initialized
INFO - 2024-06-10 08:12:08 --> Helper loaded: url_helper
INFO - 2024-06-10 08:12:08 --> Helper loaded: file_helper
INFO - 2024-06-10 08:12:08 --> Helper loaded: form_helper
INFO - 2024-06-10 08:12:08 --> Helper loaded: my_helper
INFO - 2024-06-10 08:12:08 --> Database Driver Class Initialized
INFO - 2024-06-10 08:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:12:08 --> Controller Class Initialized
DEBUG - 2024-06-10 08:12:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-10 08:12:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 08:12:08 --> Final output sent to browser
DEBUG - 2024-06-10 08:12:08 --> Total execution time: 0.0306
INFO - 2024-06-10 08:12:08 --> Config Class Initialized
INFO - 2024-06-10 08:12:08 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:12:08 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:12:08 --> Utf8 Class Initialized
INFO - 2024-06-10 08:12:08 --> URI Class Initialized
INFO - 2024-06-10 08:12:08 --> Router Class Initialized
INFO - 2024-06-10 08:12:08 --> Output Class Initialized
INFO - 2024-06-10 08:12:08 --> Security Class Initialized
DEBUG - 2024-06-10 08:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:12:08 --> Input Class Initialized
INFO - 2024-06-10 08:12:08 --> Language Class Initialized
INFO - 2024-06-10 08:12:08 --> Language Class Initialized
INFO - 2024-06-10 08:12:08 --> Config Class Initialized
INFO - 2024-06-10 08:12:08 --> Loader Class Initialized
INFO - 2024-06-10 08:12:08 --> Helper loaded: url_helper
INFO - 2024-06-10 08:12:08 --> Helper loaded: file_helper
INFO - 2024-06-10 08:12:08 --> Helper loaded: form_helper
INFO - 2024-06-10 08:12:08 --> Helper loaded: my_helper
INFO - 2024-06-10 08:12:08 --> Database Driver Class Initialized
INFO - 2024-06-10 08:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:12:08 --> Controller Class Initialized
INFO - 2024-06-10 08:13:20 --> Config Class Initialized
INFO - 2024-06-10 08:13:20 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:13:20 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:13:20 --> Utf8 Class Initialized
INFO - 2024-06-10 08:13:20 --> URI Class Initialized
INFO - 2024-06-10 08:13:20 --> Router Class Initialized
INFO - 2024-06-10 08:13:20 --> Output Class Initialized
INFO - 2024-06-10 08:13:20 --> Security Class Initialized
DEBUG - 2024-06-10 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:13:20 --> Input Class Initialized
INFO - 2024-06-10 08:13:20 --> Language Class Initialized
INFO - 2024-06-10 08:13:20 --> Language Class Initialized
INFO - 2024-06-10 08:13:20 --> Config Class Initialized
INFO - 2024-06-10 08:13:20 --> Loader Class Initialized
INFO - 2024-06-10 08:13:20 --> Helper loaded: url_helper
INFO - 2024-06-10 08:13:20 --> Helper loaded: file_helper
INFO - 2024-06-10 08:13:20 --> Helper loaded: form_helper
INFO - 2024-06-10 08:13:20 --> Helper loaded: my_helper
INFO - 2024-06-10 08:13:20 --> Database Driver Class Initialized
INFO - 2024-06-10 08:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:13:20 --> Controller Class Initialized
INFO - 2024-06-10 08:13:20 --> Final output sent to browser
DEBUG - 2024-06-10 08:13:20 --> Total execution time: 0.0278
INFO - 2024-06-10 08:14:30 --> Config Class Initialized
INFO - 2024-06-10 08:14:30 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:14:30 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:14:30 --> Utf8 Class Initialized
INFO - 2024-06-10 08:14:30 --> URI Class Initialized
INFO - 2024-06-10 08:14:30 --> Router Class Initialized
INFO - 2024-06-10 08:14:30 --> Output Class Initialized
INFO - 2024-06-10 08:14:30 --> Security Class Initialized
DEBUG - 2024-06-10 08:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:14:30 --> Input Class Initialized
INFO - 2024-06-10 08:14:30 --> Language Class Initialized
INFO - 2024-06-10 08:14:30 --> Language Class Initialized
INFO - 2024-06-10 08:14:30 --> Config Class Initialized
INFO - 2024-06-10 08:14:30 --> Loader Class Initialized
INFO - 2024-06-10 08:14:30 --> Helper loaded: url_helper
INFO - 2024-06-10 08:14:30 --> Helper loaded: file_helper
INFO - 2024-06-10 08:14:30 --> Helper loaded: form_helper
INFO - 2024-06-10 08:14:30 --> Helper loaded: my_helper
INFO - 2024-06-10 08:14:30 --> Database Driver Class Initialized
INFO - 2024-06-10 08:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:14:30 --> Controller Class Initialized
INFO - 2024-06-10 08:14:30 --> Final output sent to browser
DEBUG - 2024-06-10 08:14:30 --> Total execution time: 0.0315
INFO - 2024-06-10 08:14:30 --> Config Class Initialized
INFO - 2024-06-10 08:14:30 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:14:30 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:14:30 --> Utf8 Class Initialized
INFO - 2024-06-10 08:14:30 --> URI Class Initialized
INFO - 2024-06-10 08:14:30 --> Router Class Initialized
INFO - 2024-06-10 08:14:30 --> Output Class Initialized
INFO - 2024-06-10 08:14:30 --> Security Class Initialized
DEBUG - 2024-06-10 08:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:14:30 --> Input Class Initialized
INFO - 2024-06-10 08:14:30 --> Language Class Initialized
INFO - 2024-06-10 08:14:30 --> Language Class Initialized
INFO - 2024-06-10 08:14:30 --> Config Class Initialized
INFO - 2024-06-10 08:14:30 --> Loader Class Initialized
INFO - 2024-06-10 08:14:30 --> Helper loaded: url_helper
INFO - 2024-06-10 08:14:30 --> Helper loaded: file_helper
INFO - 2024-06-10 08:14:30 --> Helper loaded: form_helper
INFO - 2024-06-10 08:14:30 --> Helper loaded: my_helper
INFO - 2024-06-10 08:14:30 --> Database Driver Class Initialized
INFO - 2024-06-10 08:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:14:30 --> Controller Class Initialized
INFO - 2024-06-10 08:14:31 --> Config Class Initialized
INFO - 2024-06-10 08:14:31 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:14:31 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:14:31 --> Utf8 Class Initialized
INFO - 2024-06-10 08:14:31 --> URI Class Initialized
INFO - 2024-06-10 08:14:31 --> Router Class Initialized
INFO - 2024-06-10 08:14:31 --> Output Class Initialized
INFO - 2024-06-10 08:14:31 --> Security Class Initialized
DEBUG - 2024-06-10 08:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:14:31 --> Input Class Initialized
INFO - 2024-06-10 08:14:31 --> Language Class Initialized
INFO - 2024-06-10 08:14:31 --> Language Class Initialized
INFO - 2024-06-10 08:14:31 --> Config Class Initialized
INFO - 2024-06-10 08:14:31 --> Loader Class Initialized
INFO - 2024-06-10 08:14:31 --> Helper loaded: url_helper
INFO - 2024-06-10 08:14:31 --> Helper loaded: file_helper
INFO - 2024-06-10 08:14:31 --> Helper loaded: form_helper
INFO - 2024-06-10 08:14:31 --> Helper loaded: my_helper
INFO - 2024-06-10 08:14:31 --> Database Driver Class Initialized
INFO - 2024-06-10 08:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:14:31 --> Controller Class Initialized
INFO - 2024-06-10 08:14:31 --> Final output sent to browser
DEBUG - 2024-06-10 08:14:31 --> Total execution time: 0.1475
INFO - 2024-06-10 08:19:54 --> Config Class Initialized
INFO - 2024-06-10 08:19:54 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:19:54 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:19:54 --> Utf8 Class Initialized
INFO - 2024-06-10 08:19:54 --> URI Class Initialized
INFO - 2024-06-10 08:19:54 --> Router Class Initialized
INFO - 2024-06-10 08:19:54 --> Output Class Initialized
INFO - 2024-06-10 08:19:54 --> Security Class Initialized
DEBUG - 2024-06-10 08:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:19:54 --> Input Class Initialized
INFO - 2024-06-10 08:19:54 --> Language Class Initialized
INFO - 2024-06-10 08:19:54 --> Language Class Initialized
INFO - 2024-06-10 08:19:54 --> Config Class Initialized
INFO - 2024-06-10 08:19:54 --> Loader Class Initialized
INFO - 2024-06-10 08:19:54 --> Helper loaded: url_helper
INFO - 2024-06-10 08:19:54 --> Helper loaded: file_helper
INFO - 2024-06-10 08:19:54 --> Helper loaded: form_helper
INFO - 2024-06-10 08:19:54 --> Helper loaded: my_helper
INFO - 2024-06-10 08:19:54 --> Database Driver Class Initialized
INFO - 2024-06-10 08:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:19:54 --> Controller Class Initialized
INFO - 2024-06-10 08:19:54 --> Final output sent to browser
DEBUG - 2024-06-10 08:19:54 --> Total execution time: 0.0325
INFO - 2024-06-10 08:19:54 --> Config Class Initialized
INFO - 2024-06-10 08:19:54 --> Hooks Class Initialized
DEBUG - 2024-06-10 08:19:54 --> UTF-8 Support Enabled
INFO - 2024-06-10 08:19:54 --> Utf8 Class Initialized
INFO - 2024-06-10 08:19:54 --> URI Class Initialized
INFO - 2024-06-10 08:19:54 --> Router Class Initialized
INFO - 2024-06-10 08:19:54 --> Output Class Initialized
INFO - 2024-06-10 08:19:54 --> Security Class Initialized
DEBUG - 2024-06-10 08:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 08:19:54 --> Input Class Initialized
INFO - 2024-06-10 08:19:54 --> Language Class Initialized
INFO - 2024-06-10 08:19:54 --> Language Class Initialized
INFO - 2024-06-10 08:19:54 --> Config Class Initialized
INFO - 2024-06-10 08:19:54 --> Loader Class Initialized
INFO - 2024-06-10 08:19:54 --> Helper loaded: url_helper
INFO - 2024-06-10 08:19:54 --> Helper loaded: file_helper
INFO - 2024-06-10 08:19:54 --> Helper loaded: form_helper
INFO - 2024-06-10 08:19:54 --> Helper loaded: my_helper
INFO - 2024-06-10 08:19:54 --> Database Driver Class Initialized
INFO - 2024-06-10 08:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 08:19:54 --> Controller Class Initialized
INFO - 2024-06-10 13:55:11 --> Config Class Initialized
INFO - 2024-06-10 13:55:11 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:11 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:11 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:11 --> URI Class Initialized
INFO - 2024-06-10 13:55:11 --> Router Class Initialized
INFO - 2024-06-10 13:55:11 --> Output Class Initialized
INFO - 2024-06-10 13:55:11 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:11 --> Input Class Initialized
INFO - 2024-06-10 13:55:11 --> Language Class Initialized
INFO - 2024-06-10 13:55:11 --> Language Class Initialized
INFO - 2024-06-10 13:55:11 --> Config Class Initialized
INFO - 2024-06-10 13:55:11 --> Loader Class Initialized
INFO - 2024-06-10 13:55:11 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:11 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:11 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:11 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:11 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:11 --> Controller Class Initialized
DEBUG - 2024-06-10 13:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-10 13:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:55:11 --> Final output sent to browser
DEBUG - 2024-06-10 13:55:11 --> Total execution time: 0.3199
INFO - 2024-06-10 13:55:14 --> Config Class Initialized
INFO - 2024-06-10 13:55:14 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:14 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:14 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:14 --> URI Class Initialized
INFO - 2024-06-10 13:55:14 --> Router Class Initialized
INFO - 2024-06-10 13:55:14 --> Output Class Initialized
INFO - 2024-06-10 13:55:14 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:14 --> Input Class Initialized
INFO - 2024-06-10 13:55:14 --> Language Class Initialized
INFO - 2024-06-10 13:55:14 --> Language Class Initialized
INFO - 2024-06-10 13:55:14 --> Config Class Initialized
INFO - 2024-06-10 13:55:14 --> Loader Class Initialized
INFO - 2024-06-10 13:55:14 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:14 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:14 --> Controller Class Initialized
INFO - 2024-06-10 13:55:14 --> Helper loaded: cookie_helper
INFO - 2024-06-10 13:55:14 --> Config Class Initialized
INFO - 2024-06-10 13:55:14 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:14 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:14 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:14 --> URI Class Initialized
INFO - 2024-06-10 13:55:14 --> Router Class Initialized
INFO - 2024-06-10 13:55:14 --> Output Class Initialized
INFO - 2024-06-10 13:55:14 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:14 --> Input Class Initialized
INFO - 2024-06-10 13:55:14 --> Language Class Initialized
INFO - 2024-06-10 13:55:14 --> Language Class Initialized
INFO - 2024-06-10 13:55:14 --> Config Class Initialized
INFO - 2024-06-10 13:55:14 --> Loader Class Initialized
INFO - 2024-06-10 13:55:14 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:14 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:14 --> Controller Class Initialized
INFO - 2024-06-10 13:55:14 --> Config Class Initialized
INFO - 2024-06-10 13:55:14 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:14 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:14 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:14 --> URI Class Initialized
INFO - 2024-06-10 13:55:14 --> Router Class Initialized
INFO - 2024-06-10 13:55:14 --> Output Class Initialized
INFO - 2024-06-10 13:55:14 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:14 --> Input Class Initialized
INFO - 2024-06-10 13:55:14 --> Language Class Initialized
INFO - 2024-06-10 13:55:14 --> Language Class Initialized
INFO - 2024-06-10 13:55:14 --> Config Class Initialized
INFO - 2024-06-10 13:55:14 --> Loader Class Initialized
INFO - 2024-06-10 13:55:14 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:14 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:15 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:15 --> Controller Class Initialized
DEBUG - 2024-06-10 13:55:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-10 13:55:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:55:15 --> Final output sent to browser
DEBUG - 2024-06-10 13:55:15 --> Total execution time: 0.0616
INFO - 2024-06-10 13:55:20 --> Config Class Initialized
INFO - 2024-06-10 13:55:20 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:20 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:20 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:20 --> URI Class Initialized
INFO - 2024-06-10 13:55:20 --> Router Class Initialized
INFO - 2024-06-10 13:55:20 --> Output Class Initialized
INFO - 2024-06-10 13:55:20 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:20 --> Input Class Initialized
INFO - 2024-06-10 13:55:20 --> Language Class Initialized
INFO - 2024-06-10 13:55:20 --> Language Class Initialized
INFO - 2024-06-10 13:55:20 --> Config Class Initialized
INFO - 2024-06-10 13:55:20 --> Loader Class Initialized
INFO - 2024-06-10 13:55:20 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:20 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:20 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:20 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:20 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:20 --> Controller Class Initialized
INFO - 2024-06-10 13:55:20 --> Helper loaded: cookie_helper
INFO - 2024-06-10 13:55:20 --> Final output sent to browser
DEBUG - 2024-06-10 13:55:20 --> Total execution time: 0.0307
INFO - 2024-06-10 13:55:20 --> Config Class Initialized
INFO - 2024-06-10 13:55:20 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:20 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:20 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:20 --> URI Class Initialized
INFO - 2024-06-10 13:55:20 --> Router Class Initialized
INFO - 2024-06-10 13:55:20 --> Output Class Initialized
INFO - 2024-06-10 13:55:20 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:20 --> Input Class Initialized
INFO - 2024-06-10 13:55:20 --> Language Class Initialized
INFO - 2024-06-10 13:55:20 --> Language Class Initialized
INFO - 2024-06-10 13:55:20 --> Config Class Initialized
INFO - 2024-06-10 13:55:20 --> Loader Class Initialized
INFO - 2024-06-10 13:55:20 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:20 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:20 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:20 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:20 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:20 --> Controller Class Initialized
DEBUG - 2024-06-10 13:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-10 13:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:55:20 --> Final output sent to browser
DEBUG - 2024-06-10 13:55:20 --> Total execution time: 0.0277
INFO - 2024-06-10 13:55:28 --> Config Class Initialized
INFO - 2024-06-10 13:55:28 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:28 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:28 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:28 --> URI Class Initialized
INFO - 2024-06-10 13:55:28 --> Router Class Initialized
INFO - 2024-06-10 13:55:28 --> Output Class Initialized
INFO - 2024-06-10 13:55:28 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:28 --> Input Class Initialized
INFO - 2024-06-10 13:55:28 --> Language Class Initialized
INFO - 2024-06-10 13:55:28 --> Language Class Initialized
INFO - 2024-06-10 13:55:28 --> Config Class Initialized
INFO - 2024-06-10 13:55:28 --> Loader Class Initialized
INFO - 2024-06-10 13:55:28 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:28 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:28 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:28 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:28 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:28 --> Controller Class Initialized
DEBUG - 2024-06-10 13:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-06-10 13:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:55:28 --> Final output sent to browser
DEBUG - 2024-06-10 13:55:28 --> Total execution time: 0.0298
INFO - 2024-06-10 13:55:30 --> Config Class Initialized
INFO - 2024-06-10 13:55:30 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:55:30 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:55:30 --> Utf8 Class Initialized
INFO - 2024-06-10 13:55:30 --> URI Class Initialized
INFO - 2024-06-10 13:55:30 --> Router Class Initialized
INFO - 2024-06-10 13:55:30 --> Output Class Initialized
INFO - 2024-06-10 13:55:30 --> Security Class Initialized
DEBUG - 2024-06-10 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:55:30 --> Input Class Initialized
INFO - 2024-06-10 13:55:30 --> Language Class Initialized
INFO - 2024-06-10 13:55:30 --> Language Class Initialized
INFO - 2024-06-10 13:55:30 --> Config Class Initialized
INFO - 2024-06-10 13:55:30 --> Loader Class Initialized
INFO - 2024-06-10 13:55:30 --> Helper loaded: url_helper
INFO - 2024-06-10 13:55:30 --> Helper loaded: file_helper
INFO - 2024-06-10 13:55:30 --> Helper loaded: form_helper
INFO - 2024-06-10 13:55:30 --> Helper loaded: my_helper
INFO - 2024-06-10 13:55:30 --> Database Driver Class Initialized
INFO - 2024-06-10 13:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:55:30 --> Controller Class Initialized
INFO - 2024-06-10 13:55:30 --> Final output sent to browser
DEBUG - 2024-06-10 13:55:30 --> Total execution time: 0.0340
INFO - 2024-06-10 13:56:21 --> Config Class Initialized
INFO - 2024-06-10 13:56:21 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:21 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:21 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:21 --> URI Class Initialized
INFO - 2024-06-10 13:56:21 --> Router Class Initialized
INFO - 2024-06-10 13:56:21 --> Output Class Initialized
INFO - 2024-06-10 13:56:21 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:21 --> Input Class Initialized
INFO - 2024-06-10 13:56:21 --> Language Class Initialized
INFO - 2024-06-10 13:56:21 --> Language Class Initialized
INFO - 2024-06-10 13:56:21 --> Config Class Initialized
INFO - 2024-06-10 13:56:21 --> Loader Class Initialized
INFO - 2024-06-10 13:56:21 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:21 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:21 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:21 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:21 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:22 --> Controller Class Initialized
INFO - 2024-06-10 13:56:22 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:22 --> Total execution time: 0.0585
INFO - 2024-06-10 13:56:26 --> Config Class Initialized
INFO - 2024-06-10 13:56:26 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:26 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:26 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:26 --> URI Class Initialized
INFO - 2024-06-10 13:56:26 --> Router Class Initialized
INFO - 2024-06-10 13:56:26 --> Output Class Initialized
INFO - 2024-06-10 13:56:26 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:26 --> Input Class Initialized
INFO - 2024-06-10 13:56:26 --> Language Class Initialized
INFO - 2024-06-10 13:56:26 --> Language Class Initialized
INFO - 2024-06-10 13:56:26 --> Config Class Initialized
INFO - 2024-06-10 13:56:26 --> Loader Class Initialized
INFO - 2024-06-10 13:56:26 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:26 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:26 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:26 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:26 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:26 --> Controller Class Initialized
INFO - 2024-06-10 13:56:26 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:26 --> Total execution time: 0.0290
INFO - 2024-06-10 13:56:28 --> Config Class Initialized
INFO - 2024-06-10 13:56:28 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:28 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:28 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:28 --> URI Class Initialized
INFO - 2024-06-10 13:56:28 --> Router Class Initialized
INFO - 2024-06-10 13:56:28 --> Output Class Initialized
INFO - 2024-06-10 13:56:28 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:28 --> Input Class Initialized
INFO - 2024-06-10 13:56:28 --> Language Class Initialized
INFO - 2024-06-10 13:56:28 --> Language Class Initialized
INFO - 2024-06-10 13:56:28 --> Config Class Initialized
INFO - 2024-06-10 13:56:28 --> Loader Class Initialized
INFO - 2024-06-10 13:56:28 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:28 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:28 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:28 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:28 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:28 --> Controller Class Initialized
INFO - 2024-06-10 13:56:28 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:28 --> Total execution time: 0.0266
INFO - 2024-06-10 13:56:34 --> Config Class Initialized
INFO - 2024-06-10 13:56:34 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:34 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:34 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:34 --> URI Class Initialized
INFO - 2024-06-10 13:56:34 --> Router Class Initialized
INFO - 2024-06-10 13:56:35 --> Output Class Initialized
INFO - 2024-06-10 13:56:35 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:35 --> Input Class Initialized
INFO - 2024-06-10 13:56:35 --> Language Class Initialized
INFO - 2024-06-10 13:56:35 --> Language Class Initialized
INFO - 2024-06-10 13:56:35 --> Config Class Initialized
INFO - 2024-06-10 13:56:35 --> Loader Class Initialized
INFO - 2024-06-10 13:56:35 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:35 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:35 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:35 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:35 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:35 --> Controller Class Initialized
ERROR - 2024-06-10 13:56:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 13:56:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 13:56:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 13:56:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 13:56:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-10 13:56:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-10 13:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-10 13:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:56:35 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:35 --> Total execution time: 0.0328
INFO - 2024-06-10 13:56:50 --> Config Class Initialized
INFO - 2024-06-10 13:56:50 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:50 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:50 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:50 --> URI Class Initialized
INFO - 2024-06-10 13:56:50 --> Router Class Initialized
INFO - 2024-06-10 13:56:50 --> Output Class Initialized
INFO - 2024-06-10 13:56:50 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:50 --> Input Class Initialized
INFO - 2024-06-10 13:56:50 --> Language Class Initialized
INFO - 2024-06-10 13:56:50 --> Language Class Initialized
INFO - 2024-06-10 13:56:50 --> Config Class Initialized
INFO - 2024-06-10 13:56:50 --> Loader Class Initialized
INFO - 2024-06-10 13:56:50 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:50 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:50 --> Controller Class Initialized
INFO - 2024-06-10 13:56:50 --> Helper loaded: cookie_helper
INFO - 2024-06-10 13:56:50 --> Config Class Initialized
INFO - 2024-06-10 13:56:50 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:50 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:50 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:50 --> URI Class Initialized
INFO - 2024-06-10 13:56:50 --> Router Class Initialized
INFO - 2024-06-10 13:56:50 --> Output Class Initialized
INFO - 2024-06-10 13:56:50 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:50 --> Input Class Initialized
INFO - 2024-06-10 13:56:50 --> Language Class Initialized
INFO - 2024-06-10 13:56:50 --> Language Class Initialized
INFO - 2024-06-10 13:56:50 --> Config Class Initialized
INFO - 2024-06-10 13:56:50 --> Loader Class Initialized
INFO - 2024-06-10 13:56:50 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:50 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:50 --> Controller Class Initialized
INFO - 2024-06-10 13:56:50 --> Config Class Initialized
INFO - 2024-06-10 13:56:50 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:50 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:50 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:50 --> URI Class Initialized
INFO - 2024-06-10 13:56:50 --> Router Class Initialized
INFO - 2024-06-10 13:56:50 --> Output Class Initialized
INFO - 2024-06-10 13:56:50 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:50 --> Input Class Initialized
INFO - 2024-06-10 13:56:50 --> Language Class Initialized
INFO - 2024-06-10 13:56:50 --> Language Class Initialized
INFO - 2024-06-10 13:56:50 --> Config Class Initialized
INFO - 2024-06-10 13:56:50 --> Loader Class Initialized
INFO - 2024-06-10 13:56:50 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:50 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:50 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:50 --> Controller Class Initialized
DEBUG - 2024-06-10 13:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-10 13:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:56:50 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:50 --> Total execution time: 0.0288
INFO - 2024-06-10 13:56:54 --> Config Class Initialized
INFO - 2024-06-10 13:56:54 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:54 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:54 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:54 --> URI Class Initialized
INFO - 2024-06-10 13:56:54 --> Router Class Initialized
INFO - 2024-06-10 13:56:54 --> Output Class Initialized
INFO - 2024-06-10 13:56:54 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:54 --> Input Class Initialized
INFO - 2024-06-10 13:56:54 --> Language Class Initialized
INFO - 2024-06-10 13:56:54 --> Language Class Initialized
INFO - 2024-06-10 13:56:54 --> Config Class Initialized
INFO - 2024-06-10 13:56:54 --> Loader Class Initialized
INFO - 2024-06-10 13:56:54 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:54 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:54 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:54 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:54 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:54 --> Controller Class Initialized
INFO - 2024-06-10 13:56:54 --> Helper loaded: cookie_helper
INFO - 2024-06-10 13:56:54 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:54 --> Total execution time: 0.1888
INFO - 2024-06-10 13:56:54 --> Config Class Initialized
INFO - 2024-06-10 13:56:54 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:54 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:54 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:54 --> URI Class Initialized
INFO - 2024-06-10 13:56:54 --> Router Class Initialized
INFO - 2024-06-10 13:56:54 --> Output Class Initialized
INFO - 2024-06-10 13:56:54 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:54 --> Input Class Initialized
INFO - 2024-06-10 13:56:54 --> Language Class Initialized
INFO - 2024-06-10 13:56:54 --> Language Class Initialized
INFO - 2024-06-10 13:56:54 --> Config Class Initialized
INFO - 2024-06-10 13:56:54 --> Loader Class Initialized
INFO - 2024-06-10 13:56:54 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:54 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:54 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:54 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:54 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:54 --> Controller Class Initialized
DEBUG - 2024-06-10 13:56:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-10 13:56:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:56:54 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:54 --> Total execution time: 0.0316
INFO - 2024-06-10 13:56:57 --> Config Class Initialized
INFO - 2024-06-10 13:56:57 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:57 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:57 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:57 --> URI Class Initialized
INFO - 2024-06-10 13:56:57 --> Router Class Initialized
INFO - 2024-06-10 13:56:57 --> Output Class Initialized
INFO - 2024-06-10 13:56:57 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:57 --> Input Class Initialized
INFO - 2024-06-10 13:56:57 --> Language Class Initialized
INFO - 2024-06-10 13:56:57 --> Language Class Initialized
INFO - 2024-06-10 13:56:57 --> Config Class Initialized
INFO - 2024-06-10 13:56:57 --> Loader Class Initialized
INFO - 2024-06-10 13:56:57 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:57 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:57 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:57 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:57 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:57 --> Controller Class Initialized
DEBUG - 2024-06-10 13:56:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-10 13:56:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:56:57 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:57 --> Total execution time: 0.0362
INFO - 2024-06-10 13:56:59 --> Config Class Initialized
INFO - 2024-06-10 13:56:59 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:56:59 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:56:59 --> Utf8 Class Initialized
INFO - 2024-06-10 13:56:59 --> URI Class Initialized
INFO - 2024-06-10 13:56:59 --> Router Class Initialized
INFO - 2024-06-10 13:56:59 --> Output Class Initialized
INFO - 2024-06-10 13:56:59 --> Security Class Initialized
DEBUG - 2024-06-10 13:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:56:59 --> Input Class Initialized
INFO - 2024-06-10 13:56:59 --> Language Class Initialized
INFO - 2024-06-10 13:56:59 --> Language Class Initialized
INFO - 2024-06-10 13:56:59 --> Config Class Initialized
INFO - 2024-06-10 13:56:59 --> Loader Class Initialized
INFO - 2024-06-10 13:56:59 --> Helper loaded: url_helper
INFO - 2024-06-10 13:56:59 --> Helper loaded: file_helper
INFO - 2024-06-10 13:56:59 --> Helper loaded: form_helper
INFO - 2024-06-10 13:56:59 --> Helper loaded: my_helper
INFO - 2024-06-10 13:56:59 --> Database Driver Class Initialized
INFO - 2024-06-10 13:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:56:59 --> Controller Class Initialized
DEBUG - 2024-06-10 13:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-10 13:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:56:59 --> Final output sent to browser
DEBUG - 2024-06-10 13:56:59 --> Total execution time: 0.0309
INFO - 2024-06-10 13:57:09 --> Config Class Initialized
INFO - 2024-06-10 13:57:09 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:57:09 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:57:09 --> Utf8 Class Initialized
INFO - 2024-06-10 13:57:09 --> URI Class Initialized
INFO - 2024-06-10 13:57:09 --> Router Class Initialized
INFO - 2024-06-10 13:57:09 --> Output Class Initialized
INFO - 2024-06-10 13:57:09 --> Security Class Initialized
DEBUG - 2024-06-10 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:57:09 --> Input Class Initialized
INFO - 2024-06-10 13:57:09 --> Language Class Initialized
INFO - 2024-06-10 13:57:09 --> Language Class Initialized
INFO - 2024-06-10 13:57:09 --> Config Class Initialized
INFO - 2024-06-10 13:57:09 --> Loader Class Initialized
INFO - 2024-06-10 13:57:09 --> Helper loaded: url_helper
INFO - 2024-06-10 13:57:09 --> Helper loaded: file_helper
INFO - 2024-06-10 13:57:09 --> Helper loaded: form_helper
INFO - 2024-06-10 13:57:09 --> Helper loaded: my_helper
INFO - 2024-06-10 13:57:09 --> Database Driver Class Initialized
INFO - 2024-06-10 13:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:57:09 --> Controller Class Initialized
DEBUG - 2024-06-10 13:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-10 13:57:09 --> Final output sent to browser
DEBUG - 2024-06-10 13:57:09 --> Total execution time: 0.1118
INFO - 2024-06-10 13:57:22 --> Config Class Initialized
INFO - 2024-06-10 13:57:22 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:57:22 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:57:22 --> Utf8 Class Initialized
INFO - 2024-06-10 13:57:22 --> URI Class Initialized
INFO - 2024-06-10 13:57:22 --> Router Class Initialized
INFO - 2024-06-10 13:57:22 --> Output Class Initialized
INFO - 2024-06-10 13:57:22 --> Security Class Initialized
DEBUG - 2024-06-10 13:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:57:22 --> Input Class Initialized
INFO - 2024-06-10 13:57:22 --> Language Class Initialized
INFO - 2024-06-10 13:57:22 --> Language Class Initialized
INFO - 2024-06-10 13:57:22 --> Config Class Initialized
INFO - 2024-06-10 13:57:22 --> Loader Class Initialized
INFO - 2024-06-10 13:57:22 --> Helper loaded: url_helper
INFO - 2024-06-10 13:57:22 --> Helper loaded: file_helper
INFO - 2024-06-10 13:57:22 --> Helper loaded: form_helper
INFO - 2024-06-10 13:57:22 --> Helper loaded: my_helper
INFO - 2024-06-10 13:57:22 --> Database Driver Class Initialized
INFO - 2024-06-10 13:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:57:22 --> Controller Class Initialized
DEBUG - 2024-06-10 13:57:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-10 13:57:22 --> Final output sent to browser
DEBUG - 2024-06-10 13:57:22 --> Total execution time: 0.0877
INFO - 2024-06-10 13:57:32 --> Config Class Initialized
INFO - 2024-06-10 13:57:32 --> Hooks Class Initialized
DEBUG - 2024-06-10 13:57:32 --> UTF-8 Support Enabled
INFO - 2024-06-10 13:57:32 --> Utf8 Class Initialized
INFO - 2024-06-10 13:57:32 --> URI Class Initialized
INFO - 2024-06-10 13:57:32 --> Router Class Initialized
INFO - 2024-06-10 13:57:32 --> Output Class Initialized
INFO - 2024-06-10 13:57:32 --> Security Class Initialized
DEBUG - 2024-06-10 13:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-10 13:57:32 --> Input Class Initialized
INFO - 2024-06-10 13:57:32 --> Language Class Initialized
INFO - 2024-06-10 13:57:32 --> Language Class Initialized
INFO - 2024-06-10 13:57:32 --> Config Class Initialized
INFO - 2024-06-10 13:57:32 --> Loader Class Initialized
INFO - 2024-06-10 13:57:32 --> Helper loaded: url_helper
INFO - 2024-06-10 13:57:32 --> Helper loaded: file_helper
INFO - 2024-06-10 13:57:32 --> Helper loaded: form_helper
INFO - 2024-06-10 13:57:32 --> Helper loaded: my_helper
INFO - 2024-06-10 13:57:32 --> Database Driver Class Initialized
INFO - 2024-06-10 13:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-10 13:57:32 --> Controller Class Initialized
DEBUG - 2024-06-10 13:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-10 13:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-10 13:57:32 --> Final output sent to browser
DEBUG - 2024-06-10 13:57:32 --> Total execution time: 0.0320
