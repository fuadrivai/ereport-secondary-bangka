<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-17 13:34:46 --> Config Class Initialized
INFO - 2024-03-17 13:34:46 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:34:46 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:34:46 --> Utf8 Class Initialized
INFO - 2024-03-17 13:34:46 --> URI Class Initialized
INFO - 2024-03-17 13:34:46 --> Router Class Initialized
INFO - 2024-03-17 13:34:46 --> Output Class Initialized
INFO - 2024-03-17 13:34:46 --> Security Class Initialized
DEBUG - 2024-03-17 13:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:34:46 --> Input Class Initialized
INFO - 2024-03-17 13:34:46 --> Language Class Initialized
INFO - 2024-03-17 13:34:46 --> Language Class Initialized
INFO - 2024-03-17 13:34:46 --> Config Class Initialized
INFO - 2024-03-17 13:34:46 --> Loader Class Initialized
INFO - 2024-03-17 13:34:46 --> Helper loaded: url_helper
INFO - 2024-03-17 13:34:46 --> Helper loaded: file_helper
INFO - 2024-03-17 13:34:46 --> Helper loaded: form_helper
INFO - 2024-03-17 13:34:46 --> Helper loaded: my_helper
INFO - 2024-03-17 13:34:46 --> Database Driver Class Initialized
INFO - 2024-03-17 13:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:34:46 --> Controller Class Initialized
DEBUG - 2024-03-17 13:34:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-17 13:34:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:34:46 --> Final output sent to browser
DEBUG - 2024-03-17 13:34:46 --> Total execution time: 0.1637
INFO - 2024-03-17 13:34:54 --> Config Class Initialized
INFO - 2024-03-17 13:34:54 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:34:54 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:34:54 --> Utf8 Class Initialized
INFO - 2024-03-17 13:34:54 --> URI Class Initialized
INFO - 2024-03-17 13:34:54 --> Router Class Initialized
INFO - 2024-03-17 13:34:54 --> Output Class Initialized
INFO - 2024-03-17 13:34:54 --> Security Class Initialized
DEBUG - 2024-03-17 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:34:54 --> Input Class Initialized
INFO - 2024-03-17 13:34:54 --> Language Class Initialized
INFO - 2024-03-17 13:34:54 --> Language Class Initialized
INFO - 2024-03-17 13:34:54 --> Config Class Initialized
INFO - 2024-03-17 13:34:54 --> Loader Class Initialized
INFO - 2024-03-17 13:34:54 --> Helper loaded: url_helper
INFO - 2024-03-17 13:34:54 --> Helper loaded: file_helper
INFO - 2024-03-17 13:34:54 --> Helper loaded: form_helper
INFO - 2024-03-17 13:34:54 --> Helper loaded: my_helper
INFO - 2024-03-17 13:34:54 --> Database Driver Class Initialized
INFO - 2024-03-17 13:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:34:54 --> Controller Class Initialized
INFO - 2024-03-17 13:34:54 --> Helper loaded: cookie_helper
INFO - 2024-03-17 13:34:54 --> Final output sent to browser
DEBUG - 2024-03-17 13:34:54 --> Total execution time: 0.0388
INFO - 2024-03-17 13:34:54 --> Config Class Initialized
INFO - 2024-03-17 13:34:54 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:34:54 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:34:54 --> Utf8 Class Initialized
INFO - 2024-03-17 13:34:54 --> URI Class Initialized
INFO - 2024-03-17 13:34:54 --> Router Class Initialized
INFO - 2024-03-17 13:34:54 --> Output Class Initialized
INFO - 2024-03-17 13:34:54 --> Security Class Initialized
DEBUG - 2024-03-17 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:34:54 --> Input Class Initialized
INFO - 2024-03-17 13:34:54 --> Language Class Initialized
INFO - 2024-03-17 13:34:54 --> Language Class Initialized
INFO - 2024-03-17 13:34:54 --> Config Class Initialized
INFO - 2024-03-17 13:34:54 --> Loader Class Initialized
INFO - 2024-03-17 13:34:54 --> Helper loaded: url_helper
INFO - 2024-03-17 13:34:54 --> Helper loaded: file_helper
INFO - 2024-03-17 13:34:54 --> Helper loaded: form_helper
INFO - 2024-03-17 13:34:54 --> Helper loaded: my_helper
INFO - 2024-03-17 13:34:54 --> Database Driver Class Initialized
INFO - 2024-03-17 13:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:34:54 --> Controller Class Initialized
DEBUG - 2024-03-17 13:34:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-17 13:34:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:34:54 --> Final output sent to browser
DEBUG - 2024-03-17 13:34:54 --> Total execution time: 0.0364
INFO - 2024-03-17 13:34:59 --> Config Class Initialized
INFO - 2024-03-17 13:34:59 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:34:59 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:34:59 --> Utf8 Class Initialized
INFO - 2024-03-17 13:34:59 --> URI Class Initialized
INFO - 2024-03-17 13:34:59 --> Router Class Initialized
INFO - 2024-03-17 13:34:59 --> Output Class Initialized
INFO - 2024-03-17 13:34:59 --> Security Class Initialized
DEBUG - 2024-03-17 13:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:34:59 --> Input Class Initialized
INFO - 2024-03-17 13:34:59 --> Language Class Initialized
INFO - 2024-03-17 13:34:59 --> Language Class Initialized
INFO - 2024-03-17 13:34:59 --> Config Class Initialized
INFO - 2024-03-17 13:34:59 --> Loader Class Initialized
INFO - 2024-03-17 13:34:59 --> Helper loaded: url_helper
INFO - 2024-03-17 13:34:59 --> Helper loaded: file_helper
INFO - 2024-03-17 13:34:59 --> Helper loaded: form_helper
INFO - 2024-03-17 13:34:59 --> Helper loaded: my_helper
INFO - 2024-03-17 13:34:59 --> Database Driver Class Initialized
INFO - 2024-03-17 13:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:34:59 --> Controller Class Initialized
DEBUG - 2024-03-17 13:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 13:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:34:59 --> Final output sent to browser
DEBUG - 2024-03-17 13:34:59 --> Total execution time: 0.0363
INFO - 2024-03-17 13:35:03 --> Config Class Initialized
INFO - 2024-03-17 13:35:03 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:35:03 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:35:03 --> Utf8 Class Initialized
INFO - 2024-03-17 13:35:03 --> URI Class Initialized
INFO - 2024-03-17 13:35:03 --> Router Class Initialized
INFO - 2024-03-17 13:35:03 --> Output Class Initialized
INFO - 2024-03-17 13:35:03 --> Security Class Initialized
DEBUG - 2024-03-17 13:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:35:03 --> Input Class Initialized
INFO - 2024-03-17 13:35:03 --> Language Class Initialized
INFO - 2024-03-17 13:35:03 --> Language Class Initialized
INFO - 2024-03-17 13:35:03 --> Config Class Initialized
INFO - 2024-03-17 13:35:03 --> Loader Class Initialized
INFO - 2024-03-17 13:35:03 --> Helper loaded: url_helper
INFO - 2024-03-17 13:35:03 --> Helper loaded: file_helper
INFO - 2024-03-17 13:35:03 --> Helper loaded: form_helper
INFO - 2024-03-17 13:35:03 --> Helper loaded: my_helper
INFO - 2024-03-17 13:35:03 --> Database Driver Class Initialized
INFO - 2024-03-17 13:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:35:03 --> Controller Class Initialized
DEBUG - 2024-03-17 13:35:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-17 13:35:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:35:03 --> Final output sent to browser
DEBUG - 2024-03-17 13:35:03 --> Total execution time: 0.0508
INFO - 2024-03-17 13:35:06 --> Config Class Initialized
INFO - 2024-03-17 13:35:06 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:35:06 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:35:06 --> Utf8 Class Initialized
INFO - 2024-03-17 13:35:06 --> URI Class Initialized
INFO - 2024-03-17 13:35:06 --> Router Class Initialized
INFO - 2024-03-17 13:35:06 --> Output Class Initialized
INFO - 2024-03-17 13:35:06 --> Security Class Initialized
DEBUG - 2024-03-17 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:35:06 --> Input Class Initialized
INFO - 2024-03-17 13:35:06 --> Language Class Initialized
INFO - 2024-03-17 13:35:06 --> Language Class Initialized
INFO - 2024-03-17 13:35:06 --> Config Class Initialized
INFO - 2024-03-17 13:35:06 --> Loader Class Initialized
INFO - 2024-03-17 13:35:06 --> Helper loaded: url_helper
INFO - 2024-03-17 13:35:06 --> Helper loaded: file_helper
INFO - 2024-03-17 13:35:06 --> Helper loaded: form_helper
INFO - 2024-03-17 13:35:06 --> Helper loaded: my_helper
INFO - 2024-03-17 13:35:06 --> Database Driver Class Initialized
INFO - 2024-03-17 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:35:06 --> Controller Class Initialized
DEBUG - 2024-03-17 13:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 13:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:35:06 --> Final output sent to browser
DEBUG - 2024-03-17 13:35:06 --> Total execution time: 0.0604
INFO - 2024-03-17 13:35:11 --> Config Class Initialized
INFO - 2024-03-17 13:35:11 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:35:11 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:35:11 --> Utf8 Class Initialized
INFO - 2024-03-17 13:35:11 --> URI Class Initialized
INFO - 2024-03-17 13:35:11 --> Router Class Initialized
INFO - 2024-03-17 13:35:11 --> Output Class Initialized
INFO - 2024-03-17 13:35:11 --> Security Class Initialized
DEBUG - 2024-03-17 13:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:35:11 --> Input Class Initialized
INFO - 2024-03-17 13:35:11 --> Language Class Initialized
INFO - 2024-03-17 13:35:11 --> Language Class Initialized
INFO - 2024-03-17 13:35:11 --> Config Class Initialized
INFO - 2024-03-17 13:35:11 --> Loader Class Initialized
INFO - 2024-03-17 13:35:11 --> Helper loaded: url_helper
INFO - 2024-03-17 13:35:11 --> Helper loaded: file_helper
INFO - 2024-03-17 13:35:11 --> Helper loaded: form_helper
INFO - 2024-03-17 13:35:11 --> Helper loaded: my_helper
INFO - 2024-03-17 13:35:11 --> Database Driver Class Initialized
INFO - 2024-03-17 13:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:35:11 --> Controller Class Initialized
DEBUG - 2024-03-17 13:35:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-03-17 13:35:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:35:11 --> Final output sent to browser
DEBUG - 2024-03-17 13:35:11 --> Total execution time: 0.0396
INFO - 2024-03-17 13:36:49 --> Config Class Initialized
INFO - 2024-03-17 13:36:49 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:36:49 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:36:49 --> Utf8 Class Initialized
INFO - 2024-03-17 13:36:49 --> URI Class Initialized
INFO - 2024-03-17 13:36:49 --> Router Class Initialized
INFO - 2024-03-17 13:36:49 --> Output Class Initialized
INFO - 2024-03-17 13:36:49 --> Security Class Initialized
DEBUG - 2024-03-17 13:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:36:49 --> Input Class Initialized
INFO - 2024-03-17 13:36:49 --> Language Class Initialized
INFO - 2024-03-17 13:36:49 --> Language Class Initialized
INFO - 2024-03-17 13:36:49 --> Config Class Initialized
INFO - 2024-03-17 13:36:49 --> Loader Class Initialized
INFO - 2024-03-17 13:36:49 --> Helper loaded: url_helper
INFO - 2024-03-17 13:36:49 --> Helper loaded: file_helper
INFO - 2024-03-17 13:36:49 --> Helper loaded: form_helper
INFO - 2024-03-17 13:36:49 --> Helper loaded: my_helper
INFO - 2024-03-17 13:36:49 --> Database Driver Class Initialized
INFO - 2024-03-17 13:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:36:49 --> Controller Class Initialized
INFO - 2024-03-17 13:36:49 --> Final output sent to browser
DEBUG - 2024-03-17 13:36:49 --> Total execution time: 0.0649
INFO - 2024-03-17 13:37:37 --> Config Class Initialized
INFO - 2024-03-17 13:37:37 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:37:37 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:37:37 --> Utf8 Class Initialized
INFO - 2024-03-17 13:37:37 --> URI Class Initialized
INFO - 2024-03-17 13:37:37 --> Router Class Initialized
INFO - 2024-03-17 13:37:37 --> Output Class Initialized
INFO - 2024-03-17 13:37:37 --> Security Class Initialized
DEBUG - 2024-03-17 13:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:37:37 --> Input Class Initialized
INFO - 2024-03-17 13:37:37 --> Language Class Initialized
INFO - 2024-03-17 13:37:37 --> Language Class Initialized
INFO - 2024-03-17 13:37:37 --> Config Class Initialized
INFO - 2024-03-17 13:37:37 --> Loader Class Initialized
INFO - 2024-03-17 13:37:37 --> Helper loaded: url_helper
INFO - 2024-03-17 13:37:37 --> Helper loaded: file_helper
INFO - 2024-03-17 13:37:37 --> Helper loaded: form_helper
INFO - 2024-03-17 13:37:37 --> Helper loaded: my_helper
INFO - 2024-03-17 13:37:37 --> Database Driver Class Initialized
INFO - 2024-03-17 13:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:37:37 --> Controller Class Initialized
INFO - 2024-03-17 13:37:37 --> Final output sent to browser
DEBUG - 2024-03-17 13:37:37 --> Total execution time: 0.0523
INFO - 2024-03-17 13:38:07 --> Config Class Initialized
INFO - 2024-03-17 13:38:07 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:38:07 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:38:07 --> Utf8 Class Initialized
INFO - 2024-03-17 13:38:07 --> URI Class Initialized
INFO - 2024-03-17 13:38:07 --> Router Class Initialized
INFO - 2024-03-17 13:38:07 --> Output Class Initialized
INFO - 2024-03-17 13:38:07 --> Security Class Initialized
DEBUG - 2024-03-17 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:38:07 --> Input Class Initialized
INFO - 2024-03-17 13:38:07 --> Language Class Initialized
INFO - 2024-03-17 13:38:07 --> Language Class Initialized
INFO - 2024-03-17 13:38:07 --> Config Class Initialized
INFO - 2024-03-17 13:38:07 --> Loader Class Initialized
INFO - 2024-03-17 13:38:07 --> Helper loaded: url_helper
INFO - 2024-03-17 13:38:07 --> Helper loaded: file_helper
INFO - 2024-03-17 13:38:07 --> Helper loaded: form_helper
INFO - 2024-03-17 13:38:07 --> Helper loaded: my_helper
INFO - 2024-03-17 13:38:07 --> Database Driver Class Initialized
INFO - 2024-03-17 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:38:07 --> Controller Class Initialized
INFO - 2024-03-17 13:38:07 --> Final output sent to browser
DEBUG - 2024-03-17 13:38:07 --> Total execution time: 0.0642
INFO - 2024-03-17 13:38:26 --> Config Class Initialized
INFO - 2024-03-17 13:38:26 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:38:26 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:38:26 --> Utf8 Class Initialized
INFO - 2024-03-17 13:38:26 --> URI Class Initialized
INFO - 2024-03-17 13:38:26 --> Router Class Initialized
INFO - 2024-03-17 13:38:26 --> Output Class Initialized
INFO - 2024-03-17 13:38:26 --> Security Class Initialized
DEBUG - 2024-03-17 13:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:38:26 --> Input Class Initialized
INFO - 2024-03-17 13:38:26 --> Language Class Initialized
INFO - 2024-03-17 13:38:26 --> Language Class Initialized
INFO - 2024-03-17 13:38:26 --> Config Class Initialized
INFO - 2024-03-17 13:38:26 --> Loader Class Initialized
INFO - 2024-03-17 13:38:26 --> Helper loaded: url_helper
INFO - 2024-03-17 13:38:26 --> Helper loaded: file_helper
INFO - 2024-03-17 13:38:26 --> Helper loaded: form_helper
INFO - 2024-03-17 13:38:26 --> Helper loaded: my_helper
INFO - 2024-03-17 13:38:26 --> Database Driver Class Initialized
INFO - 2024-03-17 13:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:38:26 --> Controller Class Initialized
INFO - 2024-03-17 13:38:26 --> Final output sent to browser
DEBUG - 2024-03-17 13:38:26 --> Total execution time: 0.0747
INFO - 2024-03-17 13:38:35 --> Config Class Initialized
INFO - 2024-03-17 13:38:35 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:38:35 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:38:35 --> Utf8 Class Initialized
INFO - 2024-03-17 13:38:35 --> URI Class Initialized
INFO - 2024-03-17 13:38:35 --> Router Class Initialized
INFO - 2024-03-17 13:38:35 --> Output Class Initialized
INFO - 2024-03-17 13:38:35 --> Security Class Initialized
DEBUG - 2024-03-17 13:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:38:35 --> Input Class Initialized
INFO - 2024-03-17 13:38:35 --> Language Class Initialized
INFO - 2024-03-17 13:38:35 --> Language Class Initialized
INFO - 2024-03-17 13:38:35 --> Config Class Initialized
INFO - 2024-03-17 13:38:35 --> Loader Class Initialized
INFO - 2024-03-17 13:38:35 --> Helper loaded: url_helper
INFO - 2024-03-17 13:38:35 --> Helper loaded: file_helper
INFO - 2024-03-17 13:38:35 --> Helper loaded: form_helper
INFO - 2024-03-17 13:38:35 --> Helper loaded: my_helper
INFO - 2024-03-17 13:38:35 --> Database Driver Class Initialized
INFO - 2024-03-17 13:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:38:35 --> Controller Class Initialized
DEBUG - 2024-03-17 13:38:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-17 13:38:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:38:35 --> Final output sent to browser
DEBUG - 2024-03-17 13:38:35 --> Total execution time: 0.0386
INFO - 2024-03-17 13:38:37 --> Config Class Initialized
INFO - 2024-03-17 13:38:37 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:38:37 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:38:37 --> Utf8 Class Initialized
INFO - 2024-03-17 13:38:37 --> URI Class Initialized
INFO - 2024-03-17 13:38:37 --> Router Class Initialized
INFO - 2024-03-17 13:38:37 --> Output Class Initialized
INFO - 2024-03-17 13:38:37 --> Security Class Initialized
DEBUG - 2024-03-17 13:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:38:37 --> Input Class Initialized
INFO - 2024-03-17 13:38:37 --> Language Class Initialized
INFO - 2024-03-17 13:38:37 --> Language Class Initialized
INFO - 2024-03-17 13:38:37 --> Config Class Initialized
INFO - 2024-03-17 13:38:37 --> Loader Class Initialized
INFO - 2024-03-17 13:38:37 --> Helper loaded: url_helper
INFO - 2024-03-17 13:38:37 --> Helper loaded: file_helper
INFO - 2024-03-17 13:38:37 --> Helper loaded: form_helper
INFO - 2024-03-17 13:38:37 --> Helper loaded: my_helper
INFO - 2024-03-17 13:38:37 --> Database Driver Class Initialized
INFO - 2024-03-17 13:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:38:37 --> Controller Class Initialized
ERROR - 2024-03-17 13:38:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:38:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:38:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:38:40 --> Final output sent to browser
DEBUG - 2024-03-17 13:38:40 --> Total execution time: 3.5730
INFO - 2024-03-17 13:41:12 --> Config Class Initialized
INFO - 2024-03-17 13:41:12 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:12 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:12 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:12 --> URI Class Initialized
INFO - 2024-03-17 13:41:12 --> Router Class Initialized
INFO - 2024-03-17 13:41:12 --> Output Class Initialized
INFO - 2024-03-17 13:41:12 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:12 --> Input Class Initialized
INFO - 2024-03-17 13:41:12 --> Language Class Initialized
INFO - 2024-03-17 13:41:12 --> Language Class Initialized
INFO - 2024-03-17 13:41:12 --> Config Class Initialized
INFO - 2024-03-17 13:41:12 --> Loader Class Initialized
INFO - 2024-03-17 13:41:12 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:12 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:12 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:12 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:12 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:12 --> Controller Class Initialized
ERROR - 2024-03-17 13:41:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:41:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:41:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:41:15 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:15 --> Total execution time: 3.3320
INFO - 2024-03-17 13:41:19 --> Config Class Initialized
INFO - 2024-03-17 13:41:19 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:19 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:19 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:19 --> URI Class Initialized
INFO - 2024-03-17 13:41:19 --> Router Class Initialized
INFO - 2024-03-17 13:41:19 --> Output Class Initialized
INFO - 2024-03-17 13:41:19 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:19 --> Input Class Initialized
INFO - 2024-03-17 13:41:19 --> Language Class Initialized
INFO - 2024-03-17 13:41:19 --> Language Class Initialized
INFO - 2024-03-17 13:41:19 --> Config Class Initialized
INFO - 2024-03-17 13:41:19 --> Loader Class Initialized
INFO - 2024-03-17 13:41:19 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:19 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:19 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:19 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:19 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:19 --> Controller Class Initialized
DEBUG - 2024-03-17 13:41:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 13:41:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:41:19 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:19 --> Total execution time: 0.0504
INFO - 2024-03-17 13:41:21 --> Config Class Initialized
INFO - 2024-03-17 13:41:21 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:21 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:21 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:21 --> URI Class Initialized
INFO - 2024-03-17 13:41:21 --> Router Class Initialized
INFO - 2024-03-17 13:41:21 --> Output Class Initialized
INFO - 2024-03-17 13:41:21 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:21 --> Input Class Initialized
INFO - 2024-03-17 13:41:21 --> Language Class Initialized
INFO - 2024-03-17 13:41:21 --> Language Class Initialized
INFO - 2024-03-17 13:41:21 --> Config Class Initialized
INFO - 2024-03-17 13:41:21 --> Loader Class Initialized
INFO - 2024-03-17 13:41:21 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:21 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:21 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:21 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:21 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:21 --> Controller Class Initialized
DEBUG - 2024-03-17 13:41:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-17 13:41:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:41:21 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:21 --> Total execution time: 0.0357
INFO - 2024-03-17 13:41:21 --> Config Class Initialized
INFO - 2024-03-17 13:41:21 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:21 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:21 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:21 --> URI Class Initialized
INFO - 2024-03-17 13:41:21 --> Router Class Initialized
INFO - 2024-03-17 13:41:21 --> Output Class Initialized
INFO - 2024-03-17 13:41:21 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:21 --> Input Class Initialized
INFO - 2024-03-17 13:41:21 --> Language Class Initialized
INFO - 2024-03-17 13:41:21 --> Language Class Initialized
INFO - 2024-03-17 13:41:21 --> Config Class Initialized
INFO - 2024-03-17 13:41:21 --> Loader Class Initialized
INFO - 2024-03-17 13:41:21 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:21 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:21 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:21 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:21 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:21 --> Controller Class Initialized
INFO - 2024-03-17 13:41:23 --> Config Class Initialized
INFO - 2024-03-17 13:41:23 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:23 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:23 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:23 --> URI Class Initialized
INFO - 2024-03-17 13:41:23 --> Router Class Initialized
INFO - 2024-03-17 13:41:23 --> Output Class Initialized
INFO - 2024-03-17 13:41:23 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:23 --> Input Class Initialized
INFO - 2024-03-17 13:41:23 --> Language Class Initialized
INFO - 2024-03-17 13:41:23 --> Language Class Initialized
INFO - 2024-03-17 13:41:23 --> Config Class Initialized
INFO - 2024-03-17 13:41:23 --> Loader Class Initialized
INFO - 2024-03-17 13:41:23 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:23 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:23 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:23 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:23 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:23 --> Controller Class Initialized
INFO - 2024-03-17 13:41:23 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:23 --> Total execution time: 0.0326
INFO - 2024-03-17 13:41:26 --> Config Class Initialized
INFO - 2024-03-17 13:41:26 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:26 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:26 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:26 --> URI Class Initialized
INFO - 2024-03-17 13:41:26 --> Router Class Initialized
INFO - 2024-03-17 13:41:26 --> Output Class Initialized
INFO - 2024-03-17 13:41:26 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:26 --> Input Class Initialized
INFO - 2024-03-17 13:41:26 --> Language Class Initialized
INFO - 2024-03-17 13:41:26 --> Language Class Initialized
INFO - 2024-03-17 13:41:26 --> Config Class Initialized
INFO - 2024-03-17 13:41:26 --> Loader Class Initialized
INFO - 2024-03-17 13:41:26 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:26 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:26 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:26 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:26 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:26 --> Controller Class Initialized
INFO - 2024-03-17 13:41:26 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:26 --> Total execution time: 0.0393
INFO - 2024-03-17 13:41:30 --> Config Class Initialized
INFO - 2024-03-17 13:41:30 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:30 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:30 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:30 --> URI Class Initialized
INFO - 2024-03-17 13:41:30 --> Router Class Initialized
INFO - 2024-03-17 13:41:30 --> Output Class Initialized
INFO - 2024-03-17 13:41:30 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:30 --> Input Class Initialized
INFO - 2024-03-17 13:41:30 --> Language Class Initialized
INFO - 2024-03-17 13:41:30 --> Language Class Initialized
INFO - 2024-03-17 13:41:30 --> Config Class Initialized
INFO - 2024-03-17 13:41:30 --> Loader Class Initialized
INFO - 2024-03-17 13:41:30 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:30 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:30 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:30 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:30 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:30 --> Controller Class Initialized
INFO - 2024-03-17 13:41:30 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:30 --> Total execution time: 0.0394
INFO - 2024-03-17 13:41:33 --> Config Class Initialized
INFO - 2024-03-17 13:41:33 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:33 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:33 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:33 --> URI Class Initialized
INFO - 2024-03-17 13:41:33 --> Router Class Initialized
INFO - 2024-03-17 13:41:33 --> Output Class Initialized
INFO - 2024-03-17 13:41:33 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:33 --> Input Class Initialized
INFO - 2024-03-17 13:41:33 --> Language Class Initialized
INFO - 2024-03-17 13:41:33 --> Language Class Initialized
INFO - 2024-03-17 13:41:33 --> Config Class Initialized
INFO - 2024-03-17 13:41:33 --> Loader Class Initialized
INFO - 2024-03-17 13:41:33 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:33 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:33 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:33 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:33 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:33 --> Controller Class Initialized
INFO - 2024-03-17 13:41:33 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:33 --> Total execution time: 0.0317
INFO - 2024-03-17 13:41:46 --> Config Class Initialized
INFO - 2024-03-17 13:41:46 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:46 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:46 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:46 --> URI Class Initialized
INFO - 2024-03-17 13:41:46 --> Router Class Initialized
INFO - 2024-03-17 13:41:46 --> Output Class Initialized
INFO - 2024-03-17 13:41:46 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:46 --> Input Class Initialized
INFO - 2024-03-17 13:41:46 --> Language Class Initialized
INFO - 2024-03-17 13:41:46 --> Language Class Initialized
INFO - 2024-03-17 13:41:46 --> Config Class Initialized
INFO - 2024-03-17 13:41:46 --> Loader Class Initialized
INFO - 2024-03-17 13:41:46 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:46 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:46 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:46 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:46 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:46 --> Controller Class Initialized
INFO - 2024-03-17 13:41:46 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:46 --> Total execution time: 0.1288
INFO - 2024-03-17 13:41:53 --> Config Class Initialized
INFO - 2024-03-17 13:41:53 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:53 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:53 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:53 --> URI Class Initialized
INFO - 2024-03-17 13:41:53 --> Router Class Initialized
INFO - 2024-03-17 13:41:53 --> Output Class Initialized
INFO - 2024-03-17 13:41:53 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:53 --> Input Class Initialized
INFO - 2024-03-17 13:41:53 --> Language Class Initialized
INFO - 2024-03-17 13:41:53 --> Language Class Initialized
INFO - 2024-03-17 13:41:53 --> Config Class Initialized
INFO - 2024-03-17 13:41:53 --> Loader Class Initialized
INFO - 2024-03-17 13:41:53 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:53 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:53 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:53 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:53 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:53 --> Controller Class Initialized
INFO - 2024-03-17 13:41:53 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:53 --> Total execution time: 0.0728
INFO - 2024-03-17 13:41:56 --> Config Class Initialized
INFO - 2024-03-17 13:41:56 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:41:56 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:41:56 --> Utf8 Class Initialized
INFO - 2024-03-17 13:41:56 --> URI Class Initialized
INFO - 2024-03-17 13:41:56 --> Router Class Initialized
INFO - 2024-03-17 13:41:56 --> Output Class Initialized
INFO - 2024-03-17 13:41:56 --> Security Class Initialized
DEBUG - 2024-03-17 13:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:41:56 --> Input Class Initialized
INFO - 2024-03-17 13:41:56 --> Language Class Initialized
INFO - 2024-03-17 13:41:56 --> Language Class Initialized
INFO - 2024-03-17 13:41:56 --> Config Class Initialized
INFO - 2024-03-17 13:41:56 --> Loader Class Initialized
INFO - 2024-03-17 13:41:56 --> Helper loaded: url_helper
INFO - 2024-03-17 13:41:56 --> Helper loaded: file_helper
INFO - 2024-03-17 13:41:56 --> Helper loaded: form_helper
INFO - 2024-03-17 13:41:56 --> Helper loaded: my_helper
INFO - 2024-03-17 13:41:56 --> Database Driver Class Initialized
INFO - 2024-03-17 13:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:41:56 --> Controller Class Initialized
INFO - 2024-03-17 13:41:56 --> Final output sent to browser
DEBUG - 2024-03-17 13:41:56 --> Total execution time: 0.0356
INFO - 2024-03-17 13:42:07 --> Config Class Initialized
INFO - 2024-03-17 13:42:07 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:42:07 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:42:07 --> Utf8 Class Initialized
INFO - 2024-03-17 13:42:07 --> URI Class Initialized
INFO - 2024-03-17 13:42:07 --> Router Class Initialized
INFO - 2024-03-17 13:42:07 --> Output Class Initialized
INFO - 2024-03-17 13:42:07 --> Security Class Initialized
DEBUG - 2024-03-17 13:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:42:07 --> Input Class Initialized
INFO - 2024-03-17 13:42:07 --> Language Class Initialized
INFO - 2024-03-17 13:42:07 --> Language Class Initialized
INFO - 2024-03-17 13:42:07 --> Config Class Initialized
INFO - 2024-03-17 13:42:07 --> Loader Class Initialized
INFO - 2024-03-17 13:42:07 --> Helper loaded: url_helper
INFO - 2024-03-17 13:42:07 --> Helper loaded: file_helper
INFO - 2024-03-17 13:42:07 --> Helper loaded: form_helper
INFO - 2024-03-17 13:42:07 --> Helper loaded: my_helper
INFO - 2024-03-17 13:42:07 --> Database Driver Class Initialized
INFO - 2024-03-17 13:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:42:07 --> Controller Class Initialized
DEBUG - 2024-03-17 13:42:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-03-17 13:42:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:42:07 --> Final output sent to browser
DEBUG - 2024-03-17 13:42:07 --> Total execution time: 0.0812
INFO - 2024-03-17 13:42:09 --> Config Class Initialized
INFO - 2024-03-17 13:42:09 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:42:09 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:42:09 --> Utf8 Class Initialized
INFO - 2024-03-17 13:42:09 --> URI Class Initialized
INFO - 2024-03-17 13:42:09 --> Router Class Initialized
INFO - 2024-03-17 13:42:09 --> Output Class Initialized
INFO - 2024-03-17 13:42:09 --> Security Class Initialized
DEBUG - 2024-03-17 13:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:42:09 --> Input Class Initialized
INFO - 2024-03-17 13:42:09 --> Language Class Initialized
INFO - 2024-03-17 13:42:09 --> Language Class Initialized
INFO - 2024-03-17 13:42:09 --> Config Class Initialized
INFO - 2024-03-17 13:42:09 --> Loader Class Initialized
INFO - 2024-03-17 13:42:09 --> Helper loaded: url_helper
INFO - 2024-03-17 13:42:09 --> Helper loaded: file_helper
INFO - 2024-03-17 13:42:09 --> Helper loaded: form_helper
INFO - 2024-03-17 13:42:09 --> Helper loaded: my_helper
INFO - 2024-03-17 13:42:09 --> Database Driver Class Initialized
INFO - 2024-03-17 13:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:42:09 --> Controller Class Initialized
DEBUG - 2024-03-17 13:42:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-17 13:42:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:42:09 --> Final output sent to browser
DEBUG - 2024-03-17 13:42:09 --> Total execution time: 0.0943
INFO - 2024-03-17 13:42:22 --> Config Class Initialized
INFO - 2024-03-17 13:42:22 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:42:22 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:42:22 --> Utf8 Class Initialized
INFO - 2024-03-17 13:42:22 --> URI Class Initialized
INFO - 2024-03-17 13:42:22 --> Router Class Initialized
INFO - 2024-03-17 13:42:22 --> Output Class Initialized
INFO - 2024-03-17 13:42:22 --> Security Class Initialized
DEBUG - 2024-03-17 13:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:42:22 --> Input Class Initialized
INFO - 2024-03-17 13:42:22 --> Language Class Initialized
INFO - 2024-03-17 13:42:22 --> Language Class Initialized
INFO - 2024-03-17 13:42:22 --> Config Class Initialized
INFO - 2024-03-17 13:42:22 --> Loader Class Initialized
INFO - 2024-03-17 13:42:22 --> Helper loaded: url_helper
INFO - 2024-03-17 13:42:22 --> Helper loaded: file_helper
INFO - 2024-03-17 13:42:22 --> Helper loaded: form_helper
INFO - 2024-03-17 13:42:22 --> Helper loaded: my_helper
INFO - 2024-03-17 13:42:22 --> Database Driver Class Initialized
INFO - 2024-03-17 13:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:42:22 --> Controller Class Initialized
ERROR - 2024-03-17 13:42:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:42:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:42:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:42:25 --> Config Class Initialized
INFO - 2024-03-17 13:42:25 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:42:25 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:42:25 --> Utf8 Class Initialized
INFO - 2024-03-17 13:42:25 --> URI Class Initialized
INFO - 2024-03-17 13:42:25 --> Router Class Initialized
INFO - 2024-03-17 13:42:25 --> Output Class Initialized
INFO - 2024-03-17 13:42:25 --> Security Class Initialized
DEBUG - 2024-03-17 13:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:42:25 --> Input Class Initialized
INFO - 2024-03-17 13:42:25 --> Language Class Initialized
INFO - 2024-03-17 13:42:25 --> Language Class Initialized
INFO - 2024-03-17 13:42:25 --> Config Class Initialized
INFO - 2024-03-17 13:42:25 --> Loader Class Initialized
INFO - 2024-03-17 13:42:25 --> Helper loaded: url_helper
INFO - 2024-03-17 13:42:25 --> Helper loaded: file_helper
INFO - 2024-03-17 13:42:25 --> Helper loaded: form_helper
INFO - 2024-03-17 13:42:25 --> Helper loaded: my_helper
INFO - 2024-03-17 13:42:25 --> Database Driver Class Initialized
INFO - 2024-03-17 13:42:25 --> Final output sent to browser
DEBUG - 2024-03-17 13:42:25 --> Total execution time: 3.3836
INFO - 2024-03-17 13:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:42:25 --> Controller Class Initialized
ERROR - 2024-03-17 13:42:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:42:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:42:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:42:27 --> Config Class Initialized
INFO - 2024-03-17 13:42:27 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:42:27 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:42:27 --> Utf8 Class Initialized
INFO - 2024-03-17 13:42:27 --> URI Class Initialized
INFO - 2024-03-17 13:42:27 --> Router Class Initialized
INFO - 2024-03-17 13:42:27 --> Output Class Initialized
INFO - 2024-03-17 13:42:27 --> Security Class Initialized
DEBUG - 2024-03-17 13:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:42:27 --> Input Class Initialized
INFO - 2024-03-17 13:42:27 --> Language Class Initialized
INFO - 2024-03-17 13:42:27 --> Language Class Initialized
INFO - 2024-03-17 13:42:27 --> Config Class Initialized
INFO - 2024-03-17 13:42:27 --> Loader Class Initialized
INFO - 2024-03-17 13:42:27 --> Helper loaded: url_helper
INFO - 2024-03-17 13:42:27 --> Helper loaded: file_helper
INFO - 2024-03-17 13:42:27 --> Helper loaded: form_helper
INFO - 2024-03-17 13:42:27 --> Helper loaded: my_helper
INFO - 2024-03-17 13:42:27 --> Database Driver Class Initialized
INFO - 2024-03-17 13:42:29 --> Final output sent to browser
DEBUG - 2024-03-17 13:42:29 --> Total execution time: 4.0403
INFO - 2024-03-17 13:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:42:29 --> Controller Class Initialized
ERROR - 2024-03-17 13:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:42:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:42:32 --> Final output sent to browser
DEBUG - 2024-03-17 13:42:32 --> Total execution time: 5.1692
INFO - 2024-03-17 13:45:11 --> Config Class Initialized
INFO - 2024-03-17 13:45:11 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:45:11 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:45:11 --> Utf8 Class Initialized
INFO - 2024-03-17 13:45:11 --> URI Class Initialized
INFO - 2024-03-17 13:45:11 --> Router Class Initialized
INFO - 2024-03-17 13:45:11 --> Output Class Initialized
INFO - 2024-03-17 13:45:11 --> Security Class Initialized
DEBUG - 2024-03-17 13:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:45:11 --> Input Class Initialized
INFO - 2024-03-17 13:45:11 --> Language Class Initialized
INFO - 2024-03-17 13:45:11 --> Language Class Initialized
INFO - 2024-03-17 13:45:11 --> Config Class Initialized
INFO - 2024-03-17 13:45:11 --> Loader Class Initialized
INFO - 2024-03-17 13:45:11 --> Helper loaded: url_helper
INFO - 2024-03-17 13:45:11 --> Helper loaded: file_helper
INFO - 2024-03-17 13:45:11 --> Helper loaded: form_helper
INFO - 2024-03-17 13:45:11 --> Helper loaded: my_helper
INFO - 2024-03-17 13:45:11 --> Database Driver Class Initialized
INFO - 2024-03-17 13:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:45:11 --> Controller Class Initialized
ERROR - 2024-03-17 13:45:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:45:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:45:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:45:14 --> Final output sent to browser
DEBUG - 2024-03-17 13:45:14 --> Total execution time: 3.1780
INFO - 2024-03-17 13:45:45 --> Config Class Initialized
INFO - 2024-03-17 13:45:45 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:45:45 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:45:45 --> Utf8 Class Initialized
INFO - 2024-03-17 13:45:45 --> URI Class Initialized
INFO - 2024-03-17 13:45:45 --> Router Class Initialized
INFO - 2024-03-17 13:45:45 --> Output Class Initialized
INFO - 2024-03-17 13:45:45 --> Security Class Initialized
DEBUG - 2024-03-17 13:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:45:45 --> Input Class Initialized
INFO - 2024-03-17 13:45:45 --> Language Class Initialized
INFO - 2024-03-17 13:45:45 --> Language Class Initialized
INFO - 2024-03-17 13:45:45 --> Config Class Initialized
INFO - 2024-03-17 13:45:45 --> Loader Class Initialized
INFO - 2024-03-17 13:45:45 --> Helper loaded: url_helper
INFO - 2024-03-17 13:45:45 --> Helper loaded: file_helper
INFO - 2024-03-17 13:45:45 --> Helper loaded: form_helper
INFO - 2024-03-17 13:45:45 --> Helper loaded: my_helper
INFO - 2024-03-17 13:45:45 --> Database Driver Class Initialized
INFO - 2024-03-17 13:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:45:45 --> Controller Class Initialized
DEBUG - 2024-03-17 13:45:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 13:45:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:45:45 --> Final output sent to browser
DEBUG - 2024-03-17 13:45:45 --> Total execution time: 0.0464
INFO - 2024-03-17 13:45:47 --> Config Class Initialized
INFO - 2024-03-17 13:45:47 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:45:47 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:45:47 --> Utf8 Class Initialized
INFO - 2024-03-17 13:45:47 --> URI Class Initialized
INFO - 2024-03-17 13:45:47 --> Router Class Initialized
INFO - 2024-03-17 13:45:47 --> Output Class Initialized
INFO - 2024-03-17 13:45:47 --> Security Class Initialized
DEBUG - 2024-03-17 13:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:45:47 --> Input Class Initialized
INFO - 2024-03-17 13:45:47 --> Language Class Initialized
INFO - 2024-03-17 13:45:47 --> Language Class Initialized
INFO - 2024-03-17 13:45:47 --> Config Class Initialized
INFO - 2024-03-17 13:45:47 --> Loader Class Initialized
INFO - 2024-03-17 13:45:47 --> Helper loaded: url_helper
INFO - 2024-03-17 13:45:47 --> Helper loaded: file_helper
INFO - 2024-03-17 13:45:47 --> Helper loaded: form_helper
INFO - 2024-03-17 13:45:47 --> Helper loaded: my_helper
INFO - 2024-03-17 13:45:47 --> Database Driver Class Initialized
INFO - 2024-03-17 13:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:45:47 --> Controller Class Initialized
DEBUG - 2024-03-17 13:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-17 13:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:45:47 --> Final output sent to browser
DEBUG - 2024-03-17 13:45:47 --> Total execution time: 0.0323
INFO - 2024-03-17 13:45:47 --> Config Class Initialized
INFO - 2024-03-17 13:45:47 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:45:47 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:45:47 --> Utf8 Class Initialized
INFO - 2024-03-17 13:45:47 --> URI Class Initialized
INFO - 2024-03-17 13:45:47 --> Router Class Initialized
INFO - 2024-03-17 13:45:47 --> Output Class Initialized
INFO - 2024-03-17 13:45:47 --> Security Class Initialized
DEBUG - 2024-03-17 13:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:45:47 --> Input Class Initialized
INFO - 2024-03-17 13:45:47 --> Language Class Initialized
INFO - 2024-03-17 13:45:47 --> Language Class Initialized
INFO - 2024-03-17 13:45:47 --> Config Class Initialized
INFO - 2024-03-17 13:45:47 --> Loader Class Initialized
INFO - 2024-03-17 13:45:47 --> Helper loaded: url_helper
INFO - 2024-03-17 13:45:47 --> Helper loaded: file_helper
INFO - 2024-03-17 13:45:47 --> Helper loaded: form_helper
INFO - 2024-03-17 13:45:47 --> Helper loaded: my_helper
INFO - 2024-03-17 13:45:47 --> Database Driver Class Initialized
INFO - 2024-03-17 13:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:45:47 --> Controller Class Initialized
INFO - 2024-03-17 13:45:49 --> Config Class Initialized
INFO - 2024-03-17 13:45:49 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:45:49 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:45:49 --> Utf8 Class Initialized
INFO - 2024-03-17 13:45:49 --> URI Class Initialized
INFO - 2024-03-17 13:45:49 --> Router Class Initialized
INFO - 2024-03-17 13:45:49 --> Output Class Initialized
INFO - 2024-03-17 13:45:49 --> Security Class Initialized
DEBUG - 2024-03-17 13:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:45:49 --> Input Class Initialized
INFO - 2024-03-17 13:45:49 --> Language Class Initialized
INFO - 2024-03-17 13:45:49 --> Language Class Initialized
INFO - 2024-03-17 13:45:49 --> Config Class Initialized
INFO - 2024-03-17 13:45:49 --> Loader Class Initialized
INFO - 2024-03-17 13:45:49 --> Helper loaded: url_helper
INFO - 2024-03-17 13:45:49 --> Helper loaded: file_helper
INFO - 2024-03-17 13:45:49 --> Helper loaded: form_helper
INFO - 2024-03-17 13:45:49 --> Helper loaded: my_helper
INFO - 2024-03-17 13:45:49 --> Database Driver Class Initialized
INFO - 2024-03-17 13:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:45:49 --> Controller Class Initialized
INFO - 2024-03-17 13:45:49 --> Final output sent to browser
DEBUG - 2024-03-17 13:45:49 --> Total execution time: 0.0291
INFO - 2024-03-17 13:45:55 --> Config Class Initialized
INFO - 2024-03-17 13:45:55 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:45:55 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:45:55 --> Utf8 Class Initialized
INFO - 2024-03-17 13:45:55 --> URI Class Initialized
INFO - 2024-03-17 13:45:55 --> Router Class Initialized
INFO - 2024-03-17 13:45:55 --> Output Class Initialized
INFO - 2024-03-17 13:45:55 --> Security Class Initialized
DEBUG - 2024-03-17 13:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:45:55 --> Input Class Initialized
INFO - 2024-03-17 13:45:55 --> Language Class Initialized
INFO - 2024-03-17 13:45:55 --> Language Class Initialized
INFO - 2024-03-17 13:45:55 --> Config Class Initialized
INFO - 2024-03-17 13:45:55 --> Loader Class Initialized
INFO - 2024-03-17 13:45:55 --> Helper loaded: url_helper
INFO - 2024-03-17 13:45:55 --> Helper loaded: file_helper
INFO - 2024-03-17 13:45:55 --> Helper loaded: form_helper
INFO - 2024-03-17 13:45:55 --> Helper loaded: my_helper
INFO - 2024-03-17 13:45:55 --> Database Driver Class Initialized
INFO - 2024-03-17 13:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:45:55 --> Controller Class Initialized
INFO - 2024-03-17 13:45:55 --> Final output sent to browser
DEBUG - 2024-03-17 13:45:55 --> Total execution time: 0.0548
INFO - 2024-03-17 13:46:21 --> Config Class Initialized
INFO - 2024-03-17 13:46:21 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:46:21 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:46:21 --> Utf8 Class Initialized
INFO - 2024-03-17 13:46:21 --> URI Class Initialized
INFO - 2024-03-17 13:46:21 --> Router Class Initialized
INFO - 2024-03-17 13:46:21 --> Output Class Initialized
INFO - 2024-03-17 13:46:21 --> Security Class Initialized
DEBUG - 2024-03-17 13:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:46:21 --> Input Class Initialized
INFO - 2024-03-17 13:46:21 --> Language Class Initialized
INFO - 2024-03-17 13:46:21 --> Language Class Initialized
INFO - 2024-03-17 13:46:21 --> Config Class Initialized
INFO - 2024-03-17 13:46:21 --> Loader Class Initialized
INFO - 2024-03-17 13:46:21 --> Helper loaded: url_helper
INFO - 2024-03-17 13:46:21 --> Helper loaded: file_helper
INFO - 2024-03-17 13:46:21 --> Helper loaded: form_helper
INFO - 2024-03-17 13:46:21 --> Helper loaded: my_helper
INFO - 2024-03-17 13:46:21 --> Database Driver Class Initialized
INFO - 2024-03-17 13:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:46:21 --> Controller Class Initialized
INFO - 2024-03-17 13:46:21 --> Final output sent to browser
DEBUG - 2024-03-17 13:46:21 --> Total execution time: 0.4514
INFO - 2024-03-17 13:46:31 --> Config Class Initialized
INFO - 2024-03-17 13:46:31 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:46:31 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:46:31 --> Utf8 Class Initialized
INFO - 2024-03-17 13:46:31 --> URI Class Initialized
INFO - 2024-03-17 13:46:31 --> Router Class Initialized
INFO - 2024-03-17 13:46:31 --> Output Class Initialized
INFO - 2024-03-17 13:46:31 --> Security Class Initialized
DEBUG - 2024-03-17 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:46:31 --> Input Class Initialized
INFO - 2024-03-17 13:46:31 --> Language Class Initialized
INFO - 2024-03-17 13:46:31 --> Language Class Initialized
INFO - 2024-03-17 13:46:31 --> Config Class Initialized
INFO - 2024-03-17 13:46:31 --> Loader Class Initialized
INFO - 2024-03-17 13:46:31 --> Helper loaded: url_helper
INFO - 2024-03-17 13:46:31 --> Helper loaded: file_helper
INFO - 2024-03-17 13:46:31 --> Helper loaded: form_helper
INFO - 2024-03-17 13:46:31 --> Helper loaded: my_helper
INFO - 2024-03-17 13:46:31 --> Database Driver Class Initialized
INFO - 2024-03-17 13:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:46:31 --> Controller Class Initialized
DEBUG - 2024-03-17 13:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-17 13:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 13:46:31 --> Final output sent to browser
DEBUG - 2024-03-17 13:46:31 --> Total execution time: 0.0806
INFO - 2024-03-17 13:46:33 --> Config Class Initialized
INFO - 2024-03-17 13:46:33 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:46:33 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:46:33 --> Utf8 Class Initialized
INFO - 2024-03-17 13:46:33 --> URI Class Initialized
INFO - 2024-03-17 13:46:33 --> Router Class Initialized
INFO - 2024-03-17 13:46:33 --> Output Class Initialized
INFO - 2024-03-17 13:46:33 --> Security Class Initialized
DEBUG - 2024-03-17 13:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:46:33 --> Input Class Initialized
INFO - 2024-03-17 13:46:33 --> Language Class Initialized
INFO - 2024-03-17 13:46:33 --> Language Class Initialized
INFO - 2024-03-17 13:46:33 --> Config Class Initialized
INFO - 2024-03-17 13:46:33 --> Loader Class Initialized
INFO - 2024-03-17 13:46:33 --> Helper loaded: url_helper
INFO - 2024-03-17 13:46:33 --> Helper loaded: file_helper
INFO - 2024-03-17 13:46:33 --> Helper loaded: form_helper
INFO - 2024-03-17 13:46:33 --> Helper loaded: my_helper
INFO - 2024-03-17 13:46:33 --> Database Driver Class Initialized
INFO - 2024-03-17 13:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:46:33 --> Controller Class Initialized
ERROR - 2024-03-17 13:46:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:46:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:46:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:46:37 --> Final output sent to browser
DEBUG - 2024-03-17 13:46:37 --> Total execution time: 3.6101
INFO - 2024-03-17 13:46:57 --> Config Class Initialized
INFO - 2024-03-17 13:46:57 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:46:57 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:46:57 --> Utf8 Class Initialized
INFO - 2024-03-17 13:46:57 --> URI Class Initialized
INFO - 2024-03-17 13:46:57 --> Router Class Initialized
INFO - 2024-03-17 13:46:57 --> Output Class Initialized
INFO - 2024-03-17 13:46:57 --> Security Class Initialized
DEBUG - 2024-03-17 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:46:57 --> Input Class Initialized
INFO - 2024-03-17 13:46:57 --> Language Class Initialized
INFO - 2024-03-17 13:46:57 --> Language Class Initialized
INFO - 2024-03-17 13:46:57 --> Config Class Initialized
INFO - 2024-03-17 13:46:57 --> Loader Class Initialized
INFO - 2024-03-17 13:46:57 --> Helper loaded: url_helper
INFO - 2024-03-17 13:46:57 --> Helper loaded: file_helper
INFO - 2024-03-17 13:46:57 --> Helper loaded: form_helper
INFO - 2024-03-17 13:46:57 --> Helper loaded: my_helper
INFO - 2024-03-17 13:46:57 --> Database Driver Class Initialized
INFO - 2024-03-17 13:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:46:57 --> Controller Class Initialized
ERROR - 2024-03-17 13:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:46:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:47:00 --> Final output sent to browser
DEBUG - 2024-03-17 13:47:00 --> Total execution time: 2.9365
INFO - 2024-03-17 13:47:25 --> Config Class Initialized
INFO - 2024-03-17 13:47:25 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:47:25 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:47:25 --> Utf8 Class Initialized
INFO - 2024-03-17 13:47:25 --> URI Class Initialized
INFO - 2024-03-17 13:47:25 --> Router Class Initialized
INFO - 2024-03-17 13:47:25 --> Output Class Initialized
INFO - 2024-03-17 13:47:25 --> Security Class Initialized
DEBUG - 2024-03-17 13:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:47:25 --> Input Class Initialized
INFO - 2024-03-17 13:47:25 --> Language Class Initialized
INFO - 2024-03-17 13:47:25 --> Language Class Initialized
INFO - 2024-03-17 13:47:25 --> Config Class Initialized
INFO - 2024-03-17 13:47:25 --> Loader Class Initialized
INFO - 2024-03-17 13:47:25 --> Helper loaded: url_helper
INFO - 2024-03-17 13:47:25 --> Helper loaded: file_helper
INFO - 2024-03-17 13:47:25 --> Helper loaded: form_helper
INFO - 2024-03-17 13:47:25 --> Helper loaded: my_helper
INFO - 2024-03-17 13:47:25 --> Database Driver Class Initialized
INFO - 2024-03-17 13:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:47:25 --> Controller Class Initialized
ERROR - 2024-03-17 13:47:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:47:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:47:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:47:28 --> Final output sent to browser
DEBUG - 2024-03-17 13:47:28 --> Total execution time: 3.2294
INFO - 2024-03-17 13:47:57 --> Config Class Initialized
INFO - 2024-03-17 13:47:57 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:47:57 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:47:57 --> Utf8 Class Initialized
INFO - 2024-03-17 13:47:57 --> URI Class Initialized
INFO - 2024-03-17 13:47:57 --> Router Class Initialized
INFO - 2024-03-17 13:47:57 --> Output Class Initialized
INFO - 2024-03-17 13:47:57 --> Security Class Initialized
DEBUG - 2024-03-17 13:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:47:57 --> Input Class Initialized
INFO - 2024-03-17 13:47:57 --> Language Class Initialized
INFO - 2024-03-17 13:47:57 --> Language Class Initialized
INFO - 2024-03-17 13:47:57 --> Config Class Initialized
INFO - 2024-03-17 13:47:57 --> Loader Class Initialized
INFO - 2024-03-17 13:47:57 --> Helper loaded: url_helper
INFO - 2024-03-17 13:47:57 --> Helper loaded: file_helper
INFO - 2024-03-17 13:47:57 --> Helper loaded: form_helper
INFO - 2024-03-17 13:47:57 --> Helper loaded: my_helper
INFO - 2024-03-17 13:47:57 --> Database Driver Class Initialized
INFO - 2024-03-17 13:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:47:57 --> Controller Class Initialized
ERROR - 2024-03-17 13:47:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:47:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:47:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:48:01 --> Final output sent to browser
DEBUG - 2024-03-17 13:48:01 --> Total execution time: 4.0237
INFO - 2024-03-17 13:48:25 --> Config Class Initialized
INFO - 2024-03-17 13:48:25 --> Hooks Class Initialized
DEBUG - 2024-03-17 13:48:25 --> UTF-8 Support Enabled
INFO - 2024-03-17 13:48:25 --> Utf8 Class Initialized
INFO - 2024-03-17 13:48:25 --> URI Class Initialized
INFO - 2024-03-17 13:48:25 --> Router Class Initialized
INFO - 2024-03-17 13:48:25 --> Output Class Initialized
INFO - 2024-03-17 13:48:25 --> Security Class Initialized
DEBUG - 2024-03-17 13:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 13:48:25 --> Input Class Initialized
INFO - 2024-03-17 13:48:25 --> Language Class Initialized
INFO - 2024-03-17 13:48:25 --> Language Class Initialized
INFO - 2024-03-17 13:48:25 --> Config Class Initialized
INFO - 2024-03-17 13:48:25 --> Loader Class Initialized
INFO - 2024-03-17 13:48:25 --> Helper loaded: url_helper
INFO - 2024-03-17 13:48:25 --> Helper loaded: file_helper
INFO - 2024-03-17 13:48:25 --> Helper loaded: form_helper
INFO - 2024-03-17 13:48:25 --> Helper loaded: my_helper
INFO - 2024-03-17 13:48:25 --> Database Driver Class Initialized
INFO - 2024-03-17 13:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 13:48:25 --> Controller Class Initialized
ERROR - 2024-03-17 13:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 13:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 13:48:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 13:48:28 --> Final output sent to browser
DEBUG - 2024-03-17 13:48:28 --> Total execution time: 3.0306
INFO - 2024-03-17 14:06:54 --> Config Class Initialized
INFO - 2024-03-17 14:06:54 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:06:54 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:06:54 --> Utf8 Class Initialized
INFO - 2024-03-17 14:06:54 --> URI Class Initialized
DEBUG - 2024-03-17 14:06:54 --> No URI present. Default controller set.
INFO - 2024-03-17 14:06:54 --> Router Class Initialized
INFO - 2024-03-17 14:06:54 --> Output Class Initialized
INFO - 2024-03-17 14:06:54 --> Security Class Initialized
DEBUG - 2024-03-17 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:06:54 --> Input Class Initialized
INFO - 2024-03-17 14:06:54 --> Language Class Initialized
INFO - 2024-03-17 14:06:54 --> Language Class Initialized
INFO - 2024-03-17 14:06:54 --> Config Class Initialized
INFO - 2024-03-17 14:06:54 --> Loader Class Initialized
INFO - 2024-03-17 14:06:54 --> Helper loaded: url_helper
INFO - 2024-03-17 14:06:54 --> Helper loaded: file_helper
INFO - 2024-03-17 14:06:54 --> Helper loaded: form_helper
INFO - 2024-03-17 14:06:54 --> Helper loaded: my_helper
INFO - 2024-03-17 14:06:54 --> Database Driver Class Initialized
INFO - 2024-03-17 14:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:06:54 --> Controller Class Initialized
INFO - 2024-03-17 14:06:54 --> Config Class Initialized
INFO - 2024-03-17 14:06:54 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:06:54 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:06:54 --> Utf8 Class Initialized
INFO - 2024-03-17 14:06:54 --> URI Class Initialized
INFO - 2024-03-17 14:06:54 --> Router Class Initialized
INFO - 2024-03-17 14:06:54 --> Output Class Initialized
INFO - 2024-03-17 14:06:54 --> Security Class Initialized
DEBUG - 2024-03-17 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:06:54 --> Input Class Initialized
INFO - 2024-03-17 14:06:54 --> Language Class Initialized
INFO - 2024-03-17 14:06:54 --> Language Class Initialized
INFO - 2024-03-17 14:06:54 --> Config Class Initialized
INFO - 2024-03-17 14:06:54 --> Loader Class Initialized
INFO - 2024-03-17 14:06:54 --> Helper loaded: url_helper
INFO - 2024-03-17 14:06:54 --> Helper loaded: file_helper
INFO - 2024-03-17 14:06:54 --> Helper loaded: form_helper
INFO - 2024-03-17 14:06:54 --> Helper loaded: my_helper
INFO - 2024-03-17 14:06:54 --> Database Driver Class Initialized
INFO - 2024-03-17 14:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:06:54 --> Controller Class Initialized
DEBUG - 2024-03-17 14:06:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-17 14:06:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:06:54 --> Final output sent to browser
DEBUG - 2024-03-17 14:06:54 --> Total execution time: 0.0422
INFO - 2024-03-17 14:06:59 --> Config Class Initialized
INFO - 2024-03-17 14:06:59 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:06:59 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:06:59 --> Utf8 Class Initialized
INFO - 2024-03-17 14:06:59 --> URI Class Initialized
INFO - 2024-03-17 14:06:59 --> Router Class Initialized
INFO - 2024-03-17 14:06:59 --> Output Class Initialized
INFO - 2024-03-17 14:06:59 --> Security Class Initialized
DEBUG - 2024-03-17 14:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:06:59 --> Input Class Initialized
INFO - 2024-03-17 14:06:59 --> Language Class Initialized
INFO - 2024-03-17 14:06:59 --> Language Class Initialized
INFO - 2024-03-17 14:06:59 --> Config Class Initialized
INFO - 2024-03-17 14:06:59 --> Loader Class Initialized
INFO - 2024-03-17 14:06:59 --> Helper loaded: url_helper
INFO - 2024-03-17 14:06:59 --> Helper loaded: file_helper
INFO - 2024-03-17 14:06:59 --> Helper loaded: form_helper
INFO - 2024-03-17 14:06:59 --> Helper loaded: my_helper
INFO - 2024-03-17 14:06:59 --> Database Driver Class Initialized
INFO - 2024-03-17 14:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:06:59 --> Controller Class Initialized
INFO - 2024-03-17 14:07:00 --> Helper loaded: cookie_helper
INFO - 2024-03-17 14:07:00 --> Final output sent to browser
DEBUG - 2024-03-17 14:07:00 --> Total execution time: 0.0416
INFO - 2024-03-17 14:07:00 --> Config Class Initialized
INFO - 2024-03-17 14:07:00 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:07:00 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:07:00 --> Utf8 Class Initialized
INFO - 2024-03-17 14:07:00 --> URI Class Initialized
INFO - 2024-03-17 14:07:00 --> Router Class Initialized
INFO - 2024-03-17 14:07:00 --> Output Class Initialized
INFO - 2024-03-17 14:07:00 --> Security Class Initialized
DEBUG - 2024-03-17 14:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:07:00 --> Input Class Initialized
INFO - 2024-03-17 14:07:00 --> Language Class Initialized
INFO - 2024-03-17 14:07:00 --> Language Class Initialized
INFO - 2024-03-17 14:07:00 --> Config Class Initialized
INFO - 2024-03-17 14:07:00 --> Loader Class Initialized
INFO - 2024-03-17 14:07:00 --> Helper loaded: url_helper
INFO - 2024-03-17 14:07:00 --> Helper loaded: file_helper
INFO - 2024-03-17 14:07:00 --> Helper loaded: form_helper
INFO - 2024-03-17 14:07:00 --> Helper loaded: my_helper
INFO - 2024-03-17 14:07:00 --> Database Driver Class Initialized
INFO - 2024-03-17 14:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:07:00 --> Controller Class Initialized
DEBUG - 2024-03-17 14:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-17 14:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:07:00 --> Final output sent to browser
DEBUG - 2024-03-17 14:07:00 --> Total execution time: 0.0448
INFO - 2024-03-17 14:07:03 --> Config Class Initialized
INFO - 2024-03-17 14:07:03 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:07:03 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:07:03 --> Utf8 Class Initialized
INFO - 2024-03-17 14:07:03 --> URI Class Initialized
INFO - 2024-03-17 14:07:03 --> Router Class Initialized
INFO - 2024-03-17 14:07:03 --> Output Class Initialized
INFO - 2024-03-17 14:07:03 --> Security Class Initialized
DEBUG - 2024-03-17 14:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:07:03 --> Input Class Initialized
INFO - 2024-03-17 14:07:03 --> Language Class Initialized
INFO - 2024-03-17 14:07:03 --> Language Class Initialized
INFO - 2024-03-17 14:07:03 --> Config Class Initialized
INFO - 2024-03-17 14:07:03 --> Loader Class Initialized
INFO - 2024-03-17 14:07:03 --> Helper loaded: url_helper
INFO - 2024-03-17 14:07:03 --> Helper loaded: file_helper
INFO - 2024-03-17 14:07:03 --> Helper loaded: form_helper
INFO - 2024-03-17 14:07:03 --> Helper loaded: my_helper
INFO - 2024-03-17 14:07:03 --> Database Driver Class Initialized
INFO - 2024-03-17 14:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:07:03 --> Controller Class Initialized
DEBUG - 2024-03-17 14:07:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 14:07:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:07:03 --> Final output sent to browser
DEBUG - 2024-03-17 14:07:03 --> Total execution time: 0.0495
INFO - 2024-03-17 14:07:05 --> Config Class Initialized
INFO - 2024-03-17 14:07:05 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:07:05 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:07:05 --> Utf8 Class Initialized
INFO - 2024-03-17 14:07:05 --> URI Class Initialized
INFO - 2024-03-17 14:07:05 --> Router Class Initialized
INFO - 2024-03-17 14:07:05 --> Output Class Initialized
INFO - 2024-03-17 14:07:05 --> Security Class Initialized
DEBUG - 2024-03-17 14:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:07:05 --> Input Class Initialized
INFO - 2024-03-17 14:07:05 --> Language Class Initialized
INFO - 2024-03-17 14:07:05 --> Language Class Initialized
INFO - 2024-03-17 14:07:05 --> Config Class Initialized
INFO - 2024-03-17 14:07:05 --> Loader Class Initialized
INFO - 2024-03-17 14:07:05 --> Helper loaded: url_helper
INFO - 2024-03-17 14:07:05 --> Helper loaded: file_helper
INFO - 2024-03-17 14:07:05 --> Helper loaded: form_helper
INFO - 2024-03-17 14:07:05 --> Helper loaded: my_helper
INFO - 2024-03-17 14:07:05 --> Database Driver Class Initialized
INFO - 2024-03-17 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:07:05 --> Controller Class Initialized
DEBUG - 2024-03-17 14:07:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-17 14:07:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:07:05 --> Final output sent to browser
DEBUG - 2024-03-17 14:07:05 --> Total execution time: 0.0393
INFO - 2024-03-17 14:07:08 --> Config Class Initialized
INFO - 2024-03-17 14:07:08 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:07:08 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:07:08 --> Utf8 Class Initialized
INFO - 2024-03-17 14:07:08 --> URI Class Initialized
INFO - 2024-03-17 14:07:08 --> Router Class Initialized
INFO - 2024-03-17 14:07:08 --> Output Class Initialized
INFO - 2024-03-17 14:07:08 --> Security Class Initialized
DEBUG - 2024-03-17 14:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:07:08 --> Input Class Initialized
INFO - 2024-03-17 14:07:08 --> Language Class Initialized
INFO - 2024-03-17 14:07:08 --> Language Class Initialized
INFO - 2024-03-17 14:07:08 --> Config Class Initialized
INFO - 2024-03-17 14:07:08 --> Loader Class Initialized
INFO - 2024-03-17 14:07:08 --> Helper loaded: url_helper
INFO - 2024-03-17 14:07:08 --> Helper loaded: file_helper
INFO - 2024-03-17 14:07:08 --> Helper loaded: form_helper
INFO - 2024-03-17 14:07:08 --> Helper loaded: my_helper
INFO - 2024-03-17 14:07:08 --> Database Driver Class Initialized
INFO - 2024-03-17 14:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:07:08 --> Controller Class Initialized
INFO - 2024-03-17 14:07:08 --> Final output sent to browser
DEBUG - 2024-03-17 14:07:08 --> Total execution time: 0.0381
INFO - 2024-03-17 14:12:00 --> Config Class Initialized
INFO - 2024-03-17 14:12:00 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:12:00 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:12:00 --> Utf8 Class Initialized
INFO - 2024-03-17 14:12:00 --> URI Class Initialized
INFO - 2024-03-17 14:12:00 --> Router Class Initialized
INFO - 2024-03-17 14:12:00 --> Output Class Initialized
INFO - 2024-03-17 14:12:00 --> Security Class Initialized
DEBUG - 2024-03-17 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:12:00 --> Input Class Initialized
INFO - 2024-03-17 14:12:00 --> Language Class Initialized
INFO - 2024-03-17 14:12:00 --> Language Class Initialized
INFO - 2024-03-17 14:12:00 --> Config Class Initialized
INFO - 2024-03-17 14:12:00 --> Loader Class Initialized
INFO - 2024-03-17 14:12:00 --> Helper loaded: url_helper
INFO - 2024-03-17 14:12:00 --> Helper loaded: file_helper
INFO - 2024-03-17 14:12:00 --> Helper loaded: form_helper
INFO - 2024-03-17 14:12:00 --> Helper loaded: my_helper
INFO - 2024-03-17 14:12:00 --> Database Driver Class Initialized
INFO - 2024-03-17 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:12:00 --> Controller Class Initialized
INFO - 2024-03-17 14:12:00 --> Final output sent to browser
DEBUG - 2024-03-17 14:12:00 --> Total execution time: 0.3693
INFO - 2024-03-17 14:12:08 --> Config Class Initialized
INFO - 2024-03-17 14:12:08 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:12:08 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:12:08 --> Utf8 Class Initialized
INFO - 2024-03-17 14:12:08 --> URI Class Initialized
INFO - 2024-03-17 14:12:08 --> Router Class Initialized
INFO - 2024-03-17 14:12:08 --> Output Class Initialized
INFO - 2024-03-17 14:12:08 --> Security Class Initialized
DEBUG - 2024-03-17 14:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:12:08 --> Input Class Initialized
INFO - 2024-03-17 14:12:08 --> Language Class Initialized
INFO - 2024-03-17 14:12:08 --> Language Class Initialized
INFO - 2024-03-17 14:12:08 --> Config Class Initialized
INFO - 2024-03-17 14:12:08 --> Loader Class Initialized
INFO - 2024-03-17 14:12:08 --> Helper loaded: url_helper
INFO - 2024-03-17 14:12:08 --> Helper loaded: file_helper
INFO - 2024-03-17 14:12:08 --> Helper loaded: form_helper
INFO - 2024-03-17 14:12:08 --> Helper loaded: my_helper
INFO - 2024-03-17 14:12:08 --> Database Driver Class Initialized
INFO - 2024-03-17 14:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:12:08 --> Controller Class Initialized
DEBUG - 2024-03-17 14:12:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 14:12:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:12:08 --> Final output sent to browser
DEBUG - 2024-03-17 14:12:08 --> Total execution time: 0.0440
INFO - 2024-03-17 14:45:00 --> Config Class Initialized
INFO - 2024-03-17 14:45:00 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:00 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:00 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:00 --> URI Class Initialized
INFO - 2024-03-17 14:45:00 --> Router Class Initialized
INFO - 2024-03-17 14:45:00 --> Output Class Initialized
INFO - 2024-03-17 14:45:00 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:00 --> Input Class Initialized
INFO - 2024-03-17 14:45:00 --> Language Class Initialized
INFO - 2024-03-17 14:45:00 --> Language Class Initialized
INFO - 2024-03-17 14:45:00 --> Config Class Initialized
INFO - 2024-03-17 14:45:00 --> Loader Class Initialized
INFO - 2024-03-17 14:45:00 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:00 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:00 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:00 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:00 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:00 --> Controller Class Initialized
DEBUG - 2024-03-17 14:45:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-17 14:45:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:45:00 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:00 --> Total execution time: 0.0447
INFO - 2024-03-17 14:45:01 --> Config Class Initialized
INFO - 2024-03-17 14:45:01 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:01 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:01 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:01 --> URI Class Initialized
INFO - 2024-03-17 14:45:01 --> Router Class Initialized
INFO - 2024-03-17 14:45:01 --> Output Class Initialized
INFO - 2024-03-17 14:45:01 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:01 --> Input Class Initialized
INFO - 2024-03-17 14:45:01 --> Language Class Initialized
INFO - 2024-03-17 14:45:01 --> Language Class Initialized
INFO - 2024-03-17 14:45:01 --> Config Class Initialized
INFO - 2024-03-17 14:45:01 --> Loader Class Initialized
INFO - 2024-03-17 14:45:01 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:01 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:01 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:01 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:01 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:01 --> Controller Class Initialized
INFO - 2024-03-17 14:45:14 --> Config Class Initialized
INFO - 2024-03-17 14:45:14 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:14 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:14 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:14 --> URI Class Initialized
INFO - 2024-03-17 14:45:14 --> Router Class Initialized
INFO - 2024-03-17 14:45:14 --> Output Class Initialized
INFO - 2024-03-17 14:45:14 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:14 --> Input Class Initialized
INFO - 2024-03-17 14:45:14 --> Language Class Initialized
INFO - 2024-03-17 14:45:14 --> Language Class Initialized
INFO - 2024-03-17 14:45:14 --> Config Class Initialized
INFO - 2024-03-17 14:45:14 --> Loader Class Initialized
INFO - 2024-03-17 14:45:14 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:14 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:14 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:14 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:14 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:14 --> Controller Class Initialized
INFO - 2024-03-17 14:45:14 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:14 --> Total execution time: 0.0522
INFO - 2024-03-17 14:45:23 --> Config Class Initialized
INFO - 2024-03-17 14:45:23 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:23 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:23 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:23 --> URI Class Initialized
INFO - 2024-03-17 14:45:23 --> Router Class Initialized
INFO - 2024-03-17 14:45:23 --> Output Class Initialized
INFO - 2024-03-17 14:45:23 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:23 --> Input Class Initialized
INFO - 2024-03-17 14:45:23 --> Language Class Initialized
INFO - 2024-03-17 14:45:23 --> Language Class Initialized
INFO - 2024-03-17 14:45:23 --> Config Class Initialized
INFO - 2024-03-17 14:45:23 --> Loader Class Initialized
INFO - 2024-03-17 14:45:23 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:23 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:23 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:23 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:23 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:23 --> Controller Class Initialized
INFO - 2024-03-17 14:45:23 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:23 --> Total execution time: 0.0889
INFO - 2024-03-17 14:45:28 --> Config Class Initialized
INFO - 2024-03-17 14:45:28 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:28 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:28 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:28 --> URI Class Initialized
INFO - 2024-03-17 14:45:28 --> Router Class Initialized
INFO - 2024-03-17 14:45:28 --> Output Class Initialized
INFO - 2024-03-17 14:45:28 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:28 --> Input Class Initialized
INFO - 2024-03-17 14:45:28 --> Language Class Initialized
INFO - 2024-03-17 14:45:28 --> Language Class Initialized
INFO - 2024-03-17 14:45:28 --> Config Class Initialized
INFO - 2024-03-17 14:45:28 --> Loader Class Initialized
INFO - 2024-03-17 14:45:28 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:28 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:28 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:28 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:28 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:28 --> Controller Class Initialized
INFO - 2024-03-17 14:45:28 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:28 --> Total execution time: 0.0362
INFO - 2024-03-17 14:45:40 --> Config Class Initialized
INFO - 2024-03-17 14:45:40 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:40 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:40 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:40 --> URI Class Initialized
INFO - 2024-03-17 14:45:40 --> Router Class Initialized
INFO - 2024-03-17 14:45:40 --> Output Class Initialized
INFO - 2024-03-17 14:45:40 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:40 --> Input Class Initialized
INFO - 2024-03-17 14:45:40 --> Language Class Initialized
INFO - 2024-03-17 14:45:40 --> Language Class Initialized
INFO - 2024-03-17 14:45:40 --> Config Class Initialized
INFO - 2024-03-17 14:45:40 --> Loader Class Initialized
INFO - 2024-03-17 14:45:40 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:40 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:40 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:40 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:40 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:40 --> Controller Class Initialized
INFO - 2024-03-17 14:45:40 --> Config Class Initialized
INFO - 2024-03-17 14:45:40 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:40 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:40 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:40 --> URI Class Initialized
INFO - 2024-03-17 14:45:40 --> Router Class Initialized
INFO - 2024-03-17 14:45:40 --> Output Class Initialized
INFO - 2024-03-17 14:45:40 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:40 --> Input Class Initialized
INFO - 2024-03-17 14:45:40 --> Language Class Initialized
INFO - 2024-03-17 14:45:40 --> Language Class Initialized
INFO - 2024-03-17 14:45:40 --> Config Class Initialized
INFO - 2024-03-17 14:45:40 --> Loader Class Initialized
INFO - 2024-03-17 14:45:40 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:40 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:40 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:40 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:40 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:40 --> Controller Class Initialized
DEBUG - 2024-03-17 14:45:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-17 14:45:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:45:40 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:40 --> Total execution time: 0.0299
INFO - 2024-03-17 14:45:42 --> Config Class Initialized
INFO - 2024-03-17 14:45:42 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:42 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:42 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:42 --> URI Class Initialized
INFO - 2024-03-17 14:45:42 --> Router Class Initialized
INFO - 2024-03-17 14:45:42 --> Output Class Initialized
INFO - 2024-03-17 14:45:42 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:42 --> Input Class Initialized
INFO - 2024-03-17 14:45:42 --> Language Class Initialized
INFO - 2024-03-17 14:45:42 --> Language Class Initialized
INFO - 2024-03-17 14:45:42 --> Config Class Initialized
INFO - 2024-03-17 14:45:42 --> Loader Class Initialized
INFO - 2024-03-17 14:45:42 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:42 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:42 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:42 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:42 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:42 --> Controller Class Initialized
INFO - 2024-03-17 14:45:42 --> Helper loaded: cookie_helper
INFO - 2024-03-17 14:45:42 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:42 --> Total execution time: 0.0400
INFO - 2024-03-17 14:45:43 --> Config Class Initialized
INFO - 2024-03-17 14:45:43 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:43 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:43 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:43 --> URI Class Initialized
INFO - 2024-03-17 14:45:43 --> Router Class Initialized
INFO - 2024-03-17 14:45:43 --> Output Class Initialized
INFO - 2024-03-17 14:45:43 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:43 --> Input Class Initialized
INFO - 2024-03-17 14:45:43 --> Language Class Initialized
INFO - 2024-03-17 14:45:43 --> Language Class Initialized
INFO - 2024-03-17 14:45:43 --> Config Class Initialized
INFO - 2024-03-17 14:45:43 --> Loader Class Initialized
INFO - 2024-03-17 14:45:43 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:43 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:43 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:43 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:43 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:43 --> Controller Class Initialized
DEBUG - 2024-03-17 14:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-17 14:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:45:43 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:43 --> Total execution time: 0.0352
INFO - 2024-03-17 14:45:47 --> Config Class Initialized
INFO - 2024-03-17 14:45:47 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:47 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:47 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:47 --> URI Class Initialized
INFO - 2024-03-17 14:45:47 --> Router Class Initialized
INFO - 2024-03-17 14:45:47 --> Output Class Initialized
INFO - 2024-03-17 14:45:47 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:47 --> Input Class Initialized
INFO - 2024-03-17 14:45:47 --> Language Class Initialized
INFO - 2024-03-17 14:45:47 --> Language Class Initialized
INFO - 2024-03-17 14:45:47 --> Config Class Initialized
INFO - 2024-03-17 14:45:47 --> Loader Class Initialized
INFO - 2024-03-17 14:45:47 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:47 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:47 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:47 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:47 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:47 --> Controller Class Initialized
DEBUG - 2024-03-17 14:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 14:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:45:47 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:47 --> Total execution time: 0.0280
INFO - 2024-03-17 14:45:50 --> Config Class Initialized
INFO - 2024-03-17 14:45:50 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:50 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:50 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:50 --> URI Class Initialized
INFO - 2024-03-17 14:45:50 --> Router Class Initialized
INFO - 2024-03-17 14:45:50 --> Output Class Initialized
INFO - 2024-03-17 14:45:50 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:50 --> Input Class Initialized
INFO - 2024-03-17 14:45:50 --> Language Class Initialized
INFO - 2024-03-17 14:45:50 --> Language Class Initialized
INFO - 2024-03-17 14:45:50 --> Config Class Initialized
INFO - 2024-03-17 14:45:50 --> Loader Class Initialized
INFO - 2024-03-17 14:45:50 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:50 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:50 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:50 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:50 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:50 --> Controller Class Initialized
DEBUG - 2024-03-17 14:45:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-17 14:45:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:45:50 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:50 --> Total execution time: 0.0384
INFO - 2024-03-17 14:45:50 --> Config Class Initialized
INFO - 2024-03-17 14:45:50 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:50 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:50 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:50 --> URI Class Initialized
INFO - 2024-03-17 14:45:50 --> Router Class Initialized
INFO - 2024-03-17 14:45:50 --> Output Class Initialized
INFO - 2024-03-17 14:45:50 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:50 --> Input Class Initialized
INFO - 2024-03-17 14:45:50 --> Language Class Initialized
INFO - 2024-03-17 14:45:50 --> Language Class Initialized
INFO - 2024-03-17 14:45:50 --> Config Class Initialized
INFO - 2024-03-17 14:45:50 --> Loader Class Initialized
INFO - 2024-03-17 14:45:50 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:50 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:50 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:50 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:50 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:50 --> Controller Class Initialized
INFO - 2024-03-17 14:45:54 --> Config Class Initialized
INFO - 2024-03-17 14:45:54 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:54 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:54 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:54 --> URI Class Initialized
INFO - 2024-03-17 14:45:54 --> Router Class Initialized
INFO - 2024-03-17 14:45:54 --> Output Class Initialized
INFO - 2024-03-17 14:45:54 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:54 --> Input Class Initialized
INFO - 2024-03-17 14:45:54 --> Language Class Initialized
INFO - 2024-03-17 14:45:54 --> Language Class Initialized
INFO - 2024-03-17 14:45:54 --> Config Class Initialized
INFO - 2024-03-17 14:45:54 --> Loader Class Initialized
INFO - 2024-03-17 14:45:54 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:54 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:54 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:54 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:54 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:54 --> Controller Class Initialized
INFO - 2024-03-17 14:45:54 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:54 --> Total execution time: 0.0345
INFO - 2024-03-17 14:45:59 --> Config Class Initialized
INFO - 2024-03-17 14:45:59 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:45:59 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:45:59 --> Utf8 Class Initialized
INFO - 2024-03-17 14:45:59 --> URI Class Initialized
INFO - 2024-03-17 14:45:59 --> Router Class Initialized
INFO - 2024-03-17 14:45:59 --> Output Class Initialized
INFO - 2024-03-17 14:45:59 --> Security Class Initialized
DEBUG - 2024-03-17 14:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:45:59 --> Input Class Initialized
INFO - 2024-03-17 14:45:59 --> Language Class Initialized
INFO - 2024-03-17 14:45:59 --> Language Class Initialized
INFO - 2024-03-17 14:45:59 --> Config Class Initialized
INFO - 2024-03-17 14:45:59 --> Loader Class Initialized
INFO - 2024-03-17 14:45:59 --> Helper loaded: url_helper
INFO - 2024-03-17 14:45:59 --> Helper loaded: file_helper
INFO - 2024-03-17 14:45:59 --> Helper loaded: form_helper
INFO - 2024-03-17 14:45:59 --> Helper loaded: my_helper
INFO - 2024-03-17 14:45:59 --> Database Driver Class Initialized
INFO - 2024-03-17 14:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:45:59 --> Controller Class Initialized
INFO - 2024-03-17 14:45:59 --> Final output sent to browser
DEBUG - 2024-03-17 14:45:59 --> Total execution time: 0.1176
INFO - 2024-03-17 14:46:04 --> Config Class Initialized
INFO - 2024-03-17 14:46:04 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:46:04 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:46:04 --> Utf8 Class Initialized
INFO - 2024-03-17 14:46:04 --> URI Class Initialized
INFO - 2024-03-17 14:46:04 --> Router Class Initialized
INFO - 2024-03-17 14:46:04 --> Output Class Initialized
INFO - 2024-03-17 14:46:04 --> Security Class Initialized
DEBUG - 2024-03-17 14:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:46:04 --> Input Class Initialized
INFO - 2024-03-17 14:46:04 --> Language Class Initialized
INFO - 2024-03-17 14:46:04 --> Language Class Initialized
INFO - 2024-03-17 14:46:04 --> Config Class Initialized
INFO - 2024-03-17 14:46:04 --> Loader Class Initialized
INFO - 2024-03-17 14:46:04 --> Helper loaded: url_helper
INFO - 2024-03-17 14:46:04 --> Helper loaded: file_helper
INFO - 2024-03-17 14:46:04 --> Helper loaded: form_helper
INFO - 2024-03-17 14:46:04 --> Helper loaded: my_helper
INFO - 2024-03-17 14:46:04 --> Database Driver Class Initialized
INFO - 2024-03-17 14:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:46:04 --> Controller Class Initialized
INFO - 2024-03-17 14:46:04 --> Final output sent to browser
DEBUG - 2024-03-17 14:46:04 --> Total execution time: 0.0364
INFO - 2024-03-17 14:46:10 --> Config Class Initialized
INFO - 2024-03-17 14:46:10 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:46:10 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:46:10 --> Utf8 Class Initialized
INFO - 2024-03-17 14:46:10 --> URI Class Initialized
INFO - 2024-03-17 14:46:10 --> Router Class Initialized
INFO - 2024-03-17 14:46:10 --> Output Class Initialized
INFO - 2024-03-17 14:46:10 --> Security Class Initialized
DEBUG - 2024-03-17 14:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:46:10 --> Input Class Initialized
INFO - 2024-03-17 14:46:10 --> Language Class Initialized
INFO - 2024-03-17 14:46:10 --> Language Class Initialized
INFO - 2024-03-17 14:46:10 --> Config Class Initialized
INFO - 2024-03-17 14:46:10 --> Loader Class Initialized
INFO - 2024-03-17 14:46:10 --> Helper loaded: url_helper
INFO - 2024-03-17 14:46:10 --> Helper loaded: file_helper
INFO - 2024-03-17 14:46:10 --> Helper loaded: form_helper
INFO - 2024-03-17 14:46:10 --> Helper loaded: my_helper
INFO - 2024-03-17 14:46:10 --> Database Driver Class Initialized
INFO - 2024-03-17 14:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:46:10 --> Controller Class Initialized
INFO - 2024-03-17 14:46:10 --> Final output sent to browser
DEBUG - 2024-03-17 14:46:10 --> Total execution time: 0.0345
INFO - 2024-03-17 14:46:15 --> Config Class Initialized
INFO - 2024-03-17 14:46:15 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:46:15 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:46:15 --> Utf8 Class Initialized
INFO - 2024-03-17 14:46:15 --> URI Class Initialized
INFO - 2024-03-17 14:46:15 --> Router Class Initialized
INFO - 2024-03-17 14:46:15 --> Output Class Initialized
INFO - 2024-03-17 14:46:15 --> Security Class Initialized
DEBUG - 2024-03-17 14:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:46:15 --> Input Class Initialized
INFO - 2024-03-17 14:46:15 --> Language Class Initialized
INFO - 2024-03-17 14:46:15 --> Language Class Initialized
INFO - 2024-03-17 14:46:15 --> Config Class Initialized
INFO - 2024-03-17 14:46:15 --> Loader Class Initialized
INFO - 2024-03-17 14:46:15 --> Helper loaded: url_helper
INFO - 2024-03-17 14:46:15 --> Helper loaded: file_helper
INFO - 2024-03-17 14:46:15 --> Helper loaded: form_helper
INFO - 2024-03-17 14:46:15 --> Helper loaded: my_helper
INFO - 2024-03-17 14:46:15 --> Database Driver Class Initialized
INFO - 2024-03-17 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:46:15 --> Controller Class Initialized
DEBUG - 2024-03-17 14:46:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 14:46:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:46:15 --> Final output sent to browser
DEBUG - 2024-03-17 14:46:15 --> Total execution time: 0.0317
INFO - 2024-03-17 14:46:17 --> Config Class Initialized
INFO - 2024-03-17 14:46:17 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:46:17 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:46:17 --> Utf8 Class Initialized
INFO - 2024-03-17 14:46:17 --> URI Class Initialized
INFO - 2024-03-17 14:46:17 --> Router Class Initialized
INFO - 2024-03-17 14:46:17 --> Output Class Initialized
INFO - 2024-03-17 14:46:17 --> Security Class Initialized
DEBUG - 2024-03-17 14:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:46:17 --> Input Class Initialized
INFO - 2024-03-17 14:46:17 --> Language Class Initialized
INFO - 2024-03-17 14:46:17 --> Language Class Initialized
INFO - 2024-03-17 14:46:17 --> Config Class Initialized
INFO - 2024-03-17 14:46:17 --> Loader Class Initialized
INFO - 2024-03-17 14:46:17 --> Helper loaded: url_helper
INFO - 2024-03-17 14:46:17 --> Helper loaded: file_helper
INFO - 2024-03-17 14:46:17 --> Helper loaded: form_helper
INFO - 2024-03-17 14:46:17 --> Helper loaded: my_helper
INFO - 2024-03-17 14:46:17 --> Database Driver Class Initialized
INFO - 2024-03-17 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:46:17 --> Controller Class Initialized
DEBUG - 2024-03-17 14:46:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-17 14:46:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:46:17 --> Final output sent to browser
DEBUG - 2024-03-17 14:46:17 --> Total execution time: 0.0348
INFO - 2024-03-17 14:46:26 --> Config Class Initialized
INFO - 2024-03-17 14:46:26 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:46:26 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:46:26 --> Utf8 Class Initialized
INFO - 2024-03-17 14:46:26 --> URI Class Initialized
INFO - 2024-03-17 14:46:26 --> Router Class Initialized
INFO - 2024-03-17 14:46:26 --> Output Class Initialized
INFO - 2024-03-17 14:46:26 --> Security Class Initialized
DEBUG - 2024-03-17 14:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:46:26 --> Input Class Initialized
INFO - 2024-03-17 14:46:26 --> Language Class Initialized
INFO - 2024-03-17 14:46:26 --> Language Class Initialized
INFO - 2024-03-17 14:46:26 --> Config Class Initialized
INFO - 2024-03-17 14:46:26 --> Loader Class Initialized
INFO - 2024-03-17 14:46:26 --> Helper loaded: url_helper
INFO - 2024-03-17 14:46:26 --> Helper loaded: file_helper
INFO - 2024-03-17 14:46:26 --> Helper loaded: form_helper
INFO - 2024-03-17 14:46:26 --> Helper loaded: my_helper
INFO - 2024-03-17 14:46:26 --> Database Driver Class Initialized
INFO - 2024-03-17 14:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:46:26 --> Controller Class Initialized
INFO - 2024-03-17 14:46:26 --> Final output sent to browser
DEBUG - 2024-03-17 14:46:26 --> Total execution time: 0.0504
INFO - 2024-03-17 14:51:25 --> Config Class Initialized
INFO - 2024-03-17 14:51:25 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:51:25 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:51:25 --> Utf8 Class Initialized
INFO - 2024-03-17 14:51:25 --> URI Class Initialized
INFO - 2024-03-17 14:51:25 --> Router Class Initialized
INFO - 2024-03-17 14:51:25 --> Output Class Initialized
INFO - 2024-03-17 14:51:25 --> Security Class Initialized
DEBUG - 2024-03-17 14:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:51:25 --> Input Class Initialized
INFO - 2024-03-17 14:51:25 --> Language Class Initialized
INFO - 2024-03-17 14:51:25 --> Language Class Initialized
INFO - 2024-03-17 14:51:25 --> Config Class Initialized
INFO - 2024-03-17 14:51:25 --> Loader Class Initialized
INFO - 2024-03-17 14:51:25 --> Helper loaded: url_helper
INFO - 2024-03-17 14:51:25 --> Helper loaded: file_helper
INFO - 2024-03-17 14:51:25 --> Helper loaded: form_helper
INFO - 2024-03-17 14:51:25 --> Helper loaded: my_helper
INFO - 2024-03-17 14:51:25 --> Database Driver Class Initialized
INFO - 2024-03-17 14:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:51:25 --> Controller Class Initialized
INFO - 2024-03-17 14:51:25 --> Final output sent to browser
DEBUG - 2024-03-17 14:51:25 --> Total execution time: 0.0713
INFO - 2024-03-17 14:51:28 --> Config Class Initialized
INFO - 2024-03-17 14:51:28 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:51:28 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:51:28 --> Utf8 Class Initialized
INFO - 2024-03-17 14:51:28 --> URI Class Initialized
INFO - 2024-03-17 14:51:28 --> Router Class Initialized
INFO - 2024-03-17 14:51:28 --> Output Class Initialized
INFO - 2024-03-17 14:51:28 --> Security Class Initialized
DEBUG - 2024-03-17 14:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:51:28 --> Input Class Initialized
INFO - 2024-03-17 14:51:28 --> Language Class Initialized
INFO - 2024-03-17 14:51:28 --> Language Class Initialized
INFO - 2024-03-17 14:51:28 --> Config Class Initialized
INFO - 2024-03-17 14:51:28 --> Loader Class Initialized
INFO - 2024-03-17 14:51:28 --> Helper loaded: url_helper
INFO - 2024-03-17 14:51:28 --> Helper loaded: file_helper
INFO - 2024-03-17 14:51:28 --> Helper loaded: form_helper
INFO - 2024-03-17 14:51:28 --> Helper loaded: my_helper
INFO - 2024-03-17 14:51:28 --> Database Driver Class Initialized
INFO - 2024-03-17 14:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:51:28 --> Controller Class Initialized
INFO - 2024-03-17 14:51:28 --> Final output sent to browser
DEBUG - 2024-03-17 14:51:28 --> Total execution time: 0.1655
INFO - 2024-03-17 14:51:34 --> Config Class Initialized
INFO - 2024-03-17 14:51:34 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:51:34 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:51:34 --> Utf8 Class Initialized
INFO - 2024-03-17 14:51:34 --> URI Class Initialized
INFO - 2024-03-17 14:51:34 --> Router Class Initialized
INFO - 2024-03-17 14:51:34 --> Output Class Initialized
INFO - 2024-03-17 14:51:34 --> Security Class Initialized
DEBUG - 2024-03-17 14:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:51:34 --> Input Class Initialized
INFO - 2024-03-17 14:51:34 --> Language Class Initialized
INFO - 2024-03-17 14:51:34 --> Language Class Initialized
INFO - 2024-03-17 14:51:34 --> Config Class Initialized
INFO - 2024-03-17 14:51:34 --> Loader Class Initialized
INFO - 2024-03-17 14:51:34 --> Helper loaded: url_helper
INFO - 2024-03-17 14:51:34 --> Helper loaded: file_helper
INFO - 2024-03-17 14:51:34 --> Helper loaded: form_helper
INFO - 2024-03-17 14:51:34 --> Helper loaded: my_helper
INFO - 2024-03-17 14:51:34 --> Database Driver Class Initialized
INFO - 2024-03-17 14:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:51:34 --> Controller Class Initialized
INFO - 2024-03-17 14:51:34 --> Final output sent to browser
DEBUG - 2024-03-17 14:51:34 --> Total execution time: 0.0886
INFO - 2024-03-17 14:51:44 --> Config Class Initialized
INFO - 2024-03-17 14:51:44 --> Hooks Class Initialized
DEBUG - 2024-03-17 14:51:44 --> UTF-8 Support Enabled
INFO - 2024-03-17 14:51:44 --> Utf8 Class Initialized
INFO - 2024-03-17 14:51:44 --> URI Class Initialized
INFO - 2024-03-17 14:51:44 --> Router Class Initialized
INFO - 2024-03-17 14:51:44 --> Output Class Initialized
INFO - 2024-03-17 14:51:44 --> Security Class Initialized
DEBUG - 2024-03-17 14:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 14:51:44 --> Input Class Initialized
INFO - 2024-03-17 14:51:44 --> Language Class Initialized
INFO - 2024-03-17 14:51:44 --> Language Class Initialized
INFO - 2024-03-17 14:51:44 --> Config Class Initialized
INFO - 2024-03-17 14:51:44 --> Loader Class Initialized
INFO - 2024-03-17 14:51:44 --> Helper loaded: url_helper
INFO - 2024-03-17 14:51:44 --> Helper loaded: file_helper
INFO - 2024-03-17 14:51:44 --> Helper loaded: form_helper
INFO - 2024-03-17 14:51:44 --> Helper loaded: my_helper
INFO - 2024-03-17 14:51:44 --> Database Driver Class Initialized
INFO - 2024-03-17 14:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 14:51:44 --> Controller Class Initialized
DEBUG - 2024-03-17 14:51:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 14:51:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 14:51:44 --> Final output sent to browser
DEBUG - 2024-03-17 14:51:44 --> Total execution time: 0.0994
INFO - 2024-03-17 17:52:25 --> Config Class Initialized
INFO - 2024-03-17 17:52:25 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:52:25 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:52:25 --> Utf8 Class Initialized
INFO - 2024-03-17 17:52:25 --> URI Class Initialized
INFO - 2024-03-17 17:52:25 --> Router Class Initialized
INFO - 2024-03-17 17:52:25 --> Output Class Initialized
INFO - 2024-03-17 17:52:25 --> Security Class Initialized
DEBUG - 2024-03-17 17:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:52:25 --> Input Class Initialized
INFO - 2024-03-17 17:52:25 --> Language Class Initialized
INFO - 2024-03-17 17:52:25 --> Language Class Initialized
INFO - 2024-03-17 17:52:25 --> Config Class Initialized
INFO - 2024-03-17 17:52:25 --> Loader Class Initialized
INFO - 2024-03-17 17:52:25 --> Helper loaded: url_helper
INFO - 2024-03-17 17:52:25 --> Helper loaded: file_helper
INFO - 2024-03-17 17:52:25 --> Helper loaded: form_helper
INFO - 2024-03-17 17:52:25 --> Helper loaded: my_helper
INFO - 2024-03-17 17:52:25 --> Database Driver Class Initialized
INFO - 2024-03-17 17:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:52:25 --> Controller Class Initialized
DEBUG - 2024-03-17 17:52:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-17 17:52:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 17:52:25 --> Final output sent to browser
DEBUG - 2024-03-17 17:52:25 --> Total execution time: 0.0497
INFO - 2024-03-17 17:53:08 --> Config Class Initialized
INFO - 2024-03-17 17:53:08 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:53:08 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:53:08 --> Utf8 Class Initialized
INFO - 2024-03-17 17:53:08 --> URI Class Initialized
INFO - 2024-03-17 17:53:08 --> Router Class Initialized
INFO - 2024-03-17 17:53:08 --> Output Class Initialized
INFO - 2024-03-17 17:53:08 --> Security Class Initialized
DEBUG - 2024-03-17 17:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:53:08 --> Input Class Initialized
INFO - 2024-03-17 17:53:08 --> Language Class Initialized
INFO - 2024-03-17 17:53:08 --> Language Class Initialized
INFO - 2024-03-17 17:53:08 --> Config Class Initialized
INFO - 2024-03-17 17:53:08 --> Loader Class Initialized
INFO - 2024-03-17 17:53:08 --> Helper loaded: url_helper
INFO - 2024-03-17 17:53:08 --> Helper loaded: file_helper
INFO - 2024-03-17 17:53:08 --> Helper loaded: form_helper
INFO - 2024-03-17 17:53:08 --> Helper loaded: my_helper
INFO - 2024-03-17 17:53:08 --> Database Driver Class Initialized
INFO - 2024-03-17 17:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:53:08 --> Controller Class Initialized
INFO - 2024-03-17 17:53:08 --> Helper loaded: cookie_helper
INFO - 2024-03-17 17:53:08 --> Final output sent to browser
DEBUG - 2024-03-17 17:53:08 --> Total execution time: 0.0433
INFO - 2024-03-17 17:53:09 --> Config Class Initialized
INFO - 2024-03-17 17:53:09 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:53:09 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:53:09 --> Utf8 Class Initialized
INFO - 2024-03-17 17:53:09 --> URI Class Initialized
INFO - 2024-03-17 17:53:09 --> Router Class Initialized
INFO - 2024-03-17 17:53:09 --> Output Class Initialized
INFO - 2024-03-17 17:53:09 --> Security Class Initialized
DEBUG - 2024-03-17 17:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:53:09 --> Input Class Initialized
INFO - 2024-03-17 17:53:09 --> Language Class Initialized
INFO - 2024-03-17 17:53:09 --> Language Class Initialized
INFO - 2024-03-17 17:53:09 --> Config Class Initialized
INFO - 2024-03-17 17:53:09 --> Loader Class Initialized
INFO - 2024-03-17 17:53:09 --> Helper loaded: url_helper
INFO - 2024-03-17 17:53:09 --> Helper loaded: file_helper
INFO - 2024-03-17 17:53:09 --> Helper loaded: form_helper
INFO - 2024-03-17 17:53:09 --> Helper loaded: my_helper
INFO - 2024-03-17 17:53:09 --> Database Driver Class Initialized
INFO - 2024-03-17 17:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:53:09 --> Controller Class Initialized
DEBUG - 2024-03-17 17:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-17 17:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 17:53:09 --> Final output sent to browser
DEBUG - 2024-03-17 17:53:09 --> Total execution time: 0.0400
INFO - 2024-03-17 17:53:13 --> Config Class Initialized
INFO - 2024-03-17 17:53:13 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:53:13 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:53:13 --> Utf8 Class Initialized
INFO - 2024-03-17 17:53:13 --> URI Class Initialized
INFO - 2024-03-17 17:53:13 --> Router Class Initialized
INFO - 2024-03-17 17:53:13 --> Output Class Initialized
INFO - 2024-03-17 17:53:13 --> Security Class Initialized
DEBUG - 2024-03-17 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:53:13 --> Input Class Initialized
INFO - 2024-03-17 17:53:13 --> Language Class Initialized
INFO - 2024-03-17 17:53:13 --> Language Class Initialized
INFO - 2024-03-17 17:53:13 --> Config Class Initialized
INFO - 2024-03-17 17:53:13 --> Loader Class Initialized
INFO - 2024-03-17 17:53:13 --> Helper loaded: url_helper
INFO - 2024-03-17 17:53:13 --> Helper loaded: file_helper
INFO - 2024-03-17 17:53:13 --> Helper loaded: form_helper
INFO - 2024-03-17 17:53:13 --> Helper loaded: my_helper
INFO - 2024-03-17 17:53:13 --> Database Driver Class Initialized
INFO - 2024-03-17 17:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:53:13 --> Controller Class Initialized
DEBUG - 2024-03-17 17:53:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 17:53:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 17:53:13 --> Final output sent to browser
DEBUG - 2024-03-17 17:53:13 --> Total execution time: 0.0695
INFO - 2024-03-17 17:53:17 --> Config Class Initialized
INFO - 2024-03-17 17:53:17 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:53:17 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:53:17 --> Utf8 Class Initialized
INFO - 2024-03-17 17:53:17 --> URI Class Initialized
INFO - 2024-03-17 17:53:17 --> Router Class Initialized
INFO - 2024-03-17 17:53:17 --> Output Class Initialized
INFO - 2024-03-17 17:53:17 --> Security Class Initialized
DEBUG - 2024-03-17 17:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:53:17 --> Input Class Initialized
INFO - 2024-03-17 17:53:17 --> Language Class Initialized
INFO - 2024-03-17 17:53:17 --> Language Class Initialized
INFO - 2024-03-17 17:53:17 --> Config Class Initialized
INFO - 2024-03-17 17:53:17 --> Loader Class Initialized
INFO - 2024-03-17 17:53:17 --> Helper loaded: url_helper
INFO - 2024-03-17 17:53:17 --> Helper loaded: file_helper
INFO - 2024-03-17 17:53:17 --> Helper loaded: form_helper
INFO - 2024-03-17 17:53:17 --> Helper loaded: my_helper
INFO - 2024-03-17 17:53:17 --> Database Driver Class Initialized
INFO - 2024-03-17 17:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:53:17 --> Controller Class Initialized
DEBUG - 2024-03-17 17:53:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-17 17:53:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 17:53:17 --> Final output sent to browser
DEBUG - 2024-03-17 17:53:17 --> Total execution time: 0.0355
INFO - 2024-03-17 17:53:20 --> Config Class Initialized
INFO - 2024-03-17 17:53:20 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:53:20 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:53:20 --> Utf8 Class Initialized
INFO - 2024-03-17 17:53:20 --> URI Class Initialized
INFO - 2024-03-17 17:53:20 --> Router Class Initialized
INFO - 2024-03-17 17:53:20 --> Output Class Initialized
INFO - 2024-03-17 17:53:20 --> Security Class Initialized
DEBUG - 2024-03-17 17:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:53:20 --> Input Class Initialized
INFO - 2024-03-17 17:53:20 --> Language Class Initialized
INFO - 2024-03-17 17:53:20 --> Language Class Initialized
INFO - 2024-03-17 17:53:20 --> Config Class Initialized
INFO - 2024-03-17 17:53:20 --> Loader Class Initialized
INFO - 2024-03-17 17:53:20 --> Helper loaded: url_helper
INFO - 2024-03-17 17:53:20 --> Helper loaded: file_helper
INFO - 2024-03-17 17:53:20 --> Helper loaded: form_helper
INFO - 2024-03-17 17:53:20 --> Helper loaded: my_helper
INFO - 2024-03-17 17:53:20 --> Database Driver Class Initialized
INFO - 2024-03-17 17:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:53:20 --> Controller Class Initialized
ERROR - 2024-03-17 17:53:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 17:53:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 17:53:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 17:53:25 --> Final output sent to browser
DEBUG - 2024-03-17 17:53:25 --> Total execution time: 4.8122
INFO - 2024-03-17 17:54:00 --> Config Class Initialized
INFO - 2024-03-17 17:54:00 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:54:00 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:54:00 --> Utf8 Class Initialized
INFO - 2024-03-17 17:54:00 --> URI Class Initialized
INFO - 2024-03-17 17:54:00 --> Router Class Initialized
INFO - 2024-03-17 17:54:00 --> Output Class Initialized
INFO - 2024-03-17 17:54:00 --> Security Class Initialized
DEBUG - 2024-03-17 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:54:00 --> Input Class Initialized
INFO - 2024-03-17 17:54:00 --> Language Class Initialized
INFO - 2024-03-17 17:54:00 --> Language Class Initialized
INFO - 2024-03-17 17:54:00 --> Config Class Initialized
INFO - 2024-03-17 17:54:00 --> Loader Class Initialized
INFO - 2024-03-17 17:54:00 --> Helper loaded: url_helper
INFO - 2024-03-17 17:54:00 --> Helper loaded: file_helper
INFO - 2024-03-17 17:54:00 --> Helper loaded: form_helper
INFO - 2024-03-17 17:54:00 --> Helper loaded: my_helper
INFO - 2024-03-17 17:54:00 --> Database Driver Class Initialized
INFO - 2024-03-17 17:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:54:00 --> Controller Class Initialized
ERROR - 2024-03-17 17:54:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 17:54:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 17:54:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 17:54:04 --> Final output sent to browser
DEBUG - 2024-03-17 17:54:04 --> Total execution time: 3.8600
INFO - 2024-03-17 17:56:05 --> Config Class Initialized
INFO - 2024-03-17 17:56:05 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:56:05 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:56:05 --> Utf8 Class Initialized
INFO - 2024-03-17 17:56:05 --> URI Class Initialized
INFO - 2024-03-17 17:56:05 --> Router Class Initialized
INFO - 2024-03-17 17:56:05 --> Output Class Initialized
INFO - 2024-03-17 17:56:05 --> Security Class Initialized
DEBUG - 2024-03-17 17:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:56:05 --> Input Class Initialized
INFO - 2024-03-17 17:56:05 --> Language Class Initialized
INFO - 2024-03-17 17:56:05 --> Language Class Initialized
INFO - 2024-03-17 17:56:05 --> Config Class Initialized
INFO - 2024-03-17 17:56:05 --> Loader Class Initialized
INFO - 2024-03-17 17:56:05 --> Helper loaded: url_helper
INFO - 2024-03-17 17:56:05 --> Helper loaded: file_helper
INFO - 2024-03-17 17:56:05 --> Helper loaded: form_helper
INFO - 2024-03-17 17:56:05 --> Helper loaded: my_helper
INFO - 2024-03-17 17:56:05 --> Database Driver Class Initialized
INFO - 2024-03-17 17:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:56:05 --> Controller Class Initialized
ERROR - 2024-03-17 17:56:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 17:56:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 17:56:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 17:56:09 --> Final output sent to browser
DEBUG - 2024-03-17 17:56:09 --> Total execution time: 3.8486
INFO - 2024-03-17 17:56:14 --> Config Class Initialized
INFO - 2024-03-17 17:56:14 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:56:14 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:56:14 --> Utf8 Class Initialized
INFO - 2024-03-17 17:56:14 --> URI Class Initialized
INFO - 2024-03-17 17:56:14 --> Router Class Initialized
INFO - 2024-03-17 17:56:14 --> Output Class Initialized
INFO - 2024-03-17 17:56:14 --> Security Class Initialized
DEBUG - 2024-03-17 17:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:56:14 --> Input Class Initialized
INFO - 2024-03-17 17:56:14 --> Language Class Initialized
INFO - 2024-03-17 17:56:14 --> Language Class Initialized
INFO - 2024-03-17 17:56:14 --> Config Class Initialized
INFO - 2024-03-17 17:56:14 --> Loader Class Initialized
INFO - 2024-03-17 17:56:14 --> Helper loaded: url_helper
INFO - 2024-03-17 17:56:14 --> Helper loaded: file_helper
INFO - 2024-03-17 17:56:14 --> Helper loaded: form_helper
INFO - 2024-03-17 17:56:14 --> Helper loaded: my_helper
INFO - 2024-03-17 17:56:14 --> Database Driver Class Initialized
INFO - 2024-03-17 17:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:56:14 --> Controller Class Initialized
ERROR - 2024-03-17 17:56:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 17:56:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 17:56:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 17:56:17 --> Final output sent to browser
DEBUG - 2024-03-17 17:56:17 --> Total execution time: 3.4562
INFO - 2024-03-17 17:59:47 --> Config Class Initialized
INFO - 2024-03-17 17:59:47 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:59:47 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:59:47 --> Utf8 Class Initialized
INFO - 2024-03-17 17:59:47 --> URI Class Initialized
INFO - 2024-03-17 17:59:47 --> Router Class Initialized
INFO - 2024-03-17 17:59:47 --> Output Class Initialized
INFO - 2024-03-17 17:59:47 --> Security Class Initialized
DEBUG - 2024-03-17 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:59:47 --> Input Class Initialized
INFO - 2024-03-17 17:59:47 --> Language Class Initialized
INFO - 2024-03-17 17:59:47 --> Language Class Initialized
INFO - 2024-03-17 17:59:47 --> Config Class Initialized
INFO - 2024-03-17 17:59:47 --> Loader Class Initialized
INFO - 2024-03-17 17:59:47 --> Helper loaded: url_helper
INFO - 2024-03-17 17:59:47 --> Helper loaded: file_helper
INFO - 2024-03-17 17:59:47 --> Helper loaded: form_helper
INFO - 2024-03-17 17:59:47 --> Helper loaded: my_helper
INFO - 2024-03-17 17:59:47 --> Database Driver Class Initialized
INFO - 2024-03-17 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:59:47 --> Controller Class Initialized
ERROR - 2024-03-17 17:59:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 17:59:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 17:59:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 17:59:51 --> Final output sent to browser
DEBUG - 2024-03-17 17:59:51 --> Total execution time: 3.5180
INFO - 2024-03-17 17:59:51 --> Config Class Initialized
INFO - 2024-03-17 17:59:51 --> Hooks Class Initialized
DEBUG - 2024-03-17 17:59:51 --> UTF-8 Support Enabled
INFO - 2024-03-17 17:59:51 --> Utf8 Class Initialized
INFO - 2024-03-17 17:59:51 --> URI Class Initialized
INFO - 2024-03-17 17:59:51 --> Router Class Initialized
INFO - 2024-03-17 17:59:51 --> Output Class Initialized
INFO - 2024-03-17 17:59:51 --> Security Class Initialized
DEBUG - 2024-03-17 17:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 17:59:51 --> Input Class Initialized
INFO - 2024-03-17 17:59:51 --> Language Class Initialized
INFO - 2024-03-17 17:59:51 --> Language Class Initialized
INFO - 2024-03-17 17:59:51 --> Config Class Initialized
INFO - 2024-03-17 17:59:51 --> Loader Class Initialized
INFO - 2024-03-17 17:59:51 --> Helper loaded: url_helper
INFO - 2024-03-17 17:59:51 --> Helper loaded: file_helper
INFO - 2024-03-17 17:59:51 --> Helper loaded: form_helper
INFO - 2024-03-17 17:59:51 --> Helper loaded: my_helper
INFO - 2024-03-17 17:59:51 --> Database Driver Class Initialized
INFO - 2024-03-17 17:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 17:59:51 --> Controller Class Initialized
ERROR - 2024-03-17 17:59:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 17:59:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 17:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 17:59:54 --> Final output sent to browser
DEBUG - 2024-03-17 17:59:54 --> Total execution time: 3.3678
INFO - 2024-03-17 18:02:18 --> Config Class Initialized
INFO - 2024-03-17 18:02:18 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:02:18 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:02:18 --> Utf8 Class Initialized
INFO - 2024-03-17 18:02:18 --> URI Class Initialized
INFO - 2024-03-17 18:02:18 --> Router Class Initialized
INFO - 2024-03-17 18:02:18 --> Output Class Initialized
INFO - 2024-03-17 18:02:18 --> Security Class Initialized
DEBUG - 2024-03-17 18:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:02:18 --> Input Class Initialized
INFO - 2024-03-17 18:02:18 --> Language Class Initialized
INFO - 2024-03-17 18:02:18 --> Language Class Initialized
INFO - 2024-03-17 18:02:18 --> Config Class Initialized
INFO - 2024-03-17 18:02:18 --> Loader Class Initialized
INFO - 2024-03-17 18:02:18 --> Helper loaded: url_helper
INFO - 2024-03-17 18:02:18 --> Helper loaded: file_helper
INFO - 2024-03-17 18:02:18 --> Helper loaded: form_helper
INFO - 2024-03-17 18:02:18 --> Helper loaded: my_helper
INFO - 2024-03-17 18:02:18 --> Database Driver Class Initialized
INFO - 2024-03-17 18:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:02:18 --> Controller Class Initialized
ERROR - 2024-03-17 18:02:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 18:02:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 18:02:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 18:02:22 --> Final output sent to browser
DEBUG - 2024-03-17 18:02:22 --> Total execution time: 3.4121
INFO - 2024-03-17 18:04:27 --> Config Class Initialized
INFO - 2024-03-17 18:04:27 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:04:27 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:04:27 --> Utf8 Class Initialized
INFO - 2024-03-17 18:04:27 --> URI Class Initialized
INFO - 2024-03-17 18:04:27 --> Router Class Initialized
INFO - 2024-03-17 18:04:27 --> Output Class Initialized
INFO - 2024-03-17 18:04:27 --> Security Class Initialized
DEBUG - 2024-03-17 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:04:27 --> Input Class Initialized
INFO - 2024-03-17 18:04:27 --> Language Class Initialized
INFO - 2024-03-17 18:04:27 --> Language Class Initialized
INFO - 2024-03-17 18:04:27 --> Config Class Initialized
INFO - 2024-03-17 18:04:27 --> Loader Class Initialized
INFO - 2024-03-17 18:04:27 --> Helper loaded: url_helper
INFO - 2024-03-17 18:04:27 --> Helper loaded: file_helper
INFO - 2024-03-17 18:04:27 --> Helper loaded: form_helper
INFO - 2024-03-17 18:04:27 --> Helper loaded: my_helper
INFO - 2024-03-17 18:04:27 --> Database Driver Class Initialized
INFO - 2024-03-17 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:04:27 --> Controller Class Initialized
ERROR - 2024-03-17 18:04:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 18:04:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 18:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 18:04:30 --> Final output sent to browser
DEBUG - 2024-03-17 18:04:30 --> Total execution time: 3.1248
INFO - 2024-03-17 18:05:48 --> Config Class Initialized
INFO - 2024-03-17 18:05:48 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:05:48 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:05:48 --> Utf8 Class Initialized
INFO - 2024-03-17 18:05:48 --> URI Class Initialized
INFO - 2024-03-17 18:05:48 --> Router Class Initialized
INFO - 2024-03-17 18:05:48 --> Output Class Initialized
INFO - 2024-03-17 18:05:48 --> Security Class Initialized
DEBUG - 2024-03-17 18:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:05:48 --> Input Class Initialized
INFO - 2024-03-17 18:05:48 --> Language Class Initialized
INFO - 2024-03-17 18:05:48 --> Language Class Initialized
INFO - 2024-03-17 18:05:48 --> Config Class Initialized
INFO - 2024-03-17 18:05:48 --> Loader Class Initialized
INFO - 2024-03-17 18:05:48 --> Helper loaded: url_helper
INFO - 2024-03-17 18:05:48 --> Helper loaded: file_helper
INFO - 2024-03-17 18:05:48 --> Helper loaded: form_helper
INFO - 2024-03-17 18:05:48 --> Helper loaded: my_helper
INFO - 2024-03-17 18:05:48 --> Database Driver Class Initialized
INFO - 2024-03-17 18:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:05:48 --> Controller Class Initialized
ERROR - 2024-03-17 18:05:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 18:05:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 18:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 18:05:51 --> Final output sent to browser
DEBUG - 2024-03-17 18:05:51 --> Total execution time: 3.1829
INFO - 2024-03-17 18:05:54 --> Config Class Initialized
INFO - 2024-03-17 18:05:54 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:05:54 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:05:54 --> Utf8 Class Initialized
INFO - 2024-03-17 18:05:54 --> URI Class Initialized
INFO - 2024-03-17 18:05:54 --> Router Class Initialized
INFO - 2024-03-17 18:05:54 --> Output Class Initialized
INFO - 2024-03-17 18:05:54 --> Security Class Initialized
DEBUG - 2024-03-17 18:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:05:54 --> Input Class Initialized
INFO - 2024-03-17 18:05:54 --> Language Class Initialized
INFO - 2024-03-17 18:05:54 --> Language Class Initialized
INFO - 2024-03-17 18:05:54 --> Config Class Initialized
INFO - 2024-03-17 18:05:54 --> Loader Class Initialized
INFO - 2024-03-17 18:05:54 --> Helper loaded: url_helper
INFO - 2024-03-17 18:05:54 --> Helper loaded: file_helper
INFO - 2024-03-17 18:05:54 --> Helper loaded: form_helper
INFO - 2024-03-17 18:05:54 --> Helper loaded: my_helper
INFO - 2024-03-17 18:05:54 --> Database Driver Class Initialized
INFO - 2024-03-17 18:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:05:54 --> Controller Class Initialized
ERROR - 2024-03-17 18:05:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 18:05:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 18:05:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 18:05:57 --> Final output sent to browser
DEBUG - 2024-03-17 18:05:57 --> Total execution time: 3.0508
INFO - 2024-03-17 18:06:22 --> Config Class Initialized
INFO - 2024-03-17 18:06:22 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:22 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:22 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:22 --> URI Class Initialized
INFO - 2024-03-17 18:06:22 --> Router Class Initialized
INFO - 2024-03-17 18:06:22 --> Output Class Initialized
INFO - 2024-03-17 18:06:22 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:22 --> Input Class Initialized
INFO - 2024-03-17 18:06:22 --> Language Class Initialized
INFO - 2024-03-17 18:06:22 --> Language Class Initialized
INFO - 2024-03-17 18:06:22 --> Config Class Initialized
INFO - 2024-03-17 18:06:22 --> Loader Class Initialized
INFO - 2024-03-17 18:06:22 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:22 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:22 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:22 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:22 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:22 --> Controller Class Initialized
DEBUG - 2024-03-17 18:06:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-17 18:06:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 18:06:22 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:22 --> Total execution time: 0.0422
INFO - 2024-03-17 18:06:23 --> Config Class Initialized
INFO - 2024-03-17 18:06:23 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:23 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:23 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:23 --> URI Class Initialized
INFO - 2024-03-17 18:06:23 --> Router Class Initialized
INFO - 2024-03-17 18:06:23 --> Output Class Initialized
INFO - 2024-03-17 18:06:23 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:23 --> Input Class Initialized
INFO - 2024-03-17 18:06:23 --> Language Class Initialized
INFO - 2024-03-17 18:06:23 --> Language Class Initialized
INFO - 2024-03-17 18:06:23 --> Config Class Initialized
INFO - 2024-03-17 18:06:23 --> Loader Class Initialized
INFO - 2024-03-17 18:06:23 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:23 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:23 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:23 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:23 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:23 --> Controller Class Initialized
DEBUG - 2024-03-17 18:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-17 18:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 18:06:23 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:23 --> Total execution time: 0.0316
INFO - 2024-03-17 18:06:24 --> Config Class Initialized
INFO - 2024-03-17 18:06:24 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:24 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:24 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:24 --> URI Class Initialized
INFO - 2024-03-17 18:06:24 --> Router Class Initialized
INFO - 2024-03-17 18:06:24 --> Output Class Initialized
INFO - 2024-03-17 18:06:24 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:24 --> Input Class Initialized
INFO - 2024-03-17 18:06:24 --> Language Class Initialized
INFO - 2024-03-17 18:06:24 --> Language Class Initialized
INFO - 2024-03-17 18:06:24 --> Config Class Initialized
INFO - 2024-03-17 18:06:24 --> Loader Class Initialized
INFO - 2024-03-17 18:06:24 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:24 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:24 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:24 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:24 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:24 --> Controller Class Initialized
INFO - 2024-03-17 18:06:26 --> Config Class Initialized
INFO - 2024-03-17 18:06:26 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:26 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:26 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:26 --> URI Class Initialized
INFO - 2024-03-17 18:06:26 --> Router Class Initialized
INFO - 2024-03-17 18:06:26 --> Output Class Initialized
INFO - 2024-03-17 18:06:26 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:26 --> Input Class Initialized
INFO - 2024-03-17 18:06:26 --> Language Class Initialized
INFO - 2024-03-17 18:06:26 --> Language Class Initialized
INFO - 2024-03-17 18:06:26 --> Config Class Initialized
INFO - 2024-03-17 18:06:26 --> Loader Class Initialized
INFO - 2024-03-17 18:06:26 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:26 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:26 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:26 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:26 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:26 --> Controller Class Initialized
INFO - 2024-03-17 18:06:26 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:26 --> Total execution time: 0.0429
INFO - 2024-03-17 18:06:31 --> Config Class Initialized
INFO - 2024-03-17 18:06:31 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:31 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:31 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:31 --> URI Class Initialized
INFO - 2024-03-17 18:06:31 --> Router Class Initialized
INFO - 2024-03-17 18:06:31 --> Output Class Initialized
INFO - 2024-03-17 18:06:31 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:31 --> Input Class Initialized
INFO - 2024-03-17 18:06:31 --> Language Class Initialized
INFO - 2024-03-17 18:06:31 --> Language Class Initialized
INFO - 2024-03-17 18:06:31 --> Config Class Initialized
INFO - 2024-03-17 18:06:31 --> Loader Class Initialized
INFO - 2024-03-17 18:06:31 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:31 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:31 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:31 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:31 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:31 --> Controller Class Initialized
INFO - 2024-03-17 18:06:31 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:31 --> Total execution time: 0.0331
INFO - 2024-03-17 18:06:37 --> Config Class Initialized
INFO - 2024-03-17 18:06:37 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:37 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:37 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:37 --> URI Class Initialized
INFO - 2024-03-17 18:06:37 --> Router Class Initialized
INFO - 2024-03-17 18:06:37 --> Output Class Initialized
INFO - 2024-03-17 18:06:37 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:37 --> Input Class Initialized
INFO - 2024-03-17 18:06:37 --> Language Class Initialized
INFO - 2024-03-17 18:06:37 --> Language Class Initialized
INFO - 2024-03-17 18:06:37 --> Config Class Initialized
INFO - 2024-03-17 18:06:37 --> Loader Class Initialized
INFO - 2024-03-17 18:06:37 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:37 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:37 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:37 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:37 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:37 --> Controller Class Initialized
INFO - 2024-03-17 18:06:38 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:38 --> Total execution time: 0.3394
INFO - 2024-03-17 18:06:42 --> Config Class Initialized
INFO - 2024-03-17 18:06:42 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:42 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:42 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:42 --> URI Class Initialized
INFO - 2024-03-17 18:06:42 --> Router Class Initialized
INFO - 2024-03-17 18:06:42 --> Output Class Initialized
INFO - 2024-03-17 18:06:42 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:42 --> Input Class Initialized
INFO - 2024-03-17 18:06:42 --> Language Class Initialized
INFO - 2024-03-17 18:06:42 --> Language Class Initialized
INFO - 2024-03-17 18:06:42 --> Config Class Initialized
INFO - 2024-03-17 18:06:42 --> Loader Class Initialized
INFO - 2024-03-17 18:06:42 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:42 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:42 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:42 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:42 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:42 --> Controller Class Initialized
INFO - 2024-03-17 18:06:42 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:42 --> Total execution time: 0.0659
INFO - 2024-03-17 18:06:53 --> Config Class Initialized
INFO - 2024-03-17 18:06:53 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:53 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:53 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:53 --> URI Class Initialized
INFO - 2024-03-17 18:06:53 --> Router Class Initialized
INFO - 2024-03-17 18:06:53 --> Output Class Initialized
INFO - 2024-03-17 18:06:53 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:53 --> Input Class Initialized
INFO - 2024-03-17 18:06:53 --> Language Class Initialized
INFO - 2024-03-17 18:06:53 --> Language Class Initialized
INFO - 2024-03-17 18:06:53 --> Config Class Initialized
INFO - 2024-03-17 18:06:53 --> Loader Class Initialized
INFO - 2024-03-17 18:06:53 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:53 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:53 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:53 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:53 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:53 --> Controller Class Initialized
DEBUG - 2024-03-17 18:06:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-17 18:06:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 18:06:53 --> Final output sent to browser
DEBUG - 2024-03-17 18:06:53 --> Total execution time: 0.0325
INFO - 2024-03-17 18:06:57 --> Config Class Initialized
INFO - 2024-03-17 18:06:57 --> Hooks Class Initialized
DEBUG - 2024-03-17 18:06:57 --> UTF-8 Support Enabled
INFO - 2024-03-17 18:06:57 --> Utf8 Class Initialized
INFO - 2024-03-17 18:06:57 --> URI Class Initialized
INFO - 2024-03-17 18:06:57 --> Router Class Initialized
INFO - 2024-03-17 18:06:57 --> Output Class Initialized
INFO - 2024-03-17 18:06:57 --> Security Class Initialized
DEBUG - 2024-03-17 18:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 18:06:57 --> Input Class Initialized
INFO - 2024-03-17 18:06:57 --> Language Class Initialized
INFO - 2024-03-17 18:06:57 --> Language Class Initialized
INFO - 2024-03-17 18:06:57 --> Config Class Initialized
INFO - 2024-03-17 18:06:57 --> Loader Class Initialized
INFO - 2024-03-17 18:06:57 --> Helper loaded: url_helper
INFO - 2024-03-17 18:06:57 --> Helper loaded: file_helper
INFO - 2024-03-17 18:06:57 --> Helper loaded: form_helper
INFO - 2024-03-17 18:06:57 --> Helper loaded: my_helper
INFO - 2024-03-17 18:06:57 --> Database Driver Class Initialized
INFO - 2024-03-17 18:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 18:06:57 --> Controller Class Initialized
ERROR - 2024-03-17 18:06:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-17 18:06:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
DEBUG - 2024-03-17 18:06:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-17 18:07:00 --> Final output sent to browser
DEBUG - 2024-03-17 18:07:00 --> Total execution time: 3.2952
INFO - 2024-03-17 20:14:40 --> Config Class Initialized
INFO - 2024-03-17 20:14:40 --> Hooks Class Initialized
DEBUG - 2024-03-17 20:14:40 --> UTF-8 Support Enabled
INFO - 2024-03-17 20:14:40 --> Utf8 Class Initialized
INFO - 2024-03-17 20:14:40 --> URI Class Initialized
INFO - 2024-03-17 20:14:40 --> Router Class Initialized
INFO - 2024-03-17 20:14:40 --> Output Class Initialized
INFO - 2024-03-17 20:14:40 --> Security Class Initialized
DEBUG - 2024-03-17 20:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 20:14:40 --> Input Class Initialized
INFO - 2024-03-17 20:14:40 --> Language Class Initialized
INFO - 2024-03-17 20:14:40 --> Language Class Initialized
INFO - 2024-03-17 20:14:40 --> Config Class Initialized
INFO - 2024-03-17 20:14:40 --> Loader Class Initialized
INFO - 2024-03-17 20:14:40 --> Helper loaded: url_helper
INFO - 2024-03-17 20:14:40 --> Helper loaded: file_helper
INFO - 2024-03-17 20:14:40 --> Helper loaded: form_helper
INFO - 2024-03-17 20:14:40 --> Helper loaded: my_helper
INFO - 2024-03-17 20:14:40 --> Database Driver Class Initialized
INFO - 2024-03-17 20:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 20:14:40 --> Controller Class Initialized
ERROR - 2024-03-17 20:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2024-03-17 20:14:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-17 20:14:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 20:14:40 --> Final output sent to browser
DEBUG - 2024-03-17 20:14:40 --> Total execution time: 0.0501
INFO - 2024-03-17 22:56:31 --> Config Class Initialized
INFO - 2024-03-17 22:56:31 --> Hooks Class Initialized
DEBUG - 2024-03-17 22:56:31 --> UTF-8 Support Enabled
INFO - 2024-03-17 22:56:31 --> Utf8 Class Initialized
INFO - 2024-03-17 22:56:31 --> URI Class Initialized
INFO - 2024-03-17 22:56:31 --> Router Class Initialized
INFO - 2024-03-17 22:56:31 --> Output Class Initialized
INFO - 2024-03-17 22:56:31 --> Security Class Initialized
DEBUG - 2024-03-17 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 22:56:31 --> Input Class Initialized
INFO - 2024-03-17 22:56:31 --> Language Class Initialized
INFO - 2024-03-17 22:56:31 --> Language Class Initialized
INFO - 2024-03-17 22:56:31 --> Config Class Initialized
INFO - 2024-03-17 22:56:31 --> Loader Class Initialized
INFO - 2024-03-17 22:56:31 --> Helper loaded: url_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: file_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: form_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: my_helper
INFO - 2024-03-17 22:56:31 --> Database Driver Class Initialized
INFO - 2024-03-17 22:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 22:56:31 --> Controller Class Initialized
INFO - 2024-03-17 22:56:31 --> Helper loaded: cookie_helper
INFO - 2024-03-17 22:56:31 --> Final output sent to browser
DEBUG - 2024-03-17 22:56:31 --> Total execution time: 0.1311
INFO - 2024-03-17 22:56:31 --> Config Class Initialized
INFO - 2024-03-17 22:56:31 --> Hooks Class Initialized
DEBUG - 2024-03-17 22:56:31 --> UTF-8 Support Enabled
INFO - 2024-03-17 22:56:31 --> Utf8 Class Initialized
INFO - 2024-03-17 22:56:31 --> URI Class Initialized
INFO - 2024-03-17 22:56:31 --> Router Class Initialized
INFO - 2024-03-17 22:56:31 --> Output Class Initialized
INFO - 2024-03-17 22:56:31 --> Security Class Initialized
DEBUG - 2024-03-17 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 22:56:31 --> Input Class Initialized
INFO - 2024-03-17 22:56:31 --> Language Class Initialized
INFO - 2024-03-17 22:56:31 --> Language Class Initialized
INFO - 2024-03-17 22:56:31 --> Config Class Initialized
INFO - 2024-03-17 22:56:31 --> Loader Class Initialized
INFO - 2024-03-17 22:56:31 --> Helper loaded: url_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: file_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: form_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: my_helper
INFO - 2024-03-17 22:56:31 --> Database Driver Class Initialized
INFO - 2024-03-17 22:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 22:56:31 --> Controller Class Initialized
INFO - 2024-03-17 22:56:31 --> Helper loaded: cookie_helper
INFO - 2024-03-17 22:56:31 --> Config Class Initialized
INFO - 2024-03-17 22:56:31 --> Hooks Class Initialized
DEBUG - 2024-03-17 22:56:31 --> UTF-8 Support Enabled
INFO - 2024-03-17 22:56:31 --> Utf8 Class Initialized
INFO - 2024-03-17 22:56:31 --> URI Class Initialized
INFO - 2024-03-17 22:56:31 --> Router Class Initialized
INFO - 2024-03-17 22:56:31 --> Output Class Initialized
INFO - 2024-03-17 22:56:31 --> Security Class Initialized
DEBUG - 2024-03-17 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-17 22:56:31 --> Input Class Initialized
INFO - 2024-03-17 22:56:31 --> Language Class Initialized
INFO - 2024-03-17 22:56:31 --> Language Class Initialized
INFO - 2024-03-17 22:56:31 --> Config Class Initialized
INFO - 2024-03-17 22:56:31 --> Loader Class Initialized
INFO - 2024-03-17 22:56:31 --> Helper loaded: url_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: file_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: form_helper
INFO - 2024-03-17 22:56:31 --> Helper loaded: my_helper
INFO - 2024-03-17 22:56:31 --> Database Driver Class Initialized
INFO - 2024-03-17 22:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-17 22:56:31 --> Controller Class Initialized
DEBUG - 2024-03-17 22:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-17 22:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-17 22:56:31 --> Final output sent to browser
DEBUG - 2024-03-17 22:56:31 --> Total execution time: 0.0534
