<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-12 05:45:05 --> Config Class Initialized
INFO - 2024-11-12 05:45:05 --> Hooks Class Initialized
DEBUG - 2024-11-12 05:45:05 --> UTF-8 Support Enabled
INFO - 2024-11-12 05:45:05 --> Utf8 Class Initialized
INFO - 2024-11-12 05:45:05 --> URI Class Initialized
INFO - 2024-11-12 05:45:05 --> Router Class Initialized
INFO - 2024-11-12 05:45:05 --> Output Class Initialized
INFO - 2024-11-12 05:45:05 --> Security Class Initialized
DEBUG - 2024-11-12 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 05:45:05 --> Input Class Initialized
INFO - 2024-11-12 05:45:05 --> Language Class Initialized
INFO - 2024-11-12 05:45:05 --> Language Class Initialized
INFO - 2024-11-12 05:45:05 --> Config Class Initialized
INFO - 2024-11-12 05:45:05 --> Loader Class Initialized
INFO - 2024-11-12 05:45:05 --> Helper loaded: url_helper
INFO - 2024-11-12 05:45:05 --> Helper loaded: file_helper
INFO - 2024-11-12 05:45:05 --> Helper loaded: form_helper
INFO - 2024-11-12 05:45:05 --> Helper loaded: my_helper
INFO - 2024-11-12 05:45:05 --> Database Driver Class Initialized
INFO - 2024-11-12 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 05:45:05 --> Controller Class Initialized
INFO - 2024-11-12 21:08:03 --> Config Class Initialized
INFO - 2024-11-12 21:08:03 --> Hooks Class Initialized
DEBUG - 2024-11-12 21:08:03 --> UTF-8 Support Enabled
INFO - 2024-11-12 21:08:03 --> Utf8 Class Initialized
INFO - 2024-11-12 21:08:03 --> URI Class Initialized
INFO - 2024-11-12 21:08:03 --> Router Class Initialized
INFO - 2024-11-12 21:08:03 --> Output Class Initialized
INFO - 2024-11-12 21:08:03 --> Security Class Initialized
DEBUG - 2024-11-12 21:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 21:08:03 --> Input Class Initialized
INFO - 2024-11-12 21:08:03 --> Language Class Initialized
INFO - 2024-11-12 21:08:03 --> Language Class Initialized
INFO - 2024-11-12 21:08:03 --> Config Class Initialized
INFO - 2024-11-12 21:08:03 --> Loader Class Initialized
INFO - 2024-11-12 21:08:03 --> Helper loaded: url_helper
INFO - 2024-11-12 21:08:03 --> Helper loaded: file_helper
INFO - 2024-11-12 21:08:03 --> Helper loaded: form_helper
INFO - 2024-11-12 21:08:03 --> Helper loaded: my_helper
INFO - 2024-11-12 21:08:03 --> Database Driver Class Initialized
INFO - 2024-11-12 21:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 21:08:03 --> Controller Class Initialized
INFO - 2024-11-12 21:08:03 --> Helper loaded: cookie_helper
INFO - 2024-11-12 21:08:03 --> Final output sent to browser
DEBUG - 2024-11-12 21:08:03 --> Total execution time: 0.1560
INFO - 2024-11-12 21:08:04 --> Config Class Initialized
INFO - 2024-11-12 21:08:04 --> Hooks Class Initialized
DEBUG - 2024-11-12 21:08:04 --> UTF-8 Support Enabled
INFO - 2024-11-12 21:08:04 --> Utf8 Class Initialized
INFO - 2024-11-12 21:08:04 --> URI Class Initialized
INFO - 2024-11-12 21:08:04 --> Router Class Initialized
INFO - 2024-11-12 21:08:04 --> Output Class Initialized
INFO - 2024-11-12 21:08:04 --> Security Class Initialized
DEBUG - 2024-11-12 21:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 21:08:04 --> Input Class Initialized
INFO - 2024-11-12 21:08:04 --> Language Class Initialized
INFO - 2024-11-12 21:08:04 --> Language Class Initialized
INFO - 2024-11-12 21:08:04 --> Config Class Initialized
INFO - 2024-11-12 21:08:04 --> Loader Class Initialized
INFO - 2024-11-12 21:08:04 --> Helper loaded: url_helper
INFO - 2024-11-12 21:08:04 --> Helper loaded: file_helper
INFO - 2024-11-12 21:08:04 --> Helper loaded: form_helper
INFO - 2024-11-12 21:08:04 --> Helper loaded: my_helper
INFO - 2024-11-12 21:08:04 --> Database Driver Class Initialized
INFO - 2024-11-12 21:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 21:08:04 --> Controller Class Initialized
INFO - 2024-11-12 21:08:04 --> Helper loaded: cookie_helper
INFO - 2024-11-12 21:08:04 --> Config Class Initialized
INFO - 2024-11-12 21:08:04 --> Hooks Class Initialized
DEBUG - 2024-11-12 21:08:04 --> UTF-8 Support Enabled
INFO - 2024-11-12 21:08:04 --> Utf8 Class Initialized
INFO - 2024-11-12 21:08:04 --> URI Class Initialized
INFO - 2024-11-12 21:08:04 --> Router Class Initialized
INFO - 2024-11-12 21:08:04 --> Output Class Initialized
INFO - 2024-11-12 21:08:04 --> Security Class Initialized
DEBUG - 2024-11-12 21:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 21:08:04 --> Input Class Initialized
INFO - 2024-11-12 21:08:04 --> Language Class Initialized
INFO - 2024-11-12 21:08:04 --> Language Class Initialized
INFO - 2024-11-12 21:08:04 --> Config Class Initialized
INFO - 2024-11-12 21:08:04 --> Loader Class Initialized
INFO - 2024-11-12 21:08:04 --> Helper loaded: url_helper
INFO - 2024-11-12 21:08:04 --> Helper loaded: file_helper
INFO - 2024-11-12 21:08:04 --> Helper loaded: form_helper
INFO - 2024-11-12 21:08:04 --> Helper loaded: my_helper
INFO - 2024-11-12 21:08:04 --> Database Driver Class Initialized
INFO - 2024-11-12 21:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 21:08:04 --> Controller Class Initialized
DEBUG - 2024-11-12 21:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-12 21:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-12 21:08:04 --> Final output sent to browser
DEBUG - 2024-11-12 21:08:04 --> Total execution time: 0.0570
