<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-04 08:50:57 --> Config Class Initialized
INFO - 2024-03-04 08:50:57 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:50:57 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:50:57 --> Utf8 Class Initialized
INFO - 2024-03-04 08:50:57 --> URI Class Initialized
INFO - 2024-03-04 08:50:57 --> Router Class Initialized
INFO - 2024-03-04 08:50:57 --> Output Class Initialized
INFO - 2024-03-04 08:50:57 --> Security Class Initialized
DEBUG - 2024-03-04 08:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:50:57 --> Input Class Initialized
INFO - 2024-03-04 08:50:57 --> Language Class Initialized
INFO - 2024-03-04 08:50:57 --> Language Class Initialized
INFO - 2024-03-04 08:50:57 --> Config Class Initialized
INFO - 2024-03-04 08:50:57 --> Loader Class Initialized
INFO - 2024-03-04 08:50:57 --> Helper loaded: url_helper
INFO - 2024-03-04 08:50:57 --> Helper loaded: file_helper
INFO - 2024-03-04 08:50:57 --> Helper loaded: form_helper
INFO - 2024-03-04 08:50:57 --> Helper loaded: my_helper
INFO - 2024-03-04 08:50:57 --> Database Driver Class Initialized
INFO - 2024-03-04 08:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:50:57 --> Controller Class Initialized
DEBUG - 2024-03-04 08:50:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-04 08:50:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 08:50:57 --> Final output sent to browser
DEBUG - 2024-03-04 08:50:57 --> Total execution time: 0.1381
INFO - 2024-03-04 08:51:03 --> Config Class Initialized
INFO - 2024-03-04 08:51:03 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:51:03 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:51:03 --> Utf8 Class Initialized
INFO - 2024-03-04 08:51:03 --> URI Class Initialized
INFO - 2024-03-04 08:51:03 --> Router Class Initialized
INFO - 2024-03-04 08:51:03 --> Output Class Initialized
INFO - 2024-03-04 08:51:03 --> Security Class Initialized
DEBUG - 2024-03-04 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:51:03 --> Input Class Initialized
INFO - 2024-03-04 08:51:03 --> Language Class Initialized
INFO - 2024-03-04 08:51:03 --> Language Class Initialized
INFO - 2024-03-04 08:51:03 --> Config Class Initialized
INFO - 2024-03-04 08:51:03 --> Loader Class Initialized
INFO - 2024-03-04 08:51:03 --> Helper loaded: url_helper
INFO - 2024-03-04 08:51:03 --> Helper loaded: file_helper
INFO - 2024-03-04 08:51:03 --> Helper loaded: form_helper
INFO - 2024-03-04 08:51:03 --> Helper loaded: my_helper
INFO - 2024-03-04 08:51:03 --> Database Driver Class Initialized
INFO - 2024-03-04 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:51:03 --> Controller Class Initialized
INFO - 2024-03-04 08:51:03 --> Helper loaded: cookie_helper
INFO - 2024-03-04 08:51:03 --> Final output sent to browser
DEBUG - 2024-03-04 08:51:03 --> Total execution time: 0.0556
INFO - 2024-03-04 08:51:03 --> Config Class Initialized
INFO - 2024-03-04 08:51:03 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:51:03 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:51:03 --> Utf8 Class Initialized
INFO - 2024-03-04 08:51:03 --> URI Class Initialized
INFO - 2024-03-04 08:51:03 --> Router Class Initialized
INFO - 2024-03-04 08:51:03 --> Output Class Initialized
INFO - 2024-03-04 08:51:03 --> Security Class Initialized
DEBUG - 2024-03-04 08:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:51:03 --> Input Class Initialized
INFO - 2024-03-04 08:51:03 --> Language Class Initialized
INFO - 2024-03-04 08:51:03 --> Language Class Initialized
INFO - 2024-03-04 08:51:03 --> Config Class Initialized
INFO - 2024-03-04 08:51:03 --> Loader Class Initialized
INFO - 2024-03-04 08:51:03 --> Helper loaded: url_helper
INFO - 2024-03-04 08:51:03 --> Helper loaded: file_helper
INFO - 2024-03-04 08:51:03 --> Helper loaded: form_helper
INFO - 2024-03-04 08:51:03 --> Helper loaded: my_helper
INFO - 2024-03-04 08:51:03 --> Database Driver Class Initialized
INFO - 2024-03-04 08:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:51:03 --> Controller Class Initialized
DEBUG - 2024-03-04 08:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-04 08:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 08:51:03 --> Final output sent to browser
DEBUG - 2024-03-04 08:51:03 --> Total execution time: 0.0585
INFO - 2024-03-04 08:51:07 --> Config Class Initialized
INFO - 2024-03-04 08:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:51:07 --> Utf8 Class Initialized
INFO - 2024-03-04 08:51:07 --> URI Class Initialized
INFO - 2024-03-04 08:51:07 --> Router Class Initialized
INFO - 2024-03-04 08:51:07 --> Output Class Initialized
INFO - 2024-03-04 08:51:07 --> Security Class Initialized
DEBUG - 2024-03-04 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:51:07 --> Input Class Initialized
INFO - 2024-03-04 08:51:07 --> Language Class Initialized
INFO - 2024-03-04 08:51:07 --> Language Class Initialized
INFO - 2024-03-04 08:51:07 --> Config Class Initialized
INFO - 2024-03-04 08:51:07 --> Loader Class Initialized
INFO - 2024-03-04 08:51:07 --> Helper loaded: url_helper
INFO - 2024-03-04 08:51:07 --> Helper loaded: file_helper
INFO - 2024-03-04 08:51:07 --> Helper loaded: form_helper
INFO - 2024-03-04 08:51:07 --> Helper loaded: my_helper
INFO - 2024-03-04 08:51:07 --> Database Driver Class Initialized
INFO - 2024-03-04 08:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:51:07 --> Controller Class Initialized
DEBUG - 2024-03-04 08:51:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-04 08:51:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 08:51:07 --> Final output sent to browser
DEBUG - 2024-03-04 08:51:07 --> Total execution time: 0.0371
INFO - 2024-03-04 08:51:07 --> Config Class Initialized
INFO - 2024-03-04 08:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:51:07 --> Utf8 Class Initialized
INFO - 2024-03-04 08:51:07 --> URI Class Initialized
INFO - 2024-03-04 08:51:07 --> Router Class Initialized
INFO - 2024-03-04 08:51:07 --> Output Class Initialized
INFO - 2024-03-04 08:51:07 --> Security Class Initialized
DEBUG - 2024-03-04 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:51:07 --> Input Class Initialized
INFO - 2024-03-04 08:51:07 --> Language Class Initialized
ERROR - 2024-03-04 08:51:07 --> 404 Page Not Found: /index
INFO - 2024-03-04 08:51:07 --> Config Class Initialized
INFO - 2024-03-04 08:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:51:07 --> Utf8 Class Initialized
INFO - 2024-03-04 08:51:07 --> URI Class Initialized
INFO - 2024-03-04 08:51:07 --> Router Class Initialized
INFO - 2024-03-04 08:51:07 --> Output Class Initialized
INFO - 2024-03-04 08:51:07 --> Security Class Initialized
DEBUG - 2024-03-04 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:51:07 --> Input Class Initialized
INFO - 2024-03-04 08:51:07 --> Language Class Initialized
INFO - 2024-03-04 08:51:07 --> Language Class Initialized
INFO - 2024-03-04 08:51:07 --> Config Class Initialized
INFO - 2024-03-04 08:51:07 --> Loader Class Initialized
INFO - 2024-03-04 08:51:07 --> Helper loaded: url_helper
INFO - 2024-03-04 08:51:07 --> Helper loaded: file_helper
INFO - 2024-03-04 08:51:07 --> Helper loaded: form_helper
INFO - 2024-03-04 08:51:07 --> Helper loaded: my_helper
INFO - 2024-03-04 08:51:07 --> Database Driver Class Initialized
INFO - 2024-03-04 08:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:51:07 --> Controller Class Initialized
INFO - 2024-03-04 08:51:10 --> Config Class Initialized
INFO - 2024-03-04 08:51:10 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:51:10 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:51:10 --> Utf8 Class Initialized
INFO - 2024-03-04 08:51:10 --> URI Class Initialized
INFO - 2024-03-04 08:51:10 --> Router Class Initialized
INFO - 2024-03-04 08:51:10 --> Output Class Initialized
INFO - 2024-03-04 08:51:10 --> Security Class Initialized
DEBUG - 2024-03-04 08:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:51:10 --> Input Class Initialized
INFO - 2024-03-04 08:51:10 --> Language Class Initialized
INFO - 2024-03-04 08:51:10 --> Language Class Initialized
INFO - 2024-03-04 08:51:10 --> Config Class Initialized
INFO - 2024-03-04 08:51:10 --> Loader Class Initialized
INFO - 2024-03-04 08:51:10 --> Helper loaded: url_helper
INFO - 2024-03-04 08:51:10 --> Helper loaded: file_helper
INFO - 2024-03-04 08:51:10 --> Helper loaded: form_helper
INFO - 2024-03-04 08:51:10 --> Helper loaded: my_helper
INFO - 2024-03-04 08:51:10 --> Database Driver Class Initialized
INFO - 2024-03-04 08:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:51:10 --> Controller Class Initialized
INFO - 2024-03-04 08:51:10 --> Final output sent to browser
DEBUG - 2024-03-04 08:51:10 --> Total execution time: 0.0790
INFO - 2024-03-04 08:52:10 --> Config Class Initialized
INFO - 2024-03-04 08:52:10 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:10 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:10 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:10 --> URI Class Initialized
INFO - 2024-03-04 08:52:10 --> Router Class Initialized
INFO - 2024-03-04 08:52:10 --> Output Class Initialized
INFO - 2024-03-04 08:52:10 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:10 --> Input Class Initialized
INFO - 2024-03-04 08:52:10 --> Language Class Initialized
INFO - 2024-03-04 08:52:10 --> Language Class Initialized
INFO - 2024-03-04 08:52:10 --> Config Class Initialized
INFO - 2024-03-04 08:52:10 --> Loader Class Initialized
INFO - 2024-03-04 08:52:10 --> Helper loaded: url_helper
INFO - 2024-03-04 08:52:10 --> Helper loaded: file_helper
INFO - 2024-03-04 08:52:10 --> Helper loaded: form_helper
INFO - 2024-03-04 08:52:10 --> Helper loaded: my_helper
INFO - 2024-03-04 08:52:10 --> Database Driver Class Initialized
INFO - 2024-03-04 08:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:52:10 --> Controller Class Initialized
INFO - 2024-03-04 08:52:10 --> Final output sent to browser
DEBUG - 2024-03-04 08:52:10 --> Total execution time: 0.0888
INFO - 2024-03-04 08:52:10 --> Config Class Initialized
INFO - 2024-03-04 08:52:10 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:10 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:10 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:10 --> URI Class Initialized
INFO - 2024-03-04 08:52:10 --> Router Class Initialized
INFO - 2024-03-04 08:52:10 --> Output Class Initialized
INFO - 2024-03-04 08:52:10 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:10 --> Input Class Initialized
INFO - 2024-03-04 08:52:10 --> Language Class Initialized
ERROR - 2024-03-04 08:52:10 --> 404 Page Not Found: /index
INFO - 2024-03-04 08:52:10 --> Config Class Initialized
INFO - 2024-03-04 08:52:10 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:10 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:10 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:10 --> URI Class Initialized
INFO - 2024-03-04 08:52:10 --> Router Class Initialized
INFO - 2024-03-04 08:52:10 --> Output Class Initialized
INFO - 2024-03-04 08:52:10 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:10 --> Input Class Initialized
INFO - 2024-03-04 08:52:10 --> Language Class Initialized
INFO - 2024-03-04 08:52:10 --> Language Class Initialized
INFO - 2024-03-04 08:52:10 --> Config Class Initialized
INFO - 2024-03-04 08:52:10 --> Loader Class Initialized
INFO - 2024-03-04 08:52:10 --> Helper loaded: url_helper
INFO - 2024-03-04 08:52:10 --> Helper loaded: file_helper
INFO - 2024-03-04 08:52:10 --> Helper loaded: form_helper
INFO - 2024-03-04 08:52:10 --> Helper loaded: my_helper
INFO - 2024-03-04 08:52:10 --> Database Driver Class Initialized
INFO - 2024-03-04 08:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:52:11 --> Controller Class Initialized
INFO - 2024-03-04 08:52:17 --> Config Class Initialized
INFO - 2024-03-04 08:52:17 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:17 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:17 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:17 --> URI Class Initialized
INFO - 2024-03-04 08:52:17 --> Router Class Initialized
INFO - 2024-03-04 08:52:17 --> Output Class Initialized
INFO - 2024-03-04 08:52:17 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:17 --> Input Class Initialized
INFO - 2024-03-04 08:52:17 --> Language Class Initialized
INFO - 2024-03-04 08:52:17 --> Language Class Initialized
INFO - 2024-03-04 08:52:17 --> Config Class Initialized
INFO - 2024-03-04 08:52:17 --> Loader Class Initialized
INFO - 2024-03-04 08:52:17 --> Helper loaded: url_helper
INFO - 2024-03-04 08:52:17 --> Helper loaded: file_helper
INFO - 2024-03-04 08:52:17 --> Helper loaded: form_helper
INFO - 2024-03-04 08:52:17 --> Helper loaded: my_helper
INFO - 2024-03-04 08:52:17 --> Database Driver Class Initialized
INFO - 2024-03-04 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:52:17 --> Controller Class Initialized
INFO - 2024-03-04 08:52:17 --> Final output sent to browser
DEBUG - 2024-03-04 08:52:17 --> Total execution time: 0.0320
INFO - 2024-03-04 08:52:17 --> Config Class Initialized
INFO - 2024-03-04 08:52:17 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:17 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:17 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:17 --> URI Class Initialized
INFO - 2024-03-04 08:52:17 --> Router Class Initialized
INFO - 2024-03-04 08:52:17 --> Output Class Initialized
INFO - 2024-03-04 08:52:17 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:17 --> Input Class Initialized
INFO - 2024-03-04 08:52:17 --> Language Class Initialized
ERROR - 2024-03-04 08:52:17 --> 404 Page Not Found: /index
INFO - 2024-03-04 08:52:17 --> Config Class Initialized
INFO - 2024-03-04 08:52:17 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:17 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:17 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:17 --> URI Class Initialized
INFO - 2024-03-04 08:52:17 --> Router Class Initialized
INFO - 2024-03-04 08:52:17 --> Output Class Initialized
INFO - 2024-03-04 08:52:17 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:17 --> Input Class Initialized
INFO - 2024-03-04 08:52:17 --> Language Class Initialized
INFO - 2024-03-04 08:52:17 --> Language Class Initialized
INFO - 2024-03-04 08:52:17 --> Config Class Initialized
INFO - 2024-03-04 08:52:17 --> Loader Class Initialized
INFO - 2024-03-04 08:52:17 --> Helper loaded: url_helper
INFO - 2024-03-04 08:52:17 --> Helper loaded: file_helper
INFO - 2024-03-04 08:52:17 --> Helper loaded: form_helper
INFO - 2024-03-04 08:52:17 --> Helper loaded: my_helper
INFO - 2024-03-04 08:52:17 --> Database Driver Class Initialized
INFO - 2024-03-04 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:52:17 --> Controller Class Initialized
INFO - 2024-03-04 08:52:23 --> Config Class Initialized
INFO - 2024-03-04 08:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-04 08:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-04 08:52:23 --> Utf8 Class Initialized
INFO - 2024-03-04 08:52:23 --> URI Class Initialized
INFO - 2024-03-04 08:52:23 --> Router Class Initialized
INFO - 2024-03-04 08:52:23 --> Output Class Initialized
INFO - 2024-03-04 08:52:23 --> Security Class Initialized
DEBUG - 2024-03-04 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 08:52:23 --> Input Class Initialized
INFO - 2024-03-04 08:52:23 --> Language Class Initialized
INFO - 2024-03-04 08:52:23 --> Language Class Initialized
INFO - 2024-03-04 08:52:23 --> Config Class Initialized
INFO - 2024-03-04 08:52:23 --> Loader Class Initialized
INFO - 2024-03-04 08:52:23 --> Helper loaded: url_helper
INFO - 2024-03-04 08:52:23 --> Helper loaded: file_helper
INFO - 2024-03-04 08:52:23 --> Helper loaded: form_helper
INFO - 2024-03-04 08:52:23 --> Helper loaded: my_helper
INFO - 2024-03-04 08:52:23 --> Database Driver Class Initialized
INFO - 2024-03-04 08:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 08:52:23 --> Controller Class Initialized
INFO - 2024-03-04 08:52:23 --> Final output sent to browser
DEBUG - 2024-03-04 08:52:23 --> Total execution time: 0.0289
INFO - 2024-03-04 11:49:21 --> Config Class Initialized
INFO - 2024-03-04 11:49:21 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:21 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:21 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:21 --> URI Class Initialized
DEBUG - 2024-03-04 11:49:21 --> No URI present. Default controller set.
INFO - 2024-03-04 11:49:21 --> Router Class Initialized
INFO - 2024-03-04 11:49:21 --> Output Class Initialized
INFO - 2024-03-04 11:49:21 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:21 --> Input Class Initialized
INFO - 2024-03-04 11:49:21 --> Language Class Initialized
INFO - 2024-03-04 11:49:21 --> Language Class Initialized
INFO - 2024-03-04 11:49:21 --> Config Class Initialized
INFO - 2024-03-04 11:49:21 --> Loader Class Initialized
INFO - 2024-03-04 11:49:21 --> Helper loaded: url_helper
INFO - 2024-03-04 11:49:21 --> Helper loaded: file_helper
INFO - 2024-03-04 11:49:21 --> Helper loaded: form_helper
INFO - 2024-03-04 11:49:21 --> Helper loaded: my_helper
INFO - 2024-03-04 11:49:21 --> Database Driver Class Initialized
INFO - 2024-03-04 11:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:49:21 --> Controller Class Initialized
DEBUG - 2024-03-04 11:49:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-04 11:49:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:49:21 --> Final output sent to browser
DEBUG - 2024-03-04 11:49:21 --> Total execution time: 0.0848
INFO - 2024-03-04 11:49:24 --> Config Class Initialized
INFO - 2024-03-04 11:49:24 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:24 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:24 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:24 --> URI Class Initialized
INFO - 2024-03-04 11:49:24 --> Router Class Initialized
INFO - 2024-03-04 11:49:24 --> Output Class Initialized
INFO - 2024-03-04 11:49:24 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:24 --> Input Class Initialized
INFO - 2024-03-04 11:49:24 --> Language Class Initialized
INFO - 2024-03-04 11:49:24 --> Language Class Initialized
INFO - 2024-03-04 11:49:24 --> Config Class Initialized
INFO - 2024-03-04 11:49:24 --> Loader Class Initialized
INFO - 2024-03-04 11:49:24 --> Helper loaded: url_helper
INFO - 2024-03-04 11:49:24 --> Helper loaded: file_helper
INFO - 2024-03-04 11:49:24 --> Helper loaded: form_helper
INFO - 2024-03-04 11:49:24 --> Helper loaded: my_helper
INFO - 2024-03-04 11:49:24 --> Database Driver Class Initialized
INFO - 2024-03-04 11:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:49:24 --> Controller Class Initialized
DEBUG - 2024-03-04 11:49:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-04 11:49:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:49:24 --> Final output sent to browser
DEBUG - 2024-03-04 11:49:24 --> Total execution time: 0.0789
INFO - 2024-03-04 11:49:24 --> Config Class Initialized
INFO - 2024-03-04 11:49:24 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:24 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:24 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:24 --> URI Class Initialized
INFO - 2024-03-04 11:49:24 --> Router Class Initialized
INFO - 2024-03-04 11:49:24 --> Output Class Initialized
INFO - 2024-03-04 11:49:24 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:24 --> Input Class Initialized
INFO - 2024-03-04 11:49:24 --> Language Class Initialized
ERROR - 2024-03-04 11:49:24 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:49:24 --> Config Class Initialized
INFO - 2024-03-04 11:49:24 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:24 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:24 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:24 --> URI Class Initialized
INFO - 2024-03-04 11:49:24 --> Router Class Initialized
INFO - 2024-03-04 11:49:24 --> Output Class Initialized
INFO - 2024-03-04 11:49:24 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:24 --> Input Class Initialized
INFO - 2024-03-04 11:49:24 --> Language Class Initialized
INFO - 2024-03-04 11:49:24 --> Language Class Initialized
INFO - 2024-03-04 11:49:24 --> Config Class Initialized
INFO - 2024-03-04 11:49:24 --> Loader Class Initialized
INFO - 2024-03-04 11:49:24 --> Helper loaded: url_helper
INFO - 2024-03-04 11:49:24 --> Helper loaded: file_helper
INFO - 2024-03-04 11:49:24 --> Helper loaded: form_helper
INFO - 2024-03-04 11:49:24 --> Helper loaded: my_helper
INFO - 2024-03-04 11:49:24 --> Database Driver Class Initialized
INFO - 2024-03-04 11:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:49:24 --> Controller Class Initialized
INFO - 2024-03-04 11:49:28 --> Config Class Initialized
INFO - 2024-03-04 11:49:28 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:28 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:28 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:28 --> URI Class Initialized
INFO - 2024-03-04 11:49:28 --> Router Class Initialized
INFO - 2024-03-04 11:49:28 --> Output Class Initialized
INFO - 2024-03-04 11:49:28 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:28 --> Input Class Initialized
INFO - 2024-03-04 11:49:28 --> Language Class Initialized
INFO - 2024-03-04 11:49:28 --> Language Class Initialized
INFO - 2024-03-04 11:49:28 --> Config Class Initialized
INFO - 2024-03-04 11:49:28 --> Loader Class Initialized
INFO - 2024-03-04 11:49:28 --> Helper loaded: url_helper
INFO - 2024-03-04 11:49:28 --> Helper loaded: file_helper
INFO - 2024-03-04 11:49:28 --> Helper loaded: form_helper
INFO - 2024-03-04 11:49:28 --> Helper loaded: my_helper
INFO - 2024-03-04 11:49:28 --> Database Driver Class Initialized
INFO - 2024-03-04 11:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:49:28 --> Controller Class Initialized
INFO - 2024-03-04 11:49:28 --> Final output sent to browser
DEBUG - 2024-03-04 11:49:28 --> Total execution time: 0.1221
INFO - 2024-03-04 11:49:31 --> Config Class Initialized
INFO - 2024-03-04 11:49:31 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:31 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:31 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:31 --> URI Class Initialized
INFO - 2024-03-04 11:49:31 --> Router Class Initialized
INFO - 2024-03-04 11:49:31 --> Output Class Initialized
INFO - 2024-03-04 11:49:31 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:31 --> Input Class Initialized
INFO - 2024-03-04 11:49:31 --> Language Class Initialized
INFO - 2024-03-04 11:49:31 --> Language Class Initialized
INFO - 2024-03-04 11:49:31 --> Config Class Initialized
INFO - 2024-03-04 11:49:31 --> Loader Class Initialized
INFO - 2024-03-04 11:49:31 --> Helper loaded: url_helper
INFO - 2024-03-04 11:49:31 --> Helper loaded: file_helper
INFO - 2024-03-04 11:49:31 --> Helper loaded: form_helper
INFO - 2024-03-04 11:49:31 --> Helper loaded: my_helper
INFO - 2024-03-04 11:49:31 --> Database Driver Class Initialized
INFO - 2024-03-04 11:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:49:31 --> Controller Class Initialized
INFO - 2024-03-04 11:49:31 --> Final output sent to browser
DEBUG - 2024-03-04 11:49:31 --> Total execution time: 0.0716
INFO - 2024-03-04 11:49:31 --> Config Class Initialized
INFO - 2024-03-04 11:49:31 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:31 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:31 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:31 --> URI Class Initialized
INFO - 2024-03-04 11:49:31 --> Router Class Initialized
INFO - 2024-03-04 11:49:31 --> Output Class Initialized
INFO - 2024-03-04 11:49:31 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:31 --> Input Class Initialized
INFO - 2024-03-04 11:49:31 --> Language Class Initialized
ERROR - 2024-03-04 11:49:31 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:49:31 --> Config Class Initialized
INFO - 2024-03-04 11:49:31 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:49:31 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:49:31 --> Utf8 Class Initialized
INFO - 2024-03-04 11:49:31 --> URI Class Initialized
INFO - 2024-03-04 11:49:31 --> Router Class Initialized
INFO - 2024-03-04 11:49:31 --> Output Class Initialized
INFO - 2024-03-04 11:49:31 --> Security Class Initialized
DEBUG - 2024-03-04 11:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:49:31 --> Input Class Initialized
INFO - 2024-03-04 11:49:31 --> Language Class Initialized
INFO - 2024-03-04 11:49:31 --> Language Class Initialized
INFO - 2024-03-04 11:49:31 --> Config Class Initialized
INFO - 2024-03-04 11:49:31 --> Loader Class Initialized
INFO - 2024-03-04 11:49:31 --> Helper loaded: url_helper
INFO - 2024-03-04 11:49:31 --> Helper loaded: file_helper
INFO - 2024-03-04 11:49:31 --> Helper loaded: form_helper
INFO - 2024-03-04 11:49:31 --> Helper loaded: my_helper
INFO - 2024-03-04 11:49:31 --> Database Driver Class Initialized
INFO - 2024-03-04 11:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:49:31 --> Controller Class Initialized
INFO - 2024-03-04 11:50:51 --> Config Class Initialized
INFO - 2024-03-04 11:50:51 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:51 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:51 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:51 --> URI Class Initialized
INFO - 2024-03-04 11:50:51 --> Router Class Initialized
INFO - 2024-03-04 11:50:51 --> Output Class Initialized
INFO - 2024-03-04 11:50:51 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:51 --> Input Class Initialized
INFO - 2024-03-04 11:50:51 --> Language Class Initialized
INFO - 2024-03-04 11:50:51 --> Language Class Initialized
INFO - 2024-03-04 11:50:51 --> Config Class Initialized
INFO - 2024-03-04 11:50:51 --> Loader Class Initialized
INFO - 2024-03-04 11:50:51 --> Helper loaded: url_helper
INFO - 2024-03-04 11:50:51 --> Helper loaded: file_helper
INFO - 2024-03-04 11:50:51 --> Helper loaded: form_helper
INFO - 2024-03-04 11:50:51 --> Helper loaded: my_helper
INFO - 2024-03-04 11:50:51 --> Database Driver Class Initialized
INFO - 2024-03-04 11:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:50:51 --> Controller Class Initialized
INFO - 2024-03-04 11:50:51 --> Final output sent to browser
DEBUG - 2024-03-04 11:50:51 --> Total execution time: 0.0675
INFO - 2024-03-04 11:50:55 --> Config Class Initialized
INFO - 2024-03-04 11:50:55 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:55 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:55 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:55 --> URI Class Initialized
INFO - 2024-03-04 11:50:55 --> Router Class Initialized
INFO - 2024-03-04 11:50:55 --> Output Class Initialized
INFO - 2024-03-04 11:50:55 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:55 --> Input Class Initialized
INFO - 2024-03-04 11:50:55 --> Language Class Initialized
INFO - 2024-03-04 11:50:55 --> Language Class Initialized
INFO - 2024-03-04 11:50:55 --> Config Class Initialized
INFO - 2024-03-04 11:50:55 --> Loader Class Initialized
INFO - 2024-03-04 11:50:55 --> Helper loaded: url_helper
INFO - 2024-03-04 11:50:55 --> Helper loaded: file_helper
INFO - 2024-03-04 11:50:55 --> Helper loaded: form_helper
INFO - 2024-03-04 11:50:55 --> Helper loaded: my_helper
INFO - 2024-03-04 11:50:55 --> Database Driver Class Initialized
INFO - 2024-03-04 11:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:50:55 --> Controller Class Initialized
INFO - 2024-03-04 11:50:55 --> Final output sent to browser
DEBUG - 2024-03-04 11:50:55 --> Total execution time: 0.1159
INFO - 2024-03-04 11:50:55 --> Config Class Initialized
INFO - 2024-03-04 11:50:55 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:55 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:55 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:55 --> URI Class Initialized
INFO - 2024-03-04 11:50:55 --> Router Class Initialized
INFO - 2024-03-04 11:50:55 --> Output Class Initialized
INFO - 2024-03-04 11:50:55 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:55 --> Input Class Initialized
INFO - 2024-03-04 11:50:55 --> Language Class Initialized
ERROR - 2024-03-04 11:50:55 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:50:55 --> Config Class Initialized
INFO - 2024-03-04 11:50:55 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:55 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:55 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:55 --> URI Class Initialized
INFO - 2024-03-04 11:50:55 --> Router Class Initialized
INFO - 2024-03-04 11:50:55 --> Output Class Initialized
INFO - 2024-03-04 11:50:55 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:55 --> Input Class Initialized
INFO - 2024-03-04 11:50:55 --> Language Class Initialized
INFO - 2024-03-04 11:50:55 --> Language Class Initialized
INFO - 2024-03-04 11:50:55 --> Config Class Initialized
INFO - 2024-03-04 11:50:55 --> Loader Class Initialized
INFO - 2024-03-04 11:50:55 --> Helper loaded: url_helper
INFO - 2024-03-04 11:50:55 --> Helper loaded: file_helper
INFO - 2024-03-04 11:50:55 --> Helper loaded: form_helper
INFO - 2024-03-04 11:50:55 --> Helper loaded: my_helper
INFO - 2024-03-04 11:50:55 --> Database Driver Class Initialized
INFO - 2024-03-04 11:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:50:55 --> Controller Class Initialized
INFO - 2024-03-04 11:50:57 --> Config Class Initialized
INFO - 2024-03-04 11:50:57 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:57 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:57 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:57 --> URI Class Initialized
INFO - 2024-03-04 11:50:57 --> Router Class Initialized
INFO - 2024-03-04 11:50:57 --> Output Class Initialized
INFO - 2024-03-04 11:50:57 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:57 --> Input Class Initialized
INFO - 2024-03-04 11:50:57 --> Language Class Initialized
INFO - 2024-03-04 11:50:57 --> Language Class Initialized
INFO - 2024-03-04 11:50:57 --> Config Class Initialized
INFO - 2024-03-04 11:50:57 --> Loader Class Initialized
INFO - 2024-03-04 11:50:57 --> Helper loaded: url_helper
INFO - 2024-03-04 11:50:57 --> Helper loaded: file_helper
INFO - 2024-03-04 11:50:57 --> Helper loaded: form_helper
INFO - 2024-03-04 11:50:57 --> Helper loaded: my_helper
INFO - 2024-03-04 11:50:57 --> Database Driver Class Initialized
INFO - 2024-03-04 11:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:50:57 --> Controller Class Initialized
DEBUG - 2024-03-04 11:50:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-03-04 11:50:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:50:57 --> Final output sent to browser
DEBUG - 2024-03-04 11:50:57 --> Total execution time: 0.0637
INFO - 2024-03-04 11:50:59 --> Config Class Initialized
INFO - 2024-03-04 11:50:59 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:59 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:59 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:59 --> URI Class Initialized
INFO - 2024-03-04 11:50:59 --> Router Class Initialized
INFO - 2024-03-04 11:50:59 --> Output Class Initialized
INFO - 2024-03-04 11:50:59 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:59 --> Input Class Initialized
INFO - 2024-03-04 11:50:59 --> Language Class Initialized
INFO - 2024-03-04 11:50:59 --> Language Class Initialized
INFO - 2024-03-04 11:50:59 --> Config Class Initialized
INFO - 2024-03-04 11:50:59 --> Loader Class Initialized
INFO - 2024-03-04 11:50:59 --> Helper loaded: url_helper
INFO - 2024-03-04 11:50:59 --> Helper loaded: file_helper
INFO - 2024-03-04 11:50:59 --> Helper loaded: form_helper
INFO - 2024-03-04 11:50:59 --> Helper loaded: my_helper
INFO - 2024-03-04 11:50:59 --> Database Driver Class Initialized
INFO - 2024-03-04 11:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:50:59 --> Controller Class Initialized
DEBUG - 2024-03-04 11:50:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-04 11:50:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:50:59 --> Final output sent to browser
DEBUG - 2024-03-04 11:50:59 --> Total execution time: 0.0822
INFO - 2024-03-04 11:50:59 --> Config Class Initialized
INFO - 2024-03-04 11:50:59 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:59 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:59 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:59 --> URI Class Initialized
INFO - 2024-03-04 11:50:59 --> Router Class Initialized
INFO - 2024-03-04 11:50:59 --> Output Class Initialized
INFO - 2024-03-04 11:50:59 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:59 --> Input Class Initialized
INFO - 2024-03-04 11:50:59 --> Language Class Initialized
ERROR - 2024-03-04 11:50:59 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:50:59 --> Config Class Initialized
INFO - 2024-03-04 11:50:59 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:50:59 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:50:59 --> Utf8 Class Initialized
INFO - 2024-03-04 11:50:59 --> URI Class Initialized
INFO - 2024-03-04 11:50:59 --> Router Class Initialized
INFO - 2024-03-04 11:50:59 --> Output Class Initialized
INFO - 2024-03-04 11:50:59 --> Security Class Initialized
DEBUG - 2024-03-04 11:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:50:59 --> Input Class Initialized
INFO - 2024-03-04 11:50:59 --> Language Class Initialized
INFO - 2024-03-04 11:50:59 --> Language Class Initialized
INFO - 2024-03-04 11:50:59 --> Config Class Initialized
INFO - 2024-03-04 11:50:59 --> Loader Class Initialized
INFO - 2024-03-04 11:50:59 --> Helper loaded: url_helper
INFO - 2024-03-04 11:50:59 --> Helper loaded: file_helper
INFO - 2024-03-04 11:50:59 --> Helper loaded: form_helper
INFO - 2024-03-04 11:50:59 --> Helper loaded: my_helper
INFO - 2024-03-04 11:50:59 --> Database Driver Class Initialized
INFO - 2024-03-04 11:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:50:59 --> Controller Class Initialized
INFO - 2024-03-04 11:51:01 --> Config Class Initialized
INFO - 2024-03-04 11:51:01 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:01 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:01 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:01 --> URI Class Initialized
INFO - 2024-03-04 11:51:01 --> Router Class Initialized
INFO - 2024-03-04 11:51:01 --> Output Class Initialized
INFO - 2024-03-04 11:51:01 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:01 --> Input Class Initialized
INFO - 2024-03-04 11:51:01 --> Language Class Initialized
INFO - 2024-03-04 11:51:01 --> Language Class Initialized
INFO - 2024-03-04 11:51:01 --> Config Class Initialized
INFO - 2024-03-04 11:51:01 --> Loader Class Initialized
INFO - 2024-03-04 11:51:01 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:01 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:01 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:01 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:01 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:01 --> Controller Class Initialized
DEBUG - 2024-03-04 11:51:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-03-04 11:51:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:51:01 --> Final output sent to browser
DEBUG - 2024-03-04 11:51:01 --> Total execution time: 0.1300
INFO - 2024-03-04 11:51:01 --> Config Class Initialized
INFO - 2024-03-04 11:51:01 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:01 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:01 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:01 --> URI Class Initialized
INFO - 2024-03-04 11:51:01 --> Router Class Initialized
INFO - 2024-03-04 11:51:01 --> Output Class Initialized
INFO - 2024-03-04 11:51:01 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:01 --> Input Class Initialized
INFO - 2024-03-04 11:51:01 --> Language Class Initialized
ERROR - 2024-03-04 11:51:01 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:51:01 --> Config Class Initialized
INFO - 2024-03-04 11:51:01 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:01 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:01 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:01 --> URI Class Initialized
INFO - 2024-03-04 11:51:01 --> Router Class Initialized
INFO - 2024-03-04 11:51:01 --> Output Class Initialized
INFO - 2024-03-04 11:51:01 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:01 --> Input Class Initialized
INFO - 2024-03-04 11:51:01 --> Language Class Initialized
INFO - 2024-03-04 11:51:01 --> Language Class Initialized
INFO - 2024-03-04 11:51:01 --> Config Class Initialized
INFO - 2024-03-04 11:51:01 --> Loader Class Initialized
INFO - 2024-03-04 11:51:01 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:01 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:01 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:01 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:02 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:02 --> Controller Class Initialized
INFO - 2024-03-04 11:51:04 --> Config Class Initialized
INFO - 2024-03-04 11:51:04 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:04 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:04 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:04 --> URI Class Initialized
INFO - 2024-03-04 11:51:04 --> Router Class Initialized
INFO - 2024-03-04 11:51:04 --> Output Class Initialized
INFO - 2024-03-04 11:51:04 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:04 --> Input Class Initialized
INFO - 2024-03-04 11:51:04 --> Language Class Initialized
INFO - 2024-03-04 11:51:04 --> Language Class Initialized
INFO - 2024-03-04 11:51:04 --> Config Class Initialized
INFO - 2024-03-04 11:51:04 --> Loader Class Initialized
INFO - 2024-03-04 11:51:04 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:04 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:04 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:04 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:04 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:04 --> Controller Class Initialized
DEBUG - 2024-03-04 11:51:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-04 11:51:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:51:04 --> Final output sent to browser
DEBUG - 2024-03-04 11:51:04 --> Total execution time: 0.0352
INFO - 2024-03-04 11:51:04 --> Config Class Initialized
INFO - 2024-03-04 11:51:04 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:04 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:04 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:04 --> URI Class Initialized
INFO - 2024-03-04 11:51:04 --> Router Class Initialized
INFO - 2024-03-04 11:51:04 --> Output Class Initialized
INFO - 2024-03-04 11:51:04 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:04 --> Input Class Initialized
INFO - 2024-03-04 11:51:04 --> Language Class Initialized
ERROR - 2024-03-04 11:51:04 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:51:04 --> Config Class Initialized
INFO - 2024-03-04 11:51:04 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:04 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:04 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:04 --> URI Class Initialized
INFO - 2024-03-04 11:51:04 --> Router Class Initialized
INFO - 2024-03-04 11:51:04 --> Output Class Initialized
INFO - 2024-03-04 11:51:04 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:04 --> Input Class Initialized
INFO - 2024-03-04 11:51:04 --> Language Class Initialized
INFO - 2024-03-04 11:51:04 --> Language Class Initialized
INFO - 2024-03-04 11:51:04 --> Config Class Initialized
INFO - 2024-03-04 11:51:04 --> Loader Class Initialized
INFO - 2024-03-04 11:51:04 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:04 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:04 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:04 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:04 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:04 --> Controller Class Initialized
INFO - 2024-03-04 11:51:06 --> Config Class Initialized
INFO - 2024-03-04 11:51:06 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:06 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:06 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:06 --> URI Class Initialized
INFO - 2024-03-04 11:51:06 --> Router Class Initialized
INFO - 2024-03-04 11:51:06 --> Output Class Initialized
INFO - 2024-03-04 11:51:06 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:06 --> Input Class Initialized
INFO - 2024-03-04 11:51:06 --> Language Class Initialized
INFO - 2024-03-04 11:51:06 --> Language Class Initialized
INFO - 2024-03-04 11:51:06 --> Config Class Initialized
INFO - 2024-03-04 11:51:06 --> Loader Class Initialized
INFO - 2024-03-04 11:51:06 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:06 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:06 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:06 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:06 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:06 --> Controller Class Initialized
INFO - 2024-03-04 11:51:06 --> Final output sent to browser
DEBUG - 2024-03-04 11:51:06 --> Total execution time: 0.1072
INFO - 2024-03-04 11:51:09 --> Config Class Initialized
INFO - 2024-03-04 11:51:09 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:09 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:09 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:09 --> URI Class Initialized
INFO - 2024-03-04 11:51:09 --> Router Class Initialized
INFO - 2024-03-04 11:51:09 --> Output Class Initialized
INFO - 2024-03-04 11:51:09 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:09 --> Input Class Initialized
INFO - 2024-03-04 11:51:09 --> Language Class Initialized
INFO - 2024-03-04 11:51:09 --> Language Class Initialized
INFO - 2024-03-04 11:51:09 --> Config Class Initialized
INFO - 2024-03-04 11:51:09 --> Loader Class Initialized
INFO - 2024-03-04 11:51:09 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:09 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:09 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:09 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:09 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:09 --> Controller Class Initialized
INFO - 2024-03-04 11:51:09 --> Final output sent to browser
DEBUG - 2024-03-04 11:51:09 --> Total execution time: 0.1206
INFO - 2024-03-04 11:51:09 --> Config Class Initialized
INFO - 2024-03-04 11:51:09 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:09 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:09 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:09 --> URI Class Initialized
INFO - 2024-03-04 11:51:09 --> Router Class Initialized
INFO - 2024-03-04 11:51:09 --> Output Class Initialized
INFO - 2024-03-04 11:51:09 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:09 --> Input Class Initialized
INFO - 2024-03-04 11:51:09 --> Language Class Initialized
ERROR - 2024-03-04 11:51:09 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:51:09 --> Config Class Initialized
INFO - 2024-03-04 11:51:09 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:51:09 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:51:09 --> Utf8 Class Initialized
INFO - 2024-03-04 11:51:09 --> URI Class Initialized
INFO - 2024-03-04 11:51:09 --> Router Class Initialized
INFO - 2024-03-04 11:51:09 --> Output Class Initialized
INFO - 2024-03-04 11:51:09 --> Security Class Initialized
DEBUG - 2024-03-04 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:51:09 --> Input Class Initialized
INFO - 2024-03-04 11:51:09 --> Language Class Initialized
INFO - 2024-03-04 11:51:09 --> Language Class Initialized
INFO - 2024-03-04 11:51:09 --> Config Class Initialized
INFO - 2024-03-04 11:51:09 --> Loader Class Initialized
INFO - 2024-03-04 11:51:09 --> Helper loaded: url_helper
INFO - 2024-03-04 11:51:09 --> Helper loaded: file_helper
INFO - 2024-03-04 11:51:09 --> Helper loaded: form_helper
INFO - 2024-03-04 11:51:09 --> Helper loaded: my_helper
INFO - 2024-03-04 11:51:09 --> Database Driver Class Initialized
INFO - 2024-03-04 11:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:51:09 --> Controller Class Initialized
INFO - 2024-03-04 11:52:23 --> Config Class Initialized
INFO - 2024-03-04 11:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:52:23 --> Utf8 Class Initialized
INFO - 2024-03-04 11:52:23 --> URI Class Initialized
INFO - 2024-03-04 11:52:23 --> Router Class Initialized
INFO - 2024-03-04 11:52:23 --> Output Class Initialized
INFO - 2024-03-04 11:52:23 --> Security Class Initialized
DEBUG - 2024-03-04 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:52:23 --> Input Class Initialized
INFO - 2024-03-04 11:52:23 --> Language Class Initialized
INFO - 2024-03-04 11:52:23 --> Language Class Initialized
INFO - 2024-03-04 11:52:23 --> Config Class Initialized
INFO - 2024-03-04 11:52:23 --> Loader Class Initialized
INFO - 2024-03-04 11:52:23 --> Helper loaded: url_helper
INFO - 2024-03-04 11:52:23 --> Helper loaded: file_helper
INFO - 2024-03-04 11:52:23 --> Helper loaded: form_helper
INFO - 2024-03-04 11:52:23 --> Helper loaded: my_helper
INFO - 2024-03-04 11:52:23 --> Database Driver Class Initialized
INFO - 2024-03-04 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:52:23 --> Controller Class Initialized
DEBUG - 2024-03-04 11:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-04 11:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:52:23 --> Final output sent to browser
DEBUG - 2024-03-04 11:52:23 --> Total execution time: 0.0443
INFO - 2024-03-04 11:52:23 --> Config Class Initialized
INFO - 2024-03-04 11:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:52:23 --> Utf8 Class Initialized
INFO - 2024-03-04 11:52:23 --> URI Class Initialized
INFO - 2024-03-04 11:52:23 --> Router Class Initialized
INFO - 2024-03-04 11:52:23 --> Output Class Initialized
INFO - 2024-03-04 11:52:23 --> Security Class Initialized
DEBUG - 2024-03-04 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:52:23 --> Input Class Initialized
INFO - 2024-03-04 11:52:23 --> Language Class Initialized
ERROR - 2024-03-04 11:52:23 --> 404 Page Not Found: /index
INFO - 2024-03-04 11:52:23 --> Config Class Initialized
INFO - 2024-03-04 11:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:52:23 --> Utf8 Class Initialized
INFO - 2024-03-04 11:52:23 --> URI Class Initialized
INFO - 2024-03-04 11:52:23 --> Router Class Initialized
INFO - 2024-03-04 11:52:23 --> Output Class Initialized
INFO - 2024-03-04 11:52:23 --> Security Class Initialized
DEBUG - 2024-03-04 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:52:23 --> Input Class Initialized
INFO - 2024-03-04 11:52:23 --> Language Class Initialized
INFO - 2024-03-04 11:52:23 --> Language Class Initialized
INFO - 2024-03-04 11:52:23 --> Config Class Initialized
INFO - 2024-03-04 11:52:23 --> Loader Class Initialized
INFO - 2024-03-04 11:52:23 --> Helper loaded: url_helper
INFO - 2024-03-04 11:52:23 --> Helper loaded: file_helper
INFO - 2024-03-04 11:52:23 --> Helper loaded: form_helper
INFO - 2024-03-04 11:52:23 --> Helper loaded: my_helper
INFO - 2024-03-04 11:52:23 --> Database Driver Class Initialized
INFO - 2024-03-04 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:52:23 --> Controller Class Initialized
INFO - 2024-03-04 11:52:26 --> Config Class Initialized
INFO - 2024-03-04 11:52:26 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:52:26 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:52:26 --> Utf8 Class Initialized
INFO - 2024-03-04 11:52:26 --> URI Class Initialized
INFO - 2024-03-04 11:52:26 --> Router Class Initialized
INFO - 2024-03-04 11:52:26 --> Output Class Initialized
INFO - 2024-03-04 11:52:26 --> Security Class Initialized
DEBUG - 2024-03-04 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:52:26 --> Input Class Initialized
INFO - 2024-03-04 11:52:26 --> Language Class Initialized
INFO - 2024-03-04 11:52:26 --> Language Class Initialized
INFO - 2024-03-04 11:52:26 --> Config Class Initialized
INFO - 2024-03-04 11:52:26 --> Loader Class Initialized
INFO - 2024-03-04 11:52:26 --> Helper loaded: url_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: file_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: form_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: my_helper
INFO - 2024-03-04 11:52:26 --> Database Driver Class Initialized
INFO - 2024-03-04 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:52:26 --> Controller Class Initialized
INFO - 2024-03-04 11:52:26 --> Helper loaded: cookie_helper
INFO - 2024-03-04 11:52:26 --> Config Class Initialized
INFO - 2024-03-04 11:52:26 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:52:26 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:52:26 --> Utf8 Class Initialized
INFO - 2024-03-04 11:52:26 --> URI Class Initialized
INFO - 2024-03-04 11:52:26 --> Router Class Initialized
INFO - 2024-03-04 11:52:26 --> Output Class Initialized
INFO - 2024-03-04 11:52:26 --> Security Class Initialized
DEBUG - 2024-03-04 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:52:26 --> Input Class Initialized
INFO - 2024-03-04 11:52:26 --> Language Class Initialized
INFO - 2024-03-04 11:52:26 --> Language Class Initialized
INFO - 2024-03-04 11:52:26 --> Config Class Initialized
INFO - 2024-03-04 11:52:26 --> Loader Class Initialized
INFO - 2024-03-04 11:52:26 --> Helper loaded: url_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: file_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: form_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: my_helper
INFO - 2024-03-04 11:52:26 --> Database Driver Class Initialized
INFO - 2024-03-04 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:52:26 --> Controller Class Initialized
INFO - 2024-03-04 11:52:26 --> Config Class Initialized
INFO - 2024-03-04 11:52:26 --> Hooks Class Initialized
DEBUG - 2024-03-04 11:52:26 --> UTF-8 Support Enabled
INFO - 2024-03-04 11:52:26 --> Utf8 Class Initialized
INFO - 2024-03-04 11:52:26 --> URI Class Initialized
INFO - 2024-03-04 11:52:26 --> Router Class Initialized
INFO - 2024-03-04 11:52:26 --> Output Class Initialized
INFO - 2024-03-04 11:52:26 --> Security Class Initialized
DEBUG - 2024-03-04 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-04 11:52:26 --> Input Class Initialized
INFO - 2024-03-04 11:52:26 --> Language Class Initialized
INFO - 2024-03-04 11:52:26 --> Language Class Initialized
INFO - 2024-03-04 11:52:26 --> Config Class Initialized
INFO - 2024-03-04 11:52:26 --> Loader Class Initialized
INFO - 2024-03-04 11:52:26 --> Helper loaded: url_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: file_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: form_helper
INFO - 2024-03-04 11:52:26 --> Helper loaded: my_helper
INFO - 2024-03-04 11:52:26 --> Database Driver Class Initialized
INFO - 2024-03-04 11:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-04 11:52:26 --> Controller Class Initialized
DEBUG - 2024-03-04 11:52:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-04 11:52:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-04 11:52:26 --> Final output sent to browser
DEBUG - 2024-03-04 11:52:26 --> Total execution time: 0.0661
