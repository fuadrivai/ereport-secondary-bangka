<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-12 10:14:51 --> Config Class Initialized
INFO - 2024-08-12 10:14:51 --> Hooks Class Initialized
DEBUG - 2024-08-12 10:14:51 --> UTF-8 Support Enabled
INFO - 2024-08-12 10:14:51 --> Utf8 Class Initialized
INFO - 2024-08-12 10:14:51 --> URI Class Initialized
INFO - 2024-08-12 10:14:51 --> Router Class Initialized
INFO - 2024-08-12 10:14:51 --> Output Class Initialized
INFO - 2024-08-12 10:14:51 --> Security Class Initialized
DEBUG - 2024-08-12 10:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 10:14:51 --> Input Class Initialized
INFO - 2024-08-12 10:14:51 --> Language Class Initialized
INFO - 2024-08-12 10:14:51 --> Language Class Initialized
INFO - 2024-08-12 10:14:51 --> Config Class Initialized
INFO - 2024-08-12 10:14:51 --> Loader Class Initialized
INFO - 2024-08-12 10:14:51 --> Helper loaded: url_helper
INFO - 2024-08-12 10:14:51 --> Helper loaded: file_helper
INFO - 2024-08-12 10:14:51 --> Helper loaded: form_helper
INFO - 2024-08-12 10:14:51 --> Helper loaded: my_helper
INFO - 2024-08-12 10:14:51 --> Database Driver Class Initialized
INFO - 2024-08-12 10:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 10:14:51 --> Controller Class Initialized
INFO - 2024-08-12 10:14:51 --> Helper loaded: cookie_helper
INFO - 2024-08-12 10:14:51 --> Final output sent to browser
DEBUG - 2024-08-12 10:14:51 --> Total execution time: 0.0620
INFO - 2024-08-12 10:14:51 --> Config Class Initialized
INFO - 2024-08-12 10:14:51 --> Hooks Class Initialized
DEBUG - 2024-08-12 10:14:51 --> UTF-8 Support Enabled
INFO - 2024-08-12 10:14:51 --> Utf8 Class Initialized
INFO - 2024-08-12 10:14:51 --> URI Class Initialized
INFO - 2024-08-12 10:14:51 --> Router Class Initialized
INFO - 2024-08-12 10:14:51 --> Output Class Initialized
INFO - 2024-08-12 10:14:51 --> Security Class Initialized
DEBUG - 2024-08-12 10:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 10:14:51 --> Input Class Initialized
INFO - 2024-08-12 10:14:51 --> Language Class Initialized
INFO - 2024-08-12 10:14:51 --> Language Class Initialized
INFO - 2024-08-12 10:14:51 --> Config Class Initialized
INFO - 2024-08-12 10:14:51 --> Loader Class Initialized
INFO - 2024-08-12 10:14:51 --> Helper loaded: url_helper
INFO - 2024-08-12 10:14:51 --> Helper loaded: file_helper
INFO - 2024-08-12 10:14:51 --> Helper loaded: form_helper
INFO - 2024-08-12 10:14:51 --> Helper loaded: my_helper
INFO - 2024-08-12 10:14:51 --> Database Driver Class Initialized
INFO - 2024-08-12 10:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 10:14:51 --> Controller Class Initialized
INFO - 2024-08-12 10:14:51 --> Helper loaded: cookie_helper
INFO - 2024-08-12 10:14:52 --> Config Class Initialized
INFO - 2024-08-12 10:14:52 --> Hooks Class Initialized
DEBUG - 2024-08-12 10:14:52 --> UTF-8 Support Enabled
INFO - 2024-08-12 10:14:52 --> Utf8 Class Initialized
INFO - 2024-08-12 10:14:52 --> URI Class Initialized
INFO - 2024-08-12 10:14:52 --> Router Class Initialized
INFO - 2024-08-12 10:14:52 --> Output Class Initialized
INFO - 2024-08-12 10:14:52 --> Security Class Initialized
DEBUG - 2024-08-12 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 10:14:52 --> Input Class Initialized
INFO - 2024-08-12 10:14:52 --> Language Class Initialized
INFO - 2024-08-12 10:14:52 --> Language Class Initialized
INFO - 2024-08-12 10:14:52 --> Config Class Initialized
INFO - 2024-08-12 10:14:52 --> Loader Class Initialized
INFO - 2024-08-12 10:14:52 --> Helper loaded: url_helper
INFO - 2024-08-12 10:14:52 --> Helper loaded: file_helper
INFO - 2024-08-12 10:14:52 --> Helper loaded: form_helper
INFO - 2024-08-12 10:14:52 --> Helper loaded: my_helper
INFO - 2024-08-12 10:14:52 --> Database Driver Class Initialized
INFO - 2024-08-12 10:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 10:14:52 --> Controller Class Initialized
DEBUG - 2024-08-12 10:14:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-12 10:14:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-12 10:14:52 --> Final output sent to browser
DEBUG - 2024-08-12 10:14:52 --> Total execution time: 0.0376
INFO - 2024-08-12 16:38:51 --> Config Class Initialized
INFO - 2024-08-12 16:38:51 --> Hooks Class Initialized
DEBUG - 2024-08-12 16:38:51 --> UTF-8 Support Enabled
INFO - 2024-08-12 16:38:51 --> Utf8 Class Initialized
INFO - 2024-08-12 16:38:51 --> URI Class Initialized
INFO - 2024-08-12 16:38:51 --> Router Class Initialized
INFO - 2024-08-12 16:38:51 --> Output Class Initialized
INFO - 2024-08-12 16:38:51 --> Security Class Initialized
DEBUG - 2024-08-12 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 16:38:51 --> Input Class Initialized
INFO - 2024-08-12 16:38:51 --> Language Class Initialized
INFO - 2024-08-12 16:38:51 --> Language Class Initialized
INFO - 2024-08-12 16:38:51 --> Config Class Initialized
INFO - 2024-08-12 16:38:51 --> Loader Class Initialized
INFO - 2024-08-12 16:38:51 --> Helper loaded: url_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: file_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: form_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: my_helper
INFO - 2024-08-12 16:38:51 --> Database Driver Class Initialized
INFO - 2024-08-12 16:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 16:38:51 --> Controller Class Initialized
INFO - 2024-08-12 16:38:51 --> Helper loaded: cookie_helper
INFO - 2024-08-12 16:38:51 --> Final output sent to browser
DEBUG - 2024-08-12 16:38:51 --> Total execution time: 0.0739
INFO - 2024-08-12 16:38:51 --> Config Class Initialized
INFO - 2024-08-12 16:38:51 --> Hooks Class Initialized
DEBUG - 2024-08-12 16:38:51 --> UTF-8 Support Enabled
INFO - 2024-08-12 16:38:51 --> Utf8 Class Initialized
INFO - 2024-08-12 16:38:51 --> URI Class Initialized
INFO - 2024-08-12 16:38:51 --> Router Class Initialized
INFO - 2024-08-12 16:38:51 --> Output Class Initialized
INFO - 2024-08-12 16:38:51 --> Security Class Initialized
DEBUG - 2024-08-12 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 16:38:51 --> Input Class Initialized
INFO - 2024-08-12 16:38:51 --> Language Class Initialized
INFO - 2024-08-12 16:38:51 --> Language Class Initialized
INFO - 2024-08-12 16:38:51 --> Config Class Initialized
INFO - 2024-08-12 16:38:51 --> Loader Class Initialized
INFO - 2024-08-12 16:38:51 --> Helper loaded: url_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: file_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: form_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: my_helper
INFO - 2024-08-12 16:38:51 --> Database Driver Class Initialized
INFO - 2024-08-12 16:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 16:38:51 --> Controller Class Initialized
INFO - 2024-08-12 16:38:51 --> Helper loaded: cookie_helper
INFO - 2024-08-12 16:38:51 --> Config Class Initialized
INFO - 2024-08-12 16:38:51 --> Hooks Class Initialized
DEBUG - 2024-08-12 16:38:51 --> UTF-8 Support Enabled
INFO - 2024-08-12 16:38:51 --> Utf8 Class Initialized
INFO - 2024-08-12 16:38:51 --> URI Class Initialized
INFO - 2024-08-12 16:38:51 --> Router Class Initialized
INFO - 2024-08-12 16:38:51 --> Output Class Initialized
INFO - 2024-08-12 16:38:51 --> Security Class Initialized
DEBUG - 2024-08-12 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 16:38:51 --> Input Class Initialized
INFO - 2024-08-12 16:38:51 --> Language Class Initialized
INFO - 2024-08-12 16:38:51 --> Language Class Initialized
INFO - 2024-08-12 16:38:51 --> Config Class Initialized
INFO - 2024-08-12 16:38:51 --> Loader Class Initialized
INFO - 2024-08-12 16:38:51 --> Helper loaded: url_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: file_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: form_helper
INFO - 2024-08-12 16:38:51 --> Helper loaded: my_helper
INFO - 2024-08-12 16:38:51 --> Database Driver Class Initialized
INFO - 2024-08-12 16:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 16:38:51 --> Controller Class Initialized
DEBUG - 2024-08-12 16:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-12 16:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-12 16:38:51 --> Final output sent to browser
DEBUG - 2024-08-12 16:38:51 --> Total execution time: 0.0508
INFO - 2024-08-12 16:38:56 --> Config Class Initialized
INFO - 2024-08-12 16:38:56 --> Hooks Class Initialized
DEBUG - 2024-08-12 16:38:56 --> UTF-8 Support Enabled
INFO - 2024-08-12 16:38:56 --> Utf8 Class Initialized
INFO - 2024-08-12 16:38:56 --> URI Class Initialized
INFO - 2024-08-12 16:38:56 --> Router Class Initialized
INFO - 2024-08-12 16:38:56 --> Output Class Initialized
INFO - 2024-08-12 16:38:56 --> Security Class Initialized
DEBUG - 2024-08-12 16:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 16:38:56 --> Input Class Initialized
INFO - 2024-08-12 16:38:56 --> Language Class Initialized
INFO - 2024-08-12 16:38:56 --> Language Class Initialized
INFO - 2024-08-12 16:38:56 --> Config Class Initialized
INFO - 2024-08-12 16:38:56 --> Loader Class Initialized
INFO - 2024-08-12 16:38:56 --> Helper loaded: url_helper
INFO - 2024-08-12 16:38:56 --> Helper loaded: file_helper
INFO - 2024-08-12 16:38:56 --> Helper loaded: form_helper
INFO - 2024-08-12 16:38:56 --> Helper loaded: my_helper
INFO - 2024-08-12 16:38:56 --> Database Driver Class Initialized
INFO - 2024-08-12 16:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 16:38:56 --> Controller Class Initialized
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-12 16:38:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-12 16:38:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-12 16:38:57 --> Config Class Initialized
INFO - 2024-08-12 16:38:57 --> Hooks Class Initialized
DEBUG - 2024-08-12 16:38:57 --> UTF-8 Support Enabled
INFO - 2024-08-12 16:38:57 --> Utf8 Class Initialized
INFO - 2024-08-12 16:38:57 --> URI Class Initialized
INFO - 2024-08-12 16:38:57 --> Router Class Initialized
INFO - 2024-08-12 16:38:57 --> Output Class Initialized
INFO - 2024-08-12 16:38:57 --> Security Class Initialized
DEBUG - 2024-08-12 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 16:38:57 --> Input Class Initialized
INFO - 2024-08-12 16:38:57 --> Language Class Initialized
INFO - 2024-08-12 16:38:57 --> Language Class Initialized
INFO - 2024-08-12 16:38:57 --> Config Class Initialized
INFO - 2024-08-12 16:38:57 --> Loader Class Initialized
INFO - 2024-08-12 16:38:57 --> Helper loaded: url_helper
INFO - 2024-08-12 16:38:57 --> Helper loaded: file_helper
INFO - 2024-08-12 16:38:57 --> Helper loaded: form_helper
INFO - 2024-08-12 16:38:57 --> Helper loaded: my_helper
INFO - 2024-08-12 16:38:57 --> Database Driver Class Initialized
INFO - 2024-08-12 16:38:59 --> Final output sent to browser
DEBUG - 2024-08-12 16:38:59 --> Total execution time: 3.4543
INFO - 2024-08-12 16:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 16:38:59 --> Controller Class Initialized
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-12 16:38:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-12 16:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-12 16:39:03 --> Final output sent to browser
DEBUG - 2024-08-12 16:39:03 --> Total execution time: 6.4844
INFO - 2024-08-12 19:25:52 --> Config Class Initialized
INFO - 2024-08-12 19:25:52 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:25:52 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:25:52 --> Utf8 Class Initialized
INFO - 2024-08-12 19:25:52 --> URI Class Initialized
INFO - 2024-08-12 19:25:52 --> Router Class Initialized
INFO - 2024-08-12 19:25:52 --> Output Class Initialized
INFO - 2024-08-12 19:25:52 --> Security Class Initialized
DEBUG - 2024-08-12 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:25:52 --> Input Class Initialized
INFO - 2024-08-12 19:25:52 --> Language Class Initialized
INFO - 2024-08-12 19:25:52 --> Language Class Initialized
INFO - 2024-08-12 19:25:52 --> Config Class Initialized
INFO - 2024-08-12 19:25:52 --> Loader Class Initialized
INFO - 2024-08-12 19:25:52 --> Helper loaded: url_helper
INFO - 2024-08-12 19:25:52 --> Helper loaded: file_helper
INFO - 2024-08-12 19:25:52 --> Helper loaded: form_helper
INFO - 2024-08-12 19:25:52 --> Helper loaded: my_helper
INFO - 2024-08-12 19:25:52 --> Database Driver Class Initialized
INFO - 2024-08-12 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:25:52 --> Controller Class Initialized
INFO - 2024-08-12 19:25:52 --> Helper loaded: cookie_helper
INFO - 2024-08-12 19:25:52 --> Final output sent to browser
DEBUG - 2024-08-12 19:25:52 --> Total execution time: 0.1998
INFO - 2024-08-12 19:25:52 --> Config Class Initialized
INFO - 2024-08-12 19:25:52 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:25:52 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:25:52 --> Utf8 Class Initialized
INFO - 2024-08-12 19:25:52 --> URI Class Initialized
INFO - 2024-08-12 19:25:52 --> Router Class Initialized
INFO - 2024-08-12 19:25:52 --> Output Class Initialized
INFO - 2024-08-12 19:25:52 --> Security Class Initialized
DEBUG - 2024-08-12 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:25:52 --> Input Class Initialized
INFO - 2024-08-12 19:25:52 --> Language Class Initialized
INFO - 2024-08-12 19:25:52 --> Language Class Initialized
INFO - 2024-08-12 19:25:52 --> Config Class Initialized
INFO - 2024-08-12 19:25:52 --> Loader Class Initialized
INFO - 2024-08-12 19:25:52 --> Helper loaded: url_helper
INFO - 2024-08-12 19:25:52 --> Helper loaded: file_helper
INFO - 2024-08-12 19:25:52 --> Helper loaded: form_helper
INFO - 2024-08-12 19:25:52 --> Helper loaded: my_helper
INFO - 2024-08-12 19:25:52 --> Database Driver Class Initialized
INFO - 2024-08-12 19:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:25:52 --> Controller Class Initialized
INFO - 2024-08-12 19:25:52 --> Helper loaded: cookie_helper
INFO - 2024-08-12 19:25:52 --> Config Class Initialized
INFO - 2024-08-12 19:25:52 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:25:52 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:25:52 --> Utf8 Class Initialized
INFO - 2024-08-12 19:25:53 --> URI Class Initialized
INFO - 2024-08-12 19:25:53 --> Router Class Initialized
INFO - 2024-08-12 19:25:53 --> Output Class Initialized
INFO - 2024-08-12 19:25:53 --> Security Class Initialized
DEBUG - 2024-08-12 19:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:25:53 --> Input Class Initialized
INFO - 2024-08-12 19:25:53 --> Language Class Initialized
INFO - 2024-08-12 19:25:53 --> Language Class Initialized
INFO - 2024-08-12 19:25:53 --> Config Class Initialized
INFO - 2024-08-12 19:25:53 --> Loader Class Initialized
INFO - 2024-08-12 19:25:53 --> Helper loaded: url_helper
INFO - 2024-08-12 19:25:53 --> Helper loaded: file_helper
INFO - 2024-08-12 19:25:53 --> Helper loaded: form_helper
INFO - 2024-08-12 19:25:53 --> Helper loaded: my_helper
INFO - 2024-08-12 19:25:53 --> Database Driver Class Initialized
INFO - 2024-08-12 19:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:25:53 --> Controller Class Initialized
DEBUG - 2024-08-12 19:25:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-12 19:25:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-12 19:25:53 --> Final output sent to browser
DEBUG - 2024-08-12 19:25:53 --> Total execution time: 0.3088
INFO - 2024-08-12 19:25:57 --> Config Class Initialized
INFO - 2024-08-12 19:25:57 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:25:57 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:25:57 --> Utf8 Class Initialized
INFO - 2024-08-12 19:25:57 --> URI Class Initialized
INFO - 2024-08-12 19:25:57 --> Router Class Initialized
INFO - 2024-08-12 19:25:57 --> Output Class Initialized
INFO - 2024-08-12 19:25:57 --> Security Class Initialized
DEBUG - 2024-08-12 19:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:25:57 --> Input Class Initialized
INFO - 2024-08-12 19:25:57 --> Language Class Initialized
INFO - 2024-08-12 19:25:57 --> Language Class Initialized
INFO - 2024-08-12 19:25:57 --> Config Class Initialized
INFO - 2024-08-12 19:25:57 --> Loader Class Initialized
INFO - 2024-08-12 19:25:57 --> Helper loaded: url_helper
INFO - 2024-08-12 19:25:57 --> Helper loaded: file_helper
INFO - 2024-08-12 19:25:57 --> Helper loaded: form_helper
INFO - 2024-08-12 19:25:57 --> Helper loaded: my_helper
INFO - 2024-08-12 19:25:57 --> Database Driver Class Initialized
INFO - 2024-08-12 19:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:25:57 --> Controller Class Initialized
DEBUG - 2024-08-12 19:25:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-12 19:26:02 --> Final output sent to browser
DEBUG - 2024-08-12 19:26:02 --> Total execution time: 4.7626
INFO - 2024-08-12 19:39:18 --> Config Class Initialized
INFO - 2024-08-12 19:39:18 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:39:18 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:39:18 --> Utf8 Class Initialized
INFO - 2024-08-12 19:39:18 --> URI Class Initialized
INFO - 2024-08-12 19:39:18 --> Router Class Initialized
INFO - 2024-08-12 19:39:18 --> Output Class Initialized
INFO - 2024-08-12 19:39:18 --> Security Class Initialized
DEBUG - 2024-08-12 19:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:39:18 --> Input Class Initialized
INFO - 2024-08-12 19:39:18 --> Language Class Initialized
INFO - 2024-08-12 19:39:18 --> Language Class Initialized
INFO - 2024-08-12 19:39:18 --> Config Class Initialized
INFO - 2024-08-12 19:39:18 --> Loader Class Initialized
INFO - 2024-08-12 19:39:18 --> Helper loaded: url_helper
INFO - 2024-08-12 19:39:18 --> Helper loaded: file_helper
INFO - 2024-08-12 19:39:18 --> Helper loaded: form_helper
INFO - 2024-08-12 19:39:18 --> Helper loaded: my_helper
INFO - 2024-08-12 19:39:18 --> Database Driver Class Initialized
INFO - 2024-08-12 19:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:39:18 --> Controller Class Initialized
INFO - 2024-08-12 19:39:18 --> Helper loaded: cookie_helper
INFO - 2024-08-12 19:39:18 --> Final output sent to browser
DEBUG - 2024-08-12 19:39:18 --> Total execution time: 0.0703
INFO - 2024-08-12 19:39:19 --> Config Class Initialized
INFO - 2024-08-12 19:39:19 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:39:19 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:39:19 --> Utf8 Class Initialized
INFO - 2024-08-12 19:39:19 --> URI Class Initialized
INFO - 2024-08-12 19:39:19 --> Router Class Initialized
INFO - 2024-08-12 19:39:19 --> Output Class Initialized
INFO - 2024-08-12 19:39:19 --> Security Class Initialized
DEBUG - 2024-08-12 19:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:39:19 --> Input Class Initialized
INFO - 2024-08-12 19:39:19 --> Language Class Initialized
INFO - 2024-08-12 19:39:19 --> Language Class Initialized
INFO - 2024-08-12 19:39:19 --> Config Class Initialized
INFO - 2024-08-12 19:39:19 --> Loader Class Initialized
INFO - 2024-08-12 19:39:19 --> Helper loaded: url_helper
INFO - 2024-08-12 19:39:19 --> Helper loaded: file_helper
INFO - 2024-08-12 19:39:19 --> Helper loaded: form_helper
INFO - 2024-08-12 19:39:19 --> Helper loaded: my_helper
INFO - 2024-08-12 19:39:19 --> Database Driver Class Initialized
INFO - 2024-08-12 19:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:39:19 --> Controller Class Initialized
INFO - 2024-08-12 19:39:19 --> Helper loaded: cookie_helper
INFO - 2024-08-12 19:39:19 --> Config Class Initialized
INFO - 2024-08-12 19:39:19 --> Hooks Class Initialized
DEBUG - 2024-08-12 19:39:19 --> UTF-8 Support Enabled
INFO - 2024-08-12 19:39:19 --> Utf8 Class Initialized
INFO - 2024-08-12 19:39:19 --> URI Class Initialized
INFO - 2024-08-12 19:39:19 --> Router Class Initialized
INFO - 2024-08-12 19:39:19 --> Output Class Initialized
INFO - 2024-08-12 19:39:19 --> Security Class Initialized
DEBUG - 2024-08-12 19:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 19:39:19 --> Input Class Initialized
INFO - 2024-08-12 19:39:19 --> Language Class Initialized
INFO - 2024-08-12 19:39:19 --> Language Class Initialized
INFO - 2024-08-12 19:39:19 --> Config Class Initialized
INFO - 2024-08-12 19:39:19 --> Loader Class Initialized
INFO - 2024-08-12 19:39:19 --> Helper loaded: url_helper
INFO - 2024-08-12 19:39:19 --> Helper loaded: file_helper
INFO - 2024-08-12 19:39:19 --> Helper loaded: form_helper
INFO - 2024-08-12 19:39:19 --> Helper loaded: my_helper
INFO - 2024-08-12 19:39:19 --> Database Driver Class Initialized
INFO - 2024-08-12 19:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 19:39:19 --> Controller Class Initialized
DEBUG - 2024-08-12 19:39:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-12 19:39:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-12 19:39:19 --> Final output sent to browser
DEBUG - 2024-08-12 19:39:19 --> Total execution time: 0.0364
INFO - 2024-08-12 23:55:28 --> Config Class Initialized
INFO - 2024-08-12 23:55:28 --> Hooks Class Initialized
DEBUG - 2024-08-12 23:55:28 --> UTF-8 Support Enabled
INFO - 2024-08-12 23:55:28 --> Utf8 Class Initialized
INFO - 2024-08-12 23:55:28 --> URI Class Initialized
INFO - 2024-08-12 23:55:28 --> Router Class Initialized
INFO - 2024-08-12 23:55:28 --> Output Class Initialized
INFO - 2024-08-12 23:55:28 --> Security Class Initialized
DEBUG - 2024-08-12 23:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 23:55:28 --> Input Class Initialized
INFO - 2024-08-12 23:55:28 --> Language Class Initialized
INFO - 2024-08-12 23:55:28 --> Language Class Initialized
INFO - 2024-08-12 23:55:28 --> Config Class Initialized
INFO - 2024-08-12 23:55:28 --> Loader Class Initialized
INFO - 2024-08-12 23:55:28 --> Helper loaded: url_helper
INFO - 2024-08-12 23:55:28 --> Helper loaded: file_helper
INFO - 2024-08-12 23:55:28 --> Helper loaded: form_helper
INFO - 2024-08-12 23:55:28 --> Helper loaded: my_helper
INFO - 2024-08-12 23:55:28 --> Database Driver Class Initialized
INFO - 2024-08-12 23:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 23:55:28 --> Controller Class Initialized
INFO - 2024-08-12 23:55:28 --> Helper loaded: cookie_helper
INFO - 2024-08-12 23:55:28 --> Final output sent to browser
DEBUG - 2024-08-12 23:55:28 --> Total execution time: 0.0680
INFO - 2024-08-12 23:55:28 --> Config Class Initialized
INFO - 2024-08-12 23:55:28 --> Hooks Class Initialized
DEBUG - 2024-08-12 23:55:28 --> UTF-8 Support Enabled
INFO - 2024-08-12 23:55:28 --> Utf8 Class Initialized
INFO - 2024-08-12 23:55:28 --> URI Class Initialized
INFO - 2024-08-12 23:55:28 --> Router Class Initialized
INFO - 2024-08-12 23:55:28 --> Output Class Initialized
INFO - 2024-08-12 23:55:28 --> Security Class Initialized
DEBUG - 2024-08-12 23:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 23:55:28 --> Input Class Initialized
INFO - 2024-08-12 23:55:28 --> Language Class Initialized
INFO - 2024-08-12 23:55:28 --> Language Class Initialized
INFO - 2024-08-12 23:55:28 --> Config Class Initialized
INFO - 2024-08-12 23:55:28 --> Loader Class Initialized
INFO - 2024-08-12 23:55:28 --> Helper loaded: url_helper
INFO - 2024-08-12 23:55:28 --> Helper loaded: file_helper
INFO - 2024-08-12 23:55:28 --> Helper loaded: form_helper
INFO - 2024-08-12 23:55:28 --> Helper loaded: my_helper
INFO - 2024-08-12 23:55:28 --> Database Driver Class Initialized
INFO - 2024-08-12 23:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 23:55:28 --> Controller Class Initialized
INFO - 2024-08-12 23:55:28 --> Helper loaded: cookie_helper
INFO - 2024-08-12 23:55:29 --> Config Class Initialized
INFO - 2024-08-12 23:55:29 --> Hooks Class Initialized
DEBUG - 2024-08-12 23:55:29 --> UTF-8 Support Enabled
INFO - 2024-08-12 23:55:29 --> Utf8 Class Initialized
INFO - 2024-08-12 23:55:29 --> URI Class Initialized
INFO - 2024-08-12 23:55:29 --> Router Class Initialized
INFO - 2024-08-12 23:55:29 --> Output Class Initialized
INFO - 2024-08-12 23:55:29 --> Security Class Initialized
DEBUG - 2024-08-12 23:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-12 23:55:29 --> Input Class Initialized
INFO - 2024-08-12 23:55:29 --> Language Class Initialized
INFO - 2024-08-12 23:55:29 --> Language Class Initialized
INFO - 2024-08-12 23:55:29 --> Config Class Initialized
INFO - 2024-08-12 23:55:29 --> Loader Class Initialized
INFO - 2024-08-12 23:55:29 --> Helper loaded: url_helper
INFO - 2024-08-12 23:55:29 --> Helper loaded: file_helper
INFO - 2024-08-12 23:55:29 --> Helper loaded: form_helper
INFO - 2024-08-12 23:55:29 --> Helper loaded: my_helper
INFO - 2024-08-12 23:55:29 --> Database Driver Class Initialized
INFO - 2024-08-12 23:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-12 23:55:29 --> Controller Class Initialized
DEBUG - 2024-08-12 23:55:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-12 23:55:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-12 23:55:29 --> Final output sent to browser
DEBUG - 2024-08-12 23:55:29 --> Total execution time: 0.0512
