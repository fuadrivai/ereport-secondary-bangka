<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-16 09:34:47 --> Config Class Initialized
INFO - 2024-01-16 09:34:47 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:34:47 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:34:47 --> Utf8 Class Initialized
INFO - 2024-01-16 09:34:47 --> URI Class Initialized
INFO - 2024-01-16 09:34:47 --> Router Class Initialized
INFO - 2024-01-16 09:34:47 --> Output Class Initialized
INFO - 2024-01-16 09:34:47 --> Security Class Initialized
DEBUG - 2024-01-16 09:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:34:47 --> Input Class Initialized
INFO - 2024-01-16 09:34:47 --> Language Class Initialized
INFO - 2024-01-16 09:34:47 --> Language Class Initialized
INFO - 2024-01-16 09:34:47 --> Config Class Initialized
INFO - 2024-01-16 09:34:47 --> Loader Class Initialized
INFO - 2024-01-16 09:34:47 --> Helper loaded: url_helper
INFO - 2024-01-16 09:34:47 --> Helper loaded: file_helper
INFO - 2024-01-16 09:34:47 --> Helper loaded: form_helper
INFO - 2024-01-16 09:34:47 --> Helper loaded: my_helper
INFO - 2024-01-16 09:34:47 --> Database Driver Class Initialized
INFO - 2024-01-16 09:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:34:47 --> Controller Class Initialized
DEBUG - 2024-01-16 09:34:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 09:34:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:34:47 --> Final output sent to browser
DEBUG - 2024-01-16 09:34:47 --> Total execution time: 0.1266
INFO - 2024-01-16 09:34:47 --> Config Class Initialized
INFO - 2024-01-16 09:34:47 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:34:47 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:34:47 --> Utf8 Class Initialized
INFO - 2024-01-16 09:34:47 --> URI Class Initialized
INFO - 2024-01-16 09:34:47 --> Router Class Initialized
INFO - 2024-01-16 09:34:47 --> Output Class Initialized
INFO - 2024-01-16 09:34:47 --> Security Class Initialized
DEBUG - 2024-01-16 09:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:34:47 --> Input Class Initialized
INFO - 2024-01-16 09:34:47 --> Language Class Initialized
INFO - 2024-01-16 09:34:47 --> Language Class Initialized
INFO - 2024-01-16 09:34:47 --> Config Class Initialized
INFO - 2024-01-16 09:34:47 --> Loader Class Initialized
INFO - 2024-01-16 09:34:47 --> Helper loaded: url_helper
INFO - 2024-01-16 09:34:47 --> Helper loaded: file_helper
INFO - 2024-01-16 09:34:47 --> Helper loaded: form_helper
INFO - 2024-01-16 09:34:47 --> Helper loaded: my_helper
INFO - 2024-01-16 09:34:47 --> Database Driver Class Initialized
INFO - 2024-01-16 09:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:34:47 --> Controller Class Initialized
INFO - 2024-01-16 09:35:33 --> Config Class Initialized
INFO - 2024-01-16 09:35:33 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:33 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:33 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:33 --> URI Class Initialized
DEBUG - 2024-01-16 09:35:33 --> No URI present. Default controller set.
INFO - 2024-01-16 09:35:33 --> Router Class Initialized
INFO - 2024-01-16 09:35:34 --> Output Class Initialized
INFO - 2024-01-16 09:35:34 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:34 --> Input Class Initialized
INFO - 2024-01-16 09:35:34 --> Language Class Initialized
INFO - 2024-01-16 09:35:34 --> Language Class Initialized
INFO - 2024-01-16 09:35:34 --> Config Class Initialized
INFO - 2024-01-16 09:35:34 --> Loader Class Initialized
INFO - 2024-01-16 09:35:34 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:34 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:34 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:34 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:34 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:34 --> Controller Class Initialized
INFO - 2024-01-16 09:35:34 --> Config Class Initialized
INFO - 2024-01-16 09:35:34 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:34 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:34 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:34 --> URI Class Initialized
INFO - 2024-01-16 09:35:34 --> Router Class Initialized
INFO - 2024-01-16 09:35:34 --> Output Class Initialized
INFO - 2024-01-16 09:35:34 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:34 --> Input Class Initialized
INFO - 2024-01-16 09:35:34 --> Language Class Initialized
INFO - 2024-01-16 09:35:34 --> Language Class Initialized
INFO - 2024-01-16 09:35:34 --> Config Class Initialized
INFO - 2024-01-16 09:35:34 --> Loader Class Initialized
INFO - 2024-01-16 09:35:34 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:34 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:34 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:34 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:34 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:34 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 09:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:34 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:34 --> Total execution time: 0.1517
INFO - 2024-01-16 09:35:36 --> Config Class Initialized
INFO - 2024-01-16 09:35:36 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:36 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:36 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:36 --> URI Class Initialized
INFO - 2024-01-16 09:35:36 --> Router Class Initialized
INFO - 2024-01-16 09:35:36 --> Output Class Initialized
INFO - 2024-01-16 09:35:36 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:36 --> Input Class Initialized
INFO - 2024-01-16 09:35:36 --> Language Class Initialized
INFO - 2024-01-16 09:35:36 --> Language Class Initialized
INFO - 2024-01-16 09:35:36 --> Config Class Initialized
INFO - 2024-01-16 09:35:36 --> Loader Class Initialized
INFO - 2024-01-16 09:35:36 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:36 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:36 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:36 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:37 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:37 --> Controller Class Initialized
INFO - 2024-01-16 09:35:37 --> Helper loaded: cookie_helper
INFO - 2024-01-16 09:35:37 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:37 --> Total execution time: 0.0541
INFO - 2024-01-16 09:35:37 --> Config Class Initialized
INFO - 2024-01-16 09:35:37 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:37 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:37 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:37 --> URI Class Initialized
INFO - 2024-01-16 09:35:37 --> Router Class Initialized
INFO - 2024-01-16 09:35:37 --> Output Class Initialized
INFO - 2024-01-16 09:35:37 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:37 --> Input Class Initialized
INFO - 2024-01-16 09:35:37 --> Language Class Initialized
INFO - 2024-01-16 09:35:37 --> Language Class Initialized
INFO - 2024-01-16 09:35:37 --> Config Class Initialized
INFO - 2024-01-16 09:35:37 --> Loader Class Initialized
INFO - 2024-01-16 09:35:37 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:37 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:37 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:37 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:37 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:37 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 09:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:37 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:37 --> Total execution time: 0.0414
INFO - 2024-01-16 09:35:40 --> Config Class Initialized
INFO - 2024-01-16 09:35:40 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:40 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:40 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:40 --> URI Class Initialized
INFO - 2024-01-16 09:35:40 --> Router Class Initialized
INFO - 2024-01-16 09:35:40 --> Output Class Initialized
INFO - 2024-01-16 09:35:40 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:40 --> Input Class Initialized
INFO - 2024-01-16 09:35:40 --> Language Class Initialized
INFO - 2024-01-16 09:35:40 --> Language Class Initialized
INFO - 2024-01-16 09:35:40 --> Config Class Initialized
INFO - 2024-01-16 09:35:40 --> Loader Class Initialized
INFO - 2024-01-16 09:35:40 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:40 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:40 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:40 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:40 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:40 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:40 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:40 --> Total execution time: 0.0491
INFO - 2024-01-16 09:35:47 --> Config Class Initialized
INFO - 2024-01-16 09:35:47 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:47 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:47 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:47 --> URI Class Initialized
INFO - 2024-01-16 09:35:47 --> Router Class Initialized
INFO - 2024-01-16 09:35:47 --> Output Class Initialized
INFO - 2024-01-16 09:35:47 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:47 --> Input Class Initialized
INFO - 2024-01-16 09:35:47 --> Language Class Initialized
INFO - 2024-01-16 09:35:47 --> Language Class Initialized
INFO - 2024-01-16 09:35:47 --> Config Class Initialized
INFO - 2024-01-16 09:35:47 --> Loader Class Initialized
INFO - 2024-01-16 09:35:47 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:47 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:47 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:47 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:47 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:47 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:35:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:47 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:47 --> Total execution time: 0.0336
INFO - 2024-01-16 09:35:51 --> Config Class Initialized
INFO - 2024-01-16 09:35:51 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:51 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:51 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:51 --> URI Class Initialized
INFO - 2024-01-16 09:35:51 --> Router Class Initialized
INFO - 2024-01-16 09:35:51 --> Output Class Initialized
INFO - 2024-01-16 09:35:51 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:51 --> Input Class Initialized
INFO - 2024-01-16 09:35:51 --> Language Class Initialized
INFO - 2024-01-16 09:35:51 --> Language Class Initialized
INFO - 2024-01-16 09:35:51 --> Config Class Initialized
INFO - 2024-01-16 09:35:51 --> Loader Class Initialized
INFO - 2024-01-16 09:35:51 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:51 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:51 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:51 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:51 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:51 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-01-16 09:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:51 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:51 --> Total execution time: 0.0468
INFO - 2024-01-16 09:35:54 --> Config Class Initialized
INFO - 2024-01-16 09:35:54 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:54 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:54 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:54 --> URI Class Initialized
INFO - 2024-01-16 09:35:54 --> Router Class Initialized
INFO - 2024-01-16 09:35:54 --> Output Class Initialized
INFO - 2024-01-16 09:35:54 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:54 --> Input Class Initialized
INFO - 2024-01-16 09:35:54 --> Language Class Initialized
INFO - 2024-01-16 09:35:54 --> Language Class Initialized
INFO - 2024-01-16 09:35:54 --> Config Class Initialized
INFO - 2024-01-16 09:35:54 --> Loader Class Initialized
INFO - 2024-01-16 09:35:54 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:54 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:54 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:54 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:54 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:54 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:54 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:54 --> Total execution time: 0.0955
INFO - 2024-01-16 09:35:56 --> Config Class Initialized
INFO - 2024-01-16 09:35:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:56 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:56 --> URI Class Initialized
INFO - 2024-01-16 09:35:56 --> Router Class Initialized
INFO - 2024-01-16 09:35:56 --> Output Class Initialized
INFO - 2024-01-16 09:35:56 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:56 --> Input Class Initialized
INFO - 2024-01-16 09:35:56 --> Language Class Initialized
INFO - 2024-01-16 09:35:56 --> Language Class Initialized
INFO - 2024-01-16 09:35:56 --> Config Class Initialized
INFO - 2024-01-16 09:35:56 --> Loader Class Initialized
INFO - 2024-01-16 09:35:56 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:56 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:56 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:56 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:56 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:56 --> Controller Class Initialized
DEBUG - 2024-01-16 09:35:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 09:35:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:35:56 --> Final output sent to browser
DEBUG - 2024-01-16 09:35:56 --> Total execution time: 0.0523
INFO - 2024-01-16 09:35:56 --> Config Class Initialized
INFO - 2024-01-16 09:35:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:35:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:35:56 --> Utf8 Class Initialized
INFO - 2024-01-16 09:35:56 --> URI Class Initialized
INFO - 2024-01-16 09:35:56 --> Router Class Initialized
INFO - 2024-01-16 09:35:56 --> Output Class Initialized
INFO - 2024-01-16 09:35:56 --> Security Class Initialized
DEBUG - 2024-01-16 09:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:35:56 --> Input Class Initialized
INFO - 2024-01-16 09:35:56 --> Language Class Initialized
INFO - 2024-01-16 09:35:56 --> Language Class Initialized
INFO - 2024-01-16 09:35:56 --> Config Class Initialized
INFO - 2024-01-16 09:35:56 --> Loader Class Initialized
INFO - 2024-01-16 09:35:56 --> Helper loaded: url_helper
INFO - 2024-01-16 09:35:56 --> Helper loaded: file_helper
INFO - 2024-01-16 09:35:56 --> Helper loaded: form_helper
INFO - 2024-01-16 09:35:56 --> Helper loaded: my_helper
INFO - 2024-01-16 09:35:56 --> Database Driver Class Initialized
INFO - 2024-01-16 09:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:35:56 --> Controller Class Initialized
INFO - 2024-01-16 09:36:00 --> Config Class Initialized
INFO - 2024-01-16 09:36:00 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:36:00 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:36:00 --> Utf8 Class Initialized
INFO - 2024-01-16 09:36:00 --> URI Class Initialized
INFO - 2024-01-16 09:36:00 --> Router Class Initialized
INFO - 2024-01-16 09:36:00 --> Output Class Initialized
INFO - 2024-01-16 09:36:00 --> Security Class Initialized
DEBUG - 2024-01-16 09:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:36:00 --> Input Class Initialized
INFO - 2024-01-16 09:36:00 --> Language Class Initialized
INFO - 2024-01-16 09:36:00 --> Language Class Initialized
INFO - 2024-01-16 09:36:00 --> Config Class Initialized
INFO - 2024-01-16 09:36:00 --> Loader Class Initialized
INFO - 2024-01-16 09:36:00 --> Helper loaded: url_helper
INFO - 2024-01-16 09:36:00 --> Helper loaded: file_helper
INFO - 2024-01-16 09:36:00 --> Helper loaded: form_helper
INFO - 2024-01-16 09:36:00 --> Helper loaded: my_helper
INFO - 2024-01-16 09:36:00 --> Database Driver Class Initialized
INFO - 2024-01-16 09:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:36:00 --> Controller Class Initialized
INFO - 2024-01-16 09:36:00 --> Final output sent to browser
DEBUG - 2024-01-16 09:36:00 --> Total execution time: 0.0470
INFO - 2024-01-16 09:36:06 --> Config Class Initialized
INFO - 2024-01-16 09:36:06 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:36:06 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:36:06 --> Utf8 Class Initialized
INFO - 2024-01-16 09:36:06 --> URI Class Initialized
INFO - 2024-01-16 09:36:06 --> Router Class Initialized
INFO - 2024-01-16 09:36:06 --> Output Class Initialized
INFO - 2024-01-16 09:36:06 --> Security Class Initialized
DEBUG - 2024-01-16 09:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:36:06 --> Input Class Initialized
INFO - 2024-01-16 09:36:06 --> Language Class Initialized
INFO - 2024-01-16 09:36:06 --> Language Class Initialized
INFO - 2024-01-16 09:36:06 --> Config Class Initialized
INFO - 2024-01-16 09:36:06 --> Loader Class Initialized
INFO - 2024-01-16 09:36:06 --> Helper loaded: url_helper
INFO - 2024-01-16 09:36:06 --> Helper loaded: file_helper
INFO - 2024-01-16 09:36:06 --> Helper loaded: form_helper
INFO - 2024-01-16 09:36:06 --> Helper loaded: my_helper
INFO - 2024-01-16 09:36:06 --> Database Driver Class Initialized
INFO - 2024-01-16 09:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:36:06 --> Controller Class Initialized
DEBUG - 2024-01-16 09:36:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:36:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:36:06 --> Final output sent to browser
DEBUG - 2024-01-16 09:36:06 --> Total execution time: 0.0319
INFO - 2024-01-16 09:36:07 --> Config Class Initialized
INFO - 2024-01-16 09:36:07 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:36:07 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:36:07 --> Utf8 Class Initialized
INFO - 2024-01-16 09:36:07 --> URI Class Initialized
INFO - 2024-01-16 09:36:07 --> Router Class Initialized
INFO - 2024-01-16 09:36:07 --> Output Class Initialized
INFO - 2024-01-16 09:36:07 --> Security Class Initialized
DEBUG - 2024-01-16 09:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:36:07 --> Input Class Initialized
INFO - 2024-01-16 09:36:07 --> Language Class Initialized
INFO - 2024-01-16 09:36:07 --> Language Class Initialized
INFO - 2024-01-16 09:36:07 --> Config Class Initialized
INFO - 2024-01-16 09:36:07 --> Loader Class Initialized
INFO - 2024-01-16 09:36:07 --> Helper loaded: url_helper
INFO - 2024-01-16 09:36:07 --> Helper loaded: file_helper
INFO - 2024-01-16 09:36:07 --> Helper loaded: form_helper
INFO - 2024-01-16 09:36:07 --> Helper loaded: my_helper
INFO - 2024-01-16 09:36:07 --> Database Driver Class Initialized
INFO - 2024-01-16 09:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:36:07 --> Controller Class Initialized
DEBUG - 2024-01-16 09:36:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 09:36:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:36:07 --> Final output sent to browser
DEBUG - 2024-01-16 09:36:07 --> Total execution time: 0.0735
INFO - 2024-01-16 09:36:09 --> Config Class Initialized
INFO - 2024-01-16 09:36:09 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:36:09 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:36:09 --> Utf8 Class Initialized
INFO - 2024-01-16 09:36:09 --> URI Class Initialized
DEBUG - 2024-01-16 09:36:09 --> No URI present. Default controller set.
INFO - 2024-01-16 09:36:09 --> Router Class Initialized
INFO - 2024-01-16 09:36:09 --> Output Class Initialized
INFO - 2024-01-16 09:36:09 --> Security Class Initialized
DEBUG - 2024-01-16 09:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:36:09 --> Input Class Initialized
INFO - 2024-01-16 09:36:09 --> Language Class Initialized
INFO - 2024-01-16 09:36:09 --> Language Class Initialized
INFO - 2024-01-16 09:36:09 --> Config Class Initialized
INFO - 2024-01-16 09:36:09 --> Loader Class Initialized
INFO - 2024-01-16 09:36:09 --> Helper loaded: url_helper
INFO - 2024-01-16 09:36:09 --> Helper loaded: file_helper
INFO - 2024-01-16 09:36:09 --> Helper loaded: form_helper
INFO - 2024-01-16 09:36:09 --> Helper loaded: my_helper
INFO - 2024-01-16 09:36:09 --> Database Driver Class Initialized
INFO - 2024-01-16 09:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:36:09 --> Controller Class Initialized
DEBUG - 2024-01-16 09:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 09:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:36:09 --> Final output sent to browser
DEBUG - 2024-01-16 09:36:09 --> Total execution time: 0.0753
INFO - 2024-01-16 09:38:20 --> Config Class Initialized
INFO - 2024-01-16 09:38:20 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:38:20 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:38:20 --> Utf8 Class Initialized
INFO - 2024-01-16 09:38:20 --> URI Class Initialized
INFO - 2024-01-16 09:38:20 --> Router Class Initialized
INFO - 2024-01-16 09:38:20 --> Output Class Initialized
INFO - 2024-01-16 09:38:20 --> Security Class Initialized
DEBUG - 2024-01-16 09:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:38:20 --> Input Class Initialized
INFO - 2024-01-16 09:38:20 --> Language Class Initialized
INFO - 2024-01-16 09:38:20 --> Language Class Initialized
INFO - 2024-01-16 09:38:20 --> Config Class Initialized
INFO - 2024-01-16 09:38:20 --> Loader Class Initialized
INFO - 2024-01-16 09:38:20 --> Helper loaded: url_helper
INFO - 2024-01-16 09:38:20 --> Helper loaded: file_helper
INFO - 2024-01-16 09:38:20 --> Helper loaded: form_helper
INFO - 2024-01-16 09:38:20 --> Helper loaded: my_helper
INFO - 2024-01-16 09:38:20 --> Database Driver Class Initialized
INFO - 2024-01-16 09:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:38:20 --> Controller Class Initialized
DEBUG - 2024-01-16 09:38:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:38:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:38:20 --> Final output sent to browser
DEBUG - 2024-01-16 09:38:20 --> Total execution time: 0.0896
INFO - 2024-01-16 09:38:22 --> Config Class Initialized
INFO - 2024-01-16 09:38:22 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:38:22 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:38:22 --> Utf8 Class Initialized
INFO - 2024-01-16 09:38:22 --> URI Class Initialized
INFO - 2024-01-16 09:38:22 --> Router Class Initialized
INFO - 2024-01-16 09:38:22 --> Output Class Initialized
INFO - 2024-01-16 09:38:22 --> Security Class Initialized
DEBUG - 2024-01-16 09:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:38:22 --> Input Class Initialized
INFO - 2024-01-16 09:38:22 --> Language Class Initialized
INFO - 2024-01-16 09:38:22 --> Language Class Initialized
INFO - 2024-01-16 09:38:22 --> Config Class Initialized
INFO - 2024-01-16 09:38:22 --> Loader Class Initialized
INFO - 2024-01-16 09:38:22 --> Helper loaded: url_helper
INFO - 2024-01-16 09:38:22 --> Helper loaded: file_helper
INFO - 2024-01-16 09:38:22 --> Helper loaded: form_helper
INFO - 2024-01-16 09:38:22 --> Helper loaded: my_helper
INFO - 2024-01-16 09:38:22 --> Database Driver Class Initialized
INFO - 2024-01-16 09:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:38:22 --> Controller Class Initialized
DEBUG - 2024-01-16 09:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-01-16 09:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:38:22 --> Final output sent to browser
DEBUG - 2024-01-16 09:38:22 --> Total execution time: 0.0368
INFO - 2024-01-16 09:38:27 --> Config Class Initialized
INFO - 2024-01-16 09:38:27 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:38:27 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:38:27 --> Utf8 Class Initialized
INFO - 2024-01-16 09:38:27 --> URI Class Initialized
INFO - 2024-01-16 09:38:27 --> Router Class Initialized
INFO - 2024-01-16 09:38:27 --> Output Class Initialized
INFO - 2024-01-16 09:38:27 --> Security Class Initialized
DEBUG - 2024-01-16 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:38:27 --> Input Class Initialized
INFO - 2024-01-16 09:38:27 --> Language Class Initialized
INFO - 2024-01-16 09:38:27 --> Language Class Initialized
INFO - 2024-01-16 09:38:27 --> Config Class Initialized
INFO - 2024-01-16 09:38:27 --> Loader Class Initialized
INFO - 2024-01-16 09:38:27 --> Helper loaded: url_helper
INFO - 2024-01-16 09:38:27 --> Helper loaded: file_helper
INFO - 2024-01-16 09:38:27 --> Helper loaded: form_helper
INFO - 2024-01-16 09:38:27 --> Helper loaded: my_helper
INFO - 2024-01-16 09:38:27 --> Database Driver Class Initialized
INFO - 2024-01-16 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:38:27 --> Controller Class Initialized
DEBUG - 2024-01-16 09:38:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:38:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:38:27 --> Final output sent to browser
DEBUG - 2024-01-16 09:38:27 --> Total execution time: 0.1430
INFO - 2024-01-16 09:42:38 --> Config Class Initialized
INFO - 2024-01-16 09:42:38 --> Hooks Class Initialized
DEBUG - 2024-01-16 09:42:38 --> UTF-8 Support Enabled
INFO - 2024-01-16 09:42:38 --> Utf8 Class Initialized
INFO - 2024-01-16 09:42:38 --> URI Class Initialized
INFO - 2024-01-16 09:42:38 --> Router Class Initialized
INFO - 2024-01-16 09:42:38 --> Output Class Initialized
INFO - 2024-01-16 09:42:38 --> Security Class Initialized
DEBUG - 2024-01-16 09:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 09:42:38 --> Input Class Initialized
INFO - 2024-01-16 09:42:38 --> Language Class Initialized
INFO - 2024-01-16 09:42:38 --> Language Class Initialized
INFO - 2024-01-16 09:42:38 --> Config Class Initialized
INFO - 2024-01-16 09:42:38 --> Loader Class Initialized
INFO - 2024-01-16 09:42:38 --> Helper loaded: url_helper
INFO - 2024-01-16 09:42:38 --> Helper loaded: file_helper
INFO - 2024-01-16 09:42:38 --> Helper loaded: form_helper
INFO - 2024-01-16 09:42:38 --> Helper loaded: my_helper
INFO - 2024-01-16 09:42:38 --> Database Driver Class Initialized
INFO - 2024-01-16 09:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 09:42:38 --> Controller Class Initialized
DEBUG - 2024-01-16 09:42:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 09:42:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 09:42:38 --> Final output sent to browser
DEBUG - 2024-01-16 09:42:38 --> Total execution time: 0.0744
INFO - 2024-01-16 10:57:15 --> Config Class Initialized
INFO - 2024-01-16 10:57:15 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:15 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:15 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:15 --> URI Class Initialized
INFO - 2024-01-16 10:57:15 --> Router Class Initialized
INFO - 2024-01-16 10:57:15 --> Output Class Initialized
INFO - 2024-01-16 10:57:15 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:15 --> Input Class Initialized
INFO - 2024-01-16 10:57:15 --> Language Class Initialized
INFO - 2024-01-16 10:57:15 --> Language Class Initialized
INFO - 2024-01-16 10:57:15 --> Config Class Initialized
INFO - 2024-01-16 10:57:15 --> Loader Class Initialized
INFO - 2024-01-16 10:57:15 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:15 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:15 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:15 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:15 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:15 --> Controller Class Initialized
INFO - 2024-01-16 10:57:15 --> Config Class Initialized
INFO - 2024-01-16 10:57:15 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:15 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:15 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:15 --> URI Class Initialized
INFO - 2024-01-16 10:57:15 --> Router Class Initialized
INFO - 2024-01-16 10:57:15 --> Output Class Initialized
INFO - 2024-01-16 10:57:15 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:15 --> Input Class Initialized
INFO - 2024-01-16 10:57:15 --> Language Class Initialized
INFO - 2024-01-16 10:57:15 --> Language Class Initialized
INFO - 2024-01-16 10:57:15 --> Config Class Initialized
INFO - 2024-01-16 10:57:15 --> Loader Class Initialized
INFO - 2024-01-16 10:57:15 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:15 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:15 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:15 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:15 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:15 --> Controller Class Initialized
DEBUG - 2024-01-16 10:57:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 10:57:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 10:57:15 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:15 --> Total execution time: 0.0420
INFO - 2024-01-16 10:57:18 --> Config Class Initialized
INFO - 2024-01-16 10:57:18 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:18 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:18 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:18 --> URI Class Initialized
INFO - 2024-01-16 10:57:18 --> Router Class Initialized
INFO - 2024-01-16 10:57:18 --> Output Class Initialized
INFO - 2024-01-16 10:57:18 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:18 --> Input Class Initialized
INFO - 2024-01-16 10:57:18 --> Language Class Initialized
INFO - 2024-01-16 10:57:18 --> Language Class Initialized
INFO - 2024-01-16 10:57:18 --> Config Class Initialized
INFO - 2024-01-16 10:57:18 --> Loader Class Initialized
INFO - 2024-01-16 10:57:18 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:18 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:18 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:18 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:18 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:18 --> Controller Class Initialized
INFO - 2024-01-16 10:57:18 --> Helper loaded: cookie_helper
INFO - 2024-01-16 10:57:18 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:18 --> Total execution time: 0.0764
INFO - 2024-01-16 10:57:18 --> Config Class Initialized
INFO - 2024-01-16 10:57:18 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:18 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:18 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:18 --> URI Class Initialized
INFO - 2024-01-16 10:57:18 --> Router Class Initialized
INFO - 2024-01-16 10:57:18 --> Output Class Initialized
INFO - 2024-01-16 10:57:18 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:18 --> Input Class Initialized
INFO - 2024-01-16 10:57:18 --> Language Class Initialized
INFO - 2024-01-16 10:57:18 --> Language Class Initialized
INFO - 2024-01-16 10:57:18 --> Config Class Initialized
INFO - 2024-01-16 10:57:18 --> Loader Class Initialized
INFO - 2024-01-16 10:57:18 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:18 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:18 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:18 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:18 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:18 --> Controller Class Initialized
DEBUG - 2024-01-16 10:57:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 10:57:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 10:57:18 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:18 --> Total execution time: 0.0989
INFO - 2024-01-16 10:57:20 --> Config Class Initialized
INFO - 2024-01-16 10:57:20 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:20 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:20 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:20 --> URI Class Initialized
INFO - 2024-01-16 10:57:20 --> Router Class Initialized
INFO - 2024-01-16 10:57:20 --> Output Class Initialized
INFO - 2024-01-16 10:57:20 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:20 --> Input Class Initialized
INFO - 2024-01-16 10:57:20 --> Language Class Initialized
INFO - 2024-01-16 10:57:20 --> Language Class Initialized
INFO - 2024-01-16 10:57:20 --> Config Class Initialized
INFO - 2024-01-16 10:57:20 --> Loader Class Initialized
INFO - 2024-01-16 10:57:20 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:20 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:20 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:20 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:20 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:20 --> Controller Class Initialized
DEBUG - 2024-01-16 10:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 10:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 10:57:20 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:20 --> Total execution time: 0.0464
INFO - 2024-01-16 10:57:23 --> Config Class Initialized
INFO - 2024-01-16 10:57:23 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:23 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:23 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:23 --> URI Class Initialized
INFO - 2024-01-16 10:57:23 --> Router Class Initialized
INFO - 2024-01-16 10:57:23 --> Output Class Initialized
INFO - 2024-01-16 10:57:23 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:23 --> Input Class Initialized
INFO - 2024-01-16 10:57:23 --> Language Class Initialized
INFO - 2024-01-16 10:57:23 --> Language Class Initialized
INFO - 2024-01-16 10:57:23 --> Config Class Initialized
INFO - 2024-01-16 10:57:23 --> Loader Class Initialized
INFO - 2024-01-16 10:57:23 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:23 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:23 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:23 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:23 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:23 --> Controller Class Initialized
DEBUG - 2024-01-16 10:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 10:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 10:57:23 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:23 --> Total execution time: 0.0331
INFO - 2024-01-16 10:57:28 --> Config Class Initialized
INFO - 2024-01-16 10:57:28 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:28 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:28 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:28 --> URI Class Initialized
INFO - 2024-01-16 10:57:28 --> Router Class Initialized
INFO - 2024-01-16 10:57:28 --> Output Class Initialized
INFO - 2024-01-16 10:57:28 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:28 --> Input Class Initialized
INFO - 2024-01-16 10:57:28 --> Language Class Initialized
INFO - 2024-01-16 10:57:28 --> Language Class Initialized
INFO - 2024-01-16 10:57:28 --> Config Class Initialized
INFO - 2024-01-16 10:57:28 --> Loader Class Initialized
INFO - 2024-01-16 10:57:28 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:28 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:28 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:28 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:28 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:28 --> Controller Class Initialized
DEBUG - 2024-01-16 10:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 10:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 10:57:28 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:28 --> Total execution time: 0.1593
INFO - 2024-01-16 10:57:28 --> Config Class Initialized
INFO - 2024-01-16 10:57:28 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:28 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:28 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:28 --> URI Class Initialized
INFO - 2024-01-16 10:57:28 --> Router Class Initialized
INFO - 2024-01-16 10:57:28 --> Output Class Initialized
INFO - 2024-01-16 10:57:28 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:28 --> Input Class Initialized
INFO - 2024-01-16 10:57:28 --> Language Class Initialized
INFO - 2024-01-16 10:57:28 --> Language Class Initialized
INFO - 2024-01-16 10:57:28 --> Config Class Initialized
INFO - 2024-01-16 10:57:28 --> Loader Class Initialized
INFO - 2024-01-16 10:57:28 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:28 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:28 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:28 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:28 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:28 --> Controller Class Initialized
INFO - 2024-01-16 10:57:32 --> Config Class Initialized
INFO - 2024-01-16 10:57:32 --> Hooks Class Initialized
DEBUG - 2024-01-16 10:57:32 --> UTF-8 Support Enabled
INFO - 2024-01-16 10:57:32 --> Utf8 Class Initialized
INFO - 2024-01-16 10:57:32 --> URI Class Initialized
INFO - 2024-01-16 10:57:32 --> Router Class Initialized
INFO - 2024-01-16 10:57:32 --> Output Class Initialized
INFO - 2024-01-16 10:57:32 --> Security Class Initialized
DEBUG - 2024-01-16 10:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 10:57:32 --> Input Class Initialized
INFO - 2024-01-16 10:57:32 --> Language Class Initialized
INFO - 2024-01-16 10:57:32 --> Language Class Initialized
INFO - 2024-01-16 10:57:32 --> Config Class Initialized
INFO - 2024-01-16 10:57:32 --> Loader Class Initialized
INFO - 2024-01-16 10:57:32 --> Helper loaded: url_helper
INFO - 2024-01-16 10:57:32 --> Helper loaded: file_helper
INFO - 2024-01-16 10:57:32 --> Helper loaded: form_helper
INFO - 2024-01-16 10:57:32 --> Helper loaded: my_helper
INFO - 2024-01-16 10:57:32 --> Database Driver Class Initialized
INFO - 2024-01-16 10:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 10:57:32 --> Controller Class Initialized
INFO - 2024-01-16 10:57:32 --> Final output sent to browser
DEBUG - 2024-01-16 10:57:32 --> Total execution time: 0.0916
INFO - 2024-01-16 11:10:39 --> Config Class Initialized
INFO - 2024-01-16 11:10:39 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:10:39 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:10:39 --> Utf8 Class Initialized
INFO - 2024-01-16 11:10:39 --> URI Class Initialized
INFO - 2024-01-16 11:10:39 --> Router Class Initialized
INFO - 2024-01-16 11:10:39 --> Output Class Initialized
INFO - 2024-01-16 11:10:39 --> Security Class Initialized
DEBUG - 2024-01-16 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:10:39 --> Input Class Initialized
INFO - 2024-01-16 11:10:39 --> Language Class Initialized
INFO - 2024-01-16 11:10:39 --> Language Class Initialized
INFO - 2024-01-16 11:10:39 --> Config Class Initialized
INFO - 2024-01-16 11:10:39 --> Loader Class Initialized
INFO - 2024-01-16 11:10:39 --> Helper loaded: url_helper
INFO - 2024-01-16 11:10:39 --> Helper loaded: file_helper
INFO - 2024-01-16 11:10:39 --> Helper loaded: form_helper
INFO - 2024-01-16 11:10:39 --> Helper loaded: my_helper
INFO - 2024-01-16 11:10:39 --> Database Driver Class Initialized
INFO - 2024-01-16 11:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:10:39 --> Controller Class Initialized
DEBUG - 2024-01-16 11:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 11:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:10:39 --> Final output sent to browser
DEBUG - 2024-01-16 11:10:39 --> Total execution time: 0.0733
INFO - 2024-01-16 11:10:47 --> Config Class Initialized
INFO - 2024-01-16 11:10:47 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:10:47 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:10:47 --> Utf8 Class Initialized
INFO - 2024-01-16 11:10:47 --> URI Class Initialized
INFO - 2024-01-16 11:10:47 --> Router Class Initialized
INFO - 2024-01-16 11:10:47 --> Output Class Initialized
INFO - 2024-01-16 11:10:47 --> Security Class Initialized
DEBUG - 2024-01-16 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:10:47 --> Input Class Initialized
INFO - 2024-01-16 11:10:47 --> Language Class Initialized
INFO - 2024-01-16 11:10:47 --> Language Class Initialized
INFO - 2024-01-16 11:10:47 --> Config Class Initialized
INFO - 2024-01-16 11:10:47 --> Loader Class Initialized
INFO - 2024-01-16 11:10:47 --> Helper loaded: url_helper
INFO - 2024-01-16 11:10:47 --> Helper loaded: file_helper
INFO - 2024-01-16 11:10:47 --> Helper loaded: form_helper
INFO - 2024-01-16 11:10:47 --> Helper loaded: my_helper
INFO - 2024-01-16 11:10:47 --> Database Driver Class Initialized
INFO - 2024-01-16 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:10:47 --> Controller Class Initialized
INFO - 2024-01-16 11:10:47 --> Final output sent to browser
DEBUG - 2024-01-16 11:10:47 --> Total execution time: 0.0334
INFO - 2024-01-16 11:10:58 --> Config Class Initialized
INFO - 2024-01-16 11:10:58 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:10:58 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:10:58 --> Utf8 Class Initialized
INFO - 2024-01-16 11:10:58 --> URI Class Initialized
INFO - 2024-01-16 11:10:58 --> Router Class Initialized
INFO - 2024-01-16 11:10:58 --> Output Class Initialized
INFO - 2024-01-16 11:10:58 --> Security Class Initialized
DEBUG - 2024-01-16 11:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:10:58 --> Input Class Initialized
INFO - 2024-01-16 11:10:58 --> Language Class Initialized
INFO - 2024-01-16 11:10:58 --> Language Class Initialized
INFO - 2024-01-16 11:10:58 --> Config Class Initialized
INFO - 2024-01-16 11:10:58 --> Loader Class Initialized
INFO - 2024-01-16 11:10:58 --> Helper loaded: url_helper
INFO - 2024-01-16 11:10:58 --> Helper loaded: file_helper
INFO - 2024-01-16 11:10:58 --> Helper loaded: form_helper
INFO - 2024-01-16 11:10:58 --> Helper loaded: my_helper
INFO - 2024-01-16 11:10:58 --> Database Driver Class Initialized
INFO - 2024-01-16 11:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:10:58 --> Controller Class Initialized
INFO - 2024-01-16 11:10:58 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:10:58 --> Final output sent to browser
DEBUG - 2024-01-16 11:10:58 --> Total execution time: 0.0333
INFO - 2024-01-16 11:10:59 --> Config Class Initialized
INFO - 2024-01-16 11:10:59 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:10:59 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:10:59 --> Utf8 Class Initialized
INFO - 2024-01-16 11:10:59 --> URI Class Initialized
INFO - 2024-01-16 11:10:59 --> Router Class Initialized
INFO - 2024-01-16 11:10:59 --> Output Class Initialized
INFO - 2024-01-16 11:10:59 --> Security Class Initialized
DEBUG - 2024-01-16 11:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:10:59 --> Input Class Initialized
INFO - 2024-01-16 11:10:59 --> Language Class Initialized
INFO - 2024-01-16 11:10:59 --> Language Class Initialized
INFO - 2024-01-16 11:10:59 --> Config Class Initialized
INFO - 2024-01-16 11:10:59 --> Loader Class Initialized
INFO - 2024-01-16 11:10:59 --> Helper loaded: url_helper
INFO - 2024-01-16 11:10:59 --> Helper loaded: file_helper
INFO - 2024-01-16 11:10:59 --> Helper loaded: form_helper
INFO - 2024-01-16 11:10:59 --> Helper loaded: my_helper
INFO - 2024-01-16 11:10:59 --> Database Driver Class Initialized
INFO - 2024-01-16 11:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:10:59 --> Controller Class Initialized
DEBUG - 2024-01-16 11:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 11:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:10:59 --> Final output sent to browser
DEBUG - 2024-01-16 11:10:59 --> Total execution time: 0.0366
INFO - 2024-01-16 11:11:04 --> Config Class Initialized
INFO - 2024-01-16 11:11:04 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:11:04 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:11:04 --> Utf8 Class Initialized
INFO - 2024-01-16 11:11:04 --> URI Class Initialized
INFO - 2024-01-16 11:11:04 --> Router Class Initialized
INFO - 2024-01-16 11:11:04 --> Output Class Initialized
INFO - 2024-01-16 11:11:04 --> Security Class Initialized
DEBUG - 2024-01-16 11:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:11:04 --> Input Class Initialized
INFO - 2024-01-16 11:11:04 --> Language Class Initialized
INFO - 2024-01-16 11:11:04 --> Language Class Initialized
INFO - 2024-01-16 11:11:04 --> Config Class Initialized
INFO - 2024-01-16 11:11:04 --> Loader Class Initialized
INFO - 2024-01-16 11:11:04 --> Helper loaded: url_helper
INFO - 2024-01-16 11:11:04 --> Helper loaded: file_helper
INFO - 2024-01-16 11:11:04 --> Helper loaded: form_helper
INFO - 2024-01-16 11:11:04 --> Helper loaded: my_helper
INFO - 2024-01-16 11:11:04 --> Database Driver Class Initialized
INFO - 2024-01-16 11:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:11:04 --> Controller Class Initialized
DEBUG - 2024-01-16 11:11:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 11:11:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:11:04 --> Final output sent to browser
DEBUG - 2024-01-16 11:11:04 --> Total execution time: 0.0366
INFO - 2024-01-16 11:11:06 --> Config Class Initialized
INFO - 2024-01-16 11:11:06 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:11:06 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:11:06 --> Utf8 Class Initialized
INFO - 2024-01-16 11:11:06 --> URI Class Initialized
INFO - 2024-01-16 11:11:06 --> Router Class Initialized
INFO - 2024-01-16 11:11:06 --> Output Class Initialized
INFO - 2024-01-16 11:11:06 --> Security Class Initialized
DEBUG - 2024-01-16 11:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:11:06 --> Input Class Initialized
INFO - 2024-01-16 11:11:06 --> Language Class Initialized
INFO - 2024-01-16 11:11:06 --> Language Class Initialized
INFO - 2024-01-16 11:11:06 --> Config Class Initialized
INFO - 2024-01-16 11:11:06 --> Loader Class Initialized
INFO - 2024-01-16 11:11:06 --> Helper loaded: url_helper
INFO - 2024-01-16 11:11:06 --> Helper loaded: file_helper
INFO - 2024-01-16 11:11:06 --> Helper loaded: form_helper
INFO - 2024-01-16 11:11:06 --> Helper loaded: my_helper
INFO - 2024-01-16 11:11:06 --> Database Driver Class Initialized
INFO - 2024-01-16 11:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:11:06 --> Controller Class Initialized
DEBUG - 2024-01-16 11:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 11:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:11:06 --> Final output sent to browser
DEBUG - 2024-01-16 11:11:06 --> Total execution time: 0.0527
INFO - 2024-01-16 11:11:06 --> Config Class Initialized
INFO - 2024-01-16 11:11:06 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:11:06 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:11:06 --> Utf8 Class Initialized
INFO - 2024-01-16 11:11:06 --> URI Class Initialized
INFO - 2024-01-16 11:11:06 --> Router Class Initialized
INFO - 2024-01-16 11:11:06 --> Output Class Initialized
INFO - 2024-01-16 11:11:06 --> Security Class Initialized
DEBUG - 2024-01-16 11:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:11:06 --> Input Class Initialized
INFO - 2024-01-16 11:11:06 --> Language Class Initialized
INFO - 2024-01-16 11:11:06 --> Language Class Initialized
INFO - 2024-01-16 11:11:06 --> Config Class Initialized
INFO - 2024-01-16 11:11:06 --> Loader Class Initialized
INFO - 2024-01-16 11:11:06 --> Helper loaded: url_helper
INFO - 2024-01-16 11:11:06 --> Helper loaded: file_helper
INFO - 2024-01-16 11:11:06 --> Helper loaded: form_helper
INFO - 2024-01-16 11:11:06 --> Helper loaded: my_helper
INFO - 2024-01-16 11:11:06 --> Database Driver Class Initialized
INFO - 2024-01-16 11:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:11:06 --> Controller Class Initialized
INFO - 2024-01-16 11:11:08 --> Config Class Initialized
INFO - 2024-01-16 11:11:08 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:11:08 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:11:08 --> Utf8 Class Initialized
INFO - 2024-01-16 11:11:08 --> URI Class Initialized
INFO - 2024-01-16 11:11:08 --> Router Class Initialized
INFO - 2024-01-16 11:11:08 --> Output Class Initialized
INFO - 2024-01-16 11:11:08 --> Security Class Initialized
DEBUG - 2024-01-16 11:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:11:08 --> Input Class Initialized
INFO - 2024-01-16 11:11:08 --> Language Class Initialized
INFO - 2024-01-16 11:11:08 --> Language Class Initialized
INFO - 2024-01-16 11:11:08 --> Config Class Initialized
INFO - 2024-01-16 11:11:08 --> Loader Class Initialized
INFO - 2024-01-16 11:11:08 --> Helper loaded: url_helper
INFO - 2024-01-16 11:11:08 --> Helper loaded: file_helper
INFO - 2024-01-16 11:11:08 --> Helper loaded: form_helper
INFO - 2024-01-16 11:11:08 --> Helper loaded: my_helper
INFO - 2024-01-16 11:11:08 --> Database Driver Class Initialized
INFO - 2024-01-16 11:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:11:08 --> Controller Class Initialized
INFO - 2024-01-16 11:12:56 --> Config Class Initialized
INFO - 2024-01-16 11:12:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:12:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:12:56 --> Utf8 Class Initialized
INFO - 2024-01-16 11:12:56 --> URI Class Initialized
INFO - 2024-01-16 11:12:56 --> Router Class Initialized
INFO - 2024-01-16 11:12:56 --> Output Class Initialized
INFO - 2024-01-16 11:12:56 --> Security Class Initialized
DEBUG - 2024-01-16 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:12:56 --> Input Class Initialized
INFO - 2024-01-16 11:12:56 --> Language Class Initialized
INFO - 2024-01-16 11:12:56 --> Language Class Initialized
INFO - 2024-01-16 11:12:56 --> Config Class Initialized
INFO - 2024-01-16 11:12:56 --> Loader Class Initialized
INFO - 2024-01-16 11:12:56 --> Helper loaded: url_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: file_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: form_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: my_helper
INFO - 2024-01-16 11:12:56 --> Database Driver Class Initialized
INFO - 2024-01-16 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:12:56 --> Controller Class Initialized
INFO - 2024-01-16 11:12:56 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:12:56 --> Config Class Initialized
INFO - 2024-01-16 11:12:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:12:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:12:56 --> Utf8 Class Initialized
INFO - 2024-01-16 11:12:56 --> URI Class Initialized
INFO - 2024-01-16 11:12:56 --> Router Class Initialized
INFO - 2024-01-16 11:12:56 --> Output Class Initialized
INFO - 2024-01-16 11:12:56 --> Security Class Initialized
DEBUG - 2024-01-16 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:12:56 --> Input Class Initialized
INFO - 2024-01-16 11:12:56 --> Language Class Initialized
INFO - 2024-01-16 11:12:56 --> Language Class Initialized
INFO - 2024-01-16 11:12:56 --> Config Class Initialized
INFO - 2024-01-16 11:12:56 --> Loader Class Initialized
INFO - 2024-01-16 11:12:56 --> Helper loaded: url_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: file_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: form_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: my_helper
INFO - 2024-01-16 11:12:56 --> Database Driver Class Initialized
INFO - 2024-01-16 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:12:56 --> Controller Class Initialized
INFO - 2024-01-16 11:12:56 --> Config Class Initialized
INFO - 2024-01-16 11:12:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:12:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:12:56 --> Utf8 Class Initialized
INFO - 2024-01-16 11:12:56 --> URI Class Initialized
INFO - 2024-01-16 11:12:56 --> Router Class Initialized
INFO - 2024-01-16 11:12:56 --> Output Class Initialized
INFO - 2024-01-16 11:12:56 --> Security Class Initialized
DEBUG - 2024-01-16 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:12:56 --> Input Class Initialized
INFO - 2024-01-16 11:12:56 --> Language Class Initialized
INFO - 2024-01-16 11:12:56 --> Language Class Initialized
INFO - 2024-01-16 11:12:56 --> Config Class Initialized
INFO - 2024-01-16 11:12:56 --> Loader Class Initialized
INFO - 2024-01-16 11:12:56 --> Helper loaded: url_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: file_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: form_helper
INFO - 2024-01-16 11:12:56 --> Helper loaded: my_helper
INFO - 2024-01-16 11:12:56 --> Database Driver Class Initialized
INFO - 2024-01-16 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:12:56 --> Controller Class Initialized
DEBUG - 2024-01-16 11:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 11:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:12:56 --> Final output sent to browser
DEBUG - 2024-01-16 11:12:56 --> Total execution time: 0.0358
INFO - 2024-01-16 11:13:08 --> Config Class Initialized
INFO - 2024-01-16 11:13:08 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:13:08 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:13:08 --> Utf8 Class Initialized
INFO - 2024-01-16 11:13:08 --> URI Class Initialized
INFO - 2024-01-16 11:13:08 --> Router Class Initialized
INFO - 2024-01-16 11:13:08 --> Output Class Initialized
INFO - 2024-01-16 11:13:08 --> Security Class Initialized
DEBUG - 2024-01-16 11:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:13:08 --> Input Class Initialized
INFO - 2024-01-16 11:13:08 --> Language Class Initialized
INFO - 2024-01-16 11:13:08 --> Language Class Initialized
INFO - 2024-01-16 11:13:08 --> Config Class Initialized
INFO - 2024-01-16 11:13:08 --> Loader Class Initialized
INFO - 2024-01-16 11:13:08 --> Helper loaded: url_helper
INFO - 2024-01-16 11:13:08 --> Helper loaded: file_helper
INFO - 2024-01-16 11:13:08 --> Helper loaded: form_helper
INFO - 2024-01-16 11:13:08 --> Helper loaded: my_helper
INFO - 2024-01-16 11:13:08 --> Database Driver Class Initialized
INFO - 2024-01-16 11:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:13:08 --> Controller Class Initialized
INFO - 2024-01-16 11:13:08 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:13:08 --> Final output sent to browser
DEBUG - 2024-01-16 11:13:08 --> Total execution time: 0.0390
INFO - 2024-01-16 11:13:08 --> Config Class Initialized
INFO - 2024-01-16 11:13:08 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:13:08 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:13:08 --> Utf8 Class Initialized
INFO - 2024-01-16 11:13:08 --> URI Class Initialized
INFO - 2024-01-16 11:13:08 --> Router Class Initialized
INFO - 2024-01-16 11:13:08 --> Output Class Initialized
INFO - 2024-01-16 11:13:08 --> Security Class Initialized
DEBUG - 2024-01-16 11:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:13:08 --> Input Class Initialized
INFO - 2024-01-16 11:13:08 --> Language Class Initialized
INFO - 2024-01-16 11:13:08 --> Language Class Initialized
INFO - 2024-01-16 11:13:08 --> Config Class Initialized
INFO - 2024-01-16 11:13:08 --> Loader Class Initialized
INFO - 2024-01-16 11:13:08 --> Helper loaded: url_helper
INFO - 2024-01-16 11:13:08 --> Helper loaded: file_helper
INFO - 2024-01-16 11:13:08 --> Helper loaded: form_helper
INFO - 2024-01-16 11:13:08 --> Helper loaded: my_helper
INFO - 2024-01-16 11:13:08 --> Database Driver Class Initialized
INFO - 2024-01-16 11:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:13:08 --> Controller Class Initialized
DEBUG - 2024-01-16 11:13:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 11:13:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:13:08 --> Final output sent to browser
DEBUG - 2024-01-16 11:13:08 --> Total execution time: 0.0413
INFO - 2024-01-16 11:13:10 --> Config Class Initialized
INFO - 2024-01-16 11:13:10 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:13:10 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:13:10 --> Utf8 Class Initialized
INFO - 2024-01-16 11:13:10 --> URI Class Initialized
INFO - 2024-01-16 11:13:10 --> Router Class Initialized
INFO - 2024-01-16 11:13:10 --> Output Class Initialized
INFO - 2024-01-16 11:13:10 --> Security Class Initialized
DEBUG - 2024-01-16 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:13:10 --> Input Class Initialized
INFO - 2024-01-16 11:13:10 --> Language Class Initialized
INFO - 2024-01-16 11:13:10 --> Language Class Initialized
INFO - 2024-01-16 11:13:10 --> Config Class Initialized
INFO - 2024-01-16 11:13:10 --> Loader Class Initialized
INFO - 2024-01-16 11:13:10 --> Helper loaded: url_helper
INFO - 2024-01-16 11:13:10 --> Helper loaded: file_helper
INFO - 2024-01-16 11:13:10 --> Helper loaded: form_helper
INFO - 2024-01-16 11:13:10 --> Helper loaded: my_helper
INFO - 2024-01-16 11:13:10 --> Database Driver Class Initialized
INFO - 2024-01-16 11:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:13:10 --> Controller Class Initialized
DEBUG - 2024-01-16 11:13:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 11:13:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:13:10 --> Final output sent to browser
DEBUG - 2024-01-16 11:13:10 --> Total execution time: 0.0297
INFO - 2024-01-16 11:15:01 --> Config Class Initialized
INFO - 2024-01-16 11:15:01 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:15:01 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:15:01 --> Utf8 Class Initialized
INFO - 2024-01-16 11:15:01 --> URI Class Initialized
INFO - 2024-01-16 11:15:01 --> Router Class Initialized
INFO - 2024-01-16 11:15:01 --> Output Class Initialized
INFO - 2024-01-16 11:15:01 --> Security Class Initialized
DEBUG - 2024-01-16 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:15:01 --> Input Class Initialized
INFO - 2024-01-16 11:15:01 --> Language Class Initialized
INFO - 2024-01-16 11:15:01 --> Language Class Initialized
INFO - 2024-01-16 11:15:01 --> Config Class Initialized
INFO - 2024-01-16 11:15:01 --> Loader Class Initialized
INFO - 2024-01-16 11:15:01 --> Helper loaded: url_helper
INFO - 2024-01-16 11:15:01 --> Helper loaded: file_helper
INFO - 2024-01-16 11:15:01 --> Helper loaded: form_helper
INFO - 2024-01-16 11:15:01 --> Helper loaded: my_helper
INFO - 2024-01-16 11:15:01 --> Database Driver Class Initialized
INFO - 2024-01-16 11:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:15:01 --> Controller Class Initialized
DEBUG - 2024-01-16 11:15:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 11:15:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:15:02 --> Final output sent to browser
DEBUG - 2024-01-16 11:15:02 --> Total execution time: 0.0788
INFO - 2024-01-16 11:15:02 --> Config Class Initialized
INFO - 2024-01-16 11:15:02 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:15:02 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:15:02 --> Utf8 Class Initialized
INFO - 2024-01-16 11:15:02 --> URI Class Initialized
INFO - 2024-01-16 11:15:02 --> Router Class Initialized
INFO - 2024-01-16 11:15:02 --> Output Class Initialized
INFO - 2024-01-16 11:15:02 --> Security Class Initialized
DEBUG - 2024-01-16 11:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:15:02 --> Input Class Initialized
INFO - 2024-01-16 11:15:02 --> Language Class Initialized
INFO - 2024-01-16 11:15:02 --> Language Class Initialized
INFO - 2024-01-16 11:15:02 --> Config Class Initialized
INFO - 2024-01-16 11:15:02 --> Loader Class Initialized
INFO - 2024-01-16 11:15:02 --> Helper loaded: url_helper
INFO - 2024-01-16 11:15:02 --> Helper loaded: file_helper
INFO - 2024-01-16 11:15:02 --> Helper loaded: form_helper
INFO - 2024-01-16 11:15:02 --> Helper loaded: my_helper
INFO - 2024-01-16 11:15:02 --> Database Driver Class Initialized
INFO - 2024-01-16 11:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:15:02 --> Controller Class Initialized
INFO - 2024-01-16 11:15:07 --> Config Class Initialized
INFO - 2024-01-16 11:15:07 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:15:07 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:15:07 --> Utf8 Class Initialized
INFO - 2024-01-16 11:15:07 --> URI Class Initialized
INFO - 2024-01-16 11:15:07 --> Router Class Initialized
INFO - 2024-01-16 11:15:07 --> Output Class Initialized
INFO - 2024-01-16 11:15:07 --> Security Class Initialized
DEBUG - 2024-01-16 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:15:07 --> Input Class Initialized
INFO - 2024-01-16 11:15:07 --> Language Class Initialized
INFO - 2024-01-16 11:15:07 --> Language Class Initialized
INFO - 2024-01-16 11:15:07 --> Config Class Initialized
INFO - 2024-01-16 11:15:07 --> Loader Class Initialized
INFO - 2024-01-16 11:15:07 --> Helper loaded: url_helper
INFO - 2024-01-16 11:15:07 --> Helper loaded: file_helper
INFO - 2024-01-16 11:15:07 --> Helper loaded: form_helper
INFO - 2024-01-16 11:15:07 --> Helper loaded: my_helper
INFO - 2024-01-16 11:15:07 --> Database Driver Class Initialized
INFO - 2024-01-16 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:15:07 --> Controller Class Initialized
INFO - 2024-01-16 11:17:59 --> Config Class Initialized
INFO - 2024-01-16 11:17:59 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:00 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:00 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:00 --> URI Class Initialized
INFO - 2024-01-16 11:18:00 --> Router Class Initialized
INFO - 2024-01-16 11:18:00 --> Output Class Initialized
INFO - 2024-01-16 11:18:00 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:00 --> Input Class Initialized
INFO - 2024-01-16 11:18:00 --> Language Class Initialized
INFO - 2024-01-16 11:18:00 --> Language Class Initialized
INFO - 2024-01-16 11:18:00 --> Config Class Initialized
INFO - 2024-01-16 11:18:00 --> Loader Class Initialized
INFO - 2024-01-16 11:18:00 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:00 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:00 --> Controller Class Initialized
INFO - 2024-01-16 11:18:00 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:18:00 --> Config Class Initialized
INFO - 2024-01-16 11:18:00 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:00 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:00 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:00 --> URI Class Initialized
INFO - 2024-01-16 11:18:00 --> Router Class Initialized
INFO - 2024-01-16 11:18:00 --> Output Class Initialized
INFO - 2024-01-16 11:18:00 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:00 --> Input Class Initialized
INFO - 2024-01-16 11:18:00 --> Language Class Initialized
INFO - 2024-01-16 11:18:00 --> Language Class Initialized
INFO - 2024-01-16 11:18:00 --> Config Class Initialized
INFO - 2024-01-16 11:18:00 --> Loader Class Initialized
INFO - 2024-01-16 11:18:00 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:00 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:00 --> Controller Class Initialized
INFO - 2024-01-16 11:18:00 --> Config Class Initialized
INFO - 2024-01-16 11:18:00 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:00 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:00 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:00 --> URI Class Initialized
INFO - 2024-01-16 11:18:00 --> Router Class Initialized
INFO - 2024-01-16 11:18:00 --> Output Class Initialized
INFO - 2024-01-16 11:18:00 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:00 --> Input Class Initialized
INFO - 2024-01-16 11:18:00 --> Language Class Initialized
INFO - 2024-01-16 11:18:00 --> Language Class Initialized
INFO - 2024-01-16 11:18:00 --> Config Class Initialized
INFO - 2024-01-16 11:18:00 --> Loader Class Initialized
INFO - 2024-01-16 11:18:00 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:00 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:00 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:00 --> Controller Class Initialized
DEBUG - 2024-01-16 11:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 11:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:18:00 --> Final output sent to browser
DEBUG - 2024-01-16 11:18:00 --> Total execution time: 0.0357
INFO - 2024-01-16 11:18:06 --> Config Class Initialized
INFO - 2024-01-16 11:18:06 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:06 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:06 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:06 --> URI Class Initialized
INFO - 2024-01-16 11:18:06 --> Router Class Initialized
INFO - 2024-01-16 11:18:06 --> Output Class Initialized
INFO - 2024-01-16 11:18:06 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:06 --> Input Class Initialized
INFO - 2024-01-16 11:18:06 --> Language Class Initialized
INFO - 2024-01-16 11:18:06 --> Language Class Initialized
INFO - 2024-01-16 11:18:06 --> Config Class Initialized
INFO - 2024-01-16 11:18:06 --> Loader Class Initialized
INFO - 2024-01-16 11:18:06 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:06 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:06 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:06 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:06 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:06 --> Controller Class Initialized
INFO - 2024-01-16 11:18:06 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:18:06 --> Final output sent to browser
DEBUG - 2024-01-16 11:18:06 --> Total execution time: 0.0437
INFO - 2024-01-16 11:18:06 --> Config Class Initialized
INFO - 2024-01-16 11:18:06 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:06 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:06 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:06 --> URI Class Initialized
INFO - 2024-01-16 11:18:06 --> Router Class Initialized
INFO - 2024-01-16 11:18:06 --> Output Class Initialized
INFO - 2024-01-16 11:18:06 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:06 --> Input Class Initialized
INFO - 2024-01-16 11:18:06 --> Language Class Initialized
INFO - 2024-01-16 11:18:06 --> Language Class Initialized
INFO - 2024-01-16 11:18:06 --> Config Class Initialized
INFO - 2024-01-16 11:18:06 --> Loader Class Initialized
INFO - 2024-01-16 11:18:06 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:06 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:06 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:06 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:06 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:06 --> Controller Class Initialized
DEBUG - 2024-01-16 11:18:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-01-16 11:18:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:18:06 --> Final output sent to browser
DEBUG - 2024-01-16 11:18:06 --> Total execution time: 0.0555
INFO - 2024-01-16 11:18:41 --> Config Class Initialized
INFO - 2024-01-16 11:18:41 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:41 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:41 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:41 --> URI Class Initialized
INFO - 2024-01-16 11:18:41 --> Router Class Initialized
INFO - 2024-01-16 11:18:41 --> Output Class Initialized
INFO - 2024-01-16 11:18:41 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:41 --> Input Class Initialized
INFO - 2024-01-16 11:18:41 --> Language Class Initialized
INFO - 2024-01-16 11:18:41 --> Language Class Initialized
INFO - 2024-01-16 11:18:41 --> Config Class Initialized
INFO - 2024-01-16 11:18:41 --> Loader Class Initialized
INFO - 2024-01-16 11:18:41 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:41 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:41 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:41 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:41 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:41 --> Controller Class Initialized
DEBUG - 2024-01-16 11:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-01-16 11:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:18:41 --> Final output sent to browser
DEBUG - 2024-01-16 11:18:41 --> Total execution time: 0.0452
INFO - 2024-01-16 11:18:41 --> Config Class Initialized
INFO - 2024-01-16 11:18:41 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:41 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:41 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:41 --> URI Class Initialized
INFO - 2024-01-16 11:18:41 --> Router Class Initialized
INFO - 2024-01-16 11:18:41 --> Output Class Initialized
INFO - 2024-01-16 11:18:41 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:41 --> Input Class Initialized
INFO - 2024-01-16 11:18:41 --> Language Class Initialized
ERROR - 2024-01-16 11:18:41 --> 404 Page Not Found: /index
INFO - 2024-01-16 11:18:41 --> Config Class Initialized
INFO - 2024-01-16 11:18:41 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:41 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:41 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:41 --> URI Class Initialized
INFO - 2024-01-16 11:18:41 --> Router Class Initialized
INFO - 2024-01-16 11:18:41 --> Output Class Initialized
INFO - 2024-01-16 11:18:41 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:41 --> Input Class Initialized
INFO - 2024-01-16 11:18:41 --> Language Class Initialized
INFO - 2024-01-16 11:18:41 --> Language Class Initialized
INFO - 2024-01-16 11:18:41 --> Config Class Initialized
INFO - 2024-01-16 11:18:41 --> Loader Class Initialized
INFO - 2024-01-16 11:18:41 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:41 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:41 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:41 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:41 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:41 --> Controller Class Initialized
INFO - 2024-01-16 11:18:51 --> Config Class Initialized
INFO - 2024-01-16 11:18:51 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:51 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:51 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:51 --> URI Class Initialized
INFO - 2024-01-16 11:18:51 --> Router Class Initialized
INFO - 2024-01-16 11:18:51 --> Output Class Initialized
INFO - 2024-01-16 11:18:51 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:51 --> Input Class Initialized
INFO - 2024-01-16 11:18:51 --> Language Class Initialized
INFO - 2024-01-16 11:18:51 --> Language Class Initialized
INFO - 2024-01-16 11:18:51 --> Config Class Initialized
INFO - 2024-01-16 11:18:51 --> Loader Class Initialized
INFO - 2024-01-16 11:18:51 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:51 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:51 --> Controller Class Initialized
INFO - 2024-01-16 11:18:51 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:18:51 --> Config Class Initialized
INFO - 2024-01-16 11:18:51 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:51 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:51 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:51 --> URI Class Initialized
INFO - 2024-01-16 11:18:51 --> Router Class Initialized
INFO - 2024-01-16 11:18:51 --> Output Class Initialized
INFO - 2024-01-16 11:18:51 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:51 --> Input Class Initialized
INFO - 2024-01-16 11:18:51 --> Language Class Initialized
INFO - 2024-01-16 11:18:51 --> Language Class Initialized
INFO - 2024-01-16 11:18:51 --> Config Class Initialized
INFO - 2024-01-16 11:18:51 --> Loader Class Initialized
INFO - 2024-01-16 11:18:51 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:51 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:51 --> Controller Class Initialized
INFO - 2024-01-16 11:18:51 --> Config Class Initialized
INFO - 2024-01-16 11:18:51 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:18:51 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:18:51 --> Utf8 Class Initialized
INFO - 2024-01-16 11:18:51 --> URI Class Initialized
INFO - 2024-01-16 11:18:51 --> Router Class Initialized
INFO - 2024-01-16 11:18:51 --> Output Class Initialized
INFO - 2024-01-16 11:18:51 --> Security Class Initialized
DEBUG - 2024-01-16 11:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:18:51 --> Input Class Initialized
INFO - 2024-01-16 11:18:51 --> Language Class Initialized
INFO - 2024-01-16 11:18:51 --> Language Class Initialized
INFO - 2024-01-16 11:18:51 --> Config Class Initialized
INFO - 2024-01-16 11:18:51 --> Loader Class Initialized
INFO - 2024-01-16 11:18:51 --> Helper loaded: url_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: file_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: form_helper
INFO - 2024-01-16 11:18:51 --> Helper loaded: my_helper
INFO - 2024-01-16 11:18:51 --> Database Driver Class Initialized
INFO - 2024-01-16 11:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:18:51 --> Controller Class Initialized
DEBUG - 2024-01-16 11:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 11:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:18:51 --> Final output sent to browser
DEBUG - 2024-01-16 11:18:51 --> Total execution time: 0.0297
INFO - 2024-01-16 11:19:02 --> Config Class Initialized
INFO - 2024-01-16 11:19:02 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:19:02 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:19:02 --> Utf8 Class Initialized
INFO - 2024-01-16 11:19:02 --> URI Class Initialized
INFO - 2024-01-16 11:19:02 --> Router Class Initialized
INFO - 2024-01-16 11:19:02 --> Output Class Initialized
INFO - 2024-01-16 11:19:02 --> Security Class Initialized
DEBUG - 2024-01-16 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:19:02 --> Input Class Initialized
INFO - 2024-01-16 11:19:02 --> Language Class Initialized
INFO - 2024-01-16 11:19:02 --> Language Class Initialized
INFO - 2024-01-16 11:19:02 --> Config Class Initialized
INFO - 2024-01-16 11:19:02 --> Loader Class Initialized
INFO - 2024-01-16 11:19:02 --> Helper loaded: url_helper
INFO - 2024-01-16 11:19:02 --> Helper loaded: file_helper
INFO - 2024-01-16 11:19:02 --> Helper loaded: form_helper
INFO - 2024-01-16 11:19:02 --> Helper loaded: my_helper
INFO - 2024-01-16 11:19:02 --> Database Driver Class Initialized
INFO - 2024-01-16 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:19:02 --> Controller Class Initialized
INFO - 2024-01-16 11:19:02 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:19:02 --> Final output sent to browser
DEBUG - 2024-01-16 11:19:02 --> Total execution time: 0.0574
INFO - 2024-01-16 11:19:02 --> Config Class Initialized
INFO - 2024-01-16 11:19:02 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:19:02 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:19:02 --> Utf8 Class Initialized
INFO - 2024-01-16 11:19:02 --> URI Class Initialized
INFO - 2024-01-16 11:19:02 --> Router Class Initialized
INFO - 2024-01-16 11:19:02 --> Output Class Initialized
INFO - 2024-01-16 11:19:02 --> Security Class Initialized
DEBUG - 2024-01-16 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:19:02 --> Input Class Initialized
INFO - 2024-01-16 11:19:02 --> Language Class Initialized
INFO - 2024-01-16 11:19:02 --> Language Class Initialized
INFO - 2024-01-16 11:19:02 --> Config Class Initialized
INFO - 2024-01-16 11:19:02 --> Loader Class Initialized
INFO - 2024-01-16 11:19:02 --> Helper loaded: url_helper
INFO - 2024-01-16 11:19:02 --> Helper loaded: file_helper
INFO - 2024-01-16 11:19:02 --> Helper loaded: form_helper
INFO - 2024-01-16 11:19:02 --> Helper loaded: my_helper
INFO - 2024-01-16 11:19:02 --> Database Driver Class Initialized
INFO - 2024-01-16 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:19:02 --> Controller Class Initialized
DEBUG - 2024-01-16 11:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 11:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:19:02 --> Final output sent to browser
DEBUG - 2024-01-16 11:19:02 --> Total execution time: 0.0433
INFO - 2024-01-16 11:19:06 --> Config Class Initialized
INFO - 2024-01-16 11:19:06 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:19:06 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:19:06 --> Utf8 Class Initialized
INFO - 2024-01-16 11:19:06 --> URI Class Initialized
INFO - 2024-01-16 11:19:06 --> Router Class Initialized
INFO - 2024-01-16 11:19:06 --> Output Class Initialized
INFO - 2024-01-16 11:19:06 --> Security Class Initialized
DEBUG - 2024-01-16 11:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:19:06 --> Input Class Initialized
INFO - 2024-01-16 11:19:06 --> Language Class Initialized
INFO - 2024-01-16 11:19:06 --> Language Class Initialized
INFO - 2024-01-16 11:19:06 --> Config Class Initialized
INFO - 2024-01-16 11:19:06 --> Loader Class Initialized
INFO - 2024-01-16 11:19:06 --> Helper loaded: url_helper
INFO - 2024-01-16 11:19:06 --> Helper loaded: file_helper
INFO - 2024-01-16 11:19:06 --> Helper loaded: form_helper
INFO - 2024-01-16 11:19:06 --> Helper loaded: my_helper
INFO - 2024-01-16 11:19:06 --> Database Driver Class Initialized
INFO - 2024-01-16 11:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:19:06 --> Controller Class Initialized
DEBUG - 2024-01-16 11:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 11:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:19:06 --> Final output sent to browser
DEBUG - 2024-01-16 11:19:06 --> Total execution time: 0.0331
INFO - 2024-01-16 11:19:10 --> Config Class Initialized
INFO - 2024-01-16 11:19:10 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:19:10 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:19:10 --> Utf8 Class Initialized
INFO - 2024-01-16 11:19:10 --> URI Class Initialized
INFO - 2024-01-16 11:19:10 --> Router Class Initialized
INFO - 2024-01-16 11:19:10 --> Output Class Initialized
INFO - 2024-01-16 11:19:10 --> Security Class Initialized
DEBUG - 2024-01-16 11:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:19:10 --> Input Class Initialized
INFO - 2024-01-16 11:19:10 --> Language Class Initialized
INFO - 2024-01-16 11:19:10 --> Language Class Initialized
INFO - 2024-01-16 11:19:10 --> Config Class Initialized
INFO - 2024-01-16 11:19:10 --> Loader Class Initialized
INFO - 2024-01-16 11:19:10 --> Helper loaded: url_helper
INFO - 2024-01-16 11:19:10 --> Helper loaded: file_helper
INFO - 2024-01-16 11:19:10 --> Helper loaded: form_helper
INFO - 2024-01-16 11:19:10 --> Helper loaded: my_helper
INFO - 2024-01-16 11:19:10 --> Database Driver Class Initialized
INFO - 2024-01-16 11:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:19:10 --> Controller Class Initialized
DEBUG - 2024-01-16 11:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 11:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:19:10 --> Final output sent to browser
DEBUG - 2024-01-16 11:19:10 --> Total execution time: 0.0391
INFO - 2024-01-16 11:19:10 --> Config Class Initialized
INFO - 2024-01-16 11:19:10 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:19:10 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:19:10 --> Utf8 Class Initialized
INFO - 2024-01-16 11:19:10 --> URI Class Initialized
INFO - 2024-01-16 11:19:10 --> Router Class Initialized
INFO - 2024-01-16 11:19:10 --> Output Class Initialized
INFO - 2024-01-16 11:19:10 --> Security Class Initialized
DEBUG - 2024-01-16 11:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:19:10 --> Input Class Initialized
INFO - 2024-01-16 11:19:10 --> Language Class Initialized
INFO - 2024-01-16 11:19:10 --> Language Class Initialized
INFO - 2024-01-16 11:19:10 --> Config Class Initialized
INFO - 2024-01-16 11:19:10 --> Loader Class Initialized
INFO - 2024-01-16 11:19:10 --> Helper loaded: url_helper
INFO - 2024-01-16 11:19:10 --> Helper loaded: file_helper
INFO - 2024-01-16 11:19:10 --> Helper loaded: form_helper
INFO - 2024-01-16 11:19:10 --> Helper loaded: my_helper
INFO - 2024-01-16 11:19:10 --> Database Driver Class Initialized
INFO - 2024-01-16 11:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:19:10 --> Controller Class Initialized
INFO - 2024-01-16 11:19:13 --> Config Class Initialized
INFO - 2024-01-16 11:19:13 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:19:13 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:19:13 --> Utf8 Class Initialized
INFO - 2024-01-16 11:19:13 --> URI Class Initialized
INFO - 2024-01-16 11:19:13 --> Router Class Initialized
INFO - 2024-01-16 11:19:13 --> Output Class Initialized
INFO - 2024-01-16 11:19:13 --> Security Class Initialized
DEBUG - 2024-01-16 11:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:19:13 --> Input Class Initialized
INFO - 2024-01-16 11:19:13 --> Language Class Initialized
INFO - 2024-01-16 11:19:13 --> Language Class Initialized
INFO - 2024-01-16 11:19:13 --> Config Class Initialized
INFO - 2024-01-16 11:19:13 --> Loader Class Initialized
INFO - 2024-01-16 11:19:13 --> Helper loaded: url_helper
INFO - 2024-01-16 11:19:13 --> Helper loaded: file_helper
INFO - 2024-01-16 11:19:13 --> Helper loaded: form_helper
INFO - 2024-01-16 11:19:13 --> Helper loaded: my_helper
INFO - 2024-01-16 11:19:13 --> Database Driver Class Initialized
INFO - 2024-01-16 11:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:19:13 --> Controller Class Initialized
INFO - 2024-01-16 11:33:09 --> Config Class Initialized
INFO - 2024-01-16 11:33:09 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:09 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:09 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:09 --> URI Class Initialized
INFO - 2024-01-16 11:33:09 --> Router Class Initialized
INFO - 2024-01-16 11:33:09 --> Output Class Initialized
INFO - 2024-01-16 11:33:09 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:09 --> Input Class Initialized
INFO - 2024-01-16 11:33:09 --> Language Class Initialized
INFO - 2024-01-16 11:33:09 --> Language Class Initialized
INFO - 2024-01-16 11:33:09 --> Config Class Initialized
INFO - 2024-01-16 11:33:09 --> Loader Class Initialized
INFO - 2024-01-16 11:33:09 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:09 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:09 --> Controller Class Initialized
INFO - 2024-01-16 11:33:09 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:33:09 --> Config Class Initialized
INFO - 2024-01-16 11:33:09 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:09 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:09 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:09 --> URI Class Initialized
INFO - 2024-01-16 11:33:09 --> Router Class Initialized
INFO - 2024-01-16 11:33:09 --> Output Class Initialized
INFO - 2024-01-16 11:33:09 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:09 --> Input Class Initialized
INFO - 2024-01-16 11:33:09 --> Language Class Initialized
INFO - 2024-01-16 11:33:09 --> Language Class Initialized
INFO - 2024-01-16 11:33:09 --> Config Class Initialized
INFO - 2024-01-16 11:33:09 --> Loader Class Initialized
INFO - 2024-01-16 11:33:09 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:09 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:09 --> Controller Class Initialized
INFO - 2024-01-16 11:33:09 --> Config Class Initialized
INFO - 2024-01-16 11:33:09 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:09 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:09 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:09 --> URI Class Initialized
INFO - 2024-01-16 11:33:09 --> Router Class Initialized
INFO - 2024-01-16 11:33:09 --> Output Class Initialized
INFO - 2024-01-16 11:33:09 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:09 --> Input Class Initialized
INFO - 2024-01-16 11:33:09 --> Language Class Initialized
INFO - 2024-01-16 11:33:09 --> Language Class Initialized
INFO - 2024-01-16 11:33:09 --> Config Class Initialized
INFO - 2024-01-16 11:33:09 --> Loader Class Initialized
INFO - 2024-01-16 11:33:09 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:09 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:09 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:09 --> Controller Class Initialized
DEBUG - 2024-01-16 11:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 11:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:33:09 --> Final output sent to browser
DEBUG - 2024-01-16 11:33:09 --> Total execution time: 0.0421
INFO - 2024-01-16 11:33:18 --> Config Class Initialized
INFO - 2024-01-16 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:18 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:18 --> URI Class Initialized
INFO - 2024-01-16 11:33:18 --> Router Class Initialized
INFO - 2024-01-16 11:33:18 --> Output Class Initialized
INFO - 2024-01-16 11:33:18 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:18 --> Input Class Initialized
INFO - 2024-01-16 11:33:18 --> Language Class Initialized
INFO - 2024-01-16 11:33:18 --> Language Class Initialized
INFO - 2024-01-16 11:33:18 --> Config Class Initialized
INFO - 2024-01-16 11:33:18 --> Loader Class Initialized
INFO - 2024-01-16 11:33:18 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:18 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:18 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:18 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:18 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:18 --> Controller Class Initialized
INFO - 2024-01-16 11:33:18 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:33:18 --> Final output sent to browser
DEBUG - 2024-01-16 11:33:18 --> Total execution time: 0.0393
INFO - 2024-01-16 11:33:18 --> Config Class Initialized
INFO - 2024-01-16 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:18 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:18 --> URI Class Initialized
INFO - 2024-01-16 11:33:18 --> Router Class Initialized
INFO - 2024-01-16 11:33:18 --> Output Class Initialized
INFO - 2024-01-16 11:33:18 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:18 --> Input Class Initialized
INFO - 2024-01-16 11:33:18 --> Language Class Initialized
INFO - 2024-01-16 11:33:18 --> Language Class Initialized
INFO - 2024-01-16 11:33:18 --> Config Class Initialized
INFO - 2024-01-16 11:33:18 --> Loader Class Initialized
INFO - 2024-01-16 11:33:18 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:18 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:18 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:18 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:18 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:18 --> Controller Class Initialized
DEBUG - 2024-01-16 11:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 11:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:33:18 --> Final output sent to browser
DEBUG - 2024-01-16 11:33:18 --> Total execution time: 0.0331
INFO - 2024-01-16 11:33:54 --> Config Class Initialized
INFO - 2024-01-16 11:33:54 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:54 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:54 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:54 --> URI Class Initialized
INFO - 2024-01-16 11:33:54 --> Router Class Initialized
INFO - 2024-01-16 11:33:54 --> Output Class Initialized
INFO - 2024-01-16 11:33:54 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:54 --> Input Class Initialized
INFO - 2024-01-16 11:33:54 --> Language Class Initialized
INFO - 2024-01-16 11:33:54 --> Language Class Initialized
INFO - 2024-01-16 11:33:54 --> Config Class Initialized
INFO - 2024-01-16 11:33:54 --> Loader Class Initialized
INFO - 2024-01-16 11:33:54 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:54 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:54 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:54 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:54 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:54 --> Controller Class Initialized
DEBUG - 2024-01-16 11:33:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 11:33:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:33:54 --> Final output sent to browser
DEBUG - 2024-01-16 11:33:54 --> Total execution time: 0.0724
INFO - 2024-01-16 11:33:56 --> Config Class Initialized
INFO - 2024-01-16 11:33:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:56 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:56 --> URI Class Initialized
INFO - 2024-01-16 11:33:56 --> Router Class Initialized
INFO - 2024-01-16 11:33:56 --> Output Class Initialized
INFO - 2024-01-16 11:33:56 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:56 --> Input Class Initialized
INFO - 2024-01-16 11:33:56 --> Language Class Initialized
INFO - 2024-01-16 11:33:56 --> Language Class Initialized
INFO - 2024-01-16 11:33:56 --> Config Class Initialized
INFO - 2024-01-16 11:33:56 --> Loader Class Initialized
INFO - 2024-01-16 11:33:56 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:56 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:56 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:56 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:56 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:56 --> Controller Class Initialized
DEBUG - 2024-01-16 11:33:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 11:33:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:33:56 --> Final output sent to browser
DEBUG - 2024-01-16 11:33:56 --> Total execution time: 0.0400
INFO - 2024-01-16 11:33:56 --> Config Class Initialized
INFO - 2024-01-16 11:33:56 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:33:56 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:33:56 --> Utf8 Class Initialized
INFO - 2024-01-16 11:33:56 --> URI Class Initialized
INFO - 2024-01-16 11:33:56 --> Router Class Initialized
INFO - 2024-01-16 11:33:56 --> Output Class Initialized
INFO - 2024-01-16 11:33:56 --> Security Class Initialized
DEBUG - 2024-01-16 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:33:56 --> Input Class Initialized
INFO - 2024-01-16 11:33:56 --> Language Class Initialized
INFO - 2024-01-16 11:33:56 --> Language Class Initialized
INFO - 2024-01-16 11:33:56 --> Config Class Initialized
INFO - 2024-01-16 11:33:56 --> Loader Class Initialized
INFO - 2024-01-16 11:33:56 --> Helper loaded: url_helper
INFO - 2024-01-16 11:33:56 --> Helper loaded: file_helper
INFO - 2024-01-16 11:33:56 --> Helper loaded: form_helper
INFO - 2024-01-16 11:33:56 --> Helper loaded: my_helper
INFO - 2024-01-16 11:33:56 --> Database Driver Class Initialized
INFO - 2024-01-16 11:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:33:56 --> Controller Class Initialized
INFO - 2024-01-16 11:34:05 --> Config Class Initialized
INFO - 2024-01-16 11:34:05 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:34:05 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:34:05 --> Utf8 Class Initialized
INFO - 2024-01-16 11:34:05 --> URI Class Initialized
INFO - 2024-01-16 11:34:05 --> Router Class Initialized
INFO - 2024-01-16 11:34:05 --> Output Class Initialized
INFO - 2024-01-16 11:34:05 --> Security Class Initialized
DEBUG - 2024-01-16 11:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:34:05 --> Input Class Initialized
INFO - 2024-01-16 11:34:05 --> Language Class Initialized
INFO - 2024-01-16 11:34:05 --> Language Class Initialized
INFO - 2024-01-16 11:34:05 --> Config Class Initialized
INFO - 2024-01-16 11:34:05 --> Loader Class Initialized
INFO - 2024-01-16 11:34:05 --> Helper loaded: url_helper
INFO - 2024-01-16 11:34:05 --> Helper loaded: file_helper
INFO - 2024-01-16 11:34:05 --> Helper loaded: form_helper
INFO - 2024-01-16 11:34:05 --> Helper loaded: my_helper
INFO - 2024-01-16 11:34:05 --> Database Driver Class Initialized
INFO - 2024-01-16 11:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:34:05 --> Controller Class Initialized
INFO - 2024-01-16 11:35:58 --> Config Class Initialized
INFO - 2024-01-16 11:35:58 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:35:58 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:35:58 --> Utf8 Class Initialized
INFO - 2024-01-16 11:35:58 --> URI Class Initialized
INFO - 2024-01-16 11:35:58 --> Router Class Initialized
INFO - 2024-01-16 11:35:58 --> Output Class Initialized
INFO - 2024-01-16 11:35:58 --> Security Class Initialized
DEBUG - 2024-01-16 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:35:58 --> Input Class Initialized
INFO - 2024-01-16 11:35:58 --> Language Class Initialized
INFO - 2024-01-16 11:35:58 --> Language Class Initialized
INFO - 2024-01-16 11:35:58 --> Config Class Initialized
INFO - 2024-01-16 11:35:58 --> Loader Class Initialized
INFO - 2024-01-16 11:35:58 --> Helper loaded: url_helper
INFO - 2024-01-16 11:35:58 --> Helper loaded: file_helper
INFO - 2024-01-16 11:35:58 --> Helper loaded: form_helper
INFO - 2024-01-16 11:35:58 --> Helper loaded: my_helper
INFO - 2024-01-16 11:35:58 --> Database Driver Class Initialized
INFO - 2024-01-16 11:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:35:58 --> Controller Class Initialized
INFO - 2024-01-16 11:35:58 --> Final output sent to browser
DEBUG - 2024-01-16 11:35:58 --> Total execution time: 0.0353
INFO - 2024-01-16 11:36:01 --> Config Class Initialized
INFO - 2024-01-16 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:36:01 --> Utf8 Class Initialized
INFO - 2024-01-16 11:36:01 --> URI Class Initialized
INFO - 2024-01-16 11:36:01 --> Router Class Initialized
INFO - 2024-01-16 11:36:01 --> Output Class Initialized
INFO - 2024-01-16 11:36:01 --> Security Class Initialized
DEBUG - 2024-01-16 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:36:01 --> Input Class Initialized
INFO - 2024-01-16 11:36:01 --> Language Class Initialized
INFO - 2024-01-16 11:36:01 --> Language Class Initialized
INFO - 2024-01-16 11:36:01 --> Config Class Initialized
INFO - 2024-01-16 11:36:01 --> Loader Class Initialized
INFO - 2024-01-16 11:36:01 --> Helper loaded: url_helper
INFO - 2024-01-16 11:36:01 --> Helper loaded: file_helper
INFO - 2024-01-16 11:36:01 --> Helper loaded: form_helper
INFO - 2024-01-16 11:36:01 --> Helper loaded: my_helper
INFO - 2024-01-16 11:36:01 --> Database Driver Class Initialized
INFO - 2024-01-16 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:36:01 --> Controller Class Initialized
INFO - 2024-01-16 11:36:01 --> Final output sent to browser
DEBUG - 2024-01-16 11:36:01 --> Total execution time: 0.0437
INFO - 2024-01-16 11:36:07 --> Config Class Initialized
INFO - 2024-01-16 11:36:07 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:36:07 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:36:07 --> Utf8 Class Initialized
INFO - 2024-01-16 11:36:07 --> URI Class Initialized
INFO - 2024-01-16 11:36:07 --> Router Class Initialized
INFO - 2024-01-16 11:36:07 --> Output Class Initialized
INFO - 2024-01-16 11:36:07 --> Security Class Initialized
DEBUG - 2024-01-16 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:36:07 --> Input Class Initialized
INFO - 2024-01-16 11:36:07 --> Language Class Initialized
INFO - 2024-01-16 11:36:07 --> Language Class Initialized
INFO - 2024-01-16 11:36:07 --> Config Class Initialized
INFO - 2024-01-16 11:36:07 --> Loader Class Initialized
INFO - 2024-01-16 11:36:07 --> Helper loaded: url_helper
INFO - 2024-01-16 11:36:07 --> Helper loaded: file_helper
INFO - 2024-01-16 11:36:07 --> Helper loaded: form_helper
INFO - 2024-01-16 11:36:07 --> Helper loaded: my_helper
INFO - 2024-01-16 11:36:07 --> Database Driver Class Initialized
INFO - 2024-01-16 11:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:36:07 --> Controller Class Initialized
INFO - 2024-01-16 11:36:07 --> Final output sent to browser
DEBUG - 2024-01-16 11:36:07 --> Total execution time: 0.0469
INFO - 2024-01-16 11:37:23 --> Config Class Initialized
INFO - 2024-01-16 11:37:23 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:37:23 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:37:23 --> Utf8 Class Initialized
INFO - 2024-01-16 11:37:23 --> URI Class Initialized
INFO - 2024-01-16 11:37:23 --> Router Class Initialized
INFO - 2024-01-16 11:37:23 --> Output Class Initialized
INFO - 2024-01-16 11:37:23 --> Security Class Initialized
DEBUG - 2024-01-16 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:37:23 --> Input Class Initialized
INFO - 2024-01-16 11:37:23 --> Language Class Initialized
INFO - 2024-01-16 11:37:23 --> Language Class Initialized
INFO - 2024-01-16 11:37:23 --> Config Class Initialized
INFO - 2024-01-16 11:37:23 --> Loader Class Initialized
INFO - 2024-01-16 11:37:23 --> Helper loaded: url_helper
INFO - 2024-01-16 11:37:23 --> Helper loaded: file_helper
INFO - 2024-01-16 11:37:23 --> Helper loaded: form_helper
INFO - 2024-01-16 11:37:23 --> Helper loaded: my_helper
INFO - 2024-01-16 11:37:23 --> Database Driver Class Initialized
INFO - 2024-01-16 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:37:23 --> Controller Class Initialized
INFO - 2024-01-16 11:45:57 --> Config Class Initialized
INFO - 2024-01-16 11:45:57 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:45:57 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:45:57 --> Utf8 Class Initialized
INFO - 2024-01-16 11:45:57 --> URI Class Initialized
INFO - 2024-01-16 11:45:57 --> Router Class Initialized
INFO - 2024-01-16 11:45:57 --> Output Class Initialized
INFO - 2024-01-16 11:45:57 --> Security Class Initialized
DEBUG - 2024-01-16 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:45:57 --> Input Class Initialized
INFO - 2024-01-16 11:45:57 --> Language Class Initialized
INFO - 2024-01-16 11:45:57 --> Language Class Initialized
INFO - 2024-01-16 11:45:57 --> Config Class Initialized
INFO - 2024-01-16 11:45:57 --> Loader Class Initialized
INFO - 2024-01-16 11:45:57 --> Helper loaded: url_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: file_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: form_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: my_helper
INFO - 2024-01-16 11:45:57 --> Database Driver Class Initialized
INFO - 2024-01-16 11:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:45:57 --> Controller Class Initialized
INFO - 2024-01-16 11:45:57 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:45:57 --> Config Class Initialized
INFO - 2024-01-16 11:45:57 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:45:57 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:45:57 --> Utf8 Class Initialized
INFO - 2024-01-16 11:45:57 --> URI Class Initialized
INFO - 2024-01-16 11:45:57 --> Router Class Initialized
INFO - 2024-01-16 11:45:57 --> Output Class Initialized
INFO - 2024-01-16 11:45:57 --> Security Class Initialized
DEBUG - 2024-01-16 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:45:57 --> Input Class Initialized
INFO - 2024-01-16 11:45:57 --> Language Class Initialized
INFO - 2024-01-16 11:45:57 --> Language Class Initialized
INFO - 2024-01-16 11:45:57 --> Config Class Initialized
INFO - 2024-01-16 11:45:57 --> Loader Class Initialized
INFO - 2024-01-16 11:45:57 --> Helper loaded: url_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: file_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: form_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: my_helper
INFO - 2024-01-16 11:45:57 --> Database Driver Class Initialized
INFO - 2024-01-16 11:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:45:57 --> Controller Class Initialized
INFO - 2024-01-16 11:45:57 --> Config Class Initialized
INFO - 2024-01-16 11:45:57 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:45:57 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:45:57 --> Utf8 Class Initialized
INFO - 2024-01-16 11:45:57 --> URI Class Initialized
INFO - 2024-01-16 11:45:57 --> Router Class Initialized
INFO - 2024-01-16 11:45:57 --> Output Class Initialized
INFO - 2024-01-16 11:45:57 --> Security Class Initialized
DEBUG - 2024-01-16 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:45:57 --> Input Class Initialized
INFO - 2024-01-16 11:45:57 --> Language Class Initialized
INFO - 2024-01-16 11:45:57 --> Language Class Initialized
INFO - 2024-01-16 11:45:57 --> Config Class Initialized
INFO - 2024-01-16 11:45:57 --> Loader Class Initialized
INFO - 2024-01-16 11:45:57 --> Helper loaded: url_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: file_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: form_helper
INFO - 2024-01-16 11:45:57 --> Helper loaded: my_helper
INFO - 2024-01-16 11:45:57 --> Database Driver Class Initialized
INFO - 2024-01-16 11:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:45:57 --> Controller Class Initialized
DEBUG - 2024-01-16 11:45:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 11:45:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:45:57 --> Final output sent to browser
DEBUG - 2024-01-16 11:45:57 --> Total execution time: 0.0469
INFO - 2024-01-16 11:46:13 --> Config Class Initialized
INFO - 2024-01-16 11:46:13 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:46:13 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:46:13 --> Utf8 Class Initialized
INFO - 2024-01-16 11:46:13 --> URI Class Initialized
INFO - 2024-01-16 11:46:13 --> Router Class Initialized
INFO - 2024-01-16 11:46:13 --> Output Class Initialized
INFO - 2024-01-16 11:46:13 --> Security Class Initialized
DEBUG - 2024-01-16 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:46:13 --> Input Class Initialized
INFO - 2024-01-16 11:46:13 --> Language Class Initialized
INFO - 2024-01-16 11:46:13 --> Language Class Initialized
INFO - 2024-01-16 11:46:13 --> Config Class Initialized
INFO - 2024-01-16 11:46:13 --> Loader Class Initialized
INFO - 2024-01-16 11:46:13 --> Helper loaded: url_helper
INFO - 2024-01-16 11:46:13 --> Helper loaded: file_helper
INFO - 2024-01-16 11:46:13 --> Helper loaded: form_helper
INFO - 2024-01-16 11:46:13 --> Helper loaded: my_helper
INFO - 2024-01-16 11:46:13 --> Database Driver Class Initialized
INFO - 2024-01-16 11:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:46:13 --> Controller Class Initialized
INFO - 2024-01-16 11:46:13 --> Helper loaded: cookie_helper
INFO - 2024-01-16 11:46:13 --> Final output sent to browser
DEBUG - 2024-01-16 11:46:13 --> Total execution time: 0.0485
INFO - 2024-01-16 11:46:13 --> Config Class Initialized
INFO - 2024-01-16 11:46:13 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:46:13 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:46:13 --> Utf8 Class Initialized
INFO - 2024-01-16 11:46:13 --> URI Class Initialized
INFO - 2024-01-16 11:46:13 --> Router Class Initialized
INFO - 2024-01-16 11:46:13 --> Output Class Initialized
INFO - 2024-01-16 11:46:13 --> Security Class Initialized
DEBUG - 2024-01-16 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:46:13 --> Input Class Initialized
INFO - 2024-01-16 11:46:13 --> Language Class Initialized
INFO - 2024-01-16 11:46:13 --> Language Class Initialized
INFO - 2024-01-16 11:46:13 --> Config Class Initialized
INFO - 2024-01-16 11:46:13 --> Loader Class Initialized
INFO - 2024-01-16 11:46:13 --> Helper loaded: url_helper
INFO - 2024-01-16 11:46:13 --> Helper loaded: file_helper
INFO - 2024-01-16 11:46:13 --> Helper loaded: form_helper
INFO - 2024-01-16 11:46:13 --> Helper loaded: my_helper
INFO - 2024-01-16 11:46:13 --> Database Driver Class Initialized
INFO - 2024-01-16 11:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:46:13 --> Controller Class Initialized
DEBUG - 2024-01-16 11:46:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-16 11:46:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:46:13 --> Final output sent to browser
DEBUG - 2024-01-16 11:46:13 --> Total execution time: 0.0825
INFO - 2024-01-16 11:46:59 --> Config Class Initialized
INFO - 2024-01-16 11:46:59 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:46:59 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:46:59 --> Utf8 Class Initialized
INFO - 2024-01-16 11:46:59 --> URI Class Initialized
INFO - 2024-01-16 11:46:59 --> Router Class Initialized
INFO - 2024-01-16 11:46:59 --> Output Class Initialized
INFO - 2024-01-16 11:46:59 --> Security Class Initialized
DEBUG - 2024-01-16 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:46:59 --> Input Class Initialized
INFO - 2024-01-16 11:46:59 --> Language Class Initialized
INFO - 2024-01-16 11:46:59 --> Language Class Initialized
INFO - 2024-01-16 11:46:59 --> Config Class Initialized
INFO - 2024-01-16 11:46:59 --> Loader Class Initialized
INFO - 2024-01-16 11:46:59 --> Helper loaded: url_helper
INFO - 2024-01-16 11:46:59 --> Helper loaded: file_helper
INFO - 2024-01-16 11:46:59 --> Helper loaded: form_helper
INFO - 2024-01-16 11:46:59 --> Helper loaded: my_helper
INFO - 2024-01-16 11:46:59 --> Database Driver Class Initialized
INFO - 2024-01-16 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:46:59 --> Controller Class Initialized
DEBUG - 2024-01-16 11:46:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-16 11:46:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:46:59 --> Final output sent to browser
DEBUG - 2024-01-16 11:46:59 --> Total execution time: 0.0399
INFO - 2024-01-16 11:47:04 --> Config Class Initialized
INFO - 2024-01-16 11:47:04 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:47:04 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:47:04 --> Utf8 Class Initialized
INFO - 2024-01-16 11:47:04 --> URI Class Initialized
INFO - 2024-01-16 11:47:04 --> Router Class Initialized
INFO - 2024-01-16 11:47:04 --> Output Class Initialized
INFO - 2024-01-16 11:47:04 --> Security Class Initialized
DEBUG - 2024-01-16 11:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:47:04 --> Input Class Initialized
INFO - 2024-01-16 11:47:04 --> Language Class Initialized
INFO - 2024-01-16 11:47:04 --> Language Class Initialized
INFO - 2024-01-16 11:47:04 --> Config Class Initialized
INFO - 2024-01-16 11:47:04 --> Loader Class Initialized
INFO - 2024-01-16 11:47:04 --> Helper loaded: url_helper
INFO - 2024-01-16 11:47:04 --> Helper loaded: file_helper
INFO - 2024-01-16 11:47:04 --> Helper loaded: form_helper
INFO - 2024-01-16 11:47:04 --> Helper loaded: my_helper
INFO - 2024-01-16 11:47:04 --> Database Driver Class Initialized
INFO - 2024-01-16 11:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:47:04 --> Controller Class Initialized
DEBUG - 2024-01-16 11:47:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-16 11:47:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 11:47:04 --> Final output sent to browser
DEBUG - 2024-01-16 11:47:04 --> Total execution time: 0.0437
INFO - 2024-01-16 11:47:04 --> Config Class Initialized
INFO - 2024-01-16 11:47:04 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:47:04 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:47:04 --> Utf8 Class Initialized
INFO - 2024-01-16 11:47:04 --> URI Class Initialized
INFO - 2024-01-16 11:47:04 --> Router Class Initialized
INFO - 2024-01-16 11:47:04 --> Output Class Initialized
INFO - 2024-01-16 11:47:04 --> Security Class Initialized
DEBUG - 2024-01-16 11:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:47:04 --> Input Class Initialized
INFO - 2024-01-16 11:47:04 --> Language Class Initialized
INFO - 2024-01-16 11:47:04 --> Language Class Initialized
INFO - 2024-01-16 11:47:04 --> Config Class Initialized
INFO - 2024-01-16 11:47:04 --> Loader Class Initialized
INFO - 2024-01-16 11:47:04 --> Helper loaded: url_helper
INFO - 2024-01-16 11:47:04 --> Helper loaded: file_helper
INFO - 2024-01-16 11:47:04 --> Helper loaded: form_helper
INFO - 2024-01-16 11:47:04 --> Helper loaded: my_helper
INFO - 2024-01-16 11:47:04 --> Database Driver Class Initialized
INFO - 2024-01-16 11:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:47:04 --> Controller Class Initialized
INFO - 2024-01-16 11:47:08 --> Config Class Initialized
INFO - 2024-01-16 11:47:08 --> Hooks Class Initialized
DEBUG - 2024-01-16 11:47:08 --> UTF-8 Support Enabled
INFO - 2024-01-16 11:47:08 --> Utf8 Class Initialized
INFO - 2024-01-16 11:47:08 --> URI Class Initialized
INFO - 2024-01-16 11:47:08 --> Router Class Initialized
INFO - 2024-01-16 11:47:08 --> Output Class Initialized
INFO - 2024-01-16 11:47:08 --> Security Class Initialized
DEBUG - 2024-01-16 11:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 11:47:08 --> Input Class Initialized
INFO - 2024-01-16 11:47:08 --> Language Class Initialized
INFO - 2024-01-16 11:47:08 --> Language Class Initialized
INFO - 2024-01-16 11:47:08 --> Config Class Initialized
INFO - 2024-01-16 11:47:08 --> Loader Class Initialized
INFO - 2024-01-16 11:47:08 --> Helper loaded: url_helper
INFO - 2024-01-16 11:47:08 --> Helper loaded: file_helper
INFO - 2024-01-16 11:47:08 --> Helper loaded: form_helper
INFO - 2024-01-16 11:47:08 --> Helper loaded: my_helper
INFO - 2024-01-16 11:47:08 --> Database Driver Class Initialized
INFO - 2024-01-16 11:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 11:47:08 --> Controller Class Initialized
INFO - 2024-01-16 23:59:30 --> Config Class Initialized
INFO - 2024-01-16 23:59:30 --> Hooks Class Initialized
DEBUG - 2024-01-16 23:59:30 --> UTF-8 Support Enabled
INFO - 2024-01-16 23:59:30 --> Utf8 Class Initialized
INFO - 2024-01-16 23:59:30 --> URI Class Initialized
INFO - 2024-01-16 23:59:30 --> Router Class Initialized
INFO - 2024-01-16 23:59:30 --> Output Class Initialized
INFO - 2024-01-16 23:59:30 --> Security Class Initialized
DEBUG - 2024-01-16 23:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-16 23:59:30 --> Input Class Initialized
INFO - 2024-01-16 23:59:30 --> Language Class Initialized
INFO - 2024-01-16 23:59:30 --> Language Class Initialized
INFO - 2024-01-16 23:59:30 --> Config Class Initialized
INFO - 2024-01-16 23:59:30 --> Loader Class Initialized
INFO - 2024-01-16 23:59:30 --> Helper loaded: url_helper
INFO - 2024-01-16 23:59:30 --> Helper loaded: file_helper
INFO - 2024-01-16 23:59:30 --> Helper loaded: form_helper
INFO - 2024-01-16 23:59:30 --> Helper loaded: my_helper
INFO - 2024-01-16 23:59:30 --> Database Driver Class Initialized
INFO - 2024-01-16 23:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-16 23:59:30 --> Controller Class Initialized
DEBUG - 2024-01-16 23:59:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-16 23:59:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-16 23:59:30 --> Final output sent to browser
DEBUG - 2024-01-16 23:59:30 --> Total execution time: 0.1410
