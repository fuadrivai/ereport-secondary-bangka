<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-09 21:43:15 --> Config Class Initialized
INFO - 2023-10-09 21:43:15 --> Hooks Class Initialized
DEBUG - 2023-10-09 21:43:15 --> UTF-8 Support Enabled
INFO - 2023-10-09 21:43:15 --> Utf8 Class Initialized
INFO - 2023-10-09 21:43:15 --> URI Class Initialized
INFO - 2023-10-09 21:43:15 --> Router Class Initialized
INFO - 2023-10-09 21:43:15 --> Output Class Initialized
INFO - 2023-10-09 21:43:15 --> Security Class Initialized
DEBUG - 2023-10-09 21:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-09 21:43:15 --> Input Class Initialized
INFO - 2023-10-09 21:43:15 --> Language Class Initialized
INFO - 2023-10-09 21:43:15 --> Language Class Initialized
INFO - 2023-10-09 21:43:15 --> Config Class Initialized
INFO - 2023-10-09 21:43:15 --> Loader Class Initialized
INFO - 2023-10-09 21:43:15 --> Helper loaded: url_helper
INFO - 2023-10-09 21:43:15 --> Helper loaded: file_helper
INFO - 2023-10-09 21:43:15 --> Helper loaded: form_helper
INFO - 2023-10-09 21:43:15 --> Helper loaded: my_helper
INFO - 2023-10-09 21:43:15 --> Database Driver Class Initialized
INFO - 2023-10-09 21:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-09 21:43:15 --> Controller Class Initialized
DEBUG - 2023-10-09 21:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-09 21:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-09 21:43:15 --> Final output sent to browser
DEBUG - 2023-10-09 21:43:15 --> Total execution time: 0.0915
INFO - 2023-10-09 21:43:16 --> Config Class Initialized
INFO - 2023-10-09 21:43:16 --> Hooks Class Initialized
DEBUG - 2023-10-09 21:43:16 --> UTF-8 Support Enabled
INFO - 2023-10-09 21:43:16 --> Utf8 Class Initialized
INFO - 2023-10-09 21:43:16 --> URI Class Initialized
INFO - 2023-10-09 21:43:16 --> Router Class Initialized
INFO - 2023-10-09 21:43:16 --> Output Class Initialized
INFO - 2023-10-09 21:43:16 --> Security Class Initialized
DEBUG - 2023-10-09 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-09 21:43:16 --> Input Class Initialized
INFO - 2023-10-09 21:43:16 --> Language Class Initialized
INFO - 2023-10-09 21:43:16 --> Language Class Initialized
INFO - 2023-10-09 21:43:16 --> Config Class Initialized
INFO - 2023-10-09 21:43:16 --> Loader Class Initialized
INFO - 2023-10-09 21:43:16 --> Helper loaded: url_helper
INFO - 2023-10-09 21:43:16 --> Helper loaded: file_helper
INFO - 2023-10-09 21:43:16 --> Helper loaded: form_helper
INFO - 2023-10-09 21:43:16 --> Helper loaded: my_helper
INFO - 2023-10-09 21:43:16 --> Database Driver Class Initialized
INFO - 2023-10-09 21:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-09 21:43:16 --> Controller Class Initialized
INFO - 2023-10-09 21:43:29 --> Config Class Initialized
INFO - 2023-10-09 21:43:29 --> Hooks Class Initialized
DEBUG - 2023-10-09 21:43:29 --> UTF-8 Support Enabled
INFO - 2023-10-09 21:43:29 --> Utf8 Class Initialized
INFO - 2023-10-09 21:43:29 --> URI Class Initialized
INFO - 2023-10-09 21:43:29 --> Router Class Initialized
INFO - 2023-10-09 21:43:29 --> Output Class Initialized
INFO - 2023-10-09 21:43:29 --> Security Class Initialized
DEBUG - 2023-10-09 21:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-09 21:43:29 --> Input Class Initialized
INFO - 2023-10-09 21:43:29 --> Language Class Initialized
INFO - 2023-10-09 21:43:29 --> Language Class Initialized
INFO - 2023-10-09 21:43:29 --> Config Class Initialized
INFO - 2023-10-09 21:43:29 --> Loader Class Initialized
INFO - 2023-10-09 21:43:29 --> Helper loaded: url_helper
INFO - 2023-10-09 21:43:29 --> Helper loaded: file_helper
INFO - 2023-10-09 21:43:29 --> Helper loaded: form_helper
INFO - 2023-10-09 21:43:29 --> Helper loaded: my_helper
INFO - 2023-10-09 21:43:29 --> Database Driver Class Initialized
INFO - 2023-10-09 21:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-09 21:43:29 --> Controller Class Initialized
INFO - 2023-10-09 21:43:29 --> Final output sent to browser
DEBUG - 2023-10-09 21:43:29 --> Total execution time: 0.0411
