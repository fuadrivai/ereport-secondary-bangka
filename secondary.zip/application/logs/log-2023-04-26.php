<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-26 06:34:59 --> Config Class Initialized
INFO - 2023-04-26 06:34:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 06:34:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 06:34:59 --> Utf8 Class Initialized
INFO - 2023-04-26 06:34:59 --> URI Class Initialized
INFO - 2023-04-26 06:34:59 --> Router Class Initialized
INFO - 2023-04-26 06:34:59 --> Output Class Initialized
INFO - 2023-04-26 06:34:59 --> Security Class Initialized
DEBUG - 2023-04-26 06:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 06:34:59 --> Input Class Initialized
INFO - 2023-04-26 06:34:59 --> Language Class Initialized
INFO - 2023-04-26 06:34:59 --> Language Class Initialized
INFO - 2023-04-26 06:34:59 --> Config Class Initialized
INFO - 2023-04-26 06:34:59 --> Loader Class Initialized
INFO - 2023-04-26 06:34:59 --> Helper loaded: url_helper
INFO - 2023-04-26 06:34:59 --> Helper loaded: file_helper
INFO - 2023-04-26 06:34:59 --> Helper loaded: form_helper
INFO - 2023-04-26 06:34:59 --> Helper loaded: my_helper
INFO - 2023-04-26 06:35:00 --> Database Driver Class Initialized
DEBUG - 2023-04-26 06:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 06:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 06:35:00 --> Controller Class Initialized
DEBUG - 2023-04-26 06:35:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 06:35:01 --> Final output sent to browser
DEBUG - 2023-04-26 06:35:01 --> Total execution time: 2.0130
INFO - 2023-04-26 06:36:05 --> Config Class Initialized
INFO - 2023-04-26 06:36:05 --> Hooks Class Initialized
DEBUG - 2023-04-26 06:36:05 --> UTF-8 Support Enabled
INFO - 2023-04-26 06:36:05 --> Utf8 Class Initialized
INFO - 2023-04-26 06:36:05 --> URI Class Initialized
INFO - 2023-04-26 06:36:05 --> Router Class Initialized
INFO - 2023-04-26 06:36:05 --> Output Class Initialized
INFO - 2023-04-26 06:36:05 --> Security Class Initialized
DEBUG - 2023-04-26 06:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 06:36:05 --> Input Class Initialized
INFO - 2023-04-26 06:36:05 --> Language Class Initialized
INFO - 2023-04-26 06:36:05 --> Language Class Initialized
INFO - 2023-04-26 06:36:05 --> Config Class Initialized
INFO - 2023-04-26 06:36:05 --> Loader Class Initialized
INFO - 2023-04-26 06:36:05 --> Helper loaded: url_helper
INFO - 2023-04-26 06:36:05 --> Helper loaded: file_helper
INFO - 2023-04-26 06:36:05 --> Helper loaded: form_helper
INFO - 2023-04-26 06:36:05 --> Helper loaded: my_helper
INFO - 2023-04-26 06:36:05 --> Database Driver Class Initialized
DEBUG - 2023-04-26 06:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 06:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 06:36:05 --> Controller Class Initialized
DEBUG - 2023-04-26 06:36:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 06:36:06 --> Final output sent to browser
DEBUG - 2023-04-26 06:36:06 --> Total execution time: 0.5599
INFO - 2023-04-26 07:11:27 --> Config Class Initialized
INFO - 2023-04-26 07:11:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 07:11:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 07:11:27 --> Utf8 Class Initialized
INFO - 2023-04-26 07:11:27 --> URI Class Initialized
INFO - 2023-04-26 07:11:27 --> Router Class Initialized
INFO - 2023-04-26 07:11:27 --> Output Class Initialized
INFO - 2023-04-26 07:11:27 --> Security Class Initialized
DEBUG - 2023-04-26 07:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 07:11:27 --> Input Class Initialized
INFO - 2023-04-26 07:11:27 --> Language Class Initialized
INFO - 2023-04-26 07:11:27 --> Language Class Initialized
INFO - 2023-04-26 07:11:27 --> Config Class Initialized
INFO - 2023-04-26 07:11:27 --> Loader Class Initialized
INFO - 2023-04-26 07:11:27 --> Helper loaded: url_helper
INFO - 2023-04-26 07:11:27 --> Helper loaded: file_helper
INFO - 2023-04-26 07:11:27 --> Helper loaded: form_helper
INFO - 2023-04-26 07:11:27 --> Helper loaded: my_helper
INFO - 2023-04-26 07:11:27 --> Database Driver Class Initialized
DEBUG - 2023-04-26 07:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 07:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 07:11:27 --> Controller Class Initialized
DEBUG - 2023-04-26 07:11:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-26 07:11:28 --> Final output sent to browser
DEBUG - 2023-04-26 07:11:28 --> Total execution time: 1.2386
INFO - 2023-04-26 07:33:46 --> Config Class Initialized
INFO - 2023-04-26 07:33:46 --> Hooks Class Initialized
DEBUG - 2023-04-26 07:33:46 --> UTF-8 Support Enabled
INFO - 2023-04-26 07:33:46 --> Utf8 Class Initialized
INFO - 2023-04-26 07:33:46 --> URI Class Initialized
INFO - 2023-04-26 07:33:46 --> Router Class Initialized
INFO - 2023-04-26 07:33:46 --> Output Class Initialized
INFO - 2023-04-26 07:33:46 --> Security Class Initialized
DEBUG - 2023-04-26 07:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 07:33:46 --> Input Class Initialized
INFO - 2023-04-26 07:33:46 --> Language Class Initialized
INFO - 2023-04-26 07:33:46 --> Language Class Initialized
INFO - 2023-04-26 07:33:46 --> Config Class Initialized
INFO - 2023-04-26 07:33:46 --> Loader Class Initialized
INFO - 2023-04-26 07:33:46 --> Helper loaded: url_helper
INFO - 2023-04-26 07:33:46 --> Helper loaded: file_helper
INFO - 2023-04-26 07:33:46 --> Helper loaded: form_helper
INFO - 2023-04-26 07:33:46 --> Helper loaded: my_helper
INFO - 2023-04-26 07:33:46 --> Database Driver Class Initialized
DEBUG - 2023-04-26 07:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 07:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 07:33:46 --> Controller Class Initialized
ERROR - 2023-04-26 07:33:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 2693
DEBUG - 2023-04-26 07:33:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-26 07:33:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 07:33:46 --> Final output sent to browser
DEBUG - 2023-04-26 07:33:46 --> Total execution time: 0.3606
INFO - 2023-04-26 08:15:22 --> Config Class Initialized
INFO - 2023-04-26 08:15:22 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:15:22 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:15:22 --> Utf8 Class Initialized
INFO - 2023-04-26 08:15:22 --> URI Class Initialized
INFO - 2023-04-26 08:15:22 --> Router Class Initialized
INFO - 2023-04-26 08:15:22 --> Output Class Initialized
INFO - 2023-04-26 08:15:22 --> Security Class Initialized
DEBUG - 2023-04-26 08:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:15:22 --> Input Class Initialized
INFO - 2023-04-26 08:15:22 --> Language Class Initialized
INFO - 2023-04-26 08:15:22 --> Language Class Initialized
INFO - 2023-04-26 08:15:22 --> Config Class Initialized
INFO - 2023-04-26 08:15:22 --> Loader Class Initialized
INFO - 2023-04-26 08:15:22 --> Helper loaded: url_helper
INFO - 2023-04-26 08:15:22 --> Helper loaded: file_helper
INFO - 2023-04-26 08:15:22 --> Helper loaded: form_helper
INFO - 2023-04-26 08:15:22 --> Helper loaded: my_helper
INFO - 2023-04-26 08:15:22 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:15:22 --> Controller Class Initialized
DEBUG - 2023-04-26 08:15:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:15:23 --> Final output sent to browser
DEBUG - 2023-04-26 08:15:23 --> Total execution time: 0.6501
INFO - 2023-04-26 08:16:06 --> Config Class Initialized
INFO - 2023-04-26 08:16:06 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:16:06 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:16:06 --> Utf8 Class Initialized
INFO - 2023-04-26 08:16:06 --> URI Class Initialized
INFO - 2023-04-26 08:16:06 --> Router Class Initialized
INFO - 2023-04-26 08:16:06 --> Output Class Initialized
INFO - 2023-04-26 08:16:06 --> Security Class Initialized
DEBUG - 2023-04-26 08:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:16:06 --> Input Class Initialized
INFO - 2023-04-26 08:16:06 --> Language Class Initialized
INFO - 2023-04-26 08:16:06 --> Language Class Initialized
INFO - 2023-04-26 08:16:06 --> Config Class Initialized
INFO - 2023-04-26 08:16:06 --> Loader Class Initialized
INFO - 2023-04-26 08:16:06 --> Helper loaded: url_helper
INFO - 2023-04-26 08:16:06 --> Helper loaded: file_helper
INFO - 2023-04-26 08:16:06 --> Helper loaded: form_helper
INFO - 2023-04-26 08:16:06 --> Helper loaded: my_helper
INFO - 2023-04-26 08:16:06 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:16:06 --> Controller Class Initialized
DEBUG - 2023-04-26 08:16:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:16:06 --> Final output sent to browser
DEBUG - 2023-04-26 08:16:06 --> Total execution time: 0.6253
INFO - 2023-04-26 08:17:34 --> Config Class Initialized
INFO - 2023-04-26 08:17:34 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:17:34 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:17:34 --> Utf8 Class Initialized
INFO - 2023-04-26 08:17:34 --> URI Class Initialized
INFO - 2023-04-26 08:17:34 --> Router Class Initialized
INFO - 2023-04-26 08:17:34 --> Output Class Initialized
INFO - 2023-04-26 08:17:34 --> Security Class Initialized
DEBUG - 2023-04-26 08:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:17:34 --> Input Class Initialized
INFO - 2023-04-26 08:17:34 --> Language Class Initialized
INFO - 2023-04-26 08:17:34 --> Language Class Initialized
INFO - 2023-04-26 08:17:34 --> Config Class Initialized
INFO - 2023-04-26 08:17:34 --> Loader Class Initialized
INFO - 2023-04-26 08:17:34 --> Helper loaded: url_helper
INFO - 2023-04-26 08:17:34 --> Helper loaded: file_helper
INFO - 2023-04-26 08:17:34 --> Helper loaded: form_helper
INFO - 2023-04-26 08:17:34 --> Helper loaded: my_helper
INFO - 2023-04-26 08:17:34 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:17:34 --> Controller Class Initialized
DEBUG - 2023-04-26 08:17:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:17:35 --> Final output sent to browser
DEBUG - 2023-04-26 08:17:35 --> Total execution time: 0.5953
INFO - 2023-04-26 08:17:50 --> Config Class Initialized
INFO - 2023-04-26 08:17:50 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:17:50 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:17:50 --> Utf8 Class Initialized
INFO - 2023-04-26 08:17:50 --> URI Class Initialized
INFO - 2023-04-26 08:17:50 --> Router Class Initialized
INFO - 2023-04-26 08:17:50 --> Output Class Initialized
INFO - 2023-04-26 08:17:50 --> Security Class Initialized
DEBUG - 2023-04-26 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:17:50 --> Input Class Initialized
INFO - 2023-04-26 08:17:50 --> Language Class Initialized
INFO - 2023-04-26 08:17:50 --> Language Class Initialized
INFO - 2023-04-26 08:17:50 --> Config Class Initialized
INFO - 2023-04-26 08:17:50 --> Loader Class Initialized
INFO - 2023-04-26 08:17:50 --> Helper loaded: url_helper
INFO - 2023-04-26 08:17:50 --> Helper loaded: file_helper
INFO - 2023-04-26 08:17:50 --> Helper loaded: form_helper
INFO - 2023-04-26 08:17:50 --> Helper loaded: my_helper
INFO - 2023-04-26 08:17:50 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:17:50 --> Controller Class Initialized
DEBUG - 2023-04-26 08:17:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:17:51 --> Final output sent to browser
DEBUG - 2023-04-26 08:17:51 --> Total execution time: 0.5889
INFO - 2023-04-26 08:18:07 --> Config Class Initialized
INFO - 2023-04-26 08:18:07 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:18:07 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:18:07 --> Utf8 Class Initialized
INFO - 2023-04-26 08:18:07 --> URI Class Initialized
INFO - 2023-04-26 08:18:07 --> Router Class Initialized
INFO - 2023-04-26 08:18:07 --> Output Class Initialized
INFO - 2023-04-26 08:18:07 --> Security Class Initialized
DEBUG - 2023-04-26 08:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:18:07 --> Input Class Initialized
INFO - 2023-04-26 08:18:07 --> Language Class Initialized
INFO - 2023-04-26 08:18:07 --> Language Class Initialized
INFO - 2023-04-26 08:18:07 --> Config Class Initialized
INFO - 2023-04-26 08:18:07 --> Loader Class Initialized
INFO - 2023-04-26 08:18:07 --> Helper loaded: url_helper
INFO - 2023-04-26 08:18:07 --> Helper loaded: file_helper
INFO - 2023-04-26 08:18:07 --> Helper loaded: form_helper
INFO - 2023-04-26 08:18:07 --> Helper loaded: my_helper
INFO - 2023-04-26 08:18:07 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:18:07 --> Controller Class Initialized
DEBUG - 2023-04-26 08:18:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:18:07 --> Final output sent to browser
DEBUG - 2023-04-26 08:18:07 --> Total execution time: 0.5629
INFO - 2023-04-26 08:18:16 --> Config Class Initialized
INFO - 2023-04-26 08:18:16 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:18:16 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:18:16 --> Utf8 Class Initialized
INFO - 2023-04-26 08:18:16 --> URI Class Initialized
INFO - 2023-04-26 08:18:16 --> Router Class Initialized
INFO - 2023-04-26 08:18:16 --> Output Class Initialized
INFO - 2023-04-26 08:18:16 --> Security Class Initialized
DEBUG - 2023-04-26 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:18:16 --> Input Class Initialized
INFO - 2023-04-26 08:18:16 --> Language Class Initialized
INFO - 2023-04-26 08:18:16 --> Language Class Initialized
INFO - 2023-04-26 08:18:16 --> Config Class Initialized
INFO - 2023-04-26 08:18:16 --> Loader Class Initialized
INFO - 2023-04-26 08:18:16 --> Helper loaded: url_helper
INFO - 2023-04-26 08:18:16 --> Helper loaded: file_helper
INFO - 2023-04-26 08:18:16 --> Helper loaded: form_helper
INFO - 2023-04-26 08:18:16 --> Helper loaded: my_helper
INFO - 2023-04-26 08:18:16 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:18:16 --> Controller Class Initialized
DEBUG - 2023-04-26 08:18:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:18:17 --> Final output sent to browser
DEBUG - 2023-04-26 08:18:17 --> Total execution time: 0.5737
INFO - 2023-04-26 08:19:00 --> Config Class Initialized
INFO - 2023-04-26 08:19:00 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:19:00 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:19:00 --> Utf8 Class Initialized
INFO - 2023-04-26 08:19:00 --> URI Class Initialized
INFO - 2023-04-26 08:19:00 --> Router Class Initialized
INFO - 2023-04-26 08:19:00 --> Output Class Initialized
INFO - 2023-04-26 08:19:00 --> Security Class Initialized
DEBUG - 2023-04-26 08:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:19:00 --> Input Class Initialized
INFO - 2023-04-26 08:19:00 --> Language Class Initialized
INFO - 2023-04-26 08:19:00 --> Language Class Initialized
INFO - 2023-04-26 08:19:00 --> Config Class Initialized
INFO - 2023-04-26 08:19:00 --> Loader Class Initialized
INFO - 2023-04-26 08:19:00 --> Helper loaded: url_helper
INFO - 2023-04-26 08:19:00 --> Helper loaded: file_helper
INFO - 2023-04-26 08:19:00 --> Helper loaded: form_helper
INFO - 2023-04-26 08:19:00 --> Helper loaded: my_helper
INFO - 2023-04-26 08:19:00 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:19:00 --> Controller Class Initialized
DEBUG - 2023-04-26 08:19:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:19:00 --> Final output sent to browser
DEBUG - 2023-04-26 08:19:00 --> Total execution time: 0.6000
INFO - 2023-04-26 08:19:19 --> Config Class Initialized
INFO - 2023-04-26 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:19:19 --> Utf8 Class Initialized
INFO - 2023-04-26 08:19:19 --> URI Class Initialized
INFO - 2023-04-26 08:19:19 --> Router Class Initialized
INFO - 2023-04-26 08:19:19 --> Output Class Initialized
INFO - 2023-04-26 08:19:19 --> Security Class Initialized
DEBUG - 2023-04-26 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:19:19 --> Input Class Initialized
INFO - 2023-04-26 08:19:19 --> Language Class Initialized
INFO - 2023-04-26 08:19:19 --> Language Class Initialized
INFO - 2023-04-26 08:19:19 --> Config Class Initialized
INFO - 2023-04-26 08:19:19 --> Loader Class Initialized
INFO - 2023-04-26 08:19:19 --> Helper loaded: url_helper
INFO - 2023-04-26 08:19:19 --> Helper loaded: file_helper
INFO - 2023-04-26 08:19:19 --> Helper loaded: form_helper
INFO - 2023-04-26 08:19:19 --> Helper loaded: my_helper
INFO - 2023-04-26 08:19:19 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:19:19 --> Controller Class Initialized
DEBUG - 2023-04-26 08:19:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:19:20 --> Final output sent to browser
DEBUG - 2023-04-26 08:19:20 --> Total execution time: 0.5897
INFO - 2023-04-26 08:19:35 --> Config Class Initialized
INFO - 2023-04-26 08:19:35 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:19:35 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:19:35 --> Utf8 Class Initialized
INFO - 2023-04-26 08:19:35 --> URI Class Initialized
INFO - 2023-04-26 08:19:35 --> Router Class Initialized
INFO - 2023-04-26 08:19:35 --> Output Class Initialized
INFO - 2023-04-26 08:19:35 --> Security Class Initialized
DEBUG - 2023-04-26 08:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:19:35 --> Input Class Initialized
INFO - 2023-04-26 08:19:35 --> Language Class Initialized
INFO - 2023-04-26 08:19:35 --> Language Class Initialized
INFO - 2023-04-26 08:19:35 --> Config Class Initialized
INFO - 2023-04-26 08:19:35 --> Loader Class Initialized
INFO - 2023-04-26 08:19:35 --> Helper loaded: url_helper
INFO - 2023-04-26 08:19:35 --> Helper loaded: file_helper
INFO - 2023-04-26 08:19:35 --> Helper loaded: form_helper
INFO - 2023-04-26 08:19:35 --> Helper loaded: my_helper
INFO - 2023-04-26 08:19:35 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:19:35 --> Controller Class Initialized
DEBUG - 2023-04-26 08:19:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:19:35 --> Final output sent to browser
DEBUG - 2023-04-26 08:19:35 --> Total execution time: 0.5765
INFO - 2023-04-26 08:20:45 --> Config Class Initialized
INFO - 2023-04-26 08:20:45 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:20:45 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:20:45 --> Utf8 Class Initialized
INFO - 2023-04-26 08:20:45 --> URI Class Initialized
DEBUG - 2023-04-26 08:20:45 --> No URI present. Default controller set.
INFO - 2023-04-26 08:20:45 --> Router Class Initialized
INFO - 2023-04-26 08:20:45 --> Output Class Initialized
INFO - 2023-04-26 08:20:45 --> Security Class Initialized
DEBUG - 2023-04-26 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:20:45 --> Input Class Initialized
INFO - 2023-04-26 08:20:45 --> Language Class Initialized
INFO - 2023-04-26 08:20:45 --> Language Class Initialized
INFO - 2023-04-26 08:20:45 --> Config Class Initialized
INFO - 2023-04-26 08:20:45 --> Loader Class Initialized
INFO - 2023-04-26 08:20:45 --> Helper loaded: url_helper
INFO - 2023-04-26 08:20:45 --> Helper loaded: file_helper
INFO - 2023-04-26 08:20:45 --> Helper loaded: form_helper
INFO - 2023-04-26 08:20:45 --> Helper loaded: my_helper
INFO - 2023-04-26 08:20:45 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:20:45 --> Controller Class Initialized
INFO - 2023-04-26 08:20:45 --> Config Class Initialized
INFO - 2023-04-26 08:20:45 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:20:45 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:20:45 --> Utf8 Class Initialized
INFO - 2023-04-26 08:20:45 --> URI Class Initialized
INFO - 2023-04-26 08:20:45 --> Router Class Initialized
INFO - 2023-04-26 08:20:45 --> Output Class Initialized
INFO - 2023-04-26 08:20:45 --> Security Class Initialized
DEBUG - 2023-04-26 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:20:45 --> Input Class Initialized
INFO - 2023-04-26 08:20:45 --> Language Class Initialized
INFO - 2023-04-26 08:20:45 --> Language Class Initialized
INFO - 2023-04-26 08:20:45 --> Config Class Initialized
INFO - 2023-04-26 08:20:45 --> Loader Class Initialized
INFO - 2023-04-26 08:20:45 --> Helper loaded: url_helper
INFO - 2023-04-26 08:20:45 --> Helper loaded: file_helper
INFO - 2023-04-26 08:20:45 --> Helper loaded: form_helper
INFO - 2023-04-26 08:20:45 --> Helper loaded: my_helper
INFO - 2023-04-26 08:20:45 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:20:45 --> Controller Class Initialized
DEBUG - 2023-04-26 08:20:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-26 08:20:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 08:20:45 --> Final output sent to browser
DEBUG - 2023-04-26 08:20:45 --> Total execution time: 0.0750
INFO - 2023-04-26 08:20:49 --> Config Class Initialized
INFO - 2023-04-26 08:20:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:20:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:20:49 --> Utf8 Class Initialized
INFO - 2023-04-26 08:20:49 --> URI Class Initialized
INFO - 2023-04-26 08:20:49 --> Router Class Initialized
INFO - 2023-04-26 08:20:49 --> Output Class Initialized
INFO - 2023-04-26 08:20:49 --> Security Class Initialized
DEBUG - 2023-04-26 08:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:20:49 --> Input Class Initialized
INFO - 2023-04-26 08:20:49 --> Language Class Initialized
INFO - 2023-04-26 08:20:49 --> Language Class Initialized
INFO - 2023-04-26 08:20:49 --> Config Class Initialized
INFO - 2023-04-26 08:20:49 --> Loader Class Initialized
INFO - 2023-04-26 08:20:49 --> Helper loaded: url_helper
INFO - 2023-04-26 08:20:49 --> Helper loaded: file_helper
INFO - 2023-04-26 08:20:49 --> Helper loaded: form_helper
INFO - 2023-04-26 08:20:49 --> Helper loaded: my_helper
INFO - 2023-04-26 08:20:49 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:20:49 --> Controller Class Initialized
INFO - 2023-04-26 08:20:49 --> Helper loaded: cookie_helper
INFO - 2023-04-26 08:20:49 --> Final output sent to browser
DEBUG - 2023-04-26 08:20:49 --> Total execution time: 0.0480
INFO - 2023-04-26 08:20:49 --> Config Class Initialized
INFO - 2023-04-26 08:20:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:20:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:20:49 --> Utf8 Class Initialized
INFO - 2023-04-26 08:20:49 --> URI Class Initialized
INFO - 2023-04-26 08:20:49 --> Router Class Initialized
INFO - 2023-04-26 08:20:49 --> Output Class Initialized
INFO - 2023-04-26 08:20:49 --> Security Class Initialized
DEBUG - 2023-04-26 08:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:20:49 --> Input Class Initialized
INFO - 2023-04-26 08:20:49 --> Language Class Initialized
INFO - 2023-04-26 08:20:49 --> Language Class Initialized
INFO - 2023-04-26 08:20:49 --> Config Class Initialized
INFO - 2023-04-26 08:20:49 --> Loader Class Initialized
INFO - 2023-04-26 08:20:50 --> Helper loaded: url_helper
INFO - 2023-04-26 08:20:50 --> Helper loaded: file_helper
INFO - 2023-04-26 08:20:50 --> Helper loaded: form_helper
INFO - 2023-04-26 08:20:50 --> Helper loaded: my_helper
INFO - 2023-04-26 08:20:50 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:20:50 --> Controller Class Initialized
DEBUG - 2023-04-26 08:20:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-26 08:20:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 08:20:50 --> Final output sent to browser
DEBUG - 2023-04-26 08:20:50 --> Total execution time: 0.0587
INFO - 2023-04-26 08:20:53 --> Config Class Initialized
INFO - 2023-04-26 08:20:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:20:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:20:53 --> Utf8 Class Initialized
INFO - 2023-04-26 08:20:53 --> URI Class Initialized
INFO - 2023-04-26 08:20:53 --> Router Class Initialized
INFO - 2023-04-26 08:20:53 --> Output Class Initialized
INFO - 2023-04-26 08:20:53 --> Security Class Initialized
DEBUG - 2023-04-26 08:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:20:53 --> Input Class Initialized
INFO - 2023-04-26 08:20:53 --> Language Class Initialized
INFO - 2023-04-26 08:20:53 --> Language Class Initialized
INFO - 2023-04-26 08:20:53 --> Config Class Initialized
INFO - 2023-04-26 08:20:53 --> Loader Class Initialized
INFO - 2023-04-26 08:20:53 --> Helper loaded: url_helper
INFO - 2023-04-26 08:20:53 --> Helper loaded: file_helper
INFO - 2023-04-26 08:20:53 --> Helper loaded: form_helper
INFO - 2023-04-26 08:20:53 --> Helper loaded: my_helper
INFO - 2023-04-26 08:20:53 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:20:54 --> Controller Class Initialized
DEBUG - 2023-04-26 08:20:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-04-26 08:20:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 08:20:54 --> Final output sent to browser
DEBUG - 2023-04-26 08:20:54 --> Total execution time: 0.0839
INFO - 2023-04-26 08:20:58 --> Config Class Initialized
INFO - 2023-04-26 08:20:58 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:20:58 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:20:58 --> Utf8 Class Initialized
INFO - 2023-04-26 08:20:58 --> URI Class Initialized
INFO - 2023-04-26 08:20:58 --> Router Class Initialized
INFO - 2023-04-26 08:20:58 --> Output Class Initialized
INFO - 2023-04-26 08:20:58 --> Security Class Initialized
DEBUG - 2023-04-26 08:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:20:58 --> Input Class Initialized
INFO - 2023-04-26 08:20:58 --> Language Class Initialized
INFO - 2023-04-26 08:20:58 --> Language Class Initialized
INFO - 2023-04-26 08:20:58 --> Config Class Initialized
INFO - 2023-04-26 08:20:58 --> Loader Class Initialized
INFO - 2023-04-26 08:20:58 --> Helper loaded: url_helper
INFO - 2023-04-26 08:20:58 --> Helper loaded: file_helper
INFO - 2023-04-26 08:20:58 --> Helper loaded: form_helper
INFO - 2023-04-26 08:20:58 --> Helper loaded: my_helper
INFO - 2023-04-26 08:20:58 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:20:58 --> Controller Class Initialized
DEBUG - 2023-04-26 08:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-26 08:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 08:20:58 --> Final output sent to browser
DEBUG - 2023-04-26 08:20:58 --> Total execution time: 0.0577
INFO - 2023-04-26 08:21:20 --> Config Class Initialized
INFO - 2023-04-26 08:21:20 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:21:20 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:21:20 --> Utf8 Class Initialized
INFO - 2023-04-26 08:21:20 --> URI Class Initialized
INFO - 2023-04-26 08:21:20 --> Router Class Initialized
INFO - 2023-04-26 08:21:20 --> Output Class Initialized
INFO - 2023-04-26 08:21:20 --> Security Class Initialized
DEBUG - 2023-04-26 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:21:20 --> Input Class Initialized
INFO - 2023-04-26 08:21:20 --> Language Class Initialized
INFO - 2023-04-26 08:21:20 --> Language Class Initialized
INFO - 2023-04-26 08:21:20 --> Config Class Initialized
INFO - 2023-04-26 08:21:20 --> Loader Class Initialized
INFO - 2023-04-26 08:21:20 --> Helper loaded: url_helper
INFO - 2023-04-26 08:21:20 --> Helper loaded: file_helper
INFO - 2023-04-26 08:21:20 --> Helper loaded: form_helper
INFO - 2023-04-26 08:21:20 --> Helper loaded: my_helper
INFO - 2023-04-26 08:21:20 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:21:20 --> Controller Class Initialized
DEBUG - 2023-04-26 08:21:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-26 08:21:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 08:21:20 --> Final output sent to browser
DEBUG - 2023-04-26 08:21:20 --> Total execution time: 0.0334
INFO - 2023-04-26 08:21:22 --> Config Class Initialized
INFO - 2023-04-26 08:21:22 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:21:22 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:21:22 --> Utf8 Class Initialized
INFO - 2023-04-26 08:21:22 --> URI Class Initialized
INFO - 2023-04-26 08:21:22 --> Router Class Initialized
INFO - 2023-04-26 08:21:22 --> Output Class Initialized
INFO - 2023-04-26 08:21:22 --> Security Class Initialized
DEBUG - 2023-04-26 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:21:22 --> Input Class Initialized
INFO - 2023-04-26 08:21:22 --> Language Class Initialized
INFO - 2023-04-26 08:21:22 --> Language Class Initialized
INFO - 2023-04-26 08:21:22 --> Config Class Initialized
INFO - 2023-04-26 08:21:22 --> Loader Class Initialized
INFO - 2023-04-26 08:21:22 --> Helper loaded: url_helper
INFO - 2023-04-26 08:21:22 --> Helper loaded: file_helper
INFO - 2023-04-26 08:21:22 --> Helper loaded: form_helper
INFO - 2023-04-26 08:21:22 --> Helper loaded: my_helper
INFO - 2023-04-26 08:21:22 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:21:22 --> Controller Class Initialized
DEBUG - 2023-04-26 08:21:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-26 08:21:23 --> Final output sent to browser
DEBUG - 2023-04-26 08:21:23 --> Total execution time: 1.1423
INFO - 2023-04-26 08:22:25 --> Config Class Initialized
INFO - 2023-04-26 08:22:25 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:22:25 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:22:25 --> Utf8 Class Initialized
INFO - 2023-04-26 08:22:25 --> URI Class Initialized
INFO - 2023-04-26 08:22:25 --> Router Class Initialized
INFO - 2023-04-26 08:22:25 --> Output Class Initialized
INFO - 2023-04-26 08:22:25 --> Security Class Initialized
DEBUG - 2023-04-26 08:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:22:25 --> Input Class Initialized
INFO - 2023-04-26 08:22:25 --> Language Class Initialized
INFO - 2023-04-26 08:22:25 --> Language Class Initialized
INFO - 2023-04-26 08:22:25 --> Config Class Initialized
INFO - 2023-04-26 08:22:25 --> Loader Class Initialized
INFO - 2023-04-26 08:22:25 --> Helper loaded: url_helper
INFO - 2023-04-26 08:22:25 --> Helper loaded: file_helper
INFO - 2023-04-26 08:22:25 --> Helper loaded: form_helper
INFO - 2023-04-26 08:22:25 --> Helper loaded: my_helper
INFO - 2023-04-26 08:22:25 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:22:25 --> Controller Class Initialized
DEBUG - 2023-04-26 08:22:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-26 08:22:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-26 08:22:25 --> Final output sent to browser
DEBUG - 2023-04-26 08:22:25 --> Total execution time: 0.0268
INFO - 2023-04-26 08:23:30 --> Config Class Initialized
INFO - 2023-04-26 08:23:30 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:23:30 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:23:30 --> Utf8 Class Initialized
INFO - 2023-04-26 08:23:30 --> URI Class Initialized
INFO - 2023-04-26 08:23:30 --> Router Class Initialized
INFO - 2023-04-26 08:23:30 --> Output Class Initialized
INFO - 2023-04-26 08:23:30 --> Security Class Initialized
DEBUG - 2023-04-26 08:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:23:30 --> Input Class Initialized
INFO - 2023-04-26 08:23:30 --> Language Class Initialized
INFO - 2023-04-26 08:23:30 --> Language Class Initialized
INFO - 2023-04-26 08:23:30 --> Config Class Initialized
INFO - 2023-04-26 08:23:30 --> Loader Class Initialized
INFO - 2023-04-26 08:23:30 --> Helper loaded: url_helper
INFO - 2023-04-26 08:23:30 --> Helper loaded: file_helper
INFO - 2023-04-26 08:23:30 --> Helper loaded: form_helper
INFO - 2023-04-26 08:23:30 --> Helper loaded: my_helper
INFO - 2023-04-26 08:23:30 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:23:30 --> Controller Class Initialized
DEBUG - 2023-04-26 08:23:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-26 08:23:31 --> Final output sent to browser
DEBUG - 2023-04-26 08:23:31 --> Total execution time: 1.1359
INFO - 2023-04-26 08:24:04 --> Config Class Initialized
INFO - 2023-04-26 08:24:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:24:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:24:04 --> Utf8 Class Initialized
INFO - 2023-04-26 08:24:04 --> URI Class Initialized
INFO - 2023-04-26 08:24:04 --> Router Class Initialized
INFO - 2023-04-26 08:24:04 --> Output Class Initialized
INFO - 2023-04-26 08:24:04 --> Security Class Initialized
DEBUG - 2023-04-26 08:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:24:04 --> Input Class Initialized
INFO - 2023-04-26 08:24:04 --> Language Class Initialized
INFO - 2023-04-26 08:24:04 --> Language Class Initialized
INFO - 2023-04-26 08:24:04 --> Config Class Initialized
INFO - 2023-04-26 08:24:04 --> Loader Class Initialized
INFO - 2023-04-26 08:24:04 --> Helper loaded: url_helper
INFO - 2023-04-26 08:24:04 --> Helper loaded: file_helper
INFO - 2023-04-26 08:24:04 --> Helper loaded: form_helper
INFO - 2023-04-26 08:24:04 --> Helper loaded: my_helper
INFO - 2023-04-26 08:24:04 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:24:04 --> Controller Class Initialized
DEBUG - 2023-04-26 08:24:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-26 08:24:05 --> Final output sent to browser
DEBUG - 2023-04-26 08:24:05 --> Total execution time: 1.1544
INFO - 2023-04-26 08:24:50 --> Config Class Initialized
INFO - 2023-04-26 08:24:50 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:24:50 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:24:50 --> Utf8 Class Initialized
INFO - 2023-04-26 08:24:50 --> URI Class Initialized
INFO - 2023-04-26 08:24:50 --> Router Class Initialized
INFO - 2023-04-26 08:24:50 --> Output Class Initialized
INFO - 2023-04-26 08:24:50 --> Security Class Initialized
DEBUG - 2023-04-26 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:24:50 --> Input Class Initialized
INFO - 2023-04-26 08:24:50 --> Language Class Initialized
INFO - 2023-04-26 08:24:50 --> Language Class Initialized
INFO - 2023-04-26 08:24:50 --> Config Class Initialized
INFO - 2023-04-26 08:24:50 --> Loader Class Initialized
INFO - 2023-04-26 08:24:50 --> Helper loaded: url_helper
INFO - 2023-04-26 08:24:50 --> Helper loaded: file_helper
INFO - 2023-04-26 08:24:50 --> Helper loaded: form_helper
INFO - 2023-04-26 08:24:50 --> Helper loaded: my_helper
INFO - 2023-04-26 08:24:50 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:24:50 --> Controller Class Initialized
DEBUG - 2023-04-26 08:24:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-04-26 08:24:51 --> Final output sent to browser
DEBUG - 2023-04-26 08:24:51 --> Total execution time: 1.1015
INFO - 2023-04-26 08:42:01 --> Config Class Initialized
INFO - 2023-04-26 08:42:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:42:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:42:01 --> Utf8 Class Initialized
INFO - 2023-04-26 08:42:01 --> URI Class Initialized
INFO - 2023-04-26 08:42:01 --> Router Class Initialized
INFO - 2023-04-26 08:42:01 --> Output Class Initialized
INFO - 2023-04-26 08:42:01 --> Security Class Initialized
DEBUG - 2023-04-26 08:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:42:01 --> Input Class Initialized
INFO - 2023-04-26 08:42:01 --> Language Class Initialized
INFO - 2023-04-26 08:42:01 --> Language Class Initialized
INFO - 2023-04-26 08:42:01 --> Config Class Initialized
INFO - 2023-04-26 08:42:01 --> Loader Class Initialized
INFO - 2023-04-26 08:42:01 --> Helper loaded: url_helper
INFO - 2023-04-26 08:42:01 --> Helper loaded: file_helper
INFO - 2023-04-26 08:42:01 --> Helper loaded: form_helper
INFO - 2023-04-26 08:42:01 --> Helper loaded: my_helper
INFO - 2023-04-26 08:42:01 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:42:01 --> Controller Class Initialized
DEBUG - 2023-04-26 08:42:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:42:02 --> Final output sent to browser
DEBUG - 2023-04-26 08:42:02 --> Total execution time: 0.9719
INFO - 2023-04-26 08:42:43 --> Config Class Initialized
INFO - 2023-04-26 08:42:43 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:42:43 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:42:43 --> Utf8 Class Initialized
INFO - 2023-04-26 08:42:43 --> URI Class Initialized
INFO - 2023-04-26 08:42:43 --> Router Class Initialized
INFO - 2023-04-26 08:42:43 --> Output Class Initialized
INFO - 2023-04-26 08:42:43 --> Security Class Initialized
DEBUG - 2023-04-26 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:42:43 --> Input Class Initialized
INFO - 2023-04-26 08:42:43 --> Language Class Initialized
INFO - 2023-04-26 08:42:43 --> Language Class Initialized
INFO - 2023-04-26 08:42:43 --> Config Class Initialized
INFO - 2023-04-26 08:42:43 --> Loader Class Initialized
INFO - 2023-04-26 08:42:43 --> Helper loaded: url_helper
INFO - 2023-04-26 08:42:43 --> Helper loaded: file_helper
INFO - 2023-04-26 08:42:43 --> Helper loaded: form_helper
INFO - 2023-04-26 08:42:43 --> Helper loaded: my_helper
INFO - 2023-04-26 08:42:43 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:42:43 --> Controller Class Initialized
DEBUG - 2023-04-26 08:42:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:42:44 --> Final output sent to browser
DEBUG - 2023-04-26 08:42:44 --> Total execution time: 0.9126
INFO - 2023-04-26 08:43:29 --> Config Class Initialized
INFO - 2023-04-26 08:43:29 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:43:29 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:43:29 --> Utf8 Class Initialized
INFO - 2023-04-26 08:43:29 --> URI Class Initialized
INFO - 2023-04-26 08:43:29 --> Router Class Initialized
INFO - 2023-04-26 08:43:29 --> Output Class Initialized
INFO - 2023-04-26 08:43:29 --> Security Class Initialized
DEBUG - 2023-04-26 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:43:29 --> Input Class Initialized
INFO - 2023-04-26 08:43:29 --> Language Class Initialized
INFO - 2023-04-26 08:43:29 --> Language Class Initialized
INFO - 2023-04-26 08:43:29 --> Config Class Initialized
INFO - 2023-04-26 08:43:29 --> Loader Class Initialized
INFO - 2023-04-26 08:43:29 --> Helper loaded: url_helper
INFO - 2023-04-26 08:43:29 --> Helper loaded: file_helper
INFO - 2023-04-26 08:43:29 --> Helper loaded: form_helper
INFO - 2023-04-26 08:43:29 --> Helper loaded: my_helper
INFO - 2023-04-26 08:43:29 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:43:29 --> Controller Class Initialized
DEBUG - 2023-04-26 08:43:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:43:30 --> Final output sent to browser
DEBUG - 2023-04-26 08:43:30 --> Total execution time: 0.9662
INFO - 2023-04-26 08:43:41 --> Config Class Initialized
INFO - 2023-04-26 08:43:41 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:43:41 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:43:41 --> Utf8 Class Initialized
INFO - 2023-04-26 08:43:41 --> URI Class Initialized
INFO - 2023-04-26 08:43:41 --> Router Class Initialized
INFO - 2023-04-26 08:43:41 --> Output Class Initialized
INFO - 2023-04-26 08:43:41 --> Security Class Initialized
DEBUG - 2023-04-26 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:43:41 --> Input Class Initialized
INFO - 2023-04-26 08:43:41 --> Language Class Initialized
INFO - 2023-04-26 08:43:41 --> Language Class Initialized
INFO - 2023-04-26 08:43:41 --> Config Class Initialized
INFO - 2023-04-26 08:43:41 --> Loader Class Initialized
INFO - 2023-04-26 08:43:41 --> Helper loaded: url_helper
INFO - 2023-04-26 08:43:41 --> Helper loaded: file_helper
INFO - 2023-04-26 08:43:41 --> Helper loaded: form_helper
INFO - 2023-04-26 08:43:41 --> Helper loaded: my_helper
INFO - 2023-04-26 08:43:41 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:43:41 --> Controller Class Initialized
DEBUG - 2023-04-26 08:43:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:43:41 --> Final output sent to browser
DEBUG - 2023-04-26 08:43:41 --> Total execution time: 0.9353
INFO - 2023-04-26 08:43:55 --> Config Class Initialized
INFO - 2023-04-26 08:43:55 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:43:55 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:43:55 --> Utf8 Class Initialized
INFO - 2023-04-26 08:43:55 --> URI Class Initialized
INFO - 2023-04-26 08:43:55 --> Router Class Initialized
INFO - 2023-04-26 08:43:55 --> Output Class Initialized
INFO - 2023-04-26 08:43:55 --> Security Class Initialized
DEBUG - 2023-04-26 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:43:55 --> Input Class Initialized
INFO - 2023-04-26 08:43:55 --> Language Class Initialized
INFO - 2023-04-26 08:43:55 --> Language Class Initialized
INFO - 2023-04-26 08:43:55 --> Config Class Initialized
INFO - 2023-04-26 08:43:55 --> Loader Class Initialized
INFO - 2023-04-26 08:43:55 --> Helper loaded: url_helper
INFO - 2023-04-26 08:43:55 --> Helper loaded: file_helper
INFO - 2023-04-26 08:43:55 --> Helper loaded: form_helper
INFO - 2023-04-26 08:43:55 --> Helper loaded: my_helper
INFO - 2023-04-26 08:43:55 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:43:55 --> Controller Class Initialized
DEBUG - 2023-04-26 08:43:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:43:56 --> Final output sent to browser
DEBUG - 2023-04-26 08:43:56 --> Total execution time: 0.9695
INFO - 2023-04-26 08:44:17 --> Config Class Initialized
INFO - 2023-04-26 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:44:17 --> Utf8 Class Initialized
INFO - 2023-04-26 08:44:17 --> URI Class Initialized
INFO - 2023-04-26 08:44:17 --> Router Class Initialized
INFO - 2023-04-26 08:44:17 --> Output Class Initialized
INFO - 2023-04-26 08:44:17 --> Security Class Initialized
DEBUG - 2023-04-26 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:44:17 --> Input Class Initialized
INFO - 2023-04-26 08:44:17 --> Language Class Initialized
INFO - 2023-04-26 08:44:17 --> Language Class Initialized
INFO - 2023-04-26 08:44:17 --> Config Class Initialized
INFO - 2023-04-26 08:44:17 --> Loader Class Initialized
INFO - 2023-04-26 08:44:17 --> Helper loaded: url_helper
INFO - 2023-04-26 08:44:17 --> Helper loaded: file_helper
INFO - 2023-04-26 08:44:17 --> Helper loaded: form_helper
INFO - 2023-04-26 08:44:17 --> Helper loaded: my_helper
INFO - 2023-04-26 08:44:17 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:44:17 --> Controller Class Initialized
DEBUG - 2023-04-26 08:44:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:44:18 --> Final output sent to browser
DEBUG - 2023-04-26 08:44:18 --> Total execution time: 0.9548
INFO - 2023-04-26 08:46:09 --> Config Class Initialized
INFO - 2023-04-26 08:46:09 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:46:09 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:46:09 --> Utf8 Class Initialized
INFO - 2023-04-26 08:46:09 --> URI Class Initialized
INFO - 2023-04-26 08:46:09 --> Router Class Initialized
INFO - 2023-04-26 08:46:09 --> Output Class Initialized
INFO - 2023-04-26 08:46:09 --> Security Class Initialized
DEBUG - 2023-04-26 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:46:09 --> Input Class Initialized
INFO - 2023-04-26 08:46:09 --> Language Class Initialized
INFO - 2023-04-26 08:46:09 --> Language Class Initialized
INFO - 2023-04-26 08:46:09 --> Config Class Initialized
INFO - 2023-04-26 08:46:09 --> Loader Class Initialized
INFO - 2023-04-26 08:46:09 --> Helper loaded: url_helper
INFO - 2023-04-26 08:46:09 --> Helper loaded: file_helper
INFO - 2023-04-26 08:46:09 --> Helper loaded: form_helper
INFO - 2023-04-26 08:46:09 --> Helper loaded: my_helper
INFO - 2023-04-26 08:46:09 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:46:09 --> Controller Class Initialized
DEBUG - 2023-04-26 08:46:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:46:10 --> Final output sent to browser
DEBUG - 2023-04-26 08:46:10 --> Total execution time: 0.9336
INFO - 2023-04-26 08:47:21 --> Config Class Initialized
INFO - 2023-04-26 08:47:21 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:47:21 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:47:21 --> Utf8 Class Initialized
INFO - 2023-04-26 08:47:21 --> URI Class Initialized
INFO - 2023-04-26 08:47:21 --> Router Class Initialized
INFO - 2023-04-26 08:47:21 --> Output Class Initialized
INFO - 2023-04-26 08:47:21 --> Security Class Initialized
DEBUG - 2023-04-26 08:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:47:21 --> Input Class Initialized
INFO - 2023-04-26 08:47:21 --> Language Class Initialized
INFO - 2023-04-26 08:47:21 --> Language Class Initialized
INFO - 2023-04-26 08:47:21 --> Config Class Initialized
INFO - 2023-04-26 08:47:21 --> Loader Class Initialized
INFO - 2023-04-26 08:47:21 --> Helper loaded: url_helper
INFO - 2023-04-26 08:47:21 --> Helper loaded: file_helper
INFO - 2023-04-26 08:47:21 --> Helper loaded: form_helper
INFO - 2023-04-26 08:47:21 --> Helper loaded: my_helper
INFO - 2023-04-26 08:47:21 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:47:21 --> Controller Class Initialized
DEBUG - 2023-04-26 08:47:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:47:22 --> Final output sent to browser
DEBUG - 2023-04-26 08:47:22 --> Total execution time: 0.9126
INFO - 2023-04-26 08:49:01 --> Config Class Initialized
INFO - 2023-04-26 08:49:01 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:49:01 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:49:01 --> Utf8 Class Initialized
INFO - 2023-04-26 08:49:01 --> URI Class Initialized
INFO - 2023-04-26 08:49:01 --> Router Class Initialized
INFO - 2023-04-26 08:49:01 --> Output Class Initialized
INFO - 2023-04-26 08:49:01 --> Security Class Initialized
DEBUG - 2023-04-26 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:49:01 --> Input Class Initialized
INFO - 2023-04-26 08:49:01 --> Language Class Initialized
INFO - 2023-04-26 08:49:01 --> Language Class Initialized
INFO - 2023-04-26 08:49:01 --> Config Class Initialized
INFO - 2023-04-26 08:49:01 --> Loader Class Initialized
INFO - 2023-04-26 08:49:01 --> Helper loaded: url_helper
INFO - 2023-04-26 08:49:01 --> Helper loaded: file_helper
INFO - 2023-04-26 08:49:01 --> Helper loaded: form_helper
INFO - 2023-04-26 08:49:01 --> Helper loaded: my_helper
INFO - 2023-04-26 08:49:01 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:49:01 --> Controller Class Initialized
DEBUG - 2023-04-26 08:49:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:49:02 --> Final output sent to browser
DEBUG - 2023-04-26 08:49:02 --> Total execution time: 0.9429
INFO - 2023-04-26 08:49:37 --> Config Class Initialized
INFO - 2023-04-26 08:49:37 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:49:37 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:49:37 --> Utf8 Class Initialized
INFO - 2023-04-26 08:49:37 --> URI Class Initialized
INFO - 2023-04-26 08:49:37 --> Router Class Initialized
INFO - 2023-04-26 08:49:37 --> Output Class Initialized
INFO - 2023-04-26 08:49:37 --> Security Class Initialized
DEBUG - 2023-04-26 08:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:49:37 --> Input Class Initialized
INFO - 2023-04-26 08:49:37 --> Language Class Initialized
INFO - 2023-04-26 08:49:37 --> Language Class Initialized
INFO - 2023-04-26 08:49:37 --> Config Class Initialized
INFO - 2023-04-26 08:49:37 --> Loader Class Initialized
INFO - 2023-04-26 08:49:37 --> Helper loaded: url_helper
INFO - 2023-04-26 08:49:37 --> Helper loaded: file_helper
INFO - 2023-04-26 08:49:37 --> Helper loaded: form_helper
INFO - 2023-04-26 08:49:37 --> Helper loaded: my_helper
INFO - 2023-04-26 08:49:37 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:49:37 --> Controller Class Initialized
DEBUG - 2023-04-26 08:49:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:49:38 --> Final output sent to browser
DEBUG - 2023-04-26 08:49:38 --> Total execution time: 0.9942
INFO - 2023-04-26 08:50:05 --> Config Class Initialized
INFO - 2023-04-26 08:50:05 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:50:05 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:50:05 --> Utf8 Class Initialized
INFO - 2023-04-26 08:50:05 --> URI Class Initialized
INFO - 2023-04-26 08:50:05 --> Router Class Initialized
INFO - 2023-04-26 08:50:05 --> Output Class Initialized
INFO - 2023-04-26 08:50:05 --> Security Class Initialized
DEBUG - 2023-04-26 08:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:50:05 --> Input Class Initialized
INFO - 2023-04-26 08:50:05 --> Language Class Initialized
INFO - 2023-04-26 08:50:06 --> Language Class Initialized
INFO - 2023-04-26 08:50:06 --> Config Class Initialized
INFO - 2023-04-26 08:50:06 --> Loader Class Initialized
INFO - 2023-04-26 08:50:06 --> Helper loaded: url_helper
INFO - 2023-04-26 08:50:06 --> Helper loaded: file_helper
INFO - 2023-04-26 08:50:06 --> Helper loaded: form_helper
INFO - 2023-04-26 08:50:06 --> Helper loaded: my_helper
INFO - 2023-04-26 08:50:06 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:50:06 --> Controller Class Initialized
DEBUG - 2023-04-26 08:50:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:50:06 --> Final output sent to browser
DEBUG - 2023-04-26 08:50:06 --> Total execution time: 0.9144
INFO - 2023-04-26 08:50:49 --> Config Class Initialized
INFO - 2023-04-26 08:50:49 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:50:49 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:50:49 --> Utf8 Class Initialized
INFO - 2023-04-26 08:50:49 --> URI Class Initialized
INFO - 2023-04-26 08:50:49 --> Router Class Initialized
INFO - 2023-04-26 08:50:49 --> Output Class Initialized
INFO - 2023-04-26 08:50:49 --> Security Class Initialized
DEBUG - 2023-04-26 08:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:50:49 --> Input Class Initialized
INFO - 2023-04-26 08:50:49 --> Language Class Initialized
INFO - 2023-04-26 08:50:49 --> Language Class Initialized
INFO - 2023-04-26 08:50:49 --> Config Class Initialized
INFO - 2023-04-26 08:50:49 --> Loader Class Initialized
INFO - 2023-04-26 08:50:49 --> Helper loaded: url_helper
INFO - 2023-04-26 08:50:49 --> Helper loaded: file_helper
INFO - 2023-04-26 08:50:49 --> Helper loaded: form_helper
INFO - 2023-04-26 08:50:49 --> Helper loaded: my_helper
INFO - 2023-04-26 08:50:49 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:50:49 --> Controller Class Initialized
DEBUG - 2023-04-26 08:50:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:50:50 --> Final output sent to browser
DEBUG - 2023-04-26 08:50:50 --> Total execution time: 0.8503
INFO - 2023-04-26 08:51:15 --> Config Class Initialized
INFO - 2023-04-26 08:51:15 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:51:15 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:51:15 --> Utf8 Class Initialized
INFO - 2023-04-26 08:51:15 --> URI Class Initialized
INFO - 2023-04-26 08:51:15 --> Router Class Initialized
INFO - 2023-04-26 08:51:15 --> Output Class Initialized
INFO - 2023-04-26 08:51:15 --> Security Class Initialized
DEBUG - 2023-04-26 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:51:15 --> Input Class Initialized
INFO - 2023-04-26 08:51:15 --> Language Class Initialized
INFO - 2023-04-26 08:51:15 --> Language Class Initialized
INFO - 2023-04-26 08:51:15 --> Config Class Initialized
INFO - 2023-04-26 08:51:15 --> Loader Class Initialized
INFO - 2023-04-26 08:51:15 --> Helper loaded: url_helper
INFO - 2023-04-26 08:51:15 --> Helper loaded: file_helper
INFO - 2023-04-26 08:51:15 --> Helper loaded: form_helper
INFO - 2023-04-26 08:51:15 --> Helper loaded: my_helper
INFO - 2023-04-26 08:51:15 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:51:15 --> Controller Class Initialized
DEBUG - 2023-04-26 08:51:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:51:16 --> Final output sent to browser
DEBUG - 2023-04-26 08:51:16 --> Total execution time: 1.0029
INFO - 2023-04-26 08:51:42 --> Config Class Initialized
INFO - 2023-04-26 08:51:42 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:51:42 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:51:42 --> Utf8 Class Initialized
INFO - 2023-04-26 08:51:42 --> URI Class Initialized
INFO - 2023-04-26 08:51:42 --> Router Class Initialized
INFO - 2023-04-26 08:51:42 --> Output Class Initialized
INFO - 2023-04-26 08:51:42 --> Security Class Initialized
DEBUG - 2023-04-26 08:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:51:42 --> Input Class Initialized
INFO - 2023-04-26 08:51:42 --> Language Class Initialized
INFO - 2023-04-26 08:51:42 --> Language Class Initialized
INFO - 2023-04-26 08:51:42 --> Config Class Initialized
INFO - 2023-04-26 08:51:42 --> Loader Class Initialized
INFO - 2023-04-26 08:51:42 --> Helper loaded: url_helper
INFO - 2023-04-26 08:51:42 --> Helper loaded: file_helper
INFO - 2023-04-26 08:51:42 --> Helper loaded: form_helper
INFO - 2023-04-26 08:51:42 --> Helper loaded: my_helper
INFO - 2023-04-26 08:51:42 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:51:42 --> Controller Class Initialized
DEBUG - 2023-04-26 08:51:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:51:43 --> Final output sent to browser
DEBUG - 2023-04-26 08:51:43 --> Total execution time: 0.9136
INFO - 2023-04-26 08:52:27 --> Config Class Initialized
INFO - 2023-04-26 08:52:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:52:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:52:27 --> Utf8 Class Initialized
INFO - 2023-04-26 08:52:27 --> URI Class Initialized
INFO - 2023-04-26 08:52:27 --> Router Class Initialized
INFO - 2023-04-26 08:52:27 --> Output Class Initialized
INFO - 2023-04-26 08:52:27 --> Security Class Initialized
DEBUG - 2023-04-26 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:52:27 --> Input Class Initialized
INFO - 2023-04-26 08:52:27 --> Language Class Initialized
INFO - 2023-04-26 08:52:27 --> Language Class Initialized
INFO - 2023-04-26 08:52:27 --> Config Class Initialized
INFO - 2023-04-26 08:52:27 --> Loader Class Initialized
INFO - 2023-04-26 08:52:27 --> Helper loaded: url_helper
INFO - 2023-04-26 08:52:27 --> Helper loaded: file_helper
INFO - 2023-04-26 08:52:27 --> Helper loaded: form_helper
INFO - 2023-04-26 08:52:27 --> Helper loaded: my_helper
INFO - 2023-04-26 08:52:27 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:52:27 --> Controller Class Initialized
DEBUG - 2023-04-26 08:52:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:52:28 --> Final output sent to browser
DEBUG - 2023-04-26 08:52:28 --> Total execution time: 0.9998
INFO - 2023-04-26 08:52:47 --> Config Class Initialized
INFO - 2023-04-26 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:52:47 --> Utf8 Class Initialized
INFO - 2023-04-26 08:52:47 --> URI Class Initialized
INFO - 2023-04-26 08:52:47 --> Router Class Initialized
INFO - 2023-04-26 08:52:47 --> Output Class Initialized
INFO - 2023-04-26 08:52:47 --> Security Class Initialized
DEBUG - 2023-04-26 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:52:47 --> Input Class Initialized
INFO - 2023-04-26 08:52:47 --> Language Class Initialized
INFO - 2023-04-26 08:52:47 --> Language Class Initialized
INFO - 2023-04-26 08:52:47 --> Config Class Initialized
INFO - 2023-04-26 08:52:47 --> Loader Class Initialized
INFO - 2023-04-26 08:52:47 --> Helper loaded: url_helper
INFO - 2023-04-26 08:52:47 --> Helper loaded: file_helper
INFO - 2023-04-26 08:52:47 --> Helper loaded: form_helper
INFO - 2023-04-26 08:52:47 --> Helper loaded: my_helper
INFO - 2023-04-26 08:52:47 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:52:47 --> Controller Class Initialized
DEBUG - 2023-04-26 08:52:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:52:48 --> Final output sent to browser
DEBUG - 2023-04-26 08:52:48 --> Total execution time: 0.9082
INFO - 2023-04-26 08:53:03 --> Config Class Initialized
INFO - 2023-04-26 08:53:03 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:53:03 --> Utf8 Class Initialized
INFO - 2023-04-26 08:53:03 --> URI Class Initialized
INFO - 2023-04-26 08:53:03 --> Router Class Initialized
INFO - 2023-04-26 08:53:03 --> Output Class Initialized
INFO - 2023-04-26 08:53:03 --> Security Class Initialized
DEBUG - 2023-04-26 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:53:03 --> Input Class Initialized
INFO - 2023-04-26 08:53:03 --> Language Class Initialized
INFO - 2023-04-26 08:53:03 --> Language Class Initialized
INFO - 2023-04-26 08:53:03 --> Config Class Initialized
INFO - 2023-04-26 08:53:03 --> Loader Class Initialized
INFO - 2023-04-26 08:53:03 --> Helper loaded: url_helper
INFO - 2023-04-26 08:53:03 --> Helper loaded: file_helper
INFO - 2023-04-26 08:53:03 --> Helper loaded: form_helper
INFO - 2023-04-26 08:53:03 --> Helper loaded: my_helper
INFO - 2023-04-26 08:53:03 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:53:03 --> Controller Class Initialized
DEBUG - 2023-04-26 08:53:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:53:04 --> Final output sent to browser
DEBUG - 2023-04-26 08:53:04 --> Total execution time: 0.8661
INFO - 2023-04-26 08:53:27 --> Config Class Initialized
INFO - 2023-04-26 08:53:27 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:53:27 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:53:27 --> Utf8 Class Initialized
INFO - 2023-04-26 08:53:27 --> URI Class Initialized
INFO - 2023-04-26 08:53:27 --> Router Class Initialized
INFO - 2023-04-26 08:53:27 --> Output Class Initialized
INFO - 2023-04-26 08:53:27 --> Security Class Initialized
DEBUG - 2023-04-26 08:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:53:27 --> Input Class Initialized
INFO - 2023-04-26 08:53:27 --> Language Class Initialized
INFO - 2023-04-26 08:53:27 --> Language Class Initialized
INFO - 2023-04-26 08:53:27 --> Config Class Initialized
INFO - 2023-04-26 08:53:27 --> Loader Class Initialized
INFO - 2023-04-26 08:53:27 --> Helper loaded: url_helper
INFO - 2023-04-26 08:53:27 --> Helper loaded: file_helper
INFO - 2023-04-26 08:53:27 --> Helper loaded: form_helper
INFO - 2023-04-26 08:53:27 --> Helper loaded: my_helper
INFO - 2023-04-26 08:53:27 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:53:27 --> Controller Class Initialized
DEBUG - 2023-04-26 08:53:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:53:28 --> Final output sent to browser
DEBUG - 2023-04-26 08:53:28 --> Total execution time: 0.8638
INFO - 2023-04-26 08:53:43 --> Config Class Initialized
INFO - 2023-04-26 08:53:43 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:53:43 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:53:43 --> Utf8 Class Initialized
INFO - 2023-04-26 08:53:43 --> URI Class Initialized
INFO - 2023-04-26 08:53:43 --> Router Class Initialized
INFO - 2023-04-26 08:53:43 --> Output Class Initialized
INFO - 2023-04-26 08:53:43 --> Security Class Initialized
DEBUG - 2023-04-26 08:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:53:43 --> Input Class Initialized
INFO - 2023-04-26 08:53:43 --> Language Class Initialized
INFO - 2023-04-26 08:53:43 --> Language Class Initialized
INFO - 2023-04-26 08:53:43 --> Config Class Initialized
INFO - 2023-04-26 08:53:43 --> Loader Class Initialized
INFO - 2023-04-26 08:53:43 --> Helper loaded: url_helper
INFO - 2023-04-26 08:53:43 --> Helper loaded: file_helper
INFO - 2023-04-26 08:53:43 --> Helper loaded: form_helper
INFO - 2023-04-26 08:53:43 --> Helper loaded: my_helper
INFO - 2023-04-26 08:53:43 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:53:43 --> Controller Class Initialized
DEBUG - 2023-04-26 08:53:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:53:43 --> Final output sent to browser
DEBUG - 2023-04-26 08:53:43 --> Total execution time: 0.9077
INFO - 2023-04-26 08:55:59 --> Config Class Initialized
INFO - 2023-04-26 08:55:59 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:55:59 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:55:59 --> Utf8 Class Initialized
INFO - 2023-04-26 08:55:59 --> URI Class Initialized
INFO - 2023-04-26 08:55:59 --> Router Class Initialized
INFO - 2023-04-26 08:55:59 --> Output Class Initialized
INFO - 2023-04-26 08:55:59 --> Security Class Initialized
DEBUG - 2023-04-26 08:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:55:59 --> Input Class Initialized
INFO - 2023-04-26 08:55:59 --> Language Class Initialized
INFO - 2023-04-26 08:55:59 --> Language Class Initialized
INFO - 2023-04-26 08:55:59 --> Config Class Initialized
INFO - 2023-04-26 08:55:59 --> Loader Class Initialized
INFO - 2023-04-26 08:55:59 --> Helper loaded: url_helper
INFO - 2023-04-26 08:55:59 --> Helper loaded: file_helper
INFO - 2023-04-26 08:55:59 --> Helper loaded: form_helper
INFO - 2023-04-26 08:55:59 --> Helper loaded: my_helper
INFO - 2023-04-26 08:55:59 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:55:59 --> Controller Class Initialized
DEBUG - 2023-04-26 08:55:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:56:00 --> Final output sent to browser
DEBUG - 2023-04-26 08:56:00 --> Total execution time: 0.9715
INFO - 2023-04-26 08:56:22 --> Config Class Initialized
INFO - 2023-04-26 08:56:22 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:56:22 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:56:22 --> Utf8 Class Initialized
INFO - 2023-04-26 08:56:22 --> URI Class Initialized
INFO - 2023-04-26 08:56:22 --> Router Class Initialized
INFO - 2023-04-26 08:56:22 --> Output Class Initialized
INFO - 2023-04-26 08:56:22 --> Security Class Initialized
DEBUG - 2023-04-26 08:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:56:22 --> Input Class Initialized
INFO - 2023-04-26 08:56:22 --> Language Class Initialized
INFO - 2023-04-26 08:56:22 --> Language Class Initialized
INFO - 2023-04-26 08:56:22 --> Config Class Initialized
INFO - 2023-04-26 08:56:22 --> Loader Class Initialized
INFO - 2023-04-26 08:56:22 --> Helper loaded: url_helper
INFO - 2023-04-26 08:56:22 --> Helper loaded: file_helper
INFO - 2023-04-26 08:56:22 --> Helper loaded: form_helper
INFO - 2023-04-26 08:56:22 --> Helper loaded: my_helper
INFO - 2023-04-26 08:56:22 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:56:22 --> Controller Class Initialized
DEBUG - 2023-04-26 08:56:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:56:23 --> Final output sent to browser
DEBUG - 2023-04-26 08:56:23 --> Total execution time: 0.8375
INFO - 2023-04-26 08:57:53 --> Config Class Initialized
INFO - 2023-04-26 08:57:53 --> Hooks Class Initialized
DEBUG - 2023-04-26 08:57:53 --> UTF-8 Support Enabled
INFO - 2023-04-26 08:57:53 --> Utf8 Class Initialized
INFO - 2023-04-26 08:57:53 --> URI Class Initialized
INFO - 2023-04-26 08:57:53 --> Router Class Initialized
INFO - 2023-04-26 08:57:53 --> Output Class Initialized
INFO - 2023-04-26 08:57:53 --> Security Class Initialized
DEBUG - 2023-04-26 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 08:57:53 --> Input Class Initialized
INFO - 2023-04-26 08:57:53 --> Language Class Initialized
INFO - 2023-04-26 08:57:53 --> Language Class Initialized
INFO - 2023-04-26 08:57:53 --> Config Class Initialized
INFO - 2023-04-26 08:57:53 --> Loader Class Initialized
INFO - 2023-04-26 08:57:53 --> Helper loaded: url_helper
INFO - 2023-04-26 08:57:53 --> Helper loaded: file_helper
INFO - 2023-04-26 08:57:53 --> Helper loaded: form_helper
INFO - 2023-04-26 08:57:53 --> Helper loaded: my_helper
INFO - 2023-04-26 08:57:53 --> Database Driver Class Initialized
DEBUG - 2023-04-26 08:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 08:57:53 --> Controller Class Initialized
DEBUG - 2023-04-26 08:57:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 08:57:54 --> Final output sent to browser
DEBUG - 2023-04-26 08:57:54 --> Total execution time: 0.9173
INFO - 2023-04-26 09:00:04 --> Config Class Initialized
INFO - 2023-04-26 09:00:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:00:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:00:04 --> Utf8 Class Initialized
INFO - 2023-04-26 09:00:04 --> URI Class Initialized
INFO - 2023-04-26 09:00:04 --> Router Class Initialized
INFO - 2023-04-26 09:00:04 --> Output Class Initialized
INFO - 2023-04-26 09:00:04 --> Security Class Initialized
DEBUG - 2023-04-26 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:00:04 --> Input Class Initialized
INFO - 2023-04-26 09:00:04 --> Language Class Initialized
INFO - 2023-04-26 09:00:04 --> Language Class Initialized
INFO - 2023-04-26 09:00:04 --> Config Class Initialized
INFO - 2023-04-26 09:00:04 --> Loader Class Initialized
INFO - 2023-04-26 09:00:04 --> Helper loaded: url_helper
INFO - 2023-04-26 09:00:04 --> Helper loaded: file_helper
INFO - 2023-04-26 09:00:04 --> Helper loaded: form_helper
INFO - 2023-04-26 09:00:04 --> Helper loaded: my_helper
INFO - 2023-04-26 09:00:04 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:00:04 --> Controller Class Initialized
DEBUG - 2023-04-26 09:00:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:00:04 --> Final output sent to browser
DEBUG - 2023-04-26 09:00:04 --> Total execution time: 0.8232
INFO - 2023-04-26 09:00:17 --> Config Class Initialized
INFO - 2023-04-26 09:00:17 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:00:17 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:00:17 --> Utf8 Class Initialized
INFO - 2023-04-26 09:00:17 --> URI Class Initialized
INFO - 2023-04-26 09:00:17 --> Router Class Initialized
INFO - 2023-04-26 09:00:17 --> Output Class Initialized
INFO - 2023-04-26 09:00:17 --> Security Class Initialized
DEBUG - 2023-04-26 09:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:00:17 --> Input Class Initialized
INFO - 2023-04-26 09:00:17 --> Language Class Initialized
INFO - 2023-04-26 09:00:17 --> Language Class Initialized
INFO - 2023-04-26 09:00:17 --> Config Class Initialized
INFO - 2023-04-26 09:00:17 --> Loader Class Initialized
INFO - 2023-04-26 09:00:17 --> Helper loaded: url_helper
INFO - 2023-04-26 09:00:17 --> Helper loaded: file_helper
INFO - 2023-04-26 09:00:17 --> Helper loaded: form_helper
INFO - 2023-04-26 09:00:17 --> Helper loaded: my_helper
INFO - 2023-04-26 09:00:17 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:00:17 --> Controller Class Initialized
DEBUG - 2023-04-26 09:00:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:00:18 --> Final output sent to browser
DEBUG - 2023-04-26 09:00:18 --> Total execution time: 0.8467
INFO - 2023-04-26 09:00:26 --> Config Class Initialized
INFO - 2023-04-26 09:00:26 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:00:26 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:00:26 --> Utf8 Class Initialized
INFO - 2023-04-26 09:00:26 --> URI Class Initialized
INFO - 2023-04-26 09:00:26 --> Router Class Initialized
INFO - 2023-04-26 09:00:26 --> Output Class Initialized
INFO - 2023-04-26 09:00:26 --> Security Class Initialized
DEBUG - 2023-04-26 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:00:26 --> Input Class Initialized
INFO - 2023-04-26 09:00:26 --> Language Class Initialized
INFO - 2023-04-26 09:00:26 --> Language Class Initialized
INFO - 2023-04-26 09:00:26 --> Config Class Initialized
INFO - 2023-04-26 09:00:26 --> Loader Class Initialized
INFO - 2023-04-26 09:00:26 --> Helper loaded: url_helper
INFO - 2023-04-26 09:00:26 --> Helper loaded: file_helper
INFO - 2023-04-26 09:00:26 --> Helper loaded: form_helper
INFO - 2023-04-26 09:00:26 --> Helper loaded: my_helper
INFO - 2023-04-26 09:00:26 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:00:26 --> Controller Class Initialized
DEBUG - 2023-04-26 09:00:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:00:27 --> Final output sent to browser
DEBUG - 2023-04-26 09:00:27 --> Total execution time: 0.9320
INFO - 2023-04-26 09:00:37 --> Config Class Initialized
INFO - 2023-04-26 09:00:37 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:00:37 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:00:37 --> Utf8 Class Initialized
INFO - 2023-04-26 09:00:37 --> URI Class Initialized
INFO - 2023-04-26 09:00:37 --> Router Class Initialized
INFO - 2023-04-26 09:00:37 --> Output Class Initialized
INFO - 2023-04-26 09:00:37 --> Security Class Initialized
DEBUG - 2023-04-26 09:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:00:37 --> Input Class Initialized
INFO - 2023-04-26 09:00:37 --> Language Class Initialized
INFO - 2023-04-26 09:00:37 --> Language Class Initialized
INFO - 2023-04-26 09:00:37 --> Config Class Initialized
INFO - 2023-04-26 09:00:37 --> Loader Class Initialized
INFO - 2023-04-26 09:00:37 --> Helper loaded: url_helper
INFO - 2023-04-26 09:00:37 --> Helper loaded: file_helper
INFO - 2023-04-26 09:00:37 --> Helper loaded: form_helper
INFO - 2023-04-26 09:00:37 --> Helper loaded: my_helper
INFO - 2023-04-26 09:00:37 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:00:37 --> Controller Class Initialized
DEBUG - 2023-04-26 09:00:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:00:38 --> Final output sent to browser
DEBUG - 2023-04-26 09:00:38 --> Total execution time: 0.8315
INFO - 2023-04-26 09:01:25 --> Config Class Initialized
INFO - 2023-04-26 09:01:25 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:01:25 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:01:25 --> Utf8 Class Initialized
INFO - 2023-04-26 09:01:25 --> URI Class Initialized
INFO - 2023-04-26 09:01:25 --> Router Class Initialized
INFO - 2023-04-26 09:01:25 --> Output Class Initialized
INFO - 2023-04-26 09:01:25 --> Security Class Initialized
DEBUG - 2023-04-26 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:01:25 --> Input Class Initialized
INFO - 2023-04-26 09:01:25 --> Language Class Initialized
INFO - 2023-04-26 09:01:25 --> Language Class Initialized
INFO - 2023-04-26 09:01:25 --> Config Class Initialized
INFO - 2023-04-26 09:01:25 --> Loader Class Initialized
INFO - 2023-04-26 09:01:25 --> Helper loaded: url_helper
INFO - 2023-04-26 09:01:25 --> Helper loaded: file_helper
INFO - 2023-04-26 09:01:25 --> Helper loaded: form_helper
INFO - 2023-04-26 09:01:25 --> Helper loaded: my_helper
INFO - 2023-04-26 09:01:25 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:01:25 --> Controller Class Initialized
DEBUG - 2023-04-26 09:01:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:01:26 --> Final output sent to browser
DEBUG - 2023-04-26 09:01:26 --> Total execution time: 0.9091
INFO - 2023-04-26 09:01:41 --> Config Class Initialized
INFO - 2023-04-26 09:01:41 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:01:41 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:01:41 --> Utf8 Class Initialized
INFO - 2023-04-26 09:01:41 --> URI Class Initialized
INFO - 2023-04-26 09:01:41 --> Router Class Initialized
INFO - 2023-04-26 09:01:41 --> Output Class Initialized
INFO - 2023-04-26 09:01:41 --> Security Class Initialized
DEBUG - 2023-04-26 09:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:01:41 --> Input Class Initialized
INFO - 2023-04-26 09:01:41 --> Language Class Initialized
INFO - 2023-04-26 09:01:41 --> Language Class Initialized
INFO - 2023-04-26 09:01:41 --> Config Class Initialized
INFO - 2023-04-26 09:01:41 --> Loader Class Initialized
INFO - 2023-04-26 09:01:41 --> Helper loaded: url_helper
INFO - 2023-04-26 09:01:41 --> Helper loaded: file_helper
INFO - 2023-04-26 09:01:41 --> Helper loaded: form_helper
INFO - 2023-04-26 09:01:41 --> Helper loaded: my_helper
INFO - 2023-04-26 09:01:41 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:01:41 --> Controller Class Initialized
DEBUG - 2023-04-26 09:01:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:01:42 --> Final output sent to browser
DEBUG - 2023-04-26 09:01:42 --> Total execution time: 0.8383
INFO - 2023-04-26 09:02:24 --> Config Class Initialized
INFO - 2023-04-26 09:02:24 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:02:24 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:02:24 --> Utf8 Class Initialized
INFO - 2023-04-26 09:02:24 --> URI Class Initialized
INFO - 2023-04-26 09:02:24 --> Router Class Initialized
INFO - 2023-04-26 09:02:24 --> Output Class Initialized
INFO - 2023-04-26 09:02:24 --> Security Class Initialized
DEBUG - 2023-04-26 09:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:02:24 --> Input Class Initialized
INFO - 2023-04-26 09:02:24 --> Language Class Initialized
INFO - 2023-04-26 09:02:24 --> Language Class Initialized
INFO - 2023-04-26 09:02:24 --> Config Class Initialized
INFO - 2023-04-26 09:02:24 --> Loader Class Initialized
INFO - 2023-04-26 09:02:24 --> Helper loaded: url_helper
INFO - 2023-04-26 09:02:24 --> Helper loaded: file_helper
INFO - 2023-04-26 09:02:24 --> Helper loaded: form_helper
INFO - 2023-04-26 09:02:24 --> Helper loaded: my_helper
INFO - 2023-04-26 09:02:24 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:02:24 --> Controller Class Initialized
DEBUG - 2023-04-26 09:02:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:02:24 --> Final output sent to browser
DEBUG - 2023-04-26 09:02:24 --> Total execution time: 0.9019
INFO - 2023-04-26 09:02:52 --> Config Class Initialized
INFO - 2023-04-26 09:02:52 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:02:52 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:02:52 --> Utf8 Class Initialized
INFO - 2023-04-26 09:02:52 --> URI Class Initialized
INFO - 2023-04-26 09:02:52 --> Router Class Initialized
INFO - 2023-04-26 09:02:52 --> Output Class Initialized
INFO - 2023-04-26 09:02:52 --> Security Class Initialized
DEBUG - 2023-04-26 09:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:02:52 --> Input Class Initialized
INFO - 2023-04-26 09:02:52 --> Language Class Initialized
INFO - 2023-04-26 09:02:52 --> Language Class Initialized
INFO - 2023-04-26 09:02:52 --> Config Class Initialized
INFO - 2023-04-26 09:02:52 --> Loader Class Initialized
INFO - 2023-04-26 09:02:52 --> Helper loaded: url_helper
INFO - 2023-04-26 09:02:52 --> Helper loaded: file_helper
INFO - 2023-04-26 09:02:52 --> Helper loaded: form_helper
INFO - 2023-04-26 09:02:52 --> Helper loaded: my_helper
INFO - 2023-04-26 09:02:52 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:02:52 --> Controller Class Initialized
DEBUG - 2023-04-26 09:02:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:02:53 --> Final output sent to browser
DEBUG - 2023-04-26 09:02:53 --> Total execution time: 0.9365
INFO - 2023-04-26 09:03:09 --> Config Class Initialized
INFO - 2023-04-26 09:03:09 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:03:09 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:03:09 --> Utf8 Class Initialized
INFO - 2023-04-26 09:03:09 --> URI Class Initialized
INFO - 2023-04-26 09:03:09 --> Router Class Initialized
INFO - 2023-04-26 09:03:09 --> Output Class Initialized
INFO - 2023-04-26 09:03:09 --> Security Class Initialized
DEBUG - 2023-04-26 09:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:03:09 --> Input Class Initialized
INFO - 2023-04-26 09:03:09 --> Language Class Initialized
INFO - 2023-04-26 09:03:09 --> Language Class Initialized
INFO - 2023-04-26 09:03:09 --> Config Class Initialized
INFO - 2023-04-26 09:03:09 --> Loader Class Initialized
INFO - 2023-04-26 09:03:09 --> Helper loaded: url_helper
INFO - 2023-04-26 09:03:09 --> Helper loaded: file_helper
INFO - 2023-04-26 09:03:09 --> Helper loaded: form_helper
INFO - 2023-04-26 09:03:09 --> Helper loaded: my_helper
INFO - 2023-04-26 09:03:09 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:03:09 --> Controller Class Initialized
DEBUG - 2023-04-26 09:03:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:03:09 --> Final output sent to browser
DEBUG - 2023-04-26 09:03:09 --> Total execution time: 0.7974
INFO - 2023-04-26 09:04:05 --> Config Class Initialized
INFO - 2023-04-26 09:04:05 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:04:05 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:04:05 --> Utf8 Class Initialized
INFO - 2023-04-26 09:04:05 --> URI Class Initialized
INFO - 2023-04-26 09:04:05 --> Router Class Initialized
INFO - 2023-04-26 09:04:05 --> Output Class Initialized
INFO - 2023-04-26 09:04:05 --> Security Class Initialized
DEBUG - 2023-04-26 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:04:05 --> Input Class Initialized
INFO - 2023-04-26 09:04:05 --> Language Class Initialized
INFO - 2023-04-26 09:04:05 --> Language Class Initialized
INFO - 2023-04-26 09:04:05 --> Config Class Initialized
INFO - 2023-04-26 09:04:05 --> Loader Class Initialized
INFO - 2023-04-26 09:04:05 --> Helper loaded: url_helper
INFO - 2023-04-26 09:04:05 --> Helper loaded: file_helper
INFO - 2023-04-26 09:04:05 --> Helper loaded: form_helper
INFO - 2023-04-26 09:04:05 --> Helper loaded: my_helper
INFO - 2023-04-26 09:04:05 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:04:05 --> Controller Class Initialized
DEBUG - 2023-04-26 09:04:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:04:06 --> Final output sent to browser
DEBUG - 2023-04-26 09:04:06 --> Total execution time: 0.9667
INFO - 2023-04-26 09:04:28 --> Config Class Initialized
INFO - 2023-04-26 09:04:28 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:04:28 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:04:28 --> Utf8 Class Initialized
INFO - 2023-04-26 09:04:28 --> URI Class Initialized
INFO - 2023-04-26 09:04:28 --> Router Class Initialized
INFO - 2023-04-26 09:04:28 --> Output Class Initialized
INFO - 2023-04-26 09:04:28 --> Security Class Initialized
DEBUG - 2023-04-26 09:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:04:28 --> Input Class Initialized
INFO - 2023-04-26 09:04:28 --> Language Class Initialized
INFO - 2023-04-26 09:04:28 --> Language Class Initialized
INFO - 2023-04-26 09:04:28 --> Config Class Initialized
INFO - 2023-04-26 09:04:28 --> Loader Class Initialized
INFO - 2023-04-26 09:04:28 --> Helper loaded: url_helper
INFO - 2023-04-26 09:04:28 --> Helper loaded: file_helper
INFO - 2023-04-26 09:04:28 --> Helper loaded: form_helper
INFO - 2023-04-26 09:04:28 --> Helper loaded: my_helper
INFO - 2023-04-26 09:04:28 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:04:28 --> Controller Class Initialized
DEBUG - 2023-04-26 09:04:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:04:29 --> Final output sent to browser
DEBUG - 2023-04-26 09:04:29 --> Total execution time: 0.8389
INFO - 2023-04-26 09:04:45 --> Config Class Initialized
INFO - 2023-04-26 09:04:45 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:04:45 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:04:45 --> Utf8 Class Initialized
INFO - 2023-04-26 09:04:45 --> URI Class Initialized
INFO - 2023-04-26 09:04:45 --> Router Class Initialized
INFO - 2023-04-26 09:04:45 --> Output Class Initialized
INFO - 2023-04-26 09:04:45 --> Security Class Initialized
DEBUG - 2023-04-26 09:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:04:45 --> Input Class Initialized
INFO - 2023-04-26 09:04:45 --> Language Class Initialized
INFO - 2023-04-26 09:04:45 --> Language Class Initialized
INFO - 2023-04-26 09:04:45 --> Config Class Initialized
INFO - 2023-04-26 09:04:45 --> Loader Class Initialized
INFO - 2023-04-26 09:04:46 --> Helper loaded: url_helper
INFO - 2023-04-26 09:04:46 --> Helper loaded: file_helper
INFO - 2023-04-26 09:04:46 --> Helper loaded: form_helper
INFO - 2023-04-26 09:04:46 --> Helper loaded: my_helper
INFO - 2023-04-26 09:04:46 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:04:46 --> Controller Class Initialized
DEBUG - 2023-04-26 09:04:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:04:46 --> Final output sent to browser
DEBUG - 2023-04-26 09:04:46 --> Total execution time: 0.9449
INFO - 2023-04-26 09:05:04 --> Config Class Initialized
INFO - 2023-04-26 09:05:04 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:05:04 --> Utf8 Class Initialized
INFO - 2023-04-26 09:05:04 --> URI Class Initialized
INFO - 2023-04-26 09:05:04 --> Router Class Initialized
INFO - 2023-04-26 09:05:04 --> Output Class Initialized
INFO - 2023-04-26 09:05:04 --> Security Class Initialized
DEBUG - 2023-04-26 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:05:04 --> Input Class Initialized
INFO - 2023-04-26 09:05:04 --> Language Class Initialized
INFO - 2023-04-26 09:05:04 --> Language Class Initialized
INFO - 2023-04-26 09:05:04 --> Config Class Initialized
INFO - 2023-04-26 09:05:04 --> Loader Class Initialized
INFO - 2023-04-26 09:05:04 --> Helper loaded: url_helper
INFO - 2023-04-26 09:05:04 --> Helper loaded: file_helper
INFO - 2023-04-26 09:05:04 --> Helper loaded: form_helper
INFO - 2023-04-26 09:05:04 --> Helper loaded: my_helper
INFO - 2023-04-26 09:05:04 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:05:04 --> Controller Class Initialized
DEBUG - 2023-04-26 09:05:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:05:04 --> Final output sent to browser
DEBUG - 2023-04-26 09:05:04 --> Total execution time: 0.9276
INFO - 2023-04-26 09:05:13 --> Config Class Initialized
INFO - 2023-04-26 09:05:13 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:05:13 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:05:13 --> Utf8 Class Initialized
INFO - 2023-04-26 09:05:13 --> URI Class Initialized
INFO - 2023-04-26 09:05:13 --> Router Class Initialized
INFO - 2023-04-26 09:05:13 --> Output Class Initialized
INFO - 2023-04-26 09:05:13 --> Security Class Initialized
DEBUG - 2023-04-26 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:05:13 --> Input Class Initialized
INFO - 2023-04-26 09:05:13 --> Language Class Initialized
INFO - 2023-04-26 09:05:13 --> Language Class Initialized
INFO - 2023-04-26 09:05:13 --> Config Class Initialized
INFO - 2023-04-26 09:05:13 --> Loader Class Initialized
INFO - 2023-04-26 09:05:13 --> Helper loaded: url_helper
INFO - 2023-04-26 09:05:13 --> Helper loaded: file_helper
INFO - 2023-04-26 09:05:13 --> Helper loaded: form_helper
INFO - 2023-04-26 09:05:13 --> Helper loaded: my_helper
INFO - 2023-04-26 09:05:13 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:05:13 --> Controller Class Initialized
DEBUG - 2023-04-26 09:05:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:05:14 --> Final output sent to browser
DEBUG - 2023-04-26 09:05:14 --> Total execution time: 0.8954
INFO - 2023-04-26 09:05:29 --> Config Class Initialized
INFO - 2023-04-26 09:05:29 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:05:29 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:05:29 --> Utf8 Class Initialized
INFO - 2023-04-26 09:05:29 --> URI Class Initialized
INFO - 2023-04-26 09:05:29 --> Router Class Initialized
INFO - 2023-04-26 09:05:29 --> Output Class Initialized
INFO - 2023-04-26 09:05:29 --> Security Class Initialized
DEBUG - 2023-04-26 09:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:05:29 --> Input Class Initialized
INFO - 2023-04-26 09:05:29 --> Language Class Initialized
INFO - 2023-04-26 09:05:29 --> Language Class Initialized
INFO - 2023-04-26 09:05:29 --> Config Class Initialized
INFO - 2023-04-26 09:05:29 --> Loader Class Initialized
INFO - 2023-04-26 09:05:29 --> Helper loaded: url_helper
INFO - 2023-04-26 09:05:29 --> Helper loaded: file_helper
INFO - 2023-04-26 09:05:29 --> Helper loaded: form_helper
INFO - 2023-04-26 09:05:29 --> Helper loaded: my_helper
INFO - 2023-04-26 09:05:29 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:05:29 --> Controller Class Initialized
DEBUG - 2023-04-26 09:05:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:05:30 --> Final output sent to browser
DEBUG - 2023-04-26 09:05:30 --> Total execution time: 0.8433
INFO - 2023-04-26 09:05:39 --> Config Class Initialized
INFO - 2023-04-26 09:05:39 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:05:39 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:05:39 --> Utf8 Class Initialized
INFO - 2023-04-26 09:05:39 --> URI Class Initialized
INFO - 2023-04-26 09:05:39 --> Router Class Initialized
INFO - 2023-04-26 09:05:39 --> Output Class Initialized
INFO - 2023-04-26 09:05:39 --> Security Class Initialized
DEBUG - 2023-04-26 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:05:39 --> Input Class Initialized
INFO - 2023-04-26 09:05:39 --> Language Class Initialized
INFO - 2023-04-26 09:05:39 --> Language Class Initialized
INFO - 2023-04-26 09:05:39 --> Config Class Initialized
INFO - 2023-04-26 09:05:39 --> Loader Class Initialized
INFO - 2023-04-26 09:05:39 --> Helper loaded: url_helper
INFO - 2023-04-26 09:05:39 --> Helper loaded: file_helper
INFO - 2023-04-26 09:05:39 --> Helper loaded: form_helper
INFO - 2023-04-26 09:05:39 --> Helper loaded: my_helper
INFO - 2023-04-26 09:05:39 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:05:39 --> Controller Class Initialized
DEBUG - 2023-04-26 09:05:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:05:39 --> Final output sent to browser
DEBUG - 2023-04-26 09:05:39 --> Total execution time: 0.8093
INFO - 2023-04-26 09:06:34 --> Config Class Initialized
INFO - 2023-04-26 09:06:34 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:06:34 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:06:34 --> Utf8 Class Initialized
INFO - 2023-04-26 09:06:34 --> URI Class Initialized
INFO - 2023-04-26 09:06:34 --> Router Class Initialized
INFO - 2023-04-26 09:06:34 --> Output Class Initialized
INFO - 2023-04-26 09:06:34 --> Security Class Initialized
DEBUG - 2023-04-26 09:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:06:34 --> Input Class Initialized
INFO - 2023-04-26 09:06:34 --> Language Class Initialized
INFO - 2023-04-26 09:06:34 --> Language Class Initialized
INFO - 2023-04-26 09:06:34 --> Config Class Initialized
INFO - 2023-04-26 09:06:34 --> Loader Class Initialized
INFO - 2023-04-26 09:06:34 --> Helper loaded: url_helper
INFO - 2023-04-26 09:06:34 --> Helper loaded: file_helper
INFO - 2023-04-26 09:06:34 --> Helper loaded: form_helper
INFO - 2023-04-26 09:06:34 --> Helper loaded: my_helper
INFO - 2023-04-26 09:06:34 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:06:34 --> Controller Class Initialized
DEBUG - 2023-04-26 09:06:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:06:34 --> Final output sent to browser
DEBUG - 2023-04-26 09:06:34 --> Total execution time: 0.8730
INFO - 2023-04-26 09:07:37 --> Config Class Initialized
INFO - 2023-04-26 09:07:37 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:07:37 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:07:37 --> Utf8 Class Initialized
INFO - 2023-04-26 09:07:37 --> URI Class Initialized
INFO - 2023-04-26 09:07:37 --> Router Class Initialized
INFO - 2023-04-26 09:07:37 --> Output Class Initialized
INFO - 2023-04-26 09:07:37 --> Security Class Initialized
DEBUG - 2023-04-26 09:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:07:37 --> Input Class Initialized
INFO - 2023-04-26 09:07:37 --> Language Class Initialized
INFO - 2023-04-26 09:07:38 --> Language Class Initialized
INFO - 2023-04-26 09:07:38 --> Config Class Initialized
INFO - 2023-04-26 09:07:38 --> Loader Class Initialized
INFO - 2023-04-26 09:07:38 --> Helper loaded: url_helper
INFO - 2023-04-26 09:07:38 --> Helper loaded: file_helper
INFO - 2023-04-26 09:07:38 --> Helper loaded: form_helper
INFO - 2023-04-26 09:07:38 --> Helper loaded: my_helper
INFO - 2023-04-26 09:07:38 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:07:38 --> Controller Class Initialized
DEBUG - 2023-04-26 09:07:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:07:38 --> Final output sent to browser
DEBUG - 2023-04-26 09:07:38 --> Total execution time: 0.8420
INFO - 2023-04-26 09:08:02 --> Config Class Initialized
INFO - 2023-04-26 09:08:02 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:08:02 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:08:02 --> Utf8 Class Initialized
INFO - 2023-04-26 09:08:02 --> URI Class Initialized
INFO - 2023-04-26 09:08:02 --> Router Class Initialized
INFO - 2023-04-26 09:08:02 --> Output Class Initialized
INFO - 2023-04-26 09:08:02 --> Security Class Initialized
DEBUG - 2023-04-26 09:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:08:02 --> Input Class Initialized
INFO - 2023-04-26 09:08:02 --> Language Class Initialized
INFO - 2023-04-26 09:08:02 --> Language Class Initialized
INFO - 2023-04-26 09:08:02 --> Config Class Initialized
INFO - 2023-04-26 09:08:02 --> Loader Class Initialized
INFO - 2023-04-26 09:08:02 --> Helper loaded: url_helper
INFO - 2023-04-26 09:08:02 --> Helper loaded: file_helper
INFO - 2023-04-26 09:08:02 --> Helper loaded: form_helper
INFO - 2023-04-26 09:08:02 --> Helper loaded: my_helper
INFO - 2023-04-26 09:08:02 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:08:02 --> Controller Class Initialized
DEBUG - 2023-04-26 09:08:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:08:03 --> Final output sent to browser
DEBUG - 2023-04-26 09:08:03 --> Total execution time: 0.8992
INFO - 2023-04-26 09:08:19 --> Config Class Initialized
INFO - 2023-04-26 09:08:19 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:08:19 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:08:19 --> Utf8 Class Initialized
INFO - 2023-04-26 09:08:19 --> URI Class Initialized
INFO - 2023-04-26 09:08:19 --> Router Class Initialized
INFO - 2023-04-26 09:08:19 --> Output Class Initialized
INFO - 2023-04-26 09:08:19 --> Security Class Initialized
DEBUG - 2023-04-26 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:08:19 --> Input Class Initialized
INFO - 2023-04-26 09:08:19 --> Language Class Initialized
INFO - 2023-04-26 09:08:19 --> Language Class Initialized
INFO - 2023-04-26 09:08:19 --> Config Class Initialized
INFO - 2023-04-26 09:08:19 --> Loader Class Initialized
INFO - 2023-04-26 09:08:19 --> Helper loaded: url_helper
INFO - 2023-04-26 09:08:19 --> Helper loaded: file_helper
INFO - 2023-04-26 09:08:19 --> Helper loaded: form_helper
INFO - 2023-04-26 09:08:19 --> Helper loaded: my_helper
INFO - 2023-04-26 09:08:19 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:08:19 --> Controller Class Initialized
DEBUG - 2023-04-26 09:08:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:08:20 --> Final output sent to browser
DEBUG - 2023-04-26 09:08:20 --> Total execution time: 0.8343
INFO - 2023-04-26 09:08:32 --> Config Class Initialized
INFO - 2023-04-26 09:08:32 --> Hooks Class Initialized
DEBUG - 2023-04-26 09:08:32 --> UTF-8 Support Enabled
INFO - 2023-04-26 09:08:32 --> Utf8 Class Initialized
INFO - 2023-04-26 09:08:32 --> URI Class Initialized
INFO - 2023-04-26 09:08:32 --> Router Class Initialized
INFO - 2023-04-26 09:08:32 --> Output Class Initialized
INFO - 2023-04-26 09:08:32 --> Security Class Initialized
DEBUG - 2023-04-26 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-26 09:08:32 --> Input Class Initialized
INFO - 2023-04-26 09:08:32 --> Language Class Initialized
INFO - 2023-04-26 09:08:32 --> Language Class Initialized
INFO - 2023-04-26 09:08:32 --> Config Class Initialized
INFO - 2023-04-26 09:08:32 --> Loader Class Initialized
INFO - 2023-04-26 09:08:32 --> Helper loaded: url_helper
INFO - 2023-04-26 09:08:32 --> Helper loaded: file_helper
INFO - 2023-04-26 09:08:32 --> Helper loaded: form_helper
INFO - 2023-04-26 09:08:32 --> Helper loaded: my_helper
INFO - 2023-04-26 09:08:32 --> Database Driver Class Initialized
DEBUG - 2023-04-26 09:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-26 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-26 09:08:32 --> Controller Class Initialized
DEBUG - 2023-04-26 09:08:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-04-26 09:08:33 --> Final output sent to browser
DEBUG - 2023-04-26 09:08:33 --> Total execution time: 0.8507
