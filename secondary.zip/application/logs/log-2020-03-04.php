<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-04 08:29:48 --> Config Class Initialized
INFO - 2020-03-04 08:29:48 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:29:48 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:29:48 --> Utf8 Class Initialized
INFO - 2020-03-04 08:29:48 --> URI Class Initialized
DEBUG - 2020-03-04 08:29:48 --> No URI present. Default controller set.
INFO - 2020-03-04 08:29:48 --> Router Class Initialized
INFO - 2020-03-04 08:29:48 --> Output Class Initialized
INFO - 2020-03-04 08:29:48 --> Security Class Initialized
DEBUG - 2020-03-04 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:29:49 --> Input Class Initialized
INFO - 2020-03-04 08:29:49 --> Language Class Initialized
INFO - 2020-03-04 08:29:49 --> Language Class Initialized
INFO - 2020-03-04 08:29:49 --> Config Class Initialized
INFO - 2020-03-04 08:29:49 --> Loader Class Initialized
INFO - 2020-03-04 08:29:49 --> Helper loaded: url_helper
INFO - 2020-03-04 08:29:49 --> Helper loaded: file_helper
INFO - 2020-03-04 08:29:49 --> Helper loaded: form_helper
INFO - 2020-03-04 08:29:49 --> Helper loaded: my_helper
INFO - 2020-03-04 08:29:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:29:49 --> Controller Class Initialized
INFO - 2020-03-04 08:29:49 --> Config Class Initialized
INFO - 2020-03-04 08:29:49 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:29:49 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:29:49 --> Utf8 Class Initialized
INFO - 2020-03-04 08:29:49 --> URI Class Initialized
INFO - 2020-03-04 08:29:49 --> Router Class Initialized
INFO - 2020-03-04 08:29:49 --> Output Class Initialized
INFO - 2020-03-04 08:29:49 --> Security Class Initialized
DEBUG - 2020-03-04 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:29:49 --> Input Class Initialized
INFO - 2020-03-04 08:29:49 --> Language Class Initialized
INFO - 2020-03-04 08:29:49 --> Language Class Initialized
INFO - 2020-03-04 08:29:49 --> Config Class Initialized
INFO - 2020-03-04 08:29:49 --> Loader Class Initialized
INFO - 2020-03-04 08:29:49 --> Helper loaded: url_helper
INFO - 2020-03-04 08:29:49 --> Helper loaded: file_helper
INFO - 2020-03-04 08:29:49 --> Helper loaded: form_helper
INFO - 2020-03-04 08:29:49 --> Helper loaded: my_helper
INFO - 2020-03-04 08:29:49 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:29:49 --> Controller Class Initialized
DEBUG - 2020-03-04 08:29:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-04 08:29:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-04 08:29:49 --> Final output sent to browser
DEBUG - 2020-03-04 08:29:49 --> Total execution time: 0.3347
INFO - 2020-03-04 08:29:55 --> Config Class Initialized
INFO - 2020-03-04 08:29:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:29:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:29:55 --> Utf8 Class Initialized
INFO - 2020-03-04 08:29:55 --> URI Class Initialized
INFO - 2020-03-04 08:29:55 --> Router Class Initialized
INFO - 2020-03-04 08:29:55 --> Output Class Initialized
INFO - 2020-03-04 08:29:55 --> Security Class Initialized
DEBUG - 2020-03-04 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:29:55 --> Input Class Initialized
INFO - 2020-03-04 08:29:55 --> Language Class Initialized
INFO - 2020-03-04 08:29:55 --> Language Class Initialized
INFO - 2020-03-04 08:29:55 --> Config Class Initialized
INFO - 2020-03-04 08:29:55 --> Loader Class Initialized
INFO - 2020-03-04 08:29:55 --> Helper loaded: url_helper
INFO - 2020-03-04 08:29:55 --> Helper loaded: file_helper
INFO - 2020-03-04 08:29:55 --> Helper loaded: form_helper
INFO - 2020-03-04 08:29:55 --> Helper loaded: my_helper
INFO - 2020-03-04 08:29:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:29:55 --> Controller Class Initialized
INFO - 2020-03-04 08:29:55 --> Helper loaded: cookie_helper
INFO - 2020-03-04 08:29:55 --> Final output sent to browser
DEBUG - 2020-03-04 08:29:55 --> Total execution time: 0.3294
INFO - 2020-03-04 08:29:55 --> Config Class Initialized
INFO - 2020-03-04 08:29:55 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:29:55 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:29:55 --> Utf8 Class Initialized
INFO - 2020-03-04 08:29:55 --> URI Class Initialized
INFO - 2020-03-04 08:29:55 --> Router Class Initialized
INFO - 2020-03-04 08:29:55 --> Output Class Initialized
INFO - 2020-03-04 08:29:55 --> Security Class Initialized
DEBUG - 2020-03-04 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:29:55 --> Input Class Initialized
INFO - 2020-03-04 08:29:55 --> Language Class Initialized
INFO - 2020-03-04 08:29:55 --> Language Class Initialized
INFO - 2020-03-04 08:29:55 --> Config Class Initialized
INFO - 2020-03-04 08:29:55 --> Loader Class Initialized
INFO - 2020-03-04 08:29:55 --> Helper loaded: url_helper
INFO - 2020-03-04 08:29:55 --> Helper loaded: file_helper
INFO - 2020-03-04 08:29:55 --> Helper loaded: form_helper
INFO - 2020-03-04 08:29:55 --> Helper loaded: my_helper
INFO - 2020-03-04 08:29:55 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:29:56 --> Controller Class Initialized
DEBUG - 2020-03-04 08:29:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-04 08:29:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-04 08:29:56 --> Final output sent to browser
DEBUG - 2020-03-04 08:29:56 --> Total execution time: 0.4348
INFO - 2020-03-04 08:29:58 --> Config Class Initialized
INFO - 2020-03-04 08:29:58 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:29:58 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:29:58 --> Utf8 Class Initialized
INFO - 2020-03-04 08:29:58 --> URI Class Initialized
INFO - 2020-03-04 08:29:58 --> Router Class Initialized
INFO - 2020-03-04 08:29:58 --> Output Class Initialized
INFO - 2020-03-04 08:29:58 --> Security Class Initialized
DEBUG - 2020-03-04 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:29:58 --> Input Class Initialized
INFO - 2020-03-04 08:29:58 --> Language Class Initialized
INFO - 2020-03-04 08:29:58 --> Language Class Initialized
INFO - 2020-03-04 08:29:58 --> Config Class Initialized
INFO - 2020-03-04 08:29:58 --> Loader Class Initialized
INFO - 2020-03-04 08:29:58 --> Helper loaded: url_helper
INFO - 2020-03-04 08:29:58 --> Helper loaded: file_helper
INFO - 2020-03-04 08:29:58 --> Helper loaded: form_helper
INFO - 2020-03-04 08:29:58 --> Helper loaded: my_helper
INFO - 2020-03-04 08:29:58 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:29:58 --> Controller Class Initialized
DEBUG - 2020-03-04 08:29:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-04 08:29:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-04 08:29:58 --> Final output sent to browser
DEBUG - 2020-03-04 08:29:58 --> Total execution time: 0.3227
INFO - 2020-03-04 08:29:59 --> Config Class Initialized
INFO - 2020-03-04 08:29:59 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:29:59 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:29:59 --> Utf8 Class Initialized
INFO - 2020-03-04 08:29:59 --> URI Class Initialized
INFO - 2020-03-04 08:29:59 --> Router Class Initialized
INFO - 2020-03-04 08:29:59 --> Output Class Initialized
INFO - 2020-03-04 08:29:59 --> Security Class Initialized
DEBUG - 2020-03-04 08:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:29:59 --> Input Class Initialized
INFO - 2020-03-04 08:29:59 --> Language Class Initialized
INFO - 2020-03-04 08:29:59 --> Language Class Initialized
INFO - 2020-03-04 08:29:59 --> Config Class Initialized
INFO - 2020-03-04 08:29:59 --> Loader Class Initialized
INFO - 2020-03-04 08:29:59 --> Helper loaded: url_helper
INFO - 2020-03-04 08:29:59 --> Helper loaded: file_helper
INFO - 2020-03-04 08:29:59 --> Helper loaded: form_helper
INFO - 2020-03-04 08:29:59 --> Helper loaded: my_helper
INFO - 2020-03-04 08:29:59 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:29:59 --> Controller Class Initialized
INFO - 2020-03-04 08:30:04 --> Config Class Initialized
INFO - 2020-03-04 08:30:04 --> Hooks Class Initialized
DEBUG - 2020-03-04 08:30:05 --> UTF-8 Support Enabled
INFO - 2020-03-04 08:30:05 --> Utf8 Class Initialized
INFO - 2020-03-04 08:30:05 --> URI Class Initialized
INFO - 2020-03-04 08:30:05 --> Router Class Initialized
INFO - 2020-03-04 08:30:05 --> Output Class Initialized
INFO - 2020-03-04 08:30:05 --> Security Class Initialized
DEBUG - 2020-03-04 08:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-04 08:30:05 --> Input Class Initialized
INFO - 2020-03-04 08:30:05 --> Language Class Initialized
INFO - 2020-03-04 08:30:05 --> Language Class Initialized
INFO - 2020-03-04 08:30:05 --> Config Class Initialized
INFO - 2020-03-04 08:30:05 --> Loader Class Initialized
INFO - 2020-03-04 08:30:05 --> Helper loaded: url_helper
INFO - 2020-03-04 08:30:05 --> Helper loaded: file_helper
INFO - 2020-03-04 08:30:05 --> Helper loaded: form_helper
INFO - 2020-03-04 08:30:05 --> Helper loaded: my_helper
INFO - 2020-03-04 08:30:05 --> Database Driver Class Initialized
DEBUG - 2020-03-04 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-04 08:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-04 08:30:05 --> Controller Class Initialized
DEBUG - 2020-03-04 08:30:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-03-04 08:30:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-04 08:30:05 --> Final output sent to browser
DEBUG - 2020-03-04 08:30:05 --> Total execution time: 0.2923
