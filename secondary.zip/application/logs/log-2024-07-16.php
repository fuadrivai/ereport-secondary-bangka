<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-16 00:13:53 --> Config Class Initialized
INFO - 2024-07-16 00:13:53 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:13:53 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:13:53 --> Utf8 Class Initialized
INFO - 2024-07-16 00:13:53 --> URI Class Initialized
DEBUG - 2024-07-16 00:13:53 --> No URI present. Default controller set.
INFO - 2024-07-16 00:13:53 --> Router Class Initialized
INFO - 2024-07-16 00:13:53 --> Output Class Initialized
INFO - 2024-07-16 00:13:53 --> Security Class Initialized
DEBUG - 2024-07-16 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:13:53 --> Input Class Initialized
INFO - 2024-07-16 00:13:53 --> Language Class Initialized
INFO - 2024-07-16 00:13:53 --> Language Class Initialized
INFO - 2024-07-16 00:13:53 --> Config Class Initialized
INFO - 2024-07-16 00:13:53 --> Loader Class Initialized
INFO - 2024-07-16 00:13:53 --> Helper loaded: url_helper
INFO - 2024-07-16 00:13:53 --> Helper loaded: file_helper
INFO - 2024-07-16 00:13:53 --> Helper loaded: form_helper
INFO - 2024-07-16 00:13:53 --> Helper loaded: my_helper
INFO - 2024-07-16 00:13:53 --> Database Driver Class Initialized
INFO - 2024-07-16 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:13:53 --> Controller Class Initialized
INFO - 2024-07-16 00:13:53 --> Config Class Initialized
INFO - 2024-07-16 00:13:53 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:13:53 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:13:53 --> Utf8 Class Initialized
INFO - 2024-07-16 00:13:53 --> URI Class Initialized
INFO - 2024-07-16 00:13:53 --> Router Class Initialized
INFO - 2024-07-16 00:13:53 --> Output Class Initialized
INFO - 2024-07-16 00:13:53 --> Security Class Initialized
DEBUG - 2024-07-16 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:13:53 --> Input Class Initialized
INFO - 2024-07-16 00:13:53 --> Language Class Initialized
INFO - 2024-07-16 00:13:53 --> Language Class Initialized
INFO - 2024-07-16 00:13:53 --> Config Class Initialized
INFO - 2024-07-16 00:13:53 --> Loader Class Initialized
INFO - 2024-07-16 00:13:53 --> Helper loaded: url_helper
INFO - 2024-07-16 00:13:53 --> Helper loaded: file_helper
INFO - 2024-07-16 00:13:53 --> Helper loaded: form_helper
INFO - 2024-07-16 00:13:53 --> Helper loaded: my_helper
INFO - 2024-07-16 00:13:53 --> Database Driver Class Initialized
INFO - 2024-07-16 00:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:13:53 --> Controller Class Initialized
DEBUG - 2024-07-16 00:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-16 00:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:13:53 --> Final output sent to browser
DEBUG - 2024-07-16 00:13:53 --> Total execution time: 0.0325
INFO - 2024-07-16 00:13:53 --> Config Class Initialized
INFO - 2024-07-16 00:13:53 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:13:53 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:13:53 --> Utf8 Class Initialized
INFO - 2024-07-16 00:13:53 --> URI Class Initialized
INFO - 2024-07-16 00:13:53 --> Router Class Initialized
INFO - 2024-07-16 00:13:53 --> Output Class Initialized
INFO - 2024-07-16 00:13:53 --> Security Class Initialized
DEBUG - 2024-07-16 00:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:13:53 --> Input Class Initialized
INFO - 2024-07-16 00:13:53 --> Language Class Initialized
ERROR - 2024-07-16 00:13:53 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:14:00 --> Config Class Initialized
INFO - 2024-07-16 00:14:00 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:14:00 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:14:00 --> Utf8 Class Initialized
INFO - 2024-07-16 00:14:00 --> URI Class Initialized
INFO - 2024-07-16 00:14:00 --> Router Class Initialized
INFO - 2024-07-16 00:14:00 --> Output Class Initialized
INFO - 2024-07-16 00:14:00 --> Security Class Initialized
DEBUG - 2024-07-16 00:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:14:00 --> Input Class Initialized
INFO - 2024-07-16 00:14:00 --> Language Class Initialized
INFO - 2024-07-16 00:14:00 --> Language Class Initialized
INFO - 2024-07-16 00:14:00 --> Config Class Initialized
INFO - 2024-07-16 00:14:00 --> Loader Class Initialized
INFO - 2024-07-16 00:14:00 --> Helper loaded: url_helper
INFO - 2024-07-16 00:14:00 --> Helper loaded: file_helper
INFO - 2024-07-16 00:14:00 --> Helper loaded: form_helper
INFO - 2024-07-16 00:14:00 --> Helper loaded: my_helper
INFO - 2024-07-16 00:14:00 --> Database Driver Class Initialized
INFO - 2024-07-16 00:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:14:00 --> Controller Class Initialized
INFO - 2024-07-16 00:14:00 --> Helper loaded: cookie_helper
INFO - 2024-07-16 00:14:00 --> Final output sent to browser
DEBUG - 2024-07-16 00:14:00 --> Total execution time: 0.0393
INFO - 2024-07-16 00:14:00 --> Config Class Initialized
INFO - 2024-07-16 00:14:00 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:14:00 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:14:00 --> Utf8 Class Initialized
INFO - 2024-07-16 00:14:00 --> URI Class Initialized
INFO - 2024-07-16 00:14:00 --> Router Class Initialized
INFO - 2024-07-16 00:14:00 --> Output Class Initialized
INFO - 2024-07-16 00:14:00 --> Security Class Initialized
DEBUG - 2024-07-16 00:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:14:00 --> Input Class Initialized
INFO - 2024-07-16 00:14:00 --> Language Class Initialized
INFO - 2024-07-16 00:14:00 --> Language Class Initialized
INFO - 2024-07-16 00:14:00 --> Config Class Initialized
INFO - 2024-07-16 00:14:00 --> Loader Class Initialized
INFO - 2024-07-16 00:14:00 --> Helper loaded: url_helper
INFO - 2024-07-16 00:14:00 --> Helper loaded: file_helper
INFO - 2024-07-16 00:14:00 --> Helper loaded: form_helper
INFO - 2024-07-16 00:14:00 --> Helper loaded: my_helper
INFO - 2024-07-16 00:14:00 --> Database Driver Class Initialized
INFO - 2024-07-16 00:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:14:00 --> Controller Class Initialized
DEBUG - 2024-07-16 00:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-16 00:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:14:00 --> Final output sent to browser
DEBUG - 2024-07-16 00:14:00 --> Total execution time: 0.0453
INFO - 2024-07-16 00:14:00 --> Config Class Initialized
INFO - 2024-07-16 00:14:00 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:14:00 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:14:00 --> Utf8 Class Initialized
INFO - 2024-07-16 00:14:00 --> URI Class Initialized
INFO - 2024-07-16 00:14:00 --> Router Class Initialized
INFO - 2024-07-16 00:14:00 --> Output Class Initialized
INFO - 2024-07-16 00:14:00 --> Security Class Initialized
DEBUG - 2024-07-16 00:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:14:00 --> Input Class Initialized
INFO - 2024-07-16 00:14:00 --> Language Class Initialized
ERROR - 2024-07-16 00:14:00 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:15:01 --> Config Class Initialized
INFO - 2024-07-16 00:15:01 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:15:01 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:15:01 --> Utf8 Class Initialized
INFO - 2024-07-16 00:15:01 --> URI Class Initialized
INFO - 2024-07-16 00:15:01 --> Router Class Initialized
INFO - 2024-07-16 00:15:01 --> Output Class Initialized
INFO - 2024-07-16 00:15:01 --> Security Class Initialized
DEBUG - 2024-07-16 00:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:15:01 --> Input Class Initialized
INFO - 2024-07-16 00:15:01 --> Language Class Initialized
INFO - 2024-07-16 00:15:01 --> Language Class Initialized
INFO - 2024-07-16 00:15:01 --> Config Class Initialized
INFO - 2024-07-16 00:15:01 --> Loader Class Initialized
INFO - 2024-07-16 00:15:01 --> Helper loaded: url_helper
INFO - 2024-07-16 00:15:01 --> Helper loaded: file_helper
INFO - 2024-07-16 00:15:01 --> Helper loaded: form_helper
INFO - 2024-07-16 00:15:01 --> Helper loaded: my_helper
INFO - 2024-07-16 00:15:01 --> Database Driver Class Initialized
INFO - 2024-07-16 00:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:15:01 --> Controller Class Initialized
DEBUG - 2024-07-16 00:15:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-16 00:15:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:15:01 --> Final output sent to browser
DEBUG - 2024-07-16 00:15:01 --> Total execution time: 0.0366
INFO - 2024-07-16 00:15:02 --> Config Class Initialized
INFO - 2024-07-16 00:15:02 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:15:02 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:15:02 --> Utf8 Class Initialized
INFO - 2024-07-16 00:15:02 --> URI Class Initialized
INFO - 2024-07-16 00:15:02 --> Router Class Initialized
INFO - 2024-07-16 00:15:02 --> Output Class Initialized
INFO - 2024-07-16 00:15:02 --> Security Class Initialized
DEBUG - 2024-07-16 00:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:15:02 --> Input Class Initialized
INFO - 2024-07-16 00:15:02 --> Language Class Initialized
ERROR - 2024-07-16 00:15:02 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:15:03 --> Config Class Initialized
INFO - 2024-07-16 00:15:03 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:15:03 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:15:03 --> Utf8 Class Initialized
INFO - 2024-07-16 00:15:03 --> URI Class Initialized
INFO - 2024-07-16 00:15:03 --> Router Class Initialized
INFO - 2024-07-16 00:15:03 --> Output Class Initialized
INFO - 2024-07-16 00:15:03 --> Security Class Initialized
DEBUG - 2024-07-16 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:15:03 --> Input Class Initialized
INFO - 2024-07-16 00:15:03 --> Language Class Initialized
INFO - 2024-07-16 00:15:03 --> Language Class Initialized
INFO - 2024-07-16 00:15:03 --> Config Class Initialized
INFO - 2024-07-16 00:15:03 --> Loader Class Initialized
INFO - 2024-07-16 00:15:03 --> Helper loaded: url_helper
INFO - 2024-07-16 00:15:03 --> Helper loaded: file_helper
INFO - 2024-07-16 00:15:03 --> Helper loaded: form_helper
INFO - 2024-07-16 00:15:03 --> Helper loaded: my_helper
INFO - 2024-07-16 00:15:03 --> Database Driver Class Initialized
INFO - 2024-07-16 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:15:03 --> Controller Class Initialized
DEBUG - 2024-07-16 00:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-07-16 00:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:15:03 --> Final output sent to browser
DEBUG - 2024-07-16 00:15:03 --> Total execution time: 0.0367
INFO - 2024-07-16 00:15:03 --> Config Class Initialized
INFO - 2024-07-16 00:15:03 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:15:03 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:15:03 --> Utf8 Class Initialized
INFO - 2024-07-16 00:15:03 --> URI Class Initialized
INFO - 2024-07-16 00:15:03 --> Router Class Initialized
INFO - 2024-07-16 00:15:03 --> Output Class Initialized
INFO - 2024-07-16 00:15:03 --> Security Class Initialized
DEBUG - 2024-07-16 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:15:03 --> Input Class Initialized
INFO - 2024-07-16 00:15:03 --> Language Class Initialized
ERROR - 2024-07-16 00:15:03 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:15:03 --> Config Class Initialized
INFO - 2024-07-16 00:15:03 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:15:03 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:15:03 --> Utf8 Class Initialized
INFO - 2024-07-16 00:15:03 --> URI Class Initialized
INFO - 2024-07-16 00:15:03 --> Router Class Initialized
INFO - 2024-07-16 00:15:03 --> Output Class Initialized
INFO - 2024-07-16 00:15:03 --> Security Class Initialized
DEBUG - 2024-07-16 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:15:03 --> Input Class Initialized
INFO - 2024-07-16 00:15:03 --> Language Class Initialized
ERROR - 2024-07-16 00:15:03 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:15:03 --> Config Class Initialized
INFO - 2024-07-16 00:15:03 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:15:03 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:15:03 --> Utf8 Class Initialized
INFO - 2024-07-16 00:15:03 --> URI Class Initialized
INFO - 2024-07-16 00:15:03 --> Router Class Initialized
INFO - 2024-07-16 00:15:03 --> Output Class Initialized
INFO - 2024-07-16 00:15:03 --> Security Class Initialized
DEBUG - 2024-07-16 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:15:03 --> Input Class Initialized
INFO - 2024-07-16 00:15:03 --> Language Class Initialized
INFO - 2024-07-16 00:15:03 --> Language Class Initialized
INFO - 2024-07-16 00:15:03 --> Config Class Initialized
INFO - 2024-07-16 00:15:03 --> Loader Class Initialized
INFO - 2024-07-16 00:15:03 --> Helper loaded: url_helper
INFO - 2024-07-16 00:15:03 --> Helper loaded: file_helper
INFO - 2024-07-16 00:15:03 --> Helper loaded: form_helper
INFO - 2024-07-16 00:15:03 --> Helper loaded: my_helper
INFO - 2024-07-16 00:15:03 --> Database Driver Class Initialized
INFO - 2024-07-16 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:15:03 --> Controller Class Initialized
ERROR - 2024-07-16 00:15:03 --> Query error: Table 'ereport_secondary_bangka.t_pengumuman' doesn't exist - Invalid query: SELECT * FROM t_pengumuman
INFO - 2024-07-16 00:15:03 --> Language file loaded: language/english/db_lang.php
INFO - 2024-07-16 00:17:35 --> Config Class Initialized
INFO - 2024-07-16 00:17:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:17:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:17:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:17:35 --> URI Class Initialized
INFO - 2024-07-16 00:17:35 --> Router Class Initialized
INFO - 2024-07-16 00:17:35 --> Output Class Initialized
INFO - 2024-07-16 00:17:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:17:35 --> Input Class Initialized
INFO - 2024-07-16 00:17:35 --> Language Class Initialized
INFO - 2024-07-16 00:17:35 --> Language Class Initialized
INFO - 2024-07-16 00:17:35 --> Config Class Initialized
INFO - 2024-07-16 00:17:35 --> Loader Class Initialized
INFO - 2024-07-16 00:17:35 --> Helper loaded: url_helper
INFO - 2024-07-16 00:17:35 --> Helper loaded: file_helper
INFO - 2024-07-16 00:17:35 --> Helper loaded: form_helper
INFO - 2024-07-16 00:17:35 --> Helper loaded: my_helper
INFO - 2024-07-16 00:17:35 --> Database Driver Class Initialized
INFO - 2024-07-16 00:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:17:35 --> Controller Class Initialized
DEBUG - 2024-07-16 00:17:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-07-16 00:17:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:17:35 --> Final output sent to browser
DEBUG - 2024-07-16 00:17:35 --> Total execution time: 0.0287
INFO - 2024-07-16 00:17:35 --> Config Class Initialized
INFO - 2024-07-16 00:17:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:17:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:17:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:17:35 --> URI Class Initialized
INFO - 2024-07-16 00:17:35 --> Router Class Initialized
INFO - 2024-07-16 00:17:35 --> Output Class Initialized
INFO - 2024-07-16 00:17:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:17:35 --> Input Class Initialized
INFO - 2024-07-16 00:17:35 --> Language Class Initialized
ERROR - 2024-07-16 00:17:35 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:17:35 --> Config Class Initialized
INFO - 2024-07-16 00:17:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:17:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:17:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:17:35 --> URI Class Initialized
INFO - 2024-07-16 00:17:35 --> Router Class Initialized
INFO - 2024-07-16 00:17:35 --> Output Class Initialized
INFO - 2024-07-16 00:17:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:17:35 --> Input Class Initialized
INFO - 2024-07-16 00:17:35 --> Language Class Initialized
ERROR - 2024-07-16 00:17:35 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:17:36 --> Config Class Initialized
INFO - 2024-07-16 00:17:36 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:17:36 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:17:36 --> Utf8 Class Initialized
INFO - 2024-07-16 00:17:36 --> URI Class Initialized
INFO - 2024-07-16 00:17:36 --> Router Class Initialized
INFO - 2024-07-16 00:17:36 --> Output Class Initialized
INFO - 2024-07-16 00:17:36 --> Security Class Initialized
DEBUG - 2024-07-16 00:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:17:36 --> Input Class Initialized
INFO - 2024-07-16 00:17:36 --> Language Class Initialized
INFO - 2024-07-16 00:17:36 --> Language Class Initialized
INFO - 2024-07-16 00:17:36 --> Config Class Initialized
INFO - 2024-07-16 00:17:36 --> Loader Class Initialized
INFO - 2024-07-16 00:17:36 --> Helper loaded: url_helper
INFO - 2024-07-16 00:17:36 --> Helper loaded: file_helper
INFO - 2024-07-16 00:17:36 --> Helper loaded: form_helper
INFO - 2024-07-16 00:17:36 --> Helper loaded: my_helper
INFO - 2024-07-16 00:17:36 --> Database Driver Class Initialized
INFO - 2024-07-16 00:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:17:36 --> Controller Class Initialized
INFO - 2024-07-16 00:19:48 --> Config Class Initialized
INFO - 2024-07-16 00:19:48 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:19:48 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:19:48 --> Utf8 Class Initialized
INFO - 2024-07-16 00:19:48 --> URI Class Initialized
INFO - 2024-07-16 00:19:48 --> Router Class Initialized
INFO - 2024-07-16 00:19:48 --> Output Class Initialized
INFO - 2024-07-16 00:19:48 --> Security Class Initialized
DEBUG - 2024-07-16 00:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:19:48 --> Input Class Initialized
INFO - 2024-07-16 00:19:48 --> Language Class Initialized
INFO - 2024-07-16 00:19:48 --> Language Class Initialized
INFO - 2024-07-16 00:19:48 --> Config Class Initialized
INFO - 2024-07-16 00:19:48 --> Loader Class Initialized
INFO - 2024-07-16 00:19:48 --> Helper loaded: url_helper
INFO - 2024-07-16 00:19:48 --> Helper loaded: file_helper
INFO - 2024-07-16 00:19:48 --> Helper loaded: form_helper
INFO - 2024-07-16 00:19:48 --> Helper loaded: my_helper
INFO - 2024-07-16 00:19:48 --> Database Driver Class Initialized
INFO - 2024-07-16 00:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:19:48 --> Controller Class Initialized
INFO - 2024-07-16 00:19:48 --> Database Driver Class Initialized
INFO - 2024-07-16 00:19:48 --> Final output sent to browser
DEBUG - 2024-07-16 00:19:48 --> Total execution time: 0.0301
INFO - 2024-07-16 00:19:48 --> Config Class Initialized
INFO - 2024-07-16 00:19:48 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:19:48 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:19:48 --> Utf8 Class Initialized
INFO - 2024-07-16 00:19:48 --> URI Class Initialized
INFO - 2024-07-16 00:19:48 --> Router Class Initialized
INFO - 2024-07-16 00:19:48 --> Output Class Initialized
INFO - 2024-07-16 00:19:48 --> Security Class Initialized
DEBUG - 2024-07-16 00:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:19:48 --> Input Class Initialized
INFO - 2024-07-16 00:19:48 --> Language Class Initialized
ERROR - 2024-07-16 00:19:48 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:19:48 --> Config Class Initialized
INFO - 2024-07-16 00:19:48 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:19:48 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:19:48 --> Utf8 Class Initialized
INFO - 2024-07-16 00:19:48 --> URI Class Initialized
INFO - 2024-07-16 00:19:48 --> Router Class Initialized
INFO - 2024-07-16 00:19:48 --> Output Class Initialized
INFO - 2024-07-16 00:19:48 --> Security Class Initialized
DEBUG - 2024-07-16 00:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:19:48 --> Input Class Initialized
INFO - 2024-07-16 00:19:48 --> Language Class Initialized
INFO - 2024-07-16 00:19:48 --> Language Class Initialized
INFO - 2024-07-16 00:19:48 --> Config Class Initialized
INFO - 2024-07-16 00:19:48 --> Loader Class Initialized
INFO - 2024-07-16 00:19:48 --> Helper loaded: url_helper
INFO - 2024-07-16 00:19:48 --> Helper loaded: file_helper
INFO - 2024-07-16 00:19:48 --> Helper loaded: form_helper
INFO - 2024-07-16 00:19:48 --> Helper loaded: my_helper
INFO - 2024-07-16 00:19:48 --> Database Driver Class Initialized
INFO - 2024-07-16 00:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:19:48 --> Controller Class Initialized
INFO - 2024-07-16 00:24:32 --> Config Class Initialized
INFO - 2024-07-16 00:24:32 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:32 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:32 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:32 --> URI Class Initialized
INFO - 2024-07-16 00:24:32 --> Router Class Initialized
INFO - 2024-07-16 00:24:32 --> Output Class Initialized
INFO - 2024-07-16 00:24:32 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:32 --> Input Class Initialized
INFO - 2024-07-16 00:24:32 --> Language Class Initialized
INFO - 2024-07-16 00:24:32 --> Language Class Initialized
INFO - 2024-07-16 00:24:32 --> Config Class Initialized
INFO - 2024-07-16 00:24:32 --> Loader Class Initialized
INFO - 2024-07-16 00:24:32 --> Helper loaded: url_helper
INFO - 2024-07-16 00:24:32 --> Helper loaded: file_helper
INFO - 2024-07-16 00:24:32 --> Helper loaded: form_helper
INFO - 2024-07-16 00:24:32 --> Helper loaded: my_helper
INFO - 2024-07-16 00:24:32 --> Database Driver Class Initialized
INFO - 2024-07-16 00:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:24:32 --> Controller Class Initialized
DEBUG - 2024-07-16 00:24:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-07-16 00:24:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:24:32 --> Final output sent to browser
DEBUG - 2024-07-16 00:24:32 --> Total execution time: 0.0325
INFO - 2024-07-16 00:24:32 --> Config Class Initialized
INFO - 2024-07-16 00:24:32 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:32 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:32 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:32 --> URI Class Initialized
INFO - 2024-07-16 00:24:32 --> Router Class Initialized
INFO - 2024-07-16 00:24:32 --> Output Class Initialized
INFO - 2024-07-16 00:24:32 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:32 --> Input Class Initialized
INFO - 2024-07-16 00:24:32 --> Language Class Initialized
ERROR - 2024-07-16 00:24:32 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:24:32 --> Config Class Initialized
INFO - 2024-07-16 00:24:32 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:32 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:32 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:32 --> URI Class Initialized
INFO - 2024-07-16 00:24:32 --> Router Class Initialized
INFO - 2024-07-16 00:24:32 --> Output Class Initialized
INFO - 2024-07-16 00:24:32 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:32 --> Input Class Initialized
INFO - 2024-07-16 00:24:32 --> Language Class Initialized
ERROR - 2024-07-16 00:24:32 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:24:32 --> Config Class Initialized
INFO - 2024-07-16 00:24:32 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:32 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:32 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:32 --> URI Class Initialized
INFO - 2024-07-16 00:24:32 --> Router Class Initialized
INFO - 2024-07-16 00:24:32 --> Output Class Initialized
INFO - 2024-07-16 00:24:32 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:32 --> Input Class Initialized
INFO - 2024-07-16 00:24:32 --> Language Class Initialized
INFO - 2024-07-16 00:24:32 --> Language Class Initialized
INFO - 2024-07-16 00:24:32 --> Config Class Initialized
INFO - 2024-07-16 00:24:32 --> Loader Class Initialized
INFO - 2024-07-16 00:24:32 --> Helper loaded: url_helper
INFO - 2024-07-16 00:24:32 --> Helper loaded: file_helper
INFO - 2024-07-16 00:24:32 --> Helper loaded: form_helper
INFO - 2024-07-16 00:24:32 --> Helper loaded: my_helper
INFO - 2024-07-16 00:24:32 --> Database Driver Class Initialized
INFO - 2024-07-16 00:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:24:32 --> Controller Class Initialized
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:35 --> URI Class Initialized
INFO - 2024-07-16 00:24:35 --> Router Class Initialized
INFO - 2024-07-16 00:24:35 --> Output Class Initialized
INFO - 2024-07-16 00:24:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:35 --> Input Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Loader Class Initialized
INFO - 2024-07-16 00:24:35 --> Helper loaded: url_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: file_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: form_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: my_helper
INFO - 2024-07-16 00:24:35 --> Database Driver Class Initialized
INFO - 2024-07-16 00:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:24:35 --> Controller Class Initialized
INFO - 2024-07-16 00:24:35 --> Helper loaded: cookie_helper
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:35 --> URI Class Initialized
INFO - 2024-07-16 00:24:35 --> Router Class Initialized
INFO - 2024-07-16 00:24:35 --> Output Class Initialized
INFO - 2024-07-16 00:24:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:35 --> Input Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Loader Class Initialized
INFO - 2024-07-16 00:24:35 --> Helper loaded: url_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: file_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: form_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: my_helper
INFO - 2024-07-16 00:24:35 --> Database Driver Class Initialized
INFO - 2024-07-16 00:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:24:35 --> Controller Class Initialized
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:35 --> URI Class Initialized
INFO - 2024-07-16 00:24:35 --> Router Class Initialized
INFO - 2024-07-16 00:24:35 --> Output Class Initialized
INFO - 2024-07-16 00:24:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:35 --> Input Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Loader Class Initialized
INFO - 2024-07-16 00:24:35 --> Helper loaded: url_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: file_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: form_helper
INFO - 2024-07-16 00:24:35 --> Helper loaded: my_helper
INFO - 2024-07-16 00:24:35 --> Database Driver Class Initialized
INFO - 2024-07-16 00:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:24:35 --> Controller Class Initialized
DEBUG - 2024-07-16 00:24:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-16 00:24:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:24:35 --> Final output sent to browser
DEBUG - 2024-07-16 00:24:35 --> Total execution time: 0.0258
INFO - 2024-07-16 00:24:35 --> Config Class Initialized
INFO - 2024-07-16 00:24:35 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:24:35 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:24:35 --> Utf8 Class Initialized
INFO - 2024-07-16 00:24:35 --> URI Class Initialized
INFO - 2024-07-16 00:24:35 --> Router Class Initialized
INFO - 2024-07-16 00:24:35 --> Output Class Initialized
INFO - 2024-07-16 00:24:35 --> Security Class Initialized
DEBUG - 2024-07-16 00:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:24:35 --> Input Class Initialized
INFO - 2024-07-16 00:24:35 --> Language Class Initialized
ERROR - 2024-07-16 00:24:35 --> 404 Page Not Found: /index
INFO - 2024-07-16 00:55:39 --> Config Class Initialized
INFO - 2024-07-16 00:55:39 --> Hooks Class Initialized
DEBUG - 2024-07-16 00:55:39 --> UTF-8 Support Enabled
INFO - 2024-07-16 00:55:39 --> Utf8 Class Initialized
INFO - 2024-07-16 00:55:39 --> URI Class Initialized
INFO - 2024-07-16 00:55:39 --> Router Class Initialized
INFO - 2024-07-16 00:55:39 --> Output Class Initialized
INFO - 2024-07-16 00:55:39 --> Security Class Initialized
DEBUG - 2024-07-16 00:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-16 00:55:39 --> Input Class Initialized
INFO - 2024-07-16 00:55:39 --> Language Class Initialized
INFO - 2024-07-16 00:55:39 --> Language Class Initialized
INFO - 2024-07-16 00:55:39 --> Config Class Initialized
INFO - 2024-07-16 00:55:39 --> Loader Class Initialized
INFO - 2024-07-16 00:55:39 --> Helper loaded: url_helper
INFO - 2024-07-16 00:55:39 --> Helper loaded: file_helper
INFO - 2024-07-16 00:55:39 --> Helper loaded: form_helper
INFO - 2024-07-16 00:55:39 --> Helper loaded: my_helper
INFO - 2024-07-16 00:55:39 --> Database Driver Class Initialized
INFO - 2024-07-16 00:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-16 00:55:39 --> Controller Class Initialized
DEBUG - 2024-07-16 00:55:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-16 00:55:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-16 00:55:39 --> Final output sent to browser
DEBUG - 2024-07-16 00:55:39 --> Total execution time: 0.0451
