<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-01 06:33:37 --> Config Class Initialized
INFO - 2023-08-01 06:33:37 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:33:37 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:33:37 --> Utf8 Class Initialized
INFO - 2023-08-01 06:33:37 --> URI Class Initialized
DEBUG - 2023-08-01 06:33:37 --> No URI present. Default controller set.
INFO - 2023-08-01 06:33:37 --> Router Class Initialized
INFO - 2023-08-01 06:33:37 --> Output Class Initialized
INFO - 2023-08-01 06:33:37 --> Security Class Initialized
DEBUG - 2023-08-01 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:33:37 --> Input Class Initialized
INFO - 2023-08-01 06:33:37 --> Language Class Initialized
INFO - 2023-08-01 06:33:38 --> Language Class Initialized
INFO - 2023-08-01 06:33:38 --> Config Class Initialized
INFO - 2023-08-01 06:33:38 --> Loader Class Initialized
INFO - 2023-08-01 06:33:38 --> Helper loaded: url_helper
INFO - 2023-08-01 06:33:38 --> Helper loaded: file_helper
INFO - 2023-08-01 06:33:38 --> Helper loaded: form_helper
INFO - 2023-08-01 06:33:38 --> Helper loaded: my_helper
INFO - 2023-08-01 06:33:38 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:33:38 --> Controller Class Initialized
INFO - 2023-08-01 06:33:38 --> Config Class Initialized
INFO - 2023-08-01 06:33:38 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:33:38 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:33:38 --> Utf8 Class Initialized
INFO - 2023-08-01 06:33:38 --> URI Class Initialized
INFO - 2023-08-01 06:33:38 --> Router Class Initialized
INFO - 2023-08-01 06:33:38 --> Output Class Initialized
INFO - 2023-08-01 06:33:38 --> Security Class Initialized
DEBUG - 2023-08-01 06:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:33:38 --> Input Class Initialized
INFO - 2023-08-01 06:33:38 --> Language Class Initialized
INFO - 2023-08-01 06:33:38 --> Language Class Initialized
INFO - 2023-08-01 06:33:38 --> Config Class Initialized
INFO - 2023-08-01 06:33:38 --> Loader Class Initialized
INFO - 2023-08-01 06:33:38 --> Helper loaded: url_helper
INFO - 2023-08-01 06:33:38 --> Helper loaded: file_helper
INFO - 2023-08-01 06:33:38 --> Helper loaded: form_helper
INFO - 2023-08-01 06:33:38 --> Helper loaded: my_helper
INFO - 2023-08-01 06:33:38 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:33:38 --> Controller Class Initialized
DEBUG - 2023-08-01 06:33:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-08-01 06:33:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:33:38 --> Final output sent to browser
DEBUG - 2023-08-01 06:33:38 --> Total execution time: 0.1049
INFO - 2023-08-01 06:33:45 --> Config Class Initialized
INFO - 2023-08-01 06:33:45 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:33:45 --> Utf8 Class Initialized
INFO - 2023-08-01 06:33:45 --> URI Class Initialized
INFO - 2023-08-01 06:33:45 --> Router Class Initialized
INFO - 2023-08-01 06:33:45 --> Output Class Initialized
INFO - 2023-08-01 06:33:45 --> Security Class Initialized
DEBUG - 2023-08-01 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:33:45 --> Input Class Initialized
INFO - 2023-08-01 06:33:45 --> Language Class Initialized
INFO - 2023-08-01 06:33:45 --> Language Class Initialized
INFO - 2023-08-01 06:33:45 --> Config Class Initialized
INFO - 2023-08-01 06:33:45 --> Loader Class Initialized
INFO - 2023-08-01 06:33:45 --> Helper loaded: url_helper
INFO - 2023-08-01 06:33:45 --> Helper loaded: file_helper
INFO - 2023-08-01 06:33:45 --> Helper loaded: form_helper
INFO - 2023-08-01 06:33:45 --> Helper loaded: my_helper
INFO - 2023-08-01 06:33:45 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:33:45 --> Controller Class Initialized
INFO - 2023-08-01 06:33:45 --> Helper loaded: cookie_helper
INFO - 2023-08-01 06:33:45 --> Final output sent to browser
DEBUG - 2023-08-01 06:33:45 --> Total execution time: 0.1315
INFO - 2023-08-01 06:33:45 --> Config Class Initialized
INFO - 2023-08-01 06:33:45 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:33:45 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:33:45 --> Utf8 Class Initialized
INFO - 2023-08-01 06:33:45 --> URI Class Initialized
INFO - 2023-08-01 06:33:45 --> Router Class Initialized
INFO - 2023-08-01 06:33:45 --> Output Class Initialized
INFO - 2023-08-01 06:33:45 --> Security Class Initialized
DEBUG - 2023-08-01 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:33:45 --> Input Class Initialized
INFO - 2023-08-01 06:33:45 --> Language Class Initialized
INFO - 2023-08-01 06:33:45 --> Language Class Initialized
INFO - 2023-08-01 06:33:45 --> Config Class Initialized
INFO - 2023-08-01 06:33:45 --> Loader Class Initialized
INFO - 2023-08-01 06:33:45 --> Helper loaded: url_helper
INFO - 2023-08-01 06:33:45 --> Helper loaded: file_helper
INFO - 2023-08-01 06:33:45 --> Helper loaded: form_helper
INFO - 2023-08-01 06:33:45 --> Helper loaded: my_helper
INFO - 2023-08-01 06:33:45 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:33:45 --> Controller Class Initialized
DEBUG - 2023-08-01 06:33:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 06:33:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:33:46 --> Final output sent to browser
DEBUG - 2023-08-01 06:33:46 --> Total execution time: 0.0880
INFO - 2023-08-01 06:33:47 --> Config Class Initialized
INFO - 2023-08-01 06:33:47 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:33:47 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:33:47 --> Utf8 Class Initialized
INFO - 2023-08-01 06:33:47 --> URI Class Initialized
INFO - 2023-08-01 06:33:47 --> Router Class Initialized
INFO - 2023-08-01 06:33:47 --> Output Class Initialized
INFO - 2023-08-01 06:33:47 --> Security Class Initialized
DEBUG - 2023-08-01 06:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:33:47 --> Input Class Initialized
INFO - 2023-08-01 06:33:47 --> Language Class Initialized
INFO - 2023-08-01 06:33:47 --> Language Class Initialized
INFO - 2023-08-01 06:33:47 --> Config Class Initialized
INFO - 2023-08-01 06:33:47 --> Loader Class Initialized
INFO - 2023-08-01 06:33:47 --> Helper loaded: url_helper
INFO - 2023-08-01 06:33:47 --> Helper loaded: file_helper
INFO - 2023-08-01 06:33:47 --> Helper loaded: form_helper
INFO - 2023-08-01 06:33:47 --> Helper loaded: my_helper
INFO - 2023-08-01 06:33:47 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:33:47 --> Controller Class Initialized
DEBUG - 2023-08-01 06:33:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 06:33:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:33:47 --> Final output sent to browser
DEBUG - 2023-08-01 06:33:47 --> Total execution time: 0.1149
INFO - 2023-08-01 06:33:57 --> Config Class Initialized
INFO - 2023-08-01 06:33:57 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:33:57 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:33:57 --> Utf8 Class Initialized
INFO - 2023-08-01 06:33:57 --> URI Class Initialized
INFO - 2023-08-01 06:33:57 --> Router Class Initialized
INFO - 2023-08-01 06:33:57 --> Output Class Initialized
INFO - 2023-08-01 06:33:57 --> Security Class Initialized
DEBUG - 2023-08-01 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:33:57 --> Input Class Initialized
INFO - 2023-08-01 06:33:57 --> Language Class Initialized
INFO - 2023-08-01 06:33:57 --> Language Class Initialized
INFO - 2023-08-01 06:33:57 --> Config Class Initialized
INFO - 2023-08-01 06:33:57 --> Loader Class Initialized
INFO - 2023-08-01 06:33:57 --> Helper loaded: url_helper
INFO - 2023-08-01 06:33:57 --> Helper loaded: file_helper
INFO - 2023-08-01 06:33:57 --> Helper loaded: form_helper
INFO - 2023-08-01 06:33:57 --> Helper loaded: my_helper
INFO - 2023-08-01 06:33:57 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:33:57 --> Controller Class Initialized
DEBUG - 2023-08-01 06:33:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-08-01 06:33:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:33:57 --> Final output sent to browser
DEBUG - 2023-08-01 06:33:57 --> Total execution time: 0.0879
INFO - 2023-08-01 06:34:05 --> Config Class Initialized
INFO - 2023-08-01 06:34:05 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:34:05 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:34:05 --> Utf8 Class Initialized
INFO - 2023-08-01 06:34:05 --> URI Class Initialized
INFO - 2023-08-01 06:34:05 --> Router Class Initialized
INFO - 2023-08-01 06:34:05 --> Output Class Initialized
INFO - 2023-08-01 06:34:05 --> Security Class Initialized
DEBUG - 2023-08-01 06:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:34:05 --> Input Class Initialized
INFO - 2023-08-01 06:34:05 --> Language Class Initialized
INFO - 2023-08-01 06:34:05 --> Language Class Initialized
INFO - 2023-08-01 06:34:05 --> Config Class Initialized
INFO - 2023-08-01 06:34:05 --> Loader Class Initialized
INFO - 2023-08-01 06:34:05 --> Helper loaded: url_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: file_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: form_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: my_helper
INFO - 2023-08-01 06:34:05 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:34:05 --> Controller Class Initialized
INFO - 2023-08-01 06:34:05 --> Helper loaded: cookie_helper
INFO - 2023-08-01 06:34:05 --> Config Class Initialized
INFO - 2023-08-01 06:34:05 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:34:05 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:34:05 --> Utf8 Class Initialized
INFO - 2023-08-01 06:34:05 --> URI Class Initialized
INFO - 2023-08-01 06:34:05 --> Router Class Initialized
INFO - 2023-08-01 06:34:05 --> Output Class Initialized
INFO - 2023-08-01 06:34:05 --> Security Class Initialized
DEBUG - 2023-08-01 06:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:34:05 --> Input Class Initialized
INFO - 2023-08-01 06:34:05 --> Language Class Initialized
INFO - 2023-08-01 06:34:05 --> Language Class Initialized
INFO - 2023-08-01 06:34:05 --> Config Class Initialized
INFO - 2023-08-01 06:34:05 --> Loader Class Initialized
INFO - 2023-08-01 06:34:05 --> Helper loaded: url_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: file_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: form_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: my_helper
INFO - 2023-08-01 06:34:05 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:34:05 --> Controller Class Initialized
INFO - 2023-08-01 06:34:05 --> Config Class Initialized
INFO - 2023-08-01 06:34:05 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:34:05 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:34:05 --> Utf8 Class Initialized
INFO - 2023-08-01 06:34:05 --> URI Class Initialized
INFO - 2023-08-01 06:34:05 --> Router Class Initialized
INFO - 2023-08-01 06:34:05 --> Output Class Initialized
INFO - 2023-08-01 06:34:05 --> Security Class Initialized
DEBUG - 2023-08-01 06:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:34:05 --> Input Class Initialized
INFO - 2023-08-01 06:34:05 --> Language Class Initialized
INFO - 2023-08-01 06:34:05 --> Language Class Initialized
INFO - 2023-08-01 06:34:05 --> Config Class Initialized
INFO - 2023-08-01 06:34:05 --> Loader Class Initialized
INFO - 2023-08-01 06:34:05 --> Helper loaded: url_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: file_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: form_helper
INFO - 2023-08-01 06:34:05 --> Helper loaded: my_helper
INFO - 2023-08-01 06:34:05 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:34:05 --> Controller Class Initialized
DEBUG - 2023-08-01 06:34:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-08-01 06:34:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:34:05 --> Final output sent to browser
DEBUG - 2023-08-01 06:34:05 --> Total execution time: 0.0449
INFO - 2023-08-01 06:44:22 --> Config Class Initialized
INFO - 2023-08-01 06:44:22 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:44:22 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:44:22 --> Utf8 Class Initialized
INFO - 2023-08-01 06:44:22 --> URI Class Initialized
INFO - 2023-08-01 06:44:22 --> Router Class Initialized
INFO - 2023-08-01 06:44:22 --> Output Class Initialized
INFO - 2023-08-01 06:44:22 --> Security Class Initialized
DEBUG - 2023-08-01 06:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:44:22 --> Input Class Initialized
INFO - 2023-08-01 06:44:22 --> Language Class Initialized
INFO - 2023-08-01 06:44:22 --> Language Class Initialized
INFO - 2023-08-01 06:44:22 --> Config Class Initialized
INFO - 2023-08-01 06:44:22 --> Loader Class Initialized
INFO - 2023-08-01 06:44:22 --> Helper loaded: url_helper
INFO - 2023-08-01 06:44:22 --> Helper loaded: file_helper
INFO - 2023-08-01 06:44:22 --> Helper loaded: form_helper
INFO - 2023-08-01 06:44:22 --> Helper loaded: my_helper
INFO - 2023-08-01 06:44:22 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:44:22 --> Controller Class Initialized
INFO - 2023-08-01 06:44:22 --> Helper loaded: cookie_helper
INFO - 2023-08-01 06:44:22 --> Final output sent to browser
DEBUG - 2023-08-01 06:44:22 --> Total execution time: 0.0560
INFO - 2023-08-01 06:44:22 --> Config Class Initialized
INFO - 2023-08-01 06:44:22 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:44:22 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:44:22 --> Utf8 Class Initialized
INFO - 2023-08-01 06:44:22 --> URI Class Initialized
INFO - 2023-08-01 06:44:22 --> Router Class Initialized
INFO - 2023-08-01 06:44:22 --> Output Class Initialized
INFO - 2023-08-01 06:44:22 --> Security Class Initialized
DEBUG - 2023-08-01 06:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:44:22 --> Input Class Initialized
INFO - 2023-08-01 06:44:22 --> Language Class Initialized
INFO - 2023-08-01 06:44:22 --> Language Class Initialized
INFO - 2023-08-01 06:44:22 --> Config Class Initialized
INFO - 2023-08-01 06:44:22 --> Loader Class Initialized
INFO - 2023-08-01 06:44:22 --> Helper loaded: url_helper
INFO - 2023-08-01 06:44:22 --> Helper loaded: file_helper
INFO - 2023-08-01 06:44:22 --> Helper loaded: form_helper
INFO - 2023-08-01 06:44:22 --> Helper loaded: my_helper
INFO - 2023-08-01 06:44:22 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:44:22 --> Controller Class Initialized
DEBUG - 2023-08-01 06:44:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 06:44:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:44:22 --> Final output sent to browser
DEBUG - 2023-08-01 06:44:22 --> Total execution time: 0.0391
INFO - 2023-08-01 06:44:25 --> Config Class Initialized
INFO - 2023-08-01 06:44:25 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:44:25 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:44:25 --> Utf8 Class Initialized
INFO - 2023-08-01 06:44:25 --> URI Class Initialized
INFO - 2023-08-01 06:44:25 --> Router Class Initialized
INFO - 2023-08-01 06:44:25 --> Output Class Initialized
INFO - 2023-08-01 06:44:25 --> Security Class Initialized
DEBUG - 2023-08-01 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:44:25 --> Input Class Initialized
INFO - 2023-08-01 06:44:25 --> Language Class Initialized
INFO - 2023-08-01 06:44:25 --> Language Class Initialized
INFO - 2023-08-01 06:44:25 --> Config Class Initialized
INFO - 2023-08-01 06:44:25 --> Loader Class Initialized
INFO - 2023-08-01 06:44:25 --> Helper loaded: url_helper
INFO - 2023-08-01 06:44:25 --> Helper loaded: file_helper
INFO - 2023-08-01 06:44:25 --> Helper loaded: form_helper
INFO - 2023-08-01 06:44:25 --> Helper loaded: my_helper
INFO - 2023-08-01 06:44:25 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:44:25 --> Controller Class Initialized
DEBUG - 2023-08-01 06:44:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 06:44:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:44:25 --> Final output sent to browser
DEBUG - 2023-08-01 06:44:25 --> Total execution time: 0.0312
INFO - 2023-08-01 06:48:32 --> Config Class Initialized
INFO - 2023-08-01 06:48:32 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:32 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:32 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:32 --> URI Class Initialized
INFO - 2023-08-01 06:48:32 --> Router Class Initialized
INFO - 2023-08-01 06:48:32 --> Output Class Initialized
INFO - 2023-08-01 06:48:32 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:32 --> Input Class Initialized
INFO - 2023-08-01 06:48:32 --> Language Class Initialized
INFO - 2023-08-01 06:48:32 --> Language Class Initialized
INFO - 2023-08-01 06:48:32 --> Config Class Initialized
INFO - 2023-08-01 06:48:32 --> Loader Class Initialized
INFO - 2023-08-01 06:48:32 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:32 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:32 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:32 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:32 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:32 --> Controller Class Initialized
DEBUG - 2023-08-01 06:48:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-08-01 06:48:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:48:32 --> Final output sent to browser
DEBUG - 2023-08-01 06:48:32 --> Total execution time: 0.1319
INFO - 2023-08-01 06:48:34 --> Config Class Initialized
INFO - 2023-08-01 06:48:34 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:34 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:34 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:34 --> URI Class Initialized
INFO - 2023-08-01 06:48:34 --> Router Class Initialized
INFO - 2023-08-01 06:48:34 --> Output Class Initialized
INFO - 2023-08-01 06:48:34 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:34 --> Input Class Initialized
INFO - 2023-08-01 06:48:34 --> Language Class Initialized
INFO - 2023-08-01 06:48:34 --> Language Class Initialized
INFO - 2023-08-01 06:48:34 --> Config Class Initialized
INFO - 2023-08-01 06:48:34 --> Loader Class Initialized
INFO - 2023-08-01 06:48:34 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:34 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:34 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:34 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:34 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:34 --> Controller Class Initialized
DEBUG - 2023-08-01 06:48:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 06:48:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:48:34 --> Final output sent to browser
DEBUG - 2023-08-01 06:48:34 --> Total execution time: 0.0481
INFO - 2023-08-01 06:48:36 --> Config Class Initialized
INFO - 2023-08-01 06:48:36 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:36 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:36 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:36 --> URI Class Initialized
INFO - 2023-08-01 06:48:36 --> Router Class Initialized
INFO - 2023-08-01 06:48:36 --> Output Class Initialized
INFO - 2023-08-01 06:48:36 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:36 --> Input Class Initialized
INFO - 2023-08-01 06:48:36 --> Language Class Initialized
INFO - 2023-08-01 06:48:36 --> Language Class Initialized
INFO - 2023-08-01 06:48:36 --> Config Class Initialized
INFO - 2023-08-01 06:48:36 --> Loader Class Initialized
INFO - 2023-08-01 06:48:36 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:36 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:36 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:36 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:36 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:36 --> Controller Class Initialized
DEBUG - 2023-08-01 06:48:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-01 06:48:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:48:36 --> Final output sent to browser
DEBUG - 2023-08-01 06:48:36 --> Total execution time: 0.1206
INFO - 2023-08-01 06:48:39 --> Config Class Initialized
INFO - 2023-08-01 06:48:39 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:39 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:39 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:39 --> URI Class Initialized
INFO - 2023-08-01 06:48:39 --> Router Class Initialized
INFO - 2023-08-01 06:48:39 --> Output Class Initialized
INFO - 2023-08-01 06:48:39 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:39 --> Input Class Initialized
INFO - 2023-08-01 06:48:39 --> Language Class Initialized
INFO - 2023-08-01 06:48:39 --> Language Class Initialized
INFO - 2023-08-01 06:48:39 --> Config Class Initialized
INFO - 2023-08-01 06:48:39 --> Loader Class Initialized
INFO - 2023-08-01 06:48:39 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:39 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:39 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:39 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:39 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:39 --> Controller Class Initialized
DEBUG - 2023-08-01 06:48:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 06:48:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:48:39 --> Final output sent to browser
DEBUG - 2023-08-01 06:48:39 --> Total execution time: 0.0274
INFO - 2023-08-01 06:48:47 --> Config Class Initialized
INFO - 2023-08-01 06:48:47 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:47 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:47 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:47 --> URI Class Initialized
INFO - 2023-08-01 06:48:47 --> Router Class Initialized
INFO - 2023-08-01 06:48:47 --> Output Class Initialized
INFO - 2023-08-01 06:48:47 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:47 --> Input Class Initialized
INFO - 2023-08-01 06:48:47 --> Language Class Initialized
INFO - 2023-08-01 06:48:47 --> Language Class Initialized
INFO - 2023-08-01 06:48:47 --> Config Class Initialized
INFO - 2023-08-01 06:48:47 --> Loader Class Initialized
INFO - 2023-08-01 06:48:47 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:47 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:47 --> Controller Class Initialized
INFO - 2023-08-01 06:48:47 --> Helper loaded: cookie_helper
INFO - 2023-08-01 06:48:47 --> Config Class Initialized
INFO - 2023-08-01 06:48:47 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:47 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:47 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:47 --> URI Class Initialized
INFO - 2023-08-01 06:48:47 --> Router Class Initialized
INFO - 2023-08-01 06:48:47 --> Output Class Initialized
INFO - 2023-08-01 06:48:47 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:47 --> Input Class Initialized
INFO - 2023-08-01 06:48:47 --> Language Class Initialized
INFO - 2023-08-01 06:48:47 --> Language Class Initialized
INFO - 2023-08-01 06:48:47 --> Config Class Initialized
INFO - 2023-08-01 06:48:47 --> Loader Class Initialized
INFO - 2023-08-01 06:48:47 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:47 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:47 --> Controller Class Initialized
INFO - 2023-08-01 06:48:47 --> Config Class Initialized
INFO - 2023-08-01 06:48:47 --> Hooks Class Initialized
DEBUG - 2023-08-01 06:48:47 --> UTF-8 Support Enabled
INFO - 2023-08-01 06:48:47 --> Utf8 Class Initialized
INFO - 2023-08-01 06:48:47 --> URI Class Initialized
INFO - 2023-08-01 06:48:47 --> Router Class Initialized
INFO - 2023-08-01 06:48:47 --> Output Class Initialized
INFO - 2023-08-01 06:48:47 --> Security Class Initialized
DEBUG - 2023-08-01 06:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 06:48:47 --> Input Class Initialized
INFO - 2023-08-01 06:48:47 --> Language Class Initialized
INFO - 2023-08-01 06:48:47 --> Language Class Initialized
INFO - 2023-08-01 06:48:47 --> Config Class Initialized
INFO - 2023-08-01 06:48:47 --> Loader Class Initialized
INFO - 2023-08-01 06:48:47 --> Helper loaded: url_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: file_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: form_helper
INFO - 2023-08-01 06:48:47 --> Helper loaded: my_helper
INFO - 2023-08-01 06:48:47 --> Database Driver Class Initialized
DEBUG - 2023-08-01 06:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 06:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 06:48:47 --> Controller Class Initialized
DEBUG - 2023-08-01 06:48:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-08-01 06:48:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-08-01 06:48:47 --> Final output sent to browser
DEBUG - 2023-08-01 06:48:47 --> Total execution time: 0.0230
INFO - 2023-08-01 08:09:02 --> Config Class Initialized
INFO - 2023-08-01 08:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:02 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:02 --> URI Class Initialized
DEBUG - 2023-08-01 08:09:02 --> No URI present. Default controller set.
INFO - 2023-08-01 08:09:02 --> Router Class Initialized
INFO - 2023-08-01 08:09:02 --> Output Class Initialized
INFO - 2023-08-01 08:09:02 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:02 --> Input Class Initialized
INFO - 2023-08-01 08:09:02 --> Language Class Initialized
INFO - 2023-08-01 08:09:02 --> Language Class Initialized
INFO - 2023-08-01 08:09:02 --> Config Class Initialized
INFO - 2023-08-01 08:09:02 --> Loader Class Initialized
INFO - 2023-08-01 08:09:02 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:02 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:02 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:02 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:02 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:02 --> Controller Class Initialized
INFO - 2023-08-01 08:09:02 --> Config Class Initialized
INFO - 2023-08-01 08:09:02 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:02 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:02 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:02 --> URI Class Initialized
INFO - 2023-08-01 08:09:02 --> Router Class Initialized
INFO - 2023-08-01 08:09:02 --> Output Class Initialized
INFO - 2023-08-01 08:09:02 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:02 --> Input Class Initialized
INFO - 2023-08-01 08:09:02 --> Language Class Initialized
INFO - 2023-08-01 08:09:02 --> Language Class Initialized
INFO - 2023-08-01 08:09:02 --> Config Class Initialized
INFO - 2023-08-01 08:09:02 --> Loader Class Initialized
INFO - 2023-08-01 08:09:02 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:02 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:02 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:02 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:02 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:02 --> Controller Class Initialized
DEBUG - 2023-08-01 08:09:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-01 08:09:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:09:02 --> Final output sent to browser
DEBUG - 2023-08-01 08:09:02 --> Total execution time: 0.0235
INFO - 2023-08-01 08:09:07 --> Config Class Initialized
INFO - 2023-08-01 08:09:07 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:07 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:07 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:07 --> URI Class Initialized
INFO - 2023-08-01 08:09:07 --> Router Class Initialized
INFO - 2023-08-01 08:09:07 --> Output Class Initialized
INFO - 2023-08-01 08:09:07 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:07 --> Input Class Initialized
INFO - 2023-08-01 08:09:07 --> Language Class Initialized
INFO - 2023-08-01 08:09:07 --> Language Class Initialized
INFO - 2023-08-01 08:09:07 --> Config Class Initialized
INFO - 2023-08-01 08:09:07 --> Loader Class Initialized
INFO - 2023-08-01 08:09:07 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:07 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:07 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:07 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:07 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:07 --> Controller Class Initialized
INFO - 2023-08-01 08:09:07 --> Helper loaded: cookie_helper
INFO - 2023-08-01 08:09:07 --> Final output sent to browser
DEBUG - 2023-08-01 08:09:07 --> Total execution time: 0.0293
INFO - 2023-08-01 08:09:07 --> Config Class Initialized
INFO - 2023-08-01 08:09:07 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:08 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:08 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:08 --> URI Class Initialized
INFO - 2023-08-01 08:09:08 --> Router Class Initialized
INFO - 2023-08-01 08:09:08 --> Output Class Initialized
INFO - 2023-08-01 08:09:08 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:08 --> Input Class Initialized
INFO - 2023-08-01 08:09:08 --> Language Class Initialized
INFO - 2023-08-01 08:09:08 --> Language Class Initialized
INFO - 2023-08-01 08:09:08 --> Config Class Initialized
INFO - 2023-08-01 08:09:08 --> Loader Class Initialized
INFO - 2023-08-01 08:09:08 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:08 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:08 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:08 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:08 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:08 --> Controller Class Initialized
DEBUG - 2023-08-01 08:09:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-08-01 08:09:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:09:08 --> Final output sent to browser
DEBUG - 2023-08-01 08:09:08 --> Total execution time: 0.0327
INFO - 2023-08-01 08:09:12 --> Config Class Initialized
INFO - 2023-08-01 08:09:12 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:12 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:12 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:12 --> URI Class Initialized
INFO - 2023-08-01 08:09:12 --> Router Class Initialized
INFO - 2023-08-01 08:09:12 --> Output Class Initialized
INFO - 2023-08-01 08:09:12 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:12 --> Input Class Initialized
INFO - 2023-08-01 08:09:12 --> Language Class Initialized
INFO - 2023-08-01 08:09:12 --> Language Class Initialized
INFO - 2023-08-01 08:09:12 --> Config Class Initialized
INFO - 2023-08-01 08:09:12 --> Loader Class Initialized
INFO - 2023-08-01 08:09:12 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:12 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:12 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:12 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:12 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:12 --> Controller Class Initialized
DEBUG - 2023-08-01 08:09:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-01 08:09:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:09:12 --> Final output sent to browser
DEBUG - 2023-08-01 08:09:12 --> Total execution time: 0.0286
INFO - 2023-08-01 08:09:12 --> Config Class Initialized
INFO - 2023-08-01 08:09:12 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:12 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:12 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:12 --> URI Class Initialized
INFO - 2023-08-01 08:09:12 --> Router Class Initialized
INFO - 2023-08-01 08:09:12 --> Output Class Initialized
INFO - 2023-08-01 08:09:12 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:12 --> Input Class Initialized
INFO - 2023-08-01 08:09:12 --> Language Class Initialized
INFO - 2023-08-01 08:09:12 --> Language Class Initialized
INFO - 2023-08-01 08:09:12 --> Config Class Initialized
INFO - 2023-08-01 08:09:12 --> Loader Class Initialized
INFO - 2023-08-01 08:09:12 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:12 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:12 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:12 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:12 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:12 --> Controller Class Initialized
INFO - 2023-08-01 08:09:13 --> Config Class Initialized
INFO - 2023-08-01 08:09:13 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:13 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:13 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:13 --> URI Class Initialized
INFO - 2023-08-01 08:09:13 --> Router Class Initialized
INFO - 2023-08-01 08:09:13 --> Output Class Initialized
INFO - 2023-08-01 08:09:13 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:13 --> Input Class Initialized
INFO - 2023-08-01 08:09:13 --> Language Class Initialized
INFO - 2023-08-01 08:09:13 --> Language Class Initialized
INFO - 2023-08-01 08:09:13 --> Config Class Initialized
INFO - 2023-08-01 08:09:13 --> Loader Class Initialized
INFO - 2023-08-01 08:09:13 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:13 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:13 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:13 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:13 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:13 --> Controller Class Initialized
INFO - 2023-08-01 08:09:13 --> Final output sent to browser
DEBUG - 2023-08-01 08:09:13 --> Total execution time: 0.0448
INFO - 2023-08-01 08:09:43 --> Config Class Initialized
INFO - 2023-08-01 08:09:43 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:43 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:43 --> URI Class Initialized
INFO - 2023-08-01 08:09:43 --> Router Class Initialized
INFO - 2023-08-01 08:09:43 --> Output Class Initialized
INFO - 2023-08-01 08:09:43 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:43 --> Input Class Initialized
INFO - 2023-08-01 08:09:43 --> Language Class Initialized
INFO - 2023-08-01 08:09:43 --> Language Class Initialized
INFO - 2023-08-01 08:09:43 --> Config Class Initialized
INFO - 2023-08-01 08:09:43 --> Loader Class Initialized
INFO - 2023-08-01 08:09:43 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:43 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:43 --> Controller Class Initialized
INFO - 2023-08-01 08:09:43 --> Helper loaded: cookie_helper
INFO - 2023-08-01 08:09:43 --> Config Class Initialized
INFO - 2023-08-01 08:09:43 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:43 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:43 --> URI Class Initialized
INFO - 2023-08-01 08:09:43 --> Router Class Initialized
INFO - 2023-08-01 08:09:43 --> Output Class Initialized
INFO - 2023-08-01 08:09:43 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:43 --> Input Class Initialized
INFO - 2023-08-01 08:09:43 --> Language Class Initialized
INFO - 2023-08-01 08:09:43 --> Language Class Initialized
INFO - 2023-08-01 08:09:43 --> Config Class Initialized
INFO - 2023-08-01 08:09:43 --> Loader Class Initialized
INFO - 2023-08-01 08:09:43 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:43 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:43 --> Controller Class Initialized
INFO - 2023-08-01 08:09:43 --> Config Class Initialized
INFO - 2023-08-01 08:09:43 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:09:43 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:09:43 --> Utf8 Class Initialized
INFO - 2023-08-01 08:09:43 --> URI Class Initialized
INFO - 2023-08-01 08:09:43 --> Router Class Initialized
INFO - 2023-08-01 08:09:43 --> Output Class Initialized
INFO - 2023-08-01 08:09:43 --> Security Class Initialized
DEBUG - 2023-08-01 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:09:43 --> Input Class Initialized
INFO - 2023-08-01 08:09:43 --> Language Class Initialized
INFO - 2023-08-01 08:09:43 --> Language Class Initialized
INFO - 2023-08-01 08:09:43 --> Config Class Initialized
INFO - 2023-08-01 08:09:43 --> Loader Class Initialized
INFO - 2023-08-01 08:09:43 --> Helper loaded: url_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: file_helper
INFO - 2023-08-01 08:09:43 --> Helper loaded: form_helper
INFO - 2023-08-01 08:09:44 --> Helper loaded: my_helper
INFO - 2023-08-01 08:09:44 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:09:44 --> Controller Class Initialized
DEBUG - 2023-08-01 08:09:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-01 08:09:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:09:44 --> Final output sent to browser
DEBUG - 2023-08-01 08:09:44 --> Total execution time: 0.0264
INFO - 2023-08-01 08:10:10 --> Config Class Initialized
INFO - 2023-08-01 08:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:10:10 --> Utf8 Class Initialized
INFO - 2023-08-01 08:10:10 --> URI Class Initialized
DEBUG - 2023-08-01 08:10:10 --> No URI present. Default controller set.
INFO - 2023-08-01 08:10:10 --> Router Class Initialized
INFO - 2023-08-01 08:10:10 --> Output Class Initialized
INFO - 2023-08-01 08:10:10 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:10 --> Input Class Initialized
INFO - 2023-08-01 08:10:10 --> Language Class Initialized
INFO - 2023-08-01 08:10:10 --> Language Class Initialized
INFO - 2023-08-01 08:10:10 --> Config Class Initialized
INFO - 2023-08-01 08:10:10 --> Loader Class Initialized
INFO - 2023-08-01 08:10:10 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:10 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:10 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:10 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:10 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:10 --> Controller Class Initialized
INFO - 2023-08-01 08:10:10 --> Config Class Initialized
INFO - 2023-08-01 08:10:10 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:10:10 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:10:10 --> Utf8 Class Initialized
INFO - 2023-08-01 08:10:10 --> URI Class Initialized
INFO - 2023-08-01 08:10:10 --> Router Class Initialized
INFO - 2023-08-01 08:10:10 --> Output Class Initialized
INFO - 2023-08-01 08:10:10 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:10 --> Input Class Initialized
INFO - 2023-08-01 08:10:10 --> Language Class Initialized
INFO - 2023-08-01 08:10:10 --> Language Class Initialized
INFO - 2023-08-01 08:10:10 --> Config Class Initialized
INFO - 2023-08-01 08:10:10 --> Loader Class Initialized
INFO - 2023-08-01 08:10:10 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:10 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:10 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:10 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:10 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:10 --> Controller Class Initialized
DEBUG - 2023-08-01 08:10:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-01 08:10:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:10:10 --> Final output sent to browser
DEBUG - 2023-08-01 08:10:10 --> Total execution time: 0.0268
INFO - 2023-08-01 08:10:13 --> Config Class Initialized
INFO - 2023-08-01 08:10:13 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:10:13 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:10:13 --> Utf8 Class Initialized
INFO - 2023-08-01 08:10:13 --> URI Class Initialized
INFO - 2023-08-01 08:10:13 --> Router Class Initialized
INFO - 2023-08-01 08:10:13 --> Output Class Initialized
INFO - 2023-08-01 08:10:13 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:13 --> Input Class Initialized
INFO - 2023-08-01 08:10:13 --> Language Class Initialized
INFO - 2023-08-01 08:10:13 --> Language Class Initialized
INFO - 2023-08-01 08:10:13 --> Config Class Initialized
INFO - 2023-08-01 08:10:13 --> Loader Class Initialized
INFO - 2023-08-01 08:10:13 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:13 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:13 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:13 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:13 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:13 --> Controller Class Initialized
INFO - 2023-08-01 08:10:13 --> Helper loaded: cookie_helper
INFO - 2023-08-01 08:10:13 --> Final output sent to browser
DEBUG - 2023-08-01 08:10:13 --> Total execution time: 0.0264
INFO - 2023-08-01 08:10:13 --> Router Class Initialized
INFO - 2023-08-01 08:10:13 --> Output Class Initialized
INFO - 2023-08-01 08:10:13 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:13 --> Input Class Initialized
INFO - 2023-08-01 08:10:13 --> Language Class Initialized
INFO - 2023-08-01 08:10:13 --> Language Class Initialized
INFO - 2023-08-01 08:10:13 --> Config Class Initialized
INFO - 2023-08-01 08:10:13 --> Loader Class Initialized
INFO - 2023-08-01 08:10:13 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:13 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:13 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:13 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:13 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:13 --> Controller Class Initialized
DEBUG - 2023-08-01 08:10:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-08-01 08:10:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:10:13 --> Final output sent to browser
DEBUG - 2023-08-01 08:10:13 --> Total execution time: 0.0284
INFO - 2023-08-01 08:10:28 --> Config Class Initialized
INFO - 2023-08-01 08:10:28 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:10:28 --> Utf8 Class Initialized
INFO - 2023-08-01 08:10:28 --> URI Class Initialized
INFO - 2023-08-01 08:10:28 --> Router Class Initialized
INFO - 2023-08-01 08:10:28 --> Output Class Initialized
INFO - 2023-08-01 08:10:28 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:28 --> Input Class Initialized
INFO - 2023-08-01 08:10:28 --> Language Class Initialized
INFO - 2023-08-01 08:10:28 --> Language Class Initialized
INFO - 2023-08-01 08:10:28 --> Config Class Initialized
INFO - 2023-08-01 08:10:28 --> Loader Class Initialized
INFO - 2023-08-01 08:10:28 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:28 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:28 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:28 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:28 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:28 --> Controller Class Initialized
DEBUG - 2023-08-01 08:10:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-01 08:10:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:10:28 --> Final output sent to browser
DEBUG - 2023-08-01 08:10:28 --> Total execution time: 0.0308
INFO - 2023-08-01 08:10:28 --> Config Class Initialized
INFO - 2023-08-01 08:10:28 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:10:28 --> Utf8 Class Initialized
INFO - 2023-08-01 08:10:28 --> URI Class Initialized
INFO - 2023-08-01 08:10:28 --> Router Class Initialized
INFO - 2023-08-01 08:10:28 --> Output Class Initialized
INFO - 2023-08-01 08:10:28 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:28 --> Input Class Initialized
INFO - 2023-08-01 08:10:28 --> Language Class Initialized
INFO - 2023-08-01 08:10:28 --> Language Class Initialized
INFO - 2023-08-01 08:10:28 --> Config Class Initialized
INFO - 2023-08-01 08:10:28 --> Loader Class Initialized
INFO - 2023-08-01 08:10:28 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:28 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:28 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:28 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:28 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:28 --> Controller Class Initialized
INFO - 2023-08-01 08:10:29 --> Config Class Initialized
INFO - 2023-08-01 08:10:29 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:10:29 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:10:29 --> Utf8 Class Initialized
INFO - 2023-08-01 08:10:29 --> URI Class Initialized
INFO - 2023-08-01 08:10:29 --> Router Class Initialized
INFO - 2023-08-01 08:10:29 --> Output Class Initialized
INFO - 2023-08-01 08:10:29 --> Security Class Initialized
DEBUG - 2023-08-01 08:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:10:29 --> Input Class Initialized
INFO - 2023-08-01 08:10:29 --> Language Class Initialized
INFO - 2023-08-01 08:10:29 --> Language Class Initialized
INFO - 2023-08-01 08:10:29 --> Config Class Initialized
INFO - 2023-08-01 08:10:29 --> Loader Class Initialized
INFO - 2023-08-01 08:10:29 --> Helper loaded: url_helper
INFO - 2023-08-01 08:10:29 --> Helper loaded: file_helper
INFO - 2023-08-01 08:10:29 --> Helper loaded: form_helper
INFO - 2023-08-01 08:10:29 --> Helper loaded: my_helper
INFO - 2023-08-01 08:10:29 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:10:29 --> Controller Class Initialized
INFO - 2023-08-01 08:10:29 --> Final output sent to browser
DEBUG - 2023-08-01 08:10:29 --> Total execution time: 0.0296
INFO - 2023-08-01 08:11:03 --> Config Class Initialized
INFO - 2023-08-01 08:11:03 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:03 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:03 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:03 --> URI Class Initialized
INFO - 2023-08-01 08:11:03 --> Router Class Initialized
INFO - 2023-08-01 08:11:03 --> Output Class Initialized
INFO - 2023-08-01 08:11:03 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:03 --> Input Class Initialized
INFO - 2023-08-01 08:11:03 --> Language Class Initialized
INFO - 2023-08-01 08:11:03 --> Language Class Initialized
INFO - 2023-08-01 08:11:03 --> Config Class Initialized
INFO - 2023-08-01 08:11:03 --> Loader Class Initialized
INFO - 2023-08-01 08:11:03 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:03 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:03 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:03 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:03 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:03 --> Controller Class Initialized
DEBUG - 2023-08-01 08:11:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-01 08:11:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:11:03 --> Final output sent to browser
DEBUG - 2023-08-01 08:11:03 --> Total execution time: 0.0572
INFO - 2023-08-01 08:11:03 --> Config Class Initialized
INFO - 2023-08-01 08:11:03 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:03 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:03 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:03 --> URI Class Initialized
INFO - 2023-08-01 08:11:03 --> Router Class Initialized
INFO - 2023-08-01 08:11:03 --> Output Class Initialized
INFO - 2023-08-01 08:11:03 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:03 --> Input Class Initialized
INFO - 2023-08-01 08:11:03 --> Language Class Initialized
INFO - 2023-08-01 08:11:03 --> Language Class Initialized
INFO - 2023-08-01 08:11:03 --> Config Class Initialized
INFO - 2023-08-01 08:11:03 --> Loader Class Initialized
INFO - 2023-08-01 08:11:03 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:03 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:03 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:03 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:03 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:03 --> Controller Class Initialized
INFO - 2023-08-01 08:11:04 --> Config Class Initialized
INFO - 2023-08-01 08:11:04 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:04 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:04 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:04 --> URI Class Initialized
INFO - 2023-08-01 08:11:04 --> Router Class Initialized
INFO - 2023-08-01 08:11:04 --> Output Class Initialized
INFO - 2023-08-01 08:11:04 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:04 --> Input Class Initialized
INFO - 2023-08-01 08:11:04 --> Language Class Initialized
INFO - 2023-08-01 08:11:04 --> Language Class Initialized
INFO - 2023-08-01 08:11:04 --> Config Class Initialized
INFO - 2023-08-01 08:11:04 --> Loader Class Initialized
INFO - 2023-08-01 08:11:04 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:04 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:04 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:04 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:04 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:04 --> Controller Class Initialized
INFO - 2023-08-01 08:11:04 --> Final output sent to browser
DEBUG - 2023-08-01 08:11:04 --> Total execution time: 0.0457
INFO - 2023-08-01 08:11:12 --> Config Class Initialized
INFO - 2023-08-01 08:11:12 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:12 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:12 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:12 --> URI Class Initialized
INFO - 2023-08-01 08:11:12 --> Router Class Initialized
INFO - 2023-08-01 08:11:12 --> Output Class Initialized
INFO - 2023-08-01 08:11:12 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:12 --> Input Class Initialized
INFO - 2023-08-01 08:11:12 --> Language Class Initialized
INFO - 2023-08-01 08:11:12 --> Language Class Initialized
INFO - 2023-08-01 08:11:12 --> Config Class Initialized
INFO - 2023-08-01 08:11:12 --> Loader Class Initialized
INFO - 2023-08-01 08:11:12 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:12 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:12 --> Controller Class Initialized
INFO - 2023-08-01 08:11:12 --> Helper loaded: cookie_helper
INFO - 2023-08-01 08:11:12 --> Config Class Initialized
INFO - 2023-08-01 08:11:12 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:12 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:12 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:12 --> URI Class Initialized
INFO - 2023-08-01 08:11:12 --> Router Class Initialized
INFO - 2023-08-01 08:11:12 --> Output Class Initialized
INFO - 2023-08-01 08:11:12 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:12 --> Input Class Initialized
INFO - 2023-08-01 08:11:12 --> Language Class Initialized
INFO - 2023-08-01 08:11:12 --> Language Class Initialized
INFO - 2023-08-01 08:11:12 --> Config Class Initialized
INFO - 2023-08-01 08:11:12 --> Loader Class Initialized
INFO - 2023-08-01 08:11:12 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:12 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:12 --> Controller Class Initialized
INFO - 2023-08-01 08:11:12 --> Config Class Initialized
INFO - 2023-08-01 08:11:12 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:12 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:12 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:12 --> URI Class Initialized
INFO - 2023-08-01 08:11:12 --> Router Class Initialized
INFO - 2023-08-01 08:11:12 --> Output Class Initialized
INFO - 2023-08-01 08:11:12 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:12 --> Input Class Initialized
INFO - 2023-08-01 08:11:12 --> Language Class Initialized
INFO - 2023-08-01 08:11:12 --> Language Class Initialized
INFO - 2023-08-01 08:11:12 --> Config Class Initialized
INFO - 2023-08-01 08:11:12 --> Loader Class Initialized
INFO - 2023-08-01 08:11:12 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:12 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:12 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:13 --> Controller Class Initialized
DEBUG - 2023-08-01 08:11:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-01 08:11:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:11:13 --> Final output sent to browser
DEBUG - 2023-08-01 08:11:13 --> Total execution time: 0.0419
INFO - 2023-08-01 08:11:18 --> Config Class Initialized
INFO - 2023-08-01 08:11:18 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:18 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:18 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:18 --> URI Class Initialized
INFO - 2023-08-01 08:11:18 --> Router Class Initialized
INFO - 2023-08-01 08:11:18 --> Output Class Initialized
INFO - 2023-08-01 08:11:18 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:18 --> Input Class Initialized
INFO - 2023-08-01 08:11:18 --> Language Class Initialized
INFO - 2023-08-01 08:11:18 --> Language Class Initialized
INFO - 2023-08-01 08:11:18 --> Config Class Initialized
INFO - 2023-08-01 08:11:18 --> Loader Class Initialized
INFO - 2023-08-01 08:11:18 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:18 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:18 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:18 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:18 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:18 --> Controller Class Initialized
INFO - 2023-08-01 08:11:18 --> Final output sent to browser
DEBUG - 2023-08-01 08:11:18 --> Total execution time: 0.0340
INFO - 2023-08-01 08:11:21 --> Config Class Initialized
INFO - 2023-08-01 08:11:21 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:21 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:21 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:21 --> URI Class Initialized
INFO - 2023-08-01 08:11:21 --> Router Class Initialized
INFO - 2023-08-01 08:11:21 --> Output Class Initialized
INFO - 2023-08-01 08:11:21 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:21 --> Input Class Initialized
INFO - 2023-08-01 08:11:21 --> Language Class Initialized
INFO - 2023-08-01 08:11:21 --> Language Class Initialized
INFO - 2023-08-01 08:11:21 --> Config Class Initialized
INFO - 2023-08-01 08:11:21 --> Loader Class Initialized
INFO - 2023-08-01 08:11:21 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:21 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:21 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:21 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:21 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:21 --> Controller Class Initialized
INFO - 2023-08-01 08:11:21 --> Helper loaded: cookie_helper
INFO - 2023-08-01 08:11:21 --> Final output sent to browser
DEBUG - 2023-08-01 08:11:21 --> Total execution time: 0.0346
INFO - 2023-08-01 08:11:21 --> Config Class Initialized
INFO - 2023-08-01 08:11:21 --> Hooks Class Initialized
DEBUG - 2023-08-01 08:11:21 --> UTF-8 Support Enabled
INFO - 2023-08-01 08:11:21 --> Utf8 Class Initialized
INFO - 2023-08-01 08:11:21 --> URI Class Initialized
INFO - 2023-08-01 08:11:21 --> Router Class Initialized
INFO - 2023-08-01 08:11:21 --> Output Class Initialized
INFO - 2023-08-01 08:11:21 --> Security Class Initialized
DEBUG - 2023-08-01 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 08:11:21 --> Input Class Initialized
INFO - 2023-08-01 08:11:21 --> Language Class Initialized
INFO - 2023-08-01 08:11:21 --> Language Class Initialized
INFO - 2023-08-01 08:11:21 --> Config Class Initialized
INFO - 2023-08-01 08:11:21 --> Loader Class Initialized
INFO - 2023-08-01 08:11:21 --> Helper loaded: url_helper
INFO - 2023-08-01 08:11:21 --> Helper loaded: file_helper
INFO - 2023-08-01 08:11:21 --> Helper loaded: form_helper
INFO - 2023-08-01 08:11:21 --> Helper loaded: my_helper
INFO - 2023-08-01 08:11:21 --> Database Driver Class Initialized
DEBUG - 2023-08-01 08:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 08:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 08:11:21 --> Controller Class Initialized
DEBUG - 2023-08-01 08:11:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 08:11:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 08:11:21 --> Final output sent to browser
DEBUG - 2023-08-01 08:11:21 --> Total execution time: 0.0318
INFO - 2023-08-01 09:05:35 --> Config Class Initialized
INFO - 2023-08-01 09:05:35 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:35 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:35 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:35 --> URI Class Initialized
INFO - 2023-08-01 09:05:35 --> Router Class Initialized
INFO - 2023-08-01 09:05:35 --> Output Class Initialized
INFO - 2023-08-01 09:05:35 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:35 --> Input Class Initialized
INFO - 2023-08-01 09:05:35 --> Language Class Initialized
INFO - 2023-08-01 09:05:35 --> Language Class Initialized
INFO - 2023-08-01 09:05:35 --> Config Class Initialized
INFO - 2023-08-01 09:05:35 --> Loader Class Initialized
INFO - 2023-08-01 09:05:35 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:35 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:35 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:35 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:35 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:35 --> Controller Class Initialized
DEBUG - 2023-08-01 09:05:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 09:05:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:05:35 --> Final output sent to browser
DEBUG - 2023-08-01 09:05:35 --> Total execution time: 0.1164
INFO - 2023-08-01 09:05:43 --> Config Class Initialized
INFO - 2023-08-01 09:05:43 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:43 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:43 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:43 --> URI Class Initialized
INFO - 2023-08-01 09:05:43 --> Router Class Initialized
INFO - 2023-08-01 09:05:43 --> Output Class Initialized
INFO - 2023-08-01 09:05:43 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:43 --> Input Class Initialized
INFO - 2023-08-01 09:05:43 --> Language Class Initialized
INFO - 2023-08-01 09:05:43 --> Language Class Initialized
INFO - 2023-08-01 09:05:43 --> Config Class Initialized
INFO - 2023-08-01 09:05:43 --> Loader Class Initialized
INFO - 2023-08-01 09:05:43 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:43 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:43 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:43 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:43 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:43 --> Controller Class Initialized
DEBUG - 2023-08-01 09:05:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_absensi/views/list.php
DEBUG - 2023-08-01 09:05:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:05:43 --> Final output sent to browser
DEBUG - 2023-08-01 09:05:43 --> Total execution time: 0.0387
INFO - 2023-08-01 09:05:45 --> Config Class Initialized
INFO - 2023-08-01 09:05:45 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:45 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:45 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:45 --> URI Class Initialized
INFO - 2023-08-01 09:05:45 --> Router Class Initialized
INFO - 2023-08-01 09:05:45 --> Output Class Initialized
INFO - 2023-08-01 09:05:45 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:45 --> Input Class Initialized
INFO - 2023-08-01 09:05:45 --> Language Class Initialized
INFO - 2023-08-01 09:05:45 --> Language Class Initialized
INFO - 2023-08-01 09:05:45 --> Config Class Initialized
INFO - 2023-08-01 09:05:45 --> Loader Class Initialized
INFO - 2023-08-01 09:05:45 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:45 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:45 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:45 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:45 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:45 --> Controller Class Initialized
DEBUG - 2023-08-01 09:05:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 09:05:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:05:45 --> Final output sent to browser
DEBUG - 2023-08-01 09:05:45 --> Total execution time: 0.0318
INFO - 2023-08-01 09:05:46 --> Config Class Initialized
INFO - 2023-08-01 09:05:46 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:46 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:46 --> URI Class Initialized
DEBUG - 2023-08-01 09:05:46 --> No URI present. Default controller set.
INFO - 2023-08-01 09:05:46 --> Router Class Initialized
INFO - 2023-08-01 09:05:46 --> Output Class Initialized
INFO - 2023-08-01 09:05:46 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:46 --> Input Class Initialized
INFO - 2023-08-01 09:05:46 --> Language Class Initialized
INFO - 2023-08-01 09:05:46 --> Language Class Initialized
INFO - 2023-08-01 09:05:46 --> Config Class Initialized
INFO - 2023-08-01 09:05:46 --> Loader Class Initialized
INFO - 2023-08-01 09:05:46 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:46 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:46 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:46 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:46 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:46 --> Controller Class Initialized
DEBUG - 2023-08-01 09:05:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 09:05:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:05:46 --> Final output sent to browser
DEBUG - 2023-08-01 09:05:46 --> Total execution time: 0.0282
INFO - 2023-08-01 09:05:51 --> Config Class Initialized
INFO - 2023-08-01 09:05:51 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:51 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:51 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:51 --> URI Class Initialized
DEBUG - 2023-08-01 09:05:51 --> No URI present. Default controller set.
INFO - 2023-08-01 09:05:51 --> Router Class Initialized
INFO - 2023-08-01 09:05:51 --> Output Class Initialized
INFO - 2023-08-01 09:05:51 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:51 --> Input Class Initialized
INFO - 2023-08-01 09:05:51 --> Language Class Initialized
INFO - 2023-08-01 09:05:51 --> Language Class Initialized
INFO - 2023-08-01 09:05:51 --> Config Class Initialized
INFO - 2023-08-01 09:05:51 --> Loader Class Initialized
INFO - 2023-08-01 09:05:51 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:51 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:51 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:51 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:51 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:51 --> Controller Class Initialized
DEBUG - 2023-08-01 09:05:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 09:05:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:05:51 --> Final output sent to browser
DEBUG - 2023-08-01 09:05:51 --> Total execution time: 0.0337
INFO - 2023-08-01 09:05:58 --> Config Class Initialized
INFO - 2023-08-01 09:05:58 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:58 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:58 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:58 --> URI Class Initialized
INFO - 2023-08-01 09:05:58 --> Router Class Initialized
INFO - 2023-08-01 09:05:58 --> Output Class Initialized
INFO - 2023-08-01 09:05:58 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:58 --> Input Class Initialized
INFO - 2023-08-01 09:05:58 --> Language Class Initialized
INFO - 2023-08-01 09:05:58 --> Language Class Initialized
INFO - 2023-08-01 09:05:58 --> Config Class Initialized
INFO - 2023-08-01 09:05:58 --> Loader Class Initialized
INFO - 2023-08-01 09:05:58 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:58 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:58 --> Controller Class Initialized
INFO - 2023-08-01 09:05:58 --> Helper loaded: cookie_helper
INFO - 2023-08-01 09:05:58 --> Config Class Initialized
INFO - 2023-08-01 09:05:58 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:58 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:58 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:58 --> URI Class Initialized
INFO - 2023-08-01 09:05:58 --> Router Class Initialized
INFO - 2023-08-01 09:05:58 --> Output Class Initialized
INFO - 2023-08-01 09:05:58 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:58 --> Input Class Initialized
INFO - 2023-08-01 09:05:58 --> Language Class Initialized
INFO - 2023-08-01 09:05:58 --> Language Class Initialized
INFO - 2023-08-01 09:05:58 --> Config Class Initialized
INFO - 2023-08-01 09:05:58 --> Loader Class Initialized
INFO - 2023-08-01 09:05:58 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:58 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:58 --> Controller Class Initialized
INFO - 2023-08-01 09:05:58 --> Config Class Initialized
INFO - 2023-08-01 09:05:58 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:05:58 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:05:58 --> Utf8 Class Initialized
INFO - 2023-08-01 09:05:58 --> URI Class Initialized
INFO - 2023-08-01 09:05:58 --> Router Class Initialized
INFO - 2023-08-01 09:05:58 --> Output Class Initialized
INFO - 2023-08-01 09:05:58 --> Security Class Initialized
DEBUG - 2023-08-01 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:05:58 --> Input Class Initialized
INFO - 2023-08-01 09:05:58 --> Language Class Initialized
INFO - 2023-08-01 09:05:58 --> Language Class Initialized
INFO - 2023-08-01 09:05:58 --> Config Class Initialized
INFO - 2023-08-01 09:05:58 --> Loader Class Initialized
INFO - 2023-08-01 09:05:58 --> Helper loaded: url_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: file_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: form_helper
INFO - 2023-08-01 09:05:58 --> Helper loaded: my_helper
INFO - 2023-08-01 09:05:58 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:05:58 --> Controller Class Initialized
DEBUG - 2023-08-01 09:05:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-01 09:05:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:05:58 --> Final output sent to browser
DEBUG - 2023-08-01 09:05:58 --> Total execution time: 0.0414
INFO - 2023-08-01 09:06:03 --> Config Class Initialized
INFO - 2023-08-01 09:06:03 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:03 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:03 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:03 --> URI Class Initialized
INFO - 2023-08-01 09:06:03 --> Router Class Initialized
INFO - 2023-08-01 09:06:03 --> Output Class Initialized
INFO - 2023-08-01 09:06:03 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:03 --> Input Class Initialized
INFO - 2023-08-01 09:06:03 --> Language Class Initialized
INFO - 2023-08-01 09:06:03 --> Language Class Initialized
INFO - 2023-08-01 09:06:03 --> Config Class Initialized
INFO - 2023-08-01 09:06:03 --> Loader Class Initialized
INFO - 2023-08-01 09:06:03 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:03 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:03 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:03 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:03 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:03 --> Controller Class Initialized
INFO - 2023-08-01 09:06:03 --> Helper loaded: cookie_helper
INFO - 2023-08-01 09:06:03 --> Final output sent to browser
DEBUG - 2023-08-01 09:06:03 --> Total execution time: 0.0302
INFO - 2023-08-01 09:06:03 --> Config Class Initialized
INFO - 2023-08-01 09:06:03 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:03 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:03 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:03 --> URI Class Initialized
INFO - 2023-08-01 09:06:03 --> Router Class Initialized
INFO - 2023-08-01 09:06:03 --> Output Class Initialized
INFO - 2023-08-01 09:06:03 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:03 --> Input Class Initialized
INFO - 2023-08-01 09:06:03 --> Language Class Initialized
INFO - 2023-08-01 09:06:03 --> Language Class Initialized
INFO - 2023-08-01 09:06:03 --> Config Class Initialized
INFO - 2023-08-01 09:06:03 --> Loader Class Initialized
INFO - 2023-08-01 09:06:03 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:03 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:03 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:03 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:03 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:03 --> Controller Class Initialized
DEBUG - 2023-08-01 09:06:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-01 09:06:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:06:03 --> Final output sent to browser
DEBUG - 2023-08-01 09:06:03 --> Total execution time: 0.0289
INFO - 2023-08-01 09:06:04 --> Config Class Initialized
INFO - 2023-08-01 09:06:04 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:04 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:04 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:04 --> URI Class Initialized
INFO - 2023-08-01 09:06:04 --> Router Class Initialized
INFO - 2023-08-01 09:06:04 --> Output Class Initialized
INFO - 2023-08-01 09:06:04 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:04 --> Input Class Initialized
INFO - 2023-08-01 09:06:04 --> Language Class Initialized
INFO - 2023-08-01 09:06:04 --> Language Class Initialized
INFO - 2023-08-01 09:06:04 --> Config Class Initialized
INFO - 2023-08-01 09:06:04 --> Loader Class Initialized
INFO - 2023-08-01 09:06:04 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:04 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:04 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:04 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:04 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:04 --> Controller Class Initialized
DEBUG - 2023-08-01 09:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 09:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:06:04 --> Final output sent to browser
DEBUG - 2023-08-01 09:06:04 --> Total execution time: 0.0369
INFO - 2023-08-01 09:06:08 --> Config Class Initialized
INFO - 2023-08-01 09:06:08 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:08 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:08 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:08 --> URI Class Initialized
INFO - 2023-08-01 09:06:08 --> Router Class Initialized
INFO - 2023-08-01 09:06:08 --> Output Class Initialized
INFO - 2023-08-01 09:06:08 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:08 --> Input Class Initialized
INFO - 2023-08-01 09:06:08 --> Language Class Initialized
INFO - 2023-08-01 09:06:08 --> Language Class Initialized
INFO - 2023-08-01 09:06:08 --> Config Class Initialized
INFO - 2023-08-01 09:06:08 --> Loader Class Initialized
INFO - 2023-08-01 09:06:08 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:08 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:08 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:08 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:08 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:08 --> Controller Class Initialized
DEBUG - 2023-08-01 09:06:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-08-01 09:06:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:06:08 --> Final output sent to browser
DEBUG - 2023-08-01 09:06:08 --> Total execution time: 0.0344
INFO - 2023-08-01 09:06:09 --> Config Class Initialized
INFO - 2023-08-01 09:06:09 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:09 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:09 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:09 --> URI Class Initialized
INFO - 2023-08-01 09:06:09 --> Router Class Initialized
INFO - 2023-08-01 09:06:09 --> Output Class Initialized
INFO - 2023-08-01 09:06:09 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:09 --> Input Class Initialized
INFO - 2023-08-01 09:06:09 --> Language Class Initialized
INFO - 2023-08-01 09:06:09 --> Language Class Initialized
INFO - 2023-08-01 09:06:09 --> Config Class Initialized
INFO - 2023-08-01 09:06:09 --> Loader Class Initialized
INFO - 2023-08-01 09:06:09 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:09 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:09 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:09 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:09 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:09 --> Controller Class Initialized
DEBUG - 2023-08-01 09:06:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-01 09:06:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:06:09 --> Final output sent to browser
DEBUG - 2023-08-01 09:06:09 --> Total execution time: 0.0281
INFO - 2023-08-01 09:06:10 --> Config Class Initialized
INFO - 2023-08-01 09:06:10 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:10 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:10 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:10 --> URI Class Initialized
INFO - 2023-08-01 09:06:10 --> Router Class Initialized
INFO - 2023-08-01 09:06:10 --> Output Class Initialized
INFO - 2023-08-01 09:06:10 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:10 --> Input Class Initialized
INFO - 2023-08-01 09:06:10 --> Language Class Initialized
INFO - 2023-08-01 09:06:10 --> Language Class Initialized
INFO - 2023-08-01 09:06:10 --> Config Class Initialized
INFO - 2023-08-01 09:06:10 --> Loader Class Initialized
INFO - 2023-08-01 09:06:10 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:10 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:10 --> Controller Class Initialized
INFO - 2023-08-01 09:06:10 --> Helper loaded: cookie_helper
INFO - 2023-08-01 09:06:10 --> Config Class Initialized
INFO - 2023-08-01 09:06:10 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:10 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:10 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:10 --> URI Class Initialized
INFO - 2023-08-01 09:06:10 --> Router Class Initialized
INFO - 2023-08-01 09:06:10 --> Output Class Initialized
INFO - 2023-08-01 09:06:10 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:10 --> Input Class Initialized
INFO - 2023-08-01 09:06:10 --> Language Class Initialized
INFO - 2023-08-01 09:06:10 --> Language Class Initialized
INFO - 2023-08-01 09:06:10 --> Config Class Initialized
INFO - 2023-08-01 09:06:10 --> Loader Class Initialized
INFO - 2023-08-01 09:06:10 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:10 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:10 --> Controller Class Initialized
INFO - 2023-08-01 09:06:10 --> Config Class Initialized
INFO - 2023-08-01 09:06:10 --> Hooks Class Initialized
DEBUG - 2023-08-01 09:06:10 --> UTF-8 Support Enabled
INFO - 2023-08-01 09:06:10 --> Utf8 Class Initialized
INFO - 2023-08-01 09:06:10 --> URI Class Initialized
INFO - 2023-08-01 09:06:10 --> Router Class Initialized
INFO - 2023-08-01 09:06:10 --> Output Class Initialized
INFO - 2023-08-01 09:06:10 --> Security Class Initialized
DEBUG - 2023-08-01 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-01 09:06:10 --> Input Class Initialized
INFO - 2023-08-01 09:06:10 --> Language Class Initialized
INFO - 2023-08-01 09:06:10 --> Language Class Initialized
INFO - 2023-08-01 09:06:10 --> Config Class Initialized
INFO - 2023-08-01 09:06:10 --> Loader Class Initialized
INFO - 2023-08-01 09:06:10 --> Helper loaded: url_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: file_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: form_helper
INFO - 2023-08-01 09:06:10 --> Helper loaded: my_helper
INFO - 2023-08-01 09:06:10 --> Database Driver Class Initialized
DEBUG - 2023-08-01 09:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-01 09:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-01 09:06:10 --> Controller Class Initialized
DEBUG - 2023-08-01 09:06:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-01 09:06:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-01 09:06:10 --> Final output sent to browser
DEBUG - 2023-08-01 09:06:10 --> Total execution time: 0.0452
