<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-28 22:38:21 --> Config Class Initialized
INFO - 2024-07-28 22:38:21 --> Hooks Class Initialized
DEBUG - 2024-07-28 22:38:21 --> UTF-8 Support Enabled
INFO - 2024-07-28 22:38:21 --> Utf8 Class Initialized
INFO - 2024-07-28 22:38:21 --> URI Class Initialized
INFO - 2024-07-28 22:38:21 --> Router Class Initialized
INFO - 2024-07-28 22:38:21 --> Output Class Initialized
INFO - 2024-07-28 22:38:21 --> Security Class Initialized
DEBUG - 2024-07-28 22:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 22:38:21 --> Input Class Initialized
INFO - 2024-07-28 22:38:21 --> Language Class Initialized
INFO - 2024-07-28 22:38:21 --> Language Class Initialized
INFO - 2024-07-28 22:38:21 --> Config Class Initialized
INFO - 2024-07-28 22:38:21 --> Loader Class Initialized
INFO - 2024-07-28 22:38:21 --> Helper loaded: url_helper
INFO - 2024-07-28 22:38:21 --> Helper loaded: file_helper
INFO - 2024-07-28 22:38:21 --> Helper loaded: form_helper
INFO - 2024-07-28 22:38:21 --> Helper loaded: my_helper
INFO - 2024-07-28 22:38:21 --> Database Driver Class Initialized
INFO - 2024-07-28 22:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 22:38:21 --> Controller Class Initialized
INFO - 2024-07-28 22:38:21 --> Helper loaded: cookie_helper
INFO - 2024-07-28 22:38:21 --> Final output sent to browser
DEBUG - 2024-07-28 22:38:21 --> Total execution time: 0.0590
INFO - 2024-07-28 22:38:22 --> Config Class Initialized
INFO - 2024-07-28 22:38:22 --> Hooks Class Initialized
DEBUG - 2024-07-28 22:38:22 --> UTF-8 Support Enabled
INFO - 2024-07-28 22:38:22 --> Utf8 Class Initialized
INFO - 2024-07-28 22:38:22 --> URI Class Initialized
INFO - 2024-07-28 22:38:22 --> Router Class Initialized
INFO - 2024-07-28 22:38:22 --> Output Class Initialized
INFO - 2024-07-28 22:38:22 --> Security Class Initialized
DEBUG - 2024-07-28 22:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 22:38:22 --> Input Class Initialized
INFO - 2024-07-28 22:38:22 --> Language Class Initialized
INFO - 2024-07-28 22:38:22 --> Language Class Initialized
INFO - 2024-07-28 22:38:22 --> Config Class Initialized
INFO - 2024-07-28 22:38:22 --> Loader Class Initialized
INFO - 2024-07-28 22:38:22 --> Helper loaded: url_helper
INFO - 2024-07-28 22:38:22 --> Helper loaded: file_helper
INFO - 2024-07-28 22:38:22 --> Helper loaded: form_helper
INFO - 2024-07-28 22:38:22 --> Helper loaded: my_helper
INFO - 2024-07-28 22:38:22 --> Database Driver Class Initialized
INFO - 2024-07-28 22:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 22:38:22 --> Controller Class Initialized
INFO - 2024-07-28 22:38:22 --> Helper loaded: cookie_helper
INFO - 2024-07-28 22:38:22 --> Config Class Initialized
INFO - 2024-07-28 22:38:22 --> Hooks Class Initialized
DEBUG - 2024-07-28 22:38:22 --> UTF-8 Support Enabled
INFO - 2024-07-28 22:38:22 --> Utf8 Class Initialized
INFO - 2024-07-28 22:38:22 --> URI Class Initialized
INFO - 2024-07-28 22:38:22 --> Router Class Initialized
INFO - 2024-07-28 22:38:22 --> Output Class Initialized
INFO - 2024-07-28 22:38:22 --> Security Class Initialized
DEBUG - 2024-07-28 22:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 22:38:22 --> Input Class Initialized
INFO - 2024-07-28 22:38:22 --> Language Class Initialized
INFO - 2024-07-28 22:38:22 --> Language Class Initialized
INFO - 2024-07-28 22:38:22 --> Config Class Initialized
INFO - 2024-07-28 22:38:22 --> Loader Class Initialized
INFO - 2024-07-28 22:38:22 --> Helper loaded: url_helper
INFO - 2024-07-28 22:38:22 --> Helper loaded: file_helper
INFO - 2024-07-28 22:38:22 --> Helper loaded: form_helper
INFO - 2024-07-28 22:38:22 --> Helper loaded: my_helper
INFO - 2024-07-28 22:38:22 --> Database Driver Class Initialized
INFO - 2024-07-28 22:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 22:38:22 --> Controller Class Initialized
DEBUG - 2024-07-28 22:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-28 22:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-28 22:38:22 --> Final output sent to browser
DEBUG - 2024-07-28 22:38:22 --> Total execution time: 0.0398
INFO - 2024-07-28 22:41:09 --> Config Class Initialized
INFO - 2024-07-28 22:41:09 --> Hooks Class Initialized
DEBUG - 2024-07-28 22:41:09 --> UTF-8 Support Enabled
INFO - 2024-07-28 22:41:09 --> Utf8 Class Initialized
INFO - 2024-07-28 22:41:09 --> URI Class Initialized
INFO - 2024-07-28 22:41:09 --> Router Class Initialized
INFO - 2024-07-28 22:41:09 --> Output Class Initialized
INFO - 2024-07-28 22:41:09 --> Security Class Initialized
DEBUG - 2024-07-28 22:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 22:41:09 --> Input Class Initialized
INFO - 2024-07-28 22:41:09 --> Language Class Initialized
INFO - 2024-07-28 22:41:09 --> Language Class Initialized
INFO - 2024-07-28 22:41:09 --> Config Class Initialized
INFO - 2024-07-28 22:41:09 --> Loader Class Initialized
INFO - 2024-07-28 22:41:09 --> Helper loaded: url_helper
INFO - 2024-07-28 22:41:09 --> Helper loaded: file_helper
INFO - 2024-07-28 22:41:09 --> Helper loaded: form_helper
INFO - 2024-07-28 22:41:09 --> Helper loaded: my_helper
INFO - 2024-07-28 22:41:09 --> Database Driver Class Initialized
INFO - 2024-07-28 22:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 22:41:09 --> Controller Class Initialized
DEBUG - 2024-07-28 22:41:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-28 22:41:13 --> Final output sent to browser
DEBUG - 2024-07-28 22:41:13 --> Total execution time: 3.6850
INFO - 2024-07-28 23:36:48 --> Config Class Initialized
INFO - 2024-07-28 23:36:48 --> Hooks Class Initialized
DEBUG - 2024-07-28 23:36:48 --> UTF-8 Support Enabled
INFO - 2024-07-28 23:36:48 --> Utf8 Class Initialized
INFO - 2024-07-28 23:36:48 --> URI Class Initialized
INFO - 2024-07-28 23:36:48 --> Router Class Initialized
INFO - 2024-07-28 23:36:48 --> Output Class Initialized
INFO - 2024-07-28 23:36:48 --> Security Class Initialized
DEBUG - 2024-07-28 23:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 23:36:48 --> Input Class Initialized
INFO - 2024-07-28 23:36:48 --> Language Class Initialized
INFO - 2024-07-28 23:36:48 --> Language Class Initialized
INFO - 2024-07-28 23:36:48 --> Config Class Initialized
INFO - 2024-07-28 23:36:48 --> Loader Class Initialized
INFO - 2024-07-28 23:36:48 --> Helper loaded: url_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: file_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: form_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: my_helper
INFO - 2024-07-28 23:36:48 --> Database Driver Class Initialized
INFO - 2024-07-28 23:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 23:36:48 --> Controller Class Initialized
INFO - 2024-07-28 23:36:48 --> Helper loaded: cookie_helper
INFO - 2024-07-28 23:36:48 --> Final output sent to browser
DEBUG - 2024-07-28 23:36:48 --> Total execution time: 0.0336
INFO - 2024-07-28 23:36:48 --> Config Class Initialized
INFO - 2024-07-28 23:36:48 --> Hooks Class Initialized
DEBUG - 2024-07-28 23:36:48 --> UTF-8 Support Enabled
INFO - 2024-07-28 23:36:48 --> Utf8 Class Initialized
INFO - 2024-07-28 23:36:48 --> URI Class Initialized
INFO - 2024-07-28 23:36:48 --> Router Class Initialized
INFO - 2024-07-28 23:36:48 --> Output Class Initialized
INFO - 2024-07-28 23:36:48 --> Security Class Initialized
DEBUG - 2024-07-28 23:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 23:36:48 --> Input Class Initialized
INFO - 2024-07-28 23:36:48 --> Language Class Initialized
INFO - 2024-07-28 23:36:48 --> Language Class Initialized
INFO - 2024-07-28 23:36:48 --> Config Class Initialized
INFO - 2024-07-28 23:36:48 --> Loader Class Initialized
INFO - 2024-07-28 23:36:48 --> Helper loaded: url_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: file_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: form_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: my_helper
INFO - 2024-07-28 23:36:48 --> Database Driver Class Initialized
INFO - 2024-07-28 23:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 23:36:48 --> Controller Class Initialized
INFO - 2024-07-28 23:36:48 --> Helper loaded: cookie_helper
INFO - 2024-07-28 23:36:48 --> Config Class Initialized
INFO - 2024-07-28 23:36:48 --> Hooks Class Initialized
DEBUG - 2024-07-28 23:36:48 --> UTF-8 Support Enabled
INFO - 2024-07-28 23:36:48 --> Utf8 Class Initialized
INFO - 2024-07-28 23:36:48 --> URI Class Initialized
INFO - 2024-07-28 23:36:48 --> Router Class Initialized
INFO - 2024-07-28 23:36:48 --> Output Class Initialized
INFO - 2024-07-28 23:36:48 --> Security Class Initialized
DEBUG - 2024-07-28 23:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-28 23:36:48 --> Input Class Initialized
INFO - 2024-07-28 23:36:48 --> Language Class Initialized
INFO - 2024-07-28 23:36:48 --> Language Class Initialized
INFO - 2024-07-28 23:36:48 --> Config Class Initialized
INFO - 2024-07-28 23:36:48 --> Loader Class Initialized
INFO - 2024-07-28 23:36:48 --> Helper loaded: url_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: file_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: form_helper
INFO - 2024-07-28 23:36:48 --> Helper loaded: my_helper
INFO - 2024-07-28 23:36:48 --> Database Driver Class Initialized
INFO - 2024-07-28 23:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-28 23:36:48 --> Controller Class Initialized
DEBUG - 2024-07-28 23:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-28 23:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-28 23:36:48 --> Final output sent to browser
DEBUG - 2024-07-28 23:36:48 --> Total execution time: 0.0292
