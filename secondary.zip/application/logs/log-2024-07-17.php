<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-17 08:04:11 --> Config Class Initialized
INFO - 2024-07-17 08:04:11 --> Hooks Class Initialized
DEBUG - 2024-07-17 08:04:11 --> UTF-8 Support Enabled
INFO - 2024-07-17 08:04:11 --> Utf8 Class Initialized
INFO - 2024-07-17 08:04:11 --> URI Class Initialized
INFO - 2024-07-17 08:04:11 --> Router Class Initialized
INFO - 2024-07-17 08:04:11 --> Output Class Initialized
INFO - 2024-07-17 08:04:11 --> Security Class Initialized
DEBUG - 2024-07-17 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 08:04:11 --> Input Class Initialized
INFO - 2024-07-17 08:04:11 --> Language Class Initialized
INFO - 2024-07-17 08:04:11 --> Language Class Initialized
INFO - 2024-07-17 08:04:11 --> Config Class Initialized
INFO - 2024-07-17 08:04:11 --> Loader Class Initialized
INFO - 2024-07-17 08:04:11 --> Helper loaded: url_helper
INFO - 2024-07-17 08:04:11 --> Helper loaded: file_helper
INFO - 2024-07-17 08:04:11 --> Helper loaded: form_helper
INFO - 2024-07-17 08:04:11 --> Helper loaded: my_helper
INFO - 2024-07-17 08:04:11 --> Database Driver Class Initialized
INFO - 2024-07-17 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 08:04:11 --> Controller Class Initialized
DEBUG - 2024-07-17 08:04:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-17 08:04:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 08:04:11 --> Final output sent to browser
DEBUG - 2024-07-17 08:04:11 --> Total execution time: 0.0651
INFO - 2024-07-17 09:58:32 --> Config Class Initialized
INFO - 2024-07-17 09:58:32 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:32 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:32 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:32 --> URI Class Initialized
INFO - 2024-07-17 09:58:32 --> Router Class Initialized
INFO - 2024-07-17 09:58:32 --> Output Class Initialized
INFO - 2024-07-17 09:58:32 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:32 --> Input Class Initialized
INFO - 2024-07-17 09:58:32 --> Language Class Initialized
INFO - 2024-07-17 09:58:32 --> Language Class Initialized
INFO - 2024-07-17 09:58:32 --> Config Class Initialized
INFO - 2024-07-17 09:58:32 --> Loader Class Initialized
INFO - 2024-07-17 09:58:32 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:32 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:32 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:32 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:32 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:32 --> Controller Class Initialized
DEBUG - 2024-07-17 09:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-17 09:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 09:58:32 --> Final output sent to browser
DEBUG - 2024-07-17 09:58:32 --> Total execution time: 0.0493
INFO - 2024-07-17 09:58:37 --> Config Class Initialized
INFO - 2024-07-17 09:58:37 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:37 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:37 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:37 --> URI Class Initialized
INFO - 2024-07-17 09:58:37 --> Router Class Initialized
INFO - 2024-07-17 09:58:37 --> Output Class Initialized
INFO - 2024-07-17 09:58:37 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:37 --> Input Class Initialized
INFO - 2024-07-17 09:58:37 --> Language Class Initialized
INFO - 2024-07-17 09:58:37 --> Language Class Initialized
INFO - 2024-07-17 09:58:37 --> Config Class Initialized
INFO - 2024-07-17 09:58:37 --> Loader Class Initialized
INFO - 2024-07-17 09:58:37 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:37 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:37 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:37 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:37 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:37 --> Controller Class Initialized
INFO - 2024-07-17 09:58:37 --> Helper loaded: cookie_helper
INFO - 2024-07-17 09:58:37 --> Final output sent to browser
DEBUG - 2024-07-17 09:58:37 --> Total execution time: 0.0328
INFO - 2024-07-17 09:58:37 --> Config Class Initialized
INFO - 2024-07-17 09:58:37 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:37 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:37 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:37 --> URI Class Initialized
INFO - 2024-07-17 09:58:37 --> Router Class Initialized
INFO - 2024-07-17 09:58:37 --> Output Class Initialized
INFO - 2024-07-17 09:58:37 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:37 --> Input Class Initialized
INFO - 2024-07-17 09:58:37 --> Language Class Initialized
INFO - 2024-07-17 09:58:37 --> Language Class Initialized
INFO - 2024-07-17 09:58:37 --> Config Class Initialized
INFO - 2024-07-17 09:58:37 --> Loader Class Initialized
INFO - 2024-07-17 09:58:37 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:37 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:37 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:37 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:37 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:37 --> Controller Class Initialized
DEBUG - 2024-07-17 09:58:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-17 09:58:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 09:58:37 --> Final output sent to browser
DEBUG - 2024-07-17 09:58:37 --> Total execution time: 0.0318
INFO - 2024-07-17 09:58:41 --> Config Class Initialized
INFO - 2024-07-17 09:58:41 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:41 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:41 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:41 --> URI Class Initialized
INFO - 2024-07-17 09:58:41 --> Router Class Initialized
INFO - 2024-07-17 09:58:41 --> Output Class Initialized
INFO - 2024-07-17 09:58:41 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:41 --> Input Class Initialized
INFO - 2024-07-17 09:58:41 --> Language Class Initialized
INFO - 2024-07-17 09:58:41 --> Language Class Initialized
INFO - 2024-07-17 09:58:41 --> Config Class Initialized
INFO - 2024-07-17 09:58:41 --> Loader Class Initialized
INFO - 2024-07-17 09:58:41 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:41 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:41 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:41 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:41 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:41 --> Controller Class Initialized
DEBUG - 2024-07-17 09:58:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-17 09:58:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 09:58:41 --> Final output sent to browser
DEBUG - 2024-07-17 09:58:41 --> Total execution time: 0.0706
INFO - 2024-07-17 09:58:41 --> Config Class Initialized
INFO - 2024-07-17 09:58:41 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:41 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:41 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:41 --> URI Class Initialized
INFO - 2024-07-17 09:58:41 --> Router Class Initialized
INFO - 2024-07-17 09:58:42 --> Output Class Initialized
INFO - 2024-07-17 09:58:42 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:42 --> Input Class Initialized
INFO - 2024-07-17 09:58:42 --> Language Class Initialized
ERROR - 2024-07-17 09:58:42 --> 404 Page Not Found: /index
INFO - 2024-07-17 09:58:42 --> Config Class Initialized
INFO - 2024-07-17 09:58:42 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:42 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:42 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:42 --> URI Class Initialized
INFO - 2024-07-17 09:58:42 --> Router Class Initialized
INFO - 2024-07-17 09:58:42 --> Output Class Initialized
INFO - 2024-07-17 09:58:42 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:42 --> Input Class Initialized
INFO - 2024-07-17 09:58:42 --> Language Class Initialized
INFO - 2024-07-17 09:58:42 --> Language Class Initialized
INFO - 2024-07-17 09:58:42 --> Config Class Initialized
INFO - 2024-07-17 09:58:42 --> Loader Class Initialized
INFO - 2024-07-17 09:58:42 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:42 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:42 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:42 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:42 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:42 --> Controller Class Initialized
INFO - 2024-07-17 09:58:48 --> Config Class Initialized
INFO - 2024-07-17 09:58:48 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:48 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:48 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:48 --> URI Class Initialized
INFO - 2024-07-17 09:58:48 --> Router Class Initialized
INFO - 2024-07-17 09:58:48 --> Output Class Initialized
INFO - 2024-07-17 09:58:48 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:48 --> Input Class Initialized
INFO - 2024-07-17 09:58:48 --> Language Class Initialized
INFO - 2024-07-17 09:58:48 --> Language Class Initialized
INFO - 2024-07-17 09:58:48 --> Config Class Initialized
INFO - 2024-07-17 09:58:48 --> Loader Class Initialized
INFO - 2024-07-17 09:58:48 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:48 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:48 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:48 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:48 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:48 --> Controller Class Initialized
DEBUG - 2024-07-17 09:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 09:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 09:58:48 --> Final output sent to browser
DEBUG - 2024-07-17 09:58:48 --> Total execution time: 0.0294
INFO - 2024-07-17 09:58:48 --> Config Class Initialized
INFO - 2024-07-17 09:58:48 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:48 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:48 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:48 --> URI Class Initialized
INFO - 2024-07-17 09:58:48 --> Router Class Initialized
INFO - 2024-07-17 09:58:48 --> Output Class Initialized
INFO - 2024-07-17 09:58:48 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:48 --> Input Class Initialized
INFO - 2024-07-17 09:58:48 --> Language Class Initialized
ERROR - 2024-07-17 09:58:48 --> 404 Page Not Found: /index
INFO - 2024-07-17 09:58:49 --> Config Class Initialized
INFO - 2024-07-17 09:58:49 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:49 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:49 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:49 --> URI Class Initialized
INFO - 2024-07-17 09:58:49 --> Router Class Initialized
INFO - 2024-07-17 09:58:49 --> Output Class Initialized
INFO - 2024-07-17 09:58:49 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:49 --> Input Class Initialized
INFO - 2024-07-17 09:58:49 --> Language Class Initialized
INFO - 2024-07-17 09:58:49 --> Language Class Initialized
INFO - 2024-07-17 09:58:49 --> Config Class Initialized
INFO - 2024-07-17 09:58:49 --> Loader Class Initialized
INFO - 2024-07-17 09:58:49 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:49 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:49 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:49 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:49 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:49 --> Controller Class Initialized
INFO - 2024-07-17 09:58:56 --> Config Class Initialized
INFO - 2024-07-17 09:58:56 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:56 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:56 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:56 --> URI Class Initialized
INFO - 2024-07-17 09:58:56 --> Router Class Initialized
INFO - 2024-07-17 09:58:56 --> Output Class Initialized
INFO - 2024-07-17 09:58:56 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:56 --> Input Class Initialized
INFO - 2024-07-17 09:58:56 --> Language Class Initialized
INFO - 2024-07-17 09:58:56 --> Language Class Initialized
INFO - 2024-07-17 09:58:56 --> Config Class Initialized
INFO - 2024-07-17 09:58:56 --> Loader Class Initialized
INFO - 2024-07-17 09:58:56 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:56 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:56 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:56 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:56 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:56 --> Controller Class Initialized
INFO - 2024-07-17 09:58:57 --> Config Class Initialized
INFO - 2024-07-17 09:58:57 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:57 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:57 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:57 --> URI Class Initialized
INFO - 2024-07-17 09:58:57 --> Router Class Initialized
INFO - 2024-07-17 09:58:57 --> Output Class Initialized
INFO - 2024-07-17 09:58:57 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:57 --> Input Class Initialized
INFO - 2024-07-17 09:58:57 --> Language Class Initialized
INFO - 2024-07-17 09:58:57 --> Language Class Initialized
INFO - 2024-07-17 09:58:57 --> Config Class Initialized
INFO - 2024-07-17 09:58:57 --> Loader Class Initialized
INFO - 2024-07-17 09:58:57 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:57 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:57 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:57 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:57 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:57 --> Controller Class Initialized
INFO - 2024-07-17 09:58:58 --> Config Class Initialized
INFO - 2024-07-17 09:58:58 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:58 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:58 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:58 --> URI Class Initialized
INFO - 2024-07-17 09:58:58 --> Router Class Initialized
INFO - 2024-07-17 09:58:58 --> Output Class Initialized
INFO - 2024-07-17 09:58:58 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:58 --> Input Class Initialized
INFO - 2024-07-17 09:58:58 --> Language Class Initialized
INFO - 2024-07-17 09:58:58 --> Language Class Initialized
INFO - 2024-07-17 09:58:58 --> Config Class Initialized
INFO - 2024-07-17 09:58:58 --> Loader Class Initialized
INFO - 2024-07-17 09:58:58 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:58 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:58 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:58 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:58 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:58 --> Controller Class Initialized
INFO - 2024-07-17 09:58:58 --> Config Class Initialized
INFO - 2024-07-17 09:58:58 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:58 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:58 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:58 --> URI Class Initialized
INFO - 2024-07-17 09:58:58 --> Router Class Initialized
INFO - 2024-07-17 09:58:58 --> Output Class Initialized
INFO - 2024-07-17 09:58:58 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:58 --> Input Class Initialized
INFO - 2024-07-17 09:58:58 --> Language Class Initialized
INFO - 2024-07-17 09:58:59 --> Language Class Initialized
INFO - 2024-07-17 09:58:59 --> Config Class Initialized
INFO - 2024-07-17 09:58:59 --> Loader Class Initialized
INFO - 2024-07-17 09:58:59 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:59 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:59 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:59 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:59 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:59 --> Controller Class Initialized
INFO - 2024-07-17 09:58:59 --> Config Class Initialized
INFO - 2024-07-17 09:58:59 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:58:59 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:58:59 --> Utf8 Class Initialized
INFO - 2024-07-17 09:58:59 --> URI Class Initialized
INFO - 2024-07-17 09:58:59 --> Router Class Initialized
INFO - 2024-07-17 09:58:59 --> Output Class Initialized
INFO - 2024-07-17 09:58:59 --> Security Class Initialized
DEBUG - 2024-07-17 09:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:58:59 --> Input Class Initialized
INFO - 2024-07-17 09:58:59 --> Language Class Initialized
INFO - 2024-07-17 09:58:59 --> Language Class Initialized
INFO - 2024-07-17 09:58:59 --> Config Class Initialized
INFO - 2024-07-17 09:58:59 --> Loader Class Initialized
INFO - 2024-07-17 09:58:59 --> Helper loaded: url_helper
INFO - 2024-07-17 09:58:59 --> Helper loaded: file_helper
INFO - 2024-07-17 09:58:59 --> Helper loaded: form_helper
INFO - 2024-07-17 09:58:59 --> Helper loaded: my_helper
INFO - 2024-07-17 09:58:59 --> Database Driver Class Initialized
INFO - 2024-07-17 09:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:58:59 --> Controller Class Initialized
INFO - 2024-07-17 09:59:00 --> Config Class Initialized
INFO - 2024-07-17 09:59:00 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:00 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:00 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:00 --> URI Class Initialized
INFO - 2024-07-17 09:59:00 --> Router Class Initialized
INFO - 2024-07-17 09:59:00 --> Output Class Initialized
INFO - 2024-07-17 09:59:00 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:00 --> Input Class Initialized
INFO - 2024-07-17 09:59:00 --> Language Class Initialized
INFO - 2024-07-17 09:59:00 --> Language Class Initialized
INFO - 2024-07-17 09:59:00 --> Config Class Initialized
INFO - 2024-07-17 09:59:00 --> Loader Class Initialized
INFO - 2024-07-17 09:59:00 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:00 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:00 --> Controller Class Initialized
INFO - 2024-07-17 09:59:00 --> Config Class Initialized
INFO - 2024-07-17 09:59:00 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:00 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:00 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:00 --> URI Class Initialized
INFO - 2024-07-17 09:59:00 --> Router Class Initialized
INFO - 2024-07-17 09:59:00 --> Output Class Initialized
INFO - 2024-07-17 09:59:00 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:00 --> Input Class Initialized
INFO - 2024-07-17 09:59:00 --> Language Class Initialized
INFO - 2024-07-17 09:59:00 --> Language Class Initialized
INFO - 2024-07-17 09:59:00 --> Config Class Initialized
INFO - 2024-07-17 09:59:00 --> Loader Class Initialized
INFO - 2024-07-17 09:59:00 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:00 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:00 --> Controller Class Initialized
INFO - 2024-07-17 09:59:00 --> Config Class Initialized
INFO - 2024-07-17 09:59:00 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:00 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:00 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:00 --> URI Class Initialized
INFO - 2024-07-17 09:59:00 --> Router Class Initialized
INFO - 2024-07-17 09:59:00 --> Output Class Initialized
INFO - 2024-07-17 09:59:00 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:00 --> Input Class Initialized
INFO - 2024-07-17 09:59:00 --> Language Class Initialized
INFO - 2024-07-17 09:59:00 --> Language Class Initialized
INFO - 2024-07-17 09:59:00 --> Config Class Initialized
INFO - 2024-07-17 09:59:00 --> Loader Class Initialized
INFO - 2024-07-17 09:59:00 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:00 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:00 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:00 --> Controller Class Initialized
INFO - 2024-07-17 09:59:01 --> Config Class Initialized
INFO - 2024-07-17 09:59:01 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:01 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:01 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:01 --> URI Class Initialized
INFO - 2024-07-17 09:59:01 --> Router Class Initialized
INFO - 2024-07-17 09:59:01 --> Output Class Initialized
INFO - 2024-07-17 09:59:01 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:01 --> Input Class Initialized
INFO - 2024-07-17 09:59:01 --> Language Class Initialized
INFO - 2024-07-17 09:59:01 --> Language Class Initialized
INFO - 2024-07-17 09:59:01 --> Config Class Initialized
INFO - 2024-07-17 09:59:01 --> Loader Class Initialized
INFO - 2024-07-17 09:59:01 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:01 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:01 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:01 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:01 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:01 --> Controller Class Initialized
INFO - 2024-07-17 09:59:02 --> Config Class Initialized
INFO - 2024-07-17 09:59:02 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:02 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:02 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:02 --> URI Class Initialized
INFO - 2024-07-17 09:59:02 --> Router Class Initialized
INFO - 2024-07-17 09:59:02 --> Output Class Initialized
INFO - 2024-07-17 09:59:02 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:02 --> Input Class Initialized
INFO - 2024-07-17 09:59:02 --> Language Class Initialized
INFO - 2024-07-17 09:59:02 --> Language Class Initialized
INFO - 2024-07-17 09:59:02 --> Config Class Initialized
INFO - 2024-07-17 09:59:02 --> Loader Class Initialized
INFO - 2024-07-17 09:59:02 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:02 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:02 --> Controller Class Initialized
INFO - 2024-07-17 09:59:02 --> Config Class Initialized
INFO - 2024-07-17 09:59:02 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:02 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:02 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:02 --> URI Class Initialized
INFO - 2024-07-17 09:59:02 --> Router Class Initialized
INFO - 2024-07-17 09:59:02 --> Output Class Initialized
INFO - 2024-07-17 09:59:02 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:02 --> Input Class Initialized
INFO - 2024-07-17 09:59:02 --> Language Class Initialized
INFO - 2024-07-17 09:59:02 --> Language Class Initialized
INFO - 2024-07-17 09:59:02 --> Config Class Initialized
INFO - 2024-07-17 09:59:02 --> Loader Class Initialized
INFO - 2024-07-17 09:59:02 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:02 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:02 --> Controller Class Initialized
INFO - 2024-07-17 09:59:02 --> Config Class Initialized
INFO - 2024-07-17 09:59:02 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:02 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:02 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:02 --> URI Class Initialized
INFO - 2024-07-17 09:59:02 --> Router Class Initialized
INFO - 2024-07-17 09:59:02 --> Output Class Initialized
INFO - 2024-07-17 09:59:02 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:02 --> Input Class Initialized
INFO - 2024-07-17 09:59:02 --> Language Class Initialized
INFO - 2024-07-17 09:59:02 --> Language Class Initialized
INFO - 2024-07-17 09:59:02 --> Config Class Initialized
INFO - 2024-07-17 09:59:02 --> Loader Class Initialized
INFO - 2024-07-17 09:59:02 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:02 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:02 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:02 --> Controller Class Initialized
INFO - 2024-07-17 09:59:03 --> Config Class Initialized
INFO - 2024-07-17 09:59:03 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:03 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:03 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:03 --> URI Class Initialized
INFO - 2024-07-17 09:59:03 --> Router Class Initialized
INFO - 2024-07-17 09:59:03 --> Output Class Initialized
INFO - 2024-07-17 09:59:03 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:03 --> Input Class Initialized
INFO - 2024-07-17 09:59:03 --> Language Class Initialized
INFO - 2024-07-17 09:59:03 --> Language Class Initialized
INFO - 2024-07-17 09:59:03 --> Config Class Initialized
INFO - 2024-07-17 09:59:03 --> Loader Class Initialized
INFO - 2024-07-17 09:59:03 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:03 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:03 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:03 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:03 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:03 --> Controller Class Initialized
INFO - 2024-07-17 09:59:04 --> Config Class Initialized
INFO - 2024-07-17 09:59:04 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:04 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:04 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:04 --> URI Class Initialized
INFO - 2024-07-17 09:59:04 --> Router Class Initialized
INFO - 2024-07-17 09:59:04 --> Output Class Initialized
INFO - 2024-07-17 09:59:04 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:04 --> Input Class Initialized
INFO - 2024-07-17 09:59:04 --> Language Class Initialized
INFO - 2024-07-17 09:59:04 --> Language Class Initialized
INFO - 2024-07-17 09:59:04 --> Config Class Initialized
INFO - 2024-07-17 09:59:04 --> Loader Class Initialized
INFO - 2024-07-17 09:59:04 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:04 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:04 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:04 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:04 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:04 --> Controller Class Initialized
INFO - 2024-07-17 09:59:04 --> Config Class Initialized
INFO - 2024-07-17 09:59:04 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:04 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:04 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:04 --> URI Class Initialized
INFO - 2024-07-17 09:59:04 --> Router Class Initialized
INFO - 2024-07-17 09:59:04 --> Output Class Initialized
INFO - 2024-07-17 09:59:04 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:04 --> Input Class Initialized
INFO - 2024-07-17 09:59:04 --> Language Class Initialized
INFO - 2024-07-17 09:59:04 --> Language Class Initialized
INFO - 2024-07-17 09:59:04 --> Config Class Initialized
INFO - 2024-07-17 09:59:04 --> Loader Class Initialized
INFO - 2024-07-17 09:59:04 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:04 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:04 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:04 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:04 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:04 --> Controller Class Initialized
INFO - 2024-07-17 09:59:05 --> Config Class Initialized
INFO - 2024-07-17 09:59:05 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:05 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:05 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:05 --> URI Class Initialized
INFO - 2024-07-17 09:59:05 --> Router Class Initialized
INFO - 2024-07-17 09:59:05 --> Output Class Initialized
INFO - 2024-07-17 09:59:05 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:05 --> Input Class Initialized
INFO - 2024-07-17 09:59:05 --> Language Class Initialized
INFO - 2024-07-17 09:59:05 --> Language Class Initialized
INFO - 2024-07-17 09:59:05 --> Config Class Initialized
INFO - 2024-07-17 09:59:05 --> Loader Class Initialized
INFO - 2024-07-17 09:59:05 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:05 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:05 --> Controller Class Initialized
INFO - 2024-07-17 09:59:05 --> Config Class Initialized
INFO - 2024-07-17 09:59:05 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:05 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:05 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:05 --> URI Class Initialized
INFO - 2024-07-17 09:59:05 --> Router Class Initialized
INFO - 2024-07-17 09:59:05 --> Output Class Initialized
INFO - 2024-07-17 09:59:05 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:05 --> Input Class Initialized
INFO - 2024-07-17 09:59:05 --> Language Class Initialized
INFO - 2024-07-17 09:59:05 --> Language Class Initialized
INFO - 2024-07-17 09:59:05 --> Config Class Initialized
INFO - 2024-07-17 09:59:05 --> Loader Class Initialized
INFO - 2024-07-17 09:59:05 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:05 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:05 --> Controller Class Initialized
INFO - 2024-07-17 09:59:05 --> Config Class Initialized
INFO - 2024-07-17 09:59:05 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:05 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:05 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:05 --> URI Class Initialized
INFO - 2024-07-17 09:59:05 --> Router Class Initialized
INFO - 2024-07-17 09:59:05 --> Output Class Initialized
INFO - 2024-07-17 09:59:05 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:05 --> Input Class Initialized
INFO - 2024-07-17 09:59:05 --> Language Class Initialized
INFO - 2024-07-17 09:59:05 --> Language Class Initialized
INFO - 2024-07-17 09:59:05 --> Config Class Initialized
INFO - 2024-07-17 09:59:05 --> Loader Class Initialized
INFO - 2024-07-17 09:59:05 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:05 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:05 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:05 --> Controller Class Initialized
INFO - 2024-07-17 09:59:06 --> Config Class Initialized
INFO - 2024-07-17 09:59:06 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:06 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:06 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:06 --> URI Class Initialized
INFO - 2024-07-17 09:59:06 --> Router Class Initialized
INFO - 2024-07-17 09:59:06 --> Output Class Initialized
INFO - 2024-07-17 09:59:06 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:06 --> Input Class Initialized
INFO - 2024-07-17 09:59:06 --> Language Class Initialized
INFO - 2024-07-17 09:59:06 --> Language Class Initialized
INFO - 2024-07-17 09:59:06 --> Config Class Initialized
INFO - 2024-07-17 09:59:06 --> Loader Class Initialized
INFO - 2024-07-17 09:59:06 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:06 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:06 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:06 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:06 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:06 --> Controller Class Initialized
INFO - 2024-07-17 09:59:07 --> Config Class Initialized
INFO - 2024-07-17 09:59:07 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:07 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:07 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:07 --> URI Class Initialized
INFO - 2024-07-17 09:59:07 --> Router Class Initialized
INFO - 2024-07-17 09:59:07 --> Output Class Initialized
INFO - 2024-07-17 09:59:07 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:07 --> Input Class Initialized
INFO - 2024-07-17 09:59:07 --> Language Class Initialized
INFO - 2024-07-17 09:59:07 --> Language Class Initialized
INFO - 2024-07-17 09:59:07 --> Config Class Initialized
INFO - 2024-07-17 09:59:07 --> Loader Class Initialized
INFO - 2024-07-17 09:59:07 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:07 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:07 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:07 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:07 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:07 --> Controller Class Initialized
INFO - 2024-07-17 09:59:07 --> Config Class Initialized
INFO - 2024-07-17 09:59:07 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:07 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:07 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:07 --> URI Class Initialized
INFO - 2024-07-17 09:59:07 --> Router Class Initialized
INFO - 2024-07-17 09:59:07 --> Output Class Initialized
INFO - 2024-07-17 09:59:07 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:07 --> Input Class Initialized
INFO - 2024-07-17 09:59:07 --> Language Class Initialized
INFO - 2024-07-17 09:59:07 --> Language Class Initialized
INFO - 2024-07-17 09:59:07 --> Config Class Initialized
INFO - 2024-07-17 09:59:07 --> Loader Class Initialized
INFO - 2024-07-17 09:59:07 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:07 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:07 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:07 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:07 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:07 --> Controller Class Initialized
INFO - 2024-07-17 09:59:08 --> Config Class Initialized
INFO - 2024-07-17 09:59:08 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:08 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:08 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:08 --> URI Class Initialized
INFO - 2024-07-17 09:59:08 --> Router Class Initialized
INFO - 2024-07-17 09:59:08 --> Output Class Initialized
INFO - 2024-07-17 09:59:08 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:08 --> Input Class Initialized
INFO - 2024-07-17 09:59:08 --> Language Class Initialized
INFO - 2024-07-17 09:59:08 --> Language Class Initialized
INFO - 2024-07-17 09:59:08 --> Config Class Initialized
INFO - 2024-07-17 09:59:08 --> Loader Class Initialized
INFO - 2024-07-17 09:59:08 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:08 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:08 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:08 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:08 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:08 --> Controller Class Initialized
INFO - 2024-07-17 09:59:23 --> Config Class Initialized
INFO - 2024-07-17 09:59:23 --> Hooks Class Initialized
DEBUG - 2024-07-17 09:59:23 --> UTF-8 Support Enabled
INFO - 2024-07-17 09:59:23 --> Utf8 Class Initialized
INFO - 2024-07-17 09:59:23 --> URI Class Initialized
INFO - 2024-07-17 09:59:23 --> Router Class Initialized
INFO - 2024-07-17 09:59:23 --> Output Class Initialized
INFO - 2024-07-17 09:59:23 --> Security Class Initialized
DEBUG - 2024-07-17 09:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 09:59:23 --> Input Class Initialized
INFO - 2024-07-17 09:59:23 --> Language Class Initialized
INFO - 2024-07-17 09:59:23 --> Language Class Initialized
INFO - 2024-07-17 09:59:23 --> Config Class Initialized
INFO - 2024-07-17 09:59:23 --> Loader Class Initialized
INFO - 2024-07-17 09:59:23 --> Helper loaded: url_helper
INFO - 2024-07-17 09:59:23 --> Helper loaded: file_helper
INFO - 2024-07-17 09:59:23 --> Helper loaded: form_helper
INFO - 2024-07-17 09:59:23 --> Helper loaded: my_helper
INFO - 2024-07-17 09:59:23 --> Database Driver Class Initialized
INFO - 2024-07-17 09:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 09:59:23 --> Controller Class Initialized
ERROR - 2024-07-17 09:59:23 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-17 09:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-17 09:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 09:59:23 --> Final output sent to browser
DEBUG - 2024-07-17 09:59:23 --> Total execution time: 0.0423
INFO - 2024-07-17 10:03:24 --> Config Class Initialized
INFO - 2024-07-17 10:03:24 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:24 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:24 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:24 --> URI Class Initialized
INFO - 2024-07-17 10:03:24 --> Router Class Initialized
INFO - 2024-07-17 10:03:24 --> Output Class Initialized
INFO - 2024-07-17 10:03:24 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:24 --> Input Class Initialized
INFO - 2024-07-17 10:03:24 --> Language Class Initialized
INFO - 2024-07-17 10:03:24 --> Language Class Initialized
INFO - 2024-07-17 10:03:24 --> Config Class Initialized
INFO - 2024-07-17 10:03:24 --> Loader Class Initialized
INFO - 2024-07-17 10:03:24 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:24 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:24 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:24 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:24 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:24 --> Controller Class Initialized
DEBUG - 2024-07-17 10:03:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 10:03:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:03:24 --> Final output sent to browser
DEBUG - 2024-07-17 10:03:24 --> Total execution time: 0.0275
INFO - 2024-07-17 10:03:24 --> Config Class Initialized
INFO - 2024-07-17 10:03:24 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:24 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:24 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:24 --> URI Class Initialized
INFO - 2024-07-17 10:03:24 --> Router Class Initialized
INFO - 2024-07-17 10:03:24 --> Output Class Initialized
INFO - 2024-07-17 10:03:24 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:24 --> Input Class Initialized
INFO - 2024-07-17 10:03:24 --> Language Class Initialized
ERROR - 2024-07-17 10:03:24 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:03:24 --> Config Class Initialized
INFO - 2024-07-17 10:03:24 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:24 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:24 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:24 --> URI Class Initialized
INFO - 2024-07-17 10:03:24 --> Router Class Initialized
INFO - 2024-07-17 10:03:24 --> Output Class Initialized
INFO - 2024-07-17 10:03:24 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:24 --> Input Class Initialized
INFO - 2024-07-17 10:03:24 --> Language Class Initialized
INFO - 2024-07-17 10:03:24 --> Language Class Initialized
INFO - 2024-07-17 10:03:24 --> Config Class Initialized
INFO - 2024-07-17 10:03:24 --> Loader Class Initialized
INFO - 2024-07-17 10:03:24 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:24 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:24 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:24 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:24 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:24 --> Controller Class Initialized
INFO - 2024-07-17 10:03:27 --> Config Class Initialized
INFO - 2024-07-17 10:03:27 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:27 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:27 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:27 --> URI Class Initialized
INFO - 2024-07-17 10:03:27 --> Router Class Initialized
INFO - 2024-07-17 10:03:27 --> Output Class Initialized
INFO - 2024-07-17 10:03:27 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:27 --> Input Class Initialized
INFO - 2024-07-17 10:03:27 --> Language Class Initialized
INFO - 2024-07-17 10:03:27 --> Language Class Initialized
INFO - 2024-07-17 10:03:27 --> Config Class Initialized
INFO - 2024-07-17 10:03:27 --> Loader Class Initialized
INFO - 2024-07-17 10:03:27 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:27 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:27 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:27 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:27 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:27 --> Controller Class Initialized
INFO - 2024-07-17 10:03:27 --> Config Class Initialized
INFO - 2024-07-17 10:03:27 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:27 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:27 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:27 --> URI Class Initialized
INFO - 2024-07-17 10:03:27 --> Router Class Initialized
INFO - 2024-07-17 10:03:27 --> Output Class Initialized
INFO - 2024-07-17 10:03:27 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:27 --> Input Class Initialized
INFO - 2024-07-17 10:03:27 --> Language Class Initialized
INFO - 2024-07-17 10:03:27 --> Language Class Initialized
INFO - 2024-07-17 10:03:27 --> Config Class Initialized
INFO - 2024-07-17 10:03:27 --> Loader Class Initialized
INFO - 2024-07-17 10:03:27 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:27 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:27 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:27 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:27 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:27 --> Controller Class Initialized
INFO - 2024-07-17 10:03:28 --> Config Class Initialized
INFO - 2024-07-17 10:03:28 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:28 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:28 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:28 --> URI Class Initialized
INFO - 2024-07-17 10:03:28 --> Router Class Initialized
INFO - 2024-07-17 10:03:28 --> Output Class Initialized
INFO - 2024-07-17 10:03:28 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:28 --> Input Class Initialized
INFO - 2024-07-17 10:03:28 --> Language Class Initialized
INFO - 2024-07-17 10:03:28 --> Language Class Initialized
INFO - 2024-07-17 10:03:28 --> Config Class Initialized
INFO - 2024-07-17 10:03:28 --> Loader Class Initialized
INFO - 2024-07-17 10:03:28 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:28 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:28 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:28 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:28 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:28 --> Controller Class Initialized
INFO - 2024-07-17 10:03:28 --> Config Class Initialized
INFO - 2024-07-17 10:03:28 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:28 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:28 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:28 --> URI Class Initialized
INFO - 2024-07-17 10:03:28 --> Router Class Initialized
INFO - 2024-07-17 10:03:28 --> Output Class Initialized
INFO - 2024-07-17 10:03:28 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:28 --> Input Class Initialized
INFO - 2024-07-17 10:03:28 --> Language Class Initialized
INFO - 2024-07-17 10:03:28 --> Language Class Initialized
INFO - 2024-07-17 10:03:28 --> Config Class Initialized
INFO - 2024-07-17 10:03:28 --> Loader Class Initialized
INFO - 2024-07-17 10:03:28 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:28 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:28 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:28 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:28 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:28 --> Controller Class Initialized
INFO - 2024-07-17 10:03:31 --> Config Class Initialized
INFO - 2024-07-17 10:03:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:31 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:31 --> URI Class Initialized
INFO - 2024-07-17 10:03:31 --> Router Class Initialized
INFO - 2024-07-17 10:03:31 --> Output Class Initialized
INFO - 2024-07-17 10:03:31 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:31 --> Input Class Initialized
INFO - 2024-07-17 10:03:31 --> Language Class Initialized
INFO - 2024-07-17 10:03:31 --> Language Class Initialized
INFO - 2024-07-17 10:03:31 --> Config Class Initialized
INFO - 2024-07-17 10:03:31 --> Loader Class Initialized
INFO - 2024-07-17 10:03:31 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:31 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:31 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:31 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:31 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:31 --> Controller Class Initialized
INFO - 2024-07-17 10:03:31 --> Config Class Initialized
INFO - 2024-07-17 10:03:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:03:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:03:31 --> Utf8 Class Initialized
INFO - 2024-07-17 10:03:31 --> URI Class Initialized
INFO - 2024-07-17 10:03:31 --> Router Class Initialized
INFO - 2024-07-17 10:03:31 --> Output Class Initialized
INFO - 2024-07-17 10:03:31 --> Security Class Initialized
DEBUG - 2024-07-17 10:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:03:31 --> Input Class Initialized
INFO - 2024-07-17 10:03:31 --> Language Class Initialized
INFO - 2024-07-17 10:03:31 --> Language Class Initialized
INFO - 2024-07-17 10:03:31 --> Config Class Initialized
INFO - 2024-07-17 10:03:31 --> Loader Class Initialized
INFO - 2024-07-17 10:03:31 --> Helper loaded: url_helper
INFO - 2024-07-17 10:03:31 --> Helper loaded: file_helper
INFO - 2024-07-17 10:03:31 --> Helper loaded: form_helper
INFO - 2024-07-17 10:03:31 --> Helper loaded: my_helper
INFO - 2024-07-17 10:03:31 --> Database Driver Class Initialized
INFO - 2024-07-17 10:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:03:31 --> Controller Class Initialized
INFO - 2024-07-17 10:10:24 --> Config Class Initialized
INFO - 2024-07-17 10:10:24 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:10:24 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:10:24 --> Utf8 Class Initialized
INFO - 2024-07-17 10:10:24 --> URI Class Initialized
INFO - 2024-07-17 10:10:24 --> Router Class Initialized
INFO - 2024-07-17 10:10:24 --> Output Class Initialized
INFO - 2024-07-17 10:10:24 --> Security Class Initialized
DEBUG - 2024-07-17 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:10:24 --> Input Class Initialized
INFO - 2024-07-17 10:10:24 --> Language Class Initialized
INFO - 2024-07-17 10:10:24 --> Language Class Initialized
INFO - 2024-07-17 10:10:24 --> Config Class Initialized
INFO - 2024-07-17 10:10:24 --> Loader Class Initialized
INFO - 2024-07-17 10:10:24 --> Helper loaded: url_helper
INFO - 2024-07-17 10:10:24 --> Helper loaded: file_helper
INFO - 2024-07-17 10:10:24 --> Helper loaded: form_helper
INFO - 2024-07-17 10:10:24 --> Helper loaded: my_helper
INFO - 2024-07-17 10:10:24 --> Database Driver Class Initialized
INFO - 2024-07-17 10:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:10:24 --> Controller Class Initialized
DEBUG - 2024-07-17 10:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-17 10:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:10:24 --> Final output sent to browser
DEBUG - 2024-07-17 10:10:24 --> Total execution time: 0.0279
INFO - 2024-07-17 10:44:16 --> Config Class Initialized
INFO - 2024-07-17 10:44:16 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:16 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:16 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:16 --> URI Class Initialized
INFO - 2024-07-17 10:44:16 --> Router Class Initialized
INFO - 2024-07-17 10:44:16 --> Output Class Initialized
INFO - 2024-07-17 10:44:16 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:16 --> Input Class Initialized
INFO - 2024-07-17 10:44:16 --> Language Class Initialized
INFO - 2024-07-17 10:44:16 --> Language Class Initialized
INFO - 2024-07-17 10:44:16 --> Config Class Initialized
INFO - 2024-07-17 10:44:16 --> Loader Class Initialized
INFO - 2024-07-17 10:44:16 --> Helper loaded: url_helper
INFO - 2024-07-17 10:44:16 --> Helper loaded: file_helper
INFO - 2024-07-17 10:44:16 --> Helper loaded: form_helper
INFO - 2024-07-17 10:44:16 --> Helper loaded: my_helper
INFO - 2024-07-17 10:44:16 --> Database Driver Class Initialized
INFO - 2024-07-17 10:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:44:16 --> Controller Class Initialized
DEBUG - 2024-07-17 10:44:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-17 10:44:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:44:16 --> Final output sent to browser
DEBUG - 2024-07-17 10:44:16 --> Total execution time: 0.0666
INFO - 2024-07-17 10:44:31 --> Config Class Initialized
INFO - 2024-07-17 10:44:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:31 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:31 --> URI Class Initialized
INFO - 2024-07-17 10:44:31 --> Router Class Initialized
INFO - 2024-07-17 10:44:31 --> Output Class Initialized
INFO - 2024-07-17 10:44:31 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:31 --> Input Class Initialized
INFO - 2024-07-17 10:44:31 --> Language Class Initialized
INFO - 2024-07-17 10:44:31 --> Language Class Initialized
INFO - 2024-07-17 10:44:31 --> Config Class Initialized
INFO - 2024-07-17 10:44:31 --> Loader Class Initialized
INFO - 2024-07-17 10:44:31 --> Helper loaded: url_helper
INFO - 2024-07-17 10:44:31 --> Helper loaded: file_helper
INFO - 2024-07-17 10:44:31 --> Helper loaded: form_helper
INFO - 2024-07-17 10:44:31 --> Helper loaded: my_helper
INFO - 2024-07-17 10:44:31 --> Database Driver Class Initialized
INFO - 2024-07-17 10:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:44:31 --> Controller Class Initialized
DEBUG - 2024-07-17 10:44:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 10:44:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:44:31 --> Final output sent to browser
DEBUG - 2024-07-17 10:44:31 --> Total execution time: 0.0348
INFO - 2024-07-17 10:44:31 --> Config Class Initialized
INFO - 2024-07-17 10:44:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:31 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:31 --> URI Class Initialized
INFO - 2024-07-17 10:44:31 --> Router Class Initialized
INFO - 2024-07-17 10:44:31 --> Output Class Initialized
INFO - 2024-07-17 10:44:31 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:31 --> Input Class Initialized
INFO - 2024-07-17 10:44:31 --> Language Class Initialized
ERROR - 2024-07-17 10:44:31 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:44:31 --> Config Class Initialized
INFO - 2024-07-17 10:44:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:31 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:31 --> URI Class Initialized
INFO - 2024-07-17 10:44:31 --> Router Class Initialized
INFO - 2024-07-17 10:44:31 --> Output Class Initialized
INFO - 2024-07-17 10:44:31 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:31 --> Input Class Initialized
INFO - 2024-07-17 10:44:31 --> Language Class Initialized
INFO - 2024-07-17 10:44:31 --> Language Class Initialized
INFO - 2024-07-17 10:44:31 --> Config Class Initialized
INFO - 2024-07-17 10:44:31 --> Loader Class Initialized
INFO - 2024-07-17 10:44:31 --> Helper loaded: url_helper
INFO - 2024-07-17 10:44:31 --> Helper loaded: file_helper
INFO - 2024-07-17 10:44:31 --> Helper loaded: form_helper
INFO - 2024-07-17 10:44:31 --> Helper loaded: my_helper
INFO - 2024-07-17 10:44:31 --> Database Driver Class Initialized
INFO - 2024-07-17 10:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:44:31 --> Controller Class Initialized
INFO - 2024-07-17 10:44:42 --> Config Class Initialized
INFO - 2024-07-17 10:44:42 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:42 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:42 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:42 --> URI Class Initialized
INFO - 2024-07-17 10:44:42 --> Router Class Initialized
INFO - 2024-07-17 10:44:42 --> Output Class Initialized
INFO - 2024-07-17 10:44:42 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:42 --> Input Class Initialized
INFO - 2024-07-17 10:44:42 --> Language Class Initialized
INFO - 2024-07-17 10:44:42 --> Language Class Initialized
INFO - 2024-07-17 10:44:42 --> Config Class Initialized
INFO - 2024-07-17 10:44:42 --> Loader Class Initialized
INFO - 2024-07-17 10:44:42 --> Helper loaded: url_helper
INFO - 2024-07-17 10:44:42 --> Helper loaded: file_helper
INFO - 2024-07-17 10:44:42 --> Helper loaded: form_helper
INFO - 2024-07-17 10:44:42 --> Helper loaded: my_helper
INFO - 2024-07-17 10:44:42 --> Database Driver Class Initialized
INFO - 2024-07-17 10:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:44:42 --> Controller Class Initialized
DEBUG - 2024-07-17 10:44:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-07-17 10:44:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:44:42 --> Final output sent to browser
DEBUG - 2024-07-17 10:44:42 --> Total execution time: 0.0765
INFO - 2024-07-17 10:44:42 --> Config Class Initialized
INFO - 2024-07-17 10:44:42 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:42 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:42 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:42 --> URI Class Initialized
INFO - 2024-07-17 10:44:42 --> Router Class Initialized
INFO - 2024-07-17 10:44:42 --> Output Class Initialized
INFO - 2024-07-17 10:44:42 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:42 --> Input Class Initialized
INFO - 2024-07-17 10:44:42 --> Language Class Initialized
ERROR - 2024-07-17 10:44:42 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:44:42 --> Config Class Initialized
INFO - 2024-07-17 10:44:42 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:44:42 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:44:42 --> Utf8 Class Initialized
INFO - 2024-07-17 10:44:42 --> URI Class Initialized
INFO - 2024-07-17 10:44:42 --> Router Class Initialized
INFO - 2024-07-17 10:44:42 --> Output Class Initialized
INFO - 2024-07-17 10:44:42 --> Security Class Initialized
DEBUG - 2024-07-17 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:44:42 --> Input Class Initialized
INFO - 2024-07-17 10:44:42 --> Language Class Initialized
INFO - 2024-07-17 10:44:42 --> Language Class Initialized
INFO - 2024-07-17 10:44:42 --> Config Class Initialized
INFO - 2024-07-17 10:44:42 --> Loader Class Initialized
INFO - 2024-07-17 10:44:42 --> Helper loaded: url_helper
INFO - 2024-07-17 10:44:42 --> Helper loaded: file_helper
INFO - 2024-07-17 10:44:42 --> Helper loaded: form_helper
INFO - 2024-07-17 10:44:42 --> Helper loaded: my_helper
INFO - 2024-07-17 10:44:42 --> Database Driver Class Initialized
INFO - 2024-07-17 10:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:44:42 --> Controller Class Initialized
INFO - 2024-07-17 10:45:58 --> Config Class Initialized
INFO - 2024-07-17 10:45:58 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:45:58 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:45:58 --> Utf8 Class Initialized
INFO - 2024-07-17 10:45:58 --> URI Class Initialized
INFO - 2024-07-17 10:45:58 --> Router Class Initialized
INFO - 2024-07-17 10:45:58 --> Output Class Initialized
INFO - 2024-07-17 10:45:58 --> Security Class Initialized
DEBUG - 2024-07-17 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:45:58 --> Input Class Initialized
INFO - 2024-07-17 10:45:58 --> Language Class Initialized
INFO - 2024-07-17 10:45:58 --> Language Class Initialized
INFO - 2024-07-17 10:45:58 --> Config Class Initialized
INFO - 2024-07-17 10:45:58 --> Loader Class Initialized
INFO - 2024-07-17 10:45:58 --> Helper loaded: url_helper
INFO - 2024-07-17 10:45:58 --> Helper loaded: file_helper
INFO - 2024-07-17 10:45:58 --> Helper loaded: form_helper
INFO - 2024-07-17 10:45:58 --> Helper loaded: my_helper
INFO - 2024-07-17 10:45:58 --> Database Driver Class Initialized
INFO - 2024-07-17 10:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:45:58 --> Controller Class Initialized
INFO - 2024-07-17 10:45:58 --> Final output sent to browser
DEBUG - 2024-07-17 10:45:58 --> Total execution time: 0.0344
INFO - 2024-07-17 10:46:43 --> Config Class Initialized
INFO - 2024-07-17 10:46:43 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:43 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:43 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:43 --> URI Class Initialized
INFO - 2024-07-17 10:46:43 --> Router Class Initialized
INFO - 2024-07-17 10:46:43 --> Output Class Initialized
INFO - 2024-07-17 10:46:43 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:43 --> Input Class Initialized
INFO - 2024-07-17 10:46:43 --> Language Class Initialized
INFO - 2024-07-17 10:46:43 --> Language Class Initialized
INFO - 2024-07-17 10:46:43 --> Config Class Initialized
INFO - 2024-07-17 10:46:43 --> Loader Class Initialized
INFO - 2024-07-17 10:46:43 --> Helper loaded: url_helper
INFO - 2024-07-17 10:46:43 --> Helper loaded: file_helper
INFO - 2024-07-17 10:46:43 --> Helper loaded: form_helper
INFO - 2024-07-17 10:46:43 --> Helper loaded: my_helper
INFO - 2024-07-17 10:46:43 --> Database Driver Class Initialized
INFO - 2024-07-17 10:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:46:43 --> Controller Class Initialized
INFO - 2024-07-17 10:46:43 --> Final output sent to browser
DEBUG - 2024-07-17 10:46:43 --> Total execution time: 0.0313
INFO - 2024-07-17 10:46:43 --> Config Class Initialized
INFO - 2024-07-17 10:46:43 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:43 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:43 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:43 --> URI Class Initialized
INFO - 2024-07-17 10:46:43 --> Router Class Initialized
INFO - 2024-07-17 10:46:43 --> Output Class Initialized
INFO - 2024-07-17 10:46:43 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:43 --> Input Class Initialized
INFO - 2024-07-17 10:46:43 --> Language Class Initialized
ERROR - 2024-07-17 10:46:43 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:46:44 --> Config Class Initialized
INFO - 2024-07-17 10:46:44 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:44 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:44 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:44 --> URI Class Initialized
INFO - 2024-07-17 10:46:44 --> Router Class Initialized
INFO - 2024-07-17 10:46:44 --> Output Class Initialized
INFO - 2024-07-17 10:46:44 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:44 --> Input Class Initialized
INFO - 2024-07-17 10:46:44 --> Language Class Initialized
INFO - 2024-07-17 10:46:44 --> Language Class Initialized
INFO - 2024-07-17 10:46:44 --> Config Class Initialized
INFO - 2024-07-17 10:46:44 --> Loader Class Initialized
INFO - 2024-07-17 10:46:44 --> Helper loaded: url_helper
INFO - 2024-07-17 10:46:44 --> Helper loaded: file_helper
INFO - 2024-07-17 10:46:44 --> Helper loaded: form_helper
INFO - 2024-07-17 10:46:44 --> Helper loaded: my_helper
INFO - 2024-07-17 10:46:44 --> Database Driver Class Initialized
INFO - 2024-07-17 10:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:46:44 --> Controller Class Initialized
INFO - 2024-07-17 10:46:50 --> Config Class Initialized
INFO - 2024-07-17 10:46:50 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:50 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:50 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:50 --> URI Class Initialized
INFO - 2024-07-17 10:46:50 --> Router Class Initialized
INFO - 2024-07-17 10:46:50 --> Output Class Initialized
INFO - 2024-07-17 10:46:50 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:50 --> Input Class Initialized
INFO - 2024-07-17 10:46:50 --> Language Class Initialized
INFO - 2024-07-17 10:46:50 --> Language Class Initialized
INFO - 2024-07-17 10:46:50 --> Config Class Initialized
INFO - 2024-07-17 10:46:50 --> Loader Class Initialized
INFO - 2024-07-17 10:46:50 --> Helper loaded: url_helper
INFO - 2024-07-17 10:46:50 --> Helper loaded: file_helper
INFO - 2024-07-17 10:46:50 --> Helper loaded: form_helper
INFO - 2024-07-17 10:46:50 --> Helper loaded: my_helper
INFO - 2024-07-17 10:46:50 --> Database Driver Class Initialized
INFO - 2024-07-17 10:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:46:50 --> Controller Class Initialized
INFO - 2024-07-17 10:46:50 --> Final output sent to browser
DEBUG - 2024-07-17 10:46:50 --> Total execution time: 0.0299
INFO - 2024-07-17 10:46:53 --> Config Class Initialized
INFO - 2024-07-17 10:46:53 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:53 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:53 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:53 --> URI Class Initialized
INFO - 2024-07-17 10:46:53 --> Router Class Initialized
INFO - 2024-07-17 10:46:53 --> Output Class Initialized
INFO - 2024-07-17 10:46:53 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:53 --> Input Class Initialized
INFO - 2024-07-17 10:46:53 --> Language Class Initialized
INFO - 2024-07-17 10:46:53 --> Language Class Initialized
INFO - 2024-07-17 10:46:53 --> Config Class Initialized
INFO - 2024-07-17 10:46:53 --> Loader Class Initialized
INFO - 2024-07-17 10:46:53 --> Helper loaded: url_helper
INFO - 2024-07-17 10:46:53 --> Helper loaded: file_helper
INFO - 2024-07-17 10:46:53 --> Helper loaded: form_helper
INFO - 2024-07-17 10:46:53 --> Helper loaded: my_helper
INFO - 2024-07-17 10:46:53 --> Database Driver Class Initialized
INFO - 2024-07-17 10:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:46:53 --> Controller Class Initialized
INFO - 2024-07-17 10:46:53 --> Final output sent to browser
DEBUG - 2024-07-17 10:46:53 --> Total execution time: 0.0300
INFO - 2024-07-17 10:46:53 --> Config Class Initialized
INFO - 2024-07-17 10:46:53 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:53 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:53 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:53 --> URI Class Initialized
INFO - 2024-07-17 10:46:53 --> Router Class Initialized
INFO - 2024-07-17 10:46:53 --> Output Class Initialized
INFO - 2024-07-17 10:46:53 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:53 --> Input Class Initialized
INFO - 2024-07-17 10:46:53 --> Language Class Initialized
ERROR - 2024-07-17 10:46:53 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:46:53 --> Config Class Initialized
INFO - 2024-07-17 10:46:53 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:46:53 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:46:53 --> Utf8 Class Initialized
INFO - 2024-07-17 10:46:53 --> URI Class Initialized
INFO - 2024-07-17 10:46:53 --> Router Class Initialized
INFO - 2024-07-17 10:46:53 --> Output Class Initialized
INFO - 2024-07-17 10:46:53 --> Security Class Initialized
DEBUG - 2024-07-17 10:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:46:53 --> Input Class Initialized
INFO - 2024-07-17 10:46:53 --> Language Class Initialized
INFO - 2024-07-17 10:46:53 --> Language Class Initialized
INFO - 2024-07-17 10:46:53 --> Config Class Initialized
INFO - 2024-07-17 10:46:53 --> Loader Class Initialized
INFO - 2024-07-17 10:46:53 --> Helper loaded: url_helper
INFO - 2024-07-17 10:46:53 --> Helper loaded: file_helper
INFO - 2024-07-17 10:46:53 --> Helper loaded: form_helper
INFO - 2024-07-17 10:46:53 --> Helper loaded: my_helper
INFO - 2024-07-17 10:46:53 --> Database Driver Class Initialized
INFO - 2024-07-17 10:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:46:53 --> Controller Class Initialized
INFO - 2024-07-17 10:47:01 --> Config Class Initialized
INFO - 2024-07-17 10:47:01 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:01 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:01 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:01 --> URI Class Initialized
INFO - 2024-07-17 10:47:01 --> Router Class Initialized
INFO - 2024-07-17 10:47:01 --> Output Class Initialized
INFO - 2024-07-17 10:47:01 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:01 --> Input Class Initialized
INFO - 2024-07-17 10:47:01 --> Language Class Initialized
INFO - 2024-07-17 10:47:01 --> Language Class Initialized
INFO - 2024-07-17 10:47:01 --> Config Class Initialized
INFO - 2024-07-17 10:47:01 --> Loader Class Initialized
INFO - 2024-07-17 10:47:01 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:01 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:01 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:01 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:01 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:01 --> Controller Class Initialized
INFO - 2024-07-17 10:47:01 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:01 --> Total execution time: 0.0371
INFO - 2024-07-17 10:47:01 --> Config Class Initialized
INFO - 2024-07-17 10:47:01 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:01 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:01 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:01 --> URI Class Initialized
INFO - 2024-07-17 10:47:01 --> Router Class Initialized
INFO - 2024-07-17 10:47:01 --> Output Class Initialized
INFO - 2024-07-17 10:47:01 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:01 --> Input Class Initialized
INFO - 2024-07-17 10:47:01 --> Language Class Initialized
ERROR - 2024-07-17 10:47:01 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:47:01 --> Config Class Initialized
INFO - 2024-07-17 10:47:01 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:01 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:01 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:01 --> URI Class Initialized
INFO - 2024-07-17 10:47:01 --> Router Class Initialized
INFO - 2024-07-17 10:47:01 --> Output Class Initialized
INFO - 2024-07-17 10:47:01 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:01 --> Input Class Initialized
INFO - 2024-07-17 10:47:01 --> Language Class Initialized
INFO - 2024-07-17 10:47:01 --> Language Class Initialized
INFO - 2024-07-17 10:47:01 --> Config Class Initialized
INFO - 2024-07-17 10:47:01 --> Loader Class Initialized
INFO - 2024-07-17 10:47:01 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:01 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:01 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:01 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:01 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:01 --> Controller Class Initialized
INFO - 2024-07-17 10:47:15 --> Config Class Initialized
INFO - 2024-07-17 10:47:15 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:15 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:15 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:15 --> URI Class Initialized
INFO - 2024-07-17 10:47:15 --> Router Class Initialized
INFO - 2024-07-17 10:47:15 --> Output Class Initialized
INFO - 2024-07-17 10:47:15 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:15 --> Input Class Initialized
INFO - 2024-07-17 10:47:15 --> Language Class Initialized
INFO - 2024-07-17 10:47:15 --> Language Class Initialized
INFO - 2024-07-17 10:47:15 --> Config Class Initialized
INFO - 2024-07-17 10:47:15 --> Loader Class Initialized
INFO - 2024-07-17 10:47:15 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:15 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:15 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:15 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:15 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:15 --> Controller Class Initialized
INFO - 2024-07-17 10:47:15 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:15 --> Total execution time: 0.0279
INFO - 2024-07-17 10:47:19 --> Config Class Initialized
INFO - 2024-07-17 10:47:19 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:19 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:19 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:19 --> URI Class Initialized
INFO - 2024-07-17 10:47:19 --> Router Class Initialized
INFO - 2024-07-17 10:47:19 --> Output Class Initialized
INFO - 2024-07-17 10:47:19 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:19 --> Input Class Initialized
INFO - 2024-07-17 10:47:19 --> Language Class Initialized
INFO - 2024-07-17 10:47:19 --> Language Class Initialized
INFO - 2024-07-17 10:47:19 --> Config Class Initialized
INFO - 2024-07-17 10:47:19 --> Loader Class Initialized
INFO - 2024-07-17 10:47:19 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:19 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:19 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:19 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:19 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:19 --> Controller Class Initialized
INFO - 2024-07-17 10:47:19 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:19 --> Total execution time: 0.0872
INFO - 2024-07-17 10:47:19 --> Config Class Initialized
INFO - 2024-07-17 10:47:19 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:19 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:19 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:19 --> URI Class Initialized
INFO - 2024-07-17 10:47:19 --> Router Class Initialized
INFO - 2024-07-17 10:47:19 --> Output Class Initialized
INFO - 2024-07-17 10:47:19 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:19 --> Input Class Initialized
INFO - 2024-07-17 10:47:19 --> Language Class Initialized
ERROR - 2024-07-17 10:47:19 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:47:19 --> Config Class Initialized
INFO - 2024-07-17 10:47:19 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:19 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:19 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:19 --> URI Class Initialized
INFO - 2024-07-17 10:47:19 --> Router Class Initialized
INFO - 2024-07-17 10:47:19 --> Output Class Initialized
INFO - 2024-07-17 10:47:19 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:19 --> Input Class Initialized
INFO - 2024-07-17 10:47:19 --> Language Class Initialized
INFO - 2024-07-17 10:47:19 --> Language Class Initialized
INFO - 2024-07-17 10:47:19 --> Config Class Initialized
INFO - 2024-07-17 10:47:19 --> Loader Class Initialized
INFO - 2024-07-17 10:47:19 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:19 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:19 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:19 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:19 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:19 --> Controller Class Initialized
INFO - 2024-07-17 10:47:24 --> Config Class Initialized
INFO - 2024-07-17 10:47:24 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:24 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:24 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:24 --> URI Class Initialized
INFO - 2024-07-17 10:47:24 --> Router Class Initialized
INFO - 2024-07-17 10:47:24 --> Output Class Initialized
INFO - 2024-07-17 10:47:24 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:24 --> Input Class Initialized
INFO - 2024-07-17 10:47:24 --> Language Class Initialized
INFO - 2024-07-17 10:47:24 --> Language Class Initialized
INFO - 2024-07-17 10:47:24 --> Config Class Initialized
INFO - 2024-07-17 10:47:24 --> Loader Class Initialized
INFO - 2024-07-17 10:47:24 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:24 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:24 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:24 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:24 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:24 --> Controller Class Initialized
INFO - 2024-07-17 10:47:24 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:24 --> Total execution time: 0.0312
INFO - 2024-07-17 10:47:27 --> Config Class Initialized
INFO - 2024-07-17 10:47:27 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:27 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:27 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:27 --> URI Class Initialized
INFO - 2024-07-17 10:47:27 --> Router Class Initialized
INFO - 2024-07-17 10:47:27 --> Output Class Initialized
INFO - 2024-07-17 10:47:27 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:27 --> Input Class Initialized
INFO - 2024-07-17 10:47:27 --> Language Class Initialized
INFO - 2024-07-17 10:47:27 --> Language Class Initialized
INFO - 2024-07-17 10:47:27 --> Config Class Initialized
INFO - 2024-07-17 10:47:27 --> Loader Class Initialized
INFO - 2024-07-17 10:47:27 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:27 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:27 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:27 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:27 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:27 --> Controller Class Initialized
INFO - 2024-07-17 10:47:27 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:27 --> Total execution time: 0.0309
INFO - 2024-07-17 10:47:27 --> Config Class Initialized
INFO - 2024-07-17 10:47:27 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:27 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:27 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:27 --> URI Class Initialized
INFO - 2024-07-17 10:47:27 --> Router Class Initialized
INFO - 2024-07-17 10:47:27 --> Output Class Initialized
INFO - 2024-07-17 10:47:27 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:27 --> Input Class Initialized
INFO - 2024-07-17 10:47:27 --> Language Class Initialized
ERROR - 2024-07-17 10:47:27 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:47:27 --> Config Class Initialized
INFO - 2024-07-17 10:47:27 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:27 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:27 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:27 --> URI Class Initialized
INFO - 2024-07-17 10:47:27 --> Router Class Initialized
INFO - 2024-07-17 10:47:27 --> Output Class Initialized
INFO - 2024-07-17 10:47:27 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:27 --> Input Class Initialized
INFO - 2024-07-17 10:47:27 --> Language Class Initialized
INFO - 2024-07-17 10:47:27 --> Language Class Initialized
INFO - 2024-07-17 10:47:27 --> Config Class Initialized
INFO - 2024-07-17 10:47:27 --> Loader Class Initialized
INFO - 2024-07-17 10:47:27 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:27 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:27 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:27 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:27 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:27 --> Controller Class Initialized
INFO - 2024-07-17 10:47:35 --> Config Class Initialized
INFO - 2024-07-17 10:47:35 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:35 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:35 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:35 --> URI Class Initialized
INFO - 2024-07-17 10:47:35 --> Router Class Initialized
INFO - 2024-07-17 10:47:35 --> Output Class Initialized
INFO - 2024-07-17 10:47:35 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:35 --> Input Class Initialized
INFO - 2024-07-17 10:47:35 --> Language Class Initialized
INFO - 2024-07-17 10:47:35 --> Language Class Initialized
INFO - 2024-07-17 10:47:35 --> Config Class Initialized
INFO - 2024-07-17 10:47:35 --> Loader Class Initialized
INFO - 2024-07-17 10:47:35 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:35 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:35 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:35 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:35 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:35 --> Controller Class Initialized
INFO - 2024-07-17 10:47:35 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:35 --> Total execution time: 0.0402
INFO - 2024-07-17 10:47:38 --> Config Class Initialized
INFO - 2024-07-17 10:47:38 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:38 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:38 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:38 --> URI Class Initialized
INFO - 2024-07-17 10:47:38 --> Router Class Initialized
INFO - 2024-07-17 10:47:38 --> Output Class Initialized
INFO - 2024-07-17 10:47:38 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:38 --> Input Class Initialized
INFO - 2024-07-17 10:47:38 --> Language Class Initialized
INFO - 2024-07-17 10:47:38 --> Language Class Initialized
INFO - 2024-07-17 10:47:38 --> Config Class Initialized
INFO - 2024-07-17 10:47:38 --> Loader Class Initialized
INFO - 2024-07-17 10:47:38 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:38 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:38 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:38 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:38 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:38 --> Controller Class Initialized
INFO - 2024-07-17 10:47:38 --> Final output sent to browser
DEBUG - 2024-07-17 10:47:38 --> Total execution time: 0.1076
INFO - 2024-07-17 10:47:38 --> Config Class Initialized
INFO - 2024-07-17 10:47:38 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:38 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:38 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:38 --> URI Class Initialized
INFO - 2024-07-17 10:47:38 --> Router Class Initialized
INFO - 2024-07-17 10:47:38 --> Output Class Initialized
INFO - 2024-07-17 10:47:38 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:38 --> Input Class Initialized
INFO - 2024-07-17 10:47:38 --> Language Class Initialized
ERROR - 2024-07-17 10:47:38 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:47:38 --> Config Class Initialized
INFO - 2024-07-17 10:47:38 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:47:38 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:47:38 --> Utf8 Class Initialized
INFO - 2024-07-17 10:47:38 --> URI Class Initialized
INFO - 2024-07-17 10:47:38 --> Router Class Initialized
INFO - 2024-07-17 10:47:38 --> Output Class Initialized
INFO - 2024-07-17 10:47:38 --> Security Class Initialized
DEBUG - 2024-07-17 10:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:47:38 --> Input Class Initialized
INFO - 2024-07-17 10:47:38 --> Language Class Initialized
INFO - 2024-07-17 10:47:38 --> Language Class Initialized
INFO - 2024-07-17 10:47:38 --> Config Class Initialized
INFO - 2024-07-17 10:47:38 --> Loader Class Initialized
INFO - 2024-07-17 10:47:38 --> Helper loaded: url_helper
INFO - 2024-07-17 10:47:38 --> Helper loaded: file_helper
INFO - 2024-07-17 10:47:38 --> Helper loaded: form_helper
INFO - 2024-07-17 10:47:38 --> Helper loaded: my_helper
INFO - 2024-07-17 10:47:38 --> Database Driver Class Initialized
INFO - 2024-07-17 10:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:47:38 --> Controller Class Initialized
INFO - 2024-07-17 10:59:50 --> Config Class Initialized
INFO - 2024-07-17 10:59:50 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:59:50 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:59:50 --> Utf8 Class Initialized
INFO - 2024-07-17 10:59:50 --> URI Class Initialized
INFO - 2024-07-17 10:59:50 --> Router Class Initialized
INFO - 2024-07-17 10:59:50 --> Output Class Initialized
INFO - 2024-07-17 10:59:50 --> Security Class Initialized
DEBUG - 2024-07-17 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:59:50 --> Input Class Initialized
INFO - 2024-07-17 10:59:50 --> Language Class Initialized
INFO - 2024-07-17 10:59:50 --> Language Class Initialized
INFO - 2024-07-17 10:59:50 --> Config Class Initialized
INFO - 2024-07-17 10:59:50 --> Loader Class Initialized
INFO - 2024-07-17 10:59:50 --> Helper loaded: url_helper
INFO - 2024-07-17 10:59:50 --> Helper loaded: file_helper
INFO - 2024-07-17 10:59:50 --> Helper loaded: form_helper
INFO - 2024-07-17 10:59:50 --> Helper loaded: my_helper
INFO - 2024-07-17 10:59:50 --> Database Driver Class Initialized
INFO - 2024-07-17 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:59:50 --> Controller Class Initialized
DEBUG - 2024-07-17 10:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 10:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:59:50 --> Final output sent to browser
DEBUG - 2024-07-17 10:59:50 --> Total execution time: 0.0523
INFO - 2024-07-17 10:59:50 --> Config Class Initialized
INFO - 2024-07-17 10:59:50 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:59:50 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:59:50 --> Utf8 Class Initialized
INFO - 2024-07-17 10:59:50 --> URI Class Initialized
INFO - 2024-07-17 10:59:50 --> Router Class Initialized
INFO - 2024-07-17 10:59:50 --> Output Class Initialized
INFO - 2024-07-17 10:59:50 --> Security Class Initialized
DEBUG - 2024-07-17 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:59:50 --> Input Class Initialized
INFO - 2024-07-17 10:59:50 --> Language Class Initialized
ERROR - 2024-07-17 10:59:50 --> 404 Page Not Found: /index
INFO - 2024-07-17 10:59:50 --> Config Class Initialized
INFO - 2024-07-17 10:59:50 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:59:50 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:59:50 --> Utf8 Class Initialized
INFO - 2024-07-17 10:59:50 --> URI Class Initialized
INFO - 2024-07-17 10:59:50 --> Router Class Initialized
INFO - 2024-07-17 10:59:50 --> Output Class Initialized
INFO - 2024-07-17 10:59:50 --> Security Class Initialized
DEBUG - 2024-07-17 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:59:50 --> Input Class Initialized
INFO - 2024-07-17 10:59:50 --> Language Class Initialized
INFO - 2024-07-17 10:59:50 --> Language Class Initialized
INFO - 2024-07-17 10:59:50 --> Config Class Initialized
INFO - 2024-07-17 10:59:50 --> Loader Class Initialized
INFO - 2024-07-17 10:59:50 --> Helper loaded: url_helper
INFO - 2024-07-17 10:59:50 --> Helper loaded: file_helper
INFO - 2024-07-17 10:59:50 --> Helper loaded: form_helper
INFO - 2024-07-17 10:59:50 --> Helper loaded: my_helper
INFO - 2024-07-17 10:59:50 --> Database Driver Class Initialized
INFO - 2024-07-17 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:59:50 --> Controller Class Initialized
INFO - 2024-07-17 10:59:52 --> Config Class Initialized
INFO - 2024-07-17 10:59:52 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:59:52 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:59:52 --> Utf8 Class Initialized
INFO - 2024-07-17 10:59:52 --> URI Class Initialized
INFO - 2024-07-17 10:59:52 --> Router Class Initialized
INFO - 2024-07-17 10:59:52 --> Output Class Initialized
INFO - 2024-07-17 10:59:52 --> Security Class Initialized
DEBUG - 2024-07-17 10:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:59:52 --> Input Class Initialized
INFO - 2024-07-17 10:59:52 --> Language Class Initialized
INFO - 2024-07-17 10:59:52 --> Language Class Initialized
INFO - 2024-07-17 10:59:52 --> Config Class Initialized
INFO - 2024-07-17 10:59:52 --> Loader Class Initialized
INFO - 2024-07-17 10:59:52 --> Helper loaded: url_helper
INFO - 2024-07-17 10:59:52 --> Helper loaded: file_helper
INFO - 2024-07-17 10:59:52 --> Helper loaded: form_helper
INFO - 2024-07-17 10:59:52 --> Helper loaded: my_helper
INFO - 2024-07-17 10:59:52 --> Database Driver Class Initialized
INFO - 2024-07-17 10:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:59:52 --> Controller Class Initialized
DEBUG - 2024-07-17 10:59:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 10:59:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 10:59:52 --> Final output sent to browser
DEBUG - 2024-07-17 10:59:52 --> Total execution time: 0.0504
INFO - 2024-07-17 10:59:58 --> Config Class Initialized
INFO - 2024-07-17 10:59:58 --> Hooks Class Initialized
DEBUG - 2024-07-17 10:59:58 --> UTF-8 Support Enabled
INFO - 2024-07-17 10:59:58 --> Utf8 Class Initialized
INFO - 2024-07-17 10:59:58 --> URI Class Initialized
INFO - 2024-07-17 10:59:58 --> Router Class Initialized
INFO - 2024-07-17 10:59:58 --> Output Class Initialized
INFO - 2024-07-17 10:59:58 --> Security Class Initialized
DEBUG - 2024-07-17 10:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 10:59:58 --> Input Class Initialized
INFO - 2024-07-17 10:59:58 --> Language Class Initialized
INFO - 2024-07-17 10:59:58 --> Language Class Initialized
INFO - 2024-07-17 10:59:58 --> Config Class Initialized
INFO - 2024-07-17 10:59:58 --> Loader Class Initialized
INFO - 2024-07-17 10:59:58 --> Helper loaded: url_helper
INFO - 2024-07-17 10:59:58 --> Helper loaded: file_helper
INFO - 2024-07-17 10:59:58 --> Helper loaded: form_helper
INFO - 2024-07-17 10:59:58 --> Helper loaded: my_helper
INFO - 2024-07-17 10:59:58 --> Database Driver Class Initialized
INFO - 2024-07-17 10:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 10:59:58 --> Controller Class Initialized
ERROR - 2024-07-17 10:59:58 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:00:01 --> Config Class Initialized
INFO - 2024-07-17 11:00:01 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:01 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:01 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:01 --> URI Class Initialized
INFO - 2024-07-17 11:00:01 --> Router Class Initialized
INFO - 2024-07-17 11:00:01 --> Output Class Initialized
INFO - 2024-07-17 11:00:01 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:01 --> Input Class Initialized
INFO - 2024-07-17 11:00:01 --> Language Class Initialized
INFO - 2024-07-17 11:00:01 --> Language Class Initialized
INFO - 2024-07-17 11:00:01 --> Config Class Initialized
INFO - 2024-07-17 11:00:01 --> Loader Class Initialized
INFO - 2024-07-17 11:00:01 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:01 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:01 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:01 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:01 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:01 --> Controller Class Initialized
DEBUG - 2024-07-17 11:00:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:00:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:00:01 --> Final output sent to browser
DEBUG - 2024-07-17 11:00:01 --> Total execution time: 0.4995
INFO - 2024-07-17 11:00:04 --> Config Class Initialized
INFO - 2024-07-17 11:00:04 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:04 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:04 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:04 --> URI Class Initialized
INFO - 2024-07-17 11:00:04 --> Router Class Initialized
INFO - 2024-07-17 11:00:04 --> Output Class Initialized
INFO - 2024-07-17 11:00:04 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:04 --> Input Class Initialized
INFO - 2024-07-17 11:00:04 --> Language Class Initialized
INFO - 2024-07-17 11:00:04 --> Language Class Initialized
INFO - 2024-07-17 11:00:04 --> Config Class Initialized
INFO - 2024-07-17 11:00:04 --> Loader Class Initialized
INFO - 2024-07-17 11:00:04 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:04 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:05 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:05 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:05 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:05 --> Controller Class Initialized
ERROR - 2024-07-17 11:00:09 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:00:14 --> Config Class Initialized
INFO - 2024-07-17 11:00:14 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:14 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:14 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:14 --> URI Class Initialized
INFO - 2024-07-17 11:00:14 --> Router Class Initialized
INFO - 2024-07-17 11:00:14 --> Output Class Initialized
INFO - 2024-07-17 11:00:14 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:14 --> Input Class Initialized
INFO - 2024-07-17 11:00:14 --> Language Class Initialized
INFO - 2024-07-17 11:00:14 --> Language Class Initialized
INFO - 2024-07-17 11:00:14 --> Config Class Initialized
INFO - 2024-07-17 11:00:14 --> Loader Class Initialized
INFO - 2024-07-17 11:00:14 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:14 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:14 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:14 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:14 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:14 --> Controller Class Initialized
DEBUG - 2024-07-17 11:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:00:14 --> Final output sent to browser
DEBUG - 2024-07-17 11:00:14 --> Total execution time: 0.0715
INFO - 2024-07-17 11:00:20 --> Config Class Initialized
INFO - 2024-07-17 11:00:20 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:20 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:20 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:20 --> URI Class Initialized
INFO - 2024-07-17 11:00:20 --> Router Class Initialized
INFO - 2024-07-17 11:00:20 --> Output Class Initialized
INFO - 2024-07-17 11:00:20 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:20 --> Input Class Initialized
INFO - 2024-07-17 11:00:20 --> Language Class Initialized
INFO - 2024-07-17 11:00:20 --> Language Class Initialized
INFO - 2024-07-17 11:00:20 --> Config Class Initialized
INFO - 2024-07-17 11:00:20 --> Loader Class Initialized
INFO - 2024-07-17 11:00:20 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:20 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:20 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:20 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:20 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:20 --> Controller Class Initialized
DEBUG - 2024-07-17 11:00:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 11:00:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:00:20 --> Final output sent to browser
DEBUG - 2024-07-17 11:00:20 --> Total execution time: 0.0416
INFO - 2024-07-17 11:00:20 --> Config Class Initialized
INFO - 2024-07-17 11:00:20 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:20 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:20 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:20 --> URI Class Initialized
INFO - 2024-07-17 11:00:20 --> Router Class Initialized
INFO - 2024-07-17 11:00:20 --> Output Class Initialized
INFO - 2024-07-17 11:00:20 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:20 --> Input Class Initialized
INFO - 2024-07-17 11:00:20 --> Language Class Initialized
ERROR - 2024-07-17 11:00:20 --> 404 Page Not Found: /index
INFO - 2024-07-17 11:00:21 --> Config Class Initialized
INFO - 2024-07-17 11:00:21 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:21 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:21 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:21 --> URI Class Initialized
INFO - 2024-07-17 11:00:21 --> Router Class Initialized
INFO - 2024-07-17 11:00:21 --> Output Class Initialized
INFO - 2024-07-17 11:00:21 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:21 --> Input Class Initialized
INFO - 2024-07-17 11:00:21 --> Language Class Initialized
INFO - 2024-07-17 11:00:21 --> Language Class Initialized
INFO - 2024-07-17 11:00:21 --> Config Class Initialized
INFO - 2024-07-17 11:00:21 --> Loader Class Initialized
INFO - 2024-07-17 11:00:21 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:21 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:21 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:21 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:21 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:21 --> Controller Class Initialized
INFO - 2024-07-17 11:00:26 --> Config Class Initialized
INFO - 2024-07-17 11:00:26 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:26 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:26 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:26 --> URI Class Initialized
INFO - 2024-07-17 11:00:26 --> Router Class Initialized
INFO - 2024-07-17 11:00:26 --> Output Class Initialized
INFO - 2024-07-17 11:00:26 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:26 --> Input Class Initialized
INFO - 2024-07-17 11:00:26 --> Language Class Initialized
INFO - 2024-07-17 11:00:26 --> Language Class Initialized
INFO - 2024-07-17 11:00:26 --> Config Class Initialized
INFO - 2024-07-17 11:00:26 --> Loader Class Initialized
INFO - 2024-07-17 11:00:26 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:26 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:26 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:26 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:26 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:26 --> Controller Class Initialized
INFO - 2024-07-17 11:00:26 --> Config Class Initialized
INFO - 2024-07-17 11:00:26 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:26 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:26 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:26 --> URI Class Initialized
INFO - 2024-07-17 11:00:26 --> Router Class Initialized
INFO - 2024-07-17 11:00:26 --> Output Class Initialized
INFO - 2024-07-17 11:00:26 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:26 --> Input Class Initialized
INFO - 2024-07-17 11:00:26 --> Language Class Initialized
INFO - 2024-07-17 11:00:26 --> Language Class Initialized
INFO - 2024-07-17 11:00:26 --> Config Class Initialized
INFO - 2024-07-17 11:00:26 --> Loader Class Initialized
INFO - 2024-07-17 11:00:26 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:26 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:26 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:26 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:26 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:26 --> Controller Class Initialized
INFO - 2024-07-17 11:00:28 --> Config Class Initialized
INFO - 2024-07-17 11:00:28 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:28 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:28 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:28 --> URI Class Initialized
INFO - 2024-07-17 11:00:28 --> Router Class Initialized
INFO - 2024-07-17 11:00:28 --> Output Class Initialized
INFO - 2024-07-17 11:00:28 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:28 --> Input Class Initialized
INFO - 2024-07-17 11:00:28 --> Language Class Initialized
INFO - 2024-07-17 11:00:28 --> Language Class Initialized
INFO - 2024-07-17 11:00:28 --> Config Class Initialized
INFO - 2024-07-17 11:00:28 --> Loader Class Initialized
INFO - 2024-07-17 11:00:28 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:28 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:28 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:28 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:28 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:28 --> Controller Class Initialized
INFO - 2024-07-17 11:00:29 --> Config Class Initialized
INFO - 2024-07-17 11:00:29 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:00:29 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:00:29 --> Utf8 Class Initialized
INFO - 2024-07-17 11:00:29 --> URI Class Initialized
INFO - 2024-07-17 11:00:29 --> Router Class Initialized
INFO - 2024-07-17 11:00:29 --> Output Class Initialized
INFO - 2024-07-17 11:00:29 --> Security Class Initialized
DEBUG - 2024-07-17 11:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:00:29 --> Input Class Initialized
INFO - 2024-07-17 11:00:29 --> Language Class Initialized
INFO - 2024-07-17 11:00:29 --> Language Class Initialized
INFO - 2024-07-17 11:00:29 --> Config Class Initialized
INFO - 2024-07-17 11:00:29 --> Loader Class Initialized
INFO - 2024-07-17 11:00:29 --> Helper loaded: url_helper
INFO - 2024-07-17 11:00:29 --> Helper loaded: file_helper
INFO - 2024-07-17 11:00:29 --> Helper loaded: form_helper
INFO - 2024-07-17 11:00:29 --> Helper loaded: my_helper
INFO - 2024-07-17 11:00:29 --> Database Driver Class Initialized
INFO - 2024-07-17 11:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:00:29 --> Controller Class Initialized
INFO - 2024-07-17 11:05:08 --> Config Class Initialized
INFO - 2024-07-17 11:05:08 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:05:08 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:05:08 --> Utf8 Class Initialized
INFO - 2024-07-17 11:05:08 --> URI Class Initialized
INFO - 2024-07-17 11:05:08 --> Router Class Initialized
INFO - 2024-07-17 11:05:08 --> Output Class Initialized
INFO - 2024-07-17 11:05:08 --> Security Class Initialized
DEBUG - 2024-07-17 11:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:05:08 --> Input Class Initialized
INFO - 2024-07-17 11:05:08 --> Language Class Initialized
INFO - 2024-07-17 11:05:08 --> Language Class Initialized
INFO - 2024-07-17 11:05:08 --> Config Class Initialized
INFO - 2024-07-17 11:05:08 --> Loader Class Initialized
INFO - 2024-07-17 11:05:08 --> Helper loaded: url_helper
INFO - 2024-07-17 11:05:08 --> Helper loaded: file_helper
INFO - 2024-07-17 11:05:08 --> Helper loaded: form_helper
INFO - 2024-07-17 11:05:08 --> Helper loaded: my_helper
INFO - 2024-07-17 11:05:08 --> Database Driver Class Initialized
INFO - 2024-07-17 11:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:05:08 --> Controller Class Initialized
DEBUG - 2024-07-17 11:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:05:08 --> Final output sent to browser
DEBUG - 2024-07-17 11:05:08 --> Total execution time: 0.0570
INFO - 2024-07-17 11:05:13 --> Config Class Initialized
INFO - 2024-07-17 11:05:13 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:05:13 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:05:13 --> Utf8 Class Initialized
INFO - 2024-07-17 11:05:13 --> URI Class Initialized
INFO - 2024-07-17 11:05:13 --> Router Class Initialized
INFO - 2024-07-17 11:05:13 --> Output Class Initialized
INFO - 2024-07-17 11:05:13 --> Security Class Initialized
DEBUG - 2024-07-17 11:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:05:13 --> Input Class Initialized
INFO - 2024-07-17 11:05:13 --> Language Class Initialized
INFO - 2024-07-17 11:05:13 --> Language Class Initialized
INFO - 2024-07-17 11:05:13 --> Config Class Initialized
INFO - 2024-07-17 11:05:13 --> Loader Class Initialized
INFO - 2024-07-17 11:05:13 --> Helper loaded: url_helper
INFO - 2024-07-17 11:05:13 --> Helper loaded: file_helper
INFO - 2024-07-17 11:05:13 --> Helper loaded: form_helper
INFO - 2024-07-17 11:05:13 --> Helper loaded: my_helper
INFO - 2024-07-17 11:05:13 --> Database Driver Class Initialized
INFO - 2024-07-17 11:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:05:13 --> Controller Class Initialized
ERROR - 2024-07-17 11:05:14 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:05:16 --> Config Class Initialized
INFO - 2024-07-17 11:05:16 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:05:16 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:05:16 --> Utf8 Class Initialized
INFO - 2024-07-17 11:05:16 --> URI Class Initialized
INFO - 2024-07-17 11:05:16 --> Router Class Initialized
INFO - 2024-07-17 11:05:16 --> Output Class Initialized
INFO - 2024-07-17 11:05:16 --> Security Class Initialized
DEBUG - 2024-07-17 11:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:05:16 --> Input Class Initialized
INFO - 2024-07-17 11:05:16 --> Language Class Initialized
INFO - 2024-07-17 11:05:16 --> Language Class Initialized
INFO - 2024-07-17 11:05:16 --> Config Class Initialized
INFO - 2024-07-17 11:05:16 --> Loader Class Initialized
INFO - 2024-07-17 11:05:16 --> Helper loaded: url_helper
INFO - 2024-07-17 11:05:16 --> Helper loaded: file_helper
INFO - 2024-07-17 11:05:16 --> Helper loaded: form_helper
INFO - 2024-07-17 11:05:16 --> Helper loaded: my_helper
INFO - 2024-07-17 11:05:16 --> Database Driver Class Initialized
INFO - 2024-07-17 11:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:05:16 --> Controller Class Initialized
DEBUG - 2024-07-17 11:05:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:05:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:05:16 --> Final output sent to browser
DEBUG - 2024-07-17 11:05:16 --> Total execution time: 0.0279
INFO - 2024-07-17 11:05:21 --> Config Class Initialized
INFO - 2024-07-17 11:05:21 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:05:21 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:05:21 --> Utf8 Class Initialized
INFO - 2024-07-17 11:05:21 --> URI Class Initialized
INFO - 2024-07-17 11:05:21 --> Router Class Initialized
INFO - 2024-07-17 11:05:21 --> Output Class Initialized
INFO - 2024-07-17 11:05:21 --> Security Class Initialized
DEBUG - 2024-07-17 11:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:05:21 --> Input Class Initialized
INFO - 2024-07-17 11:05:21 --> Language Class Initialized
INFO - 2024-07-17 11:05:21 --> Language Class Initialized
INFO - 2024-07-17 11:05:21 --> Config Class Initialized
INFO - 2024-07-17 11:05:21 --> Loader Class Initialized
INFO - 2024-07-17 11:05:21 --> Helper loaded: url_helper
INFO - 2024-07-17 11:05:21 --> Helper loaded: file_helper
INFO - 2024-07-17 11:05:21 --> Helper loaded: form_helper
INFO - 2024-07-17 11:05:21 --> Helper loaded: my_helper
INFO - 2024-07-17 11:05:21 --> Database Driver Class Initialized
INFO - 2024-07-17 11:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:05:21 --> Controller Class Initialized
ERROR - 2024-07-17 11:05:21 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:06:01 --> Config Class Initialized
INFO - 2024-07-17 11:06:01 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:01 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:01 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:01 --> URI Class Initialized
INFO - 2024-07-17 11:06:02 --> Router Class Initialized
INFO - 2024-07-17 11:06:02 --> Output Class Initialized
INFO - 2024-07-17 11:06:02 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:02 --> Input Class Initialized
INFO - 2024-07-17 11:06:02 --> Language Class Initialized
INFO - 2024-07-17 11:06:02 --> Language Class Initialized
INFO - 2024-07-17 11:06:02 --> Config Class Initialized
INFO - 2024-07-17 11:06:02 --> Loader Class Initialized
INFO - 2024-07-17 11:06:02 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:02 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:02 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:02 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:02 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:02 --> Controller Class Initialized
DEBUG - 2024-07-17 11:06:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:06:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:06:02 --> Final output sent to browser
DEBUG - 2024-07-17 11:06:02 --> Total execution time: 0.1780
INFO - 2024-07-17 11:06:07 --> Config Class Initialized
INFO - 2024-07-17 11:06:07 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:07 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:07 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:07 --> URI Class Initialized
INFO - 2024-07-17 11:06:07 --> Router Class Initialized
INFO - 2024-07-17 11:06:07 --> Output Class Initialized
INFO - 2024-07-17 11:06:07 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:07 --> Input Class Initialized
INFO - 2024-07-17 11:06:07 --> Language Class Initialized
INFO - 2024-07-17 11:06:07 --> Language Class Initialized
INFO - 2024-07-17 11:06:07 --> Config Class Initialized
INFO - 2024-07-17 11:06:07 --> Loader Class Initialized
INFO - 2024-07-17 11:06:07 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:07 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:07 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:07 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:07 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:07 --> Controller Class Initialized
ERROR - 2024-07-17 11:06:08 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:06:10 --> Config Class Initialized
INFO - 2024-07-17 11:06:10 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:10 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:10 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:10 --> URI Class Initialized
INFO - 2024-07-17 11:06:10 --> Router Class Initialized
INFO - 2024-07-17 11:06:10 --> Output Class Initialized
INFO - 2024-07-17 11:06:10 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:10 --> Input Class Initialized
INFO - 2024-07-17 11:06:10 --> Language Class Initialized
INFO - 2024-07-17 11:06:10 --> Language Class Initialized
INFO - 2024-07-17 11:06:10 --> Config Class Initialized
INFO - 2024-07-17 11:06:10 --> Loader Class Initialized
INFO - 2024-07-17 11:06:10 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:10 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:10 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:10 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:10 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:10 --> Controller Class Initialized
DEBUG - 2024-07-17 11:06:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:06:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:06:10 --> Final output sent to browser
DEBUG - 2024-07-17 11:06:10 --> Total execution time: 0.0392
INFO - 2024-07-17 11:06:12 --> Config Class Initialized
INFO - 2024-07-17 11:06:12 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:12 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:12 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:12 --> URI Class Initialized
INFO - 2024-07-17 11:06:12 --> Router Class Initialized
INFO - 2024-07-17 11:06:12 --> Output Class Initialized
INFO - 2024-07-17 11:06:12 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:12 --> Input Class Initialized
INFO - 2024-07-17 11:06:12 --> Language Class Initialized
INFO - 2024-07-17 11:06:12 --> Language Class Initialized
INFO - 2024-07-17 11:06:12 --> Config Class Initialized
INFO - 2024-07-17 11:06:12 --> Loader Class Initialized
INFO - 2024-07-17 11:06:12 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:12 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:12 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:12 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:12 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:12 --> Controller Class Initialized
DEBUG - 2024-07-17 11:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 11:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:06:12 --> Final output sent to browser
DEBUG - 2024-07-17 11:06:12 --> Total execution time: 0.0826
INFO - 2024-07-17 11:06:12 --> Config Class Initialized
INFO - 2024-07-17 11:06:12 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:12 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:12 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:12 --> URI Class Initialized
INFO - 2024-07-17 11:06:12 --> Router Class Initialized
INFO - 2024-07-17 11:06:12 --> Output Class Initialized
INFO - 2024-07-17 11:06:12 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:12 --> Input Class Initialized
INFO - 2024-07-17 11:06:12 --> Language Class Initialized
ERROR - 2024-07-17 11:06:12 --> 404 Page Not Found: /index
INFO - 2024-07-17 11:06:12 --> Config Class Initialized
INFO - 2024-07-17 11:06:12 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:12 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:12 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:12 --> URI Class Initialized
INFO - 2024-07-17 11:06:12 --> Router Class Initialized
INFO - 2024-07-17 11:06:12 --> Output Class Initialized
INFO - 2024-07-17 11:06:12 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:12 --> Input Class Initialized
INFO - 2024-07-17 11:06:12 --> Language Class Initialized
INFO - 2024-07-17 11:06:12 --> Language Class Initialized
INFO - 2024-07-17 11:06:12 --> Config Class Initialized
INFO - 2024-07-17 11:06:12 --> Loader Class Initialized
INFO - 2024-07-17 11:06:12 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:12 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:12 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:12 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:12 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:12 --> Controller Class Initialized
INFO - 2024-07-17 11:06:15 --> Config Class Initialized
INFO - 2024-07-17 11:06:15 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:15 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:15 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:15 --> URI Class Initialized
INFO - 2024-07-17 11:06:15 --> Router Class Initialized
INFO - 2024-07-17 11:06:15 --> Output Class Initialized
INFO - 2024-07-17 11:06:15 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:15 --> Input Class Initialized
INFO - 2024-07-17 11:06:15 --> Language Class Initialized
INFO - 2024-07-17 11:06:15 --> Language Class Initialized
INFO - 2024-07-17 11:06:15 --> Config Class Initialized
INFO - 2024-07-17 11:06:15 --> Loader Class Initialized
INFO - 2024-07-17 11:06:15 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:15 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:15 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:15 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:15 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:15 --> Controller Class Initialized
INFO - 2024-07-17 11:06:15 --> Config Class Initialized
INFO - 2024-07-17 11:06:15 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:15 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:15 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:15 --> URI Class Initialized
INFO - 2024-07-17 11:06:15 --> Router Class Initialized
INFO - 2024-07-17 11:06:15 --> Output Class Initialized
INFO - 2024-07-17 11:06:15 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:15 --> Input Class Initialized
INFO - 2024-07-17 11:06:15 --> Language Class Initialized
INFO - 2024-07-17 11:06:15 --> Language Class Initialized
INFO - 2024-07-17 11:06:15 --> Config Class Initialized
INFO - 2024-07-17 11:06:15 --> Loader Class Initialized
INFO - 2024-07-17 11:06:15 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:15 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:15 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:15 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:15 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:15 --> Controller Class Initialized
INFO - 2024-07-17 11:06:16 --> Config Class Initialized
INFO - 2024-07-17 11:06:16 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:16 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:16 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:16 --> URI Class Initialized
INFO - 2024-07-17 11:06:16 --> Router Class Initialized
INFO - 2024-07-17 11:06:16 --> Output Class Initialized
INFO - 2024-07-17 11:06:16 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:16 --> Input Class Initialized
INFO - 2024-07-17 11:06:16 --> Language Class Initialized
INFO - 2024-07-17 11:06:16 --> Language Class Initialized
INFO - 2024-07-17 11:06:16 --> Config Class Initialized
INFO - 2024-07-17 11:06:16 --> Loader Class Initialized
INFO - 2024-07-17 11:06:16 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:16 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:16 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:16 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:16 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:16 --> Controller Class Initialized
INFO - 2024-07-17 11:06:18 --> Config Class Initialized
INFO - 2024-07-17 11:06:18 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:06:18 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:06:18 --> Utf8 Class Initialized
INFO - 2024-07-17 11:06:18 --> URI Class Initialized
INFO - 2024-07-17 11:06:18 --> Router Class Initialized
INFO - 2024-07-17 11:06:18 --> Output Class Initialized
INFO - 2024-07-17 11:06:18 --> Security Class Initialized
DEBUG - 2024-07-17 11:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:06:18 --> Input Class Initialized
INFO - 2024-07-17 11:06:18 --> Language Class Initialized
INFO - 2024-07-17 11:06:18 --> Language Class Initialized
INFO - 2024-07-17 11:06:18 --> Config Class Initialized
INFO - 2024-07-17 11:06:18 --> Loader Class Initialized
INFO - 2024-07-17 11:06:18 --> Helper loaded: url_helper
INFO - 2024-07-17 11:06:18 --> Helper loaded: file_helper
INFO - 2024-07-17 11:06:18 --> Helper loaded: form_helper
INFO - 2024-07-17 11:06:18 --> Helper loaded: my_helper
INFO - 2024-07-17 11:06:18 --> Database Driver Class Initialized
INFO - 2024-07-17 11:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:06:18 --> Controller Class Initialized
INFO - 2024-07-17 11:07:05 --> Config Class Initialized
INFO - 2024-07-17 11:07:05 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:05 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:05 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:05 --> URI Class Initialized
INFO - 2024-07-17 11:07:05 --> Router Class Initialized
INFO - 2024-07-17 11:07:05 --> Output Class Initialized
INFO - 2024-07-17 11:07:05 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:05 --> Input Class Initialized
INFO - 2024-07-17 11:07:05 --> Language Class Initialized
INFO - 2024-07-17 11:07:05 --> Language Class Initialized
INFO - 2024-07-17 11:07:05 --> Config Class Initialized
INFO - 2024-07-17 11:07:05 --> Loader Class Initialized
INFO - 2024-07-17 11:07:05 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:05 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:05 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:05 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:05 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:05 --> Controller Class Initialized
DEBUG - 2024-07-17 11:07:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:07:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:07:05 --> Final output sent to browser
DEBUG - 2024-07-17 11:07:05 --> Total execution time: 0.0295
INFO - 2024-07-17 11:07:10 --> Config Class Initialized
INFO - 2024-07-17 11:07:10 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:10 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:10 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:10 --> URI Class Initialized
INFO - 2024-07-17 11:07:10 --> Router Class Initialized
INFO - 2024-07-17 11:07:10 --> Output Class Initialized
INFO - 2024-07-17 11:07:10 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:10 --> Input Class Initialized
INFO - 2024-07-17 11:07:10 --> Language Class Initialized
INFO - 2024-07-17 11:07:10 --> Language Class Initialized
INFO - 2024-07-17 11:07:10 --> Config Class Initialized
INFO - 2024-07-17 11:07:10 --> Loader Class Initialized
INFO - 2024-07-17 11:07:10 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:10 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:10 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:10 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:10 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:10 --> Controller Class Initialized
ERROR - 2024-07-17 11:07:11 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:07:15 --> Config Class Initialized
INFO - 2024-07-17 11:07:15 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:15 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:15 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:15 --> URI Class Initialized
INFO - 2024-07-17 11:07:15 --> Router Class Initialized
INFO - 2024-07-17 11:07:15 --> Output Class Initialized
INFO - 2024-07-17 11:07:15 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:15 --> Input Class Initialized
INFO - 2024-07-17 11:07:15 --> Language Class Initialized
INFO - 2024-07-17 11:07:15 --> Language Class Initialized
INFO - 2024-07-17 11:07:15 --> Config Class Initialized
INFO - 2024-07-17 11:07:15 --> Loader Class Initialized
INFO - 2024-07-17 11:07:15 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:15 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:15 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:15 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:15 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:15 --> Controller Class Initialized
ERROR - 2024-07-17 11:07:15 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-17 11:07:17 --> Config Class Initialized
INFO - 2024-07-17 11:07:17 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:17 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:17 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:17 --> URI Class Initialized
INFO - 2024-07-17 11:07:17 --> Router Class Initialized
INFO - 2024-07-17 11:07:17 --> Output Class Initialized
INFO - 2024-07-17 11:07:17 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:17 --> Input Class Initialized
INFO - 2024-07-17 11:07:17 --> Language Class Initialized
INFO - 2024-07-17 11:07:17 --> Language Class Initialized
INFO - 2024-07-17 11:07:17 --> Config Class Initialized
INFO - 2024-07-17 11:07:17 --> Loader Class Initialized
INFO - 2024-07-17 11:07:17 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:17 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:17 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:17 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:17 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:17 --> Controller Class Initialized
DEBUG - 2024-07-17 11:07:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:07:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:07:17 --> Final output sent to browser
DEBUG - 2024-07-17 11:07:17 --> Total execution time: 0.0265
INFO - 2024-07-17 11:07:26 --> Config Class Initialized
INFO - 2024-07-17 11:07:26 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:26 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:26 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:26 --> URI Class Initialized
INFO - 2024-07-17 11:07:26 --> Router Class Initialized
INFO - 2024-07-17 11:07:26 --> Output Class Initialized
INFO - 2024-07-17 11:07:26 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:26 --> Input Class Initialized
INFO - 2024-07-17 11:07:26 --> Language Class Initialized
INFO - 2024-07-17 11:07:26 --> Language Class Initialized
INFO - 2024-07-17 11:07:26 --> Config Class Initialized
INFO - 2024-07-17 11:07:26 --> Loader Class Initialized
INFO - 2024-07-17 11:07:26 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:26 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:26 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:26 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:26 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:26 --> Controller Class Initialized
DEBUG - 2024-07-17 11:07:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 11:07:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:07:26 --> Final output sent to browser
DEBUG - 2024-07-17 11:07:26 --> Total execution time: 0.0315
INFO - 2024-07-17 11:07:26 --> Config Class Initialized
INFO - 2024-07-17 11:07:26 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:26 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:26 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:26 --> URI Class Initialized
INFO - 2024-07-17 11:07:26 --> Router Class Initialized
INFO - 2024-07-17 11:07:26 --> Output Class Initialized
INFO - 2024-07-17 11:07:26 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:26 --> Input Class Initialized
INFO - 2024-07-17 11:07:26 --> Language Class Initialized
ERROR - 2024-07-17 11:07:26 --> 404 Page Not Found: /index
INFO - 2024-07-17 11:07:26 --> Config Class Initialized
INFO - 2024-07-17 11:07:26 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:26 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:26 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:26 --> URI Class Initialized
INFO - 2024-07-17 11:07:26 --> Router Class Initialized
INFO - 2024-07-17 11:07:26 --> Output Class Initialized
INFO - 2024-07-17 11:07:26 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:26 --> Input Class Initialized
INFO - 2024-07-17 11:07:26 --> Language Class Initialized
INFO - 2024-07-17 11:07:26 --> Language Class Initialized
INFO - 2024-07-17 11:07:26 --> Config Class Initialized
INFO - 2024-07-17 11:07:26 --> Loader Class Initialized
INFO - 2024-07-17 11:07:26 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:26 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:26 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:26 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:26 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:26 --> Controller Class Initialized
INFO - 2024-07-17 11:07:30 --> Config Class Initialized
INFO - 2024-07-17 11:07:30 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:30 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:30 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:30 --> URI Class Initialized
INFO - 2024-07-17 11:07:30 --> Router Class Initialized
INFO - 2024-07-17 11:07:30 --> Output Class Initialized
INFO - 2024-07-17 11:07:30 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:30 --> Input Class Initialized
INFO - 2024-07-17 11:07:30 --> Language Class Initialized
INFO - 2024-07-17 11:07:30 --> Language Class Initialized
INFO - 2024-07-17 11:07:30 --> Config Class Initialized
INFO - 2024-07-17 11:07:30 --> Loader Class Initialized
INFO - 2024-07-17 11:07:30 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:30 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:30 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:30 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:30 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:30 --> Controller Class Initialized
INFO - 2024-07-17 11:07:31 --> Config Class Initialized
INFO - 2024-07-17 11:07:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:31 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:31 --> URI Class Initialized
INFO - 2024-07-17 11:07:31 --> Router Class Initialized
INFO - 2024-07-17 11:07:31 --> Output Class Initialized
INFO - 2024-07-17 11:07:31 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:31 --> Input Class Initialized
INFO - 2024-07-17 11:07:31 --> Language Class Initialized
INFO - 2024-07-17 11:07:31 --> Language Class Initialized
INFO - 2024-07-17 11:07:31 --> Config Class Initialized
INFO - 2024-07-17 11:07:31 --> Loader Class Initialized
INFO - 2024-07-17 11:07:31 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:31 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:31 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:31 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:31 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:31 --> Controller Class Initialized
INFO - 2024-07-17 11:07:31 --> Config Class Initialized
INFO - 2024-07-17 11:07:31 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:31 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:31 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:31 --> URI Class Initialized
INFO - 2024-07-17 11:07:31 --> Router Class Initialized
INFO - 2024-07-17 11:07:31 --> Output Class Initialized
INFO - 2024-07-17 11:07:31 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:31 --> Input Class Initialized
INFO - 2024-07-17 11:07:31 --> Language Class Initialized
INFO - 2024-07-17 11:07:31 --> Language Class Initialized
INFO - 2024-07-17 11:07:31 --> Config Class Initialized
INFO - 2024-07-17 11:07:31 --> Loader Class Initialized
INFO - 2024-07-17 11:07:31 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:31 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:31 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:31 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:31 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:31 --> Controller Class Initialized
INFO - 2024-07-17 11:07:32 --> Config Class Initialized
INFO - 2024-07-17 11:07:32 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:32 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:32 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:32 --> URI Class Initialized
INFO - 2024-07-17 11:07:32 --> Router Class Initialized
INFO - 2024-07-17 11:07:32 --> Output Class Initialized
INFO - 2024-07-17 11:07:32 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:32 --> Input Class Initialized
INFO - 2024-07-17 11:07:32 --> Language Class Initialized
INFO - 2024-07-17 11:07:32 --> Language Class Initialized
INFO - 2024-07-17 11:07:32 --> Config Class Initialized
INFO - 2024-07-17 11:07:32 --> Loader Class Initialized
INFO - 2024-07-17 11:07:32 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:32 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:32 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:32 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:32 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:32 --> Controller Class Initialized
INFO - 2024-07-17 11:07:34 --> Config Class Initialized
INFO - 2024-07-17 11:07:34 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:34 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:34 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:34 --> URI Class Initialized
INFO - 2024-07-17 11:07:34 --> Router Class Initialized
INFO - 2024-07-17 11:07:34 --> Output Class Initialized
INFO - 2024-07-17 11:07:34 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:34 --> Input Class Initialized
INFO - 2024-07-17 11:07:34 --> Language Class Initialized
INFO - 2024-07-17 11:07:34 --> Language Class Initialized
INFO - 2024-07-17 11:07:34 --> Config Class Initialized
INFO - 2024-07-17 11:07:34 --> Loader Class Initialized
INFO - 2024-07-17 11:07:34 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:34 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:34 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:34 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:34 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:34 --> Controller Class Initialized
INFO - 2024-07-17 11:07:36 --> Config Class Initialized
INFO - 2024-07-17 11:07:36 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:36 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:36 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:36 --> URI Class Initialized
INFO - 2024-07-17 11:07:36 --> Router Class Initialized
INFO - 2024-07-17 11:07:36 --> Output Class Initialized
INFO - 2024-07-17 11:07:36 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:36 --> Input Class Initialized
INFO - 2024-07-17 11:07:36 --> Language Class Initialized
INFO - 2024-07-17 11:07:36 --> Language Class Initialized
INFO - 2024-07-17 11:07:36 --> Config Class Initialized
INFO - 2024-07-17 11:07:36 --> Loader Class Initialized
INFO - 2024-07-17 11:07:36 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:36 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:36 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:36 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:36 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:36 --> Controller Class Initialized
DEBUG - 2024-07-17 11:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:07:36 --> Final output sent to browser
DEBUG - 2024-07-17 11:07:36 --> Total execution time: 0.0499
INFO - 2024-07-17 11:07:38 --> Config Class Initialized
INFO - 2024-07-17 11:07:38 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:38 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:38 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:38 --> URI Class Initialized
INFO - 2024-07-17 11:07:38 --> Router Class Initialized
INFO - 2024-07-17 11:07:38 --> Output Class Initialized
INFO - 2024-07-17 11:07:38 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:38 --> Input Class Initialized
INFO - 2024-07-17 11:07:38 --> Language Class Initialized
INFO - 2024-07-17 11:07:38 --> Language Class Initialized
INFO - 2024-07-17 11:07:38 --> Config Class Initialized
INFO - 2024-07-17 11:07:38 --> Loader Class Initialized
INFO - 2024-07-17 11:07:38 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:38 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:38 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:38 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:38 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:38 --> Controller Class Initialized
DEBUG - 2024-07-17 11:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-17 11:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:07:38 --> Final output sent to browser
DEBUG - 2024-07-17 11:07:38 --> Total execution time: 0.0277
INFO - 2024-07-17 11:07:38 --> Config Class Initialized
INFO - 2024-07-17 11:07:38 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:38 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:38 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:38 --> URI Class Initialized
INFO - 2024-07-17 11:07:38 --> Router Class Initialized
INFO - 2024-07-17 11:07:38 --> Output Class Initialized
INFO - 2024-07-17 11:07:38 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:38 --> Input Class Initialized
INFO - 2024-07-17 11:07:38 --> Language Class Initialized
ERROR - 2024-07-17 11:07:38 --> 404 Page Not Found: /index
INFO - 2024-07-17 11:07:38 --> Config Class Initialized
INFO - 2024-07-17 11:07:38 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:07:38 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:07:38 --> Utf8 Class Initialized
INFO - 2024-07-17 11:07:38 --> URI Class Initialized
INFO - 2024-07-17 11:07:38 --> Router Class Initialized
INFO - 2024-07-17 11:07:38 --> Output Class Initialized
INFO - 2024-07-17 11:07:38 --> Security Class Initialized
DEBUG - 2024-07-17 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:07:38 --> Input Class Initialized
INFO - 2024-07-17 11:07:38 --> Language Class Initialized
INFO - 2024-07-17 11:07:38 --> Language Class Initialized
INFO - 2024-07-17 11:07:38 --> Config Class Initialized
INFO - 2024-07-17 11:07:38 --> Loader Class Initialized
INFO - 2024-07-17 11:07:38 --> Helper loaded: url_helper
INFO - 2024-07-17 11:07:38 --> Helper loaded: file_helper
INFO - 2024-07-17 11:07:38 --> Helper loaded: form_helper
INFO - 2024-07-17 11:07:38 --> Helper loaded: my_helper
INFO - 2024-07-17 11:07:38 --> Database Driver Class Initialized
INFO - 2024-07-17 11:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:07:38 --> Controller Class Initialized
INFO - 2024-07-17 11:09:30 --> Config Class Initialized
INFO - 2024-07-17 11:09:30 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:09:30 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:09:30 --> Utf8 Class Initialized
INFO - 2024-07-17 11:09:30 --> URI Class Initialized
INFO - 2024-07-17 11:09:30 --> Router Class Initialized
INFO - 2024-07-17 11:09:30 --> Output Class Initialized
INFO - 2024-07-17 11:09:30 --> Security Class Initialized
DEBUG - 2024-07-17 11:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:09:30 --> Input Class Initialized
INFO - 2024-07-17 11:09:30 --> Language Class Initialized
INFO - 2024-07-17 11:09:30 --> Language Class Initialized
INFO - 2024-07-17 11:09:30 --> Config Class Initialized
INFO - 2024-07-17 11:09:30 --> Loader Class Initialized
INFO - 2024-07-17 11:09:30 --> Helper loaded: url_helper
INFO - 2024-07-17 11:09:30 --> Helper loaded: file_helper
INFO - 2024-07-17 11:09:30 --> Helper loaded: form_helper
INFO - 2024-07-17 11:09:30 --> Helper loaded: my_helper
INFO - 2024-07-17 11:09:30 --> Database Driver Class Initialized
INFO - 2024-07-17 11:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:09:30 --> Controller Class Initialized
DEBUG - 2024-07-17 11:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:09:30 --> Final output sent to browser
DEBUG - 2024-07-17 11:09:30 --> Total execution time: 0.0689
INFO - 2024-07-17 11:09:37 --> Config Class Initialized
INFO - 2024-07-17 11:09:37 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:09:37 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:09:37 --> Utf8 Class Initialized
INFO - 2024-07-17 11:09:37 --> URI Class Initialized
INFO - 2024-07-17 11:09:37 --> Router Class Initialized
INFO - 2024-07-17 11:09:37 --> Output Class Initialized
INFO - 2024-07-17 11:09:37 --> Security Class Initialized
DEBUG - 2024-07-17 11:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:09:37 --> Input Class Initialized
INFO - 2024-07-17 11:09:37 --> Language Class Initialized
INFO - 2024-07-17 11:09:37 --> Language Class Initialized
INFO - 2024-07-17 11:09:37 --> Config Class Initialized
INFO - 2024-07-17 11:09:37 --> Loader Class Initialized
INFO - 2024-07-17 11:09:37 --> Helper loaded: url_helper
INFO - 2024-07-17 11:09:37 --> Helper loaded: file_helper
INFO - 2024-07-17 11:09:37 --> Helper loaded: form_helper
INFO - 2024-07-17 11:09:37 --> Helper loaded: my_helper
INFO - 2024-07-17 11:09:37 --> Database Driver Class Initialized
INFO - 2024-07-17 11:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:09:37 --> Controller Class Initialized
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1862
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1921
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2060
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2085
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2095
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2113
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2126
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2130
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2212
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2490
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2557
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2565
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2744
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2828
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2897
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2921
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3820
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3844
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3845
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3846
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3860
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3861
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3862
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3866
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3868
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3869
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3870
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3874
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3876
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3877
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3878
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3946
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4013
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4016
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4394
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4546
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4548
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6093
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6096
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6503
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6506
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6509
ERROR - 2024-07-17 11:09:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 290
ERROR - 2024-07-17 11:09:38 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 450
ERROR - 2024-07-17 11:09:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/system/helpers/url_helper.php 564
INFO - 2024-07-17 11:09:40 --> Config Class Initialized
INFO - 2024-07-17 11:09:40 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:09:40 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:09:40 --> Utf8 Class Initialized
INFO - 2024-07-17 11:09:40 --> URI Class Initialized
INFO - 2024-07-17 11:09:40 --> Router Class Initialized
INFO - 2024-07-17 11:09:40 --> Output Class Initialized
INFO - 2024-07-17 11:09:40 --> Security Class Initialized
DEBUG - 2024-07-17 11:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:09:40 --> Input Class Initialized
INFO - 2024-07-17 11:09:40 --> Language Class Initialized
INFO - 2024-07-17 11:09:40 --> Language Class Initialized
INFO - 2024-07-17 11:09:40 --> Config Class Initialized
INFO - 2024-07-17 11:09:40 --> Loader Class Initialized
INFO - 2024-07-17 11:09:40 --> Helper loaded: url_helper
INFO - 2024-07-17 11:09:40 --> Helper loaded: file_helper
INFO - 2024-07-17 11:09:40 --> Helper loaded: form_helper
INFO - 2024-07-17 11:09:40 --> Helper loaded: my_helper
INFO - 2024-07-17 11:09:40 --> Database Driver Class Initialized
INFO - 2024-07-17 11:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:09:40 --> Controller Class Initialized
DEBUG - 2024-07-17 11:09:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-17 11:09:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:09:40 --> Final output sent to browser
DEBUG - 2024-07-17 11:09:40 --> Total execution time: 0.0384
INFO - 2024-07-17 11:09:48 --> Config Class Initialized
INFO - 2024-07-17 11:09:48 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:09:48 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:09:48 --> Utf8 Class Initialized
INFO - 2024-07-17 11:09:48 --> URI Class Initialized
INFO - 2024-07-17 11:09:48 --> Router Class Initialized
INFO - 2024-07-17 11:09:48 --> Output Class Initialized
INFO - 2024-07-17 11:09:48 --> Security Class Initialized
DEBUG - 2024-07-17 11:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:09:48 --> Input Class Initialized
INFO - 2024-07-17 11:09:48 --> Language Class Initialized
INFO - 2024-07-17 11:09:48 --> Language Class Initialized
INFO - 2024-07-17 11:09:48 --> Config Class Initialized
INFO - 2024-07-17 11:09:48 --> Loader Class Initialized
INFO - 2024-07-17 11:09:48 --> Helper loaded: url_helper
INFO - 2024-07-17 11:09:48 --> Helper loaded: file_helper
INFO - 2024-07-17 11:09:48 --> Helper loaded: form_helper
INFO - 2024-07-17 11:09:48 --> Helper loaded: my_helper
INFO - 2024-07-17 11:09:48 --> Database Driver Class Initialized
INFO - 2024-07-17 11:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:09:48 --> Controller Class Initialized
DEBUG - 2024-07-17 11:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-17 11:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:09:48 --> Final output sent to browser
DEBUG - 2024-07-17 11:09:48 --> Total execution time: 0.0486
INFO - 2024-07-17 11:09:53 --> Config Class Initialized
INFO - 2024-07-17 11:09:53 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:09:53 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:09:53 --> Utf8 Class Initialized
INFO - 2024-07-17 11:09:53 --> URI Class Initialized
INFO - 2024-07-17 11:09:53 --> Router Class Initialized
INFO - 2024-07-17 11:09:53 --> Output Class Initialized
INFO - 2024-07-17 11:09:53 --> Security Class Initialized
DEBUG - 2024-07-17 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:09:53 --> Input Class Initialized
INFO - 2024-07-17 11:09:53 --> Language Class Initialized
INFO - 2024-07-17 11:09:53 --> Language Class Initialized
INFO - 2024-07-17 11:09:53 --> Config Class Initialized
INFO - 2024-07-17 11:09:53 --> Loader Class Initialized
INFO - 2024-07-17 11:09:53 --> Helper loaded: url_helper
INFO - 2024-07-17 11:09:53 --> Helper loaded: file_helper
INFO - 2024-07-17 11:09:53 --> Helper loaded: form_helper
INFO - 2024-07-17 11:09:53 --> Helper loaded: my_helper
INFO - 2024-07-17 11:09:53 --> Database Driver Class Initialized
INFO - 2024-07-17 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:09:53 --> Controller Class Initialized
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:09:53 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-17 11:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-17 11:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:09:53 --> Final output sent to browser
DEBUG - 2024-07-17 11:09:53 --> Total execution time: 0.0442
INFO - 2024-07-17 11:10:11 --> Config Class Initialized
INFO - 2024-07-17 11:10:11 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:11 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:11 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:11 --> URI Class Initialized
INFO - 2024-07-17 11:10:11 --> Router Class Initialized
INFO - 2024-07-17 11:10:11 --> Output Class Initialized
INFO - 2024-07-17 11:10:11 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:11 --> Input Class Initialized
INFO - 2024-07-17 11:10:11 --> Language Class Initialized
INFO - 2024-07-17 11:10:11 --> Language Class Initialized
INFO - 2024-07-17 11:10:11 --> Config Class Initialized
INFO - 2024-07-17 11:10:11 --> Loader Class Initialized
INFO - 2024-07-17 11:10:11 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:11 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:11 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:11 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:11 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:11 --> Controller Class Initialized
INFO - 2024-07-17 11:10:11 --> Config Class Initialized
INFO - 2024-07-17 11:10:11 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:11 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:11 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:11 --> URI Class Initialized
INFO - 2024-07-17 11:10:11 --> Router Class Initialized
INFO - 2024-07-17 11:10:11 --> Output Class Initialized
INFO - 2024-07-17 11:10:11 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:11 --> Input Class Initialized
INFO - 2024-07-17 11:10:11 --> Language Class Initialized
INFO - 2024-07-17 11:10:11 --> Language Class Initialized
INFO - 2024-07-17 11:10:11 --> Config Class Initialized
INFO - 2024-07-17 11:10:11 --> Loader Class Initialized
INFO - 2024-07-17 11:10:11 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:11 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:11 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:11 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:11 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:11 --> Controller Class Initialized
DEBUG - 2024-07-17 11:10:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-17 11:10:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:10:11 --> Final output sent to browser
DEBUG - 2024-07-17 11:10:11 --> Total execution time: 0.0373
INFO - 2024-07-17 11:10:13 --> Config Class Initialized
INFO - 2024-07-17 11:10:13 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:13 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:13 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:13 --> URI Class Initialized
INFO - 2024-07-17 11:10:13 --> Router Class Initialized
INFO - 2024-07-17 11:10:13 --> Output Class Initialized
INFO - 2024-07-17 11:10:13 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:13 --> Input Class Initialized
INFO - 2024-07-17 11:10:13 --> Language Class Initialized
INFO - 2024-07-17 11:10:13 --> Language Class Initialized
INFO - 2024-07-17 11:10:13 --> Config Class Initialized
INFO - 2024-07-17 11:10:13 --> Loader Class Initialized
INFO - 2024-07-17 11:10:13 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:13 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:13 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:13 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:13 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:13 --> Controller Class Initialized
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-17 11:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-17 11:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:10:13 --> Final output sent to browser
DEBUG - 2024-07-17 11:10:13 --> Total execution time: 0.0416
INFO - 2024-07-17 11:10:22 --> Config Class Initialized
INFO - 2024-07-17 11:10:22 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:22 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:22 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:22 --> URI Class Initialized
INFO - 2024-07-17 11:10:22 --> Router Class Initialized
INFO - 2024-07-17 11:10:22 --> Output Class Initialized
INFO - 2024-07-17 11:10:22 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:22 --> Input Class Initialized
INFO - 2024-07-17 11:10:22 --> Language Class Initialized
INFO - 2024-07-17 11:10:22 --> Language Class Initialized
INFO - 2024-07-17 11:10:22 --> Config Class Initialized
INFO - 2024-07-17 11:10:22 --> Loader Class Initialized
INFO - 2024-07-17 11:10:22 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:22 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:22 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:22 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:22 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:22 --> Controller Class Initialized
INFO - 2024-07-17 11:10:22 --> Config Class Initialized
INFO - 2024-07-17 11:10:22 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:22 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:22 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:22 --> URI Class Initialized
INFO - 2024-07-17 11:10:22 --> Router Class Initialized
INFO - 2024-07-17 11:10:22 --> Output Class Initialized
INFO - 2024-07-17 11:10:22 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:22 --> Input Class Initialized
INFO - 2024-07-17 11:10:22 --> Language Class Initialized
INFO - 2024-07-17 11:10:22 --> Language Class Initialized
INFO - 2024-07-17 11:10:22 --> Config Class Initialized
INFO - 2024-07-17 11:10:22 --> Loader Class Initialized
INFO - 2024-07-17 11:10:22 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:22 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:22 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:22 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:22 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:22 --> Controller Class Initialized
DEBUG - 2024-07-17 11:10:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-17 11:10:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:10:22 --> Final output sent to browser
DEBUG - 2024-07-17 11:10:22 --> Total execution time: 0.0387
INFO - 2024-07-17 11:10:24 --> Config Class Initialized
INFO - 2024-07-17 11:10:24 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:24 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:24 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:24 --> URI Class Initialized
INFO - 2024-07-17 11:10:24 --> Router Class Initialized
INFO - 2024-07-17 11:10:24 --> Output Class Initialized
INFO - 2024-07-17 11:10:24 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:24 --> Input Class Initialized
INFO - 2024-07-17 11:10:24 --> Language Class Initialized
INFO - 2024-07-17 11:10:24 --> Language Class Initialized
INFO - 2024-07-17 11:10:24 --> Config Class Initialized
INFO - 2024-07-17 11:10:24 --> Loader Class Initialized
INFO - 2024-07-17 11:10:24 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:24 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:24 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:24 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:24 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:24 --> Controller Class Initialized
ERROR - 2024-07-17 11:10:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-17 11:10:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-17 11:10:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-17 11:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-17 11:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:10:24 --> Final output sent to browser
DEBUG - 2024-07-17 11:10:24 --> Total execution time: 0.0315
INFO - 2024-07-17 11:10:32 --> Config Class Initialized
INFO - 2024-07-17 11:10:32 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:32 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:32 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:32 --> URI Class Initialized
INFO - 2024-07-17 11:10:32 --> Router Class Initialized
INFO - 2024-07-17 11:10:32 --> Output Class Initialized
INFO - 2024-07-17 11:10:32 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:32 --> Input Class Initialized
INFO - 2024-07-17 11:10:32 --> Language Class Initialized
INFO - 2024-07-17 11:10:32 --> Language Class Initialized
INFO - 2024-07-17 11:10:32 --> Config Class Initialized
INFO - 2024-07-17 11:10:32 --> Loader Class Initialized
INFO - 2024-07-17 11:10:32 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:32 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:32 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:32 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:32 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:32 --> Controller Class Initialized
INFO - 2024-07-17 11:10:32 --> Config Class Initialized
INFO - 2024-07-17 11:10:32 --> Hooks Class Initialized
DEBUG - 2024-07-17 11:10:32 --> UTF-8 Support Enabled
INFO - 2024-07-17 11:10:32 --> Utf8 Class Initialized
INFO - 2024-07-17 11:10:32 --> URI Class Initialized
INFO - 2024-07-17 11:10:32 --> Router Class Initialized
INFO - 2024-07-17 11:10:32 --> Output Class Initialized
INFO - 2024-07-17 11:10:32 --> Security Class Initialized
DEBUG - 2024-07-17 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 11:10:32 --> Input Class Initialized
INFO - 2024-07-17 11:10:32 --> Language Class Initialized
INFO - 2024-07-17 11:10:32 --> Language Class Initialized
INFO - 2024-07-17 11:10:32 --> Config Class Initialized
INFO - 2024-07-17 11:10:32 --> Loader Class Initialized
INFO - 2024-07-17 11:10:32 --> Helper loaded: url_helper
INFO - 2024-07-17 11:10:32 --> Helper loaded: file_helper
INFO - 2024-07-17 11:10:32 --> Helper loaded: form_helper
INFO - 2024-07-17 11:10:32 --> Helper loaded: my_helper
INFO - 2024-07-17 11:10:32 --> Database Driver Class Initialized
INFO - 2024-07-17 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 11:10:32 --> Controller Class Initialized
DEBUG - 2024-07-17 11:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-17 11:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-17 11:10:32 --> Final output sent to browser
DEBUG - 2024-07-17 11:10:32 --> Total execution time: 0.0710
INFO - 2024-07-17 22:01:45 --> Config Class Initialized
INFO - 2024-07-17 22:01:45 --> Hooks Class Initialized
DEBUG - 2024-07-17 22:01:45 --> UTF-8 Support Enabled
INFO - 2024-07-17 22:01:45 --> Utf8 Class Initialized
INFO - 2024-07-17 22:01:45 --> URI Class Initialized
INFO - 2024-07-17 22:01:45 --> Router Class Initialized
INFO - 2024-07-17 22:01:45 --> Output Class Initialized
INFO - 2024-07-17 22:01:45 --> Security Class Initialized
DEBUG - 2024-07-17 22:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-17 22:01:45 --> Input Class Initialized
INFO - 2024-07-17 22:01:45 --> Language Class Initialized
INFO - 2024-07-17 22:01:45 --> Language Class Initialized
INFO - 2024-07-17 22:01:45 --> Config Class Initialized
INFO - 2024-07-17 22:01:45 --> Loader Class Initialized
INFO - 2024-07-17 22:01:45 --> Helper loaded: url_helper
INFO - 2024-07-17 22:01:45 --> Helper loaded: file_helper
INFO - 2024-07-17 22:01:45 --> Helper loaded: form_helper
INFO - 2024-07-17 22:01:45 --> Helper loaded: my_helper
INFO - 2024-07-17 22:01:45 --> Database Driver Class Initialized
INFO - 2024-07-17 22:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-17 22:01:46 --> Controller Class Initialized
