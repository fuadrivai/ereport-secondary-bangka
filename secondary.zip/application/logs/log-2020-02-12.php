<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-12 13:29:27 --> Config Class Initialized
INFO - 2020-02-12 13:29:27 --> Hooks Class Initialized
DEBUG - 2020-02-12 13:29:27 --> UTF-8 Support Enabled
INFO - 2020-02-12 13:29:27 --> Utf8 Class Initialized
INFO - 2020-02-12 13:29:27 --> URI Class Initialized
DEBUG - 2020-02-12 13:29:27 --> No URI present. Default controller set.
INFO - 2020-02-12 13:29:27 --> Router Class Initialized
INFO - 2020-02-12 13:29:27 --> Output Class Initialized
INFO - 2020-02-12 13:29:28 --> Security Class Initialized
DEBUG - 2020-02-12 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 13:29:28 --> Input Class Initialized
INFO - 2020-02-12 13:29:28 --> Language Class Initialized
INFO - 2020-02-12 13:29:28 --> Language Class Initialized
INFO - 2020-02-12 13:29:28 --> Config Class Initialized
INFO - 2020-02-12 13:29:28 --> Loader Class Initialized
INFO - 2020-02-12 13:29:28 --> Helper loaded: url_helper
INFO - 2020-02-12 13:29:28 --> Helper loaded: file_helper
INFO - 2020-02-12 13:29:28 --> Helper loaded: form_helper
INFO - 2020-02-12 13:29:28 --> Helper loaded: my_helper
INFO - 2020-02-12 13:29:28 --> Database Driver Class Initialized
DEBUG - 2020-02-12 13:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 13:29:28 --> Controller Class Initialized
INFO - 2020-02-12 13:29:28 --> Config Class Initialized
INFO - 2020-02-12 13:29:28 --> Hooks Class Initialized
DEBUG - 2020-02-12 13:29:28 --> UTF-8 Support Enabled
INFO - 2020-02-12 13:29:28 --> Utf8 Class Initialized
INFO - 2020-02-12 13:29:28 --> URI Class Initialized
INFO - 2020-02-12 13:29:28 --> Router Class Initialized
INFO - 2020-02-12 13:29:28 --> Output Class Initialized
INFO - 2020-02-12 13:29:28 --> Security Class Initialized
DEBUG - 2020-02-12 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 13:29:28 --> Input Class Initialized
INFO - 2020-02-12 13:29:28 --> Language Class Initialized
INFO - 2020-02-12 13:29:28 --> Language Class Initialized
INFO - 2020-02-12 13:29:28 --> Config Class Initialized
INFO - 2020-02-12 13:29:28 --> Loader Class Initialized
INFO - 2020-02-12 13:29:28 --> Helper loaded: url_helper
INFO - 2020-02-12 13:29:28 --> Helper loaded: file_helper
INFO - 2020-02-12 13:29:28 --> Helper loaded: form_helper
INFO - 2020-02-12 13:29:28 --> Helper loaded: my_helper
INFO - 2020-02-12 13:29:28 --> Database Driver Class Initialized
DEBUG - 2020-02-12 13:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 13:29:28 --> Controller Class Initialized
DEBUG - 2020-02-12 13:29:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-12 13:29:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 13:29:28 --> Final output sent to browser
DEBUG - 2020-02-12 13:29:28 --> Total execution time: 0.3292
INFO - 2020-02-12 13:29:39 --> Config Class Initialized
INFO - 2020-02-12 13:29:39 --> Hooks Class Initialized
DEBUG - 2020-02-12 13:29:39 --> UTF-8 Support Enabled
INFO - 2020-02-12 13:29:39 --> Utf8 Class Initialized
INFO - 2020-02-12 13:29:39 --> URI Class Initialized
INFO - 2020-02-12 13:29:39 --> Router Class Initialized
INFO - 2020-02-12 13:29:39 --> Output Class Initialized
INFO - 2020-02-12 13:29:39 --> Security Class Initialized
DEBUG - 2020-02-12 13:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 13:29:39 --> Input Class Initialized
INFO - 2020-02-12 13:29:39 --> Language Class Initialized
INFO - 2020-02-12 13:29:39 --> Language Class Initialized
INFO - 2020-02-12 13:29:39 --> Config Class Initialized
INFO - 2020-02-12 13:29:39 --> Loader Class Initialized
INFO - 2020-02-12 13:29:39 --> Helper loaded: url_helper
INFO - 2020-02-12 13:29:39 --> Helper loaded: file_helper
INFO - 2020-02-12 13:29:39 --> Helper loaded: form_helper
INFO - 2020-02-12 13:29:39 --> Helper loaded: my_helper
INFO - 2020-02-12 13:29:39 --> Database Driver Class Initialized
DEBUG - 2020-02-12 13:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 13:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 13:29:39 --> Controller Class Initialized
INFO - 2020-02-12 13:29:39 --> Helper loaded: cookie_helper
INFO - 2020-02-12 13:29:39 --> Final output sent to browser
DEBUG - 2020-02-12 13:29:39 --> Total execution time: 0.3205
INFO - 2020-02-12 13:29:39 --> Config Class Initialized
INFO - 2020-02-12 13:29:39 --> Hooks Class Initialized
DEBUG - 2020-02-12 13:29:39 --> UTF-8 Support Enabled
INFO - 2020-02-12 13:29:39 --> Utf8 Class Initialized
INFO - 2020-02-12 13:29:39 --> URI Class Initialized
INFO - 2020-02-12 13:29:39 --> Router Class Initialized
INFO - 2020-02-12 13:29:39 --> Output Class Initialized
INFO - 2020-02-12 13:29:39 --> Security Class Initialized
DEBUG - 2020-02-12 13:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 13:29:39 --> Input Class Initialized
INFO - 2020-02-12 13:29:39 --> Language Class Initialized
INFO - 2020-02-12 13:29:39 --> Language Class Initialized
INFO - 2020-02-12 13:29:39 --> Config Class Initialized
INFO - 2020-02-12 13:29:39 --> Loader Class Initialized
INFO - 2020-02-12 13:29:39 --> Helper loaded: url_helper
INFO - 2020-02-12 13:29:39 --> Helper loaded: file_helper
INFO - 2020-02-12 13:29:39 --> Helper loaded: form_helper
INFO - 2020-02-12 13:29:39 --> Helper loaded: my_helper
INFO - 2020-02-12 13:29:39 --> Database Driver Class Initialized
DEBUG - 2020-02-12 13:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 13:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 13:29:39 --> Controller Class Initialized
DEBUG - 2020-02-12 13:29:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-12 13:29:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 13:29:39 --> Final output sent to browser
DEBUG - 2020-02-12 13:29:39 --> Total execution time: 0.3549
INFO - 2020-02-12 13:29:47 --> Config Class Initialized
INFO - 2020-02-12 13:29:47 --> Hooks Class Initialized
DEBUG - 2020-02-12 13:29:47 --> UTF-8 Support Enabled
INFO - 2020-02-12 13:29:47 --> Utf8 Class Initialized
INFO - 2020-02-12 13:29:47 --> URI Class Initialized
INFO - 2020-02-12 13:29:47 --> Router Class Initialized
INFO - 2020-02-12 13:29:47 --> Output Class Initialized
INFO - 2020-02-12 13:29:47 --> Security Class Initialized
DEBUG - 2020-02-12 13:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 13:29:47 --> Input Class Initialized
INFO - 2020-02-12 13:29:47 --> Language Class Initialized
INFO - 2020-02-12 13:29:47 --> Language Class Initialized
INFO - 2020-02-12 13:29:47 --> Config Class Initialized
INFO - 2020-02-12 13:29:47 --> Loader Class Initialized
INFO - 2020-02-12 13:29:47 --> Helper loaded: url_helper
INFO - 2020-02-12 13:29:47 --> Helper loaded: file_helper
INFO - 2020-02-12 13:29:47 --> Helper loaded: form_helper
INFO - 2020-02-12 13:29:47 --> Helper loaded: my_helper
INFO - 2020-02-12 13:29:48 --> Database Driver Class Initialized
DEBUG - 2020-02-12 13:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 13:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 13:29:48 --> Controller Class Initialized
DEBUG - 2020-02-12 13:29:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-12 13:29:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 13:29:48 --> Final output sent to browser
DEBUG - 2020-02-12 13:29:48 --> Total execution time: 0.3401
INFO - 2020-02-12 14:24:38 --> Config Class Initialized
INFO - 2020-02-12 14:24:38 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:24:38 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:24:38 --> Utf8 Class Initialized
INFO - 2020-02-12 14:24:38 --> URI Class Initialized
INFO - 2020-02-12 14:24:38 --> Router Class Initialized
INFO - 2020-02-12 14:24:38 --> Output Class Initialized
INFO - 2020-02-12 14:24:38 --> Security Class Initialized
DEBUG - 2020-02-12 14:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:24:38 --> Input Class Initialized
INFO - 2020-02-12 14:24:38 --> Language Class Initialized
INFO - 2020-02-12 14:24:38 --> Language Class Initialized
INFO - 2020-02-12 14:24:38 --> Config Class Initialized
INFO - 2020-02-12 14:24:38 --> Loader Class Initialized
INFO - 2020-02-12 14:24:38 --> Helper loaded: url_helper
INFO - 2020-02-12 14:24:38 --> Helper loaded: file_helper
INFO - 2020-02-12 14:24:38 --> Helper loaded: form_helper
INFO - 2020-02-12 14:24:38 --> Helper loaded: my_helper
INFO - 2020-02-12 14:24:38 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:24:38 --> Controller Class Initialized
INFO - 2020-02-12 14:24:38 --> Helper loaded: cookie_helper
INFO - 2020-02-12 14:24:38 --> Config Class Initialized
INFO - 2020-02-12 14:24:38 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:24:38 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:24:38 --> Utf8 Class Initialized
INFO - 2020-02-12 14:24:38 --> URI Class Initialized
INFO - 2020-02-12 14:24:38 --> Router Class Initialized
INFO - 2020-02-12 14:24:38 --> Output Class Initialized
INFO - 2020-02-12 14:24:38 --> Security Class Initialized
DEBUG - 2020-02-12 14:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:24:38 --> Input Class Initialized
INFO - 2020-02-12 14:24:38 --> Language Class Initialized
INFO - 2020-02-12 14:24:38 --> Language Class Initialized
INFO - 2020-02-12 14:24:38 --> Config Class Initialized
INFO - 2020-02-12 14:24:38 --> Loader Class Initialized
INFO - 2020-02-12 14:24:39 --> Helper loaded: url_helper
INFO - 2020-02-12 14:24:39 --> Helper loaded: file_helper
INFO - 2020-02-12 14:24:39 --> Helper loaded: form_helper
INFO - 2020-02-12 14:24:39 --> Helper loaded: my_helper
INFO - 2020-02-12 14:24:39 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:24:39 --> Controller Class Initialized
INFO - 2020-02-12 14:24:39 --> Config Class Initialized
INFO - 2020-02-12 14:24:39 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:24:39 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:24:39 --> Utf8 Class Initialized
INFO - 2020-02-12 14:24:39 --> URI Class Initialized
INFO - 2020-02-12 14:24:39 --> Router Class Initialized
INFO - 2020-02-12 14:24:39 --> Output Class Initialized
INFO - 2020-02-12 14:24:39 --> Security Class Initialized
DEBUG - 2020-02-12 14:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:24:39 --> Input Class Initialized
INFO - 2020-02-12 14:24:39 --> Language Class Initialized
INFO - 2020-02-12 14:24:39 --> Language Class Initialized
INFO - 2020-02-12 14:24:39 --> Config Class Initialized
INFO - 2020-02-12 14:24:39 --> Loader Class Initialized
INFO - 2020-02-12 14:24:39 --> Helper loaded: url_helper
INFO - 2020-02-12 14:24:39 --> Helper loaded: file_helper
INFO - 2020-02-12 14:24:39 --> Helper loaded: form_helper
INFO - 2020-02-12 14:24:39 --> Helper loaded: my_helper
INFO - 2020-02-12 14:24:39 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:24:39 --> Controller Class Initialized
DEBUG - 2020-02-12 14:24:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-12 14:24:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:24:39 --> Final output sent to browser
DEBUG - 2020-02-12 14:24:39 --> Total execution time: 0.2823
INFO - 2020-02-12 14:25:26 --> Config Class Initialized
INFO - 2020-02-12 14:25:26 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:25:26 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:25:26 --> Utf8 Class Initialized
INFO - 2020-02-12 14:25:26 --> URI Class Initialized
INFO - 2020-02-12 14:25:26 --> Router Class Initialized
INFO - 2020-02-12 14:25:26 --> Output Class Initialized
INFO - 2020-02-12 14:25:26 --> Security Class Initialized
DEBUG - 2020-02-12 14:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:25:26 --> Input Class Initialized
INFO - 2020-02-12 14:25:26 --> Language Class Initialized
INFO - 2020-02-12 14:25:26 --> Language Class Initialized
INFO - 2020-02-12 14:25:26 --> Config Class Initialized
INFO - 2020-02-12 14:25:26 --> Loader Class Initialized
INFO - 2020-02-12 14:25:26 --> Helper loaded: url_helper
INFO - 2020-02-12 14:25:26 --> Helper loaded: file_helper
INFO - 2020-02-12 14:25:26 --> Helper loaded: form_helper
INFO - 2020-02-12 14:25:26 --> Helper loaded: my_helper
INFO - 2020-02-12 14:25:26 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:25:26 --> Controller Class Initialized
INFO - 2020-02-12 14:25:26 --> Helper loaded: cookie_helper
INFO - 2020-02-12 14:25:26 --> Final output sent to browser
DEBUG - 2020-02-12 14:25:26 --> Total execution time: 0.3224
INFO - 2020-02-12 14:25:26 --> Config Class Initialized
INFO - 2020-02-12 14:25:26 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:25:26 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:25:26 --> Utf8 Class Initialized
INFO - 2020-02-12 14:25:26 --> URI Class Initialized
INFO - 2020-02-12 14:25:26 --> Router Class Initialized
INFO - 2020-02-12 14:25:26 --> Output Class Initialized
INFO - 2020-02-12 14:25:26 --> Security Class Initialized
DEBUG - 2020-02-12 14:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:25:26 --> Input Class Initialized
INFO - 2020-02-12 14:25:26 --> Language Class Initialized
INFO - 2020-02-12 14:25:26 --> Language Class Initialized
INFO - 2020-02-12 14:25:26 --> Config Class Initialized
INFO - 2020-02-12 14:25:26 --> Loader Class Initialized
INFO - 2020-02-12 14:25:26 --> Helper loaded: url_helper
INFO - 2020-02-12 14:25:26 --> Helper loaded: file_helper
INFO - 2020-02-12 14:25:26 --> Helper loaded: form_helper
INFO - 2020-02-12 14:25:26 --> Helper loaded: my_helper
INFO - 2020-02-12 14:25:26 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:25:27 --> Controller Class Initialized
DEBUG - 2020-02-12 14:25:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-12 14:25:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:25:27 --> Final output sent to browser
DEBUG - 2020-02-12 14:25:27 --> Total execution time: 0.3133
INFO - 2020-02-12 14:25:57 --> Config Class Initialized
INFO - 2020-02-12 14:25:57 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:25:57 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:25:57 --> Utf8 Class Initialized
INFO - 2020-02-12 14:25:57 --> URI Class Initialized
INFO - 2020-02-12 14:25:57 --> Router Class Initialized
INFO - 2020-02-12 14:25:57 --> Output Class Initialized
INFO - 2020-02-12 14:25:57 --> Security Class Initialized
DEBUG - 2020-02-12 14:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:25:57 --> Input Class Initialized
INFO - 2020-02-12 14:25:57 --> Language Class Initialized
INFO - 2020-02-12 14:25:57 --> Language Class Initialized
INFO - 2020-02-12 14:25:57 --> Config Class Initialized
INFO - 2020-02-12 14:25:57 --> Loader Class Initialized
INFO - 2020-02-12 14:25:57 --> Helper loaded: url_helper
INFO - 2020-02-12 14:25:57 --> Helper loaded: file_helper
INFO - 2020-02-12 14:25:57 --> Helper loaded: form_helper
INFO - 2020-02-12 14:25:57 --> Helper loaded: my_helper
INFO - 2020-02-12 14:25:57 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:25:57 --> Controller Class Initialized
DEBUG - 2020-02-12 14:25:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-12 14:25:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:25:57 --> Final output sent to browser
DEBUG - 2020-02-12 14:25:57 --> Total execution time: 0.2536
INFO - 2020-02-12 14:25:57 --> Config Class Initialized
INFO - 2020-02-12 14:25:57 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:25:57 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:25:57 --> Utf8 Class Initialized
INFO - 2020-02-12 14:25:57 --> URI Class Initialized
INFO - 2020-02-12 14:25:57 --> Router Class Initialized
INFO - 2020-02-12 14:25:57 --> Output Class Initialized
INFO - 2020-02-12 14:25:57 --> Security Class Initialized
DEBUG - 2020-02-12 14:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:25:57 --> Input Class Initialized
INFO - 2020-02-12 14:25:57 --> Language Class Initialized
INFO - 2020-02-12 14:25:57 --> Language Class Initialized
INFO - 2020-02-12 14:25:57 --> Config Class Initialized
INFO - 2020-02-12 14:25:57 --> Loader Class Initialized
INFO - 2020-02-12 14:25:57 --> Helper loaded: url_helper
INFO - 2020-02-12 14:25:57 --> Helper loaded: file_helper
INFO - 2020-02-12 14:25:57 --> Helper loaded: form_helper
INFO - 2020-02-12 14:25:57 --> Helper loaded: my_helper
INFO - 2020-02-12 14:25:57 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:25:57 --> Controller Class Initialized
INFO - 2020-02-12 14:26:00 --> Config Class Initialized
INFO - 2020-02-12 14:26:00 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:00 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:00 --> URI Class Initialized
INFO - 2020-02-12 14:26:00 --> Router Class Initialized
INFO - 2020-02-12 14:26:00 --> Output Class Initialized
INFO - 2020-02-12 14:26:00 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:00 --> Input Class Initialized
INFO - 2020-02-12 14:26:00 --> Language Class Initialized
INFO - 2020-02-12 14:26:00 --> Language Class Initialized
INFO - 2020-02-12 14:26:00 --> Config Class Initialized
INFO - 2020-02-12 14:26:00 --> Loader Class Initialized
INFO - 2020-02-12 14:26:00 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:00 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:00 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:00 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:00 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:00 --> Controller Class Initialized
DEBUG - 2020-02-12 14:26:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-12 14:26:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:26:00 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:00 --> Total execution time: 0.4106
INFO - 2020-02-12 14:26:00 --> Config Class Initialized
INFO - 2020-02-12 14:26:00 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:00 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:00 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:00 --> URI Class Initialized
INFO - 2020-02-12 14:26:00 --> Router Class Initialized
INFO - 2020-02-12 14:26:00 --> Output Class Initialized
INFO - 2020-02-12 14:26:00 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:01 --> Input Class Initialized
INFO - 2020-02-12 14:26:01 --> Language Class Initialized
INFO - 2020-02-12 14:26:01 --> Language Class Initialized
INFO - 2020-02-12 14:26:01 --> Config Class Initialized
INFO - 2020-02-12 14:26:01 --> Loader Class Initialized
INFO - 2020-02-12 14:26:01 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:01 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:01 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:01 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:01 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:01 --> Controller Class Initialized
INFO - 2020-02-12 14:26:13 --> Config Class Initialized
INFO - 2020-02-12 14:26:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:13 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:13 --> URI Class Initialized
INFO - 2020-02-12 14:26:13 --> Router Class Initialized
INFO - 2020-02-12 14:26:13 --> Output Class Initialized
INFO - 2020-02-12 14:26:13 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:13 --> Input Class Initialized
INFO - 2020-02-12 14:26:13 --> Language Class Initialized
INFO - 2020-02-12 14:26:13 --> Language Class Initialized
INFO - 2020-02-12 14:26:13 --> Config Class Initialized
INFO - 2020-02-12 14:26:13 --> Loader Class Initialized
INFO - 2020-02-12 14:26:13 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:13 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:13 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:13 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:13 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:13 --> Controller Class Initialized
DEBUG - 2020-02-12 14:26:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-12 14:26:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:26:13 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:13 --> Total execution time: 0.3007
INFO - 2020-02-12 14:26:14 --> Config Class Initialized
INFO - 2020-02-12 14:26:14 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:14 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:14 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:14 --> URI Class Initialized
INFO - 2020-02-12 14:26:14 --> Router Class Initialized
INFO - 2020-02-12 14:26:14 --> Output Class Initialized
INFO - 2020-02-12 14:26:14 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:14 --> Input Class Initialized
INFO - 2020-02-12 14:26:14 --> Language Class Initialized
INFO - 2020-02-12 14:26:14 --> Language Class Initialized
INFO - 2020-02-12 14:26:14 --> Config Class Initialized
INFO - 2020-02-12 14:26:14 --> Loader Class Initialized
INFO - 2020-02-12 14:26:14 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:14 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:14 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:14 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:14 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:14 --> Controller Class Initialized
INFO - 2020-02-12 14:26:15 --> Config Class Initialized
INFO - 2020-02-12 14:26:15 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:15 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:15 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:15 --> URI Class Initialized
INFO - 2020-02-12 14:26:15 --> Router Class Initialized
INFO - 2020-02-12 14:26:15 --> Output Class Initialized
INFO - 2020-02-12 14:26:15 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:15 --> Input Class Initialized
INFO - 2020-02-12 14:26:15 --> Language Class Initialized
INFO - 2020-02-12 14:26:15 --> Language Class Initialized
INFO - 2020-02-12 14:26:15 --> Config Class Initialized
INFO - 2020-02-12 14:26:15 --> Loader Class Initialized
INFO - 2020-02-12 14:26:15 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:15 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:15 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:15 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:15 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:15 --> Controller Class Initialized
DEBUG - 2020-02-12 14:26:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-12 14:26:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:26:15 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:15 --> Total execution time: 0.4036
INFO - 2020-02-12 14:26:16 --> Config Class Initialized
INFO - 2020-02-12 14:26:16 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:16 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:16 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:16 --> URI Class Initialized
INFO - 2020-02-12 14:26:16 --> Router Class Initialized
INFO - 2020-02-12 14:26:16 --> Output Class Initialized
INFO - 2020-02-12 14:26:16 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:16 --> Input Class Initialized
INFO - 2020-02-12 14:26:16 --> Language Class Initialized
INFO - 2020-02-12 14:26:16 --> Language Class Initialized
INFO - 2020-02-12 14:26:16 --> Config Class Initialized
INFO - 2020-02-12 14:26:16 --> Loader Class Initialized
INFO - 2020-02-12 14:26:16 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:16 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:16 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:16 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:16 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:16 --> Controller Class Initialized
INFO - 2020-02-12 14:26:21 --> Config Class Initialized
INFO - 2020-02-12 14:26:21 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:21 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:21 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:21 --> URI Class Initialized
INFO - 2020-02-12 14:26:21 --> Router Class Initialized
INFO - 2020-02-12 14:26:21 --> Output Class Initialized
INFO - 2020-02-12 14:26:21 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:21 --> Input Class Initialized
INFO - 2020-02-12 14:26:21 --> Language Class Initialized
INFO - 2020-02-12 14:26:21 --> Language Class Initialized
INFO - 2020-02-12 14:26:21 --> Config Class Initialized
INFO - 2020-02-12 14:26:21 --> Loader Class Initialized
INFO - 2020-02-12 14:26:21 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:21 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:21 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:21 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:21 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:21 --> Controller Class Initialized
DEBUG - 2020-02-12 14:26:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-12 14:26:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:26:21 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:21 --> Total execution time: 0.3003
INFO - 2020-02-12 14:26:21 --> Config Class Initialized
INFO - 2020-02-12 14:26:21 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:21 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:21 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:21 --> URI Class Initialized
INFO - 2020-02-12 14:26:21 --> Router Class Initialized
INFO - 2020-02-12 14:26:21 --> Output Class Initialized
INFO - 2020-02-12 14:26:21 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:22 --> Input Class Initialized
INFO - 2020-02-12 14:26:22 --> Language Class Initialized
INFO - 2020-02-12 14:26:22 --> Language Class Initialized
INFO - 2020-02-12 14:26:22 --> Config Class Initialized
INFO - 2020-02-12 14:26:22 --> Loader Class Initialized
INFO - 2020-02-12 14:26:22 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:22 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:22 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:22 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:22 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:22 --> Controller Class Initialized
INFO - 2020-02-12 14:26:45 --> Config Class Initialized
INFO - 2020-02-12 14:26:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:45 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:45 --> URI Class Initialized
INFO - 2020-02-12 14:26:45 --> Router Class Initialized
INFO - 2020-02-12 14:26:45 --> Output Class Initialized
INFO - 2020-02-12 14:26:45 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:45 --> Input Class Initialized
INFO - 2020-02-12 14:26:45 --> Language Class Initialized
INFO - 2020-02-12 14:26:45 --> Language Class Initialized
INFO - 2020-02-12 14:26:45 --> Config Class Initialized
INFO - 2020-02-12 14:26:45 --> Loader Class Initialized
INFO - 2020-02-12 14:26:45 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:45 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:45 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:45 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:45 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:45 --> Controller Class Initialized
INFO - 2020-02-12 14:26:45 --> Helper loaded: cookie_helper
INFO - 2020-02-12 14:26:45 --> Config Class Initialized
INFO - 2020-02-12 14:26:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:45 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:45 --> URI Class Initialized
INFO - 2020-02-12 14:26:45 --> Router Class Initialized
INFO - 2020-02-12 14:26:45 --> Output Class Initialized
INFO - 2020-02-12 14:26:45 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:45 --> Input Class Initialized
INFO - 2020-02-12 14:26:45 --> Language Class Initialized
INFO - 2020-02-12 14:26:45 --> Language Class Initialized
INFO - 2020-02-12 14:26:45 --> Config Class Initialized
INFO - 2020-02-12 14:26:45 --> Loader Class Initialized
INFO - 2020-02-12 14:26:45 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:45 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:45 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:45 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:45 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:45 --> Controller Class Initialized
INFO - 2020-02-12 14:26:45 --> Config Class Initialized
INFO - 2020-02-12 14:26:45 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:45 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:45 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:45 --> URI Class Initialized
INFO - 2020-02-12 14:26:45 --> Router Class Initialized
INFO - 2020-02-12 14:26:46 --> Output Class Initialized
INFO - 2020-02-12 14:26:46 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:46 --> Input Class Initialized
INFO - 2020-02-12 14:26:46 --> Language Class Initialized
INFO - 2020-02-12 14:26:46 --> Language Class Initialized
INFO - 2020-02-12 14:26:46 --> Config Class Initialized
INFO - 2020-02-12 14:26:46 --> Loader Class Initialized
INFO - 2020-02-12 14:26:46 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:46 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:46 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:46 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:46 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:46 --> Controller Class Initialized
DEBUG - 2020-02-12 14:26:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-12 14:26:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:26:46 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:46 --> Total execution time: 0.2746
INFO - 2020-02-12 14:26:56 --> Config Class Initialized
INFO - 2020-02-12 14:26:56 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:56 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:56 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:56 --> URI Class Initialized
INFO - 2020-02-12 14:26:56 --> Router Class Initialized
INFO - 2020-02-12 14:26:56 --> Output Class Initialized
INFO - 2020-02-12 14:26:56 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:56 --> Input Class Initialized
INFO - 2020-02-12 14:26:56 --> Language Class Initialized
INFO - 2020-02-12 14:26:56 --> Language Class Initialized
INFO - 2020-02-12 14:26:56 --> Config Class Initialized
INFO - 2020-02-12 14:26:56 --> Loader Class Initialized
INFO - 2020-02-12 14:26:56 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:56 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:56 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:56 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:56 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:56 --> Controller Class Initialized
INFO - 2020-02-12 14:26:56 --> Helper loaded: cookie_helper
INFO - 2020-02-12 14:26:56 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:56 --> Total execution time: 0.3139
INFO - 2020-02-12 14:26:56 --> Config Class Initialized
INFO - 2020-02-12 14:26:56 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:26:56 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:26:56 --> Utf8 Class Initialized
INFO - 2020-02-12 14:26:56 --> URI Class Initialized
INFO - 2020-02-12 14:26:56 --> Router Class Initialized
INFO - 2020-02-12 14:26:56 --> Output Class Initialized
INFO - 2020-02-12 14:26:56 --> Security Class Initialized
DEBUG - 2020-02-12 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:26:56 --> Input Class Initialized
INFO - 2020-02-12 14:26:56 --> Language Class Initialized
INFO - 2020-02-12 14:26:56 --> Language Class Initialized
INFO - 2020-02-12 14:26:56 --> Config Class Initialized
INFO - 2020-02-12 14:26:56 --> Loader Class Initialized
INFO - 2020-02-12 14:26:56 --> Helper loaded: url_helper
INFO - 2020-02-12 14:26:56 --> Helper loaded: file_helper
INFO - 2020-02-12 14:26:56 --> Helper loaded: form_helper
INFO - 2020-02-12 14:26:56 --> Helper loaded: my_helper
INFO - 2020-02-12 14:26:56 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:26:56 --> Controller Class Initialized
DEBUG - 2020-02-12 14:26:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-12 14:26:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:26:56 --> Final output sent to browser
DEBUG - 2020-02-12 14:26:56 --> Total execution time: 0.3305
INFO - 2020-02-12 14:27:25 --> Config Class Initialized
INFO - 2020-02-12 14:27:25 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:27:25 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:27:25 --> Utf8 Class Initialized
INFO - 2020-02-12 14:27:25 --> URI Class Initialized
INFO - 2020-02-12 14:27:25 --> Router Class Initialized
INFO - 2020-02-12 14:27:25 --> Output Class Initialized
INFO - 2020-02-12 14:27:25 --> Security Class Initialized
DEBUG - 2020-02-12 14:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:27:25 --> Input Class Initialized
INFO - 2020-02-12 14:27:25 --> Language Class Initialized
INFO - 2020-02-12 14:27:25 --> Language Class Initialized
INFO - 2020-02-12 14:27:25 --> Config Class Initialized
INFO - 2020-02-12 14:27:25 --> Loader Class Initialized
INFO - 2020-02-12 14:27:25 --> Helper loaded: url_helper
INFO - 2020-02-12 14:27:25 --> Helper loaded: file_helper
INFO - 2020-02-12 14:27:25 --> Helper loaded: form_helper
INFO - 2020-02-12 14:27:25 --> Helper loaded: my_helper
INFO - 2020-02-12 14:27:25 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:27:25 --> Controller Class Initialized
DEBUG - 2020-02-12 14:27:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-12 14:27:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:27:25 --> Final output sent to browser
DEBUG - 2020-02-12 14:27:25 --> Total execution time: 0.3011
INFO - 2020-02-12 14:27:27 --> Config Class Initialized
INFO - 2020-02-12 14:27:27 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:27:28 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:27:28 --> Utf8 Class Initialized
INFO - 2020-02-12 14:27:28 --> URI Class Initialized
INFO - 2020-02-12 14:27:28 --> Router Class Initialized
INFO - 2020-02-12 14:27:28 --> Output Class Initialized
INFO - 2020-02-12 14:27:28 --> Security Class Initialized
DEBUG - 2020-02-12 14:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:27:28 --> Input Class Initialized
INFO - 2020-02-12 14:27:28 --> Language Class Initialized
INFO - 2020-02-12 14:27:28 --> Language Class Initialized
INFO - 2020-02-12 14:27:28 --> Config Class Initialized
INFO - 2020-02-12 14:27:28 --> Loader Class Initialized
INFO - 2020-02-12 14:27:28 --> Helper loaded: url_helper
INFO - 2020-02-12 14:27:28 --> Helper loaded: file_helper
INFO - 2020-02-12 14:27:28 --> Helper loaded: form_helper
INFO - 2020-02-12 14:27:28 --> Helper loaded: my_helper
INFO - 2020-02-12 14:27:28 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:27:28 --> Controller Class Initialized
DEBUG - 2020-02-12 14:27:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-12 14:27:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:27:28 --> Final output sent to browser
DEBUG - 2020-02-12 14:27:28 --> Total execution time: 0.3134
INFO - 2020-02-12 14:27:28 --> Config Class Initialized
INFO - 2020-02-12 14:27:28 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:27:28 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:27:28 --> Utf8 Class Initialized
INFO - 2020-02-12 14:27:28 --> URI Class Initialized
INFO - 2020-02-12 14:27:28 --> Router Class Initialized
INFO - 2020-02-12 14:27:28 --> Output Class Initialized
INFO - 2020-02-12 14:27:28 --> Security Class Initialized
DEBUG - 2020-02-12 14:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:27:28 --> Input Class Initialized
INFO - 2020-02-12 14:27:28 --> Language Class Initialized
INFO - 2020-02-12 14:27:28 --> Language Class Initialized
INFO - 2020-02-12 14:27:28 --> Config Class Initialized
INFO - 2020-02-12 14:27:28 --> Loader Class Initialized
INFO - 2020-02-12 14:27:28 --> Helper loaded: url_helper
INFO - 2020-02-12 14:27:28 --> Helper loaded: file_helper
INFO - 2020-02-12 14:27:28 --> Helper loaded: form_helper
INFO - 2020-02-12 14:27:28 --> Helper loaded: my_helper
INFO - 2020-02-12 14:27:28 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:27:28 --> Controller Class Initialized
INFO - 2020-02-12 14:27:41 --> Config Class Initialized
INFO - 2020-02-12 14:27:41 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:27:41 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:27:41 --> Utf8 Class Initialized
INFO - 2020-02-12 14:27:41 --> URI Class Initialized
INFO - 2020-02-12 14:27:41 --> Router Class Initialized
INFO - 2020-02-12 14:27:41 --> Output Class Initialized
INFO - 2020-02-12 14:27:41 --> Security Class Initialized
DEBUG - 2020-02-12 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:27:41 --> Input Class Initialized
INFO - 2020-02-12 14:27:41 --> Language Class Initialized
INFO - 2020-02-12 14:27:41 --> Language Class Initialized
INFO - 2020-02-12 14:27:41 --> Config Class Initialized
INFO - 2020-02-12 14:27:41 --> Loader Class Initialized
INFO - 2020-02-12 14:27:41 --> Helper loaded: url_helper
INFO - 2020-02-12 14:27:41 --> Helper loaded: file_helper
INFO - 2020-02-12 14:27:41 --> Helper loaded: form_helper
INFO - 2020-02-12 14:27:41 --> Helper loaded: my_helper
INFO - 2020-02-12 14:27:41 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:27:41 --> Controller Class Initialized
INFO - 2020-02-12 14:27:41 --> Final output sent to browser
DEBUG - 2020-02-12 14:27:41 --> Total execution time: 0.2496
INFO - 2020-02-12 14:28:11 --> Config Class Initialized
INFO - 2020-02-12 14:28:11 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:11 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:11 --> URI Class Initialized
INFO - 2020-02-12 14:28:11 --> Router Class Initialized
INFO - 2020-02-12 14:28:11 --> Output Class Initialized
INFO - 2020-02-12 14:28:11 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:11 --> Input Class Initialized
INFO - 2020-02-12 14:28:11 --> Language Class Initialized
INFO - 2020-02-12 14:28:11 --> Language Class Initialized
INFO - 2020-02-12 14:28:11 --> Config Class Initialized
INFO - 2020-02-12 14:28:11 --> Loader Class Initialized
INFO - 2020-02-12 14:28:11 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:11 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:11 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:11 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:11 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:11 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-12 14:28:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:28:11 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:11 --> Total execution time: 0.3344
INFO - 2020-02-12 14:28:13 --> Config Class Initialized
INFO - 2020-02-12 14:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:13 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:13 --> URI Class Initialized
INFO - 2020-02-12 14:28:13 --> Router Class Initialized
INFO - 2020-02-12 14:28:13 --> Output Class Initialized
INFO - 2020-02-12 14:28:13 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:13 --> Input Class Initialized
INFO - 2020-02-12 14:28:13 --> Language Class Initialized
INFO - 2020-02-12 14:28:13 --> Language Class Initialized
INFO - 2020-02-12 14:28:13 --> Config Class Initialized
INFO - 2020-02-12 14:28:13 --> Loader Class Initialized
INFO - 2020-02-12 14:28:13 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:13 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:13 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:13 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:13 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:13 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-12 14:28:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:28:13 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:13 --> Total execution time: 0.4143
INFO - 2020-02-12 14:28:15 --> Config Class Initialized
INFO - 2020-02-12 14:28:15 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:15 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:15 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:15 --> URI Class Initialized
INFO - 2020-02-12 14:28:15 --> Router Class Initialized
INFO - 2020-02-12 14:28:15 --> Output Class Initialized
INFO - 2020-02-12 14:28:15 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:15 --> Input Class Initialized
INFO - 2020-02-12 14:28:15 --> Language Class Initialized
INFO - 2020-02-12 14:28:15 --> Language Class Initialized
INFO - 2020-02-12 14:28:15 --> Config Class Initialized
INFO - 2020-02-12 14:28:15 --> Loader Class Initialized
INFO - 2020-02-12 14:28:15 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:15 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:15 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:15 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:15 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:15 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-12 14:28:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:28:15 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:15 --> Total execution time: 0.3634
INFO - 2020-02-12 14:28:16 --> Config Class Initialized
INFO - 2020-02-12 14:28:16 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:16 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:16 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:16 --> URI Class Initialized
INFO - 2020-02-12 14:28:16 --> Router Class Initialized
INFO - 2020-02-12 14:28:16 --> Output Class Initialized
INFO - 2020-02-12 14:28:16 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:16 --> Input Class Initialized
INFO - 2020-02-12 14:28:16 --> Language Class Initialized
INFO - 2020-02-12 14:28:16 --> Language Class Initialized
INFO - 2020-02-12 14:28:16 --> Config Class Initialized
INFO - 2020-02-12 14:28:16 --> Loader Class Initialized
INFO - 2020-02-12 14:28:16 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:16 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:16 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:16 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:16 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:16 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-12 14:28:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:28:17 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:17 --> Total execution time: 0.3379
INFO - 2020-02-12 14:28:18 --> Config Class Initialized
INFO - 2020-02-12 14:28:18 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:18 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:18 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:18 --> URI Class Initialized
INFO - 2020-02-12 14:28:18 --> Router Class Initialized
INFO - 2020-02-12 14:28:18 --> Output Class Initialized
INFO - 2020-02-12 14:28:18 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:18 --> Input Class Initialized
INFO - 2020-02-12 14:28:18 --> Language Class Initialized
INFO - 2020-02-12 14:28:18 --> Language Class Initialized
INFO - 2020-02-12 14:28:18 --> Config Class Initialized
INFO - 2020-02-12 14:28:18 --> Loader Class Initialized
INFO - 2020-02-12 14:28:18 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:18 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:18 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:18 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:18 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:18 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-12 14:28:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:28:18 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:18 --> Total execution time: 0.3102
INFO - 2020-02-12 14:28:18 --> Config Class Initialized
INFO - 2020-02-12 14:28:18 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:18 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:19 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:19 --> URI Class Initialized
INFO - 2020-02-12 14:28:19 --> Router Class Initialized
INFO - 2020-02-12 14:28:19 --> Output Class Initialized
INFO - 2020-02-12 14:28:19 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:19 --> Input Class Initialized
INFO - 2020-02-12 14:28:19 --> Language Class Initialized
INFO - 2020-02-12 14:28:19 --> Language Class Initialized
INFO - 2020-02-12 14:28:19 --> Config Class Initialized
INFO - 2020-02-12 14:28:19 --> Loader Class Initialized
INFO - 2020-02-12 14:28:19 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:19 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:19 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:19 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:19 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:19 --> Controller Class Initialized
INFO - 2020-02-12 14:28:19 --> Config Class Initialized
INFO - 2020-02-12 14:28:19 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:19 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:19 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:19 --> URI Class Initialized
INFO - 2020-02-12 14:28:19 --> Router Class Initialized
INFO - 2020-02-12 14:28:19 --> Output Class Initialized
INFO - 2020-02-12 14:28:19 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:19 --> Input Class Initialized
INFO - 2020-02-12 14:28:19 --> Language Class Initialized
INFO - 2020-02-12 14:28:20 --> Language Class Initialized
INFO - 2020-02-12 14:28:20 --> Config Class Initialized
INFO - 2020-02-12 14:28:20 --> Loader Class Initialized
INFO - 2020-02-12 14:28:20 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:20 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:20 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:20 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:20 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:20 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-12 14:28:20 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:20 --> Total execution time: 0.5486
INFO - 2020-02-12 14:28:49 --> Config Class Initialized
INFO - 2020-02-12 14:28:49 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:49 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:49 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:49 --> URI Class Initialized
INFO - 2020-02-12 14:28:49 --> Router Class Initialized
INFO - 2020-02-12 14:28:49 --> Output Class Initialized
INFO - 2020-02-12 14:28:49 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:49 --> Input Class Initialized
INFO - 2020-02-12 14:28:49 --> Language Class Initialized
INFO - 2020-02-12 14:28:49 --> Language Class Initialized
INFO - 2020-02-12 14:28:49 --> Config Class Initialized
INFO - 2020-02-12 14:28:49 --> Loader Class Initialized
INFO - 2020-02-12 14:28:49 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:49 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:49 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:49 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:50 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:50 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-02-12 14:28:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:28:50 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:50 --> Total execution time: 0.3127
INFO - 2020-02-12 14:28:52 --> Config Class Initialized
INFO - 2020-02-12 14:28:52 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:28:52 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:28:52 --> Utf8 Class Initialized
INFO - 2020-02-12 14:28:52 --> URI Class Initialized
INFO - 2020-02-12 14:28:52 --> Router Class Initialized
INFO - 2020-02-12 14:28:52 --> Output Class Initialized
INFO - 2020-02-12 14:28:52 --> Security Class Initialized
DEBUG - 2020-02-12 14:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:28:52 --> Input Class Initialized
INFO - 2020-02-12 14:28:52 --> Language Class Initialized
INFO - 2020-02-12 14:28:52 --> Language Class Initialized
INFO - 2020-02-12 14:28:52 --> Config Class Initialized
INFO - 2020-02-12 14:28:52 --> Loader Class Initialized
INFO - 2020-02-12 14:28:52 --> Helper loaded: url_helper
INFO - 2020-02-12 14:28:52 --> Helper loaded: file_helper
INFO - 2020-02-12 14:28:52 --> Helper loaded: form_helper
INFO - 2020-02-12 14:28:52 --> Helper loaded: my_helper
INFO - 2020-02-12 14:28:52 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:28:52 --> Controller Class Initialized
DEBUG - 2020-02-12 14:28:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-02-12 14:28:52 --> Final output sent to browser
DEBUG - 2020-02-12 14:28:52 --> Total execution time: 0.3822
INFO - 2020-02-12 14:29:29 --> Config Class Initialized
INFO - 2020-02-12 14:29:29 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:29:29 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:29:29 --> Utf8 Class Initialized
INFO - 2020-02-12 14:29:29 --> URI Class Initialized
INFO - 2020-02-12 14:29:29 --> Router Class Initialized
INFO - 2020-02-12 14:29:29 --> Output Class Initialized
INFO - 2020-02-12 14:29:29 --> Security Class Initialized
DEBUG - 2020-02-12 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:29:29 --> Input Class Initialized
INFO - 2020-02-12 14:29:29 --> Language Class Initialized
INFO - 2020-02-12 14:29:29 --> Language Class Initialized
INFO - 2020-02-12 14:29:29 --> Config Class Initialized
INFO - 2020-02-12 14:29:29 --> Loader Class Initialized
INFO - 2020-02-12 14:29:29 --> Helper loaded: url_helper
INFO - 2020-02-12 14:29:29 --> Helper loaded: file_helper
INFO - 2020-02-12 14:29:29 --> Helper loaded: form_helper
INFO - 2020-02-12 14:29:29 --> Helper loaded: my_helper
INFO - 2020-02-12 14:29:29 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:29:29 --> Controller Class Initialized
DEBUG - 2020-02-12 14:29:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-02-12 14:29:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-12 14:29:29 --> Final output sent to browser
DEBUG - 2020-02-12 14:29:29 --> Total execution time: 0.3298
INFO - 2020-02-12 14:29:32 --> Config Class Initialized
INFO - 2020-02-12 14:29:32 --> Hooks Class Initialized
DEBUG - 2020-02-12 14:29:32 --> UTF-8 Support Enabled
INFO - 2020-02-12 14:29:32 --> Utf8 Class Initialized
INFO - 2020-02-12 14:29:32 --> URI Class Initialized
INFO - 2020-02-12 14:29:32 --> Router Class Initialized
INFO - 2020-02-12 14:29:32 --> Output Class Initialized
INFO - 2020-02-12 14:29:32 --> Security Class Initialized
DEBUG - 2020-02-12 14:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 14:29:32 --> Input Class Initialized
INFO - 2020-02-12 14:29:32 --> Language Class Initialized
INFO - 2020-02-12 14:29:32 --> Language Class Initialized
INFO - 2020-02-12 14:29:32 --> Config Class Initialized
INFO - 2020-02-12 14:29:32 --> Loader Class Initialized
INFO - 2020-02-12 14:29:32 --> Helper loaded: url_helper
INFO - 2020-02-12 14:29:32 --> Helper loaded: file_helper
INFO - 2020-02-12 14:29:32 --> Helper loaded: form_helper
INFO - 2020-02-12 14:29:32 --> Helper loaded: my_helper
INFO - 2020-02-12 14:29:32 --> Database Driver Class Initialized
DEBUG - 2020-02-12 14:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-12 14:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-12 14:29:32 --> Controller Class Initialized
DEBUG - 2020-02-12 14:29:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-02-12 14:29:32 --> Final output sent to browser
DEBUG - 2020-02-12 14:29:32 --> Total execution time: 0.4088
