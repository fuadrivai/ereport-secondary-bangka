<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-01 10:22:30 --> Config Class Initialized
INFO - 2024-07-01 10:22:30 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:22:30 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:22:30 --> Utf8 Class Initialized
INFO - 2024-07-01 10:22:30 --> URI Class Initialized
INFO - 2024-07-01 10:22:30 --> Router Class Initialized
INFO - 2024-07-01 10:22:30 --> Output Class Initialized
INFO - 2024-07-01 10:22:30 --> Security Class Initialized
DEBUG - 2024-07-01 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:22:30 --> Input Class Initialized
INFO - 2024-07-01 10:22:30 --> Language Class Initialized
INFO - 2024-07-01 10:22:30 --> Language Class Initialized
INFO - 2024-07-01 10:22:30 --> Config Class Initialized
INFO - 2024-07-01 10:22:30 --> Loader Class Initialized
INFO - 2024-07-01 10:22:30 --> Helper loaded: url_helper
INFO - 2024-07-01 10:22:30 --> Helper loaded: file_helper
INFO - 2024-07-01 10:22:30 --> Helper loaded: form_helper
INFO - 2024-07-01 10:22:30 --> Helper loaded: my_helper
INFO - 2024-07-01 10:22:30 --> Database Driver Class Initialized
INFO - 2024-07-01 10:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:22:30 --> Controller Class Initialized
DEBUG - 2024-07-01 10:22:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-01 10:22:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:22:30 --> Final output sent to browser
DEBUG - 2024-07-01 10:22:30 --> Total execution time: 0.0779
INFO - 2024-07-01 10:22:33 --> Config Class Initialized
INFO - 2024-07-01 10:22:33 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:22:33 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:22:33 --> Utf8 Class Initialized
INFO - 2024-07-01 10:22:33 --> URI Class Initialized
INFO - 2024-07-01 10:22:33 --> Router Class Initialized
INFO - 2024-07-01 10:22:33 --> Output Class Initialized
INFO - 2024-07-01 10:22:33 --> Security Class Initialized
DEBUG - 2024-07-01 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:22:33 --> Input Class Initialized
INFO - 2024-07-01 10:22:33 --> Language Class Initialized
INFO - 2024-07-01 10:22:33 --> Language Class Initialized
INFO - 2024-07-01 10:22:33 --> Config Class Initialized
INFO - 2024-07-01 10:22:33 --> Loader Class Initialized
INFO - 2024-07-01 10:22:33 --> Helper loaded: url_helper
INFO - 2024-07-01 10:22:33 --> Helper loaded: file_helper
INFO - 2024-07-01 10:22:33 --> Helper loaded: form_helper
INFO - 2024-07-01 10:22:33 --> Helper loaded: my_helper
INFO - 2024-07-01 10:22:33 --> Database Driver Class Initialized
INFO - 2024-07-01 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:22:33 --> Controller Class Initialized
INFO - 2024-07-01 10:22:33 --> Helper loaded: cookie_helper
INFO - 2024-07-01 10:22:33 --> Final output sent to browser
DEBUG - 2024-07-01 10:22:33 --> Total execution time: 0.0512
INFO - 2024-07-01 10:22:33 --> Config Class Initialized
INFO - 2024-07-01 10:22:33 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:22:33 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:22:33 --> Utf8 Class Initialized
INFO - 2024-07-01 10:22:33 --> URI Class Initialized
INFO - 2024-07-01 10:22:33 --> Router Class Initialized
INFO - 2024-07-01 10:22:33 --> Output Class Initialized
INFO - 2024-07-01 10:22:33 --> Security Class Initialized
DEBUG - 2024-07-01 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:22:33 --> Input Class Initialized
INFO - 2024-07-01 10:22:33 --> Language Class Initialized
INFO - 2024-07-01 10:22:33 --> Language Class Initialized
INFO - 2024-07-01 10:22:33 --> Config Class Initialized
INFO - 2024-07-01 10:22:33 --> Loader Class Initialized
INFO - 2024-07-01 10:22:33 --> Helper loaded: url_helper
INFO - 2024-07-01 10:22:33 --> Helper loaded: file_helper
INFO - 2024-07-01 10:22:33 --> Helper loaded: form_helper
INFO - 2024-07-01 10:22:33 --> Helper loaded: my_helper
INFO - 2024-07-01 10:22:33 --> Database Driver Class Initialized
INFO - 2024-07-01 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:22:33 --> Controller Class Initialized
DEBUG - 2024-07-01 10:22:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-07-01 10:22:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:22:33 --> Final output sent to browser
DEBUG - 2024-07-01 10:22:33 --> Total execution time: 0.0622
INFO - 2024-07-01 10:22:39 --> Config Class Initialized
INFO - 2024-07-01 10:22:39 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:22:39 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:22:39 --> Utf8 Class Initialized
INFO - 2024-07-01 10:22:39 --> URI Class Initialized
INFO - 2024-07-01 10:22:39 --> Router Class Initialized
INFO - 2024-07-01 10:22:39 --> Output Class Initialized
INFO - 2024-07-01 10:22:39 --> Security Class Initialized
DEBUG - 2024-07-01 10:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:22:39 --> Input Class Initialized
INFO - 2024-07-01 10:22:39 --> Language Class Initialized
INFO - 2024-07-01 10:22:39 --> Language Class Initialized
INFO - 2024-07-01 10:22:39 --> Config Class Initialized
INFO - 2024-07-01 10:22:39 --> Loader Class Initialized
INFO - 2024-07-01 10:22:39 --> Helper loaded: url_helper
INFO - 2024-07-01 10:22:39 --> Helper loaded: file_helper
INFO - 2024-07-01 10:22:39 --> Helper loaded: form_helper
INFO - 2024-07-01 10:22:39 --> Helper loaded: my_helper
INFO - 2024-07-01 10:22:39 --> Database Driver Class Initialized
INFO - 2024-07-01 10:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:22:39 --> Controller Class Initialized
DEBUG - 2024-07-01 10:22:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-07-01 10:22:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:22:39 --> Final output sent to browser
DEBUG - 2024-07-01 10:22:39 --> Total execution time: 0.0365
INFO - 2024-07-01 10:22:43 --> Config Class Initialized
INFO - 2024-07-01 10:22:43 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:22:43 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:22:43 --> Utf8 Class Initialized
INFO - 2024-07-01 10:22:43 --> URI Class Initialized
INFO - 2024-07-01 10:22:43 --> Router Class Initialized
INFO - 2024-07-01 10:22:43 --> Output Class Initialized
INFO - 2024-07-01 10:22:43 --> Security Class Initialized
DEBUG - 2024-07-01 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:22:43 --> Input Class Initialized
INFO - 2024-07-01 10:22:43 --> Language Class Initialized
INFO - 2024-07-01 10:22:43 --> Language Class Initialized
INFO - 2024-07-01 10:22:43 --> Config Class Initialized
INFO - 2024-07-01 10:22:43 --> Loader Class Initialized
INFO - 2024-07-01 10:22:43 --> Helper loaded: url_helper
INFO - 2024-07-01 10:22:43 --> Helper loaded: file_helper
INFO - 2024-07-01 10:22:43 --> Helper loaded: form_helper
INFO - 2024-07-01 10:22:43 --> Helper loaded: my_helper
INFO - 2024-07-01 10:22:43 --> Database Driver Class Initialized
INFO - 2024-07-01 10:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:22:43 --> Controller Class Initialized
ERROR - 2024-07-01 10:22:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-07-01 10:22:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-07-01 10:22:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-07-01 10:22:48 --> Final output sent to browser
DEBUG - 2024-07-01 10:22:48 --> Total execution time: 4.5148
INFO - 2024-07-01 10:26:14 --> Config Class Initialized
INFO - 2024-07-01 10:26:14 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:14 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:14 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:14 --> URI Class Initialized
DEBUG - 2024-07-01 10:26:14 --> No URI present. Default controller set.
INFO - 2024-07-01 10:26:14 --> Router Class Initialized
INFO - 2024-07-01 10:26:14 --> Output Class Initialized
INFO - 2024-07-01 10:26:14 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:14 --> Input Class Initialized
INFO - 2024-07-01 10:26:14 --> Language Class Initialized
INFO - 2024-07-01 10:26:14 --> Language Class Initialized
INFO - 2024-07-01 10:26:14 --> Config Class Initialized
INFO - 2024-07-01 10:26:14 --> Loader Class Initialized
INFO - 2024-07-01 10:26:14 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:14 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:14 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:14 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:14 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:14 --> Controller Class Initialized
INFO - 2024-07-01 10:26:14 --> Config Class Initialized
INFO - 2024-07-01 10:26:14 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:14 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:14 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:14 --> URI Class Initialized
INFO - 2024-07-01 10:26:14 --> Router Class Initialized
INFO - 2024-07-01 10:26:14 --> Output Class Initialized
INFO - 2024-07-01 10:26:14 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:14 --> Input Class Initialized
INFO - 2024-07-01 10:26:14 --> Language Class Initialized
INFO - 2024-07-01 10:26:14 --> Language Class Initialized
INFO - 2024-07-01 10:26:14 --> Config Class Initialized
INFO - 2024-07-01 10:26:14 --> Loader Class Initialized
INFO - 2024-07-01 10:26:14 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:14 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:14 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:14 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:15 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:15 --> Controller Class Initialized
DEBUG - 2024-07-01 10:26:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-01 10:26:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:26:15 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:15 --> Total execution time: 0.0476
INFO - 2024-07-01 10:26:21 --> Config Class Initialized
INFO - 2024-07-01 10:26:21 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:21 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:21 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:21 --> URI Class Initialized
INFO - 2024-07-01 10:26:21 --> Router Class Initialized
INFO - 2024-07-01 10:26:21 --> Output Class Initialized
INFO - 2024-07-01 10:26:21 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:21 --> Input Class Initialized
INFO - 2024-07-01 10:26:21 --> Language Class Initialized
INFO - 2024-07-01 10:26:21 --> Language Class Initialized
INFO - 2024-07-01 10:26:21 --> Config Class Initialized
INFO - 2024-07-01 10:26:21 --> Loader Class Initialized
INFO - 2024-07-01 10:26:21 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:21 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:21 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:21 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:21 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:21 --> Controller Class Initialized
INFO - 2024-07-01 10:26:21 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:21 --> Total execution time: 0.0353
INFO - 2024-07-01 10:26:26 --> Config Class Initialized
INFO - 2024-07-01 10:26:26 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:26 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:26 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:26 --> URI Class Initialized
INFO - 2024-07-01 10:26:26 --> Router Class Initialized
INFO - 2024-07-01 10:26:26 --> Output Class Initialized
INFO - 2024-07-01 10:26:26 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:26 --> Input Class Initialized
INFO - 2024-07-01 10:26:26 --> Language Class Initialized
INFO - 2024-07-01 10:26:26 --> Language Class Initialized
INFO - 2024-07-01 10:26:26 --> Config Class Initialized
INFO - 2024-07-01 10:26:26 --> Loader Class Initialized
INFO - 2024-07-01 10:26:26 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:26 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:26 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:26 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:26 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:26 --> Controller Class Initialized
INFO - 2024-07-01 10:26:26 --> Helper loaded: cookie_helper
INFO - 2024-07-01 10:26:26 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:26 --> Total execution time: 0.0336
INFO - 2024-07-01 10:26:26 --> Config Class Initialized
INFO - 2024-07-01 10:26:26 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:26 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:26 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:26 --> URI Class Initialized
INFO - 2024-07-01 10:26:26 --> Router Class Initialized
INFO - 2024-07-01 10:26:26 --> Output Class Initialized
INFO - 2024-07-01 10:26:26 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:26 --> Input Class Initialized
INFO - 2024-07-01 10:26:26 --> Language Class Initialized
INFO - 2024-07-01 10:26:26 --> Language Class Initialized
INFO - 2024-07-01 10:26:26 --> Config Class Initialized
INFO - 2024-07-01 10:26:26 --> Loader Class Initialized
INFO - 2024-07-01 10:26:26 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:26 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:26 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:26 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:26 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:26 --> Controller Class Initialized
DEBUG - 2024-07-01 10:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-07-01 10:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:26:26 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:26 --> Total execution time: 0.0317
INFO - 2024-07-01 10:26:27 --> Config Class Initialized
INFO - 2024-07-01 10:26:27 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:27 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:27 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:27 --> URI Class Initialized
INFO - 2024-07-01 10:26:27 --> Router Class Initialized
INFO - 2024-07-01 10:26:27 --> Output Class Initialized
INFO - 2024-07-01 10:26:27 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:27 --> Input Class Initialized
INFO - 2024-07-01 10:26:27 --> Language Class Initialized
INFO - 2024-07-01 10:26:27 --> Language Class Initialized
INFO - 2024-07-01 10:26:27 --> Config Class Initialized
INFO - 2024-07-01 10:26:27 --> Loader Class Initialized
INFO - 2024-07-01 10:26:27 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:27 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:27 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:27 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:27 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:27 --> Controller Class Initialized
DEBUG - 2024-07-01 10:26:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-07-01 10:26:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:26:27 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:27 --> Total execution time: 0.0434
INFO - 2024-07-01 10:26:29 --> Config Class Initialized
INFO - 2024-07-01 10:26:29 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:29 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:29 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:29 --> URI Class Initialized
INFO - 2024-07-01 10:26:29 --> Router Class Initialized
INFO - 2024-07-01 10:26:29 --> Output Class Initialized
INFO - 2024-07-01 10:26:29 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:29 --> Input Class Initialized
INFO - 2024-07-01 10:26:29 --> Language Class Initialized
INFO - 2024-07-01 10:26:29 --> Language Class Initialized
INFO - 2024-07-01 10:26:29 --> Config Class Initialized
INFO - 2024-07-01 10:26:29 --> Loader Class Initialized
INFO - 2024-07-01 10:26:29 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:29 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:29 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:29 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:29 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:29 --> Controller Class Initialized
DEBUG - 2024-07-01 10:26:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-07-01 10:26:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:26:29 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:29 --> Total execution time: 0.0383
INFO - 2024-07-01 10:26:32 --> Config Class Initialized
INFO - 2024-07-01 10:26:32 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:32 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:32 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:32 --> URI Class Initialized
INFO - 2024-07-01 10:26:32 --> Router Class Initialized
INFO - 2024-07-01 10:26:32 --> Output Class Initialized
INFO - 2024-07-01 10:26:32 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:32 --> Input Class Initialized
INFO - 2024-07-01 10:26:32 --> Language Class Initialized
INFO - 2024-07-01 10:26:32 --> Language Class Initialized
INFO - 2024-07-01 10:26:32 --> Config Class Initialized
INFO - 2024-07-01 10:26:32 --> Loader Class Initialized
INFO - 2024-07-01 10:26:32 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:32 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:32 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:32 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:32 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:32 --> Controller Class Initialized
DEBUG - 2024-07-01 10:26:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-07-01 10:26:34 --> Config Class Initialized
INFO - 2024-07-01 10:26:34 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:34 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:34 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:34 --> URI Class Initialized
INFO - 2024-07-01 10:26:34 --> Router Class Initialized
INFO - 2024-07-01 10:26:34 --> Output Class Initialized
INFO - 2024-07-01 10:26:34 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:34 --> Input Class Initialized
INFO - 2024-07-01 10:26:34 --> Language Class Initialized
INFO - 2024-07-01 10:26:34 --> Language Class Initialized
INFO - 2024-07-01 10:26:34 --> Config Class Initialized
INFO - 2024-07-01 10:26:34 --> Loader Class Initialized
INFO - 2024-07-01 10:26:34 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:34 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:34 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:34 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:34 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:34 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:34 --> Total execution time: 1.9491
INFO - 2024-07-01 10:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:34 --> Controller Class Initialized
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-01 10:26:34 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-07-01 10:26:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-07-01 10:26:35 --> Config Class Initialized
INFO - 2024-07-01 10:26:35 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:35 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:35 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:35 --> URI Class Initialized
INFO - 2024-07-01 10:26:35 --> Router Class Initialized
INFO - 2024-07-01 10:26:35 --> Output Class Initialized
INFO - 2024-07-01 10:26:35 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:35 --> Input Class Initialized
INFO - 2024-07-01 10:26:35 --> Language Class Initialized
INFO - 2024-07-01 10:26:36 --> Language Class Initialized
INFO - 2024-07-01 10:26:36 --> Config Class Initialized
INFO - 2024-07-01 10:26:36 --> Loader Class Initialized
INFO - 2024-07-01 10:26:36 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:36 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:36 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:36 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:36 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:37 --> Config Class Initialized
INFO - 2024-07-01 10:26:37 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:26:37 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:26:37 --> Utf8 Class Initialized
INFO - 2024-07-01 10:26:37 --> URI Class Initialized
INFO - 2024-07-01 10:26:37 --> Router Class Initialized
INFO - 2024-07-01 10:26:37 --> Output Class Initialized
INFO - 2024-07-01 10:26:37 --> Security Class Initialized
DEBUG - 2024-07-01 10:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:26:37 --> Input Class Initialized
INFO - 2024-07-01 10:26:37 --> Language Class Initialized
INFO - 2024-07-01 10:26:37 --> Language Class Initialized
INFO - 2024-07-01 10:26:37 --> Config Class Initialized
INFO - 2024-07-01 10:26:37 --> Loader Class Initialized
INFO - 2024-07-01 10:26:37 --> Helper loaded: url_helper
INFO - 2024-07-01 10:26:37 --> Helper loaded: file_helper
INFO - 2024-07-01 10:26:37 --> Helper loaded: form_helper
INFO - 2024-07-01 10:26:37 --> Helper loaded: my_helper
INFO - 2024-07-01 10:26:37 --> Database Driver Class Initialized
INFO - 2024-07-01 10:26:39 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:39 --> Total execution time: 5.5264
INFO - 2024-07-01 10:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:39 --> Controller Class Initialized
ERROR - 2024-07-01 10:26:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-07-01 10:26:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-07-01 10:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-07-01 10:26:44 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:44 --> Total execution time: 8.1651
INFO - 2024-07-01 10:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:26:44 --> Controller Class Initialized
DEBUG - 2024-07-01 10:26:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-01 10:26:47 --> Final output sent to browser
DEBUG - 2024-07-01 10:26:47 --> Total execution time: 10.5456
INFO - 2024-07-01 10:28:14 --> Config Class Initialized
INFO - 2024-07-01 10:28:14 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:28:14 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:28:14 --> Utf8 Class Initialized
INFO - 2024-07-01 10:28:14 --> URI Class Initialized
INFO - 2024-07-01 10:28:14 --> Router Class Initialized
INFO - 2024-07-01 10:28:14 --> Output Class Initialized
INFO - 2024-07-01 10:28:14 --> Security Class Initialized
DEBUG - 2024-07-01 10:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:28:14 --> Input Class Initialized
INFO - 2024-07-01 10:28:14 --> Language Class Initialized
INFO - 2024-07-01 10:28:14 --> Language Class Initialized
INFO - 2024-07-01 10:28:14 --> Config Class Initialized
INFO - 2024-07-01 10:28:14 --> Loader Class Initialized
INFO - 2024-07-01 10:28:14 --> Helper loaded: url_helper
INFO - 2024-07-01 10:28:14 --> Helper loaded: file_helper
INFO - 2024-07-01 10:28:14 --> Helper loaded: form_helper
INFO - 2024-07-01 10:28:14 --> Helper loaded: my_helper
INFO - 2024-07-01 10:28:14 --> Database Driver Class Initialized
INFO - 2024-07-01 10:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:28:14 --> Controller Class Initialized
DEBUG - 2024-07-01 10:28:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-07-01 10:28:18 --> Final output sent to browser
DEBUG - 2024-07-01 10:28:18 --> Total execution time: 4.0010
INFO - 2024-07-01 10:29:25 --> Config Class Initialized
INFO - 2024-07-01 10:29:25 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:29:25 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:29:25 --> Utf8 Class Initialized
INFO - 2024-07-01 10:29:25 --> URI Class Initialized
INFO - 2024-07-01 10:29:25 --> Router Class Initialized
INFO - 2024-07-01 10:29:25 --> Output Class Initialized
INFO - 2024-07-01 10:29:25 --> Security Class Initialized
DEBUG - 2024-07-01 10:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:29:25 --> Input Class Initialized
INFO - 2024-07-01 10:29:25 --> Language Class Initialized
INFO - 2024-07-01 10:29:25 --> Language Class Initialized
INFO - 2024-07-01 10:29:25 --> Config Class Initialized
INFO - 2024-07-01 10:29:25 --> Loader Class Initialized
INFO - 2024-07-01 10:29:25 --> Helper loaded: url_helper
INFO - 2024-07-01 10:29:25 --> Helper loaded: file_helper
INFO - 2024-07-01 10:29:25 --> Helper loaded: form_helper
INFO - 2024-07-01 10:29:25 --> Helper loaded: my_helper
INFO - 2024-07-01 10:29:25 --> Database Driver Class Initialized
INFO - 2024-07-01 10:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:29:25 --> Controller Class Initialized
DEBUG - 2024-07-01 10:29:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-01 10:29:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:29:25 --> Final output sent to browser
DEBUG - 2024-07-01 10:29:25 --> Total execution time: 0.1424
INFO - 2024-07-01 10:29:27 --> Config Class Initialized
INFO - 2024-07-01 10:29:27 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:29:27 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:29:27 --> Utf8 Class Initialized
INFO - 2024-07-01 10:29:27 --> URI Class Initialized
INFO - 2024-07-01 10:29:27 --> Router Class Initialized
INFO - 2024-07-01 10:29:27 --> Output Class Initialized
INFO - 2024-07-01 10:29:27 --> Security Class Initialized
DEBUG - 2024-07-01 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:29:27 --> Input Class Initialized
INFO - 2024-07-01 10:29:27 --> Language Class Initialized
INFO - 2024-07-01 10:29:27 --> Language Class Initialized
INFO - 2024-07-01 10:29:27 --> Config Class Initialized
INFO - 2024-07-01 10:29:27 --> Loader Class Initialized
INFO - 2024-07-01 10:29:27 --> Helper loaded: url_helper
INFO - 2024-07-01 10:29:27 --> Helper loaded: file_helper
INFO - 2024-07-01 10:29:27 --> Helper loaded: form_helper
INFO - 2024-07-01 10:29:27 --> Helper loaded: my_helper
INFO - 2024-07-01 10:29:27 --> Database Driver Class Initialized
INFO - 2024-07-01 10:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:29:27 --> Controller Class Initialized
INFO - 2024-07-01 10:29:27 --> Helper loaded: cookie_helper
INFO - 2024-07-01 10:29:27 --> Final output sent to browser
DEBUG - 2024-07-01 10:29:27 --> Total execution time: 0.0323
INFO - 2024-07-01 10:29:27 --> Config Class Initialized
INFO - 2024-07-01 10:29:27 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:29:27 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:29:27 --> Utf8 Class Initialized
INFO - 2024-07-01 10:29:27 --> URI Class Initialized
INFO - 2024-07-01 10:29:28 --> Router Class Initialized
INFO - 2024-07-01 10:29:28 --> Output Class Initialized
INFO - 2024-07-01 10:29:28 --> Security Class Initialized
DEBUG - 2024-07-01 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:29:28 --> Input Class Initialized
INFO - 2024-07-01 10:29:28 --> Language Class Initialized
INFO - 2024-07-01 10:29:28 --> Language Class Initialized
INFO - 2024-07-01 10:29:28 --> Config Class Initialized
INFO - 2024-07-01 10:29:28 --> Loader Class Initialized
INFO - 2024-07-01 10:29:28 --> Helper loaded: url_helper
INFO - 2024-07-01 10:29:28 --> Helper loaded: file_helper
INFO - 2024-07-01 10:29:28 --> Helper loaded: form_helper
INFO - 2024-07-01 10:29:28 --> Helper loaded: my_helper
INFO - 2024-07-01 10:29:28 --> Database Driver Class Initialized
INFO - 2024-07-01 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:29:28 --> Controller Class Initialized
DEBUG - 2024-07-01 10:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-07-01 10:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:29:28 --> Final output sent to browser
DEBUG - 2024-07-01 10:29:28 --> Total execution time: 0.0286
INFO - 2024-07-01 10:29:34 --> Config Class Initialized
INFO - 2024-07-01 10:29:34 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:29:34 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:29:34 --> Utf8 Class Initialized
INFO - 2024-07-01 10:29:34 --> URI Class Initialized
INFO - 2024-07-01 10:29:34 --> Router Class Initialized
INFO - 2024-07-01 10:29:34 --> Output Class Initialized
INFO - 2024-07-01 10:29:34 --> Security Class Initialized
DEBUG - 2024-07-01 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:29:34 --> Input Class Initialized
INFO - 2024-07-01 10:29:34 --> Language Class Initialized
INFO - 2024-07-01 10:29:35 --> Language Class Initialized
INFO - 2024-07-01 10:29:35 --> Config Class Initialized
INFO - 2024-07-01 10:29:35 --> Loader Class Initialized
INFO - 2024-07-01 10:29:35 --> Helper loaded: url_helper
INFO - 2024-07-01 10:29:35 --> Helper loaded: file_helper
INFO - 2024-07-01 10:29:35 --> Helper loaded: form_helper
INFO - 2024-07-01 10:29:35 --> Helper loaded: my_helper
INFO - 2024-07-01 10:29:35 --> Database Driver Class Initialized
INFO - 2024-07-01 10:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:29:35 --> Controller Class Initialized
DEBUG - 2024-07-01 10:29:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-07-01 10:29:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 10:29:35 --> Final output sent to browser
DEBUG - 2024-07-01 10:29:35 --> Total execution time: 0.0356
INFO - 2024-07-01 10:29:37 --> Config Class Initialized
INFO - 2024-07-01 10:29:37 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:29:37 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:29:37 --> Utf8 Class Initialized
INFO - 2024-07-01 10:29:37 --> URI Class Initialized
INFO - 2024-07-01 10:29:37 --> Router Class Initialized
INFO - 2024-07-01 10:29:37 --> Output Class Initialized
INFO - 2024-07-01 10:29:37 --> Security Class Initialized
DEBUG - 2024-07-01 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:29:37 --> Input Class Initialized
INFO - 2024-07-01 10:29:37 --> Language Class Initialized
INFO - 2024-07-01 10:29:37 --> Language Class Initialized
INFO - 2024-07-01 10:29:37 --> Config Class Initialized
INFO - 2024-07-01 10:29:37 --> Loader Class Initialized
INFO - 2024-07-01 10:29:37 --> Helper loaded: url_helper
INFO - 2024-07-01 10:29:37 --> Helper loaded: file_helper
INFO - 2024-07-01 10:29:37 --> Helper loaded: form_helper
INFO - 2024-07-01 10:29:37 --> Helper loaded: my_helper
INFO - 2024-07-01 10:29:37 --> Database Driver Class Initialized
INFO - 2024-07-01 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:29:37 --> Controller Class Initialized
DEBUG - 2024-07-01 10:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-07-01 10:29:41 --> Final output sent to browser
DEBUG - 2024-07-01 10:29:41 --> Total execution time: 4.0939
INFO - 2024-07-01 10:31:21 --> Config Class Initialized
INFO - 2024-07-01 10:31:21 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:31:21 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:31:21 --> Utf8 Class Initialized
INFO - 2024-07-01 10:31:21 --> URI Class Initialized
INFO - 2024-07-01 10:31:21 --> Router Class Initialized
INFO - 2024-07-01 10:31:21 --> Output Class Initialized
INFO - 2024-07-01 10:31:21 --> Security Class Initialized
DEBUG - 2024-07-01 10:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:31:21 --> Input Class Initialized
INFO - 2024-07-01 10:31:21 --> Language Class Initialized
INFO - 2024-07-01 10:31:21 --> Language Class Initialized
INFO - 2024-07-01 10:31:21 --> Config Class Initialized
INFO - 2024-07-01 10:31:21 --> Loader Class Initialized
INFO - 2024-07-01 10:31:21 --> Helper loaded: url_helper
INFO - 2024-07-01 10:31:21 --> Helper loaded: file_helper
INFO - 2024-07-01 10:31:21 --> Helper loaded: form_helper
INFO - 2024-07-01 10:31:21 --> Helper loaded: my_helper
INFO - 2024-07-01 10:31:21 --> Database Driver Class Initialized
INFO - 2024-07-01 10:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:31:21 --> Controller Class Initialized
DEBUG - 2024-07-01 10:31:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-07-01 10:31:26 --> Final output sent to browser
DEBUG - 2024-07-01 10:31:26 --> Total execution time: 4.5627
INFO - 2024-07-01 10:31:51 --> Config Class Initialized
INFO - 2024-07-01 10:31:51 --> Hooks Class Initialized
DEBUG - 2024-07-01 10:31:51 --> UTF-8 Support Enabled
INFO - 2024-07-01 10:31:51 --> Utf8 Class Initialized
INFO - 2024-07-01 10:31:51 --> URI Class Initialized
INFO - 2024-07-01 10:31:51 --> Router Class Initialized
INFO - 2024-07-01 10:31:51 --> Output Class Initialized
INFO - 2024-07-01 10:31:51 --> Security Class Initialized
DEBUG - 2024-07-01 10:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 10:31:51 --> Input Class Initialized
INFO - 2024-07-01 10:31:51 --> Language Class Initialized
INFO - 2024-07-01 10:31:51 --> Language Class Initialized
INFO - 2024-07-01 10:31:51 --> Config Class Initialized
INFO - 2024-07-01 10:31:51 --> Loader Class Initialized
INFO - 2024-07-01 10:31:51 --> Helper loaded: url_helper
INFO - 2024-07-01 10:31:51 --> Helper loaded: file_helper
INFO - 2024-07-01 10:31:51 --> Helper loaded: form_helper
INFO - 2024-07-01 10:31:51 --> Helper loaded: my_helper
INFO - 2024-07-01 10:31:51 --> Database Driver Class Initialized
INFO - 2024-07-01 10:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 10:31:51 --> Controller Class Initialized
DEBUG - 2024-07-01 10:31:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-07-01 10:31:56 --> Final output sent to browser
DEBUG - 2024-07-01 10:31:56 --> Total execution time: 4.5887
INFO - 2024-07-01 14:04:27 --> Config Class Initialized
INFO - 2024-07-01 14:04:27 --> Hooks Class Initialized
DEBUG - 2024-07-01 14:04:27 --> UTF-8 Support Enabled
INFO - 2024-07-01 14:04:27 --> Utf8 Class Initialized
INFO - 2024-07-01 14:04:27 --> URI Class Initialized
INFO - 2024-07-01 14:04:27 --> Router Class Initialized
INFO - 2024-07-01 14:04:27 --> Output Class Initialized
INFO - 2024-07-01 14:04:27 --> Security Class Initialized
DEBUG - 2024-07-01 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-01 14:04:27 --> Input Class Initialized
INFO - 2024-07-01 14:04:27 --> Language Class Initialized
INFO - 2024-07-01 14:04:27 --> Language Class Initialized
INFO - 2024-07-01 14:04:27 --> Config Class Initialized
INFO - 2024-07-01 14:04:27 --> Loader Class Initialized
INFO - 2024-07-01 14:04:27 --> Helper loaded: url_helper
INFO - 2024-07-01 14:04:27 --> Helper loaded: file_helper
INFO - 2024-07-01 14:04:27 --> Helper loaded: form_helper
INFO - 2024-07-01 14:04:27 --> Helper loaded: my_helper
INFO - 2024-07-01 14:04:27 --> Database Driver Class Initialized
INFO - 2024-07-01 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-01 14:04:27 --> Controller Class Initialized
DEBUG - 2024-07-01 14:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-01 14:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-01 14:04:27 --> Final output sent to browser
DEBUG - 2024-07-01 14:04:27 --> Total execution time: 0.0562
