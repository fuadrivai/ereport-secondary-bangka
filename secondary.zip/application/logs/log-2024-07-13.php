<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-13 11:10:56 --> Config Class Initialized
INFO - 2024-07-13 11:10:56 --> Hooks Class Initialized
DEBUG - 2024-07-13 11:10:56 --> UTF-8 Support Enabled
INFO - 2024-07-13 11:10:56 --> Utf8 Class Initialized
INFO - 2024-07-13 11:10:56 --> URI Class Initialized
INFO - 2024-07-13 11:10:56 --> Router Class Initialized
INFO - 2024-07-13 11:10:56 --> Output Class Initialized
INFO - 2024-07-13 11:10:56 --> Security Class Initialized
DEBUG - 2024-07-13 11:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 11:10:56 --> Input Class Initialized
INFO - 2024-07-13 11:10:56 --> Language Class Initialized
INFO - 2024-07-13 11:10:56 --> Language Class Initialized
INFO - 2024-07-13 11:10:56 --> Config Class Initialized
INFO - 2024-07-13 11:10:56 --> Loader Class Initialized
INFO - 2024-07-13 11:10:56 --> Helper loaded: url_helper
INFO - 2024-07-13 11:10:56 --> Helper loaded: file_helper
INFO - 2024-07-13 11:10:56 --> Helper loaded: form_helper
INFO - 2024-07-13 11:10:56 --> Helper loaded: my_helper
INFO - 2024-07-13 11:10:56 --> Database Driver Class Initialized
INFO - 2024-07-13 11:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 11:10:56 --> Controller Class Initialized
DEBUG - 2024-07-13 11:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-13 11:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-13 11:10:56 --> Final output sent to browser
DEBUG - 2024-07-13 11:10:56 --> Total execution time: 0.0752
INFO - 2024-07-13 11:11:00 --> Config Class Initialized
INFO - 2024-07-13 11:11:00 --> Hooks Class Initialized
DEBUG - 2024-07-13 11:11:00 --> UTF-8 Support Enabled
INFO - 2024-07-13 11:11:00 --> Utf8 Class Initialized
INFO - 2024-07-13 11:11:00 --> URI Class Initialized
INFO - 2024-07-13 11:11:00 --> Router Class Initialized
INFO - 2024-07-13 11:11:00 --> Output Class Initialized
INFO - 2024-07-13 11:11:00 --> Security Class Initialized
DEBUG - 2024-07-13 11:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 11:11:00 --> Input Class Initialized
INFO - 2024-07-13 11:11:00 --> Language Class Initialized
INFO - 2024-07-13 11:11:00 --> Language Class Initialized
INFO - 2024-07-13 11:11:00 --> Config Class Initialized
INFO - 2024-07-13 11:11:00 --> Loader Class Initialized
INFO - 2024-07-13 11:11:00 --> Helper loaded: url_helper
INFO - 2024-07-13 11:11:00 --> Helper loaded: file_helper
INFO - 2024-07-13 11:11:00 --> Helper loaded: form_helper
INFO - 2024-07-13 11:11:00 --> Helper loaded: my_helper
INFO - 2024-07-13 11:11:00 --> Database Driver Class Initialized
INFO - 2024-07-13 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 11:11:00 --> Controller Class Initialized
INFO - 2024-07-13 11:11:00 --> Database Driver Class Initialized
INFO - 2024-07-13 11:11:00 --> Config Class Initialized
INFO - 2024-07-13 11:11:00 --> Hooks Class Initialized
DEBUG - 2024-07-13 11:11:00 --> UTF-8 Support Enabled
INFO - 2024-07-13 11:11:00 --> Utf8 Class Initialized
INFO - 2024-07-13 11:11:00 --> URI Class Initialized
INFO - 2024-07-13 11:11:00 --> Router Class Initialized
INFO - 2024-07-13 11:11:00 --> Output Class Initialized
INFO - 2024-07-13 11:11:00 --> Security Class Initialized
DEBUG - 2024-07-13 11:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 11:11:00 --> Input Class Initialized
INFO - 2024-07-13 11:11:00 --> Language Class Initialized
INFO - 2024-07-13 11:11:00 --> Language Class Initialized
INFO - 2024-07-13 11:11:00 --> Config Class Initialized
INFO - 2024-07-13 11:11:00 --> Loader Class Initialized
INFO - 2024-07-13 11:11:00 --> Helper loaded: url_helper
INFO - 2024-07-13 11:11:00 --> Helper loaded: file_helper
INFO - 2024-07-13 11:11:00 --> Helper loaded: form_helper
INFO - 2024-07-13 11:11:00 --> Helper loaded: my_helper
INFO - 2024-07-13 11:11:00 --> Database Driver Class Initialized
INFO - 2024-07-13 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 11:11:00 --> Controller Class Initialized
DEBUG - 2024-07-13 11:11:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-13 11:11:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-13 11:11:00 --> Final output sent to browser
DEBUG - 2024-07-13 11:11:00 --> Total execution time: 0.0440
INFO - 2024-07-13 13:55:23 --> Config Class Initialized
INFO - 2024-07-13 13:55:23 --> Hooks Class Initialized
DEBUG - 2024-07-13 13:55:23 --> UTF-8 Support Enabled
INFO - 2024-07-13 13:55:23 --> Utf8 Class Initialized
INFO - 2024-07-13 13:55:23 --> URI Class Initialized
INFO - 2024-07-13 13:55:23 --> Router Class Initialized
INFO - 2024-07-13 13:55:23 --> Output Class Initialized
INFO - 2024-07-13 13:55:23 --> Security Class Initialized
DEBUG - 2024-07-13 13:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 13:55:23 --> Input Class Initialized
INFO - 2024-07-13 13:55:23 --> Language Class Initialized
INFO - 2024-07-13 13:55:23 --> Language Class Initialized
INFO - 2024-07-13 13:55:23 --> Config Class Initialized
INFO - 2024-07-13 13:55:23 --> Loader Class Initialized
INFO - 2024-07-13 13:55:23 --> Helper loaded: url_helper
INFO - 2024-07-13 13:55:23 --> Helper loaded: file_helper
INFO - 2024-07-13 13:55:23 --> Helper loaded: form_helper
INFO - 2024-07-13 13:55:23 --> Helper loaded: my_helper
INFO - 2024-07-13 13:55:23 --> Database Driver Class Initialized
INFO - 2024-07-13 13:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 13:55:23 --> Controller Class Initialized
DEBUG - 2024-07-13 13:55:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-13 13:55:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-13 13:55:23 --> Final output sent to browser
DEBUG - 2024-07-13 13:55:23 --> Total execution time: 0.0533
INFO - 2024-07-13 21:52:23 --> Config Class Initialized
INFO - 2024-07-13 21:52:23 --> Hooks Class Initialized
DEBUG - 2024-07-13 21:52:23 --> UTF-8 Support Enabled
INFO - 2024-07-13 21:52:23 --> Utf8 Class Initialized
INFO - 2024-07-13 21:52:23 --> URI Class Initialized
INFO - 2024-07-13 21:52:23 --> Router Class Initialized
INFO - 2024-07-13 21:52:23 --> Output Class Initialized
INFO - 2024-07-13 21:52:23 --> Security Class Initialized
DEBUG - 2024-07-13 21:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-13 21:52:23 --> Input Class Initialized
INFO - 2024-07-13 21:52:23 --> Language Class Initialized
INFO - 2024-07-13 21:52:23 --> Language Class Initialized
INFO - 2024-07-13 21:52:23 --> Config Class Initialized
INFO - 2024-07-13 21:52:23 --> Loader Class Initialized
INFO - 2024-07-13 21:52:23 --> Helper loaded: url_helper
INFO - 2024-07-13 21:52:23 --> Helper loaded: file_helper
INFO - 2024-07-13 21:52:23 --> Helper loaded: form_helper
INFO - 2024-07-13 21:52:23 --> Helper loaded: my_helper
INFO - 2024-07-13 21:52:23 --> Database Driver Class Initialized
INFO - 2024-07-13 21:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-13 21:52:24 --> Controller Class Initialized
INFO - 2024-07-13 21:52:24 --> Helper loaded: cookie_helper
INFO - 2024-07-13 21:52:24 --> Final output sent to browser
DEBUG - 2024-07-13 21:52:24 --> Total execution time: 0.1008
