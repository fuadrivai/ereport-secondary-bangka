<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-15 16:05:05 --> Config Class Initialized
INFO - 2024-01-15 16:05:05 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:05:05 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:05:05 --> Utf8 Class Initialized
INFO - 2024-01-15 16:05:05 --> URI Class Initialized
INFO - 2024-01-15 16:05:05 --> Router Class Initialized
INFO - 2024-01-15 16:05:05 --> Output Class Initialized
INFO - 2024-01-15 16:05:05 --> Security Class Initialized
DEBUG - 2024-01-15 16:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:05:05 --> Input Class Initialized
INFO - 2024-01-15 16:05:05 --> Language Class Initialized
INFO - 2024-01-15 16:05:05 --> Language Class Initialized
INFO - 2024-01-15 16:05:05 --> Config Class Initialized
INFO - 2024-01-15 16:05:05 --> Loader Class Initialized
INFO - 2024-01-15 16:05:05 --> Helper loaded: url_helper
INFO - 2024-01-15 16:05:05 --> Helper loaded: file_helper
INFO - 2024-01-15 16:05:05 --> Helper loaded: form_helper
INFO - 2024-01-15 16:05:05 --> Helper loaded: my_helper
INFO - 2024-01-15 16:05:05 --> Database Driver Class Initialized
INFO - 2024-01-15 16:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:05:05 --> Controller Class Initialized
DEBUG - 2024-01-15 16:05:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:05:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:05:05 --> Final output sent to browser
DEBUG - 2024-01-15 16:05:05 --> Total execution time: 0.7079
INFO - 2024-01-15 16:05:50 --> Config Class Initialized
INFO - 2024-01-15 16:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:05:50 --> Utf8 Class Initialized
INFO - 2024-01-15 16:05:50 --> URI Class Initialized
INFO - 2024-01-15 16:05:50 --> Router Class Initialized
INFO - 2024-01-15 16:05:50 --> Output Class Initialized
INFO - 2024-01-15 16:05:50 --> Security Class Initialized
DEBUG - 2024-01-15 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:05:50 --> Input Class Initialized
INFO - 2024-01-15 16:05:50 --> Language Class Initialized
INFO - 2024-01-15 16:05:50 --> Language Class Initialized
INFO - 2024-01-15 16:05:50 --> Config Class Initialized
INFO - 2024-01-15 16:05:50 --> Loader Class Initialized
INFO - 2024-01-15 16:05:50 --> Helper loaded: url_helper
INFO - 2024-01-15 16:05:50 --> Helper loaded: file_helper
INFO - 2024-01-15 16:05:50 --> Helper loaded: form_helper
INFO - 2024-01-15 16:05:50 --> Helper loaded: my_helper
INFO - 2024-01-15 16:05:50 --> Database Driver Class Initialized
INFO - 2024-01-15 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:05:50 --> Controller Class Initialized
INFO - 2024-01-15 16:05:50 --> Helper loaded: cookie_helper
INFO - 2024-01-15 16:05:50 --> Final output sent to browser
DEBUG - 2024-01-15 16:05:50 --> Total execution time: 0.0486
INFO - 2024-01-15 16:05:50 --> Config Class Initialized
INFO - 2024-01-15 16:05:50 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:05:50 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:05:50 --> Utf8 Class Initialized
INFO - 2024-01-15 16:05:50 --> URI Class Initialized
INFO - 2024-01-15 16:05:50 --> Router Class Initialized
INFO - 2024-01-15 16:05:50 --> Output Class Initialized
INFO - 2024-01-15 16:05:50 --> Security Class Initialized
DEBUG - 2024-01-15 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:05:50 --> Input Class Initialized
INFO - 2024-01-15 16:05:50 --> Language Class Initialized
INFO - 2024-01-15 16:05:50 --> Language Class Initialized
INFO - 2024-01-15 16:05:50 --> Config Class Initialized
INFO - 2024-01-15 16:05:50 --> Loader Class Initialized
INFO - 2024-01-15 16:05:50 --> Helper loaded: url_helper
INFO - 2024-01-15 16:05:50 --> Helper loaded: file_helper
INFO - 2024-01-15 16:05:50 --> Helper loaded: form_helper
INFO - 2024-01-15 16:05:50 --> Helper loaded: my_helper
INFO - 2024-01-15 16:05:50 --> Database Driver Class Initialized
INFO - 2024-01-15 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:05:50 --> Controller Class Initialized
DEBUG - 2024-01-15 16:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-15 16:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:05:50 --> Final output sent to browser
DEBUG - 2024-01-15 16:05:50 --> Total execution time: 0.0501
INFO - 2024-01-15 16:16:48 --> Config Class Initialized
INFO - 2024-01-15 16:16:48 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:16:49 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:16:49 --> Utf8 Class Initialized
INFO - 2024-01-15 16:16:49 --> URI Class Initialized
INFO - 2024-01-15 16:16:49 --> Router Class Initialized
INFO - 2024-01-15 16:16:49 --> Output Class Initialized
INFO - 2024-01-15 16:16:49 --> Security Class Initialized
DEBUG - 2024-01-15 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:16:49 --> Input Class Initialized
INFO - 2024-01-15 16:16:49 --> Language Class Initialized
INFO - 2024-01-15 16:16:49 --> Language Class Initialized
INFO - 2024-01-15 16:16:49 --> Config Class Initialized
INFO - 2024-01-15 16:16:49 --> Loader Class Initialized
INFO - 2024-01-15 16:16:49 --> Helper loaded: url_helper
INFO - 2024-01-15 16:16:49 --> Helper loaded: file_helper
INFO - 2024-01-15 16:16:49 --> Helper loaded: form_helper
INFO - 2024-01-15 16:16:49 --> Helper loaded: my_helper
INFO - 2024-01-15 16:16:49 --> Database Driver Class Initialized
INFO - 2024-01-15 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:16:49 --> Controller Class Initialized
DEBUG - 2024-01-15 16:16:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-15 16:16:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:16:49 --> Final output sent to browser
DEBUG - 2024-01-15 16:16:49 --> Total execution time: 0.4978
INFO - 2024-01-15 16:16:53 --> Config Class Initialized
INFO - 2024-01-15 16:16:53 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:16:53 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:16:53 --> Utf8 Class Initialized
INFO - 2024-01-15 16:16:53 --> URI Class Initialized
INFO - 2024-01-15 16:16:54 --> Router Class Initialized
INFO - 2024-01-15 16:16:54 --> Output Class Initialized
INFO - 2024-01-15 16:16:54 --> Security Class Initialized
DEBUG - 2024-01-15 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:16:54 --> Input Class Initialized
INFO - 2024-01-15 16:16:54 --> Language Class Initialized
INFO - 2024-01-15 16:16:54 --> Language Class Initialized
INFO - 2024-01-15 16:16:54 --> Config Class Initialized
INFO - 2024-01-15 16:16:54 --> Loader Class Initialized
INFO - 2024-01-15 16:16:54 --> Helper loaded: url_helper
INFO - 2024-01-15 16:16:54 --> Helper loaded: file_helper
INFO - 2024-01-15 16:16:54 --> Helper loaded: form_helper
INFO - 2024-01-15 16:16:54 --> Helper loaded: my_helper
INFO - 2024-01-15 16:16:54 --> Database Driver Class Initialized
INFO - 2024-01-15 16:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:16:54 --> Controller Class Initialized
DEBUG - 2024-01-15 16:16:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-15 16:16:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:16:54 --> Final output sent to browser
DEBUG - 2024-01-15 16:16:54 --> Total execution time: 0.5690
INFO - 2024-01-15 16:16:54 --> Config Class Initialized
INFO - 2024-01-15 16:16:54 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:16:54 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:16:54 --> Utf8 Class Initialized
INFO - 2024-01-15 16:16:54 --> URI Class Initialized
INFO - 2024-01-15 16:16:54 --> Router Class Initialized
INFO - 2024-01-15 16:16:54 --> Output Class Initialized
INFO - 2024-01-15 16:16:54 --> Security Class Initialized
DEBUG - 2024-01-15 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:16:54 --> Input Class Initialized
INFO - 2024-01-15 16:16:54 --> Language Class Initialized
INFO - 2024-01-15 16:16:54 --> Language Class Initialized
INFO - 2024-01-15 16:16:54 --> Config Class Initialized
INFO - 2024-01-15 16:16:54 --> Loader Class Initialized
INFO - 2024-01-15 16:16:54 --> Helper loaded: url_helper
INFO - 2024-01-15 16:16:54 --> Helper loaded: file_helper
INFO - 2024-01-15 16:16:54 --> Helper loaded: form_helper
INFO - 2024-01-15 16:16:54 --> Helper loaded: my_helper
INFO - 2024-01-15 16:16:55 --> Database Driver Class Initialized
INFO - 2024-01-15 16:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:16:55 --> Controller Class Initialized
INFO - 2024-01-15 16:16:57 --> Config Class Initialized
INFO - 2024-01-15 16:16:57 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:16:57 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:16:57 --> Utf8 Class Initialized
INFO - 2024-01-15 16:16:57 --> URI Class Initialized
INFO - 2024-01-15 16:16:57 --> Router Class Initialized
INFO - 2024-01-15 16:16:57 --> Output Class Initialized
INFO - 2024-01-15 16:16:57 --> Security Class Initialized
DEBUG - 2024-01-15 16:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:16:57 --> Input Class Initialized
INFO - 2024-01-15 16:16:57 --> Language Class Initialized
INFO - 2024-01-15 16:16:57 --> Language Class Initialized
INFO - 2024-01-15 16:16:57 --> Config Class Initialized
INFO - 2024-01-15 16:16:57 --> Loader Class Initialized
INFO - 2024-01-15 16:16:57 --> Helper loaded: url_helper
INFO - 2024-01-15 16:16:57 --> Helper loaded: file_helper
INFO - 2024-01-15 16:16:57 --> Helper loaded: form_helper
INFO - 2024-01-15 16:16:57 --> Helper loaded: my_helper
INFO - 2024-01-15 16:16:57 --> Database Driver Class Initialized
INFO - 2024-01-15 16:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:16:57 --> Controller Class Initialized
INFO - 2024-01-15 16:17:13 --> Config Class Initialized
INFO - 2024-01-15 16:17:13 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:17:13 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:17:13 --> Utf8 Class Initialized
INFO - 2024-01-15 16:17:13 --> URI Class Initialized
INFO - 2024-01-15 16:17:13 --> Router Class Initialized
INFO - 2024-01-15 16:17:13 --> Output Class Initialized
INFO - 2024-01-15 16:17:13 --> Security Class Initialized
DEBUG - 2024-01-15 16:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:17:14 --> Input Class Initialized
INFO - 2024-01-15 16:17:14 --> Language Class Initialized
INFO - 2024-01-15 16:17:14 --> Language Class Initialized
INFO - 2024-01-15 16:17:14 --> Config Class Initialized
INFO - 2024-01-15 16:17:14 --> Loader Class Initialized
INFO - 2024-01-15 16:17:14 --> Helper loaded: url_helper
INFO - 2024-01-15 16:17:14 --> Helper loaded: file_helper
INFO - 2024-01-15 16:17:15 --> Helper loaded: form_helper
INFO - 2024-01-15 16:17:15 --> Helper loaded: my_helper
INFO - 2024-01-15 16:17:15 --> Database Driver Class Initialized
INFO - 2024-01-15 16:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:17:15 --> Controller Class Initialized
INFO - 2024-01-15 16:17:15 --> Helper loaded: cookie_helper
INFO - 2024-01-15 16:17:16 --> Config Class Initialized
INFO - 2024-01-15 16:17:16 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:17:16 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:17:16 --> Utf8 Class Initialized
INFO - 2024-01-15 16:17:16 --> URI Class Initialized
INFO - 2024-01-15 16:17:16 --> Router Class Initialized
INFO - 2024-01-15 16:17:16 --> Output Class Initialized
INFO - 2024-01-15 16:17:16 --> Security Class Initialized
DEBUG - 2024-01-15 16:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:17:16 --> Input Class Initialized
INFO - 2024-01-15 16:17:16 --> Language Class Initialized
INFO - 2024-01-15 16:17:17 --> Language Class Initialized
INFO - 2024-01-15 16:17:17 --> Config Class Initialized
INFO - 2024-01-15 16:17:17 --> Loader Class Initialized
INFO - 2024-01-15 16:17:17 --> Helper loaded: url_helper
INFO - 2024-01-15 16:17:17 --> Helper loaded: file_helper
INFO - 2024-01-15 16:17:17 --> Helper loaded: form_helper
INFO - 2024-01-15 16:17:17 --> Helper loaded: my_helper
INFO - 2024-01-15 16:17:17 --> Database Driver Class Initialized
INFO - 2024-01-15 16:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:17:18 --> Controller Class Initialized
INFO - 2024-01-15 16:17:18 --> Config Class Initialized
INFO - 2024-01-15 16:17:18 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:17:19 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:17:19 --> Utf8 Class Initialized
INFO - 2024-01-15 16:17:19 --> URI Class Initialized
INFO - 2024-01-15 16:17:19 --> Router Class Initialized
INFO - 2024-01-15 16:17:19 --> Output Class Initialized
INFO - 2024-01-15 16:17:19 --> Security Class Initialized
DEBUG - 2024-01-15 16:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:17:19 --> Input Class Initialized
INFO - 2024-01-15 16:17:19 --> Language Class Initialized
INFO - 2024-01-15 16:17:20 --> Language Class Initialized
INFO - 2024-01-15 16:17:20 --> Config Class Initialized
INFO - 2024-01-15 16:17:20 --> Loader Class Initialized
INFO - 2024-01-15 16:17:20 --> Helper loaded: url_helper
INFO - 2024-01-15 16:17:20 --> Helper loaded: file_helper
INFO - 2024-01-15 16:17:20 --> Helper loaded: form_helper
INFO - 2024-01-15 16:17:20 --> Helper loaded: my_helper
INFO - 2024-01-15 16:17:20 --> Database Driver Class Initialized
INFO - 2024-01-15 16:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:17:21 --> Controller Class Initialized
DEBUG - 2024-01-15 16:17:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:17:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:17:21 --> Final output sent to browser
DEBUG - 2024-01-15 16:17:21 --> Total execution time: 2.7745
INFO - 2024-01-15 16:19:41 --> Config Class Initialized
INFO - 2024-01-15 16:19:41 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:19:41 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:19:41 --> Utf8 Class Initialized
INFO - 2024-01-15 16:19:41 --> URI Class Initialized
INFO - 2024-01-15 16:19:42 --> Router Class Initialized
INFO - 2024-01-15 16:19:42 --> Output Class Initialized
INFO - 2024-01-15 16:19:42 --> Security Class Initialized
DEBUG - 2024-01-15 16:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:19:42 --> Input Class Initialized
INFO - 2024-01-15 16:19:42 --> Language Class Initialized
INFO - 2024-01-15 16:19:42 --> Language Class Initialized
INFO - 2024-01-15 16:19:42 --> Config Class Initialized
INFO - 2024-01-15 16:19:42 --> Loader Class Initialized
INFO - 2024-01-15 16:19:43 --> Helper loaded: url_helper
INFO - 2024-01-15 16:19:43 --> Helper loaded: file_helper
INFO - 2024-01-15 16:19:43 --> Helper loaded: form_helper
INFO - 2024-01-15 16:19:43 --> Helper loaded: my_helper
INFO - 2024-01-15 16:19:44 --> Database Driver Class Initialized
INFO - 2024-01-15 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:19:45 --> Controller Class Initialized
INFO - 2024-01-15 16:19:46 --> Final output sent to browser
DEBUG - 2024-01-15 16:19:46 --> Total execution time: 4.9957
INFO - 2024-01-15 16:21:29 --> Config Class Initialized
INFO - 2024-01-15 16:21:29 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:21:29 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:21:29 --> Utf8 Class Initialized
INFO - 2024-01-15 16:21:29 --> URI Class Initialized
INFO - 2024-01-15 16:21:29 --> Router Class Initialized
INFO - 2024-01-15 16:21:30 --> Output Class Initialized
INFO - 2024-01-15 16:21:30 --> Security Class Initialized
DEBUG - 2024-01-15 16:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:21:30 --> Input Class Initialized
INFO - 2024-01-15 16:21:30 --> Language Class Initialized
INFO - 2024-01-15 16:21:30 --> Language Class Initialized
INFO - 2024-01-15 16:21:30 --> Config Class Initialized
INFO - 2024-01-15 16:21:30 --> Loader Class Initialized
INFO - 2024-01-15 16:21:30 --> Helper loaded: url_helper
INFO - 2024-01-15 16:21:30 --> Helper loaded: file_helper
INFO - 2024-01-15 16:21:30 --> Helper loaded: form_helper
INFO - 2024-01-15 16:21:30 --> Helper loaded: my_helper
INFO - 2024-01-15 16:21:30 --> Database Driver Class Initialized
ERROR - 2024-01-15 16:21:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-01-15 16:21:31 --> Unable to connect to the database
INFO - 2024-01-15 16:21:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-01-15 16:21:48 --> Config Class Initialized
INFO - 2024-01-15 16:21:48 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:21:48 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:21:48 --> Utf8 Class Initialized
INFO - 2024-01-15 16:21:48 --> URI Class Initialized
INFO - 2024-01-15 16:21:48 --> Router Class Initialized
INFO - 2024-01-15 16:21:48 --> Output Class Initialized
INFO - 2024-01-15 16:21:48 --> Security Class Initialized
DEBUG - 2024-01-15 16:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:21:48 --> Input Class Initialized
INFO - 2024-01-15 16:21:48 --> Language Class Initialized
INFO - 2024-01-15 16:21:48 --> Language Class Initialized
INFO - 2024-01-15 16:21:48 --> Config Class Initialized
INFO - 2024-01-15 16:21:48 --> Loader Class Initialized
INFO - 2024-01-15 16:21:49 --> Helper loaded: url_helper
INFO - 2024-01-15 16:21:49 --> Helper loaded: file_helper
INFO - 2024-01-15 16:21:49 --> Helper loaded: form_helper
INFO - 2024-01-15 16:21:49 --> Helper loaded: my_helper
INFO - 2024-01-15 16:21:49 --> Database Driver Class Initialized
INFO - 2024-01-15 16:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:21:49 --> Controller Class Initialized
DEBUG - 2024-01-15 16:21:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:21:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:21:49 --> Final output sent to browser
DEBUG - 2024-01-15 16:21:49 --> Total execution time: 0.8620
INFO - 2024-01-15 16:21:58 --> Config Class Initialized
INFO - 2024-01-15 16:21:58 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:21:58 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:21:58 --> Utf8 Class Initialized
INFO - 2024-01-15 16:21:58 --> URI Class Initialized
INFO - 2024-01-15 16:21:58 --> Router Class Initialized
INFO - 2024-01-15 16:21:58 --> Output Class Initialized
INFO - 2024-01-15 16:21:58 --> Security Class Initialized
DEBUG - 2024-01-15 16:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:21:58 --> Input Class Initialized
INFO - 2024-01-15 16:21:58 --> Language Class Initialized
INFO - 2024-01-15 16:21:58 --> Language Class Initialized
INFO - 2024-01-15 16:21:58 --> Config Class Initialized
INFO - 2024-01-15 16:21:58 --> Loader Class Initialized
INFO - 2024-01-15 16:21:58 --> Helper loaded: url_helper
INFO - 2024-01-15 16:21:58 --> Helper loaded: file_helper
INFO - 2024-01-15 16:21:58 --> Helper loaded: form_helper
INFO - 2024-01-15 16:21:58 --> Helper loaded: my_helper
INFO - 2024-01-15 16:21:58 --> Database Driver Class Initialized
INFO - 2024-01-15 16:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:21:58 --> Controller Class Initialized
DEBUG - 2024-01-15 16:21:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:21:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:21:58 --> Final output sent to browser
DEBUG - 2024-01-15 16:21:58 --> Total execution time: 0.3708
INFO - 2024-01-15 16:22:39 --> Config Class Initialized
INFO - 2024-01-15 16:22:39 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:22:39 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:22:39 --> Utf8 Class Initialized
INFO - 2024-01-15 16:22:39 --> URI Class Initialized
INFO - 2024-01-15 16:22:39 --> Router Class Initialized
INFO - 2024-01-15 16:22:39 --> Output Class Initialized
INFO - 2024-01-15 16:22:39 --> Security Class Initialized
DEBUG - 2024-01-15 16:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:22:39 --> Input Class Initialized
INFO - 2024-01-15 16:22:39 --> Language Class Initialized
INFO - 2024-01-15 16:22:40 --> Language Class Initialized
INFO - 2024-01-15 16:22:40 --> Config Class Initialized
INFO - 2024-01-15 16:22:40 --> Loader Class Initialized
INFO - 2024-01-15 16:22:40 --> Helper loaded: url_helper
INFO - 2024-01-15 16:22:40 --> Helper loaded: file_helper
INFO - 2024-01-15 16:22:40 --> Helper loaded: form_helper
INFO - 2024-01-15 16:22:40 --> Helper loaded: my_helper
INFO - 2024-01-15 16:22:40 --> Database Driver Class Initialized
INFO - 2024-01-15 16:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:22:40 --> Controller Class Initialized
DEBUG - 2024-01-15 16:22:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:22:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:22:40 --> Final output sent to browser
DEBUG - 2024-01-15 16:22:40 --> Total execution time: 0.6493
INFO - 2024-01-15 16:25:15 --> Config Class Initialized
INFO - 2024-01-15 16:25:15 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:15 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:15 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:15 --> URI Class Initialized
INFO - 2024-01-15 16:25:15 --> Router Class Initialized
INFO - 2024-01-15 16:25:15 --> Output Class Initialized
INFO - 2024-01-15 16:25:15 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:15 --> Input Class Initialized
INFO - 2024-01-15 16:25:15 --> Language Class Initialized
INFO - 2024-01-15 16:25:15 --> Language Class Initialized
INFO - 2024-01-15 16:25:15 --> Config Class Initialized
INFO - 2024-01-15 16:25:15 --> Loader Class Initialized
INFO - 2024-01-15 16:25:15 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:15 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:15 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:15 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:15 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:15 --> Controller Class Initialized
DEBUG - 2024-01-15 16:25:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:25:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:25:15 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:15 --> Total execution time: 0.0709
INFO - 2024-01-15 16:25:24 --> Config Class Initialized
INFO - 2024-01-15 16:25:24 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:24 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:24 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:24 --> URI Class Initialized
INFO - 2024-01-15 16:25:24 --> Router Class Initialized
INFO - 2024-01-15 16:25:24 --> Output Class Initialized
INFO - 2024-01-15 16:25:24 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:24 --> Input Class Initialized
INFO - 2024-01-15 16:25:24 --> Language Class Initialized
INFO - 2024-01-15 16:25:24 --> Language Class Initialized
INFO - 2024-01-15 16:25:24 --> Config Class Initialized
INFO - 2024-01-15 16:25:24 --> Loader Class Initialized
INFO - 2024-01-15 16:25:24 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:24 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:24 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:24 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:24 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:24 --> Controller Class Initialized
INFO - 2024-01-15 16:25:24 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:24 --> Total execution time: 0.0686
INFO - 2024-01-15 16:25:40 --> Config Class Initialized
INFO - 2024-01-15 16:25:40 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:40 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:40 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:40 --> URI Class Initialized
INFO - 2024-01-15 16:25:40 --> Router Class Initialized
INFO - 2024-01-15 16:25:40 --> Output Class Initialized
INFO - 2024-01-15 16:25:40 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:40 --> Input Class Initialized
INFO - 2024-01-15 16:25:40 --> Language Class Initialized
INFO - 2024-01-15 16:25:40 --> Language Class Initialized
INFO - 2024-01-15 16:25:40 --> Config Class Initialized
INFO - 2024-01-15 16:25:40 --> Loader Class Initialized
INFO - 2024-01-15 16:25:40 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:40 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:40 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:40 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:40 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:40 --> Controller Class Initialized
INFO - 2024-01-15 16:25:40 --> Helper loaded: cookie_helper
INFO - 2024-01-15 16:25:40 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:40 --> Total execution time: 0.0693
INFO - 2024-01-15 16:25:40 --> Config Class Initialized
INFO - 2024-01-15 16:25:40 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:40 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:40 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:40 --> URI Class Initialized
INFO - 2024-01-15 16:25:40 --> Router Class Initialized
INFO - 2024-01-15 16:25:40 --> Output Class Initialized
INFO - 2024-01-15 16:25:40 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:40 --> Input Class Initialized
INFO - 2024-01-15 16:25:40 --> Language Class Initialized
INFO - 2024-01-15 16:25:40 --> Language Class Initialized
INFO - 2024-01-15 16:25:40 --> Config Class Initialized
INFO - 2024-01-15 16:25:40 --> Loader Class Initialized
INFO - 2024-01-15 16:25:40 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:40 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:40 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:40 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:40 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:40 --> Controller Class Initialized
DEBUG - 2024-01-15 16:25:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-15 16:25:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:25:41 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:41 --> Total execution time: 0.0655
INFO - 2024-01-15 16:25:44 --> Config Class Initialized
INFO - 2024-01-15 16:25:44 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:44 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:44 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:44 --> URI Class Initialized
INFO - 2024-01-15 16:25:44 --> Router Class Initialized
INFO - 2024-01-15 16:25:44 --> Output Class Initialized
INFO - 2024-01-15 16:25:44 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:44 --> Input Class Initialized
INFO - 2024-01-15 16:25:44 --> Language Class Initialized
INFO - 2024-01-15 16:25:44 --> Language Class Initialized
INFO - 2024-01-15 16:25:44 --> Config Class Initialized
INFO - 2024-01-15 16:25:44 --> Loader Class Initialized
INFO - 2024-01-15 16:25:44 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:44 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:44 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:44 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:45 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:45 --> Controller Class Initialized
DEBUG - 2024-01-15 16:25:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-15 16:25:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:25:45 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:45 --> Total execution time: 0.0655
INFO - 2024-01-15 16:25:48 --> Config Class Initialized
INFO - 2024-01-15 16:25:48 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:48 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:48 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:48 --> URI Class Initialized
INFO - 2024-01-15 16:25:48 --> Router Class Initialized
INFO - 2024-01-15 16:25:48 --> Output Class Initialized
INFO - 2024-01-15 16:25:48 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:48 --> Input Class Initialized
INFO - 2024-01-15 16:25:48 --> Language Class Initialized
INFO - 2024-01-15 16:25:48 --> Language Class Initialized
INFO - 2024-01-15 16:25:48 --> Config Class Initialized
INFO - 2024-01-15 16:25:48 --> Loader Class Initialized
INFO - 2024-01-15 16:25:48 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:48 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:48 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:48 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:48 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:48 --> Controller Class Initialized
DEBUG - 2024-01-15 16:25:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-15 16:25:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:25:48 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:48 --> Total execution time: 0.0839
INFO - 2024-01-15 16:25:48 --> Config Class Initialized
INFO - 2024-01-15 16:25:48 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:48 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:48 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:48 --> URI Class Initialized
INFO - 2024-01-15 16:25:48 --> Router Class Initialized
INFO - 2024-01-15 16:25:48 --> Output Class Initialized
INFO - 2024-01-15 16:25:48 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:48 --> Input Class Initialized
INFO - 2024-01-15 16:25:48 --> Language Class Initialized
INFO - 2024-01-15 16:25:48 --> Language Class Initialized
INFO - 2024-01-15 16:25:48 --> Config Class Initialized
INFO - 2024-01-15 16:25:48 --> Loader Class Initialized
INFO - 2024-01-15 16:25:48 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:48 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:48 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:48 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:48 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:48 --> Controller Class Initialized
INFO - 2024-01-15 16:25:50 --> Config Class Initialized
INFO - 2024-01-15 16:25:50 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:50 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:50 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:50 --> URI Class Initialized
INFO - 2024-01-15 16:25:50 --> Router Class Initialized
INFO - 2024-01-15 16:25:50 --> Output Class Initialized
INFO - 2024-01-15 16:25:50 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:50 --> Input Class Initialized
INFO - 2024-01-15 16:25:50 --> Language Class Initialized
INFO - 2024-01-15 16:25:50 --> Language Class Initialized
INFO - 2024-01-15 16:25:50 --> Config Class Initialized
INFO - 2024-01-15 16:25:50 --> Loader Class Initialized
INFO - 2024-01-15 16:25:50 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:50 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:50 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:50 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:51 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:51 --> Controller Class Initialized
INFO - 2024-01-15 16:25:54 --> Config Class Initialized
INFO - 2024-01-15 16:25:54 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:54 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:54 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:54 --> URI Class Initialized
INFO - 2024-01-15 16:25:54 --> Router Class Initialized
INFO - 2024-01-15 16:25:54 --> Output Class Initialized
INFO - 2024-01-15 16:25:54 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:54 --> Input Class Initialized
INFO - 2024-01-15 16:25:54 --> Language Class Initialized
INFO - 2024-01-15 16:25:54 --> Language Class Initialized
INFO - 2024-01-15 16:25:54 --> Config Class Initialized
INFO - 2024-01-15 16:25:54 --> Loader Class Initialized
INFO - 2024-01-15 16:25:54 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:54 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:54 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:54 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:54 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:54 --> Controller Class Initialized
DEBUG - 2024-01-15 16:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-15 16:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:25:54 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:54 --> Total execution time: 0.0367
INFO - 2024-01-15 16:25:56 --> Config Class Initialized
INFO - 2024-01-15 16:25:56 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:56 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:56 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:56 --> URI Class Initialized
INFO - 2024-01-15 16:25:56 --> Router Class Initialized
INFO - 2024-01-15 16:25:56 --> Output Class Initialized
INFO - 2024-01-15 16:25:56 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:56 --> Input Class Initialized
INFO - 2024-01-15 16:25:56 --> Language Class Initialized
INFO - 2024-01-15 16:25:56 --> Language Class Initialized
INFO - 2024-01-15 16:25:56 --> Config Class Initialized
INFO - 2024-01-15 16:25:56 --> Loader Class Initialized
INFO - 2024-01-15 16:25:56 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:56 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:56 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:56 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:56 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:56 --> Controller Class Initialized
DEBUG - 2024-01-15 16:25:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-15 16:25:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:25:56 --> Final output sent to browser
DEBUG - 2024-01-15 16:25:56 --> Total execution time: 0.0770
INFO - 2024-01-15 16:25:57 --> Config Class Initialized
INFO - 2024-01-15 16:25:57 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:25:57 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:25:57 --> Utf8 Class Initialized
INFO - 2024-01-15 16:25:57 --> URI Class Initialized
INFO - 2024-01-15 16:25:57 --> Router Class Initialized
INFO - 2024-01-15 16:25:57 --> Output Class Initialized
INFO - 2024-01-15 16:25:57 --> Security Class Initialized
DEBUG - 2024-01-15 16:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:25:57 --> Input Class Initialized
INFO - 2024-01-15 16:25:57 --> Language Class Initialized
INFO - 2024-01-15 16:25:57 --> Language Class Initialized
INFO - 2024-01-15 16:25:57 --> Config Class Initialized
INFO - 2024-01-15 16:25:57 --> Loader Class Initialized
INFO - 2024-01-15 16:25:57 --> Helper loaded: url_helper
INFO - 2024-01-15 16:25:57 --> Helper loaded: file_helper
INFO - 2024-01-15 16:25:57 --> Helper loaded: form_helper
INFO - 2024-01-15 16:25:57 --> Helper loaded: my_helper
INFO - 2024-01-15 16:25:57 --> Database Driver Class Initialized
INFO - 2024-01-15 16:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:25:57 --> Controller Class Initialized
INFO - 2024-01-15 16:26:02 --> Config Class Initialized
INFO - 2024-01-15 16:26:02 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:02 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:02 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:02 --> URI Class Initialized
INFO - 2024-01-15 16:26:02 --> Router Class Initialized
INFO - 2024-01-15 16:26:02 --> Output Class Initialized
INFO - 2024-01-15 16:26:02 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:02 --> Input Class Initialized
INFO - 2024-01-15 16:26:02 --> Language Class Initialized
INFO - 2024-01-15 16:26:02 --> Language Class Initialized
INFO - 2024-01-15 16:26:02 --> Config Class Initialized
INFO - 2024-01-15 16:26:02 --> Loader Class Initialized
INFO - 2024-01-15 16:26:02 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:02 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:02 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:02 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:02 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:02 --> Controller Class Initialized
INFO - 2024-01-15 16:26:12 --> Config Class Initialized
INFO - 2024-01-15 16:26:12 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:12 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:12 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:12 --> URI Class Initialized
INFO - 2024-01-15 16:26:12 --> Router Class Initialized
INFO - 2024-01-15 16:26:12 --> Output Class Initialized
INFO - 2024-01-15 16:26:12 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:12 --> Input Class Initialized
INFO - 2024-01-15 16:26:12 --> Language Class Initialized
INFO - 2024-01-15 16:26:12 --> Language Class Initialized
INFO - 2024-01-15 16:26:12 --> Config Class Initialized
INFO - 2024-01-15 16:26:12 --> Loader Class Initialized
INFO - 2024-01-15 16:26:12 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:12 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:13 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:13 --> Controller Class Initialized
INFO - 2024-01-15 16:26:13 --> Helper loaded: cookie_helper
INFO - 2024-01-15 16:26:13 --> Config Class Initialized
INFO - 2024-01-15 16:26:13 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:13 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:13 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:13 --> URI Class Initialized
INFO - 2024-01-15 16:26:13 --> Router Class Initialized
INFO - 2024-01-15 16:26:13 --> Output Class Initialized
INFO - 2024-01-15 16:26:13 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:13 --> Input Class Initialized
INFO - 2024-01-15 16:26:13 --> Language Class Initialized
INFO - 2024-01-15 16:26:13 --> Language Class Initialized
INFO - 2024-01-15 16:26:13 --> Config Class Initialized
INFO - 2024-01-15 16:26:13 --> Loader Class Initialized
INFO - 2024-01-15 16:26:13 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:13 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:13 --> Controller Class Initialized
INFO - 2024-01-15 16:26:13 --> Config Class Initialized
INFO - 2024-01-15 16:26:13 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:13 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:13 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:13 --> URI Class Initialized
INFO - 2024-01-15 16:26:13 --> Router Class Initialized
INFO - 2024-01-15 16:26:13 --> Output Class Initialized
INFO - 2024-01-15 16:26:13 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:13 --> Input Class Initialized
INFO - 2024-01-15 16:26:13 --> Language Class Initialized
INFO - 2024-01-15 16:26:13 --> Language Class Initialized
INFO - 2024-01-15 16:26:13 --> Config Class Initialized
INFO - 2024-01-15 16:26:13 --> Loader Class Initialized
INFO - 2024-01-15 16:26:13 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:13 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:13 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:13 --> Controller Class Initialized
DEBUG - 2024-01-15 16:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:26:13 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:13 --> Total execution time: 0.0756
INFO - 2024-01-15 16:26:29 --> Config Class Initialized
INFO - 2024-01-15 16:26:29 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:29 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:29 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:29 --> URI Class Initialized
INFO - 2024-01-15 16:26:29 --> Router Class Initialized
INFO - 2024-01-15 16:26:29 --> Output Class Initialized
INFO - 2024-01-15 16:26:29 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:29 --> Input Class Initialized
INFO - 2024-01-15 16:26:29 --> Language Class Initialized
INFO - 2024-01-15 16:26:29 --> Language Class Initialized
INFO - 2024-01-15 16:26:29 --> Config Class Initialized
INFO - 2024-01-15 16:26:29 --> Loader Class Initialized
INFO - 2024-01-15 16:26:29 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:29 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:29 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:29 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:29 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:30 --> Controller Class Initialized
INFO - 2024-01-15 16:26:30 --> Helper loaded: cookie_helper
INFO - 2024-01-15 16:26:30 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:30 --> Total execution time: 0.3521
INFO - 2024-01-15 16:26:30 --> Config Class Initialized
INFO - 2024-01-15 16:26:30 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:30 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:30 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:30 --> URI Class Initialized
INFO - 2024-01-15 16:26:30 --> Router Class Initialized
INFO - 2024-01-15 16:26:30 --> Output Class Initialized
INFO - 2024-01-15 16:26:30 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:30 --> Input Class Initialized
INFO - 2024-01-15 16:26:30 --> Language Class Initialized
INFO - 2024-01-15 16:26:30 --> Language Class Initialized
INFO - 2024-01-15 16:26:30 --> Config Class Initialized
INFO - 2024-01-15 16:26:30 --> Loader Class Initialized
INFO - 2024-01-15 16:26:30 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:30 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:30 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:30 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:30 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:30 --> Controller Class Initialized
DEBUG - 2024-01-15 16:26:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-15 16:26:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:26:30 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:30 --> Total execution time: 0.0804
INFO - 2024-01-15 16:26:32 --> Config Class Initialized
INFO - 2024-01-15 16:26:32 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:32 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:32 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:32 --> URI Class Initialized
INFO - 2024-01-15 16:26:32 --> Router Class Initialized
INFO - 2024-01-15 16:26:32 --> Output Class Initialized
INFO - 2024-01-15 16:26:32 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:32 --> Input Class Initialized
INFO - 2024-01-15 16:26:32 --> Language Class Initialized
INFO - 2024-01-15 16:26:32 --> Language Class Initialized
INFO - 2024-01-15 16:26:32 --> Config Class Initialized
INFO - 2024-01-15 16:26:32 --> Loader Class Initialized
INFO - 2024-01-15 16:26:32 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:32 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:32 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:32 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:32 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:32 --> Controller Class Initialized
DEBUG - 2024-01-15 16:26:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-15 16:26:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:26:32 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:32 --> Total execution time: 0.0382
INFO - 2024-01-15 16:26:34 --> Config Class Initialized
INFO - 2024-01-15 16:26:34 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:34 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:34 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:34 --> URI Class Initialized
INFO - 2024-01-15 16:26:34 --> Router Class Initialized
INFO - 2024-01-15 16:26:34 --> Output Class Initialized
INFO - 2024-01-15 16:26:34 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:34 --> Input Class Initialized
INFO - 2024-01-15 16:26:34 --> Language Class Initialized
INFO - 2024-01-15 16:26:34 --> Language Class Initialized
INFO - 2024-01-15 16:26:34 --> Config Class Initialized
INFO - 2024-01-15 16:26:34 --> Loader Class Initialized
INFO - 2024-01-15 16:26:34 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:34 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:34 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:34 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:34 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:34 --> Controller Class Initialized
DEBUG - 2024-01-15 16:26:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-15 16:26:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:26:34 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:34 --> Total execution time: 0.0409
INFO - 2024-01-15 16:26:35 --> Config Class Initialized
INFO - 2024-01-15 16:26:35 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:35 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:35 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:35 --> URI Class Initialized
INFO - 2024-01-15 16:26:35 --> Router Class Initialized
INFO - 2024-01-15 16:26:35 --> Output Class Initialized
INFO - 2024-01-15 16:26:35 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:35 --> Input Class Initialized
INFO - 2024-01-15 16:26:35 --> Language Class Initialized
INFO - 2024-01-15 16:26:35 --> Language Class Initialized
INFO - 2024-01-15 16:26:35 --> Config Class Initialized
INFO - 2024-01-15 16:26:35 --> Loader Class Initialized
INFO - 2024-01-15 16:26:35 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:35 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:35 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:35 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:35 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:35 --> Controller Class Initialized
INFO - 2024-01-15 16:26:36 --> Config Class Initialized
INFO - 2024-01-15 16:26:36 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:36 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:36 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:36 --> URI Class Initialized
INFO - 2024-01-15 16:26:36 --> Router Class Initialized
INFO - 2024-01-15 16:26:36 --> Output Class Initialized
INFO - 2024-01-15 16:26:36 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:36 --> Input Class Initialized
INFO - 2024-01-15 16:26:36 --> Language Class Initialized
INFO - 2024-01-15 16:26:36 --> Language Class Initialized
INFO - 2024-01-15 16:26:36 --> Config Class Initialized
INFO - 2024-01-15 16:26:36 --> Loader Class Initialized
INFO - 2024-01-15 16:26:36 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:36 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:36 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:36 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:36 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:36 --> Controller Class Initialized
INFO - 2024-01-15 16:26:38 --> Config Class Initialized
INFO - 2024-01-15 16:26:38 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:38 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:38 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:38 --> URI Class Initialized
INFO - 2024-01-15 16:26:38 --> Router Class Initialized
INFO - 2024-01-15 16:26:38 --> Output Class Initialized
INFO - 2024-01-15 16:26:38 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:38 --> Input Class Initialized
INFO - 2024-01-15 16:26:38 --> Language Class Initialized
INFO - 2024-01-15 16:26:38 --> Language Class Initialized
INFO - 2024-01-15 16:26:38 --> Config Class Initialized
INFO - 2024-01-15 16:26:38 --> Loader Class Initialized
INFO - 2024-01-15 16:26:38 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:38 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:38 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:38 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:38 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:38 --> Controller Class Initialized
DEBUG - 2024-01-15 16:26:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-15 16:26:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:26:38 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:38 --> Total execution time: 0.0727
INFO - 2024-01-15 16:26:40 --> Config Class Initialized
INFO - 2024-01-15 16:26:40 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:40 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:40 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:40 --> URI Class Initialized
INFO - 2024-01-15 16:26:40 --> Router Class Initialized
INFO - 2024-01-15 16:26:40 --> Output Class Initialized
INFO - 2024-01-15 16:26:40 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:40 --> Input Class Initialized
INFO - 2024-01-15 16:26:40 --> Language Class Initialized
INFO - 2024-01-15 16:26:40 --> Language Class Initialized
INFO - 2024-01-15 16:26:40 --> Config Class Initialized
INFO - 2024-01-15 16:26:40 --> Loader Class Initialized
INFO - 2024-01-15 16:26:40 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:40 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:40 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:40 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:40 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:40 --> Controller Class Initialized
DEBUG - 2024-01-15 16:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-15 16:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:26:40 --> Final output sent to browser
DEBUG - 2024-01-15 16:26:40 --> Total execution time: 0.0373
INFO - 2024-01-15 16:26:40 --> Config Class Initialized
INFO - 2024-01-15 16:26:40 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:26:40 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:26:40 --> Utf8 Class Initialized
INFO - 2024-01-15 16:26:40 --> URI Class Initialized
INFO - 2024-01-15 16:26:40 --> Router Class Initialized
INFO - 2024-01-15 16:26:40 --> Output Class Initialized
INFO - 2024-01-15 16:26:40 --> Security Class Initialized
DEBUG - 2024-01-15 16:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:26:40 --> Input Class Initialized
INFO - 2024-01-15 16:26:40 --> Language Class Initialized
INFO - 2024-01-15 16:26:40 --> Language Class Initialized
INFO - 2024-01-15 16:26:40 --> Config Class Initialized
INFO - 2024-01-15 16:26:40 --> Loader Class Initialized
INFO - 2024-01-15 16:26:40 --> Helper loaded: url_helper
INFO - 2024-01-15 16:26:40 --> Helper loaded: file_helper
INFO - 2024-01-15 16:26:40 --> Helper loaded: form_helper
INFO - 2024-01-15 16:26:40 --> Helper loaded: my_helper
INFO - 2024-01-15 16:26:40 --> Database Driver Class Initialized
INFO - 2024-01-15 16:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:26:40 --> Controller Class Initialized
INFO - 2024-01-15 16:27:06 --> Config Class Initialized
INFO - 2024-01-15 16:27:06 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:27:06 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:27:06 --> Utf8 Class Initialized
INFO - 2024-01-15 16:27:06 --> URI Class Initialized
INFO - 2024-01-15 16:27:06 --> Router Class Initialized
INFO - 2024-01-15 16:27:06 --> Output Class Initialized
INFO - 2024-01-15 16:27:06 --> Security Class Initialized
DEBUG - 2024-01-15 16:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:27:06 --> Input Class Initialized
INFO - 2024-01-15 16:27:06 --> Language Class Initialized
INFO - 2024-01-15 16:27:06 --> Language Class Initialized
INFO - 2024-01-15 16:27:06 --> Config Class Initialized
INFO - 2024-01-15 16:27:06 --> Loader Class Initialized
INFO - 2024-01-15 16:27:06 --> Helper loaded: url_helper
INFO - 2024-01-15 16:27:06 --> Helper loaded: file_helper
INFO - 2024-01-15 16:27:06 --> Helper loaded: form_helper
INFO - 2024-01-15 16:27:06 --> Helper loaded: my_helper
INFO - 2024-01-15 16:27:06 --> Database Driver Class Initialized
INFO - 2024-01-15 16:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:27:06 --> Controller Class Initialized
INFO - 2024-01-15 16:27:12 --> Config Class Initialized
INFO - 2024-01-15 16:27:12 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:27:12 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:27:12 --> Utf8 Class Initialized
INFO - 2024-01-15 16:27:12 --> URI Class Initialized
INFO - 2024-01-15 16:27:12 --> Router Class Initialized
INFO - 2024-01-15 16:27:12 --> Output Class Initialized
INFO - 2024-01-15 16:27:12 --> Security Class Initialized
DEBUG - 2024-01-15 16:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:27:12 --> Input Class Initialized
INFO - 2024-01-15 16:27:12 --> Language Class Initialized
INFO - 2024-01-15 16:27:12 --> Language Class Initialized
INFO - 2024-01-15 16:27:12 --> Config Class Initialized
INFO - 2024-01-15 16:27:12 --> Loader Class Initialized
INFO - 2024-01-15 16:27:12 --> Helper loaded: url_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: file_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: form_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: my_helper
INFO - 2024-01-15 16:27:12 --> Database Driver Class Initialized
INFO - 2024-01-15 16:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:27:12 --> Controller Class Initialized
INFO - 2024-01-15 16:27:12 --> Helper loaded: cookie_helper
INFO - 2024-01-15 16:27:12 --> Config Class Initialized
INFO - 2024-01-15 16:27:12 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:27:12 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:27:12 --> Utf8 Class Initialized
INFO - 2024-01-15 16:27:12 --> URI Class Initialized
INFO - 2024-01-15 16:27:12 --> Router Class Initialized
INFO - 2024-01-15 16:27:12 --> Output Class Initialized
INFO - 2024-01-15 16:27:12 --> Security Class Initialized
DEBUG - 2024-01-15 16:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:27:12 --> Input Class Initialized
INFO - 2024-01-15 16:27:12 --> Language Class Initialized
INFO - 2024-01-15 16:27:12 --> Language Class Initialized
INFO - 2024-01-15 16:27:12 --> Config Class Initialized
INFO - 2024-01-15 16:27:12 --> Loader Class Initialized
INFO - 2024-01-15 16:27:12 --> Helper loaded: url_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: file_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: form_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: my_helper
INFO - 2024-01-15 16:27:12 --> Database Driver Class Initialized
INFO - 2024-01-15 16:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:27:12 --> Controller Class Initialized
INFO - 2024-01-15 16:27:12 --> Config Class Initialized
INFO - 2024-01-15 16:27:12 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:27:12 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:27:12 --> Utf8 Class Initialized
INFO - 2024-01-15 16:27:12 --> URI Class Initialized
INFO - 2024-01-15 16:27:12 --> Router Class Initialized
INFO - 2024-01-15 16:27:12 --> Output Class Initialized
INFO - 2024-01-15 16:27:12 --> Security Class Initialized
DEBUG - 2024-01-15 16:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:27:12 --> Input Class Initialized
INFO - 2024-01-15 16:27:12 --> Language Class Initialized
INFO - 2024-01-15 16:27:12 --> Language Class Initialized
INFO - 2024-01-15 16:27:12 --> Config Class Initialized
INFO - 2024-01-15 16:27:12 --> Loader Class Initialized
INFO - 2024-01-15 16:27:12 --> Helper loaded: url_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: file_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: form_helper
INFO - 2024-01-15 16:27:12 --> Helper loaded: my_helper
INFO - 2024-01-15 16:27:12 --> Database Driver Class Initialized
INFO - 2024-01-15 16:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:27:12 --> Controller Class Initialized
DEBUG - 2024-01-15 16:27:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-15 16:27:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:27:12 --> Final output sent to browser
DEBUG - 2024-01-15 16:27:12 --> Total execution time: 0.0387
INFO - 2024-01-15 16:31:57 --> Config Class Initialized
INFO - 2024-01-15 16:31:57 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:31:57 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:31:57 --> Utf8 Class Initialized
INFO - 2024-01-15 16:31:57 --> URI Class Initialized
INFO - 2024-01-15 16:31:57 --> Router Class Initialized
INFO - 2024-01-15 16:31:57 --> Output Class Initialized
INFO - 2024-01-15 16:31:57 --> Security Class Initialized
DEBUG - 2024-01-15 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:31:57 --> Input Class Initialized
INFO - 2024-01-15 16:31:57 --> Language Class Initialized
INFO - 2024-01-15 16:31:57 --> Language Class Initialized
INFO - 2024-01-15 16:31:57 --> Config Class Initialized
INFO - 2024-01-15 16:31:57 --> Loader Class Initialized
INFO - 2024-01-15 16:31:57 --> Helper loaded: url_helper
INFO - 2024-01-15 16:31:57 --> Helper loaded: file_helper
INFO - 2024-01-15 16:31:57 --> Helper loaded: form_helper
INFO - 2024-01-15 16:31:57 --> Helper loaded: my_helper
INFO - 2024-01-15 16:31:57 --> Database Driver Class Initialized
INFO - 2024-01-15 16:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:31:57 --> Controller Class Initialized
DEBUG - 2024-01-15 16:31:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-15 16:31:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-15 16:31:57 --> Final output sent to browser
DEBUG - 2024-01-15 16:31:57 --> Total execution time: 0.0475
INFO - 2024-01-15 16:31:57 --> Config Class Initialized
INFO - 2024-01-15 16:31:57 --> Hooks Class Initialized
DEBUG - 2024-01-15 16:31:57 --> UTF-8 Support Enabled
INFO - 2024-01-15 16:31:57 --> Utf8 Class Initialized
INFO - 2024-01-15 16:31:57 --> URI Class Initialized
INFO - 2024-01-15 16:31:57 --> Router Class Initialized
INFO - 2024-01-15 16:31:57 --> Output Class Initialized
INFO - 2024-01-15 16:31:57 --> Security Class Initialized
DEBUG - 2024-01-15 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-15 16:31:57 --> Input Class Initialized
INFO - 2024-01-15 16:31:57 --> Language Class Initialized
INFO - 2024-01-15 16:31:57 --> Language Class Initialized
INFO - 2024-01-15 16:31:57 --> Config Class Initialized
INFO - 2024-01-15 16:31:57 --> Loader Class Initialized
INFO - 2024-01-15 16:31:57 --> Helper loaded: url_helper
INFO - 2024-01-15 16:31:57 --> Helper loaded: file_helper
INFO - 2024-01-15 16:31:57 --> Helper loaded: form_helper
INFO - 2024-01-15 16:31:57 --> Helper loaded: my_helper
INFO - 2024-01-15 16:31:57 --> Database Driver Class Initialized
INFO - 2024-01-15 16:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-15 16:31:57 --> Controller Class Initialized
