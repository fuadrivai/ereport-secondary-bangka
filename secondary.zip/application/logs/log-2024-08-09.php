<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-09 10:01:31 --> Config Class Initialized
INFO - 2024-08-09 10:01:31 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:31 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:31 --> URI Class Initialized
INFO - 2024-08-09 10:01:31 --> Router Class Initialized
INFO - 2024-08-09 10:01:31 --> Output Class Initialized
INFO - 2024-08-09 10:01:31 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:31 --> Input Class Initialized
INFO - 2024-08-09 10:01:31 --> Language Class Initialized
INFO - 2024-08-09 10:01:31 --> Language Class Initialized
INFO - 2024-08-09 10:01:31 --> Config Class Initialized
INFO - 2024-08-09 10:01:31 --> Loader Class Initialized
INFO - 2024-08-09 10:01:31 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:31 --> Helper loaded: file_helper
INFO - 2024-08-09 10:01:31 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:31 --> Helper loaded: my_helper
INFO - 2024-08-09 10:01:31 --> Database Driver Class Initialized
INFO - 2024-08-09 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:31 --> Controller Class Initialized
INFO - 2024-08-09 10:01:31 --> Helper loaded: cookie_helper
INFO - 2024-08-09 10:01:31 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:31 --> Total execution time: 0.2352
INFO - 2024-08-09 10:01:32 --> Config Class Initialized
INFO - 2024-08-09 10:01:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:32 --> URI Class Initialized
INFO - 2024-08-09 10:01:32 --> Router Class Initialized
INFO - 2024-08-09 10:01:32 --> Output Class Initialized
INFO - 2024-08-09 10:01:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:32 --> Input Class Initialized
INFO - 2024-08-09 10:01:32 --> Language Class Initialized
INFO - 2024-08-09 10:01:32 --> Language Class Initialized
INFO - 2024-08-09 10:01:32 --> Config Class Initialized
INFO - 2024-08-09 10:01:32 --> Loader Class Initialized
INFO - 2024-08-09 10:01:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: file_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: my_helper
INFO - 2024-08-09 10:01:32 --> Database Driver Class Initialized
INFO - 2024-08-09 10:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:32 --> Controller Class Initialized
INFO - 2024-08-09 10:01:32 --> Helper loaded: cookie_helper
INFO - 2024-08-09 10:01:32 --> Config Class Initialized
INFO - 2024-08-09 10:01:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:32 --> URI Class Initialized
INFO - 2024-08-09 10:01:32 --> Router Class Initialized
INFO - 2024-08-09 10:01:32 --> Output Class Initialized
INFO - 2024-08-09 10:01:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:32 --> Input Class Initialized
INFO - 2024-08-09 10:01:32 --> Language Class Initialized
INFO - 2024-08-09 10:01:32 --> Language Class Initialized
INFO - 2024-08-09 10:01:32 --> Config Class Initialized
INFO - 2024-08-09 10:01:32 --> Loader Class Initialized
INFO - 2024-08-09 10:01:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: file_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: my_helper
INFO - 2024-08-09 10:01:32 --> Database Driver Class Initialized
INFO - 2024-08-09 10:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:32 --> Controller Class Initialized
DEBUG - 2024-08-09 10:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-09 10:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-09 10:01:32 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:32 --> Total execution time: 0.0382
INFO - 2024-08-09 17:27:49 --> Config Class Initialized
INFO - 2024-08-09 17:27:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:27:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:27:49 --> Utf8 Class Initialized
INFO - 2024-08-09 17:27:49 --> URI Class Initialized
INFO - 2024-08-09 17:27:49 --> Router Class Initialized
INFO - 2024-08-09 17:27:49 --> Output Class Initialized
INFO - 2024-08-09 17:27:49 --> Security Class Initialized
DEBUG - 2024-08-09 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:27:49 --> Input Class Initialized
INFO - 2024-08-09 17:27:49 --> Language Class Initialized
INFO - 2024-08-09 17:27:49 --> Language Class Initialized
INFO - 2024-08-09 17:27:49 --> Config Class Initialized
INFO - 2024-08-09 17:27:49 --> Loader Class Initialized
INFO - 2024-08-09 17:27:49 --> Helper loaded: url_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: file_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: form_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: my_helper
INFO - 2024-08-09 17:27:49 --> Database Driver Class Initialized
INFO - 2024-08-09 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:27:49 --> Controller Class Initialized
INFO - 2024-08-09 17:27:49 --> Helper loaded: cookie_helper
INFO - 2024-08-09 17:27:49 --> Final output sent to browser
DEBUG - 2024-08-09 17:27:49 --> Total execution time: 0.0757
INFO - 2024-08-09 17:27:49 --> Config Class Initialized
INFO - 2024-08-09 17:27:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:27:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:27:49 --> Utf8 Class Initialized
INFO - 2024-08-09 17:27:49 --> URI Class Initialized
INFO - 2024-08-09 17:27:49 --> Router Class Initialized
INFO - 2024-08-09 17:27:49 --> Output Class Initialized
INFO - 2024-08-09 17:27:49 --> Security Class Initialized
DEBUG - 2024-08-09 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:27:49 --> Input Class Initialized
INFO - 2024-08-09 17:27:49 --> Language Class Initialized
INFO - 2024-08-09 17:27:49 --> Language Class Initialized
INFO - 2024-08-09 17:27:49 --> Config Class Initialized
INFO - 2024-08-09 17:27:49 --> Loader Class Initialized
INFO - 2024-08-09 17:27:49 --> Helper loaded: url_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: file_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: form_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: my_helper
INFO - 2024-08-09 17:27:49 --> Database Driver Class Initialized
INFO - 2024-08-09 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:27:49 --> Controller Class Initialized
INFO - 2024-08-09 17:27:49 --> Helper loaded: cookie_helper
INFO - 2024-08-09 17:27:49 --> Config Class Initialized
INFO - 2024-08-09 17:27:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:27:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:27:49 --> Utf8 Class Initialized
INFO - 2024-08-09 17:27:49 --> URI Class Initialized
INFO - 2024-08-09 17:27:49 --> Router Class Initialized
INFO - 2024-08-09 17:27:49 --> Output Class Initialized
INFO - 2024-08-09 17:27:49 --> Security Class Initialized
DEBUG - 2024-08-09 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:27:49 --> Input Class Initialized
INFO - 2024-08-09 17:27:49 --> Language Class Initialized
INFO - 2024-08-09 17:27:49 --> Language Class Initialized
INFO - 2024-08-09 17:27:49 --> Config Class Initialized
INFO - 2024-08-09 17:27:49 --> Loader Class Initialized
INFO - 2024-08-09 17:27:49 --> Helper loaded: url_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: file_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: form_helper
INFO - 2024-08-09 17:27:49 --> Helper loaded: my_helper
INFO - 2024-08-09 17:27:49 --> Database Driver Class Initialized
INFO - 2024-08-09 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:27:49 --> Controller Class Initialized
DEBUG - 2024-08-09 17:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-09 17:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-09 17:27:50 --> Final output sent to browser
DEBUG - 2024-08-09 17:27:50 --> Total execution time: 0.2737
