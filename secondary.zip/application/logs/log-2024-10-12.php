<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-12 08:14:00 --> Config Class Initialized
INFO - 2024-10-12 08:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-12 08:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-12 08:14:00 --> Utf8 Class Initialized
INFO - 2024-10-12 08:14:00 --> URI Class Initialized
INFO - 2024-10-12 08:14:00 --> Router Class Initialized
INFO - 2024-10-12 08:14:00 --> Output Class Initialized
INFO - 2024-10-12 08:14:00 --> Security Class Initialized
DEBUG - 2024-10-12 08:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 08:14:00 --> Input Class Initialized
INFO - 2024-10-12 08:14:00 --> Language Class Initialized
INFO - 2024-10-12 08:14:00 --> Language Class Initialized
INFO - 2024-10-12 08:14:00 --> Config Class Initialized
INFO - 2024-10-12 08:14:00 --> Loader Class Initialized
INFO - 2024-10-12 08:14:00 --> Helper loaded: url_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: file_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: form_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: my_helper
INFO - 2024-10-12 08:14:00 --> Database Driver Class Initialized
INFO - 2024-10-12 08:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 08:14:00 --> Controller Class Initialized
INFO - 2024-10-12 08:14:00 --> Helper loaded: cookie_helper
INFO - 2024-10-12 08:14:00 --> Final output sent to browser
DEBUG - 2024-10-12 08:14:00 --> Total execution time: 0.0718
INFO - 2024-10-12 08:14:00 --> Config Class Initialized
INFO - 2024-10-12 08:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-12 08:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-12 08:14:00 --> Utf8 Class Initialized
INFO - 2024-10-12 08:14:00 --> URI Class Initialized
INFO - 2024-10-12 08:14:00 --> Router Class Initialized
INFO - 2024-10-12 08:14:00 --> Output Class Initialized
INFO - 2024-10-12 08:14:00 --> Security Class Initialized
DEBUG - 2024-10-12 08:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 08:14:00 --> Input Class Initialized
INFO - 2024-10-12 08:14:00 --> Language Class Initialized
INFO - 2024-10-12 08:14:00 --> Language Class Initialized
INFO - 2024-10-12 08:14:00 --> Config Class Initialized
INFO - 2024-10-12 08:14:00 --> Loader Class Initialized
INFO - 2024-10-12 08:14:00 --> Helper loaded: url_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: file_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: form_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: my_helper
INFO - 2024-10-12 08:14:00 --> Database Driver Class Initialized
INFO - 2024-10-12 08:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 08:14:00 --> Controller Class Initialized
INFO - 2024-10-12 08:14:00 --> Helper loaded: cookie_helper
INFO - 2024-10-12 08:14:00 --> Config Class Initialized
INFO - 2024-10-12 08:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-12 08:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-12 08:14:00 --> Utf8 Class Initialized
INFO - 2024-10-12 08:14:00 --> URI Class Initialized
INFO - 2024-10-12 08:14:00 --> Router Class Initialized
INFO - 2024-10-12 08:14:00 --> Output Class Initialized
INFO - 2024-10-12 08:14:00 --> Security Class Initialized
DEBUG - 2024-10-12 08:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 08:14:00 --> Input Class Initialized
INFO - 2024-10-12 08:14:00 --> Language Class Initialized
INFO - 2024-10-12 08:14:00 --> Language Class Initialized
INFO - 2024-10-12 08:14:00 --> Config Class Initialized
INFO - 2024-10-12 08:14:00 --> Loader Class Initialized
INFO - 2024-10-12 08:14:00 --> Helper loaded: url_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: file_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: form_helper
INFO - 2024-10-12 08:14:00 --> Helper loaded: my_helper
INFO - 2024-10-12 08:14:00 --> Database Driver Class Initialized
INFO - 2024-10-12 08:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 08:14:00 --> Controller Class Initialized
DEBUG - 2024-10-12 08:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 08:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 08:14:00 --> Final output sent to browser
DEBUG - 2024-10-12 08:14:00 --> Total execution time: 0.0446
INFO - 2024-10-12 08:14:05 --> Config Class Initialized
INFO - 2024-10-12 08:14:05 --> Hooks Class Initialized
DEBUG - 2024-10-12 08:14:05 --> UTF-8 Support Enabled
INFO - 2024-10-12 08:14:05 --> Utf8 Class Initialized
INFO - 2024-10-12 08:14:05 --> URI Class Initialized
INFO - 2024-10-12 08:14:05 --> Router Class Initialized
INFO - 2024-10-12 08:14:05 --> Output Class Initialized
INFO - 2024-10-12 08:14:05 --> Security Class Initialized
DEBUG - 2024-10-12 08:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 08:14:05 --> Input Class Initialized
INFO - 2024-10-12 08:14:05 --> Language Class Initialized
INFO - 2024-10-12 08:14:05 --> Language Class Initialized
INFO - 2024-10-12 08:14:05 --> Config Class Initialized
INFO - 2024-10-12 08:14:05 --> Loader Class Initialized
INFO - 2024-10-12 08:14:05 --> Helper loaded: url_helper
INFO - 2024-10-12 08:14:05 --> Helper loaded: file_helper
INFO - 2024-10-12 08:14:05 --> Helper loaded: form_helper
INFO - 2024-10-12 08:14:05 --> Helper loaded: my_helper
INFO - 2024-10-12 08:14:05 --> Database Driver Class Initialized
INFO - 2024-10-12 08:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 08:14:05 --> Controller Class Initialized
DEBUG - 2024-10-12 08:14:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 08:14:08 --> Final output sent to browser
DEBUG - 2024-10-12 08:14:08 --> Total execution time: 2.9096
INFO - 2024-10-12 09:57:42 --> Config Class Initialized
INFO - 2024-10-12 09:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-12 09:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-12 09:57:42 --> Utf8 Class Initialized
INFO - 2024-10-12 09:57:42 --> URI Class Initialized
INFO - 2024-10-12 09:57:42 --> Router Class Initialized
INFO - 2024-10-12 09:57:42 --> Output Class Initialized
INFO - 2024-10-12 09:57:42 --> Security Class Initialized
DEBUG - 2024-10-12 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 09:57:42 --> Input Class Initialized
INFO - 2024-10-12 09:57:42 --> Language Class Initialized
INFO - 2024-10-12 09:57:42 --> Language Class Initialized
INFO - 2024-10-12 09:57:42 --> Config Class Initialized
INFO - 2024-10-12 09:57:42 --> Loader Class Initialized
INFO - 2024-10-12 09:57:42 --> Helper loaded: url_helper
INFO - 2024-10-12 09:57:42 --> Helper loaded: file_helper
INFO - 2024-10-12 09:57:42 --> Helper loaded: form_helper
INFO - 2024-10-12 09:57:42 --> Helper loaded: my_helper
INFO - 2024-10-12 09:57:42 --> Database Driver Class Initialized
INFO - 2024-10-12 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 09:57:42 --> Controller Class Initialized
INFO - 2024-10-12 09:57:42 --> Helper loaded: cookie_helper
INFO - 2024-10-12 09:57:42 --> Final output sent to browser
DEBUG - 2024-10-12 09:57:42 --> Total execution time: 0.0595
INFO - 2024-10-12 09:57:43 --> Config Class Initialized
INFO - 2024-10-12 09:57:43 --> Hooks Class Initialized
DEBUG - 2024-10-12 09:57:43 --> UTF-8 Support Enabled
INFO - 2024-10-12 09:57:43 --> Utf8 Class Initialized
INFO - 2024-10-12 09:57:43 --> URI Class Initialized
INFO - 2024-10-12 09:57:43 --> Router Class Initialized
INFO - 2024-10-12 09:57:43 --> Output Class Initialized
INFO - 2024-10-12 09:57:43 --> Security Class Initialized
DEBUG - 2024-10-12 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 09:57:43 --> Input Class Initialized
INFO - 2024-10-12 09:57:43 --> Language Class Initialized
INFO - 2024-10-12 09:57:43 --> Language Class Initialized
INFO - 2024-10-12 09:57:43 --> Config Class Initialized
INFO - 2024-10-12 09:57:43 --> Loader Class Initialized
INFO - 2024-10-12 09:57:43 --> Helper loaded: url_helper
INFO - 2024-10-12 09:57:43 --> Helper loaded: file_helper
INFO - 2024-10-12 09:57:43 --> Helper loaded: form_helper
INFO - 2024-10-12 09:57:43 --> Helper loaded: my_helper
INFO - 2024-10-12 09:57:43 --> Database Driver Class Initialized
INFO - 2024-10-12 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 09:57:43 --> Controller Class Initialized
INFO - 2024-10-12 09:57:43 --> Helper loaded: cookie_helper
INFO - 2024-10-12 09:57:43 --> Config Class Initialized
INFO - 2024-10-12 09:57:43 --> Hooks Class Initialized
DEBUG - 2024-10-12 09:57:43 --> UTF-8 Support Enabled
INFO - 2024-10-12 09:57:43 --> Utf8 Class Initialized
INFO - 2024-10-12 09:57:43 --> URI Class Initialized
INFO - 2024-10-12 09:57:43 --> Router Class Initialized
INFO - 2024-10-12 09:57:43 --> Output Class Initialized
INFO - 2024-10-12 09:57:43 --> Security Class Initialized
DEBUG - 2024-10-12 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 09:57:43 --> Input Class Initialized
INFO - 2024-10-12 09:57:43 --> Language Class Initialized
INFO - 2024-10-12 09:57:43 --> Language Class Initialized
INFO - 2024-10-12 09:57:43 --> Config Class Initialized
INFO - 2024-10-12 09:57:43 --> Loader Class Initialized
INFO - 2024-10-12 09:57:43 --> Helper loaded: url_helper
INFO - 2024-10-12 09:57:43 --> Helper loaded: file_helper
INFO - 2024-10-12 09:57:43 --> Helper loaded: form_helper
INFO - 2024-10-12 09:57:43 --> Helper loaded: my_helper
INFO - 2024-10-12 09:57:43 --> Database Driver Class Initialized
INFO - 2024-10-12 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 09:57:43 --> Controller Class Initialized
DEBUG - 2024-10-12 09:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 09:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 09:57:43 --> Final output sent to browser
DEBUG - 2024-10-12 09:57:43 --> Total execution time: 0.0413
INFO - 2024-10-12 09:57:46 --> Config Class Initialized
INFO - 2024-10-12 09:57:46 --> Hooks Class Initialized
DEBUG - 2024-10-12 09:57:46 --> UTF-8 Support Enabled
INFO - 2024-10-12 09:57:46 --> Utf8 Class Initialized
INFO - 2024-10-12 09:57:46 --> URI Class Initialized
INFO - 2024-10-12 09:57:46 --> Router Class Initialized
INFO - 2024-10-12 09:57:46 --> Output Class Initialized
INFO - 2024-10-12 09:57:46 --> Security Class Initialized
DEBUG - 2024-10-12 09:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 09:57:46 --> Input Class Initialized
INFO - 2024-10-12 09:57:46 --> Language Class Initialized
INFO - 2024-10-12 09:57:46 --> Language Class Initialized
INFO - 2024-10-12 09:57:46 --> Config Class Initialized
INFO - 2024-10-12 09:57:46 --> Loader Class Initialized
INFO - 2024-10-12 09:57:46 --> Helper loaded: url_helper
INFO - 2024-10-12 09:57:46 --> Helper loaded: file_helper
INFO - 2024-10-12 09:57:46 --> Helper loaded: form_helper
INFO - 2024-10-12 09:57:46 --> Helper loaded: my_helper
INFO - 2024-10-12 09:57:46 --> Database Driver Class Initialized
INFO - 2024-10-12 09:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 09:57:46 --> Controller Class Initialized
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-12 09:57:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-12 09:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 09:57:48 --> Final output sent to browser
DEBUG - 2024-10-12 09:57:48 --> Total execution time: 2.5289
INFO - 2024-10-12 09:59:33 --> Config Class Initialized
INFO - 2024-10-12 09:59:33 --> Hooks Class Initialized
DEBUG - 2024-10-12 09:59:33 --> UTF-8 Support Enabled
INFO - 2024-10-12 09:59:33 --> Utf8 Class Initialized
INFO - 2024-10-12 09:59:33 --> URI Class Initialized
INFO - 2024-10-12 09:59:33 --> Router Class Initialized
INFO - 2024-10-12 09:59:33 --> Output Class Initialized
INFO - 2024-10-12 09:59:33 --> Security Class Initialized
DEBUG - 2024-10-12 09:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 09:59:33 --> Input Class Initialized
INFO - 2024-10-12 09:59:33 --> Language Class Initialized
INFO - 2024-10-12 09:59:33 --> Language Class Initialized
INFO - 2024-10-12 09:59:33 --> Config Class Initialized
INFO - 2024-10-12 09:59:33 --> Loader Class Initialized
INFO - 2024-10-12 09:59:33 --> Helper loaded: url_helper
INFO - 2024-10-12 09:59:33 --> Helper loaded: file_helper
INFO - 2024-10-12 09:59:33 --> Helper loaded: form_helper
INFO - 2024-10-12 09:59:33 --> Helper loaded: my_helper
INFO - 2024-10-12 09:59:33 --> Database Driver Class Initialized
INFO - 2024-10-12 09:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 09:59:33 --> Controller Class Initialized
DEBUG - 2024-10-12 09:59:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 09:59:36 --> Final output sent to browser
DEBUG - 2024-10-12 09:59:36 --> Total execution time: 2.7778
INFO - 2024-10-12 11:08:42 --> Config Class Initialized
INFO - 2024-10-12 11:08:42 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:08:42 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:08:42 --> Utf8 Class Initialized
INFO - 2024-10-12 11:08:42 --> URI Class Initialized
INFO - 2024-10-12 11:08:42 --> Router Class Initialized
INFO - 2024-10-12 11:08:42 --> Output Class Initialized
INFO - 2024-10-12 11:08:42 --> Security Class Initialized
DEBUG - 2024-10-12 11:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:08:42 --> Input Class Initialized
INFO - 2024-10-12 11:08:42 --> Language Class Initialized
INFO - 2024-10-12 11:08:42 --> Language Class Initialized
INFO - 2024-10-12 11:08:42 --> Config Class Initialized
INFO - 2024-10-12 11:08:42 --> Loader Class Initialized
INFO - 2024-10-12 11:08:42 --> Helper loaded: url_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: file_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: form_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: my_helper
INFO - 2024-10-12 11:08:42 --> Database Driver Class Initialized
INFO - 2024-10-12 11:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:08:42 --> Controller Class Initialized
INFO - 2024-10-12 11:08:42 --> Helper loaded: cookie_helper
INFO - 2024-10-12 11:08:42 --> Final output sent to browser
DEBUG - 2024-10-12 11:08:42 --> Total execution time: 0.0778
INFO - 2024-10-12 11:08:42 --> Config Class Initialized
INFO - 2024-10-12 11:08:42 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:08:42 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:08:42 --> Utf8 Class Initialized
INFO - 2024-10-12 11:08:42 --> URI Class Initialized
INFO - 2024-10-12 11:08:42 --> Router Class Initialized
INFO - 2024-10-12 11:08:42 --> Output Class Initialized
INFO - 2024-10-12 11:08:42 --> Security Class Initialized
DEBUG - 2024-10-12 11:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:08:42 --> Input Class Initialized
INFO - 2024-10-12 11:08:42 --> Language Class Initialized
INFO - 2024-10-12 11:08:42 --> Language Class Initialized
INFO - 2024-10-12 11:08:42 --> Config Class Initialized
INFO - 2024-10-12 11:08:42 --> Loader Class Initialized
INFO - 2024-10-12 11:08:42 --> Helper loaded: url_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: file_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: form_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: my_helper
INFO - 2024-10-12 11:08:42 --> Database Driver Class Initialized
INFO - 2024-10-12 11:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:08:42 --> Controller Class Initialized
INFO - 2024-10-12 11:08:42 --> Helper loaded: cookie_helper
INFO - 2024-10-12 11:08:42 --> Config Class Initialized
INFO - 2024-10-12 11:08:42 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:08:42 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:08:42 --> Utf8 Class Initialized
INFO - 2024-10-12 11:08:42 --> URI Class Initialized
INFO - 2024-10-12 11:08:42 --> Router Class Initialized
INFO - 2024-10-12 11:08:42 --> Output Class Initialized
INFO - 2024-10-12 11:08:42 --> Security Class Initialized
DEBUG - 2024-10-12 11:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:08:42 --> Input Class Initialized
INFO - 2024-10-12 11:08:42 --> Language Class Initialized
INFO - 2024-10-12 11:08:42 --> Language Class Initialized
INFO - 2024-10-12 11:08:42 --> Config Class Initialized
INFO - 2024-10-12 11:08:42 --> Loader Class Initialized
INFO - 2024-10-12 11:08:42 --> Helper loaded: url_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: file_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: form_helper
INFO - 2024-10-12 11:08:42 --> Helper loaded: my_helper
INFO - 2024-10-12 11:08:42 --> Database Driver Class Initialized
INFO - 2024-10-12 11:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:08:42 --> Controller Class Initialized
DEBUG - 2024-10-12 11:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 11:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 11:08:42 --> Final output sent to browser
DEBUG - 2024-10-12 11:08:42 --> Total execution time: 0.0335
INFO - 2024-10-12 11:08:44 --> Config Class Initialized
INFO - 2024-10-12 11:08:44 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:08:44 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:08:44 --> Utf8 Class Initialized
INFO - 2024-10-12 11:08:44 --> URI Class Initialized
INFO - 2024-10-12 11:08:44 --> Router Class Initialized
INFO - 2024-10-12 11:08:44 --> Output Class Initialized
INFO - 2024-10-12 11:08:44 --> Security Class Initialized
DEBUG - 2024-10-12 11:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:08:44 --> Input Class Initialized
INFO - 2024-10-12 11:08:44 --> Language Class Initialized
INFO - 2024-10-12 11:08:44 --> Language Class Initialized
INFO - 2024-10-12 11:08:44 --> Config Class Initialized
INFO - 2024-10-12 11:08:44 --> Loader Class Initialized
INFO - 2024-10-12 11:08:44 --> Helper loaded: url_helper
INFO - 2024-10-12 11:08:44 --> Helper loaded: file_helper
INFO - 2024-10-12 11:08:44 --> Helper loaded: form_helper
INFO - 2024-10-12 11:08:44 --> Helper loaded: my_helper
INFO - 2024-10-12 11:08:44 --> Database Driver Class Initialized
INFO - 2024-10-12 11:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:08:44 --> Controller Class Initialized
DEBUG - 2024-10-12 11:08:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:08:47 --> Final output sent to browser
DEBUG - 2024-10-12 11:08:47 --> Total execution time: 3.2754
INFO - 2024-10-12 11:21:51 --> Config Class Initialized
INFO - 2024-10-12 11:21:51 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:21:51 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:21:51 --> Utf8 Class Initialized
INFO - 2024-10-12 11:21:51 --> URI Class Initialized
INFO - 2024-10-12 11:21:51 --> Router Class Initialized
INFO - 2024-10-12 11:21:51 --> Output Class Initialized
INFO - 2024-10-12 11:21:51 --> Security Class Initialized
DEBUG - 2024-10-12 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:21:51 --> Input Class Initialized
INFO - 2024-10-12 11:21:51 --> Language Class Initialized
INFO - 2024-10-12 11:21:51 --> Language Class Initialized
INFO - 2024-10-12 11:21:51 --> Config Class Initialized
INFO - 2024-10-12 11:21:51 --> Loader Class Initialized
INFO - 2024-10-12 11:21:51 --> Helper loaded: url_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: file_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: form_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: my_helper
INFO - 2024-10-12 11:21:51 --> Database Driver Class Initialized
INFO - 2024-10-12 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:21:51 --> Controller Class Initialized
INFO - 2024-10-12 11:21:51 --> Helper loaded: cookie_helper
INFO - 2024-10-12 11:21:51 --> Final output sent to browser
DEBUG - 2024-10-12 11:21:51 --> Total execution time: 0.0385
INFO - 2024-10-12 11:21:51 --> Config Class Initialized
INFO - 2024-10-12 11:21:51 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:21:51 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:21:51 --> Utf8 Class Initialized
INFO - 2024-10-12 11:21:51 --> URI Class Initialized
INFO - 2024-10-12 11:21:51 --> Router Class Initialized
INFO - 2024-10-12 11:21:51 --> Output Class Initialized
INFO - 2024-10-12 11:21:51 --> Security Class Initialized
DEBUG - 2024-10-12 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:21:51 --> Input Class Initialized
INFO - 2024-10-12 11:21:51 --> Language Class Initialized
INFO - 2024-10-12 11:21:51 --> Language Class Initialized
INFO - 2024-10-12 11:21:51 --> Config Class Initialized
INFO - 2024-10-12 11:21:51 --> Loader Class Initialized
INFO - 2024-10-12 11:21:51 --> Helper loaded: url_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: file_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: form_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: my_helper
INFO - 2024-10-12 11:21:51 --> Database Driver Class Initialized
INFO - 2024-10-12 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:21:51 --> Controller Class Initialized
INFO - 2024-10-12 11:21:51 --> Helper loaded: cookie_helper
INFO - 2024-10-12 11:21:51 --> Config Class Initialized
INFO - 2024-10-12 11:21:51 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:21:51 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:21:51 --> Utf8 Class Initialized
INFO - 2024-10-12 11:21:51 --> URI Class Initialized
INFO - 2024-10-12 11:21:51 --> Router Class Initialized
INFO - 2024-10-12 11:21:51 --> Output Class Initialized
INFO - 2024-10-12 11:21:51 --> Security Class Initialized
DEBUG - 2024-10-12 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:21:51 --> Input Class Initialized
INFO - 2024-10-12 11:21:51 --> Language Class Initialized
INFO - 2024-10-12 11:21:51 --> Language Class Initialized
INFO - 2024-10-12 11:21:51 --> Config Class Initialized
INFO - 2024-10-12 11:21:51 --> Loader Class Initialized
INFO - 2024-10-12 11:21:51 --> Helper loaded: url_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: file_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: form_helper
INFO - 2024-10-12 11:21:51 --> Helper loaded: my_helper
INFO - 2024-10-12 11:21:51 --> Database Driver Class Initialized
INFO - 2024-10-12 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:21:51 --> Controller Class Initialized
DEBUG - 2024-10-12 11:21:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 11:21:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 11:21:51 --> Final output sent to browser
DEBUG - 2024-10-12 11:21:51 --> Total execution time: 0.0437
INFO - 2024-10-12 11:22:37 --> Config Class Initialized
INFO - 2024-10-12 11:22:37 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:22:37 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:22:37 --> Utf8 Class Initialized
INFO - 2024-10-12 11:22:37 --> URI Class Initialized
INFO - 2024-10-12 11:22:37 --> Router Class Initialized
INFO - 2024-10-12 11:22:37 --> Output Class Initialized
INFO - 2024-10-12 11:22:37 --> Security Class Initialized
DEBUG - 2024-10-12 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:22:37 --> Input Class Initialized
INFO - 2024-10-12 11:22:37 --> Language Class Initialized
INFO - 2024-10-12 11:22:37 --> Language Class Initialized
INFO - 2024-10-12 11:22:37 --> Config Class Initialized
INFO - 2024-10-12 11:22:37 --> Loader Class Initialized
INFO - 2024-10-12 11:22:38 --> Helper loaded: url_helper
INFO - 2024-10-12 11:22:38 --> Helper loaded: file_helper
INFO - 2024-10-12 11:22:38 --> Helper loaded: form_helper
INFO - 2024-10-12 11:22:38 --> Helper loaded: my_helper
INFO - 2024-10-12 11:22:38 --> Database Driver Class Initialized
INFO - 2024-10-12 11:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:22:38 --> Controller Class Initialized
DEBUG - 2024-10-12 11:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:22:40 --> Final output sent to browser
DEBUG - 2024-10-12 11:22:40 --> Total execution time: 2.9231
INFO - 2024-10-12 11:23:47 --> Config Class Initialized
INFO - 2024-10-12 11:23:47 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:23:47 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:23:47 --> Utf8 Class Initialized
INFO - 2024-10-12 11:23:47 --> URI Class Initialized
INFO - 2024-10-12 11:23:47 --> Router Class Initialized
INFO - 2024-10-12 11:23:47 --> Output Class Initialized
INFO - 2024-10-12 11:23:47 --> Security Class Initialized
DEBUG - 2024-10-12 11:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:23:47 --> Input Class Initialized
INFO - 2024-10-12 11:23:47 --> Language Class Initialized
INFO - 2024-10-12 11:23:48 --> Language Class Initialized
INFO - 2024-10-12 11:23:48 --> Config Class Initialized
INFO - 2024-10-12 11:23:48 --> Loader Class Initialized
INFO - 2024-10-12 11:23:48 --> Helper loaded: url_helper
INFO - 2024-10-12 11:23:48 --> Helper loaded: file_helper
INFO - 2024-10-12 11:23:48 --> Helper loaded: form_helper
INFO - 2024-10-12 11:23:48 --> Helper loaded: my_helper
INFO - 2024-10-12 11:23:48 --> Database Driver Class Initialized
INFO - 2024-10-12 11:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:23:48 --> Controller Class Initialized
DEBUG - 2024-10-12 11:23:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:23:52 --> Final output sent to browser
DEBUG - 2024-10-12 11:23:52 --> Total execution time: 4.6944
INFO - 2024-10-12 11:24:16 --> Config Class Initialized
INFO - 2024-10-12 11:24:16 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:24:16 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:24:16 --> Utf8 Class Initialized
INFO - 2024-10-12 11:24:16 --> URI Class Initialized
INFO - 2024-10-12 11:24:16 --> Router Class Initialized
INFO - 2024-10-12 11:24:16 --> Output Class Initialized
INFO - 2024-10-12 11:24:16 --> Security Class Initialized
DEBUG - 2024-10-12 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:24:16 --> Input Class Initialized
INFO - 2024-10-12 11:24:16 --> Language Class Initialized
INFO - 2024-10-12 11:24:16 --> Language Class Initialized
INFO - 2024-10-12 11:24:16 --> Config Class Initialized
INFO - 2024-10-12 11:24:16 --> Loader Class Initialized
INFO - 2024-10-12 11:24:16 --> Helper loaded: url_helper
INFO - 2024-10-12 11:24:16 --> Helper loaded: file_helper
INFO - 2024-10-12 11:24:16 --> Helper loaded: form_helper
INFO - 2024-10-12 11:24:16 --> Helper loaded: my_helper
INFO - 2024-10-12 11:24:16 --> Database Driver Class Initialized
INFO - 2024-10-12 11:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:24:16 --> Controller Class Initialized
DEBUG - 2024-10-12 11:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:24:19 --> Final output sent to browser
DEBUG - 2024-10-12 11:24:19 --> Total execution time: 3.0626
INFO - 2024-10-12 11:24:43 --> Config Class Initialized
INFO - 2024-10-12 11:24:43 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:24:43 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:24:43 --> Utf8 Class Initialized
INFO - 2024-10-12 11:24:43 --> URI Class Initialized
INFO - 2024-10-12 11:24:43 --> Router Class Initialized
INFO - 2024-10-12 11:24:43 --> Output Class Initialized
INFO - 2024-10-12 11:24:43 --> Security Class Initialized
DEBUG - 2024-10-12 11:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:24:43 --> Input Class Initialized
INFO - 2024-10-12 11:24:43 --> Language Class Initialized
INFO - 2024-10-12 11:24:43 --> Language Class Initialized
INFO - 2024-10-12 11:24:43 --> Config Class Initialized
INFO - 2024-10-12 11:24:43 --> Loader Class Initialized
INFO - 2024-10-12 11:24:43 --> Helper loaded: url_helper
INFO - 2024-10-12 11:24:43 --> Helper loaded: file_helper
INFO - 2024-10-12 11:24:43 --> Helper loaded: form_helper
INFO - 2024-10-12 11:24:43 --> Helper loaded: my_helper
INFO - 2024-10-12 11:24:43 --> Database Driver Class Initialized
INFO - 2024-10-12 11:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:24:43 --> Controller Class Initialized
DEBUG - 2024-10-12 11:24:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:24:46 --> Final output sent to browser
DEBUG - 2024-10-12 11:24:46 --> Total execution time: 3.1811
INFO - 2024-10-12 11:24:58 --> Config Class Initialized
INFO - 2024-10-12 11:24:58 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:24:58 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:24:58 --> Utf8 Class Initialized
INFO - 2024-10-12 11:24:58 --> URI Class Initialized
INFO - 2024-10-12 11:24:58 --> Router Class Initialized
INFO - 2024-10-12 11:24:58 --> Output Class Initialized
INFO - 2024-10-12 11:24:58 --> Security Class Initialized
DEBUG - 2024-10-12 11:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:24:58 --> Input Class Initialized
INFO - 2024-10-12 11:24:58 --> Language Class Initialized
INFO - 2024-10-12 11:24:58 --> Language Class Initialized
INFO - 2024-10-12 11:24:58 --> Config Class Initialized
INFO - 2024-10-12 11:24:58 --> Loader Class Initialized
INFO - 2024-10-12 11:24:58 --> Helper loaded: url_helper
INFO - 2024-10-12 11:24:58 --> Helper loaded: file_helper
INFO - 2024-10-12 11:24:58 --> Helper loaded: form_helper
INFO - 2024-10-12 11:24:58 --> Helper loaded: my_helper
INFO - 2024-10-12 11:24:58 --> Database Driver Class Initialized
INFO - 2024-10-12 11:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:24:58 --> Controller Class Initialized
DEBUG - 2024-10-12 11:24:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:25:01 --> Final output sent to browser
DEBUG - 2024-10-12 11:25:01 --> Total execution time: 3.4720
INFO - 2024-10-12 11:25:40 --> Config Class Initialized
INFO - 2024-10-12 11:25:40 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:25:40 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:25:40 --> Utf8 Class Initialized
INFO - 2024-10-12 11:25:40 --> URI Class Initialized
INFO - 2024-10-12 11:25:40 --> Router Class Initialized
INFO - 2024-10-12 11:25:40 --> Output Class Initialized
INFO - 2024-10-12 11:25:40 --> Security Class Initialized
DEBUG - 2024-10-12 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:25:40 --> Input Class Initialized
INFO - 2024-10-12 11:25:40 --> Language Class Initialized
INFO - 2024-10-12 11:25:40 --> Language Class Initialized
INFO - 2024-10-12 11:25:40 --> Config Class Initialized
INFO - 2024-10-12 11:25:40 --> Loader Class Initialized
INFO - 2024-10-12 11:25:40 --> Helper loaded: url_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: file_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: form_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: my_helper
INFO - 2024-10-12 11:25:40 --> Database Driver Class Initialized
INFO - 2024-10-12 11:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:25:40 --> Controller Class Initialized
INFO - 2024-10-12 11:25:40 --> Helper loaded: cookie_helper
INFO - 2024-10-12 11:25:40 --> Final output sent to browser
DEBUG - 2024-10-12 11:25:40 --> Total execution time: 0.0480
INFO - 2024-10-12 11:25:40 --> Config Class Initialized
INFO - 2024-10-12 11:25:40 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:25:40 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:25:40 --> Utf8 Class Initialized
INFO - 2024-10-12 11:25:40 --> URI Class Initialized
INFO - 2024-10-12 11:25:40 --> Router Class Initialized
INFO - 2024-10-12 11:25:40 --> Output Class Initialized
INFO - 2024-10-12 11:25:40 --> Security Class Initialized
DEBUG - 2024-10-12 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:25:40 --> Input Class Initialized
INFO - 2024-10-12 11:25:40 --> Language Class Initialized
INFO - 2024-10-12 11:25:40 --> Language Class Initialized
INFO - 2024-10-12 11:25:40 --> Config Class Initialized
INFO - 2024-10-12 11:25:40 --> Loader Class Initialized
INFO - 2024-10-12 11:25:40 --> Helper loaded: url_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: file_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: form_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: my_helper
INFO - 2024-10-12 11:25:40 --> Database Driver Class Initialized
INFO - 2024-10-12 11:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:25:40 --> Controller Class Initialized
INFO - 2024-10-12 11:25:40 --> Helper loaded: cookie_helper
INFO - 2024-10-12 11:25:40 --> Config Class Initialized
INFO - 2024-10-12 11:25:40 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:25:40 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:25:40 --> Utf8 Class Initialized
INFO - 2024-10-12 11:25:40 --> URI Class Initialized
INFO - 2024-10-12 11:25:40 --> Router Class Initialized
INFO - 2024-10-12 11:25:40 --> Output Class Initialized
INFO - 2024-10-12 11:25:40 --> Security Class Initialized
DEBUG - 2024-10-12 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:25:40 --> Input Class Initialized
INFO - 2024-10-12 11:25:40 --> Language Class Initialized
INFO - 2024-10-12 11:25:40 --> Language Class Initialized
INFO - 2024-10-12 11:25:40 --> Config Class Initialized
INFO - 2024-10-12 11:25:40 --> Loader Class Initialized
INFO - 2024-10-12 11:25:40 --> Helper loaded: url_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: file_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: form_helper
INFO - 2024-10-12 11:25:40 --> Helper loaded: my_helper
INFO - 2024-10-12 11:25:40 --> Database Driver Class Initialized
INFO - 2024-10-12 11:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:25:40 --> Controller Class Initialized
DEBUG - 2024-10-12 11:25:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 11:25:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 11:25:40 --> Final output sent to browser
DEBUG - 2024-10-12 11:25:40 --> Total execution time: 0.0420
INFO - 2024-10-12 11:25:51 --> Config Class Initialized
INFO - 2024-10-12 11:25:51 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:25:51 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:25:51 --> Utf8 Class Initialized
INFO - 2024-10-12 11:25:51 --> URI Class Initialized
INFO - 2024-10-12 11:25:51 --> Router Class Initialized
INFO - 2024-10-12 11:25:51 --> Output Class Initialized
INFO - 2024-10-12 11:25:51 --> Security Class Initialized
DEBUG - 2024-10-12 11:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:25:51 --> Input Class Initialized
INFO - 2024-10-12 11:25:51 --> Language Class Initialized
INFO - 2024-10-12 11:25:51 --> Language Class Initialized
INFO - 2024-10-12 11:25:51 --> Config Class Initialized
INFO - 2024-10-12 11:25:51 --> Loader Class Initialized
INFO - 2024-10-12 11:25:51 --> Helper loaded: url_helper
INFO - 2024-10-12 11:25:51 --> Helper loaded: file_helper
INFO - 2024-10-12 11:25:51 --> Helper loaded: form_helper
INFO - 2024-10-12 11:25:51 --> Helper loaded: my_helper
INFO - 2024-10-12 11:25:51 --> Database Driver Class Initialized
INFO - 2024-10-12 11:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:25:51 --> Controller Class Initialized
DEBUG - 2024-10-12 11:25:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:25:54 --> Final output sent to browser
DEBUG - 2024-10-12 11:25:54 --> Total execution time: 3.2071
INFO - 2024-10-12 11:26:18 --> Config Class Initialized
INFO - 2024-10-12 11:26:18 --> Hooks Class Initialized
DEBUG - 2024-10-12 11:26:18 --> UTF-8 Support Enabled
INFO - 2024-10-12 11:26:18 --> Utf8 Class Initialized
INFO - 2024-10-12 11:26:18 --> URI Class Initialized
INFO - 2024-10-12 11:26:18 --> Router Class Initialized
INFO - 2024-10-12 11:26:18 --> Output Class Initialized
INFO - 2024-10-12 11:26:18 --> Security Class Initialized
DEBUG - 2024-10-12 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 11:26:18 --> Input Class Initialized
INFO - 2024-10-12 11:26:18 --> Language Class Initialized
INFO - 2024-10-12 11:26:18 --> Language Class Initialized
INFO - 2024-10-12 11:26:18 --> Config Class Initialized
INFO - 2024-10-12 11:26:18 --> Loader Class Initialized
INFO - 2024-10-12 11:26:18 --> Helper loaded: url_helper
INFO - 2024-10-12 11:26:18 --> Helper loaded: file_helper
INFO - 2024-10-12 11:26:18 --> Helper loaded: form_helper
INFO - 2024-10-12 11:26:18 --> Helper loaded: my_helper
INFO - 2024-10-12 11:26:18 --> Database Driver Class Initialized
INFO - 2024-10-12 11:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 11:26:18 --> Controller Class Initialized
DEBUG - 2024-10-12 11:26:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 11:26:21 --> Final output sent to browser
DEBUG - 2024-10-12 11:26:21 --> Total execution time: 3.0999
INFO - 2024-10-12 14:08:23 --> Config Class Initialized
INFO - 2024-10-12 14:08:23 --> Hooks Class Initialized
DEBUG - 2024-10-12 14:08:23 --> UTF-8 Support Enabled
INFO - 2024-10-12 14:08:23 --> Utf8 Class Initialized
INFO - 2024-10-12 14:08:23 --> URI Class Initialized
INFO - 2024-10-12 14:08:23 --> Router Class Initialized
INFO - 2024-10-12 14:08:23 --> Output Class Initialized
INFO - 2024-10-12 14:08:23 --> Security Class Initialized
DEBUG - 2024-10-12 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 14:08:23 --> Input Class Initialized
INFO - 2024-10-12 14:08:23 --> Language Class Initialized
INFO - 2024-10-12 14:08:23 --> Language Class Initialized
INFO - 2024-10-12 14:08:23 --> Config Class Initialized
INFO - 2024-10-12 14:08:23 --> Loader Class Initialized
INFO - 2024-10-12 14:08:23 --> Helper loaded: url_helper
INFO - 2024-10-12 14:08:23 --> Helper loaded: file_helper
INFO - 2024-10-12 14:08:23 --> Helper loaded: form_helper
INFO - 2024-10-12 14:08:23 --> Helper loaded: my_helper
INFO - 2024-10-12 14:08:23 --> Database Driver Class Initialized
INFO - 2024-10-12 14:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 14:08:23 --> Controller Class Initialized
INFO - 2024-10-12 14:08:23 --> Helper loaded: cookie_helper
INFO - 2024-10-12 14:08:23 --> Final output sent to browser
DEBUG - 2024-10-12 14:08:23 --> Total execution time: 0.0663
INFO - 2024-10-12 14:08:24 --> Config Class Initialized
INFO - 2024-10-12 14:08:24 --> Hooks Class Initialized
DEBUG - 2024-10-12 14:08:24 --> UTF-8 Support Enabled
INFO - 2024-10-12 14:08:24 --> Utf8 Class Initialized
INFO - 2024-10-12 14:08:24 --> URI Class Initialized
INFO - 2024-10-12 14:08:24 --> Router Class Initialized
INFO - 2024-10-12 14:08:24 --> Output Class Initialized
INFO - 2024-10-12 14:08:24 --> Security Class Initialized
DEBUG - 2024-10-12 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 14:08:24 --> Input Class Initialized
INFO - 2024-10-12 14:08:24 --> Language Class Initialized
INFO - 2024-10-12 14:08:24 --> Language Class Initialized
INFO - 2024-10-12 14:08:24 --> Config Class Initialized
INFO - 2024-10-12 14:08:24 --> Loader Class Initialized
INFO - 2024-10-12 14:08:24 --> Helper loaded: url_helper
INFO - 2024-10-12 14:08:24 --> Helper loaded: file_helper
INFO - 2024-10-12 14:08:24 --> Helper loaded: form_helper
INFO - 2024-10-12 14:08:24 --> Helper loaded: my_helper
INFO - 2024-10-12 14:08:24 --> Database Driver Class Initialized
INFO - 2024-10-12 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 14:08:24 --> Controller Class Initialized
INFO - 2024-10-12 14:08:24 --> Helper loaded: cookie_helper
INFO - 2024-10-12 14:08:24 --> Config Class Initialized
INFO - 2024-10-12 14:08:24 --> Hooks Class Initialized
DEBUG - 2024-10-12 14:08:24 --> UTF-8 Support Enabled
INFO - 2024-10-12 14:08:24 --> Utf8 Class Initialized
INFO - 2024-10-12 14:08:24 --> URI Class Initialized
INFO - 2024-10-12 14:08:24 --> Router Class Initialized
INFO - 2024-10-12 14:08:24 --> Output Class Initialized
INFO - 2024-10-12 14:08:24 --> Security Class Initialized
DEBUG - 2024-10-12 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 14:08:24 --> Input Class Initialized
INFO - 2024-10-12 14:08:24 --> Language Class Initialized
INFO - 2024-10-12 14:08:24 --> Language Class Initialized
INFO - 2024-10-12 14:08:24 --> Config Class Initialized
INFO - 2024-10-12 14:08:24 --> Loader Class Initialized
INFO - 2024-10-12 14:08:24 --> Helper loaded: url_helper
INFO - 2024-10-12 14:08:24 --> Helper loaded: file_helper
INFO - 2024-10-12 14:08:24 --> Helper loaded: form_helper
INFO - 2024-10-12 14:08:24 --> Helper loaded: my_helper
INFO - 2024-10-12 14:08:24 --> Database Driver Class Initialized
INFO - 2024-10-12 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 14:08:24 --> Controller Class Initialized
DEBUG - 2024-10-12 14:08:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 14:08:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 14:08:24 --> Final output sent to browser
DEBUG - 2024-10-12 14:08:24 --> Total execution time: 0.0773
INFO - 2024-10-12 14:08:33 --> Config Class Initialized
INFO - 2024-10-12 14:08:33 --> Hooks Class Initialized
DEBUG - 2024-10-12 14:08:33 --> UTF-8 Support Enabled
INFO - 2024-10-12 14:08:33 --> Utf8 Class Initialized
INFO - 2024-10-12 14:08:33 --> URI Class Initialized
INFO - 2024-10-12 14:08:33 --> Router Class Initialized
INFO - 2024-10-12 14:08:33 --> Output Class Initialized
INFO - 2024-10-12 14:08:33 --> Security Class Initialized
DEBUG - 2024-10-12 14:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 14:08:33 --> Input Class Initialized
INFO - 2024-10-12 14:08:33 --> Language Class Initialized
INFO - 2024-10-12 14:08:33 --> Language Class Initialized
INFO - 2024-10-12 14:08:33 --> Config Class Initialized
INFO - 2024-10-12 14:08:33 --> Loader Class Initialized
INFO - 2024-10-12 14:08:33 --> Helper loaded: url_helper
INFO - 2024-10-12 14:08:33 --> Helper loaded: file_helper
INFO - 2024-10-12 14:08:33 --> Helper loaded: form_helper
INFO - 2024-10-12 14:08:33 --> Helper loaded: my_helper
INFO - 2024-10-12 14:08:33 --> Database Driver Class Initialized
INFO - 2024-10-12 14:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 14:08:33 --> Controller Class Initialized
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-12 14:08:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-12 14:08:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 14:08:36 --> Final output sent to browser
DEBUG - 2024-10-12 14:08:36 --> Total execution time: 2.8130
INFO - 2024-10-12 14:08:52 --> Config Class Initialized
INFO - 2024-10-12 14:08:52 --> Hooks Class Initialized
DEBUG - 2024-10-12 14:08:52 --> UTF-8 Support Enabled
INFO - 2024-10-12 14:08:52 --> Utf8 Class Initialized
INFO - 2024-10-12 14:08:52 --> URI Class Initialized
INFO - 2024-10-12 14:08:52 --> Router Class Initialized
INFO - 2024-10-12 14:08:52 --> Output Class Initialized
INFO - 2024-10-12 14:08:52 --> Security Class Initialized
DEBUG - 2024-10-12 14:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 14:08:52 --> Input Class Initialized
INFO - 2024-10-12 14:08:52 --> Language Class Initialized
INFO - 2024-10-12 14:08:52 --> Language Class Initialized
INFO - 2024-10-12 14:08:52 --> Config Class Initialized
INFO - 2024-10-12 14:08:52 --> Loader Class Initialized
INFO - 2024-10-12 14:08:52 --> Helper loaded: url_helper
INFO - 2024-10-12 14:08:52 --> Helper loaded: file_helper
INFO - 2024-10-12 14:08:52 --> Helper loaded: form_helper
INFO - 2024-10-12 14:08:52 --> Helper loaded: my_helper
INFO - 2024-10-12 14:08:52 --> Database Driver Class Initialized
INFO - 2024-10-12 14:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 14:08:52 --> Controller Class Initialized
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-12 14:08:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-12 14:08:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-12 14:08:55 --> Final output sent to browser
DEBUG - 2024-10-12 14:08:55 --> Total execution time: 2.7119
INFO - 2024-10-12 14:09:11 --> Config Class Initialized
INFO - 2024-10-12 14:09:11 --> Hooks Class Initialized
DEBUG - 2024-10-12 14:09:11 --> UTF-8 Support Enabled
INFO - 2024-10-12 14:09:11 --> Utf8 Class Initialized
INFO - 2024-10-12 14:09:11 --> URI Class Initialized
INFO - 2024-10-12 14:09:11 --> Router Class Initialized
INFO - 2024-10-12 14:09:11 --> Output Class Initialized
INFO - 2024-10-12 14:09:11 --> Security Class Initialized
DEBUG - 2024-10-12 14:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 14:09:11 --> Input Class Initialized
INFO - 2024-10-12 14:09:11 --> Language Class Initialized
INFO - 2024-10-12 14:09:11 --> Language Class Initialized
INFO - 2024-10-12 14:09:11 --> Config Class Initialized
INFO - 2024-10-12 14:09:11 --> Loader Class Initialized
INFO - 2024-10-12 14:09:11 --> Helper loaded: url_helper
INFO - 2024-10-12 14:09:11 --> Helper loaded: file_helper
INFO - 2024-10-12 14:09:11 --> Helper loaded: form_helper
INFO - 2024-10-12 14:09:11 --> Helper loaded: my_helper
INFO - 2024-10-12 14:09:11 --> Database Driver Class Initialized
INFO - 2024-10-12 14:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 14:09:11 --> Controller Class Initialized
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-12 14:09:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-12 14:09:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 14:09:14 --> Final output sent to browser
DEBUG - 2024-10-12 14:09:14 --> Total execution time: 3.1268
INFO - 2024-10-12 17:33:20 --> Config Class Initialized
INFO - 2024-10-12 17:33:20 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:33:20 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:33:20 --> Utf8 Class Initialized
INFO - 2024-10-12 17:33:20 --> URI Class Initialized
INFO - 2024-10-12 17:33:20 --> Router Class Initialized
INFO - 2024-10-12 17:33:20 --> Output Class Initialized
INFO - 2024-10-12 17:33:20 --> Security Class Initialized
DEBUG - 2024-10-12 17:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:33:20 --> Input Class Initialized
INFO - 2024-10-12 17:33:20 --> Language Class Initialized
INFO - 2024-10-12 17:33:20 --> Language Class Initialized
INFO - 2024-10-12 17:33:20 --> Config Class Initialized
INFO - 2024-10-12 17:33:20 --> Loader Class Initialized
INFO - 2024-10-12 17:33:20 --> Helper loaded: url_helper
INFO - 2024-10-12 17:33:20 --> Helper loaded: file_helper
INFO - 2024-10-12 17:33:20 --> Helper loaded: form_helper
INFO - 2024-10-12 17:33:20 --> Helper loaded: my_helper
INFO - 2024-10-12 17:33:20 --> Database Driver Class Initialized
INFO - 2024-10-12 17:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:33:20 --> Controller Class Initialized
INFO - 2024-10-12 17:33:20 --> Helper loaded: cookie_helper
INFO - 2024-10-12 17:33:20 --> Final output sent to browser
DEBUG - 2024-10-12 17:33:20 --> Total execution time: 0.0832
INFO - 2024-10-12 17:33:21 --> Config Class Initialized
INFO - 2024-10-12 17:33:21 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:33:21 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:33:21 --> Utf8 Class Initialized
INFO - 2024-10-12 17:33:21 --> URI Class Initialized
INFO - 2024-10-12 17:33:21 --> Router Class Initialized
INFO - 2024-10-12 17:33:21 --> Output Class Initialized
INFO - 2024-10-12 17:33:21 --> Security Class Initialized
DEBUG - 2024-10-12 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:33:21 --> Input Class Initialized
INFO - 2024-10-12 17:33:21 --> Language Class Initialized
INFO - 2024-10-12 17:33:21 --> Language Class Initialized
INFO - 2024-10-12 17:33:21 --> Config Class Initialized
INFO - 2024-10-12 17:33:21 --> Loader Class Initialized
INFO - 2024-10-12 17:33:21 --> Helper loaded: url_helper
INFO - 2024-10-12 17:33:21 --> Helper loaded: file_helper
INFO - 2024-10-12 17:33:21 --> Helper loaded: form_helper
INFO - 2024-10-12 17:33:21 --> Helper loaded: my_helper
INFO - 2024-10-12 17:33:21 --> Database Driver Class Initialized
INFO - 2024-10-12 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:33:21 --> Controller Class Initialized
INFO - 2024-10-12 17:33:21 --> Helper loaded: cookie_helper
INFO - 2024-10-12 17:33:21 --> Config Class Initialized
INFO - 2024-10-12 17:33:21 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:33:21 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:33:21 --> Utf8 Class Initialized
INFO - 2024-10-12 17:33:21 --> URI Class Initialized
INFO - 2024-10-12 17:33:21 --> Router Class Initialized
INFO - 2024-10-12 17:33:21 --> Output Class Initialized
INFO - 2024-10-12 17:33:21 --> Security Class Initialized
DEBUG - 2024-10-12 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:33:21 --> Input Class Initialized
INFO - 2024-10-12 17:33:21 --> Language Class Initialized
INFO - 2024-10-12 17:33:21 --> Language Class Initialized
INFO - 2024-10-12 17:33:21 --> Config Class Initialized
INFO - 2024-10-12 17:33:21 --> Loader Class Initialized
INFO - 2024-10-12 17:33:21 --> Helper loaded: url_helper
INFO - 2024-10-12 17:33:21 --> Helper loaded: file_helper
INFO - 2024-10-12 17:33:21 --> Helper loaded: form_helper
INFO - 2024-10-12 17:33:21 --> Helper loaded: my_helper
INFO - 2024-10-12 17:33:21 --> Database Driver Class Initialized
INFO - 2024-10-12 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:33:21 --> Controller Class Initialized
DEBUG - 2024-10-12 17:33:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-12 17:33:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-12 17:33:21 --> Final output sent to browser
DEBUG - 2024-10-12 17:33:21 --> Total execution time: 0.0387
INFO - 2024-10-12 17:33:40 --> Config Class Initialized
INFO - 2024-10-12 17:33:40 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:33:40 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:33:40 --> Utf8 Class Initialized
INFO - 2024-10-12 17:33:40 --> URI Class Initialized
INFO - 2024-10-12 17:33:40 --> Router Class Initialized
INFO - 2024-10-12 17:33:40 --> Output Class Initialized
INFO - 2024-10-12 17:33:40 --> Security Class Initialized
DEBUG - 2024-10-12 17:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:33:40 --> Input Class Initialized
INFO - 2024-10-12 17:33:40 --> Language Class Initialized
INFO - 2024-10-12 17:33:40 --> Language Class Initialized
INFO - 2024-10-12 17:33:40 --> Config Class Initialized
INFO - 2024-10-12 17:33:40 --> Loader Class Initialized
INFO - 2024-10-12 17:33:40 --> Helper loaded: url_helper
INFO - 2024-10-12 17:33:40 --> Helper loaded: file_helper
INFO - 2024-10-12 17:33:40 --> Helper loaded: form_helper
INFO - 2024-10-12 17:33:40 --> Helper loaded: my_helper
INFO - 2024-10-12 17:33:40 --> Database Driver Class Initialized
INFO - 2024-10-12 17:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:33:40 --> Controller Class Initialized
DEBUG - 2024-10-12 17:33:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 17:33:44 --> Final output sent to browser
DEBUG - 2024-10-12 17:33:44 --> Total execution time: 3.2451
INFO - 2024-10-12 17:34:34 --> Config Class Initialized
INFO - 2024-10-12 17:34:34 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:34:34 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:34:34 --> Utf8 Class Initialized
INFO - 2024-10-12 17:34:34 --> URI Class Initialized
INFO - 2024-10-12 17:34:34 --> Router Class Initialized
INFO - 2024-10-12 17:34:34 --> Output Class Initialized
INFO - 2024-10-12 17:34:34 --> Security Class Initialized
DEBUG - 2024-10-12 17:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:34:34 --> Input Class Initialized
INFO - 2024-10-12 17:34:34 --> Language Class Initialized
INFO - 2024-10-12 17:34:34 --> Language Class Initialized
INFO - 2024-10-12 17:34:34 --> Config Class Initialized
INFO - 2024-10-12 17:34:34 --> Loader Class Initialized
INFO - 2024-10-12 17:34:34 --> Helper loaded: url_helper
INFO - 2024-10-12 17:34:34 --> Helper loaded: file_helper
INFO - 2024-10-12 17:34:34 --> Helper loaded: form_helper
INFO - 2024-10-12 17:34:34 --> Helper loaded: my_helper
INFO - 2024-10-12 17:34:34 --> Database Driver Class Initialized
INFO - 2024-10-12 17:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:34:34 --> Controller Class Initialized
DEBUG - 2024-10-12 17:34:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 17:34:37 --> Final output sent to browser
DEBUG - 2024-10-12 17:34:37 --> Total execution time: 3.2560
INFO - 2024-10-12 17:34:48 --> Config Class Initialized
INFO - 2024-10-12 17:34:48 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:34:48 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:34:48 --> Utf8 Class Initialized
INFO - 2024-10-12 17:34:48 --> URI Class Initialized
INFO - 2024-10-12 17:34:48 --> Router Class Initialized
INFO - 2024-10-12 17:34:48 --> Output Class Initialized
INFO - 2024-10-12 17:34:48 --> Security Class Initialized
DEBUG - 2024-10-12 17:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:34:48 --> Input Class Initialized
INFO - 2024-10-12 17:34:48 --> Language Class Initialized
INFO - 2024-10-12 17:34:48 --> Language Class Initialized
INFO - 2024-10-12 17:34:48 --> Config Class Initialized
INFO - 2024-10-12 17:34:48 --> Loader Class Initialized
INFO - 2024-10-12 17:34:48 --> Helper loaded: url_helper
INFO - 2024-10-12 17:34:48 --> Helper loaded: file_helper
INFO - 2024-10-12 17:34:48 --> Helper loaded: form_helper
INFO - 2024-10-12 17:34:48 --> Helper loaded: my_helper
INFO - 2024-10-12 17:34:48 --> Database Driver Class Initialized
INFO - 2024-10-12 17:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:34:48 --> Controller Class Initialized
DEBUG - 2024-10-12 17:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 17:34:52 --> Final output sent to browser
DEBUG - 2024-10-12 17:34:52 --> Total execution time: 3.2036
INFO - 2024-10-12 17:35:23 --> Config Class Initialized
INFO - 2024-10-12 17:35:23 --> Hooks Class Initialized
DEBUG - 2024-10-12 17:35:23 --> UTF-8 Support Enabled
INFO - 2024-10-12 17:35:23 --> Utf8 Class Initialized
INFO - 2024-10-12 17:35:23 --> URI Class Initialized
INFO - 2024-10-12 17:35:23 --> Router Class Initialized
INFO - 2024-10-12 17:35:23 --> Output Class Initialized
INFO - 2024-10-12 17:35:23 --> Security Class Initialized
DEBUG - 2024-10-12 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 17:35:23 --> Input Class Initialized
INFO - 2024-10-12 17:35:23 --> Language Class Initialized
INFO - 2024-10-12 17:35:23 --> Language Class Initialized
INFO - 2024-10-12 17:35:23 --> Config Class Initialized
INFO - 2024-10-12 17:35:23 --> Loader Class Initialized
INFO - 2024-10-12 17:35:23 --> Helper loaded: url_helper
INFO - 2024-10-12 17:35:23 --> Helper loaded: file_helper
INFO - 2024-10-12 17:35:23 --> Helper loaded: form_helper
INFO - 2024-10-12 17:35:23 --> Helper loaded: my_helper
INFO - 2024-10-12 17:35:23 --> Database Driver Class Initialized
INFO - 2024-10-12 17:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 17:35:23 --> Controller Class Initialized
DEBUG - 2024-10-12 17:35:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-12 17:35:26 --> Final output sent to browser
DEBUG - 2024-10-12 17:35:26 --> Total execution time: 3.5341
