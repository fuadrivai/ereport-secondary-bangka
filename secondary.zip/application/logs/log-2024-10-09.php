<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-09 08:18:13 --> Config Class Initialized
INFO - 2024-10-09 08:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 08:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 08:18:13 --> Utf8 Class Initialized
INFO - 2024-10-09 08:18:13 --> URI Class Initialized
INFO - 2024-10-09 08:18:13 --> Router Class Initialized
INFO - 2024-10-09 08:18:13 --> Output Class Initialized
INFO - 2024-10-09 08:18:13 --> Security Class Initialized
DEBUG - 2024-10-09 08:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 08:18:13 --> Input Class Initialized
INFO - 2024-10-09 08:18:13 --> Language Class Initialized
INFO - 2024-10-09 08:18:13 --> Language Class Initialized
INFO - 2024-10-09 08:18:13 --> Config Class Initialized
INFO - 2024-10-09 08:18:13 --> Loader Class Initialized
INFO - 2024-10-09 08:18:13 --> Helper loaded: url_helper
INFO - 2024-10-09 08:18:13 --> Helper loaded: file_helper
INFO - 2024-10-09 08:18:13 --> Helper loaded: form_helper
INFO - 2024-10-09 08:18:13 --> Helper loaded: my_helper
INFO - 2024-10-09 08:18:13 --> Database Driver Class Initialized
INFO - 2024-10-09 08:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 08:18:13 --> Controller Class Initialized
INFO - 2024-10-09 08:18:13 --> Helper loaded: cookie_helper
INFO - 2024-10-09 08:18:13 --> Final output sent to browser
DEBUG - 2024-10-09 08:18:13 --> Total execution time: 0.0643
INFO - 2024-10-09 08:18:13 --> Config Class Initialized
INFO - 2024-10-09 08:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 08:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 08:18:13 --> Utf8 Class Initialized
INFO - 2024-10-09 08:18:13 --> URI Class Initialized
INFO - 2024-10-09 08:18:13 --> Router Class Initialized
INFO - 2024-10-09 08:18:13 --> Output Class Initialized
INFO - 2024-10-09 08:18:13 --> Security Class Initialized
DEBUG - 2024-10-09 08:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 08:18:13 --> Input Class Initialized
INFO - 2024-10-09 08:18:13 --> Language Class Initialized
INFO - 2024-10-09 08:18:13 --> Language Class Initialized
INFO - 2024-10-09 08:18:13 --> Config Class Initialized
INFO - 2024-10-09 08:18:13 --> Loader Class Initialized
INFO - 2024-10-09 08:18:13 --> Helper loaded: url_helper
INFO - 2024-10-09 08:18:13 --> Helper loaded: file_helper
INFO - 2024-10-09 08:18:13 --> Helper loaded: form_helper
INFO - 2024-10-09 08:18:13 --> Helper loaded: my_helper
INFO - 2024-10-09 08:18:13 --> Database Driver Class Initialized
INFO - 2024-10-09 08:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 08:18:13 --> Controller Class Initialized
DEBUG - 2024-10-09 08:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 08:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 08:18:13 --> Final output sent to browser
DEBUG - 2024-10-09 08:18:13 --> Total execution time: 0.0409
INFO - 2024-10-09 08:18:15 --> Config Class Initialized
INFO - 2024-10-09 08:18:15 --> Hooks Class Initialized
DEBUG - 2024-10-09 08:18:15 --> UTF-8 Support Enabled
INFO - 2024-10-09 08:18:15 --> Utf8 Class Initialized
INFO - 2024-10-09 08:18:15 --> URI Class Initialized
INFO - 2024-10-09 08:18:15 --> Router Class Initialized
INFO - 2024-10-09 08:18:15 --> Output Class Initialized
INFO - 2024-10-09 08:18:15 --> Security Class Initialized
DEBUG - 2024-10-09 08:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 08:18:15 --> Input Class Initialized
INFO - 2024-10-09 08:18:15 --> Language Class Initialized
INFO - 2024-10-09 08:18:15 --> Language Class Initialized
INFO - 2024-10-09 08:18:15 --> Config Class Initialized
INFO - 2024-10-09 08:18:15 --> Loader Class Initialized
INFO - 2024-10-09 08:18:15 --> Helper loaded: url_helper
INFO - 2024-10-09 08:18:15 --> Helper loaded: file_helper
INFO - 2024-10-09 08:18:15 --> Helper loaded: form_helper
INFO - 2024-10-09 08:18:15 --> Helper loaded: my_helper
INFO - 2024-10-09 08:18:15 --> Database Driver Class Initialized
INFO - 2024-10-09 08:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 08:18:15 --> Controller Class Initialized
DEBUG - 2024-10-09 08:18:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 08:18:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 08:18:15 --> Final output sent to browser
DEBUG - 2024-10-09 08:18:15 --> Total execution time: 0.0362
INFO - 2024-10-09 08:18:32 --> Config Class Initialized
INFO - 2024-10-09 08:18:32 --> Hooks Class Initialized
DEBUG - 2024-10-09 08:18:32 --> UTF-8 Support Enabled
INFO - 2024-10-09 08:18:32 --> Utf8 Class Initialized
INFO - 2024-10-09 08:18:32 --> URI Class Initialized
INFO - 2024-10-09 08:18:32 --> Router Class Initialized
INFO - 2024-10-09 08:18:32 --> Output Class Initialized
INFO - 2024-10-09 08:18:32 --> Security Class Initialized
DEBUG - 2024-10-09 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 08:18:32 --> Input Class Initialized
INFO - 2024-10-09 08:18:32 --> Language Class Initialized
INFO - 2024-10-09 08:18:32 --> Language Class Initialized
INFO - 2024-10-09 08:18:32 --> Config Class Initialized
INFO - 2024-10-09 08:18:32 --> Loader Class Initialized
INFO - 2024-10-09 08:18:32 --> Helper loaded: url_helper
INFO - 2024-10-09 08:18:32 --> Helper loaded: file_helper
INFO - 2024-10-09 08:18:32 --> Helper loaded: form_helper
INFO - 2024-10-09 08:18:32 --> Helper loaded: my_helper
INFO - 2024-10-09 08:18:32 --> Database Driver Class Initialized
INFO - 2024-10-09 08:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 08:18:32 --> Controller Class Initialized
DEBUG - 2024-10-09 08:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 08:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 08:18:32 --> Final output sent to browser
DEBUG - 2024-10-09 08:18:32 --> Total execution time: 0.0329
INFO - 2024-10-09 09:19:03 --> Config Class Initialized
INFO - 2024-10-09 09:19:03 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:03 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:03 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:03 --> URI Class Initialized
INFO - 2024-10-09 09:19:03 --> Router Class Initialized
INFO - 2024-10-09 09:19:03 --> Output Class Initialized
INFO - 2024-10-09 09:19:03 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:03 --> Input Class Initialized
INFO - 2024-10-09 09:19:03 --> Language Class Initialized
INFO - 2024-10-09 09:19:03 --> Language Class Initialized
INFO - 2024-10-09 09:19:03 --> Config Class Initialized
INFO - 2024-10-09 09:19:03 --> Loader Class Initialized
INFO - 2024-10-09 09:19:03 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:03 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:03 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:03 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:03 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:03 --> Controller Class Initialized
DEBUG - 2024-10-09 09:19:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:19:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:19:03 --> Final output sent to browser
DEBUG - 2024-10-09 09:19:03 --> Total execution time: 0.0529
INFO - 2024-10-09 09:19:12 --> Config Class Initialized
INFO - 2024-10-09 09:19:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:12 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:12 --> URI Class Initialized
INFO - 2024-10-09 09:19:12 --> Router Class Initialized
INFO - 2024-10-09 09:19:12 --> Output Class Initialized
INFO - 2024-10-09 09:19:12 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:12 --> Input Class Initialized
INFO - 2024-10-09 09:19:12 --> Language Class Initialized
INFO - 2024-10-09 09:19:12 --> Language Class Initialized
INFO - 2024-10-09 09:19:12 --> Config Class Initialized
INFO - 2024-10-09 09:19:12 --> Loader Class Initialized
INFO - 2024-10-09 09:19:12 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:12 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:12 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:12 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:12 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:12 --> Controller Class Initialized
INFO - 2024-10-09 09:19:12 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:19:12 --> Final output sent to browser
DEBUG - 2024-10-09 09:19:12 --> Total execution time: 0.0334
INFO - 2024-10-09 09:19:13 --> Config Class Initialized
INFO - 2024-10-09 09:19:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:13 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:13 --> URI Class Initialized
INFO - 2024-10-09 09:19:13 --> Router Class Initialized
INFO - 2024-10-09 09:19:13 --> Output Class Initialized
INFO - 2024-10-09 09:19:13 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:13 --> Input Class Initialized
INFO - 2024-10-09 09:19:13 --> Language Class Initialized
INFO - 2024-10-09 09:19:13 --> Language Class Initialized
INFO - 2024-10-09 09:19:13 --> Config Class Initialized
INFO - 2024-10-09 09:19:13 --> Loader Class Initialized
INFO - 2024-10-09 09:19:13 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:13 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:13 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:13 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:13 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:13 --> Controller Class Initialized
DEBUG - 2024-10-09 09:19:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-09 09:19:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:19:13 --> Final output sent to browser
DEBUG - 2024-10-09 09:19:13 --> Total execution time: 0.0398
INFO - 2024-10-09 09:19:41 --> Config Class Initialized
INFO - 2024-10-09 09:19:41 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:41 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:41 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:41 --> URI Class Initialized
INFO - 2024-10-09 09:19:41 --> Router Class Initialized
INFO - 2024-10-09 09:19:41 --> Output Class Initialized
INFO - 2024-10-09 09:19:41 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:41 --> Input Class Initialized
INFO - 2024-10-09 09:19:41 --> Language Class Initialized
INFO - 2024-10-09 09:19:41 --> Language Class Initialized
INFO - 2024-10-09 09:19:41 --> Config Class Initialized
INFO - 2024-10-09 09:19:41 --> Loader Class Initialized
INFO - 2024-10-09 09:19:41 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:41 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:41 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:41 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:41 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:41 --> Controller Class Initialized
INFO - 2024-10-09 09:19:41 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:19:42 --> Config Class Initialized
INFO - 2024-10-09 09:19:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:42 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:42 --> URI Class Initialized
INFO - 2024-10-09 09:19:42 --> Router Class Initialized
INFO - 2024-10-09 09:19:42 --> Output Class Initialized
INFO - 2024-10-09 09:19:42 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:42 --> Input Class Initialized
INFO - 2024-10-09 09:19:42 --> Language Class Initialized
INFO - 2024-10-09 09:19:42 --> Language Class Initialized
INFO - 2024-10-09 09:19:42 --> Config Class Initialized
INFO - 2024-10-09 09:19:42 --> Loader Class Initialized
INFO - 2024-10-09 09:19:42 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:42 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:42 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:42 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:42 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:42 --> Controller Class Initialized
INFO - 2024-10-09 09:19:42 --> Config Class Initialized
INFO - 2024-10-09 09:19:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:42 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:42 --> URI Class Initialized
INFO - 2024-10-09 09:19:42 --> Router Class Initialized
INFO - 2024-10-09 09:19:42 --> Output Class Initialized
INFO - 2024-10-09 09:19:42 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:42 --> Input Class Initialized
INFO - 2024-10-09 09:19:42 --> Language Class Initialized
INFO - 2024-10-09 09:19:42 --> Language Class Initialized
INFO - 2024-10-09 09:19:42 --> Config Class Initialized
INFO - 2024-10-09 09:19:42 --> Loader Class Initialized
INFO - 2024-10-09 09:19:42 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:42 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:42 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:42 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:42 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:42 --> Controller Class Initialized
DEBUG - 2024-10-09 09:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:19:42 --> Final output sent to browser
DEBUG - 2024-10-09 09:19:42 --> Total execution time: 0.0288
INFO - 2024-10-09 09:19:54 --> Config Class Initialized
INFO - 2024-10-09 09:19:54 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:54 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:54 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:54 --> URI Class Initialized
INFO - 2024-10-09 09:19:54 --> Router Class Initialized
INFO - 2024-10-09 09:19:54 --> Output Class Initialized
INFO - 2024-10-09 09:19:54 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:54 --> Input Class Initialized
INFO - 2024-10-09 09:19:54 --> Language Class Initialized
INFO - 2024-10-09 09:19:54 --> Language Class Initialized
INFO - 2024-10-09 09:19:54 --> Config Class Initialized
INFO - 2024-10-09 09:19:54 --> Loader Class Initialized
INFO - 2024-10-09 09:19:54 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:54 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:54 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:54 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:54 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:54 --> Controller Class Initialized
INFO - 2024-10-09 09:19:54 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:19:54 --> Final output sent to browser
DEBUG - 2024-10-09 09:19:54 --> Total execution time: 0.0344
INFO - 2024-10-09 09:19:59 --> Config Class Initialized
INFO - 2024-10-09 09:19:59 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:19:59 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:19:59 --> Utf8 Class Initialized
INFO - 2024-10-09 09:19:59 --> URI Class Initialized
INFO - 2024-10-09 09:19:59 --> Router Class Initialized
INFO - 2024-10-09 09:19:59 --> Output Class Initialized
INFO - 2024-10-09 09:19:59 --> Security Class Initialized
DEBUG - 2024-10-09 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:19:59 --> Input Class Initialized
INFO - 2024-10-09 09:19:59 --> Language Class Initialized
INFO - 2024-10-09 09:19:59 --> Language Class Initialized
INFO - 2024-10-09 09:19:59 --> Config Class Initialized
INFO - 2024-10-09 09:19:59 --> Loader Class Initialized
INFO - 2024-10-09 09:19:59 --> Helper loaded: url_helper
INFO - 2024-10-09 09:19:59 --> Helper loaded: file_helper
INFO - 2024-10-09 09:19:59 --> Helper loaded: form_helper
INFO - 2024-10-09 09:19:59 --> Helper loaded: my_helper
INFO - 2024-10-09 09:19:59 --> Database Driver Class Initialized
INFO - 2024-10-09 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:19:59 --> Controller Class Initialized
DEBUG - 2024-10-09 09:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 09:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:19:59 --> Final output sent to browser
DEBUG - 2024-10-09 09:19:59 --> Total execution time: 0.0404
INFO - 2024-10-09 09:20:07 --> Config Class Initialized
INFO - 2024-10-09 09:20:07 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:20:07 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:20:07 --> Utf8 Class Initialized
INFO - 2024-10-09 09:20:07 --> URI Class Initialized
INFO - 2024-10-09 09:20:07 --> Router Class Initialized
INFO - 2024-10-09 09:20:07 --> Output Class Initialized
INFO - 2024-10-09 09:20:07 --> Security Class Initialized
DEBUG - 2024-10-09 09:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:20:07 --> Input Class Initialized
INFO - 2024-10-09 09:20:07 --> Language Class Initialized
INFO - 2024-10-09 09:20:07 --> Language Class Initialized
INFO - 2024-10-09 09:20:07 --> Config Class Initialized
INFO - 2024-10-09 09:20:07 --> Loader Class Initialized
INFO - 2024-10-09 09:20:07 --> Helper loaded: url_helper
INFO - 2024-10-09 09:20:07 --> Helper loaded: file_helper
INFO - 2024-10-09 09:20:07 --> Helper loaded: form_helper
INFO - 2024-10-09 09:20:07 --> Helper loaded: my_helper
INFO - 2024-10-09 09:20:07 --> Database Driver Class Initialized
INFO - 2024-10-09 09:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:20:07 --> Controller Class Initialized
DEBUG - 2024-10-09 09:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 09:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:20:07 --> Final output sent to browser
DEBUG - 2024-10-09 09:20:07 --> Total execution time: 0.0486
INFO - 2024-10-09 09:20:09 --> Config Class Initialized
INFO - 2024-10-09 09:20:09 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:20:09 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:20:09 --> Utf8 Class Initialized
INFO - 2024-10-09 09:20:09 --> URI Class Initialized
INFO - 2024-10-09 09:20:09 --> Router Class Initialized
INFO - 2024-10-09 09:20:09 --> Output Class Initialized
INFO - 2024-10-09 09:20:09 --> Security Class Initialized
DEBUG - 2024-10-09 09:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:20:09 --> Input Class Initialized
INFO - 2024-10-09 09:20:09 --> Language Class Initialized
INFO - 2024-10-09 09:20:09 --> Language Class Initialized
INFO - 2024-10-09 09:20:09 --> Config Class Initialized
INFO - 2024-10-09 09:20:09 --> Loader Class Initialized
INFO - 2024-10-09 09:20:09 --> Helper loaded: url_helper
INFO - 2024-10-09 09:20:09 --> Helper loaded: file_helper
INFO - 2024-10-09 09:20:09 --> Helper loaded: form_helper
INFO - 2024-10-09 09:20:09 --> Helper loaded: my_helper
INFO - 2024-10-09 09:20:09 --> Database Driver Class Initialized
INFO - 2024-10-09 09:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:20:09 --> Controller Class Initialized
DEBUG - 2024-10-09 09:20:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 09:20:12 --> Final output sent to browser
DEBUG - 2024-10-09 09:20:12 --> Total execution time: 3.3089
INFO - 2024-10-09 09:23:55 --> Config Class Initialized
INFO - 2024-10-09 09:23:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:23:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:23:55 --> Utf8 Class Initialized
INFO - 2024-10-09 09:23:55 --> URI Class Initialized
INFO - 2024-10-09 09:23:55 --> Router Class Initialized
INFO - 2024-10-09 09:23:55 --> Output Class Initialized
INFO - 2024-10-09 09:23:55 --> Security Class Initialized
DEBUG - 2024-10-09 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:23:55 --> Input Class Initialized
INFO - 2024-10-09 09:23:55 --> Language Class Initialized
INFO - 2024-10-09 09:23:55 --> Language Class Initialized
INFO - 2024-10-09 09:23:55 --> Config Class Initialized
INFO - 2024-10-09 09:23:55 --> Loader Class Initialized
INFO - 2024-10-09 09:23:55 --> Helper loaded: url_helper
INFO - 2024-10-09 09:23:55 --> Helper loaded: file_helper
INFO - 2024-10-09 09:23:55 --> Helper loaded: form_helper
INFO - 2024-10-09 09:23:55 --> Helper loaded: my_helper
INFO - 2024-10-09 09:23:55 --> Database Driver Class Initialized
INFO - 2024-10-09 09:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:23:55 --> Controller Class Initialized
INFO - 2024-10-09 09:23:55 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:23:56 --> Config Class Initialized
INFO - 2024-10-09 09:23:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:23:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:23:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:23:56 --> URI Class Initialized
INFO - 2024-10-09 09:23:56 --> Router Class Initialized
INFO - 2024-10-09 09:23:56 --> Output Class Initialized
INFO - 2024-10-09 09:23:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:23:56 --> Input Class Initialized
INFO - 2024-10-09 09:23:56 --> Language Class Initialized
INFO - 2024-10-09 09:23:56 --> Language Class Initialized
INFO - 2024-10-09 09:23:56 --> Config Class Initialized
INFO - 2024-10-09 09:23:56 --> Loader Class Initialized
INFO - 2024-10-09 09:23:56 --> Helper loaded: url_helper
INFO - 2024-10-09 09:23:56 --> Helper loaded: file_helper
INFO - 2024-10-09 09:23:56 --> Helper loaded: form_helper
INFO - 2024-10-09 09:23:56 --> Helper loaded: my_helper
INFO - 2024-10-09 09:23:56 --> Database Driver Class Initialized
INFO - 2024-10-09 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:23:56 --> Controller Class Initialized
INFO - 2024-10-09 09:23:56 --> Config Class Initialized
INFO - 2024-10-09 09:23:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:23:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:23:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:23:56 --> URI Class Initialized
INFO - 2024-10-09 09:23:56 --> Router Class Initialized
INFO - 2024-10-09 09:23:56 --> Output Class Initialized
INFO - 2024-10-09 09:23:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:23:56 --> Input Class Initialized
INFO - 2024-10-09 09:23:56 --> Language Class Initialized
INFO - 2024-10-09 09:23:56 --> Language Class Initialized
INFO - 2024-10-09 09:23:56 --> Config Class Initialized
INFO - 2024-10-09 09:23:56 --> Loader Class Initialized
INFO - 2024-10-09 09:23:56 --> Helper loaded: url_helper
INFO - 2024-10-09 09:23:56 --> Helper loaded: file_helper
INFO - 2024-10-09 09:23:56 --> Helper loaded: form_helper
INFO - 2024-10-09 09:23:56 --> Helper loaded: my_helper
INFO - 2024-10-09 09:23:56 --> Database Driver Class Initialized
INFO - 2024-10-09 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:23:56 --> Controller Class Initialized
DEBUG - 2024-10-09 09:23:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:23:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:23:56 --> Final output sent to browser
DEBUG - 2024-10-09 09:23:56 --> Total execution time: 0.0324
INFO - 2024-10-09 09:24:07 --> Config Class Initialized
INFO - 2024-10-09 09:24:07 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:07 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:07 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:07 --> URI Class Initialized
INFO - 2024-10-09 09:24:07 --> Router Class Initialized
INFO - 2024-10-09 09:24:07 --> Output Class Initialized
INFO - 2024-10-09 09:24:07 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:07 --> Input Class Initialized
INFO - 2024-10-09 09:24:07 --> Language Class Initialized
INFO - 2024-10-09 09:24:07 --> Language Class Initialized
INFO - 2024-10-09 09:24:07 --> Config Class Initialized
INFO - 2024-10-09 09:24:07 --> Loader Class Initialized
INFO - 2024-10-09 09:24:07 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:07 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:07 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:07 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:07 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:07 --> Controller Class Initialized
INFO - 2024-10-09 09:24:07 --> Final output sent to browser
DEBUG - 2024-10-09 09:24:07 --> Total execution time: 0.0323
INFO - 2024-10-09 09:24:17 --> Config Class Initialized
INFO - 2024-10-09 09:24:17 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:17 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:17 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:17 --> URI Class Initialized
INFO - 2024-10-09 09:24:17 --> Router Class Initialized
INFO - 2024-10-09 09:24:17 --> Output Class Initialized
INFO - 2024-10-09 09:24:17 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:17 --> Input Class Initialized
INFO - 2024-10-09 09:24:17 --> Language Class Initialized
INFO - 2024-10-09 09:24:17 --> Language Class Initialized
INFO - 2024-10-09 09:24:17 --> Config Class Initialized
INFO - 2024-10-09 09:24:17 --> Loader Class Initialized
INFO - 2024-10-09 09:24:17 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:17 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:17 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:17 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:17 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:17 --> Controller Class Initialized
INFO - 2024-10-09 09:24:17 --> Final output sent to browser
DEBUG - 2024-10-09 09:24:17 --> Total execution time: 0.0296
INFO - 2024-10-09 09:24:27 --> Config Class Initialized
INFO - 2024-10-09 09:24:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:27 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:27 --> URI Class Initialized
INFO - 2024-10-09 09:24:27 --> Router Class Initialized
INFO - 2024-10-09 09:24:27 --> Output Class Initialized
INFO - 2024-10-09 09:24:27 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:27 --> Input Class Initialized
INFO - 2024-10-09 09:24:27 --> Language Class Initialized
INFO - 2024-10-09 09:24:27 --> Language Class Initialized
INFO - 2024-10-09 09:24:27 --> Config Class Initialized
INFO - 2024-10-09 09:24:27 --> Loader Class Initialized
INFO - 2024-10-09 09:24:27 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:27 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:27 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:27 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:27 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:27 --> Controller Class Initialized
INFO - 2024-10-09 09:24:27 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:24:27 --> Final output sent to browser
DEBUG - 2024-10-09 09:24:27 --> Total execution time: 0.0302
INFO - 2024-10-09 09:24:28 --> Config Class Initialized
INFO - 2024-10-09 09:24:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:28 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:28 --> URI Class Initialized
INFO - 2024-10-09 09:24:28 --> Router Class Initialized
INFO - 2024-10-09 09:24:28 --> Output Class Initialized
INFO - 2024-10-09 09:24:28 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:28 --> Input Class Initialized
INFO - 2024-10-09 09:24:28 --> Language Class Initialized
INFO - 2024-10-09 09:24:28 --> Language Class Initialized
INFO - 2024-10-09 09:24:28 --> Config Class Initialized
INFO - 2024-10-09 09:24:28 --> Loader Class Initialized
INFO - 2024-10-09 09:24:28 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:28 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:28 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:28 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:28 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:28 --> Controller Class Initialized
DEBUG - 2024-10-09 09:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 09:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:24:28 --> Final output sent to browser
DEBUG - 2024-10-09 09:24:28 --> Total execution time: 0.1075
INFO - 2024-10-09 09:24:34 --> Config Class Initialized
INFO - 2024-10-09 09:24:34 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:34 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:34 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:34 --> URI Class Initialized
INFO - 2024-10-09 09:24:34 --> Router Class Initialized
INFO - 2024-10-09 09:24:34 --> Output Class Initialized
INFO - 2024-10-09 09:24:34 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:34 --> Input Class Initialized
INFO - 2024-10-09 09:24:34 --> Language Class Initialized
INFO - 2024-10-09 09:24:34 --> Language Class Initialized
INFO - 2024-10-09 09:24:34 --> Config Class Initialized
INFO - 2024-10-09 09:24:34 --> Loader Class Initialized
INFO - 2024-10-09 09:24:34 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:34 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:34 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:34 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:34 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:34 --> Controller Class Initialized
DEBUG - 2024-10-09 09:24:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:24:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:24:34 --> Final output sent to browser
DEBUG - 2024-10-09 09:24:34 --> Total execution time: 0.0332
INFO - 2024-10-09 09:24:41 --> Config Class Initialized
INFO - 2024-10-09 09:24:41 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:41 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:41 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:41 --> URI Class Initialized
INFO - 2024-10-09 09:24:41 --> Router Class Initialized
INFO - 2024-10-09 09:24:41 --> Output Class Initialized
INFO - 2024-10-09 09:24:41 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:41 --> Input Class Initialized
INFO - 2024-10-09 09:24:41 --> Language Class Initialized
INFO - 2024-10-09 09:24:41 --> Language Class Initialized
INFO - 2024-10-09 09:24:41 --> Config Class Initialized
INFO - 2024-10-09 09:24:41 --> Loader Class Initialized
INFO - 2024-10-09 09:24:41 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:41 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:41 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:41 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:41 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:41 --> Controller Class Initialized
DEBUG - 2024-10-09 09:24:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:24:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:24:41 --> Final output sent to browser
DEBUG - 2024-10-09 09:24:41 --> Total execution time: 0.0322
INFO - 2024-10-09 09:24:45 --> Config Class Initialized
INFO - 2024-10-09 09:24:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:24:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:24:45 --> Utf8 Class Initialized
INFO - 2024-10-09 09:24:45 --> URI Class Initialized
INFO - 2024-10-09 09:24:45 --> Router Class Initialized
INFO - 2024-10-09 09:24:45 --> Output Class Initialized
INFO - 2024-10-09 09:24:45 --> Security Class Initialized
DEBUG - 2024-10-09 09:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:24:45 --> Input Class Initialized
INFO - 2024-10-09 09:24:45 --> Language Class Initialized
INFO - 2024-10-09 09:24:45 --> Language Class Initialized
INFO - 2024-10-09 09:24:45 --> Config Class Initialized
INFO - 2024-10-09 09:24:45 --> Loader Class Initialized
INFO - 2024-10-09 09:24:45 --> Helper loaded: url_helper
INFO - 2024-10-09 09:24:45 --> Helper loaded: file_helper
INFO - 2024-10-09 09:24:45 --> Helper loaded: form_helper
INFO - 2024-10-09 09:24:45 --> Helper loaded: my_helper
INFO - 2024-10-09 09:24:45 --> Database Driver Class Initialized
INFO - 2024-10-09 09:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:24:45 --> Controller Class Initialized
INFO - 2024-10-09 09:27:19 --> Config Class Initialized
INFO - 2024-10-09 09:27:19 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:19 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:19 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:19 --> URI Class Initialized
INFO - 2024-10-09 09:27:19 --> Router Class Initialized
INFO - 2024-10-09 09:27:19 --> Output Class Initialized
INFO - 2024-10-09 09:27:19 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:19 --> Input Class Initialized
INFO - 2024-10-09 09:27:19 --> Language Class Initialized
INFO - 2024-10-09 09:27:19 --> Language Class Initialized
INFO - 2024-10-09 09:27:19 --> Config Class Initialized
INFO - 2024-10-09 09:27:19 --> Loader Class Initialized
INFO - 2024-10-09 09:27:19 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:19 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:19 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:19 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:19 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:19 --> Controller Class Initialized
DEBUG - 2024-10-09 09:27:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-09 09:27:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:27:19 --> Final output sent to browser
DEBUG - 2024-10-09 09:27:19 --> Total execution time: 0.0369
INFO - 2024-10-09 09:27:26 --> Config Class Initialized
INFO - 2024-10-09 09:27:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:26 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:26 --> URI Class Initialized
INFO - 2024-10-09 09:27:26 --> Router Class Initialized
INFO - 2024-10-09 09:27:26 --> Output Class Initialized
INFO - 2024-10-09 09:27:26 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:26 --> Input Class Initialized
INFO - 2024-10-09 09:27:26 --> Language Class Initialized
INFO - 2024-10-09 09:27:26 --> Language Class Initialized
INFO - 2024-10-09 09:27:26 --> Config Class Initialized
INFO - 2024-10-09 09:27:26 --> Loader Class Initialized
INFO - 2024-10-09 09:27:26 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:26 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:26 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:26 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:26 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:26 --> Controller Class Initialized
INFO - 2024-10-09 09:27:27 --> Config Class Initialized
INFO - 2024-10-09 09:27:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:27 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:27 --> URI Class Initialized
INFO - 2024-10-09 09:27:27 --> Router Class Initialized
INFO - 2024-10-09 09:27:27 --> Output Class Initialized
INFO - 2024-10-09 09:27:27 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:27 --> Input Class Initialized
INFO - 2024-10-09 09:27:27 --> Language Class Initialized
INFO - 2024-10-09 09:27:27 --> Language Class Initialized
INFO - 2024-10-09 09:27:27 --> Config Class Initialized
INFO - 2024-10-09 09:27:27 --> Loader Class Initialized
INFO - 2024-10-09 09:27:27 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:27 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:27 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:27 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:27 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:27 --> Controller Class Initialized
DEBUG - 2024-10-09 09:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:27:27 --> Final output sent to browser
DEBUG - 2024-10-09 09:27:27 --> Total execution time: 0.0332
INFO - 2024-10-09 09:27:29 --> Config Class Initialized
INFO - 2024-10-09 09:27:29 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:29 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:29 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:29 --> URI Class Initialized
INFO - 2024-10-09 09:27:29 --> Router Class Initialized
INFO - 2024-10-09 09:27:29 --> Output Class Initialized
INFO - 2024-10-09 09:27:29 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:29 --> Input Class Initialized
INFO - 2024-10-09 09:27:29 --> Language Class Initialized
INFO - 2024-10-09 09:27:29 --> Language Class Initialized
INFO - 2024-10-09 09:27:29 --> Config Class Initialized
INFO - 2024-10-09 09:27:29 --> Loader Class Initialized
INFO - 2024-10-09 09:27:29 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:29 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:29 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:29 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:29 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:29 --> Controller Class Initialized
INFO - 2024-10-09 09:27:29 --> Final output sent to browser
DEBUG - 2024-10-09 09:27:29 --> Total execution time: 0.0391
INFO - 2024-10-09 09:27:40 --> Config Class Initialized
INFO - 2024-10-09 09:27:40 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:40 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:40 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:40 --> URI Class Initialized
INFO - 2024-10-09 09:27:40 --> Router Class Initialized
INFO - 2024-10-09 09:27:40 --> Output Class Initialized
INFO - 2024-10-09 09:27:40 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:40 --> Input Class Initialized
INFO - 2024-10-09 09:27:40 --> Language Class Initialized
INFO - 2024-10-09 09:27:40 --> Language Class Initialized
INFO - 2024-10-09 09:27:40 --> Config Class Initialized
INFO - 2024-10-09 09:27:40 --> Loader Class Initialized
INFO - 2024-10-09 09:27:40 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:40 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:40 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:40 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:40 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:40 --> Controller Class Initialized
DEBUG - 2024-10-09 09:27:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:27:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:27:40 --> Final output sent to browser
DEBUG - 2024-10-09 09:27:40 --> Total execution time: 0.0287
INFO - 2024-10-09 09:27:42 --> Config Class Initialized
INFO - 2024-10-09 09:27:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:42 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:42 --> URI Class Initialized
INFO - 2024-10-09 09:27:42 --> Router Class Initialized
INFO - 2024-10-09 09:27:42 --> Output Class Initialized
INFO - 2024-10-09 09:27:42 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:42 --> Input Class Initialized
INFO - 2024-10-09 09:27:42 --> Language Class Initialized
INFO - 2024-10-09 09:27:42 --> Language Class Initialized
INFO - 2024-10-09 09:27:42 --> Config Class Initialized
INFO - 2024-10-09 09:27:42 --> Loader Class Initialized
INFO - 2024-10-09 09:27:42 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:42 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:42 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:42 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:42 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:42 --> Controller Class Initialized
DEBUG - 2024-10-09 09:27:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:27:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:27:42 --> Final output sent to browser
DEBUG - 2024-10-09 09:27:42 --> Total execution time: 0.0331
INFO - 2024-10-09 09:27:45 --> Config Class Initialized
INFO - 2024-10-09 09:27:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:27:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:27:45 --> Utf8 Class Initialized
INFO - 2024-10-09 09:27:45 --> URI Class Initialized
INFO - 2024-10-09 09:27:45 --> Router Class Initialized
INFO - 2024-10-09 09:27:45 --> Output Class Initialized
INFO - 2024-10-09 09:27:45 --> Security Class Initialized
DEBUG - 2024-10-09 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:27:45 --> Input Class Initialized
INFO - 2024-10-09 09:27:45 --> Language Class Initialized
INFO - 2024-10-09 09:27:45 --> Language Class Initialized
INFO - 2024-10-09 09:27:45 --> Config Class Initialized
INFO - 2024-10-09 09:27:45 --> Loader Class Initialized
INFO - 2024-10-09 09:27:45 --> Helper loaded: url_helper
INFO - 2024-10-09 09:27:45 --> Helper loaded: file_helper
INFO - 2024-10-09 09:27:45 --> Helper loaded: form_helper
INFO - 2024-10-09 09:27:45 --> Helper loaded: my_helper
INFO - 2024-10-09 09:27:45 --> Database Driver Class Initialized
INFO - 2024-10-09 09:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:27:45 --> Controller Class Initialized
INFO - 2024-10-09 09:28:54 --> Config Class Initialized
INFO - 2024-10-09 09:28:54 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:28:54 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:28:54 --> Utf8 Class Initialized
INFO - 2024-10-09 09:28:54 --> URI Class Initialized
INFO - 2024-10-09 09:28:54 --> Router Class Initialized
INFO - 2024-10-09 09:28:54 --> Output Class Initialized
INFO - 2024-10-09 09:28:54 --> Security Class Initialized
DEBUG - 2024-10-09 09:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:28:54 --> Input Class Initialized
INFO - 2024-10-09 09:28:54 --> Language Class Initialized
INFO - 2024-10-09 09:28:54 --> Language Class Initialized
INFO - 2024-10-09 09:28:54 --> Config Class Initialized
INFO - 2024-10-09 09:28:54 --> Loader Class Initialized
INFO - 2024-10-09 09:28:54 --> Helper loaded: url_helper
INFO - 2024-10-09 09:28:54 --> Helper loaded: file_helper
INFO - 2024-10-09 09:28:54 --> Helper loaded: form_helper
INFO - 2024-10-09 09:28:54 --> Helper loaded: my_helper
INFO - 2024-10-09 09:28:54 --> Database Driver Class Initialized
INFO - 2024-10-09 09:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:28:54 --> Controller Class Initialized
DEBUG - 2024-10-09 09:28:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:28:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:28:54 --> Final output sent to browser
DEBUG - 2024-10-09 09:28:54 --> Total execution time: 0.0304
INFO - 2024-10-09 09:28:56 --> Config Class Initialized
INFO - 2024-10-09 09:28:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:28:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:28:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:28:56 --> URI Class Initialized
INFO - 2024-10-09 09:28:56 --> Router Class Initialized
INFO - 2024-10-09 09:28:56 --> Output Class Initialized
INFO - 2024-10-09 09:28:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:28:56 --> Input Class Initialized
INFO - 2024-10-09 09:28:56 --> Language Class Initialized
INFO - 2024-10-09 09:28:56 --> Language Class Initialized
INFO - 2024-10-09 09:28:56 --> Config Class Initialized
INFO - 2024-10-09 09:28:56 --> Loader Class Initialized
INFO - 2024-10-09 09:28:56 --> Helper loaded: url_helper
INFO - 2024-10-09 09:28:56 --> Helper loaded: file_helper
INFO - 2024-10-09 09:28:56 --> Helper loaded: form_helper
INFO - 2024-10-09 09:28:56 --> Helper loaded: my_helper
INFO - 2024-10-09 09:28:56 --> Database Driver Class Initialized
INFO - 2024-10-09 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:28:56 --> Controller Class Initialized
DEBUG - 2024-10-09 09:28:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:28:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:28:56 --> Final output sent to browser
DEBUG - 2024-10-09 09:28:56 --> Total execution time: 0.0402
INFO - 2024-10-09 09:28:58 --> Config Class Initialized
INFO - 2024-10-09 09:28:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:28:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:28:58 --> Utf8 Class Initialized
INFO - 2024-10-09 09:28:58 --> URI Class Initialized
INFO - 2024-10-09 09:28:58 --> Router Class Initialized
INFO - 2024-10-09 09:28:58 --> Output Class Initialized
INFO - 2024-10-09 09:28:58 --> Security Class Initialized
DEBUG - 2024-10-09 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:28:58 --> Input Class Initialized
INFO - 2024-10-09 09:28:58 --> Language Class Initialized
INFO - 2024-10-09 09:28:58 --> Language Class Initialized
INFO - 2024-10-09 09:28:58 --> Config Class Initialized
INFO - 2024-10-09 09:28:58 --> Loader Class Initialized
INFO - 2024-10-09 09:28:58 --> Helper loaded: url_helper
INFO - 2024-10-09 09:28:58 --> Helper loaded: file_helper
INFO - 2024-10-09 09:28:58 --> Helper loaded: form_helper
INFO - 2024-10-09 09:28:58 --> Helper loaded: my_helper
INFO - 2024-10-09 09:28:58 --> Database Driver Class Initialized
INFO - 2024-10-09 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:28:58 --> Controller Class Initialized
INFO - 2024-10-09 09:28:58 --> Final output sent to browser
DEBUG - 2024-10-09 09:28:58 --> Total execution time: 0.0292
INFO - 2024-10-09 09:29:01 --> Config Class Initialized
INFO - 2024-10-09 09:29:01 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:29:01 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:29:01 --> Utf8 Class Initialized
INFO - 2024-10-09 09:29:01 --> URI Class Initialized
INFO - 2024-10-09 09:29:01 --> Router Class Initialized
INFO - 2024-10-09 09:29:01 --> Output Class Initialized
INFO - 2024-10-09 09:29:01 --> Security Class Initialized
DEBUG - 2024-10-09 09:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:29:01 --> Input Class Initialized
INFO - 2024-10-09 09:29:01 --> Language Class Initialized
INFO - 2024-10-09 09:29:01 --> Language Class Initialized
INFO - 2024-10-09 09:29:01 --> Config Class Initialized
INFO - 2024-10-09 09:29:01 --> Loader Class Initialized
INFO - 2024-10-09 09:29:01 --> Helper loaded: url_helper
INFO - 2024-10-09 09:29:01 --> Helper loaded: file_helper
INFO - 2024-10-09 09:29:01 --> Helper loaded: form_helper
INFO - 2024-10-09 09:29:01 --> Helper loaded: my_helper
INFO - 2024-10-09 09:29:01 --> Database Driver Class Initialized
INFO - 2024-10-09 09:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:29:01 --> Controller Class Initialized
INFO - 2024-10-09 09:32:02 --> Config Class Initialized
INFO - 2024-10-09 09:32:02 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:32:02 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:32:02 --> Utf8 Class Initialized
INFO - 2024-10-09 09:32:02 --> URI Class Initialized
INFO - 2024-10-09 09:32:02 --> Router Class Initialized
INFO - 2024-10-09 09:32:02 --> Output Class Initialized
INFO - 2024-10-09 09:32:02 --> Security Class Initialized
DEBUG - 2024-10-09 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:32:02 --> Input Class Initialized
INFO - 2024-10-09 09:32:02 --> Language Class Initialized
INFO - 2024-10-09 09:32:02 --> Language Class Initialized
INFO - 2024-10-09 09:32:02 --> Config Class Initialized
INFO - 2024-10-09 09:32:02 --> Loader Class Initialized
INFO - 2024-10-09 09:32:02 --> Helper loaded: url_helper
INFO - 2024-10-09 09:32:02 --> Helper loaded: file_helper
INFO - 2024-10-09 09:32:02 --> Helper loaded: form_helper
INFO - 2024-10-09 09:32:02 --> Helper loaded: my_helper
INFO - 2024-10-09 09:32:02 --> Database Driver Class Initialized
INFO - 2024-10-09 09:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:32:02 --> Controller Class Initialized
DEBUG - 2024-10-09 09:32:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-09 09:32:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:32:02 --> Final output sent to browser
DEBUG - 2024-10-09 09:32:02 --> Total execution time: 0.4795
INFO - 2024-10-09 09:32:10 --> Config Class Initialized
INFO - 2024-10-09 09:32:10 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:32:10 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:32:10 --> Utf8 Class Initialized
INFO - 2024-10-09 09:32:10 --> URI Class Initialized
INFO - 2024-10-09 09:32:10 --> Router Class Initialized
INFO - 2024-10-09 09:32:10 --> Output Class Initialized
INFO - 2024-10-09 09:32:10 --> Security Class Initialized
DEBUG - 2024-10-09 09:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:32:10 --> Input Class Initialized
INFO - 2024-10-09 09:32:10 --> Language Class Initialized
INFO - 2024-10-09 09:32:10 --> Language Class Initialized
INFO - 2024-10-09 09:32:10 --> Config Class Initialized
INFO - 2024-10-09 09:32:10 --> Loader Class Initialized
INFO - 2024-10-09 09:32:10 --> Helper loaded: url_helper
INFO - 2024-10-09 09:32:10 --> Helper loaded: file_helper
INFO - 2024-10-09 09:32:10 --> Helper loaded: form_helper
INFO - 2024-10-09 09:32:10 --> Helper loaded: my_helper
INFO - 2024-10-09 09:32:10 --> Database Driver Class Initialized
INFO - 2024-10-09 09:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:32:10 --> Controller Class Initialized
INFO - 2024-10-09 09:32:11 --> Config Class Initialized
INFO - 2024-10-09 09:32:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:32:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:32:11 --> Utf8 Class Initialized
INFO - 2024-10-09 09:32:11 --> URI Class Initialized
INFO - 2024-10-09 09:32:11 --> Router Class Initialized
INFO - 2024-10-09 09:32:11 --> Output Class Initialized
INFO - 2024-10-09 09:32:11 --> Security Class Initialized
DEBUG - 2024-10-09 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:32:11 --> Input Class Initialized
INFO - 2024-10-09 09:32:11 --> Language Class Initialized
INFO - 2024-10-09 09:32:11 --> Language Class Initialized
INFO - 2024-10-09 09:32:11 --> Config Class Initialized
INFO - 2024-10-09 09:32:11 --> Loader Class Initialized
INFO - 2024-10-09 09:32:11 --> Helper loaded: url_helper
INFO - 2024-10-09 09:32:11 --> Helper loaded: file_helper
INFO - 2024-10-09 09:32:11 --> Helper loaded: form_helper
INFO - 2024-10-09 09:32:11 --> Helper loaded: my_helper
INFO - 2024-10-09 09:32:11 --> Database Driver Class Initialized
INFO - 2024-10-09 09:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:32:11 --> Controller Class Initialized
DEBUG - 2024-10-09 09:32:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:32:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:32:11 --> Final output sent to browser
DEBUG - 2024-10-09 09:32:11 --> Total execution time: 0.0418
INFO - 2024-10-09 09:32:13 --> Config Class Initialized
INFO - 2024-10-09 09:32:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:32:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:32:13 --> Utf8 Class Initialized
INFO - 2024-10-09 09:32:13 --> URI Class Initialized
INFO - 2024-10-09 09:32:13 --> Router Class Initialized
INFO - 2024-10-09 09:32:13 --> Output Class Initialized
INFO - 2024-10-09 09:32:13 --> Security Class Initialized
DEBUG - 2024-10-09 09:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:32:13 --> Input Class Initialized
INFO - 2024-10-09 09:32:13 --> Language Class Initialized
INFO - 2024-10-09 09:32:13 --> Language Class Initialized
INFO - 2024-10-09 09:32:13 --> Config Class Initialized
INFO - 2024-10-09 09:32:13 --> Loader Class Initialized
INFO - 2024-10-09 09:32:13 --> Helper loaded: url_helper
INFO - 2024-10-09 09:32:13 --> Helper loaded: file_helper
INFO - 2024-10-09 09:32:13 --> Helper loaded: form_helper
INFO - 2024-10-09 09:32:13 --> Helper loaded: my_helper
INFO - 2024-10-09 09:32:13 --> Database Driver Class Initialized
INFO - 2024-10-09 09:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:32:13 --> Controller Class Initialized
INFO - 2024-10-09 09:32:13 --> Final output sent to browser
DEBUG - 2024-10-09 09:32:13 --> Total execution time: 0.0414
INFO - 2024-10-09 09:35:08 --> Config Class Initialized
INFO - 2024-10-09 09:35:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:35:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:35:08 --> Utf8 Class Initialized
INFO - 2024-10-09 09:35:08 --> URI Class Initialized
INFO - 2024-10-09 09:35:08 --> Router Class Initialized
INFO - 2024-10-09 09:35:08 --> Output Class Initialized
INFO - 2024-10-09 09:35:08 --> Security Class Initialized
DEBUG - 2024-10-09 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:35:08 --> Input Class Initialized
INFO - 2024-10-09 09:35:08 --> Language Class Initialized
INFO - 2024-10-09 09:35:08 --> Language Class Initialized
INFO - 2024-10-09 09:35:08 --> Config Class Initialized
INFO - 2024-10-09 09:35:08 --> Loader Class Initialized
INFO - 2024-10-09 09:35:08 --> Helper loaded: url_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: file_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: form_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: my_helper
INFO - 2024-10-09 09:35:08 --> Database Driver Class Initialized
INFO - 2024-10-09 09:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:35:08 --> Controller Class Initialized
INFO - 2024-10-09 09:35:08 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:35:08 --> Config Class Initialized
INFO - 2024-10-09 09:35:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:35:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:35:08 --> Utf8 Class Initialized
INFO - 2024-10-09 09:35:08 --> URI Class Initialized
INFO - 2024-10-09 09:35:08 --> Router Class Initialized
INFO - 2024-10-09 09:35:08 --> Output Class Initialized
INFO - 2024-10-09 09:35:08 --> Security Class Initialized
DEBUG - 2024-10-09 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:35:08 --> Input Class Initialized
INFO - 2024-10-09 09:35:08 --> Language Class Initialized
INFO - 2024-10-09 09:35:08 --> Language Class Initialized
INFO - 2024-10-09 09:35:08 --> Config Class Initialized
INFO - 2024-10-09 09:35:08 --> Loader Class Initialized
INFO - 2024-10-09 09:35:08 --> Helper loaded: url_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: file_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: form_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: my_helper
INFO - 2024-10-09 09:35:08 --> Database Driver Class Initialized
INFO - 2024-10-09 09:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:35:08 --> Controller Class Initialized
INFO - 2024-10-09 09:35:08 --> Config Class Initialized
INFO - 2024-10-09 09:35:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:35:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:35:08 --> Utf8 Class Initialized
INFO - 2024-10-09 09:35:08 --> URI Class Initialized
INFO - 2024-10-09 09:35:08 --> Router Class Initialized
INFO - 2024-10-09 09:35:08 --> Output Class Initialized
INFO - 2024-10-09 09:35:08 --> Security Class Initialized
DEBUG - 2024-10-09 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:35:08 --> Input Class Initialized
INFO - 2024-10-09 09:35:08 --> Language Class Initialized
INFO - 2024-10-09 09:35:08 --> Language Class Initialized
INFO - 2024-10-09 09:35:08 --> Config Class Initialized
INFO - 2024-10-09 09:35:08 --> Loader Class Initialized
INFO - 2024-10-09 09:35:08 --> Helper loaded: url_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: file_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: form_helper
INFO - 2024-10-09 09:35:08 --> Helper loaded: my_helper
INFO - 2024-10-09 09:35:08 --> Database Driver Class Initialized
INFO - 2024-10-09 09:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:35:08 --> Controller Class Initialized
DEBUG - 2024-10-09 09:35:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:35:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:35:08 --> Final output sent to browser
DEBUG - 2024-10-09 09:35:08 --> Total execution time: 0.0311
INFO - 2024-10-09 09:35:36 --> Config Class Initialized
INFO - 2024-10-09 09:35:36 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:35:36 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:35:36 --> Utf8 Class Initialized
INFO - 2024-10-09 09:35:36 --> URI Class Initialized
INFO - 2024-10-09 09:35:36 --> Router Class Initialized
INFO - 2024-10-09 09:35:36 --> Output Class Initialized
INFO - 2024-10-09 09:35:36 --> Security Class Initialized
DEBUG - 2024-10-09 09:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:35:36 --> Input Class Initialized
INFO - 2024-10-09 09:35:36 --> Language Class Initialized
INFO - 2024-10-09 09:35:36 --> Language Class Initialized
INFO - 2024-10-09 09:35:36 --> Config Class Initialized
INFO - 2024-10-09 09:35:36 --> Loader Class Initialized
INFO - 2024-10-09 09:35:36 --> Helper loaded: url_helper
INFO - 2024-10-09 09:35:36 --> Helper loaded: file_helper
INFO - 2024-10-09 09:35:36 --> Helper loaded: form_helper
INFO - 2024-10-09 09:35:36 --> Helper loaded: my_helper
INFO - 2024-10-09 09:35:36 --> Database Driver Class Initialized
INFO - 2024-10-09 09:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:35:36 --> Controller Class Initialized
INFO - 2024-10-09 09:35:36 --> Final output sent to browser
DEBUG - 2024-10-09 09:35:36 --> Total execution time: 0.0338
INFO - 2024-10-09 09:35:44 --> Config Class Initialized
INFO - 2024-10-09 09:35:44 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:35:44 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:35:44 --> Utf8 Class Initialized
INFO - 2024-10-09 09:35:44 --> URI Class Initialized
INFO - 2024-10-09 09:35:44 --> Router Class Initialized
INFO - 2024-10-09 09:35:44 --> Output Class Initialized
INFO - 2024-10-09 09:35:44 --> Security Class Initialized
DEBUG - 2024-10-09 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:35:44 --> Input Class Initialized
INFO - 2024-10-09 09:35:44 --> Language Class Initialized
INFO - 2024-10-09 09:35:44 --> Language Class Initialized
INFO - 2024-10-09 09:35:44 --> Config Class Initialized
INFO - 2024-10-09 09:35:44 --> Loader Class Initialized
INFO - 2024-10-09 09:35:44 --> Helper loaded: url_helper
INFO - 2024-10-09 09:35:44 --> Helper loaded: file_helper
INFO - 2024-10-09 09:35:44 --> Helper loaded: form_helper
INFO - 2024-10-09 09:35:44 --> Helper loaded: my_helper
INFO - 2024-10-09 09:35:44 --> Database Driver Class Initialized
INFO - 2024-10-09 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:35:44 --> Controller Class Initialized
INFO - 2024-10-09 09:35:44 --> Final output sent to browser
DEBUG - 2024-10-09 09:35:44 --> Total execution time: 0.0369
INFO - 2024-10-09 09:36:00 --> Config Class Initialized
INFO - 2024-10-09 09:36:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:00 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:00 --> URI Class Initialized
INFO - 2024-10-09 09:36:00 --> Router Class Initialized
INFO - 2024-10-09 09:36:00 --> Output Class Initialized
INFO - 2024-10-09 09:36:00 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:00 --> Input Class Initialized
INFO - 2024-10-09 09:36:00 --> Language Class Initialized
INFO - 2024-10-09 09:36:00 --> Language Class Initialized
INFO - 2024-10-09 09:36:00 --> Config Class Initialized
INFO - 2024-10-09 09:36:00 --> Loader Class Initialized
INFO - 2024-10-09 09:36:00 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:00 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:00 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:00 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:00 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:00 --> Controller Class Initialized
INFO - 2024-10-09 09:36:00 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:00 --> Total execution time: 0.0424
INFO - 2024-10-09 09:36:10 --> Config Class Initialized
INFO - 2024-10-09 09:36:10 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:10 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:10 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:10 --> URI Class Initialized
INFO - 2024-10-09 09:36:10 --> Router Class Initialized
INFO - 2024-10-09 09:36:10 --> Output Class Initialized
INFO - 2024-10-09 09:36:10 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:10 --> Input Class Initialized
INFO - 2024-10-09 09:36:10 --> Language Class Initialized
INFO - 2024-10-09 09:36:10 --> Language Class Initialized
INFO - 2024-10-09 09:36:10 --> Config Class Initialized
INFO - 2024-10-09 09:36:10 --> Loader Class Initialized
INFO - 2024-10-09 09:36:10 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:10 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:10 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:10 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:10 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:10 --> Controller Class Initialized
INFO - 2024-10-09 09:36:10 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:36:10 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:10 --> Total execution time: 0.0347
INFO - 2024-10-09 09:36:10 --> Config Class Initialized
INFO - 2024-10-09 09:36:10 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:10 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:10 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:10 --> URI Class Initialized
INFO - 2024-10-09 09:36:10 --> Router Class Initialized
INFO - 2024-10-09 09:36:10 --> Output Class Initialized
INFO - 2024-10-09 09:36:10 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:10 --> Input Class Initialized
INFO - 2024-10-09 09:36:10 --> Language Class Initialized
INFO - 2024-10-09 09:36:10 --> Language Class Initialized
INFO - 2024-10-09 09:36:10 --> Config Class Initialized
INFO - 2024-10-09 09:36:10 --> Loader Class Initialized
INFO - 2024-10-09 09:36:10 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:10 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:10 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:10 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:10 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:10 --> Controller Class Initialized
DEBUG - 2024-10-09 09:36:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-09 09:36:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:36:10 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:10 --> Total execution time: 0.0387
INFO - 2024-10-09 09:36:12 --> Config Class Initialized
INFO - 2024-10-09 09:36:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:12 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:12 --> URI Class Initialized
INFO - 2024-10-09 09:36:12 --> Router Class Initialized
INFO - 2024-10-09 09:36:12 --> Output Class Initialized
INFO - 2024-10-09 09:36:12 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:12 --> Input Class Initialized
INFO - 2024-10-09 09:36:12 --> Language Class Initialized
INFO - 2024-10-09 09:36:12 --> Language Class Initialized
INFO - 2024-10-09 09:36:12 --> Config Class Initialized
INFO - 2024-10-09 09:36:12 --> Loader Class Initialized
INFO - 2024-10-09 09:36:12 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:12 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:12 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:12 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:12 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:12 --> Controller Class Initialized
DEBUG - 2024-10-09 09:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-09 09:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:36:12 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:12 --> Total execution time: 0.0361
INFO - 2024-10-09 09:36:13 --> Config Class Initialized
INFO - 2024-10-09 09:36:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:13 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:13 --> URI Class Initialized
INFO - 2024-10-09 09:36:13 --> Router Class Initialized
INFO - 2024-10-09 09:36:13 --> Output Class Initialized
INFO - 2024-10-09 09:36:13 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:13 --> Input Class Initialized
INFO - 2024-10-09 09:36:13 --> Language Class Initialized
ERROR - 2024-10-09 09:36:13 --> 404 Page Not Found: /index
INFO - 2024-10-09 09:36:13 --> Config Class Initialized
INFO - 2024-10-09 09:36:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:13 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:13 --> URI Class Initialized
INFO - 2024-10-09 09:36:13 --> Router Class Initialized
INFO - 2024-10-09 09:36:13 --> Output Class Initialized
INFO - 2024-10-09 09:36:13 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:13 --> Input Class Initialized
INFO - 2024-10-09 09:36:13 --> Language Class Initialized
INFO - 2024-10-09 09:36:13 --> Language Class Initialized
INFO - 2024-10-09 09:36:13 --> Config Class Initialized
INFO - 2024-10-09 09:36:13 --> Loader Class Initialized
INFO - 2024-10-09 09:36:13 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:13 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:13 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:13 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:13 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:13 --> Controller Class Initialized
INFO - 2024-10-09 09:36:25 --> Config Class Initialized
INFO - 2024-10-09 09:36:25 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:25 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:25 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:25 --> URI Class Initialized
INFO - 2024-10-09 09:36:25 --> Router Class Initialized
INFO - 2024-10-09 09:36:25 --> Output Class Initialized
INFO - 2024-10-09 09:36:25 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:25 --> Input Class Initialized
INFO - 2024-10-09 09:36:25 --> Language Class Initialized
INFO - 2024-10-09 09:36:25 --> Language Class Initialized
INFO - 2024-10-09 09:36:25 --> Config Class Initialized
INFO - 2024-10-09 09:36:25 --> Loader Class Initialized
INFO - 2024-10-09 09:36:25 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:25 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:25 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:25 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:25 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:25 --> Controller Class Initialized
INFO - 2024-10-09 09:36:25 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:36:26 --> Config Class Initialized
INFO - 2024-10-09 09:36:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:26 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:26 --> URI Class Initialized
INFO - 2024-10-09 09:36:26 --> Router Class Initialized
INFO - 2024-10-09 09:36:26 --> Output Class Initialized
INFO - 2024-10-09 09:36:26 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:26 --> Input Class Initialized
INFO - 2024-10-09 09:36:26 --> Language Class Initialized
INFO - 2024-10-09 09:36:26 --> Language Class Initialized
INFO - 2024-10-09 09:36:26 --> Config Class Initialized
INFO - 2024-10-09 09:36:26 --> Loader Class Initialized
INFO - 2024-10-09 09:36:26 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:26 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:26 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:26 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:26 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:26 --> Controller Class Initialized
INFO - 2024-10-09 09:36:26 --> Config Class Initialized
INFO - 2024-10-09 09:36:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:26 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:26 --> URI Class Initialized
INFO - 2024-10-09 09:36:26 --> Router Class Initialized
INFO - 2024-10-09 09:36:26 --> Output Class Initialized
INFO - 2024-10-09 09:36:26 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:26 --> Input Class Initialized
INFO - 2024-10-09 09:36:26 --> Language Class Initialized
INFO - 2024-10-09 09:36:26 --> Language Class Initialized
INFO - 2024-10-09 09:36:26 --> Config Class Initialized
INFO - 2024-10-09 09:36:26 --> Loader Class Initialized
INFO - 2024-10-09 09:36:26 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:26 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:26 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:26 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:26 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:26 --> Controller Class Initialized
DEBUG - 2024-10-09 09:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:36:26 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:26 --> Total execution time: 0.0354
INFO - 2024-10-09 09:36:33 --> Config Class Initialized
INFO - 2024-10-09 09:36:33 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:33 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:33 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:33 --> URI Class Initialized
INFO - 2024-10-09 09:36:33 --> Router Class Initialized
INFO - 2024-10-09 09:36:33 --> Output Class Initialized
INFO - 2024-10-09 09:36:33 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:33 --> Input Class Initialized
INFO - 2024-10-09 09:36:33 --> Language Class Initialized
INFO - 2024-10-09 09:36:33 --> Language Class Initialized
INFO - 2024-10-09 09:36:33 --> Config Class Initialized
INFO - 2024-10-09 09:36:33 --> Loader Class Initialized
INFO - 2024-10-09 09:36:33 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:33 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:33 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:33 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:33 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:33 --> Controller Class Initialized
INFO - 2024-10-09 09:36:33 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:36:33 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:33 --> Total execution time: 0.0302
INFO - 2024-10-09 09:36:33 --> Config Class Initialized
INFO - 2024-10-09 09:36:33 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:33 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:33 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:33 --> URI Class Initialized
INFO - 2024-10-09 09:36:33 --> Router Class Initialized
INFO - 2024-10-09 09:36:33 --> Output Class Initialized
INFO - 2024-10-09 09:36:33 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:33 --> Input Class Initialized
INFO - 2024-10-09 09:36:33 --> Language Class Initialized
INFO - 2024-10-09 09:36:33 --> Language Class Initialized
INFO - 2024-10-09 09:36:33 --> Config Class Initialized
INFO - 2024-10-09 09:36:33 --> Loader Class Initialized
INFO - 2024-10-09 09:36:33 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:33 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:33 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:33 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:33 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:33 --> Controller Class Initialized
DEBUG - 2024-10-09 09:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 09:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:36:33 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:33 --> Total execution time: 0.0342
INFO - 2024-10-09 09:36:36 --> Config Class Initialized
INFO - 2024-10-09 09:36:36 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:36 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:36 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:36 --> URI Class Initialized
INFO - 2024-10-09 09:36:36 --> Router Class Initialized
INFO - 2024-10-09 09:36:36 --> Output Class Initialized
INFO - 2024-10-09 09:36:36 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:36 --> Input Class Initialized
INFO - 2024-10-09 09:36:36 --> Language Class Initialized
INFO - 2024-10-09 09:36:36 --> Language Class Initialized
INFO - 2024-10-09 09:36:36 --> Config Class Initialized
INFO - 2024-10-09 09:36:36 --> Loader Class Initialized
INFO - 2024-10-09 09:36:36 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:36 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:36 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:36 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:36 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:36 --> Controller Class Initialized
DEBUG - 2024-10-09 09:36:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:36:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:36:36 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:36 --> Total execution time: 0.0543
INFO - 2024-10-09 09:36:53 --> Config Class Initialized
INFO - 2024-10-09 09:36:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:53 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:53 --> URI Class Initialized
INFO - 2024-10-09 09:36:53 --> Router Class Initialized
INFO - 2024-10-09 09:36:53 --> Output Class Initialized
INFO - 2024-10-09 09:36:53 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:53 --> Input Class Initialized
INFO - 2024-10-09 09:36:53 --> Language Class Initialized
INFO - 2024-10-09 09:36:53 --> Language Class Initialized
INFO - 2024-10-09 09:36:53 --> Config Class Initialized
INFO - 2024-10-09 09:36:53 --> Loader Class Initialized
INFO - 2024-10-09 09:36:53 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:53 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:53 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:53 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:53 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:53 --> Controller Class Initialized
DEBUG - 2024-10-09 09:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:36:53 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:53 --> Total execution time: 0.0468
INFO - 2024-10-09 09:36:56 --> Config Class Initialized
INFO - 2024-10-09 09:36:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:56 --> URI Class Initialized
INFO - 2024-10-09 09:36:56 --> Router Class Initialized
INFO - 2024-10-09 09:36:56 --> Output Class Initialized
INFO - 2024-10-09 09:36:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:56 --> Input Class Initialized
INFO - 2024-10-09 09:36:56 --> Language Class Initialized
INFO - 2024-10-09 09:36:56 --> Language Class Initialized
INFO - 2024-10-09 09:36:56 --> Config Class Initialized
INFO - 2024-10-09 09:36:56 --> Loader Class Initialized
INFO - 2024-10-09 09:36:56 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:56 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:56 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:56 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:56 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:56 --> Controller Class Initialized
INFO - 2024-10-09 09:36:58 --> Config Class Initialized
INFO - 2024-10-09 09:36:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:36:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:36:58 --> Utf8 Class Initialized
INFO - 2024-10-09 09:36:58 --> URI Class Initialized
INFO - 2024-10-09 09:36:58 --> Router Class Initialized
INFO - 2024-10-09 09:36:58 --> Output Class Initialized
INFO - 2024-10-09 09:36:58 --> Security Class Initialized
DEBUG - 2024-10-09 09:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:36:58 --> Input Class Initialized
INFO - 2024-10-09 09:36:58 --> Language Class Initialized
INFO - 2024-10-09 09:36:58 --> Language Class Initialized
INFO - 2024-10-09 09:36:58 --> Config Class Initialized
INFO - 2024-10-09 09:36:58 --> Loader Class Initialized
INFO - 2024-10-09 09:36:58 --> Helper loaded: url_helper
INFO - 2024-10-09 09:36:58 --> Helper loaded: file_helper
INFO - 2024-10-09 09:36:58 --> Helper loaded: form_helper
INFO - 2024-10-09 09:36:58 --> Helper loaded: my_helper
INFO - 2024-10-09 09:36:58 --> Database Driver Class Initialized
INFO - 2024-10-09 09:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:36:58 --> Controller Class Initialized
INFO - 2024-10-09 09:36:58 --> Final output sent to browser
DEBUG - 2024-10-09 09:36:58 --> Total execution time: 0.0314
INFO - 2024-10-09 09:37:02 --> Config Class Initialized
INFO - 2024-10-09 09:37:02 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:02 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:02 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:02 --> URI Class Initialized
INFO - 2024-10-09 09:37:02 --> Router Class Initialized
INFO - 2024-10-09 09:37:02 --> Output Class Initialized
INFO - 2024-10-09 09:37:02 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:02 --> Input Class Initialized
INFO - 2024-10-09 09:37:02 --> Language Class Initialized
INFO - 2024-10-09 09:37:02 --> Language Class Initialized
INFO - 2024-10-09 09:37:02 --> Config Class Initialized
INFO - 2024-10-09 09:37:02 --> Loader Class Initialized
INFO - 2024-10-09 09:37:02 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:02 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:02 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:02 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:02 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:02 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:37:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:02 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:02 --> Total execution time: 0.0354
INFO - 2024-10-09 09:37:14 --> Config Class Initialized
INFO - 2024-10-09 09:37:14 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:14 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:14 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:14 --> URI Class Initialized
INFO - 2024-10-09 09:37:14 --> Router Class Initialized
INFO - 2024-10-09 09:37:14 --> Output Class Initialized
INFO - 2024-10-09 09:37:14 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:14 --> Input Class Initialized
INFO - 2024-10-09 09:37:14 --> Language Class Initialized
INFO - 2024-10-09 09:37:14 --> Language Class Initialized
INFO - 2024-10-09 09:37:14 --> Config Class Initialized
INFO - 2024-10-09 09:37:14 --> Loader Class Initialized
INFO - 2024-10-09 09:37:14 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:14 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:14 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:14 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:14 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:14 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:37:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:14 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:14 --> Total execution time: 0.0336
INFO - 2024-10-09 09:37:16 --> Config Class Initialized
INFO - 2024-10-09 09:37:16 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:16 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:16 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:16 --> URI Class Initialized
INFO - 2024-10-09 09:37:16 --> Router Class Initialized
INFO - 2024-10-09 09:37:16 --> Output Class Initialized
INFO - 2024-10-09 09:37:16 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:16 --> Input Class Initialized
INFO - 2024-10-09 09:37:16 --> Language Class Initialized
INFO - 2024-10-09 09:37:16 --> Language Class Initialized
INFO - 2024-10-09 09:37:16 --> Config Class Initialized
INFO - 2024-10-09 09:37:16 --> Loader Class Initialized
INFO - 2024-10-09 09:37:16 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:16 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:16 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:16 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:16 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:16 --> Controller Class Initialized
INFO - 2024-10-09 09:37:18 --> Config Class Initialized
INFO - 2024-10-09 09:37:18 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:18 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:18 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:18 --> URI Class Initialized
INFO - 2024-10-09 09:37:18 --> Router Class Initialized
INFO - 2024-10-09 09:37:18 --> Output Class Initialized
INFO - 2024-10-09 09:37:18 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:18 --> Input Class Initialized
INFO - 2024-10-09 09:37:18 --> Language Class Initialized
INFO - 2024-10-09 09:37:18 --> Language Class Initialized
INFO - 2024-10-09 09:37:18 --> Config Class Initialized
INFO - 2024-10-09 09:37:18 --> Loader Class Initialized
INFO - 2024-10-09 09:37:18 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:18 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:18 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:18 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:18 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:18 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:37:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:18 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:18 --> Total execution time: 0.0413
INFO - 2024-10-09 09:37:21 --> Config Class Initialized
INFO - 2024-10-09 09:37:21 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:21 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:21 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:21 --> URI Class Initialized
INFO - 2024-10-09 09:37:21 --> Router Class Initialized
INFO - 2024-10-09 09:37:21 --> Output Class Initialized
INFO - 2024-10-09 09:37:21 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:21 --> Input Class Initialized
INFO - 2024-10-09 09:37:21 --> Language Class Initialized
INFO - 2024-10-09 09:37:21 --> Language Class Initialized
INFO - 2024-10-09 09:37:21 --> Config Class Initialized
INFO - 2024-10-09 09:37:21 --> Loader Class Initialized
INFO - 2024-10-09 09:37:21 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:21 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:21 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:21 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:21 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:21 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:37:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:21 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:21 --> Total execution time: 0.0462
INFO - 2024-10-09 09:37:23 --> Config Class Initialized
INFO - 2024-10-09 09:37:23 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:23 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:23 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:23 --> URI Class Initialized
INFO - 2024-10-09 09:37:23 --> Router Class Initialized
INFO - 2024-10-09 09:37:23 --> Output Class Initialized
INFO - 2024-10-09 09:37:23 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:23 --> Input Class Initialized
INFO - 2024-10-09 09:37:23 --> Language Class Initialized
INFO - 2024-10-09 09:37:23 --> Language Class Initialized
INFO - 2024-10-09 09:37:23 --> Config Class Initialized
INFO - 2024-10-09 09:37:23 --> Loader Class Initialized
INFO - 2024-10-09 09:37:23 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:23 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:23 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:23 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:23 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:23 --> Controller Class Initialized
INFO - 2024-10-09 09:37:24 --> Config Class Initialized
INFO - 2024-10-09 09:37:24 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:24 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:24 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:24 --> URI Class Initialized
INFO - 2024-10-09 09:37:24 --> Router Class Initialized
INFO - 2024-10-09 09:37:24 --> Output Class Initialized
INFO - 2024-10-09 09:37:24 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:24 --> Input Class Initialized
INFO - 2024-10-09 09:37:24 --> Language Class Initialized
INFO - 2024-10-09 09:37:24 --> Language Class Initialized
INFO - 2024-10-09 09:37:24 --> Config Class Initialized
INFO - 2024-10-09 09:37:24 --> Loader Class Initialized
INFO - 2024-10-09 09:37:24 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:24 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:24 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:24 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:24 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:24 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:37:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:24 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:24 --> Total execution time: 0.0297
INFO - 2024-10-09 09:37:26 --> Config Class Initialized
INFO - 2024-10-09 09:37:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:26 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:26 --> URI Class Initialized
INFO - 2024-10-09 09:37:26 --> Router Class Initialized
INFO - 2024-10-09 09:37:26 --> Output Class Initialized
INFO - 2024-10-09 09:37:26 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:26 --> Input Class Initialized
INFO - 2024-10-09 09:37:26 --> Language Class Initialized
INFO - 2024-10-09 09:37:26 --> Language Class Initialized
INFO - 2024-10-09 09:37:26 --> Config Class Initialized
INFO - 2024-10-09 09:37:26 --> Loader Class Initialized
INFO - 2024-10-09 09:37:26 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:26 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:26 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:26 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:26 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:26 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 09:37:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:26 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:26 --> Total execution time: 0.0447
INFO - 2024-10-09 09:37:26 --> Config Class Initialized
INFO - 2024-10-09 09:37:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:26 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:26 --> URI Class Initialized
INFO - 2024-10-09 09:37:26 --> Router Class Initialized
INFO - 2024-10-09 09:37:26 --> Output Class Initialized
INFO - 2024-10-09 09:37:26 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:26 --> Input Class Initialized
INFO - 2024-10-09 09:37:26 --> Language Class Initialized
INFO - 2024-10-09 09:37:26 --> Language Class Initialized
INFO - 2024-10-09 09:37:26 --> Config Class Initialized
INFO - 2024-10-09 09:37:26 --> Loader Class Initialized
INFO - 2024-10-09 09:37:26 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:26 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:26 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:26 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:26 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:26 --> Controller Class Initialized
INFO - 2024-10-09 09:37:28 --> Config Class Initialized
INFO - 2024-10-09 09:37:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:28 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:28 --> URI Class Initialized
INFO - 2024-10-09 09:37:28 --> Router Class Initialized
INFO - 2024-10-09 09:37:28 --> Output Class Initialized
INFO - 2024-10-09 09:37:28 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:28 --> Input Class Initialized
INFO - 2024-10-09 09:37:28 --> Language Class Initialized
INFO - 2024-10-09 09:37:28 --> Language Class Initialized
INFO - 2024-10-09 09:37:28 --> Config Class Initialized
INFO - 2024-10-09 09:37:28 --> Loader Class Initialized
INFO - 2024-10-09 09:37:28 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:28 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:28 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:28 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:28 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:28 --> Controller Class Initialized
INFO - 2024-10-09 09:37:31 --> Config Class Initialized
INFO - 2024-10-09 09:37:31 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:31 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:31 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:31 --> URI Class Initialized
INFO - 2024-10-09 09:37:31 --> Router Class Initialized
INFO - 2024-10-09 09:37:32 --> Output Class Initialized
INFO - 2024-10-09 09:37:32 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:32 --> Input Class Initialized
INFO - 2024-10-09 09:37:32 --> Language Class Initialized
INFO - 2024-10-09 09:37:32 --> Language Class Initialized
INFO - 2024-10-09 09:37:32 --> Config Class Initialized
INFO - 2024-10-09 09:37:32 --> Loader Class Initialized
INFO - 2024-10-09 09:37:32 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:32 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:32 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:32 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:32 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:32 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:37:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:32 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:32 --> Total execution time: 0.0273
INFO - 2024-10-09 09:37:33 --> Config Class Initialized
INFO - 2024-10-09 09:37:33 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:33 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:33 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:33 --> URI Class Initialized
INFO - 2024-10-09 09:37:33 --> Router Class Initialized
INFO - 2024-10-09 09:37:33 --> Output Class Initialized
INFO - 2024-10-09 09:37:33 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:33 --> Input Class Initialized
INFO - 2024-10-09 09:37:33 --> Language Class Initialized
INFO - 2024-10-09 09:37:33 --> Language Class Initialized
INFO - 2024-10-09 09:37:33 --> Config Class Initialized
INFO - 2024-10-09 09:37:33 --> Loader Class Initialized
INFO - 2024-10-09 09:37:33 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:33 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:33 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:33 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:33 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:33 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 09:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:33 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:33 --> Total execution time: 0.0623
INFO - 2024-10-09 09:37:33 --> Config Class Initialized
INFO - 2024-10-09 09:37:33 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:33 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:33 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:33 --> URI Class Initialized
INFO - 2024-10-09 09:37:33 --> Router Class Initialized
INFO - 2024-10-09 09:37:33 --> Output Class Initialized
INFO - 2024-10-09 09:37:33 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:33 --> Input Class Initialized
INFO - 2024-10-09 09:37:33 --> Language Class Initialized
INFO - 2024-10-09 09:37:33 --> Language Class Initialized
INFO - 2024-10-09 09:37:33 --> Config Class Initialized
INFO - 2024-10-09 09:37:33 --> Loader Class Initialized
INFO - 2024-10-09 09:37:33 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:33 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:33 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:33 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:33 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:34 --> Controller Class Initialized
INFO - 2024-10-09 09:37:38 --> Config Class Initialized
INFO - 2024-10-09 09:37:38 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:38 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:38 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:38 --> URI Class Initialized
INFO - 2024-10-09 09:37:38 --> Router Class Initialized
INFO - 2024-10-09 09:37:38 --> Output Class Initialized
INFO - 2024-10-09 09:37:38 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:38 --> Input Class Initialized
INFO - 2024-10-09 09:37:38 --> Language Class Initialized
INFO - 2024-10-09 09:37:38 --> Language Class Initialized
INFO - 2024-10-09 09:37:38 --> Config Class Initialized
INFO - 2024-10-09 09:37:38 --> Loader Class Initialized
INFO - 2024-10-09 09:37:38 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:38 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:38 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:38 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:38 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:38 --> Controller Class Initialized
INFO - 2024-10-09 09:37:48 --> Config Class Initialized
INFO - 2024-10-09 09:37:48 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:48 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:48 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:48 --> URI Class Initialized
INFO - 2024-10-09 09:37:48 --> Router Class Initialized
INFO - 2024-10-09 09:37:48 --> Output Class Initialized
INFO - 2024-10-09 09:37:48 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:48 --> Input Class Initialized
INFO - 2024-10-09 09:37:48 --> Language Class Initialized
INFO - 2024-10-09 09:37:48 --> Language Class Initialized
INFO - 2024-10-09 09:37:48 --> Config Class Initialized
INFO - 2024-10-09 09:37:48 --> Loader Class Initialized
INFO - 2024-10-09 09:37:48 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:48 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:48 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:48 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:48 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:48 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:37:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:48 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:48 --> Total execution time: 0.0293
INFO - 2024-10-09 09:37:51 --> Config Class Initialized
INFO - 2024-10-09 09:37:51 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:51 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:51 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:51 --> URI Class Initialized
INFO - 2024-10-09 09:37:51 --> Router Class Initialized
INFO - 2024-10-09 09:37:51 --> Output Class Initialized
INFO - 2024-10-09 09:37:51 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:51 --> Input Class Initialized
INFO - 2024-10-09 09:37:51 --> Language Class Initialized
INFO - 2024-10-09 09:37:51 --> Language Class Initialized
INFO - 2024-10-09 09:37:51 --> Config Class Initialized
INFO - 2024-10-09 09:37:51 --> Loader Class Initialized
INFO - 2024-10-09 09:37:51 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:51 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:51 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:51 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:51 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:51 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 09:37:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:51 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:51 --> Total execution time: 0.0383
INFO - 2024-10-09 09:37:51 --> Config Class Initialized
INFO - 2024-10-09 09:37:51 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:51 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:51 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:51 --> URI Class Initialized
INFO - 2024-10-09 09:37:51 --> Router Class Initialized
INFO - 2024-10-09 09:37:51 --> Output Class Initialized
INFO - 2024-10-09 09:37:51 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:51 --> Input Class Initialized
INFO - 2024-10-09 09:37:51 --> Language Class Initialized
INFO - 2024-10-09 09:37:51 --> Language Class Initialized
INFO - 2024-10-09 09:37:51 --> Config Class Initialized
INFO - 2024-10-09 09:37:51 --> Loader Class Initialized
INFO - 2024-10-09 09:37:51 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:51 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:51 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:51 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:51 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:51 --> Controller Class Initialized
INFO - 2024-10-09 09:37:55 --> Config Class Initialized
INFO - 2024-10-09 09:37:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:55 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:55 --> URI Class Initialized
INFO - 2024-10-09 09:37:55 --> Router Class Initialized
INFO - 2024-10-09 09:37:55 --> Output Class Initialized
INFO - 2024-10-09 09:37:55 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:55 --> Input Class Initialized
INFO - 2024-10-09 09:37:55 --> Language Class Initialized
INFO - 2024-10-09 09:37:55 --> Language Class Initialized
INFO - 2024-10-09 09:37:55 --> Config Class Initialized
INFO - 2024-10-09 09:37:55 --> Loader Class Initialized
INFO - 2024-10-09 09:37:55 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:55 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:55 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:55 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:55 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:55 --> Controller Class Initialized
INFO - 2024-10-09 09:37:57 --> Config Class Initialized
INFO - 2024-10-09 09:37:57 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:57 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:57 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:57 --> URI Class Initialized
INFO - 2024-10-09 09:37:57 --> Router Class Initialized
INFO - 2024-10-09 09:37:57 --> Output Class Initialized
INFO - 2024-10-09 09:37:57 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:57 --> Input Class Initialized
INFO - 2024-10-09 09:37:57 --> Language Class Initialized
INFO - 2024-10-09 09:37:57 --> Language Class Initialized
INFO - 2024-10-09 09:37:57 --> Config Class Initialized
INFO - 2024-10-09 09:37:57 --> Loader Class Initialized
INFO - 2024-10-09 09:37:57 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:57 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:57 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:57 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:57 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:57 --> Controller Class Initialized
DEBUG - 2024-10-09 09:37:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 09:37:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:37:57 --> Final output sent to browser
DEBUG - 2024-10-09 09:37:57 --> Total execution time: 0.0327
INFO - 2024-10-09 09:37:58 --> Config Class Initialized
INFO - 2024-10-09 09:37:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:37:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:37:58 --> Utf8 Class Initialized
INFO - 2024-10-09 09:37:58 --> URI Class Initialized
INFO - 2024-10-09 09:37:58 --> Router Class Initialized
INFO - 2024-10-09 09:37:58 --> Output Class Initialized
INFO - 2024-10-09 09:37:58 --> Security Class Initialized
DEBUG - 2024-10-09 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:37:58 --> Input Class Initialized
INFO - 2024-10-09 09:37:58 --> Language Class Initialized
INFO - 2024-10-09 09:37:58 --> Language Class Initialized
INFO - 2024-10-09 09:37:58 --> Config Class Initialized
INFO - 2024-10-09 09:37:58 --> Loader Class Initialized
INFO - 2024-10-09 09:37:58 --> Helper loaded: url_helper
INFO - 2024-10-09 09:37:58 --> Helper loaded: file_helper
INFO - 2024-10-09 09:37:58 --> Helper loaded: form_helper
INFO - 2024-10-09 09:37:58 --> Helper loaded: my_helper
INFO - 2024-10-09 09:37:58 --> Database Driver Class Initialized
INFO - 2024-10-09 09:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:37:58 --> Controller Class Initialized
INFO - 2024-10-09 09:38:00 --> Config Class Initialized
INFO - 2024-10-09 09:38:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:00 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:00 --> URI Class Initialized
INFO - 2024-10-09 09:38:00 --> Router Class Initialized
INFO - 2024-10-09 09:38:00 --> Output Class Initialized
INFO - 2024-10-09 09:38:00 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:00 --> Input Class Initialized
INFO - 2024-10-09 09:38:00 --> Language Class Initialized
INFO - 2024-10-09 09:38:00 --> Language Class Initialized
INFO - 2024-10-09 09:38:00 --> Config Class Initialized
INFO - 2024-10-09 09:38:00 --> Loader Class Initialized
INFO - 2024-10-09 09:38:00 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:00 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:00 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:00 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:00 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:00 --> Controller Class Initialized
DEBUG - 2024-10-09 09:38:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:38:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:38:00 --> Final output sent to browser
DEBUG - 2024-10-09 09:38:00 --> Total execution time: 0.0288
INFO - 2024-10-09 09:38:45 --> Config Class Initialized
INFO - 2024-10-09 09:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:45 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:45 --> URI Class Initialized
INFO - 2024-10-09 09:38:45 --> Router Class Initialized
INFO - 2024-10-09 09:38:45 --> Output Class Initialized
INFO - 2024-10-09 09:38:45 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:45 --> Input Class Initialized
INFO - 2024-10-09 09:38:45 --> Language Class Initialized
INFO - 2024-10-09 09:38:45 --> Language Class Initialized
INFO - 2024-10-09 09:38:45 --> Config Class Initialized
INFO - 2024-10-09 09:38:45 --> Loader Class Initialized
INFO - 2024-10-09 09:38:45 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:45 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:45 --> Controller Class Initialized
INFO - 2024-10-09 09:38:45 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:38:45 --> Config Class Initialized
INFO - 2024-10-09 09:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:45 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:45 --> URI Class Initialized
INFO - 2024-10-09 09:38:45 --> Router Class Initialized
INFO - 2024-10-09 09:38:45 --> Output Class Initialized
INFO - 2024-10-09 09:38:45 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:45 --> Input Class Initialized
INFO - 2024-10-09 09:38:45 --> Language Class Initialized
INFO - 2024-10-09 09:38:45 --> Language Class Initialized
INFO - 2024-10-09 09:38:45 --> Config Class Initialized
INFO - 2024-10-09 09:38:45 --> Loader Class Initialized
INFO - 2024-10-09 09:38:45 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:45 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:45 --> Controller Class Initialized
INFO - 2024-10-09 09:38:45 --> Config Class Initialized
INFO - 2024-10-09 09:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:45 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:45 --> URI Class Initialized
INFO - 2024-10-09 09:38:45 --> Router Class Initialized
INFO - 2024-10-09 09:38:45 --> Output Class Initialized
INFO - 2024-10-09 09:38:45 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:45 --> Input Class Initialized
INFO - 2024-10-09 09:38:45 --> Language Class Initialized
INFO - 2024-10-09 09:38:45 --> Language Class Initialized
INFO - 2024-10-09 09:38:45 --> Config Class Initialized
INFO - 2024-10-09 09:38:45 --> Loader Class Initialized
INFO - 2024-10-09 09:38:45 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:45 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:45 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:45 --> Controller Class Initialized
DEBUG - 2024-10-09 09:38:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:38:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:38:45 --> Final output sent to browser
DEBUG - 2024-10-09 09:38:45 --> Total execution time: 0.0320
INFO - 2024-10-09 09:38:50 --> Config Class Initialized
INFO - 2024-10-09 09:38:50 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:50 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:50 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:50 --> URI Class Initialized
INFO - 2024-10-09 09:38:50 --> Router Class Initialized
INFO - 2024-10-09 09:38:50 --> Output Class Initialized
INFO - 2024-10-09 09:38:50 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:50 --> Input Class Initialized
INFO - 2024-10-09 09:38:50 --> Language Class Initialized
INFO - 2024-10-09 09:38:50 --> Language Class Initialized
INFO - 2024-10-09 09:38:50 --> Config Class Initialized
INFO - 2024-10-09 09:38:50 --> Loader Class Initialized
INFO - 2024-10-09 09:38:50 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:50 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:50 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:50 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:50 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:50 --> Controller Class Initialized
INFO - 2024-10-09 09:38:50 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:38:50 --> Final output sent to browser
DEBUG - 2024-10-09 09:38:50 --> Total execution time: 0.0339
INFO - 2024-10-09 09:38:50 --> Config Class Initialized
INFO - 2024-10-09 09:38:50 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:50 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:50 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:50 --> URI Class Initialized
INFO - 2024-10-09 09:38:50 --> Router Class Initialized
INFO - 2024-10-09 09:38:50 --> Output Class Initialized
INFO - 2024-10-09 09:38:50 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:50 --> Input Class Initialized
INFO - 2024-10-09 09:38:50 --> Language Class Initialized
INFO - 2024-10-09 09:38:50 --> Language Class Initialized
INFO - 2024-10-09 09:38:50 --> Config Class Initialized
INFO - 2024-10-09 09:38:50 --> Loader Class Initialized
INFO - 2024-10-09 09:38:50 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:50 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:50 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:50 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:50 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:50 --> Controller Class Initialized
DEBUG - 2024-10-09 09:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-09 09:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:38:51 --> Final output sent to browser
DEBUG - 2024-10-09 09:38:51 --> Total execution time: 0.0530
INFO - 2024-10-09 09:38:53 --> Config Class Initialized
INFO - 2024-10-09 09:38:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:53 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:53 --> URI Class Initialized
INFO - 2024-10-09 09:38:53 --> Router Class Initialized
INFO - 2024-10-09 09:38:53 --> Output Class Initialized
INFO - 2024-10-09 09:38:53 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:53 --> Input Class Initialized
INFO - 2024-10-09 09:38:53 --> Language Class Initialized
INFO - 2024-10-09 09:38:53 --> Language Class Initialized
INFO - 2024-10-09 09:38:53 --> Config Class Initialized
INFO - 2024-10-09 09:38:53 --> Loader Class Initialized
INFO - 2024-10-09 09:38:53 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:53 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:53 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:53 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:53 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:53 --> Controller Class Initialized
DEBUG - 2024-10-09 09:38:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-09 09:38:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:38:53 --> Final output sent to browser
DEBUG - 2024-10-09 09:38:53 --> Total execution time: 0.0316
INFO - 2024-10-09 09:38:56 --> Config Class Initialized
INFO - 2024-10-09 09:38:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:56 --> URI Class Initialized
INFO - 2024-10-09 09:38:56 --> Router Class Initialized
INFO - 2024-10-09 09:38:56 --> Output Class Initialized
INFO - 2024-10-09 09:38:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:56 --> Input Class Initialized
INFO - 2024-10-09 09:38:56 --> Language Class Initialized
INFO - 2024-10-09 09:38:56 --> Language Class Initialized
INFO - 2024-10-09 09:38:56 --> Config Class Initialized
INFO - 2024-10-09 09:38:56 --> Loader Class Initialized
INFO - 2024-10-09 09:38:56 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:56 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:56 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:56 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:56 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:56 --> Controller Class Initialized
DEBUG - 2024-10-09 09:38:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-10-09 09:38:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:38:56 --> Final output sent to browser
DEBUG - 2024-10-09 09:38:56 --> Total execution time: 0.0279
INFO - 2024-10-09 09:38:56 --> Config Class Initialized
INFO - 2024-10-09 09:38:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:56 --> URI Class Initialized
INFO - 2024-10-09 09:38:56 --> Router Class Initialized
INFO - 2024-10-09 09:38:56 --> Output Class Initialized
INFO - 2024-10-09 09:38:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:56 --> Input Class Initialized
INFO - 2024-10-09 09:38:56 --> Language Class Initialized
ERROR - 2024-10-09 09:38:56 --> 404 Page Not Found: /index
INFO - 2024-10-09 09:38:56 --> Config Class Initialized
INFO - 2024-10-09 09:38:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:38:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:38:56 --> Utf8 Class Initialized
INFO - 2024-10-09 09:38:56 --> URI Class Initialized
INFO - 2024-10-09 09:38:56 --> Router Class Initialized
INFO - 2024-10-09 09:38:56 --> Output Class Initialized
INFO - 2024-10-09 09:38:56 --> Security Class Initialized
DEBUG - 2024-10-09 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:38:56 --> Input Class Initialized
INFO - 2024-10-09 09:38:56 --> Language Class Initialized
INFO - 2024-10-09 09:38:56 --> Language Class Initialized
INFO - 2024-10-09 09:38:56 --> Config Class Initialized
INFO - 2024-10-09 09:38:56 --> Loader Class Initialized
INFO - 2024-10-09 09:38:56 --> Helper loaded: url_helper
INFO - 2024-10-09 09:38:56 --> Helper loaded: file_helper
INFO - 2024-10-09 09:38:56 --> Helper loaded: form_helper
INFO - 2024-10-09 09:38:56 --> Helper loaded: my_helper
INFO - 2024-10-09 09:38:56 --> Database Driver Class Initialized
INFO - 2024-10-09 09:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:38:56 --> Controller Class Initialized
INFO - 2024-10-09 09:52:59 --> Config Class Initialized
INFO - 2024-10-09 09:52:59 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:52:59 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:52:59 --> Utf8 Class Initialized
INFO - 2024-10-09 09:52:59 --> URI Class Initialized
INFO - 2024-10-09 09:52:59 --> Router Class Initialized
INFO - 2024-10-09 09:52:59 --> Output Class Initialized
INFO - 2024-10-09 09:52:59 --> Security Class Initialized
DEBUG - 2024-10-09 09:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:52:59 --> Input Class Initialized
INFO - 2024-10-09 09:52:59 --> Language Class Initialized
INFO - 2024-10-09 09:52:59 --> Language Class Initialized
INFO - 2024-10-09 09:52:59 --> Config Class Initialized
INFO - 2024-10-09 09:52:59 --> Loader Class Initialized
INFO - 2024-10-09 09:52:59 --> Helper loaded: url_helper
INFO - 2024-10-09 09:52:59 --> Helper loaded: file_helper
INFO - 2024-10-09 09:52:59 --> Helper loaded: form_helper
INFO - 2024-10-09 09:52:59 --> Helper loaded: my_helper
INFO - 2024-10-09 09:52:59 --> Database Driver Class Initialized
INFO - 2024-10-09 09:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:52:59 --> Controller Class Initialized
INFO - 2024-10-09 09:52:59 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:53:00 --> Config Class Initialized
INFO - 2024-10-09 09:53:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:00 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:00 --> URI Class Initialized
INFO - 2024-10-09 09:53:00 --> Router Class Initialized
INFO - 2024-10-09 09:53:00 --> Output Class Initialized
INFO - 2024-10-09 09:53:00 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:00 --> Input Class Initialized
INFO - 2024-10-09 09:53:00 --> Language Class Initialized
INFO - 2024-10-09 09:53:00 --> Language Class Initialized
INFO - 2024-10-09 09:53:00 --> Config Class Initialized
INFO - 2024-10-09 09:53:00 --> Loader Class Initialized
INFO - 2024-10-09 09:53:00 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:00 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:00 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:00 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:00 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:00 --> Controller Class Initialized
INFO - 2024-10-09 09:53:00 --> Config Class Initialized
INFO - 2024-10-09 09:53:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:00 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:00 --> URI Class Initialized
INFO - 2024-10-09 09:53:00 --> Router Class Initialized
INFO - 2024-10-09 09:53:00 --> Output Class Initialized
INFO - 2024-10-09 09:53:00 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:00 --> Input Class Initialized
INFO - 2024-10-09 09:53:00 --> Language Class Initialized
INFO - 2024-10-09 09:53:00 --> Language Class Initialized
INFO - 2024-10-09 09:53:00 --> Config Class Initialized
INFO - 2024-10-09 09:53:00 --> Loader Class Initialized
INFO - 2024-10-09 09:53:00 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:00 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:00 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:00 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:00 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:00 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:53:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:00 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:00 --> Total execution time: 0.0313
INFO - 2024-10-09 09:53:09 --> Config Class Initialized
INFO - 2024-10-09 09:53:09 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:09 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:09 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:09 --> URI Class Initialized
INFO - 2024-10-09 09:53:09 --> Router Class Initialized
INFO - 2024-10-09 09:53:09 --> Output Class Initialized
INFO - 2024-10-09 09:53:09 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:09 --> Input Class Initialized
INFO - 2024-10-09 09:53:09 --> Language Class Initialized
INFO - 2024-10-09 09:53:09 --> Language Class Initialized
INFO - 2024-10-09 09:53:09 --> Config Class Initialized
INFO - 2024-10-09 09:53:09 --> Loader Class Initialized
INFO - 2024-10-09 09:53:09 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:09 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:09 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:09 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:09 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:09 --> Controller Class Initialized
INFO - 2024-10-09 09:53:09 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:53:09 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:09 --> Total execution time: 0.0342
INFO - 2024-10-09 09:53:09 --> Config Class Initialized
INFO - 2024-10-09 09:53:09 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:09 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:09 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:09 --> URI Class Initialized
INFO - 2024-10-09 09:53:09 --> Router Class Initialized
INFO - 2024-10-09 09:53:09 --> Output Class Initialized
INFO - 2024-10-09 09:53:09 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:09 --> Input Class Initialized
INFO - 2024-10-09 09:53:09 --> Language Class Initialized
INFO - 2024-10-09 09:53:09 --> Language Class Initialized
INFO - 2024-10-09 09:53:09 --> Config Class Initialized
INFO - 2024-10-09 09:53:09 --> Loader Class Initialized
INFO - 2024-10-09 09:53:09 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:09 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:09 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:09 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:09 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:09 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 09:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:09 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:09 --> Total execution time: 0.0321
INFO - 2024-10-09 09:53:11 --> Config Class Initialized
INFO - 2024-10-09 09:53:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:11 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:11 --> URI Class Initialized
INFO - 2024-10-09 09:53:12 --> Router Class Initialized
INFO - 2024-10-09 09:53:12 --> Output Class Initialized
INFO - 2024-10-09 09:53:12 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:12 --> Input Class Initialized
INFO - 2024-10-09 09:53:12 --> Language Class Initialized
INFO - 2024-10-09 09:53:12 --> Language Class Initialized
INFO - 2024-10-09 09:53:12 --> Config Class Initialized
INFO - 2024-10-09 09:53:12 --> Loader Class Initialized
INFO - 2024-10-09 09:53:12 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:12 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:12 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:12 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:12 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:12 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:53:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:12 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:12 --> Total execution time: 0.0329
INFO - 2024-10-09 09:53:15 --> Config Class Initialized
INFO - 2024-10-09 09:53:15 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:15 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:15 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:15 --> URI Class Initialized
INFO - 2024-10-09 09:53:15 --> Router Class Initialized
INFO - 2024-10-09 09:53:15 --> Output Class Initialized
INFO - 2024-10-09 09:53:15 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:15 --> Input Class Initialized
INFO - 2024-10-09 09:53:15 --> Language Class Initialized
INFO - 2024-10-09 09:53:15 --> Language Class Initialized
INFO - 2024-10-09 09:53:15 --> Config Class Initialized
INFO - 2024-10-09 09:53:15 --> Loader Class Initialized
INFO - 2024-10-09 09:53:15 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:15 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:15 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:15 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:15 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:15 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 09:53:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:15 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:15 --> Total execution time: 0.0357
INFO - 2024-10-09 09:53:15 --> Config Class Initialized
INFO - 2024-10-09 09:53:15 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:15 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:15 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:15 --> URI Class Initialized
INFO - 2024-10-09 09:53:15 --> Router Class Initialized
INFO - 2024-10-09 09:53:15 --> Output Class Initialized
INFO - 2024-10-09 09:53:15 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:15 --> Input Class Initialized
INFO - 2024-10-09 09:53:15 --> Language Class Initialized
INFO - 2024-10-09 09:53:15 --> Language Class Initialized
INFO - 2024-10-09 09:53:15 --> Config Class Initialized
INFO - 2024-10-09 09:53:15 --> Loader Class Initialized
INFO - 2024-10-09 09:53:15 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:15 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:15 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:15 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:15 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:15 --> Controller Class Initialized
INFO - 2024-10-09 09:53:17 --> Config Class Initialized
INFO - 2024-10-09 09:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:17 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:17 --> URI Class Initialized
INFO - 2024-10-09 09:53:17 --> Router Class Initialized
INFO - 2024-10-09 09:53:17 --> Output Class Initialized
INFO - 2024-10-09 09:53:17 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:17 --> Input Class Initialized
INFO - 2024-10-09 09:53:17 --> Language Class Initialized
INFO - 2024-10-09 09:53:17 --> Language Class Initialized
INFO - 2024-10-09 09:53:17 --> Config Class Initialized
INFO - 2024-10-09 09:53:17 --> Loader Class Initialized
INFO - 2024-10-09 09:53:17 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:17 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:17 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:17 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:17 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:17 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:53:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:17 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:17 --> Total execution time: 0.0308
INFO - 2024-10-09 09:53:19 --> Config Class Initialized
INFO - 2024-10-09 09:53:19 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:19 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:19 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:19 --> URI Class Initialized
INFO - 2024-10-09 09:53:19 --> Router Class Initialized
INFO - 2024-10-09 09:53:19 --> Output Class Initialized
INFO - 2024-10-09 09:53:19 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:19 --> Input Class Initialized
INFO - 2024-10-09 09:53:19 --> Language Class Initialized
INFO - 2024-10-09 09:53:19 --> Language Class Initialized
INFO - 2024-10-09 09:53:19 --> Config Class Initialized
INFO - 2024-10-09 09:53:19 --> Loader Class Initialized
INFO - 2024-10-09 09:53:19 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:19 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:19 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:19 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:19 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:19 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:53:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:19 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:19 --> Total execution time: 0.0392
INFO - 2024-10-09 09:53:21 --> Config Class Initialized
INFO - 2024-10-09 09:53:21 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:21 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:21 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:21 --> URI Class Initialized
INFO - 2024-10-09 09:53:21 --> Router Class Initialized
INFO - 2024-10-09 09:53:21 --> Output Class Initialized
INFO - 2024-10-09 09:53:21 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:21 --> Input Class Initialized
INFO - 2024-10-09 09:53:21 --> Language Class Initialized
INFO - 2024-10-09 09:53:21 --> Language Class Initialized
INFO - 2024-10-09 09:53:21 --> Config Class Initialized
INFO - 2024-10-09 09:53:21 --> Loader Class Initialized
INFO - 2024-10-09 09:53:21 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:21 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:21 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:21 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:21 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:21 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-09 09:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:21 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:21 --> Total execution time: 0.0320
INFO - 2024-10-09 09:53:28 --> Config Class Initialized
INFO - 2024-10-09 09:53:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:28 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:28 --> URI Class Initialized
INFO - 2024-10-09 09:53:28 --> Router Class Initialized
INFO - 2024-10-09 09:53:28 --> Output Class Initialized
INFO - 2024-10-09 09:53:28 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:28 --> Input Class Initialized
INFO - 2024-10-09 09:53:28 --> Language Class Initialized
INFO - 2024-10-09 09:53:28 --> Language Class Initialized
INFO - 2024-10-09 09:53:28 --> Config Class Initialized
INFO - 2024-10-09 09:53:28 --> Loader Class Initialized
INFO - 2024-10-09 09:53:28 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:28 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:28 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:28 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:28 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:28 --> Controller Class Initialized
INFO - 2024-10-09 09:53:29 --> Config Class Initialized
INFO - 2024-10-09 09:53:29 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:29 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:29 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:29 --> URI Class Initialized
INFO - 2024-10-09 09:53:29 --> Router Class Initialized
INFO - 2024-10-09 09:53:29 --> Output Class Initialized
INFO - 2024-10-09 09:53:29 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:29 --> Input Class Initialized
INFO - 2024-10-09 09:53:29 --> Language Class Initialized
INFO - 2024-10-09 09:53:29 --> Language Class Initialized
INFO - 2024-10-09 09:53:29 --> Config Class Initialized
INFO - 2024-10-09 09:53:29 --> Loader Class Initialized
INFO - 2024-10-09 09:53:29 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:29 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:29 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:29 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:29 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:29 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:53:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:29 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:29 --> Total execution time: 0.0446
INFO - 2024-10-09 09:53:30 --> Config Class Initialized
INFO - 2024-10-09 09:53:30 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:30 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:30 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:30 --> URI Class Initialized
INFO - 2024-10-09 09:53:30 --> Router Class Initialized
INFO - 2024-10-09 09:53:30 --> Output Class Initialized
INFO - 2024-10-09 09:53:30 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:30 --> Input Class Initialized
INFO - 2024-10-09 09:53:30 --> Language Class Initialized
INFO - 2024-10-09 09:53:30 --> Language Class Initialized
INFO - 2024-10-09 09:53:30 --> Config Class Initialized
INFO - 2024-10-09 09:53:30 --> Loader Class Initialized
INFO - 2024-10-09 09:53:30 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:30 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:30 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:30 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:30 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:30 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:53:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:30 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:30 --> Total execution time: 0.0492
INFO - 2024-10-09 09:53:32 --> Config Class Initialized
INFO - 2024-10-09 09:53:32 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:32 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:32 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:32 --> URI Class Initialized
INFO - 2024-10-09 09:53:32 --> Router Class Initialized
INFO - 2024-10-09 09:53:32 --> Output Class Initialized
INFO - 2024-10-09 09:53:32 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:32 --> Input Class Initialized
INFO - 2024-10-09 09:53:32 --> Language Class Initialized
INFO - 2024-10-09 09:53:32 --> Language Class Initialized
INFO - 2024-10-09 09:53:32 --> Config Class Initialized
INFO - 2024-10-09 09:53:32 --> Loader Class Initialized
INFO - 2024-10-09 09:53:32 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:32 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:32 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:32 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:32 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:32 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:53:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:32 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:32 --> Total execution time: 0.0315
INFO - 2024-10-09 09:53:34 --> Config Class Initialized
INFO - 2024-10-09 09:53:34 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:34 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:34 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:34 --> URI Class Initialized
INFO - 2024-10-09 09:53:34 --> Router Class Initialized
INFO - 2024-10-09 09:53:34 --> Output Class Initialized
INFO - 2024-10-09 09:53:34 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:34 --> Input Class Initialized
INFO - 2024-10-09 09:53:34 --> Language Class Initialized
INFO - 2024-10-09 09:53:34 --> Language Class Initialized
INFO - 2024-10-09 09:53:34 --> Config Class Initialized
INFO - 2024-10-09 09:53:34 --> Loader Class Initialized
INFO - 2024-10-09 09:53:34 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:34 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:34 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:34 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:34 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:34 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-09 09:53:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:34 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:34 --> Total execution time: 0.0337
INFO - 2024-10-09 09:53:41 --> Config Class Initialized
INFO - 2024-10-09 09:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:41 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:41 --> URI Class Initialized
INFO - 2024-10-09 09:53:41 --> Router Class Initialized
INFO - 2024-10-09 09:53:41 --> Output Class Initialized
INFO - 2024-10-09 09:53:41 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:41 --> Input Class Initialized
INFO - 2024-10-09 09:53:41 --> Language Class Initialized
INFO - 2024-10-09 09:53:41 --> Language Class Initialized
INFO - 2024-10-09 09:53:41 --> Config Class Initialized
INFO - 2024-10-09 09:53:41 --> Loader Class Initialized
INFO - 2024-10-09 09:53:41 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:41 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:41 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:41 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:41 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:41 --> Controller Class Initialized
INFO - 2024-10-09 09:53:42 --> Config Class Initialized
INFO - 2024-10-09 09:53:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:42 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:42 --> URI Class Initialized
INFO - 2024-10-09 09:53:42 --> Router Class Initialized
INFO - 2024-10-09 09:53:42 --> Output Class Initialized
INFO - 2024-10-09 09:53:42 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:42 --> Input Class Initialized
INFO - 2024-10-09 09:53:42 --> Language Class Initialized
INFO - 2024-10-09 09:53:42 --> Language Class Initialized
INFO - 2024-10-09 09:53:42 --> Config Class Initialized
INFO - 2024-10-09 09:53:42 --> Loader Class Initialized
INFO - 2024-10-09 09:53:42 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:42 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:42 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:42 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:42 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:42 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:42 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:42 --> Total execution time: 0.0319
INFO - 2024-10-09 09:53:43 --> Config Class Initialized
INFO - 2024-10-09 09:53:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:43 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:43 --> URI Class Initialized
INFO - 2024-10-09 09:53:43 --> Router Class Initialized
INFO - 2024-10-09 09:53:43 --> Output Class Initialized
INFO - 2024-10-09 09:53:43 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:43 --> Input Class Initialized
INFO - 2024-10-09 09:53:43 --> Language Class Initialized
INFO - 2024-10-09 09:53:43 --> Language Class Initialized
INFO - 2024-10-09 09:53:43 --> Config Class Initialized
INFO - 2024-10-09 09:53:43 --> Loader Class Initialized
INFO - 2024-10-09 09:53:43 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:43 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:43 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:43 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:43 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:43 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 09:53:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:43 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:43 --> Total execution time: 0.0250
INFO - 2024-10-09 09:53:45 --> Config Class Initialized
INFO - 2024-10-09 09:53:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:45 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:45 --> URI Class Initialized
INFO - 2024-10-09 09:53:45 --> Router Class Initialized
INFO - 2024-10-09 09:53:45 --> Output Class Initialized
INFO - 2024-10-09 09:53:45 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:45 --> Input Class Initialized
INFO - 2024-10-09 09:53:45 --> Language Class Initialized
INFO - 2024-10-09 09:53:45 --> Language Class Initialized
INFO - 2024-10-09 09:53:45 --> Config Class Initialized
INFO - 2024-10-09 09:53:45 --> Loader Class Initialized
INFO - 2024-10-09 09:53:45 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:45 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:45 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:45 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:45 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:45 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:53:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:45 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:45 --> Total execution time: 0.0298
INFO - 2024-10-09 09:53:47 --> Config Class Initialized
INFO - 2024-10-09 09:53:47 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:47 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:47 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:47 --> URI Class Initialized
INFO - 2024-10-09 09:53:47 --> Router Class Initialized
INFO - 2024-10-09 09:53:47 --> Output Class Initialized
INFO - 2024-10-09 09:53:47 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:47 --> Input Class Initialized
INFO - 2024-10-09 09:53:47 --> Language Class Initialized
INFO - 2024-10-09 09:53:47 --> Language Class Initialized
INFO - 2024-10-09 09:53:47 --> Config Class Initialized
INFO - 2024-10-09 09:53:47 --> Loader Class Initialized
INFO - 2024-10-09 09:53:47 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:47 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:47 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:47 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:47 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:47 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-09 09:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:47 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:47 --> Total execution time: 0.0340
INFO - 2024-10-09 09:53:55 --> Config Class Initialized
INFO - 2024-10-09 09:53:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:55 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:55 --> URI Class Initialized
INFO - 2024-10-09 09:53:55 --> Router Class Initialized
INFO - 2024-10-09 09:53:55 --> Output Class Initialized
INFO - 2024-10-09 09:53:55 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:55 --> Input Class Initialized
INFO - 2024-10-09 09:53:55 --> Language Class Initialized
INFO - 2024-10-09 09:53:55 --> Language Class Initialized
INFO - 2024-10-09 09:53:55 --> Config Class Initialized
INFO - 2024-10-09 09:53:55 --> Loader Class Initialized
INFO - 2024-10-09 09:53:55 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:55 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:55 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:55 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:55 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:55 --> Controller Class Initialized
INFO - 2024-10-09 09:53:55 --> Config Class Initialized
INFO - 2024-10-09 09:53:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:53:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:53:55 --> Utf8 Class Initialized
INFO - 2024-10-09 09:53:55 --> URI Class Initialized
INFO - 2024-10-09 09:53:55 --> Router Class Initialized
INFO - 2024-10-09 09:53:55 --> Output Class Initialized
INFO - 2024-10-09 09:53:55 --> Security Class Initialized
DEBUG - 2024-10-09 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:53:55 --> Input Class Initialized
INFO - 2024-10-09 09:53:55 --> Language Class Initialized
INFO - 2024-10-09 09:53:55 --> Language Class Initialized
INFO - 2024-10-09 09:53:55 --> Config Class Initialized
INFO - 2024-10-09 09:53:55 --> Loader Class Initialized
INFO - 2024-10-09 09:53:55 --> Helper loaded: url_helper
INFO - 2024-10-09 09:53:55 --> Helper loaded: file_helper
INFO - 2024-10-09 09:53:55 --> Helper loaded: form_helper
INFO - 2024-10-09 09:53:55 --> Helper loaded: my_helper
INFO - 2024-10-09 09:53:55 --> Database Driver Class Initialized
INFO - 2024-10-09 09:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:53:55 --> Controller Class Initialized
DEBUG - 2024-10-09 09:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 09:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:53:55 --> Final output sent to browser
DEBUG - 2024-10-09 09:53:55 --> Total execution time: 0.0289
INFO - 2024-10-09 09:54:57 --> Config Class Initialized
INFO - 2024-10-09 09:54:57 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:54:57 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:54:57 --> Utf8 Class Initialized
INFO - 2024-10-09 09:54:57 --> URI Class Initialized
INFO - 2024-10-09 09:54:57 --> Router Class Initialized
INFO - 2024-10-09 09:54:57 --> Output Class Initialized
INFO - 2024-10-09 09:54:57 --> Security Class Initialized
DEBUG - 2024-10-09 09:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:54:57 --> Input Class Initialized
INFO - 2024-10-09 09:54:57 --> Language Class Initialized
INFO - 2024-10-09 09:54:57 --> Language Class Initialized
INFO - 2024-10-09 09:54:57 --> Config Class Initialized
INFO - 2024-10-09 09:54:57 --> Loader Class Initialized
INFO - 2024-10-09 09:54:57 --> Helper loaded: url_helper
INFO - 2024-10-09 09:54:57 --> Helper loaded: file_helper
INFO - 2024-10-09 09:54:57 --> Helper loaded: form_helper
INFO - 2024-10-09 09:54:57 --> Helper loaded: my_helper
INFO - 2024-10-09 09:54:57 --> Database Driver Class Initialized
INFO - 2024-10-09 09:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:54:57 --> Controller Class Initialized
INFO - 2024-10-09 09:54:57 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:54:58 --> Config Class Initialized
INFO - 2024-10-09 09:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:54:58 --> Utf8 Class Initialized
INFO - 2024-10-09 09:54:58 --> URI Class Initialized
INFO - 2024-10-09 09:54:58 --> Router Class Initialized
INFO - 2024-10-09 09:54:58 --> Output Class Initialized
INFO - 2024-10-09 09:54:58 --> Security Class Initialized
DEBUG - 2024-10-09 09:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:54:58 --> Input Class Initialized
INFO - 2024-10-09 09:54:58 --> Language Class Initialized
INFO - 2024-10-09 09:54:58 --> Language Class Initialized
INFO - 2024-10-09 09:54:58 --> Config Class Initialized
INFO - 2024-10-09 09:54:58 --> Loader Class Initialized
INFO - 2024-10-09 09:54:58 --> Helper loaded: url_helper
INFO - 2024-10-09 09:54:58 --> Helper loaded: file_helper
INFO - 2024-10-09 09:54:58 --> Helper loaded: form_helper
INFO - 2024-10-09 09:54:58 --> Helper loaded: my_helper
INFO - 2024-10-09 09:54:58 --> Database Driver Class Initialized
INFO - 2024-10-09 09:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:54:58 --> Controller Class Initialized
INFO - 2024-10-09 09:54:58 --> Config Class Initialized
INFO - 2024-10-09 09:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:54:58 --> Utf8 Class Initialized
INFO - 2024-10-09 09:54:58 --> URI Class Initialized
INFO - 2024-10-09 09:54:58 --> Router Class Initialized
INFO - 2024-10-09 09:54:58 --> Output Class Initialized
INFO - 2024-10-09 09:54:58 --> Security Class Initialized
DEBUG - 2024-10-09 09:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:54:58 --> Input Class Initialized
INFO - 2024-10-09 09:54:58 --> Language Class Initialized
INFO - 2024-10-09 09:54:58 --> Language Class Initialized
INFO - 2024-10-09 09:54:58 --> Config Class Initialized
INFO - 2024-10-09 09:54:58 --> Loader Class Initialized
INFO - 2024-10-09 09:54:58 --> Helper loaded: url_helper
INFO - 2024-10-09 09:54:58 --> Helper loaded: file_helper
INFO - 2024-10-09 09:54:58 --> Helper loaded: form_helper
INFO - 2024-10-09 09:54:58 --> Helper loaded: my_helper
INFO - 2024-10-09 09:54:58 --> Database Driver Class Initialized
INFO - 2024-10-09 09:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:54:58 --> Controller Class Initialized
DEBUG - 2024-10-09 09:54:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 09:54:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:54:58 --> Final output sent to browser
DEBUG - 2024-10-09 09:54:58 --> Total execution time: 0.0289
INFO - 2024-10-09 09:55:12 --> Config Class Initialized
INFO - 2024-10-09 09:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:55:12 --> Utf8 Class Initialized
INFO - 2024-10-09 09:55:12 --> URI Class Initialized
INFO - 2024-10-09 09:55:12 --> Router Class Initialized
INFO - 2024-10-09 09:55:12 --> Output Class Initialized
INFO - 2024-10-09 09:55:12 --> Security Class Initialized
DEBUG - 2024-10-09 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:55:12 --> Input Class Initialized
INFO - 2024-10-09 09:55:12 --> Language Class Initialized
INFO - 2024-10-09 09:55:12 --> Language Class Initialized
INFO - 2024-10-09 09:55:12 --> Config Class Initialized
INFO - 2024-10-09 09:55:12 --> Loader Class Initialized
INFO - 2024-10-09 09:55:12 --> Helper loaded: url_helper
INFO - 2024-10-09 09:55:12 --> Helper loaded: file_helper
INFO - 2024-10-09 09:55:12 --> Helper loaded: form_helper
INFO - 2024-10-09 09:55:12 --> Helper loaded: my_helper
INFO - 2024-10-09 09:55:12 --> Database Driver Class Initialized
INFO - 2024-10-09 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:55:12 --> Controller Class Initialized
INFO - 2024-10-09 09:55:12 --> Helper loaded: cookie_helper
INFO - 2024-10-09 09:55:12 --> Final output sent to browser
DEBUG - 2024-10-09 09:55:12 --> Total execution time: 0.0389
INFO - 2024-10-09 09:55:12 --> Config Class Initialized
INFO - 2024-10-09 09:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:55:12 --> Utf8 Class Initialized
INFO - 2024-10-09 09:55:12 --> URI Class Initialized
INFO - 2024-10-09 09:55:12 --> Router Class Initialized
INFO - 2024-10-09 09:55:12 --> Output Class Initialized
INFO - 2024-10-09 09:55:12 --> Security Class Initialized
DEBUG - 2024-10-09 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:55:12 --> Input Class Initialized
INFO - 2024-10-09 09:55:12 --> Language Class Initialized
INFO - 2024-10-09 09:55:12 --> Language Class Initialized
INFO - 2024-10-09 09:55:12 --> Config Class Initialized
INFO - 2024-10-09 09:55:12 --> Loader Class Initialized
INFO - 2024-10-09 09:55:12 --> Helper loaded: url_helper
INFO - 2024-10-09 09:55:12 --> Helper loaded: file_helper
INFO - 2024-10-09 09:55:12 --> Helper loaded: form_helper
INFO - 2024-10-09 09:55:12 --> Helper loaded: my_helper
INFO - 2024-10-09 09:55:12 --> Database Driver Class Initialized
INFO - 2024-10-09 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:55:12 --> Controller Class Initialized
DEBUG - 2024-10-09 09:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 09:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:55:12 --> Final output sent to browser
DEBUG - 2024-10-09 09:55:12 --> Total execution time: 0.0357
INFO - 2024-10-09 09:55:17 --> Config Class Initialized
INFO - 2024-10-09 09:55:17 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:55:17 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:55:17 --> Utf8 Class Initialized
INFO - 2024-10-09 09:55:17 --> URI Class Initialized
INFO - 2024-10-09 09:55:17 --> Router Class Initialized
INFO - 2024-10-09 09:55:17 --> Output Class Initialized
INFO - 2024-10-09 09:55:17 --> Security Class Initialized
DEBUG - 2024-10-09 09:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:55:17 --> Input Class Initialized
INFO - 2024-10-09 09:55:17 --> Language Class Initialized
INFO - 2024-10-09 09:55:17 --> Language Class Initialized
INFO - 2024-10-09 09:55:17 --> Config Class Initialized
INFO - 2024-10-09 09:55:17 --> Loader Class Initialized
INFO - 2024-10-09 09:55:17 --> Helper loaded: url_helper
INFO - 2024-10-09 09:55:17 --> Helper loaded: file_helper
INFO - 2024-10-09 09:55:17 --> Helper loaded: form_helper
INFO - 2024-10-09 09:55:17 --> Helper loaded: my_helper
INFO - 2024-10-09 09:55:17 --> Database Driver Class Initialized
INFO - 2024-10-09 09:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:55:17 --> Controller Class Initialized
DEBUG - 2024-10-09 09:55:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 09:55:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 09:55:17 --> Final output sent to browser
DEBUG - 2024-10-09 09:55:17 --> Total execution time: 0.0412
INFO - 2024-10-09 09:55:19 --> Config Class Initialized
INFO - 2024-10-09 09:55:19 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:55:19 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:55:19 --> Utf8 Class Initialized
INFO - 2024-10-09 09:55:19 --> URI Class Initialized
INFO - 2024-10-09 09:55:19 --> Router Class Initialized
INFO - 2024-10-09 09:55:19 --> Output Class Initialized
INFO - 2024-10-09 09:55:19 --> Security Class Initialized
DEBUG - 2024-10-09 09:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:55:19 --> Input Class Initialized
INFO - 2024-10-09 09:55:19 --> Language Class Initialized
INFO - 2024-10-09 09:55:19 --> Language Class Initialized
INFO - 2024-10-09 09:55:19 --> Config Class Initialized
INFO - 2024-10-09 09:55:19 --> Loader Class Initialized
INFO - 2024-10-09 09:55:19 --> Helper loaded: url_helper
INFO - 2024-10-09 09:55:19 --> Helper loaded: file_helper
INFO - 2024-10-09 09:55:19 --> Helper loaded: form_helper
INFO - 2024-10-09 09:55:19 --> Helper loaded: my_helper
INFO - 2024-10-09 09:55:19 --> Database Driver Class Initialized
INFO - 2024-10-09 09:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:55:19 --> Controller Class Initialized
DEBUG - 2024-10-09 09:55:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 09:55:22 --> Final output sent to browser
DEBUG - 2024-10-09 09:55:22 --> Total execution time: 2.9406
INFO - 2024-10-09 15:15:30 --> Config Class Initialized
INFO - 2024-10-09 15:15:30 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:15:30 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:15:30 --> Utf8 Class Initialized
INFO - 2024-10-09 15:15:30 --> URI Class Initialized
INFO - 2024-10-09 15:15:30 --> Router Class Initialized
INFO - 2024-10-09 15:15:30 --> Output Class Initialized
INFO - 2024-10-09 15:15:30 --> Security Class Initialized
DEBUG - 2024-10-09 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:15:30 --> Input Class Initialized
INFO - 2024-10-09 15:15:30 --> Language Class Initialized
INFO - 2024-10-09 15:15:30 --> Language Class Initialized
INFO - 2024-10-09 15:15:30 --> Config Class Initialized
INFO - 2024-10-09 15:15:30 --> Loader Class Initialized
INFO - 2024-10-09 15:15:30 --> Helper loaded: url_helper
INFO - 2024-10-09 15:15:30 --> Helper loaded: file_helper
INFO - 2024-10-09 15:15:30 --> Helper loaded: form_helper
INFO - 2024-10-09 15:15:30 --> Helper loaded: my_helper
INFO - 2024-10-09 15:15:30 --> Database Driver Class Initialized
INFO - 2024-10-09 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:15:30 --> Controller Class Initialized
INFO - 2024-10-09 15:15:30 --> Config Class Initialized
INFO - 2024-10-09 15:15:30 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:15:30 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:15:30 --> Utf8 Class Initialized
INFO - 2024-10-09 15:15:30 --> URI Class Initialized
INFO - 2024-10-09 15:15:30 --> Router Class Initialized
INFO - 2024-10-09 15:15:30 --> Output Class Initialized
INFO - 2024-10-09 15:15:30 --> Security Class Initialized
DEBUG - 2024-10-09 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:15:30 --> Input Class Initialized
INFO - 2024-10-09 15:15:30 --> Language Class Initialized
INFO - 2024-10-09 15:15:30 --> Language Class Initialized
INFO - 2024-10-09 15:15:30 --> Config Class Initialized
INFO - 2024-10-09 15:15:30 --> Loader Class Initialized
INFO - 2024-10-09 15:15:30 --> Helper loaded: url_helper
INFO - 2024-10-09 15:15:30 --> Helper loaded: file_helper
INFO - 2024-10-09 15:15:30 --> Helper loaded: form_helper
INFO - 2024-10-09 15:15:30 --> Helper loaded: my_helper
INFO - 2024-10-09 15:15:30 --> Database Driver Class Initialized
INFO - 2024-10-09 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:15:30 --> Controller Class Initialized
DEBUG - 2024-10-09 15:15:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 15:15:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:15:30 --> Final output sent to browser
DEBUG - 2024-10-09 15:15:30 --> Total execution time: 0.0340
INFO - 2024-10-09 15:15:53 --> Config Class Initialized
INFO - 2024-10-09 15:15:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:15:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:15:53 --> Utf8 Class Initialized
INFO - 2024-10-09 15:15:53 --> URI Class Initialized
INFO - 2024-10-09 15:15:53 --> Router Class Initialized
INFO - 2024-10-09 15:15:53 --> Output Class Initialized
INFO - 2024-10-09 15:15:53 --> Security Class Initialized
DEBUG - 2024-10-09 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:15:53 --> Input Class Initialized
INFO - 2024-10-09 15:15:53 --> Language Class Initialized
INFO - 2024-10-09 15:15:53 --> Language Class Initialized
INFO - 2024-10-09 15:15:53 --> Config Class Initialized
INFO - 2024-10-09 15:15:53 --> Loader Class Initialized
INFO - 2024-10-09 15:15:53 --> Helper loaded: url_helper
INFO - 2024-10-09 15:15:53 --> Helper loaded: file_helper
INFO - 2024-10-09 15:15:53 --> Helper loaded: form_helper
INFO - 2024-10-09 15:15:53 --> Helper loaded: my_helper
INFO - 2024-10-09 15:15:53 --> Database Driver Class Initialized
INFO - 2024-10-09 15:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:15:53 --> Controller Class Initialized
INFO - 2024-10-09 15:15:53 --> Helper loaded: cookie_helper
INFO - 2024-10-09 15:15:53 --> Final output sent to browser
DEBUG - 2024-10-09 15:15:53 --> Total execution time: 0.0512
INFO - 2024-10-09 15:15:53 --> Config Class Initialized
INFO - 2024-10-09 15:15:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:15:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:15:53 --> Utf8 Class Initialized
INFO - 2024-10-09 15:15:53 --> URI Class Initialized
INFO - 2024-10-09 15:15:53 --> Router Class Initialized
INFO - 2024-10-09 15:15:53 --> Output Class Initialized
INFO - 2024-10-09 15:15:53 --> Security Class Initialized
DEBUG - 2024-10-09 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:15:53 --> Input Class Initialized
INFO - 2024-10-09 15:15:53 --> Language Class Initialized
INFO - 2024-10-09 15:15:53 --> Language Class Initialized
INFO - 2024-10-09 15:15:53 --> Config Class Initialized
INFO - 2024-10-09 15:15:53 --> Loader Class Initialized
INFO - 2024-10-09 15:15:53 --> Helper loaded: url_helper
INFO - 2024-10-09 15:15:53 --> Helper loaded: file_helper
INFO - 2024-10-09 15:15:53 --> Helper loaded: form_helper
INFO - 2024-10-09 15:15:53 --> Helper loaded: my_helper
INFO - 2024-10-09 15:15:53 --> Database Driver Class Initialized
INFO - 2024-10-09 15:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:15:53 --> Controller Class Initialized
DEBUG - 2024-10-09 15:15:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:15:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:15:53 --> Final output sent to browser
DEBUG - 2024-10-09 15:15:53 --> Total execution time: 0.0475
INFO - 2024-10-09 15:16:00 --> Config Class Initialized
INFO - 2024-10-09 15:16:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:16:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:16:00 --> Utf8 Class Initialized
INFO - 2024-10-09 15:16:00 --> URI Class Initialized
INFO - 2024-10-09 15:16:00 --> Router Class Initialized
INFO - 2024-10-09 15:16:00 --> Output Class Initialized
INFO - 2024-10-09 15:16:00 --> Security Class Initialized
DEBUG - 2024-10-09 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:16:00 --> Input Class Initialized
INFO - 2024-10-09 15:16:00 --> Language Class Initialized
INFO - 2024-10-09 15:16:00 --> Language Class Initialized
INFO - 2024-10-09 15:16:00 --> Config Class Initialized
INFO - 2024-10-09 15:16:00 --> Loader Class Initialized
INFO - 2024-10-09 15:16:00 --> Helper loaded: url_helper
INFO - 2024-10-09 15:16:00 --> Helper loaded: file_helper
INFO - 2024-10-09 15:16:00 --> Helper loaded: form_helper
INFO - 2024-10-09 15:16:00 --> Helper loaded: my_helper
INFO - 2024-10-09 15:16:00 --> Database Driver Class Initialized
INFO - 2024-10-09 15:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:16:00 --> Controller Class Initialized
DEBUG - 2024-10-09 15:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 15:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:16:00 --> Final output sent to browser
DEBUG - 2024-10-09 15:16:00 --> Total execution time: 0.0417
INFO - 2024-10-09 15:16:03 --> Config Class Initialized
INFO - 2024-10-09 15:16:03 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:16:03 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:16:03 --> Utf8 Class Initialized
INFO - 2024-10-09 15:16:03 --> URI Class Initialized
INFO - 2024-10-09 15:16:03 --> Router Class Initialized
INFO - 2024-10-09 15:16:03 --> Output Class Initialized
INFO - 2024-10-09 15:16:03 --> Security Class Initialized
DEBUG - 2024-10-09 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:16:03 --> Input Class Initialized
INFO - 2024-10-09 15:16:03 --> Language Class Initialized
INFO - 2024-10-09 15:16:03 --> Language Class Initialized
INFO - 2024-10-09 15:16:03 --> Config Class Initialized
INFO - 2024-10-09 15:16:03 --> Loader Class Initialized
INFO - 2024-10-09 15:16:03 --> Helper loaded: url_helper
INFO - 2024-10-09 15:16:03 --> Helper loaded: file_helper
INFO - 2024-10-09 15:16:03 --> Helper loaded: form_helper
INFO - 2024-10-09 15:16:03 --> Helper loaded: my_helper
INFO - 2024-10-09 15:16:03 --> Database Driver Class Initialized
INFO - 2024-10-09 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:16:03 --> Controller Class Initialized
DEBUG - 2024-10-09 15:16:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 15:16:06 --> Final output sent to browser
DEBUG - 2024-10-09 15:16:06 --> Total execution time: 3.5060
INFO - 2024-10-09 15:17:01 --> Config Class Initialized
INFO - 2024-10-09 15:17:01 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:17:01 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:17:01 --> Utf8 Class Initialized
INFO - 2024-10-09 15:17:01 --> URI Class Initialized
INFO - 2024-10-09 15:17:01 --> Router Class Initialized
INFO - 2024-10-09 15:17:01 --> Output Class Initialized
INFO - 2024-10-09 15:17:01 --> Security Class Initialized
DEBUG - 2024-10-09 15:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:17:01 --> Input Class Initialized
INFO - 2024-10-09 15:17:01 --> Language Class Initialized
INFO - 2024-10-09 15:17:01 --> Language Class Initialized
INFO - 2024-10-09 15:17:01 --> Config Class Initialized
INFO - 2024-10-09 15:17:01 --> Loader Class Initialized
INFO - 2024-10-09 15:17:01 --> Helper loaded: url_helper
INFO - 2024-10-09 15:17:01 --> Helper loaded: file_helper
INFO - 2024-10-09 15:17:01 --> Helper loaded: form_helper
INFO - 2024-10-09 15:17:01 --> Helper loaded: my_helper
INFO - 2024-10-09 15:17:01 --> Database Driver Class Initialized
INFO - 2024-10-09 15:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:17:01 --> Controller Class Initialized
DEBUG - 2024-10-09 15:17:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 15:17:05 --> Final output sent to browser
DEBUG - 2024-10-09 15:17:05 --> Total execution time: 4.3809
INFO - 2024-10-09 15:18:03 --> Config Class Initialized
INFO - 2024-10-09 15:18:03 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:18:03 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:18:03 --> Utf8 Class Initialized
INFO - 2024-10-09 15:18:03 --> URI Class Initialized
INFO - 2024-10-09 15:18:03 --> Router Class Initialized
INFO - 2024-10-09 15:18:03 --> Output Class Initialized
INFO - 2024-10-09 15:18:03 --> Security Class Initialized
DEBUG - 2024-10-09 15:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:18:03 --> Input Class Initialized
INFO - 2024-10-09 15:18:03 --> Language Class Initialized
INFO - 2024-10-09 15:18:03 --> Language Class Initialized
INFO - 2024-10-09 15:18:03 --> Config Class Initialized
INFO - 2024-10-09 15:18:03 --> Loader Class Initialized
INFO - 2024-10-09 15:18:03 --> Helper loaded: url_helper
INFO - 2024-10-09 15:18:03 --> Helper loaded: file_helper
INFO - 2024-10-09 15:18:03 --> Helper loaded: form_helper
INFO - 2024-10-09 15:18:03 --> Helper loaded: my_helper
INFO - 2024-10-09 15:18:03 --> Database Driver Class Initialized
INFO - 2024-10-09 15:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:18:03 --> Controller Class Initialized
DEBUG - 2024-10-09 15:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 15:18:09 --> Final output sent to browser
DEBUG - 2024-10-09 15:18:09 --> Total execution time: 5.8307
INFO - 2024-10-09 15:18:53 --> Config Class Initialized
INFO - 2024-10-09 15:18:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:18:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:18:53 --> Utf8 Class Initialized
INFO - 2024-10-09 15:18:53 --> URI Class Initialized
INFO - 2024-10-09 15:18:53 --> Router Class Initialized
INFO - 2024-10-09 15:18:53 --> Output Class Initialized
INFO - 2024-10-09 15:18:53 --> Security Class Initialized
DEBUG - 2024-10-09 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:18:53 --> Input Class Initialized
INFO - 2024-10-09 15:18:53 --> Language Class Initialized
INFO - 2024-10-09 15:18:54 --> Language Class Initialized
INFO - 2024-10-09 15:18:54 --> Config Class Initialized
INFO - 2024-10-09 15:18:54 --> Loader Class Initialized
INFO - 2024-10-09 15:18:54 --> Helper loaded: url_helper
INFO - 2024-10-09 15:18:54 --> Helper loaded: file_helper
INFO - 2024-10-09 15:18:54 --> Helper loaded: form_helper
INFO - 2024-10-09 15:18:54 --> Helper loaded: my_helper
INFO - 2024-10-09 15:18:54 --> Database Driver Class Initialized
INFO - 2024-10-09 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:18:54 --> Controller Class Initialized
DEBUG - 2024-10-09 15:18:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 15:18:58 --> Final output sent to browser
DEBUG - 2024-10-09 15:18:58 --> Total execution time: 5.0540
INFO - 2024-10-09 15:19:56 --> Config Class Initialized
INFO - 2024-10-09 15:19:56 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:19:56 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:19:56 --> Utf8 Class Initialized
INFO - 2024-10-09 15:19:56 --> URI Class Initialized
INFO - 2024-10-09 15:19:56 --> Router Class Initialized
INFO - 2024-10-09 15:19:56 --> Output Class Initialized
INFO - 2024-10-09 15:19:56 --> Security Class Initialized
DEBUG - 2024-10-09 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:19:56 --> Input Class Initialized
INFO - 2024-10-09 15:19:56 --> Language Class Initialized
INFO - 2024-10-09 15:19:56 --> Language Class Initialized
INFO - 2024-10-09 15:19:56 --> Config Class Initialized
INFO - 2024-10-09 15:19:56 --> Loader Class Initialized
INFO - 2024-10-09 15:19:56 --> Helper loaded: url_helper
INFO - 2024-10-09 15:19:56 --> Helper loaded: file_helper
INFO - 2024-10-09 15:19:56 --> Helper loaded: form_helper
INFO - 2024-10-09 15:19:56 --> Helper loaded: my_helper
INFO - 2024-10-09 15:19:56 --> Database Driver Class Initialized
INFO - 2024-10-09 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:19:56 --> Controller Class Initialized
DEBUG - 2024-10-09 15:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 15:19:59 --> Final output sent to browser
DEBUG - 2024-10-09 15:19:59 --> Total execution time: 3.1809
INFO - 2024-10-09 15:41:58 --> Config Class Initialized
INFO - 2024-10-09 15:41:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:41:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:41:58 --> Utf8 Class Initialized
INFO - 2024-10-09 15:41:58 --> URI Class Initialized
INFO - 2024-10-09 15:41:58 --> Router Class Initialized
INFO - 2024-10-09 15:41:58 --> Output Class Initialized
INFO - 2024-10-09 15:41:58 --> Security Class Initialized
DEBUG - 2024-10-09 15:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:41:58 --> Input Class Initialized
INFO - 2024-10-09 15:41:58 --> Language Class Initialized
INFO - 2024-10-09 15:41:58 --> Language Class Initialized
INFO - 2024-10-09 15:41:58 --> Config Class Initialized
INFO - 2024-10-09 15:41:58 --> Loader Class Initialized
INFO - 2024-10-09 15:41:58 --> Helper loaded: url_helper
INFO - 2024-10-09 15:41:58 --> Helper loaded: file_helper
INFO - 2024-10-09 15:41:58 --> Helper loaded: form_helper
INFO - 2024-10-09 15:41:58 --> Helper loaded: my_helper
INFO - 2024-10-09 15:41:58 --> Database Driver Class Initialized
INFO - 2024-10-09 15:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:41:58 --> Controller Class Initialized
DEBUG - 2024-10-09 15:41:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 15:41:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:41:58 --> Final output sent to browser
DEBUG - 2024-10-09 15:41:58 --> Total execution time: 0.0453
INFO - 2024-10-09 15:52:08 --> Config Class Initialized
INFO - 2024-10-09 15:52:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:08 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:08 --> URI Class Initialized
INFO - 2024-10-09 15:52:08 --> Router Class Initialized
INFO - 2024-10-09 15:52:08 --> Output Class Initialized
INFO - 2024-10-09 15:52:08 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:08 --> Input Class Initialized
INFO - 2024-10-09 15:52:08 --> Language Class Initialized
INFO - 2024-10-09 15:52:08 --> Language Class Initialized
INFO - 2024-10-09 15:52:08 --> Config Class Initialized
INFO - 2024-10-09 15:52:08 --> Loader Class Initialized
INFO - 2024-10-09 15:52:08 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:08 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:08 --> Controller Class Initialized
INFO - 2024-10-09 15:52:08 --> Config Class Initialized
INFO - 2024-10-09 15:52:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:08 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:08 --> URI Class Initialized
INFO - 2024-10-09 15:52:08 --> Router Class Initialized
INFO - 2024-10-09 15:52:08 --> Output Class Initialized
INFO - 2024-10-09 15:52:08 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:08 --> Input Class Initialized
INFO - 2024-10-09 15:52:08 --> Language Class Initialized
INFO - 2024-10-09 15:52:08 --> Language Class Initialized
INFO - 2024-10-09 15:52:08 --> Config Class Initialized
INFO - 2024-10-09 15:52:08 --> Loader Class Initialized
INFO - 2024-10-09 15:52:08 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:08 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:08 --> Controller Class Initialized
INFO - 2024-10-09 15:52:08 --> Config Class Initialized
INFO - 2024-10-09 15:52:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:08 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:08 --> URI Class Initialized
INFO - 2024-10-09 15:52:08 --> Router Class Initialized
INFO - 2024-10-09 15:52:08 --> Output Class Initialized
INFO - 2024-10-09 15:52:08 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:08 --> Input Class Initialized
INFO - 2024-10-09 15:52:08 --> Language Class Initialized
INFO - 2024-10-09 15:52:08 --> Language Class Initialized
INFO - 2024-10-09 15:52:08 --> Config Class Initialized
INFO - 2024-10-09 15:52:08 --> Loader Class Initialized
INFO - 2024-10-09 15:52:08 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:08 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:08 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:08 --> Controller Class Initialized
DEBUG - 2024-10-09 15:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 15:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:52:08 --> Final output sent to browser
DEBUG - 2024-10-09 15:52:08 --> Total execution time: 0.0421
INFO - 2024-10-09 15:52:09 --> Config Class Initialized
INFO - 2024-10-09 15:52:09 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:09 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:09 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:09 --> URI Class Initialized
INFO - 2024-10-09 15:52:09 --> Router Class Initialized
INFO - 2024-10-09 15:52:09 --> Output Class Initialized
INFO - 2024-10-09 15:52:09 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:09 --> Input Class Initialized
INFO - 2024-10-09 15:52:09 --> Language Class Initialized
INFO - 2024-10-09 15:52:09 --> Language Class Initialized
INFO - 2024-10-09 15:52:09 --> Config Class Initialized
INFO - 2024-10-09 15:52:09 --> Loader Class Initialized
INFO - 2024-10-09 15:52:09 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:09 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:09 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:09 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:09 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:09 --> Controller Class Initialized
INFO - 2024-10-09 15:52:09 --> Helper loaded: cookie_helper
INFO - 2024-10-09 15:52:09 --> Final output sent to browser
DEBUG - 2024-10-09 15:52:09 --> Total execution time: 0.0754
INFO - 2024-10-09 15:52:09 --> Config Class Initialized
INFO - 2024-10-09 15:52:09 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:09 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:09 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:09 --> URI Class Initialized
INFO - 2024-10-09 15:52:09 --> Router Class Initialized
INFO - 2024-10-09 15:52:09 --> Output Class Initialized
INFO - 2024-10-09 15:52:09 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:09 --> Input Class Initialized
INFO - 2024-10-09 15:52:09 --> Language Class Initialized
INFO - 2024-10-09 15:52:09 --> Language Class Initialized
INFO - 2024-10-09 15:52:09 --> Config Class Initialized
INFO - 2024-10-09 15:52:09 --> Loader Class Initialized
INFO - 2024-10-09 15:52:09 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:09 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:09 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:09 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:09 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:09 --> Controller Class Initialized
DEBUG - 2024-10-09 15:52:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:52:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:52:09 --> Final output sent to browser
DEBUG - 2024-10-09 15:52:09 --> Total execution time: 0.0587
INFO - 2024-10-09 15:52:11 --> Config Class Initialized
INFO - 2024-10-09 15:52:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:11 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:11 --> URI Class Initialized
INFO - 2024-10-09 15:52:11 --> Router Class Initialized
INFO - 2024-10-09 15:52:11 --> Output Class Initialized
INFO - 2024-10-09 15:52:11 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:11 --> Input Class Initialized
INFO - 2024-10-09 15:52:11 --> Language Class Initialized
INFO - 2024-10-09 15:52:11 --> Language Class Initialized
INFO - 2024-10-09 15:52:11 --> Config Class Initialized
INFO - 2024-10-09 15:52:11 --> Loader Class Initialized
INFO - 2024-10-09 15:52:11 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:11 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:11 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:11 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:11 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:11 --> Controller Class Initialized
DEBUG - 2024-10-09 15:52:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:52:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:52:11 --> Final output sent to browser
DEBUG - 2024-10-09 15:52:11 --> Total execution time: 0.0466
INFO - 2024-10-09 15:52:16 --> Config Class Initialized
INFO - 2024-10-09 15:52:16 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:16 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:16 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:16 --> URI Class Initialized
INFO - 2024-10-09 15:52:16 --> Router Class Initialized
INFO - 2024-10-09 15:52:16 --> Output Class Initialized
INFO - 2024-10-09 15:52:16 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:16 --> Input Class Initialized
INFO - 2024-10-09 15:52:16 --> Language Class Initialized
INFO - 2024-10-09 15:52:16 --> Language Class Initialized
INFO - 2024-10-09 15:52:16 --> Config Class Initialized
INFO - 2024-10-09 15:52:16 --> Loader Class Initialized
INFO - 2024-10-09 15:52:16 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:16 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:16 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:16 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:16 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:16 --> Controller Class Initialized
DEBUG - 2024-10-09 15:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 15:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:52:16 --> Final output sent to browser
DEBUG - 2024-10-09 15:52:16 --> Total execution time: 0.0363
INFO - 2024-10-09 15:52:20 --> Config Class Initialized
INFO - 2024-10-09 15:52:20 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:52:20 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:52:20 --> Utf8 Class Initialized
INFO - 2024-10-09 15:52:20 --> URI Class Initialized
INFO - 2024-10-09 15:52:20 --> Router Class Initialized
INFO - 2024-10-09 15:52:20 --> Output Class Initialized
INFO - 2024-10-09 15:52:20 --> Security Class Initialized
DEBUG - 2024-10-09 15:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:52:20 --> Input Class Initialized
INFO - 2024-10-09 15:52:20 --> Language Class Initialized
INFO - 2024-10-09 15:52:20 --> Language Class Initialized
INFO - 2024-10-09 15:52:20 --> Config Class Initialized
INFO - 2024-10-09 15:52:20 --> Loader Class Initialized
INFO - 2024-10-09 15:52:20 --> Helper loaded: url_helper
INFO - 2024-10-09 15:52:20 --> Helper loaded: file_helper
INFO - 2024-10-09 15:52:20 --> Helper loaded: form_helper
INFO - 2024-10-09 15:52:20 --> Helper loaded: my_helper
INFO - 2024-10-09 15:52:20 --> Database Driver Class Initialized
INFO - 2024-10-09 15:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:52:20 --> Controller Class Initialized
DEBUG - 2024-10-09 15:52:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 15:52:24 --> Final output sent to browser
DEBUG - 2024-10-09 15:52:24 --> Total execution time: 3.1198
INFO - 2024-10-09 15:55:11 --> Config Class Initialized
INFO - 2024-10-09 15:55:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:55:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:55:11 --> Utf8 Class Initialized
INFO - 2024-10-09 15:55:11 --> URI Class Initialized
INFO - 2024-10-09 15:55:11 --> Router Class Initialized
INFO - 2024-10-09 15:55:11 --> Output Class Initialized
INFO - 2024-10-09 15:55:11 --> Security Class Initialized
DEBUG - 2024-10-09 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:55:11 --> Input Class Initialized
INFO - 2024-10-09 15:55:11 --> Language Class Initialized
INFO - 2024-10-09 15:55:11 --> Language Class Initialized
INFO - 2024-10-09 15:55:11 --> Config Class Initialized
INFO - 2024-10-09 15:55:11 --> Loader Class Initialized
INFO - 2024-10-09 15:55:11 --> Helper loaded: url_helper
INFO - 2024-10-09 15:55:11 --> Helper loaded: file_helper
INFO - 2024-10-09 15:55:11 --> Helper loaded: form_helper
INFO - 2024-10-09 15:55:11 --> Helper loaded: my_helper
INFO - 2024-10-09 15:55:11 --> Database Driver Class Initialized
INFO - 2024-10-09 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:55:11 --> Controller Class Initialized
DEBUG - 2024-10-09 15:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-10-09 15:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:55:11 --> Final output sent to browser
DEBUG - 2024-10-09 15:55:11 --> Total execution time: 0.0479
INFO - 2024-10-09 15:55:11 --> Config Class Initialized
INFO - 2024-10-09 15:55:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:55:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:55:11 --> Utf8 Class Initialized
INFO - 2024-10-09 15:55:11 --> URI Class Initialized
INFO - 2024-10-09 15:55:11 --> Router Class Initialized
INFO - 2024-10-09 15:55:11 --> Output Class Initialized
INFO - 2024-10-09 15:55:11 --> Security Class Initialized
DEBUG - 2024-10-09 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:55:11 --> Input Class Initialized
INFO - 2024-10-09 15:55:11 --> Language Class Initialized
ERROR - 2024-10-09 15:55:11 --> 404 Page Not Found: /index
INFO - 2024-10-09 15:55:11 --> Config Class Initialized
INFO - 2024-10-09 15:55:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:55:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:55:11 --> Utf8 Class Initialized
INFO - 2024-10-09 15:55:11 --> URI Class Initialized
INFO - 2024-10-09 15:55:11 --> Router Class Initialized
INFO - 2024-10-09 15:55:11 --> Output Class Initialized
INFO - 2024-10-09 15:55:11 --> Security Class Initialized
DEBUG - 2024-10-09 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:55:11 --> Input Class Initialized
INFO - 2024-10-09 15:55:11 --> Language Class Initialized
INFO - 2024-10-09 15:55:11 --> Language Class Initialized
INFO - 2024-10-09 15:55:11 --> Config Class Initialized
INFO - 2024-10-09 15:55:11 --> Loader Class Initialized
INFO - 2024-10-09 15:55:11 --> Helper loaded: url_helper
INFO - 2024-10-09 15:55:11 --> Helper loaded: file_helper
INFO - 2024-10-09 15:55:11 --> Helper loaded: form_helper
INFO - 2024-10-09 15:55:11 --> Helper loaded: my_helper
INFO - 2024-10-09 15:55:11 --> Database Driver Class Initialized
INFO - 2024-10-09 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:55:11 --> Controller Class Initialized
INFO - 2024-10-09 15:56:38 --> Config Class Initialized
INFO - 2024-10-09 15:56:38 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:38 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:38 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:38 --> URI Class Initialized
INFO - 2024-10-09 15:56:38 --> Router Class Initialized
INFO - 2024-10-09 15:56:38 --> Output Class Initialized
INFO - 2024-10-09 15:56:38 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:38 --> Input Class Initialized
INFO - 2024-10-09 15:56:38 --> Language Class Initialized
INFO - 2024-10-09 15:56:38 --> Language Class Initialized
INFO - 2024-10-09 15:56:38 --> Config Class Initialized
INFO - 2024-10-09 15:56:38 --> Loader Class Initialized
INFO - 2024-10-09 15:56:38 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:38 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:38 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:38 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:39 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:39 --> Controller Class Initialized
INFO - 2024-10-09 15:56:39 --> Config Class Initialized
INFO - 2024-10-09 15:56:39 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:39 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:39 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:39 --> URI Class Initialized
INFO - 2024-10-09 15:56:39 --> Router Class Initialized
INFO - 2024-10-09 15:56:39 --> Output Class Initialized
INFO - 2024-10-09 15:56:39 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:39 --> Input Class Initialized
INFO - 2024-10-09 15:56:39 --> Language Class Initialized
INFO - 2024-10-09 15:56:39 --> Language Class Initialized
INFO - 2024-10-09 15:56:39 --> Config Class Initialized
INFO - 2024-10-09 15:56:39 --> Loader Class Initialized
INFO - 2024-10-09 15:56:39 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:39 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:39 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:39 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:39 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:39 --> Controller Class Initialized
DEBUG - 2024-10-09 15:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 15:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:56:39 --> Final output sent to browser
DEBUG - 2024-10-09 15:56:39 --> Total execution time: 0.0475
INFO - 2024-10-09 15:56:42 --> Config Class Initialized
INFO - 2024-10-09 15:56:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:42 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:42 --> URI Class Initialized
INFO - 2024-10-09 15:56:42 --> Router Class Initialized
INFO - 2024-10-09 15:56:42 --> Output Class Initialized
INFO - 2024-10-09 15:56:42 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:42 --> Input Class Initialized
INFO - 2024-10-09 15:56:42 --> Language Class Initialized
INFO - 2024-10-09 15:56:42 --> Language Class Initialized
INFO - 2024-10-09 15:56:42 --> Config Class Initialized
INFO - 2024-10-09 15:56:42 --> Loader Class Initialized
INFO - 2024-10-09 15:56:42 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:42 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:42 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:42 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:42 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:42 --> Controller Class Initialized
INFO - 2024-10-09 15:56:42 --> Helper loaded: cookie_helper
INFO - 2024-10-09 15:56:42 --> Final output sent to browser
DEBUG - 2024-10-09 15:56:42 --> Total execution time: 0.0306
INFO - 2024-10-09 15:56:42 --> Config Class Initialized
INFO - 2024-10-09 15:56:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:42 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:42 --> URI Class Initialized
INFO - 2024-10-09 15:56:42 --> Router Class Initialized
INFO - 2024-10-09 15:56:42 --> Output Class Initialized
INFO - 2024-10-09 15:56:42 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:42 --> Input Class Initialized
INFO - 2024-10-09 15:56:42 --> Language Class Initialized
INFO - 2024-10-09 15:56:42 --> Language Class Initialized
INFO - 2024-10-09 15:56:42 --> Config Class Initialized
INFO - 2024-10-09 15:56:42 --> Loader Class Initialized
INFO - 2024-10-09 15:56:42 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:42 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:42 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:42 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:42 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:42 --> Controller Class Initialized
DEBUG - 2024-10-09 15:56:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:56:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:56:42 --> Final output sent to browser
DEBUG - 2024-10-09 15:56:42 --> Total execution time: 0.0293
INFO - 2024-10-09 15:56:46 --> Config Class Initialized
INFO - 2024-10-09 15:56:46 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:46 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:46 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:46 --> URI Class Initialized
INFO - 2024-10-09 15:56:46 --> Router Class Initialized
INFO - 2024-10-09 15:56:46 --> Output Class Initialized
INFO - 2024-10-09 15:56:46 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:46 --> Input Class Initialized
INFO - 2024-10-09 15:56:46 --> Language Class Initialized
INFO - 2024-10-09 15:56:46 --> Language Class Initialized
INFO - 2024-10-09 15:56:46 --> Config Class Initialized
INFO - 2024-10-09 15:56:46 --> Loader Class Initialized
INFO - 2024-10-09 15:56:46 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:46 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:46 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:46 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:46 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:46 --> Controller Class Initialized
DEBUG - 2024-10-09 15:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:56:46 --> Final output sent to browser
DEBUG - 2024-10-09 15:56:46 --> Total execution time: 0.0314
INFO - 2024-10-09 15:56:50 --> Config Class Initialized
INFO - 2024-10-09 15:56:50 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:50 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:50 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:50 --> URI Class Initialized
INFO - 2024-10-09 15:56:50 --> Router Class Initialized
INFO - 2024-10-09 15:56:50 --> Output Class Initialized
INFO - 2024-10-09 15:56:50 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:50 --> Input Class Initialized
INFO - 2024-10-09 15:56:50 --> Language Class Initialized
INFO - 2024-10-09 15:56:50 --> Language Class Initialized
INFO - 2024-10-09 15:56:50 --> Config Class Initialized
INFO - 2024-10-09 15:56:50 --> Loader Class Initialized
INFO - 2024-10-09 15:56:50 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:50 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:50 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:50 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:50 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:50 --> Controller Class Initialized
DEBUG - 2024-10-09 15:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 15:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:56:50 --> Final output sent to browser
DEBUG - 2024-10-09 15:56:50 --> Total execution time: 0.0378
INFO - 2024-10-09 15:56:50 --> Config Class Initialized
INFO - 2024-10-09 15:56:50 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:50 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:50 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:50 --> URI Class Initialized
INFO - 2024-10-09 15:56:50 --> Router Class Initialized
INFO - 2024-10-09 15:56:50 --> Output Class Initialized
INFO - 2024-10-09 15:56:50 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:50 --> Input Class Initialized
INFO - 2024-10-09 15:56:50 --> Language Class Initialized
INFO - 2024-10-09 15:56:50 --> Language Class Initialized
INFO - 2024-10-09 15:56:50 --> Config Class Initialized
INFO - 2024-10-09 15:56:50 --> Loader Class Initialized
INFO - 2024-10-09 15:56:50 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:50 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:50 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:50 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:50 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:50 --> Controller Class Initialized
INFO - 2024-10-09 15:56:59 --> Config Class Initialized
INFO - 2024-10-09 15:56:59 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:56:59 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:56:59 --> Utf8 Class Initialized
INFO - 2024-10-09 15:56:59 --> URI Class Initialized
INFO - 2024-10-09 15:56:59 --> Router Class Initialized
INFO - 2024-10-09 15:56:59 --> Output Class Initialized
INFO - 2024-10-09 15:56:59 --> Security Class Initialized
DEBUG - 2024-10-09 15:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:56:59 --> Input Class Initialized
INFO - 2024-10-09 15:56:59 --> Language Class Initialized
INFO - 2024-10-09 15:56:59 --> Language Class Initialized
INFO - 2024-10-09 15:56:59 --> Config Class Initialized
INFO - 2024-10-09 15:56:59 --> Loader Class Initialized
INFO - 2024-10-09 15:56:59 --> Helper loaded: url_helper
INFO - 2024-10-09 15:56:59 --> Helper loaded: file_helper
INFO - 2024-10-09 15:56:59 --> Helper loaded: form_helper
INFO - 2024-10-09 15:56:59 --> Helper loaded: my_helper
INFO - 2024-10-09 15:56:59 --> Database Driver Class Initialized
INFO - 2024-10-09 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:56:59 --> Controller Class Initialized
INFO - 2024-10-09 15:56:59 --> Final output sent to browser
DEBUG - 2024-10-09 15:56:59 --> Total execution time: 0.0284
INFO - 2024-10-09 15:57:03 --> Config Class Initialized
INFO - 2024-10-09 15:57:03 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:03 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:03 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:03 --> URI Class Initialized
INFO - 2024-10-09 15:57:03 --> Router Class Initialized
INFO - 2024-10-09 15:57:03 --> Output Class Initialized
INFO - 2024-10-09 15:57:03 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:03 --> Input Class Initialized
INFO - 2024-10-09 15:57:03 --> Language Class Initialized
INFO - 2024-10-09 15:57:03 --> Language Class Initialized
INFO - 2024-10-09 15:57:03 --> Config Class Initialized
INFO - 2024-10-09 15:57:03 --> Loader Class Initialized
INFO - 2024-10-09 15:57:03 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:03 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:03 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:03 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:03 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:03 --> Controller Class Initialized
INFO - 2024-10-09 15:57:03 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:03 --> Total execution time: 0.0875
INFO - 2024-10-09 15:57:03 --> Config Class Initialized
INFO - 2024-10-09 15:57:03 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:03 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:03 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:03 --> URI Class Initialized
INFO - 2024-10-09 15:57:03 --> Router Class Initialized
INFO - 2024-10-09 15:57:03 --> Output Class Initialized
INFO - 2024-10-09 15:57:03 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:03 --> Input Class Initialized
INFO - 2024-10-09 15:57:03 --> Language Class Initialized
INFO - 2024-10-09 15:57:03 --> Language Class Initialized
INFO - 2024-10-09 15:57:03 --> Config Class Initialized
INFO - 2024-10-09 15:57:03 --> Loader Class Initialized
INFO - 2024-10-09 15:57:03 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:03 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:03 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:03 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:03 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:03 --> Controller Class Initialized
INFO - 2024-10-09 15:57:14 --> Config Class Initialized
INFO - 2024-10-09 15:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:14 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:14 --> URI Class Initialized
INFO - 2024-10-09 15:57:14 --> Router Class Initialized
INFO - 2024-10-09 15:57:14 --> Output Class Initialized
INFO - 2024-10-09 15:57:14 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:14 --> Input Class Initialized
INFO - 2024-10-09 15:57:14 --> Language Class Initialized
INFO - 2024-10-09 15:57:14 --> Language Class Initialized
INFO - 2024-10-09 15:57:14 --> Config Class Initialized
INFO - 2024-10-09 15:57:14 --> Loader Class Initialized
INFO - 2024-10-09 15:57:14 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:14 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:14 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:14 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:14 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:14 --> Controller Class Initialized
INFO - 2024-10-09 15:57:14 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:14 --> Total execution time: 0.0282
INFO - 2024-10-09 15:57:16 --> Config Class Initialized
INFO - 2024-10-09 15:57:16 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:16 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:16 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:16 --> URI Class Initialized
INFO - 2024-10-09 15:57:16 --> Router Class Initialized
INFO - 2024-10-09 15:57:16 --> Output Class Initialized
INFO - 2024-10-09 15:57:16 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:16 --> Input Class Initialized
INFO - 2024-10-09 15:57:16 --> Language Class Initialized
INFO - 2024-10-09 15:57:16 --> Language Class Initialized
INFO - 2024-10-09 15:57:16 --> Config Class Initialized
INFO - 2024-10-09 15:57:16 --> Loader Class Initialized
INFO - 2024-10-09 15:57:16 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:16 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:16 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:16 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:16 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:16 --> Controller Class Initialized
INFO - 2024-10-09 15:57:16 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:16 --> Total execution time: 0.0789
INFO - 2024-10-09 15:57:16 --> Config Class Initialized
INFO - 2024-10-09 15:57:16 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:16 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:16 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:16 --> URI Class Initialized
INFO - 2024-10-09 15:57:16 --> Router Class Initialized
INFO - 2024-10-09 15:57:16 --> Output Class Initialized
INFO - 2024-10-09 15:57:16 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:16 --> Input Class Initialized
INFO - 2024-10-09 15:57:16 --> Language Class Initialized
INFO - 2024-10-09 15:57:16 --> Language Class Initialized
INFO - 2024-10-09 15:57:16 --> Config Class Initialized
INFO - 2024-10-09 15:57:16 --> Loader Class Initialized
INFO - 2024-10-09 15:57:16 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:16 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:16 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:16 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:16 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:16 --> Controller Class Initialized
INFO - 2024-10-09 15:57:19 --> Config Class Initialized
INFO - 2024-10-09 15:57:19 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:19 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:19 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:19 --> URI Class Initialized
INFO - 2024-10-09 15:57:19 --> Router Class Initialized
INFO - 2024-10-09 15:57:19 --> Output Class Initialized
INFO - 2024-10-09 15:57:19 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:19 --> Input Class Initialized
INFO - 2024-10-09 15:57:19 --> Language Class Initialized
INFO - 2024-10-09 15:57:19 --> Language Class Initialized
INFO - 2024-10-09 15:57:19 --> Config Class Initialized
INFO - 2024-10-09 15:57:19 --> Loader Class Initialized
INFO - 2024-10-09 15:57:19 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:19 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:19 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:19 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:19 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:19 --> Controller Class Initialized
INFO - 2024-10-09 15:57:19 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:19 --> Total execution time: 0.0694
INFO - 2024-10-09 15:57:22 --> Config Class Initialized
INFO - 2024-10-09 15:57:22 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:22 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:22 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:22 --> URI Class Initialized
INFO - 2024-10-09 15:57:22 --> Router Class Initialized
INFO - 2024-10-09 15:57:22 --> Output Class Initialized
INFO - 2024-10-09 15:57:22 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:22 --> Input Class Initialized
INFO - 2024-10-09 15:57:22 --> Language Class Initialized
INFO - 2024-10-09 15:57:22 --> Language Class Initialized
INFO - 2024-10-09 15:57:22 --> Config Class Initialized
INFO - 2024-10-09 15:57:22 --> Loader Class Initialized
INFO - 2024-10-09 15:57:22 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:22 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:22 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:22 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:22 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:22 --> Controller Class Initialized
INFO - 2024-10-09 15:57:22 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:22 --> Total execution time: 0.0410
INFO - 2024-10-09 15:57:39 --> Config Class Initialized
INFO - 2024-10-09 15:57:39 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:39 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:39 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:39 --> URI Class Initialized
DEBUG - 2024-10-09 15:57:39 --> No URI present. Default controller set.
INFO - 2024-10-09 15:57:39 --> Router Class Initialized
INFO - 2024-10-09 15:57:39 --> Output Class Initialized
INFO - 2024-10-09 15:57:39 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:39 --> Input Class Initialized
INFO - 2024-10-09 15:57:39 --> Language Class Initialized
INFO - 2024-10-09 15:57:39 --> Language Class Initialized
INFO - 2024-10-09 15:57:39 --> Config Class Initialized
INFO - 2024-10-09 15:57:39 --> Loader Class Initialized
INFO - 2024-10-09 15:57:39 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:39 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:39 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:39 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:39 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:39 --> Controller Class Initialized
INFO - 2024-10-09 15:57:41 --> Config Class Initialized
INFO - 2024-10-09 15:57:41 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:41 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:41 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:41 --> URI Class Initialized
INFO - 2024-10-09 15:57:41 --> Router Class Initialized
INFO - 2024-10-09 15:57:41 --> Output Class Initialized
INFO - 2024-10-09 15:57:41 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:41 --> Input Class Initialized
INFO - 2024-10-09 15:57:41 --> Language Class Initialized
INFO - 2024-10-09 15:57:41 --> Language Class Initialized
INFO - 2024-10-09 15:57:41 --> Config Class Initialized
INFO - 2024-10-09 15:57:41 --> Loader Class Initialized
INFO - 2024-10-09 15:57:41 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:41 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:41 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:41 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:41 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:41 --> Controller Class Initialized
DEBUG - 2024-10-09 15:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 15:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:57:41 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:41 --> Total execution time: 0.0294
INFO - 2024-10-09 15:57:43 --> Config Class Initialized
INFO - 2024-10-09 15:57:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:43 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:43 --> URI Class Initialized
INFO - 2024-10-09 15:57:43 --> Router Class Initialized
INFO - 2024-10-09 15:57:43 --> Output Class Initialized
INFO - 2024-10-09 15:57:43 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:43 --> Input Class Initialized
INFO - 2024-10-09 15:57:43 --> Language Class Initialized
INFO - 2024-10-09 15:57:43 --> Language Class Initialized
INFO - 2024-10-09 15:57:43 --> Config Class Initialized
INFO - 2024-10-09 15:57:43 --> Loader Class Initialized
INFO - 2024-10-09 15:57:43 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:43 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:43 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:43 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:43 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:43 --> Controller Class Initialized
INFO - 2024-10-09 15:57:43 --> Helper loaded: cookie_helper
INFO - 2024-10-09 15:57:43 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:43 --> Total execution time: 0.0299
INFO - 2024-10-09 15:57:43 --> Config Class Initialized
INFO - 2024-10-09 15:57:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:43 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:43 --> URI Class Initialized
INFO - 2024-10-09 15:57:43 --> Router Class Initialized
INFO - 2024-10-09 15:57:43 --> Output Class Initialized
INFO - 2024-10-09 15:57:43 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:43 --> Input Class Initialized
INFO - 2024-10-09 15:57:43 --> Language Class Initialized
INFO - 2024-10-09 15:57:43 --> Language Class Initialized
INFO - 2024-10-09 15:57:43 --> Config Class Initialized
INFO - 2024-10-09 15:57:43 --> Loader Class Initialized
INFO - 2024-10-09 15:57:43 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:43 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:43 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:43 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:43 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:43 --> Controller Class Initialized
DEBUG - 2024-10-09 15:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:57:43 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:43 --> Total execution time: 0.0285
INFO - 2024-10-09 15:57:45 --> Config Class Initialized
INFO - 2024-10-09 15:57:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:45 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:45 --> URI Class Initialized
INFO - 2024-10-09 15:57:45 --> Router Class Initialized
INFO - 2024-10-09 15:57:45 --> Output Class Initialized
INFO - 2024-10-09 15:57:45 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:45 --> Input Class Initialized
INFO - 2024-10-09 15:57:45 --> Language Class Initialized
INFO - 2024-10-09 15:57:45 --> Language Class Initialized
INFO - 2024-10-09 15:57:45 --> Config Class Initialized
INFO - 2024-10-09 15:57:45 --> Loader Class Initialized
INFO - 2024-10-09 15:57:45 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:45 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:45 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:45 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:45 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:45 --> Controller Class Initialized
DEBUG - 2024-10-09 15:57:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:57:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:57:45 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:45 --> Total execution time: 0.0311
INFO - 2024-10-09 15:57:46 --> Config Class Initialized
INFO - 2024-10-09 15:57:46 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:46 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:46 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:46 --> URI Class Initialized
INFO - 2024-10-09 15:57:46 --> Router Class Initialized
INFO - 2024-10-09 15:57:46 --> Output Class Initialized
INFO - 2024-10-09 15:57:46 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:46 --> Input Class Initialized
INFO - 2024-10-09 15:57:46 --> Language Class Initialized
INFO - 2024-10-09 15:57:46 --> Language Class Initialized
INFO - 2024-10-09 15:57:46 --> Config Class Initialized
INFO - 2024-10-09 15:57:46 --> Loader Class Initialized
INFO - 2024-10-09 15:57:46 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:46 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:46 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:46 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:46 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:46 --> Controller Class Initialized
INFO - 2024-10-09 15:57:46 --> Config Class Initialized
INFO - 2024-10-09 15:57:46 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:57:46 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:57:46 --> Utf8 Class Initialized
INFO - 2024-10-09 15:57:46 --> URI Class Initialized
INFO - 2024-10-09 15:57:46 --> Router Class Initialized
INFO - 2024-10-09 15:57:46 --> Output Class Initialized
INFO - 2024-10-09 15:57:46 --> Security Class Initialized
DEBUG - 2024-10-09 15:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:57:46 --> Input Class Initialized
INFO - 2024-10-09 15:57:46 --> Language Class Initialized
INFO - 2024-10-09 15:57:46 --> Language Class Initialized
INFO - 2024-10-09 15:57:46 --> Config Class Initialized
INFO - 2024-10-09 15:57:46 --> Loader Class Initialized
INFO - 2024-10-09 15:57:46 --> Helper loaded: url_helper
INFO - 2024-10-09 15:57:46 --> Helper loaded: file_helper
INFO - 2024-10-09 15:57:46 --> Helper loaded: form_helper
INFO - 2024-10-09 15:57:46 --> Helper loaded: my_helper
INFO - 2024-10-09 15:57:46 --> Database Driver Class Initialized
INFO - 2024-10-09 15:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:57:46 --> Controller Class Initialized
DEBUG - 2024-10-09 15:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 15:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:57:46 --> Final output sent to browser
DEBUG - 2024-10-09 15:57:46 --> Total execution time: 0.0299
INFO - 2024-10-09 15:58:01 --> Config Class Initialized
INFO - 2024-10-09 15:58:01 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:01 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:01 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:01 --> URI Class Initialized
INFO - 2024-10-09 15:58:01 --> Router Class Initialized
INFO - 2024-10-09 15:58:01 --> Output Class Initialized
INFO - 2024-10-09 15:58:01 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:01 --> Input Class Initialized
INFO - 2024-10-09 15:58:01 --> Language Class Initialized
INFO - 2024-10-09 15:58:01 --> Language Class Initialized
INFO - 2024-10-09 15:58:01 --> Config Class Initialized
INFO - 2024-10-09 15:58:01 --> Loader Class Initialized
INFO - 2024-10-09 15:58:01 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:01 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:01 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:01 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:01 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:01 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 15:58:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:01 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:01 --> Total execution time: 0.1408
INFO - 2024-10-09 15:58:01 --> Config Class Initialized
INFO - 2024-10-09 15:58:01 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:01 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:01 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:01 --> URI Class Initialized
INFO - 2024-10-09 15:58:01 --> Router Class Initialized
INFO - 2024-10-09 15:58:01 --> Output Class Initialized
INFO - 2024-10-09 15:58:01 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:01 --> Input Class Initialized
INFO - 2024-10-09 15:58:01 --> Language Class Initialized
INFO - 2024-10-09 15:58:01 --> Language Class Initialized
INFO - 2024-10-09 15:58:01 --> Config Class Initialized
INFO - 2024-10-09 15:58:01 --> Loader Class Initialized
INFO - 2024-10-09 15:58:01 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:01 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:01 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:01 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:01 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:01 --> Controller Class Initialized
INFO - 2024-10-09 15:58:05 --> Config Class Initialized
INFO - 2024-10-09 15:58:05 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:05 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:05 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:05 --> URI Class Initialized
INFO - 2024-10-09 15:58:05 --> Router Class Initialized
INFO - 2024-10-09 15:58:05 --> Output Class Initialized
INFO - 2024-10-09 15:58:05 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:05 --> Input Class Initialized
INFO - 2024-10-09 15:58:05 --> Language Class Initialized
INFO - 2024-10-09 15:58:05 --> Language Class Initialized
INFO - 2024-10-09 15:58:05 --> Config Class Initialized
INFO - 2024-10-09 15:58:05 --> Loader Class Initialized
INFO - 2024-10-09 15:58:05 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:05 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:05 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:05 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:05 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:05 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 15:58:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:05 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:05 --> Total execution time: 0.0455
INFO - 2024-10-09 15:58:12 --> Config Class Initialized
INFO - 2024-10-09 15:58:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:12 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:12 --> URI Class Initialized
INFO - 2024-10-09 15:58:12 --> Router Class Initialized
INFO - 2024-10-09 15:58:12 --> Output Class Initialized
INFO - 2024-10-09 15:58:12 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:12 --> Input Class Initialized
INFO - 2024-10-09 15:58:12 --> Language Class Initialized
INFO - 2024-10-09 15:58:12 --> Language Class Initialized
INFO - 2024-10-09 15:58:12 --> Config Class Initialized
INFO - 2024-10-09 15:58:12 --> Loader Class Initialized
INFO - 2024-10-09 15:58:12 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:12 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:12 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:12 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:12 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:12 --> Controller Class Initialized
INFO - 2024-10-09 15:58:12 --> Config Class Initialized
INFO - 2024-10-09 15:58:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:12 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:12 --> URI Class Initialized
INFO - 2024-10-09 15:58:12 --> Router Class Initialized
INFO - 2024-10-09 15:58:12 --> Output Class Initialized
INFO - 2024-10-09 15:58:12 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:12 --> Input Class Initialized
INFO - 2024-10-09 15:58:12 --> Language Class Initialized
INFO - 2024-10-09 15:58:12 --> Language Class Initialized
INFO - 2024-10-09 15:58:12 --> Config Class Initialized
INFO - 2024-10-09 15:58:12 --> Loader Class Initialized
INFO - 2024-10-09 15:58:12 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:12 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:12 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:12 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:12 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:12 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 15:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:12 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:12 --> Total execution time: 0.0279
INFO - 2024-10-09 15:58:21 --> Config Class Initialized
INFO - 2024-10-09 15:58:21 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:21 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:21 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:21 --> URI Class Initialized
INFO - 2024-10-09 15:58:21 --> Router Class Initialized
INFO - 2024-10-09 15:58:21 --> Output Class Initialized
INFO - 2024-10-09 15:58:21 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:21 --> Input Class Initialized
INFO - 2024-10-09 15:58:21 --> Language Class Initialized
INFO - 2024-10-09 15:58:21 --> Language Class Initialized
INFO - 2024-10-09 15:58:21 --> Config Class Initialized
INFO - 2024-10-09 15:58:21 --> Loader Class Initialized
INFO - 2024-10-09 15:58:21 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:21 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:21 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:21 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:21 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:21 --> Controller Class Initialized
INFO - 2024-10-09 15:58:21 --> Config Class Initialized
INFO - 2024-10-09 15:58:21 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:21 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:21 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:21 --> URI Class Initialized
INFO - 2024-10-09 15:58:21 --> Router Class Initialized
INFO - 2024-10-09 15:58:21 --> Output Class Initialized
INFO - 2024-10-09 15:58:21 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:21 --> Input Class Initialized
INFO - 2024-10-09 15:58:21 --> Language Class Initialized
INFO - 2024-10-09 15:58:21 --> Language Class Initialized
INFO - 2024-10-09 15:58:21 --> Config Class Initialized
INFO - 2024-10-09 15:58:21 --> Loader Class Initialized
INFO - 2024-10-09 15:58:21 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:21 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:22 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:22 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:22 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:22 --> Controller Class Initialized
INFO - 2024-10-09 15:58:22 --> Helper loaded: cookie_helper
INFO - 2024-10-09 15:58:22 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:22 --> Total execution time: 0.0467
INFO - 2024-10-09 15:58:22 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:22 --> Total execution time: 0.2350
INFO - 2024-10-09 15:58:22 --> Config Class Initialized
INFO - 2024-10-09 15:58:22 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:22 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:22 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:22 --> URI Class Initialized
INFO - 2024-10-09 15:58:22 --> Router Class Initialized
INFO - 2024-10-09 15:58:22 --> Output Class Initialized
INFO - 2024-10-09 15:58:22 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:22 --> Input Class Initialized
INFO - 2024-10-09 15:58:22 --> Language Class Initialized
INFO - 2024-10-09 15:58:22 --> Language Class Initialized
INFO - 2024-10-09 15:58:22 --> Config Class Initialized
INFO - 2024-10-09 15:58:22 --> Loader Class Initialized
INFO - 2024-10-09 15:58:22 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:22 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:22 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:22 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:22 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:22 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:58:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:22 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:22 --> Total execution time: 0.0305
INFO - 2024-10-09 15:58:29 --> Config Class Initialized
INFO - 2024-10-09 15:58:29 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:29 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:29 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:29 --> URI Class Initialized
INFO - 2024-10-09 15:58:29 --> Router Class Initialized
INFO - 2024-10-09 15:58:29 --> Output Class Initialized
INFO - 2024-10-09 15:58:29 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:29 --> Input Class Initialized
INFO - 2024-10-09 15:58:29 --> Language Class Initialized
INFO - 2024-10-09 15:58:29 --> Language Class Initialized
INFO - 2024-10-09 15:58:29 --> Config Class Initialized
INFO - 2024-10-09 15:58:29 --> Loader Class Initialized
INFO - 2024-10-09 15:58:29 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:29 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:29 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:29 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:29 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:29 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:58:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:29 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:29 --> Total execution time: 0.0273
INFO - 2024-10-09 15:58:31 --> Config Class Initialized
INFO - 2024-10-09 15:58:31 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:31 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:31 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:31 --> URI Class Initialized
INFO - 2024-10-09 15:58:31 --> Router Class Initialized
INFO - 2024-10-09 15:58:31 --> Output Class Initialized
INFO - 2024-10-09 15:58:31 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:31 --> Input Class Initialized
INFO - 2024-10-09 15:58:31 --> Language Class Initialized
INFO - 2024-10-09 15:58:31 --> Language Class Initialized
INFO - 2024-10-09 15:58:31 --> Config Class Initialized
INFO - 2024-10-09 15:58:31 --> Loader Class Initialized
INFO - 2024-10-09 15:58:31 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:31 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:31 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:31 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:31 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:31 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 15:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:31 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:31 --> Total execution time: 0.0319
INFO - 2024-10-09 15:58:31 --> Config Class Initialized
INFO - 2024-10-09 15:58:31 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:31 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:31 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:31 --> URI Class Initialized
INFO - 2024-10-09 15:58:31 --> Router Class Initialized
INFO - 2024-10-09 15:58:31 --> Output Class Initialized
INFO - 2024-10-09 15:58:31 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:31 --> Input Class Initialized
INFO - 2024-10-09 15:58:31 --> Language Class Initialized
INFO - 2024-10-09 15:58:31 --> Language Class Initialized
INFO - 2024-10-09 15:58:31 --> Config Class Initialized
INFO - 2024-10-09 15:58:31 --> Loader Class Initialized
INFO - 2024-10-09 15:58:31 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:31 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:31 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:31 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:31 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:31 --> Controller Class Initialized
INFO - 2024-10-09 15:58:31 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:31 --> Total execution time: 0.0319
INFO - 2024-10-09 15:58:33 --> Config Class Initialized
INFO - 2024-10-09 15:58:33 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:33 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:33 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:33 --> URI Class Initialized
INFO - 2024-10-09 15:58:33 --> Router Class Initialized
INFO - 2024-10-09 15:58:33 --> Output Class Initialized
INFO - 2024-10-09 15:58:33 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:33 --> Input Class Initialized
INFO - 2024-10-09 15:58:33 --> Language Class Initialized
INFO - 2024-10-09 15:58:33 --> Language Class Initialized
INFO - 2024-10-09 15:58:33 --> Config Class Initialized
INFO - 2024-10-09 15:58:33 --> Loader Class Initialized
INFO - 2024-10-09 15:58:33 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:33 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:33 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:33 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:33 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:33 --> Controller Class Initialized
INFO - 2024-10-09 15:58:33 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:33 --> Total execution time: 0.0405
INFO - 2024-10-09 15:58:34 --> Config Class Initialized
INFO - 2024-10-09 15:58:34 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:34 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:34 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:34 --> URI Class Initialized
INFO - 2024-10-09 15:58:34 --> Router Class Initialized
INFO - 2024-10-09 15:58:34 --> Output Class Initialized
INFO - 2024-10-09 15:58:34 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:34 --> Input Class Initialized
INFO - 2024-10-09 15:58:34 --> Language Class Initialized
INFO - 2024-10-09 15:58:34 --> Language Class Initialized
INFO - 2024-10-09 15:58:34 --> Config Class Initialized
INFO - 2024-10-09 15:58:34 --> Loader Class Initialized
INFO - 2024-10-09 15:58:34 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:34 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:34 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:34 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:34 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:34 --> Controller Class Initialized
INFO - 2024-10-09 15:58:34 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:34 --> Total execution time: 0.0322
INFO - 2024-10-09 15:58:38 --> Config Class Initialized
INFO - 2024-10-09 15:58:38 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:38 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:38 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:38 --> URI Class Initialized
INFO - 2024-10-09 15:58:38 --> Router Class Initialized
INFO - 2024-10-09 15:58:38 --> Output Class Initialized
INFO - 2024-10-09 15:58:38 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:38 --> Input Class Initialized
INFO - 2024-10-09 15:58:38 --> Language Class Initialized
INFO - 2024-10-09 15:58:38 --> Language Class Initialized
INFO - 2024-10-09 15:58:38 --> Config Class Initialized
INFO - 2024-10-09 15:58:38 --> Loader Class Initialized
INFO - 2024-10-09 15:58:38 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:38 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:38 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:38 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:38 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:38 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:38 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:38 --> Total execution time: 0.0326
INFO - 2024-10-09 15:58:41 --> Config Class Initialized
INFO - 2024-10-09 15:58:41 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:41 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:41 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:41 --> URI Class Initialized
INFO - 2024-10-09 15:58:41 --> Router Class Initialized
INFO - 2024-10-09 15:58:41 --> Output Class Initialized
INFO - 2024-10-09 15:58:41 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:41 --> Input Class Initialized
INFO - 2024-10-09 15:58:41 --> Language Class Initialized
INFO - 2024-10-09 15:58:41 --> Language Class Initialized
INFO - 2024-10-09 15:58:41 --> Config Class Initialized
INFO - 2024-10-09 15:58:41 --> Loader Class Initialized
INFO - 2024-10-09 15:58:41 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:41 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:41 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:41 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:41 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:41 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 15:58:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:41 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:41 --> Total execution time: 0.0301
INFO - 2024-10-09 15:58:42 --> Config Class Initialized
INFO - 2024-10-09 15:58:42 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:42 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:42 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:42 --> URI Class Initialized
DEBUG - 2024-10-09 15:58:42 --> No URI present. Default controller set.
INFO - 2024-10-09 15:58:42 --> Router Class Initialized
INFO - 2024-10-09 15:58:42 --> Output Class Initialized
INFO - 2024-10-09 15:58:42 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:42 --> Input Class Initialized
INFO - 2024-10-09 15:58:42 --> Language Class Initialized
INFO - 2024-10-09 15:58:42 --> Language Class Initialized
INFO - 2024-10-09 15:58:42 --> Config Class Initialized
INFO - 2024-10-09 15:58:42 --> Loader Class Initialized
INFO - 2024-10-09 15:58:42 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:42 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:42 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:42 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:42 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:42 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:58:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:42 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:42 --> Total execution time: 0.0349
INFO - 2024-10-09 15:58:43 --> Config Class Initialized
INFO - 2024-10-09 15:58:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:43 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:43 --> URI Class Initialized
INFO - 2024-10-09 15:58:43 --> Router Class Initialized
INFO - 2024-10-09 15:58:43 --> Output Class Initialized
INFO - 2024-10-09 15:58:43 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:43 --> Input Class Initialized
INFO - 2024-10-09 15:58:43 --> Language Class Initialized
INFO - 2024-10-09 15:58:43 --> Language Class Initialized
INFO - 2024-10-09 15:58:43 --> Config Class Initialized
INFO - 2024-10-09 15:58:43 --> Loader Class Initialized
INFO - 2024-10-09 15:58:43 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:43 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:43 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:43 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:43 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:43 --> Controller Class Initialized
INFO - 2024-10-09 15:58:43 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:43 --> Total execution time: 0.0377
INFO - 2024-10-09 15:58:44 --> Config Class Initialized
INFO - 2024-10-09 15:58:44 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:44 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:44 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:44 --> URI Class Initialized
INFO - 2024-10-09 15:58:44 --> Router Class Initialized
INFO - 2024-10-09 15:58:44 --> Output Class Initialized
INFO - 2024-10-09 15:58:44 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:44 --> Input Class Initialized
INFO - 2024-10-09 15:58:44 --> Language Class Initialized
INFO - 2024-10-09 15:58:44 --> Language Class Initialized
INFO - 2024-10-09 15:58:44 --> Config Class Initialized
INFO - 2024-10-09 15:58:44 --> Loader Class Initialized
INFO - 2024-10-09 15:58:44 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:44 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:44 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:44 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:44 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:44 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:58:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:44 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:44 --> Total execution time: 0.0339
INFO - 2024-10-09 15:58:48 --> Config Class Initialized
INFO - 2024-10-09 15:58:48 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:48 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:48 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:48 --> URI Class Initialized
INFO - 2024-10-09 15:58:48 --> Router Class Initialized
INFO - 2024-10-09 15:58:48 --> Output Class Initialized
INFO - 2024-10-09 15:58:48 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:48 --> Input Class Initialized
INFO - 2024-10-09 15:58:48 --> Language Class Initialized
INFO - 2024-10-09 15:58:48 --> Language Class Initialized
INFO - 2024-10-09 15:58:48 --> Config Class Initialized
INFO - 2024-10-09 15:58:48 --> Loader Class Initialized
INFO - 2024-10-09 15:58:48 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:48 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:48 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:48 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:48 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:48 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:48 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:48 --> Total execution time: 0.0295
INFO - 2024-10-09 15:58:51 --> Config Class Initialized
INFO - 2024-10-09 15:58:51 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:51 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:51 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:51 --> URI Class Initialized
INFO - 2024-10-09 15:58:51 --> Router Class Initialized
INFO - 2024-10-09 15:58:51 --> Output Class Initialized
INFO - 2024-10-09 15:58:51 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:51 --> Input Class Initialized
INFO - 2024-10-09 15:58:51 --> Language Class Initialized
INFO - 2024-10-09 15:58:51 --> Language Class Initialized
INFO - 2024-10-09 15:58:51 --> Config Class Initialized
INFO - 2024-10-09 15:58:51 --> Loader Class Initialized
INFO - 2024-10-09 15:58:51 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:51 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:51 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:51 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:51 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:51 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:58:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:51 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:51 --> Total execution time: 0.0347
INFO - 2024-10-09 15:58:53 --> Config Class Initialized
INFO - 2024-10-09 15:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:53 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:53 --> URI Class Initialized
INFO - 2024-10-09 15:58:53 --> Router Class Initialized
INFO - 2024-10-09 15:58:53 --> Output Class Initialized
INFO - 2024-10-09 15:58:53 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:53 --> Input Class Initialized
INFO - 2024-10-09 15:58:53 --> Language Class Initialized
INFO - 2024-10-09 15:58:53 --> Language Class Initialized
INFO - 2024-10-09 15:58:53 --> Config Class Initialized
INFO - 2024-10-09 15:58:53 --> Loader Class Initialized
INFO - 2024-10-09 15:58:53 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:53 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:53 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 15:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:53 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:53 --> Total execution time: 0.0540
INFO - 2024-10-09 15:58:53 --> Config Class Initialized
INFO - 2024-10-09 15:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:53 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:53 --> URI Class Initialized
INFO - 2024-10-09 15:58:53 --> Router Class Initialized
INFO - 2024-10-09 15:58:53 --> Output Class Initialized
INFO - 2024-10-09 15:58:53 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:53 --> Input Class Initialized
INFO - 2024-10-09 15:58:53 --> Language Class Initialized
INFO - 2024-10-09 15:58:53 --> Language Class Initialized
INFO - 2024-10-09 15:58:53 --> Config Class Initialized
INFO - 2024-10-09 15:58:53 --> Loader Class Initialized
INFO - 2024-10-09 15:58:53 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:53 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:53 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 15:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:53 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:53 --> Total execution time: 0.0355
INFO - 2024-10-09 15:58:53 --> Config Class Initialized
INFO - 2024-10-09 15:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:53 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:53 --> URI Class Initialized
INFO - 2024-10-09 15:58:53 --> Router Class Initialized
INFO - 2024-10-09 15:58:53 --> Output Class Initialized
INFO - 2024-10-09 15:58:53 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:53 --> Input Class Initialized
INFO - 2024-10-09 15:58:53 --> Language Class Initialized
INFO - 2024-10-09 15:58:53 --> Language Class Initialized
INFO - 2024-10-09 15:58:53 --> Config Class Initialized
INFO - 2024-10-09 15:58:53 --> Loader Class Initialized
INFO - 2024-10-09 15:58:53 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:53 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:53 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:53 --> Controller Class Initialized
DEBUG - 2024-10-09 15:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 15:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:58:53 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:53 --> Total execution time: 0.0330
INFO - 2024-10-09 15:58:54 --> Config Class Initialized
INFO - 2024-10-09 15:58:54 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:54 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:54 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:54 --> URI Class Initialized
INFO - 2024-10-09 15:58:54 --> Router Class Initialized
INFO - 2024-10-09 15:58:54 --> Output Class Initialized
INFO - 2024-10-09 15:58:54 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:54 --> Input Class Initialized
INFO - 2024-10-09 15:58:54 --> Language Class Initialized
INFO - 2024-10-09 15:58:54 --> Language Class Initialized
INFO - 2024-10-09 15:58:54 --> Config Class Initialized
INFO - 2024-10-09 15:58:54 --> Loader Class Initialized
INFO - 2024-10-09 15:58:54 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:54 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:54 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:54 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:54 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:54 --> Controller Class Initialized
INFO - 2024-10-09 15:58:55 --> Config Class Initialized
INFO - 2024-10-09 15:58:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:55 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:55 --> URI Class Initialized
INFO - 2024-10-09 15:58:55 --> Router Class Initialized
INFO - 2024-10-09 15:58:55 --> Output Class Initialized
INFO - 2024-10-09 15:58:55 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:55 --> Input Class Initialized
INFO - 2024-10-09 15:58:55 --> Language Class Initialized
INFO - 2024-10-09 15:58:55 --> Language Class Initialized
INFO - 2024-10-09 15:58:55 --> Config Class Initialized
INFO - 2024-10-09 15:58:55 --> Loader Class Initialized
INFO - 2024-10-09 15:58:55 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:55 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:55 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:55 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:55 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:55 --> Controller Class Initialized
INFO - 2024-10-09 15:58:55 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:55 --> Total execution time: 0.0320
INFO - 2024-10-09 15:58:57 --> Config Class Initialized
INFO - 2024-10-09 15:58:57 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:57 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:57 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:57 --> URI Class Initialized
INFO - 2024-10-09 15:58:57 --> Router Class Initialized
INFO - 2024-10-09 15:58:57 --> Output Class Initialized
INFO - 2024-10-09 15:58:57 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:57 --> Input Class Initialized
INFO - 2024-10-09 15:58:57 --> Language Class Initialized
INFO - 2024-10-09 15:58:57 --> Language Class Initialized
INFO - 2024-10-09 15:58:57 --> Config Class Initialized
INFO - 2024-10-09 15:58:57 --> Loader Class Initialized
INFO - 2024-10-09 15:58:57 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:57 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:57 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:57 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:57 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:57 --> Controller Class Initialized
INFO - 2024-10-09 15:58:57 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:57 --> Total execution time: 0.0302
INFO - 2024-10-09 15:58:58 --> Config Class Initialized
INFO - 2024-10-09 15:58:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:58:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:58:58 --> Utf8 Class Initialized
INFO - 2024-10-09 15:58:58 --> URI Class Initialized
INFO - 2024-10-09 15:58:58 --> Router Class Initialized
INFO - 2024-10-09 15:58:58 --> Output Class Initialized
INFO - 2024-10-09 15:58:58 --> Security Class Initialized
DEBUG - 2024-10-09 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:58:58 --> Input Class Initialized
INFO - 2024-10-09 15:58:58 --> Language Class Initialized
INFO - 2024-10-09 15:58:58 --> Language Class Initialized
INFO - 2024-10-09 15:58:58 --> Config Class Initialized
INFO - 2024-10-09 15:58:58 --> Loader Class Initialized
INFO - 2024-10-09 15:58:58 --> Helper loaded: url_helper
INFO - 2024-10-09 15:58:58 --> Helper loaded: file_helper
INFO - 2024-10-09 15:58:58 --> Helper loaded: form_helper
INFO - 2024-10-09 15:58:58 --> Helper loaded: my_helper
INFO - 2024-10-09 15:58:58 --> Database Driver Class Initialized
INFO - 2024-10-09 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:58:58 --> Controller Class Initialized
INFO - 2024-10-09 15:58:58 --> Final output sent to browser
DEBUG - 2024-10-09 15:58:58 --> Total execution time: 0.0347
INFO - 2024-10-09 15:59:00 --> Config Class Initialized
INFO - 2024-10-09 15:59:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:59:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:59:00 --> Utf8 Class Initialized
INFO - 2024-10-09 15:59:00 --> URI Class Initialized
INFO - 2024-10-09 15:59:00 --> Router Class Initialized
INFO - 2024-10-09 15:59:00 --> Output Class Initialized
INFO - 2024-10-09 15:59:00 --> Security Class Initialized
DEBUG - 2024-10-09 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:59:00 --> Input Class Initialized
INFO - 2024-10-09 15:59:00 --> Language Class Initialized
INFO - 2024-10-09 15:59:00 --> Language Class Initialized
INFO - 2024-10-09 15:59:00 --> Config Class Initialized
INFO - 2024-10-09 15:59:00 --> Loader Class Initialized
INFO - 2024-10-09 15:59:00 --> Helper loaded: url_helper
INFO - 2024-10-09 15:59:00 --> Helper loaded: file_helper
INFO - 2024-10-09 15:59:00 --> Helper loaded: form_helper
INFO - 2024-10-09 15:59:00 --> Helper loaded: my_helper
INFO - 2024-10-09 15:59:00 --> Database Driver Class Initialized
INFO - 2024-10-09 15:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:59:00 --> Controller Class Initialized
DEBUG - 2024-10-09 15:59:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:59:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:59:00 --> Final output sent to browser
DEBUG - 2024-10-09 15:59:00 --> Total execution time: 0.0294
INFO - 2024-10-09 15:59:22 --> Config Class Initialized
INFO - 2024-10-09 15:59:22 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:59:22 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:59:22 --> Utf8 Class Initialized
INFO - 2024-10-09 15:59:22 --> URI Class Initialized
INFO - 2024-10-09 15:59:22 --> Router Class Initialized
INFO - 2024-10-09 15:59:22 --> Output Class Initialized
INFO - 2024-10-09 15:59:22 --> Security Class Initialized
DEBUG - 2024-10-09 15:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:59:22 --> Input Class Initialized
INFO - 2024-10-09 15:59:22 --> Language Class Initialized
INFO - 2024-10-09 15:59:22 --> Language Class Initialized
INFO - 2024-10-09 15:59:22 --> Config Class Initialized
INFO - 2024-10-09 15:59:22 --> Loader Class Initialized
INFO - 2024-10-09 15:59:22 --> Helper loaded: url_helper
INFO - 2024-10-09 15:59:22 --> Helper loaded: file_helper
INFO - 2024-10-09 15:59:22 --> Helper loaded: form_helper
INFO - 2024-10-09 15:59:22 --> Helper loaded: my_helper
INFO - 2024-10-09 15:59:22 --> Database Driver Class Initialized
INFO - 2024-10-09 15:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:59:22 --> Controller Class Initialized
INFO - 2024-10-09 15:59:23 --> Final output sent to browser
DEBUG - 2024-10-09 15:59:23 --> Total execution time: 0.3775
INFO - 2024-10-09 15:59:27 --> Config Class Initialized
INFO - 2024-10-09 15:59:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:59:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:59:27 --> Utf8 Class Initialized
INFO - 2024-10-09 15:59:27 --> URI Class Initialized
INFO - 2024-10-09 15:59:27 --> Router Class Initialized
INFO - 2024-10-09 15:59:27 --> Output Class Initialized
INFO - 2024-10-09 15:59:27 --> Security Class Initialized
DEBUG - 2024-10-09 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:59:27 --> Input Class Initialized
INFO - 2024-10-09 15:59:27 --> Language Class Initialized
INFO - 2024-10-09 15:59:27 --> Language Class Initialized
INFO - 2024-10-09 15:59:27 --> Config Class Initialized
INFO - 2024-10-09 15:59:27 --> Loader Class Initialized
INFO - 2024-10-09 15:59:27 --> Helper loaded: url_helper
INFO - 2024-10-09 15:59:27 --> Helper loaded: file_helper
INFO - 2024-10-09 15:59:27 --> Helper loaded: form_helper
INFO - 2024-10-09 15:59:27 --> Helper loaded: my_helper
INFO - 2024-10-09 15:59:27 --> Database Driver Class Initialized
INFO - 2024-10-09 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:59:27 --> Controller Class Initialized
DEBUG - 2024-10-09 15:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 15:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:59:27 --> Final output sent to browser
DEBUG - 2024-10-09 15:59:27 --> Total execution time: 0.0340
INFO - 2024-10-09 15:59:27 --> Config Class Initialized
INFO - 2024-10-09 15:59:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:59:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:59:27 --> Utf8 Class Initialized
INFO - 2024-10-09 15:59:27 --> URI Class Initialized
DEBUG - 2024-10-09 15:59:27 --> No URI present. Default controller set.
INFO - 2024-10-09 15:59:27 --> Router Class Initialized
INFO - 2024-10-09 15:59:27 --> Output Class Initialized
INFO - 2024-10-09 15:59:27 --> Security Class Initialized
DEBUG - 2024-10-09 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:59:27 --> Input Class Initialized
INFO - 2024-10-09 15:59:27 --> Language Class Initialized
INFO - 2024-10-09 15:59:27 --> Language Class Initialized
INFO - 2024-10-09 15:59:27 --> Config Class Initialized
INFO - 2024-10-09 15:59:27 --> Loader Class Initialized
INFO - 2024-10-09 15:59:27 --> Helper loaded: url_helper
INFO - 2024-10-09 15:59:27 --> Helper loaded: file_helper
INFO - 2024-10-09 15:59:27 --> Helper loaded: form_helper
INFO - 2024-10-09 15:59:27 --> Helper loaded: my_helper
INFO - 2024-10-09 15:59:27 --> Database Driver Class Initialized
INFO - 2024-10-09 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:59:27 --> Controller Class Initialized
DEBUG - 2024-10-09 15:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 15:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:59:27 --> Final output sent to browser
DEBUG - 2024-10-09 15:59:27 --> Total execution time: 0.0268
INFO - 2024-10-09 15:59:30 --> Config Class Initialized
INFO - 2024-10-09 15:59:30 --> Hooks Class Initialized
DEBUG - 2024-10-09 15:59:30 --> UTF-8 Support Enabled
INFO - 2024-10-09 15:59:30 --> Utf8 Class Initialized
INFO - 2024-10-09 15:59:30 --> URI Class Initialized
INFO - 2024-10-09 15:59:30 --> Router Class Initialized
INFO - 2024-10-09 15:59:30 --> Output Class Initialized
INFO - 2024-10-09 15:59:30 --> Security Class Initialized
DEBUG - 2024-10-09 15:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 15:59:30 --> Input Class Initialized
INFO - 2024-10-09 15:59:30 --> Language Class Initialized
INFO - 2024-10-09 15:59:30 --> Language Class Initialized
INFO - 2024-10-09 15:59:30 --> Config Class Initialized
INFO - 2024-10-09 15:59:30 --> Loader Class Initialized
INFO - 2024-10-09 15:59:30 --> Helper loaded: url_helper
INFO - 2024-10-09 15:59:30 --> Helper loaded: file_helper
INFO - 2024-10-09 15:59:30 --> Helper loaded: form_helper
INFO - 2024-10-09 15:59:30 --> Helper loaded: my_helper
INFO - 2024-10-09 15:59:30 --> Database Driver Class Initialized
INFO - 2024-10-09 15:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 15:59:30 --> Controller Class Initialized
DEBUG - 2024-10-09 15:59:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-10-09 15:59:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 15:59:30 --> Final output sent to browser
DEBUG - 2024-10-09 15:59:30 --> Total execution time: 0.0381
INFO - 2024-10-09 16:00:08 --> Config Class Initialized
INFO - 2024-10-09 16:00:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:00:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:00:08 --> Utf8 Class Initialized
INFO - 2024-10-09 16:00:08 --> URI Class Initialized
INFO - 2024-10-09 16:00:08 --> Router Class Initialized
INFO - 2024-10-09 16:00:08 --> Output Class Initialized
INFO - 2024-10-09 16:00:08 --> Security Class Initialized
DEBUG - 2024-10-09 16:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:00:08 --> Input Class Initialized
INFO - 2024-10-09 16:00:08 --> Language Class Initialized
INFO - 2024-10-09 16:00:08 --> Language Class Initialized
INFO - 2024-10-09 16:00:08 --> Config Class Initialized
INFO - 2024-10-09 16:00:08 --> Loader Class Initialized
INFO - 2024-10-09 16:00:08 --> Helper loaded: url_helper
INFO - 2024-10-09 16:00:08 --> Helper loaded: file_helper
INFO - 2024-10-09 16:00:08 --> Helper loaded: form_helper
INFO - 2024-10-09 16:00:08 --> Helper loaded: my_helper
INFO - 2024-10-09 16:00:08 --> Database Driver Class Initialized
INFO - 2024-10-09 16:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:00:08 --> Controller Class Initialized
DEBUG - 2024-10-09 16:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 16:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:00:08 --> Final output sent to browser
DEBUG - 2024-10-09 16:00:08 --> Total execution time: 0.0347
INFO - 2024-10-09 16:00:08 --> Config Class Initialized
INFO - 2024-10-09 16:00:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:00:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:00:08 --> Utf8 Class Initialized
INFO - 2024-10-09 16:00:08 --> URI Class Initialized
INFO - 2024-10-09 16:00:08 --> Router Class Initialized
INFO - 2024-10-09 16:00:08 --> Output Class Initialized
INFO - 2024-10-09 16:00:08 --> Security Class Initialized
DEBUG - 2024-10-09 16:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:00:08 --> Input Class Initialized
INFO - 2024-10-09 16:00:08 --> Language Class Initialized
INFO - 2024-10-09 16:00:08 --> Language Class Initialized
INFO - 2024-10-09 16:00:08 --> Config Class Initialized
INFO - 2024-10-09 16:00:08 --> Loader Class Initialized
INFO - 2024-10-09 16:00:08 --> Helper loaded: url_helper
INFO - 2024-10-09 16:00:08 --> Helper loaded: file_helper
INFO - 2024-10-09 16:00:08 --> Helper loaded: form_helper
INFO - 2024-10-09 16:00:08 --> Helper loaded: my_helper
INFO - 2024-10-09 16:00:08 --> Database Driver Class Initialized
INFO - 2024-10-09 16:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:00:08 --> Controller Class Initialized
INFO - 2024-10-09 16:00:58 --> Config Class Initialized
INFO - 2024-10-09 16:00:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:00:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:00:58 --> Utf8 Class Initialized
INFO - 2024-10-09 16:00:58 --> URI Class Initialized
INFO - 2024-10-09 16:00:58 --> Router Class Initialized
INFO - 2024-10-09 16:00:58 --> Output Class Initialized
INFO - 2024-10-09 16:00:58 --> Security Class Initialized
DEBUG - 2024-10-09 16:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:00:58 --> Input Class Initialized
INFO - 2024-10-09 16:00:58 --> Language Class Initialized
INFO - 2024-10-09 16:00:58 --> Language Class Initialized
INFO - 2024-10-09 16:00:58 --> Config Class Initialized
INFO - 2024-10-09 16:00:58 --> Loader Class Initialized
INFO - 2024-10-09 16:00:58 --> Helper loaded: url_helper
INFO - 2024-10-09 16:00:58 --> Helper loaded: file_helper
INFO - 2024-10-09 16:00:58 --> Helper loaded: form_helper
INFO - 2024-10-09 16:00:58 --> Helper loaded: my_helper
INFO - 2024-10-09 16:00:58 --> Database Driver Class Initialized
INFO - 2024-10-09 16:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:00:58 --> Controller Class Initialized
DEBUG - 2024-10-09 16:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 16:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:00:58 --> Final output sent to browser
DEBUG - 2024-10-09 16:00:58 --> Total execution time: 0.0917
INFO - 2024-10-09 16:01:01 --> Config Class Initialized
INFO - 2024-10-09 16:01:01 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:01:01 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:01:01 --> Utf8 Class Initialized
INFO - 2024-10-09 16:01:01 --> URI Class Initialized
INFO - 2024-10-09 16:01:01 --> Router Class Initialized
INFO - 2024-10-09 16:01:01 --> Output Class Initialized
INFO - 2024-10-09 16:01:01 --> Security Class Initialized
DEBUG - 2024-10-09 16:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:01:01 --> Input Class Initialized
INFO - 2024-10-09 16:01:01 --> Language Class Initialized
INFO - 2024-10-09 16:01:01 --> Language Class Initialized
INFO - 2024-10-09 16:01:01 --> Config Class Initialized
INFO - 2024-10-09 16:01:01 --> Loader Class Initialized
INFO - 2024-10-09 16:01:01 --> Helper loaded: url_helper
INFO - 2024-10-09 16:01:01 --> Helper loaded: file_helper
INFO - 2024-10-09 16:01:01 --> Helper loaded: form_helper
INFO - 2024-10-09 16:01:01 --> Helper loaded: my_helper
INFO - 2024-10-09 16:01:01 --> Database Driver Class Initialized
INFO - 2024-10-09 16:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:01:01 --> Controller Class Initialized
DEBUG - 2024-10-09 16:01:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:01:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:01:02 --> Final output sent to browser
DEBUG - 2024-10-09 16:01:02 --> Total execution time: 0.2210
INFO - 2024-10-09 16:01:06 --> Config Class Initialized
INFO - 2024-10-09 16:01:06 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:01:06 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:01:06 --> Utf8 Class Initialized
INFO - 2024-10-09 16:01:06 --> URI Class Initialized
INFO - 2024-10-09 16:01:06 --> Router Class Initialized
INFO - 2024-10-09 16:01:06 --> Output Class Initialized
INFO - 2024-10-09 16:01:06 --> Security Class Initialized
DEBUG - 2024-10-09 16:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:01:06 --> Input Class Initialized
INFO - 2024-10-09 16:01:06 --> Language Class Initialized
INFO - 2024-10-09 16:01:06 --> Language Class Initialized
INFO - 2024-10-09 16:01:06 --> Config Class Initialized
INFO - 2024-10-09 16:01:06 --> Loader Class Initialized
INFO - 2024-10-09 16:01:06 --> Helper loaded: url_helper
INFO - 2024-10-09 16:01:06 --> Helper loaded: file_helper
INFO - 2024-10-09 16:01:06 --> Helper loaded: form_helper
INFO - 2024-10-09 16:01:06 --> Helper loaded: my_helper
INFO - 2024-10-09 16:01:06 --> Database Driver Class Initialized
INFO - 2024-10-09 16:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:01:06 --> Controller Class Initialized
DEBUG - 2024-10-09 16:01:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 16:01:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:01:06 --> Final output sent to browser
DEBUG - 2024-10-09 16:01:06 --> Total execution time: 0.0373
INFO - 2024-10-09 16:01:08 --> Config Class Initialized
INFO - 2024-10-09 16:01:08 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:01:08 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:01:08 --> Utf8 Class Initialized
INFO - 2024-10-09 16:01:08 --> URI Class Initialized
INFO - 2024-10-09 16:01:08 --> Router Class Initialized
INFO - 2024-10-09 16:01:08 --> Output Class Initialized
INFO - 2024-10-09 16:01:08 --> Security Class Initialized
DEBUG - 2024-10-09 16:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:01:08 --> Input Class Initialized
INFO - 2024-10-09 16:01:08 --> Language Class Initialized
INFO - 2024-10-09 16:01:08 --> Language Class Initialized
INFO - 2024-10-09 16:01:08 --> Config Class Initialized
INFO - 2024-10-09 16:01:08 --> Loader Class Initialized
INFO - 2024-10-09 16:01:08 --> Helper loaded: url_helper
INFO - 2024-10-09 16:01:08 --> Helper loaded: file_helper
INFO - 2024-10-09 16:01:08 --> Helper loaded: form_helper
INFO - 2024-10-09 16:01:08 --> Helper loaded: my_helper
INFO - 2024-10-09 16:01:08 --> Database Driver Class Initialized
INFO - 2024-10-09 16:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:01:08 --> Controller Class Initialized
INFO - 2024-10-09 16:01:08 --> Final output sent to browser
DEBUG - 2024-10-09 16:01:08 --> Total execution time: 0.0462
INFO - 2024-10-09 16:01:10 --> Config Class Initialized
INFO - 2024-10-09 16:01:10 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:01:10 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:01:10 --> Utf8 Class Initialized
INFO - 2024-10-09 16:01:10 --> URI Class Initialized
INFO - 2024-10-09 16:01:10 --> Router Class Initialized
INFO - 2024-10-09 16:01:10 --> Output Class Initialized
INFO - 2024-10-09 16:01:10 --> Security Class Initialized
DEBUG - 2024-10-09 16:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:01:10 --> Input Class Initialized
INFO - 2024-10-09 16:01:10 --> Language Class Initialized
INFO - 2024-10-09 16:01:10 --> Language Class Initialized
INFO - 2024-10-09 16:01:10 --> Config Class Initialized
INFO - 2024-10-09 16:01:10 --> Loader Class Initialized
INFO - 2024-10-09 16:01:10 --> Helper loaded: url_helper
INFO - 2024-10-09 16:01:10 --> Helper loaded: file_helper
INFO - 2024-10-09 16:01:10 --> Helper loaded: form_helper
INFO - 2024-10-09 16:01:10 --> Helper loaded: my_helper
INFO - 2024-10-09 16:01:10 --> Database Driver Class Initialized
INFO - 2024-10-09 16:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:01:10 --> Controller Class Initialized
INFO - 2024-10-09 16:04:19 --> Config Class Initialized
INFO - 2024-10-09 16:04:19 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:19 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:19 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:19 --> URI Class Initialized
INFO - 2024-10-09 16:04:19 --> Router Class Initialized
INFO - 2024-10-09 16:04:19 --> Output Class Initialized
INFO - 2024-10-09 16:04:19 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:19 --> Input Class Initialized
INFO - 2024-10-09 16:04:19 --> Language Class Initialized
INFO - 2024-10-09 16:04:19 --> Language Class Initialized
INFO - 2024-10-09 16:04:19 --> Config Class Initialized
INFO - 2024-10-09 16:04:19 --> Loader Class Initialized
INFO - 2024-10-09 16:04:19 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:19 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:19 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:19 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:19 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:19 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-09 16:04:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:19 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:19 --> Total execution time: 0.0399
INFO - 2024-10-09 16:04:30 --> Config Class Initialized
INFO - 2024-10-09 16:04:30 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:30 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:30 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:30 --> URI Class Initialized
INFO - 2024-10-09 16:04:30 --> Router Class Initialized
INFO - 2024-10-09 16:04:30 --> Output Class Initialized
INFO - 2024-10-09 16:04:30 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:30 --> Input Class Initialized
INFO - 2024-10-09 16:04:30 --> Language Class Initialized
INFO - 2024-10-09 16:04:30 --> Language Class Initialized
INFO - 2024-10-09 16:04:30 --> Config Class Initialized
INFO - 2024-10-09 16:04:30 --> Loader Class Initialized
INFO - 2024-10-09 16:04:30 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:30 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:30 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:30 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:30 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:30 --> Controller Class Initialized
INFO - 2024-10-09 16:04:30 --> Config Class Initialized
INFO - 2024-10-09 16:04:30 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:30 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:30 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:30 --> URI Class Initialized
INFO - 2024-10-09 16:04:30 --> Router Class Initialized
INFO - 2024-10-09 16:04:30 --> Output Class Initialized
INFO - 2024-10-09 16:04:30 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:30 --> Input Class Initialized
INFO - 2024-10-09 16:04:30 --> Language Class Initialized
INFO - 2024-10-09 16:04:30 --> Language Class Initialized
INFO - 2024-10-09 16:04:30 --> Config Class Initialized
INFO - 2024-10-09 16:04:30 --> Loader Class Initialized
INFO - 2024-10-09 16:04:30 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:30 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:30 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:30 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:30 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:30 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 16:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:30 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:30 --> Total execution time: 0.0294
INFO - 2024-10-09 16:04:33 --> Config Class Initialized
INFO - 2024-10-09 16:04:33 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:33 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:33 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:33 --> URI Class Initialized
INFO - 2024-10-09 16:04:33 --> Router Class Initialized
INFO - 2024-10-09 16:04:33 --> Output Class Initialized
INFO - 2024-10-09 16:04:33 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:33 --> Input Class Initialized
INFO - 2024-10-09 16:04:33 --> Language Class Initialized
INFO - 2024-10-09 16:04:33 --> Language Class Initialized
INFO - 2024-10-09 16:04:33 --> Config Class Initialized
INFO - 2024-10-09 16:04:33 --> Loader Class Initialized
INFO - 2024-10-09 16:04:33 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:33 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:33 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:33 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:33 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:33 --> Controller Class Initialized
INFO - 2024-10-09 16:04:33 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:33 --> Total execution time: 0.0305
INFO - 2024-10-09 16:04:38 --> Config Class Initialized
INFO - 2024-10-09 16:04:38 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:38 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:38 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:38 --> URI Class Initialized
INFO - 2024-10-09 16:04:38 --> Router Class Initialized
INFO - 2024-10-09 16:04:38 --> Output Class Initialized
INFO - 2024-10-09 16:04:38 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:38 --> Input Class Initialized
INFO - 2024-10-09 16:04:38 --> Language Class Initialized
INFO - 2024-10-09 16:04:38 --> Language Class Initialized
INFO - 2024-10-09 16:04:38 --> Config Class Initialized
INFO - 2024-10-09 16:04:38 --> Loader Class Initialized
INFO - 2024-10-09 16:04:38 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:38 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:38 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:38 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:38 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:38 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:04:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:38 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:38 --> Total execution time: 0.0306
INFO - 2024-10-09 16:04:41 --> Config Class Initialized
INFO - 2024-10-09 16:04:41 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:41 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:41 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:41 --> URI Class Initialized
INFO - 2024-10-09 16:04:41 --> Router Class Initialized
INFO - 2024-10-09 16:04:41 --> Output Class Initialized
INFO - 2024-10-09 16:04:41 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:41 --> Input Class Initialized
INFO - 2024-10-09 16:04:41 --> Language Class Initialized
INFO - 2024-10-09 16:04:41 --> Language Class Initialized
INFO - 2024-10-09 16:04:41 --> Config Class Initialized
INFO - 2024-10-09 16:04:41 --> Loader Class Initialized
INFO - 2024-10-09 16:04:41 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:41 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:41 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:41 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:41 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:41 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 16:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:41 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:41 --> Total execution time: 0.0325
INFO - 2024-10-09 16:04:43 --> Config Class Initialized
INFO - 2024-10-09 16:04:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:43 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:43 --> URI Class Initialized
INFO - 2024-10-09 16:04:43 --> Router Class Initialized
INFO - 2024-10-09 16:04:43 --> Output Class Initialized
INFO - 2024-10-09 16:04:43 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:43 --> Input Class Initialized
INFO - 2024-10-09 16:04:43 --> Language Class Initialized
INFO - 2024-10-09 16:04:43 --> Language Class Initialized
INFO - 2024-10-09 16:04:43 --> Config Class Initialized
INFO - 2024-10-09 16:04:43 --> Loader Class Initialized
INFO - 2024-10-09 16:04:43 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:43 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:43 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:43 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:43 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:43 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:04:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:43 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:43 --> Total execution time: 0.0551
INFO - 2024-10-09 16:04:44 --> Config Class Initialized
INFO - 2024-10-09 16:04:44 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:44 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:44 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:44 --> URI Class Initialized
INFO - 2024-10-09 16:04:44 --> Router Class Initialized
INFO - 2024-10-09 16:04:44 --> Output Class Initialized
INFO - 2024-10-09 16:04:44 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:44 --> Input Class Initialized
INFO - 2024-10-09 16:04:44 --> Language Class Initialized
INFO - 2024-10-09 16:04:44 --> Language Class Initialized
INFO - 2024-10-09 16:04:44 --> Config Class Initialized
INFO - 2024-10-09 16:04:44 --> Loader Class Initialized
INFO - 2024-10-09 16:04:44 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:44 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:44 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:44 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:44 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:44 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-09 16:04:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:44 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:44 --> Total execution time: 0.0664
INFO - 2024-10-09 16:04:46 --> Config Class Initialized
INFO - 2024-10-09 16:04:46 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:46 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:46 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:46 --> URI Class Initialized
INFO - 2024-10-09 16:04:46 --> Router Class Initialized
INFO - 2024-10-09 16:04:46 --> Output Class Initialized
INFO - 2024-10-09 16:04:46 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:46 --> Input Class Initialized
INFO - 2024-10-09 16:04:46 --> Language Class Initialized
INFO - 2024-10-09 16:04:46 --> Language Class Initialized
INFO - 2024-10-09 16:04:46 --> Config Class Initialized
INFO - 2024-10-09 16:04:46 --> Loader Class Initialized
INFO - 2024-10-09 16:04:46 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:46 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:46 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:46 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:46 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:46 --> Controller Class Initialized
INFO - 2024-10-09 16:04:46 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:46 --> Total execution time: 0.0314
INFO - 2024-10-09 16:04:48 --> Config Class Initialized
INFO - 2024-10-09 16:04:48 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:48 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:48 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:48 --> URI Class Initialized
INFO - 2024-10-09 16:04:48 --> Router Class Initialized
INFO - 2024-10-09 16:04:48 --> Output Class Initialized
INFO - 2024-10-09 16:04:48 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:48 --> Input Class Initialized
INFO - 2024-10-09 16:04:48 --> Language Class Initialized
INFO - 2024-10-09 16:04:48 --> Language Class Initialized
INFO - 2024-10-09 16:04:48 --> Config Class Initialized
INFO - 2024-10-09 16:04:48 --> Loader Class Initialized
INFO - 2024-10-09 16:04:48 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:48 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:48 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:48 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:48 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:48 --> Controller Class Initialized
INFO - 2024-10-09 16:04:59 --> Config Class Initialized
INFO - 2024-10-09 16:04:59 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:04:59 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:04:59 --> Utf8 Class Initialized
INFO - 2024-10-09 16:04:59 --> URI Class Initialized
INFO - 2024-10-09 16:04:59 --> Router Class Initialized
INFO - 2024-10-09 16:04:59 --> Output Class Initialized
INFO - 2024-10-09 16:04:59 --> Security Class Initialized
DEBUG - 2024-10-09 16:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:04:59 --> Input Class Initialized
INFO - 2024-10-09 16:04:59 --> Language Class Initialized
INFO - 2024-10-09 16:04:59 --> Language Class Initialized
INFO - 2024-10-09 16:04:59 --> Config Class Initialized
INFO - 2024-10-09 16:04:59 --> Loader Class Initialized
INFO - 2024-10-09 16:04:59 --> Helper loaded: url_helper
INFO - 2024-10-09 16:04:59 --> Helper loaded: file_helper
INFO - 2024-10-09 16:04:59 --> Helper loaded: form_helper
INFO - 2024-10-09 16:04:59 --> Helper loaded: my_helper
INFO - 2024-10-09 16:04:59 --> Database Driver Class Initialized
INFO - 2024-10-09 16:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:04:59 --> Controller Class Initialized
DEBUG - 2024-10-09 16:04:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:04:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:04:59 --> Final output sent to browser
DEBUG - 2024-10-09 16:04:59 --> Total execution time: 0.0277
INFO - 2024-10-09 16:08:25 --> Config Class Initialized
INFO - 2024-10-09 16:08:25 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:08:25 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:08:25 --> Utf8 Class Initialized
INFO - 2024-10-09 16:08:25 --> URI Class Initialized
INFO - 2024-10-09 16:08:25 --> Router Class Initialized
INFO - 2024-10-09 16:08:25 --> Output Class Initialized
INFO - 2024-10-09 16:08:25 --> Security Class Initialized
DEBUG - 2024-10-09 16:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:08:25 --> Input Class Initialized
INFO - 2024-10-09 16:08:25 --> Language Class Initialized
INFO - 2024-10-09 16:08:25 --> Language Class Initialized
INFO - 2024-10-09 16:08:25 --> Config Class Initialized
INFO - 2024-10-09 16:08:25 --> Loader Class Initialized
INFO - 2024-10-09 16:08:25 --> Helper loaded: url_helper
INFO - 2024-10-09 16:08:25 --> Helper loaded: file_helper
INFO - 2024-10-09 16:08:25 --> Helper loaded: form_helper
INFO - 2024-10-09 16:08:25 --> Helper loaded: my_helper
INFO - 2024-10-09 16:08:25 --> Database Driver Class Initialized
INFO - 2024-10-09 16:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:08:25 --> Controller Class Initialized
DEBUG - 2024-10-09 16:08:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 16:08:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:08:25 --> Final output sent to browser
DEBUG - 2024-10-09 16:08:25 --> Total execution time: 0.0757
INFO - 2024-10-09 16:08:27 --> Config Class Initialized
INFO - 2024-10-09 16:08:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:08:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:08:27 --> Utf8 Class Initialized
INFO - 2024-10-09 16:08:27 --> URI Class Initialized
INFO - 2024-10-09 16:08:27 --> Router Class Initialized
INFO - 2024-10-09 16:08:27 --> Output Class Initialized
INFO - 2024-10-09 16:08:27 --> Security Class Initialized
DEBUG - 2024-10-09 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:08:27 --> Input Class Initialized
INFO - 2024-10-09 16:08:27 --> Language Class Initialized
INFO - 2024-10-09 16:08:27 --> Language Class Initialized
INFO - 2024-10-09 16:08:27 --> Config Class Initialized
INFO - 2024-10-09 16:08:27 --> Loader Class Initialized
INFO - 2024-10-09 16:08:27 --> Helper loaded: url_helper
INFO - 2024-10-09 16:08:27 --> Helper loaded: file_helper
INFO - 2024-10-09 16:08:27 --> Helper loaded: form_helper
INFO - 2024-10-09 16:08:27 --> Helper loaded: my_helper
INFO - 2024-10-09 16:08:27 --> Database Driver Class Initialized
INFO - 2024-10-09 16:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:08:27 --> Controller Class Initialized
DEBUG - 2024-10-09 16:08:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:08:30 --> Final output sent to browser
DEBUG - 2024-10-09 16:08:30 --> Total execution time: 2.9024
INFO - 2024-10-09 16:08:47 --> Config Class Initialized
INFO - 2024-10-09 16:08:47 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:08:47 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:08:47 --> Utf8 Class Initialized
INFO - 2024-10-09 16:08:47 --> URI Class Initialized
INFO - 2024-10-09 16:08:47 --> Router Class Initialized
INFO - 2024-10-09 16:08:47 --> Output Class Initialized
INFO - 2024-10-09 16:08:47 --> Security Class Initialized
DEBUG - 2024-10-09 16:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:08:47 --> Input Class Initialized
INFO - 2024-10-09 16:08:47 --> Language Class Initialized
INFO - 2024-10-09 16:08:47 --> Language Class Initialized
INFO - 2024-10-09 16:08:47 --> Config Class Initialized
INFO - 2024-10-09 16:08:47 --> Loader Class Initialized
INFO - 2024-10-09 16:08:47 --> Helper loaded: url_helper
INFO - 2024-10-09 16:08:47 --> Helper loaded: file_helper
INFO - 2024-10-09 16:08:47 --> Helper loaded: form_helper
INFO - 2024-10-09 16:08:47 --> Helper loaded: my_helper
INFO - 2024-10-09 16:08:47 --> Database Driver Class Initialized
INFO - 2024-10-09 16:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:08:47 --> Controller Class Initialized
DEBUG - 2024-10-09 16:08:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:08:50 --> Final output sent to browser
DEBUG - 2024-10-09 16:08:50 --> Total execution time: 2.8526
INFO - 2024-10-09 16:09:39 --> Config Class Initialized
INFO - 2024-10-09 16:09:39 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:09:39 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:09:39 --> Utf8 Class Initialized
INFO - 2024-10-09 16:09:39 --> URI Class Initialized
INFO - 2024-10-09 16:09:39 --> Router Class Initialized
INFO - 2024-10-09 16:09:39 --> Output Class Initialized
INFO - 2024-10-09 16:09:39 --> Security Class Initialized
DEBUG - 2024-10-09 16:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:09:39 --> Input Class Initialized
INFO - 2024-10-09 16:09:39 --> Language Class Initialized
INFO - 2024-10-09 16:09:39 --> Language Class Initialized
INFO - 2024-10-09 16:09:39 --> Config Class Initialized
INFO - 2024-10-09 16:09:39 --> Loader Class Initialized
INFO - 2024-10-09 16:09:39 --> Helper loaded: url_helper
INFO - 2024-10-09 16:09:39 --> Helper loaded: file_helper
INFO - 2024-10-09 16:09:39 --> Helper loaded: form_helper
INFO - 2024-10-09 16:09:39 --> Helper loaded: my_helper
INFO - 2024-10-09 16:09:39 --> Database Driver Class Initialized
INFO - 2024-10-09 16:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:09:39 --> Controller Class Initialized
DEBUG - 2024-10-09 16:09:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:09:40 --> Config Class Initialized
INFO - 2024-10-09 16:09:40 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:09:40 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:09:40 --> Utf8 Class Initialized
INFO - 2024-10-09 16:09:40 --> URI Class Initialized
INFO - 2024-10-09 16:09:40 --> Router Class Initialized
INFO - 2024-10-09 16:09:40 --> Output Class Initialized
INFO - 2024-10-09 16:09:40 --> Security Class Initialized
DEBUG - 2024-10-09 16:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:09:40 --> Input Class Initialized
INFO - 2024-10-09 16:09:40 --> Language Class Initialized
INFO - 2024-10-09 16:09:40 --> Language Class Initialized
INFO - 2024-10-09 16:09:40 --> Config Class Initialized
INFO - 2024-10-09 16:09:40 --> Loader Class Initialized
INFO - 2024-10-09 16:09:40 --> Helper loaded: url_helper
INFO - 2024-10-09 16:09:40 --> Helper loaded: file_helper
INFO - 2024-10-09 16:09:40 --> Helper loaded: form_helper
INFO - 2024-10-09 16:09:40 --> Helper loaded: my_helper
INFO - 2024-10-09 16:09:40 --> Database Driver Class Initialized
INFO - 2024-10-09 16:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:09:41 --> Controller Class Initialized
DEBUG - 2024-10-09 16:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-09 16:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:09:41 --> Final output sent to browser
DEBUG - 2024-10-09 16:09:41 --> Total execution time: 0.0652
INFO - 2024-10-09 16:09:42 --> Final output sent to browser
DEBUG - 2024-10-09 16:09:42 --> Total execution time: 3.0119
INFO - 2024-10-09 16:09:43 --> Config Class Initialized
INFO - 2024-10-09 16:09:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:09:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:09:43 --> Utf8 Class Initialized
INFO - 2024-10-09 16:09:43 --> URI Class Initialized
INFO - 2024-10-09 16:09:43 --> Router Class Initialized
INFO - 2024-10-09 16:09:43 --> Output Class Initialized
INFO - 2024-10-09 16:09:43 --> Security Class Initialized
DEBUG - 2024-10-09 16:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:09:43 --> Input Class Initialized
INFO - 2024-10-09 16:09:43 --> Language Class Initialized
INFO - 2024-10-09 16:09:43 --> Language Class Initialized
INFO - 2024-10-09 16:09:43 --> Config Class Initialized
INFO - 2024-10-09 16:09:43 --> Loader Class Initialized
INFO - 2024-10-09 16:09:43 --> Helper loaded: url_helper
INFO - 2024-10-09 16:09:43 --> Helper loaded: file_helper
INFO - 2024-10-09 16:09:43 --> Helper loaded: form_helper
INFO - 2024-10-09 16:09:43 --> Helper loaded: my_helper
INFO - 2024-10-09 16:09:43 --> Database Driver Class Initialized
INFO - 2024-10-09 16:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:09:43 --> Controller Class Initialized
DEBUG - 2024-10-09 16:09:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:09:48 --> Final output sent to browser
DEBUG - 2024-10-09 16:09:48 --> Total execution time: 4.9305
INFO - 2024-10-09 16:10:11 --> Config Class Initialized
INFO - 2024-10-09 16:10:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:11 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:11 --> URI Class Initialized
DEBUG - 2024-10-09 16:10:11 --> No URI present. Default controller set.
INFO - 2024-10-09 16:10:11 --> Router Class Initialized
INFO - 2024-10-09 16:10:11 --> Output Class Initialized
INFO - 2024-10-09 16:10:11 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:11 --> Input Class Initialized
INFO - 2024-10-09 16:10:11 --> Language Class Initialized
INFO - 2024-10-09 16:10:11 --> Language Class Initialized
INFO - 2024-10-09 16:10:11 --> Config Class Initialized
INFO - 2024-10-09 16:10:11 --> Loader Class Initialized
INFO - 2024-10-09 16:10:11 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:11 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:11 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:11 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:11 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:11 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-09 16:10:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:11 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:11 --> Total execution time: 0.0390
INFO - 2024-10-09 16:10:15 --> Config Class Initialized
INFO - 2024-10-09 16:10:15 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:15 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:15 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:15 --> URI Class Initialized
INFO - 2024-10-09 16:10:15 --> Router Class Initialized
INFO - 2024-10-09 16:10:15 --> Output Class Initialized
INFO - 2024-10-09 16:10:15 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:15 --> Input Class Initialized
INFO - 2024-10-09 16:10:15 --> Language Class Initialized
INFO - 2024-10-09 16:10:15 --> Language Class Initialized
INFO - 2024-10-09 16:10:15 --> Config Class Initialized
INFO - 2024-10-09 16:10:15 --> Loader Class Initialized
INFO - 2024-10-09 16:10:15 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:15 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:15 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:15 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:15 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:15 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:10:16 --> Config Class Initialized
INFO - 2024-10-09 16:10:16 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:16 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:16 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:16 --> URI Class Initialized
INFO - 2024-10-09 16:10:16 --> Router Class Initialized
INFO - 2024-10-09 16:10:16 --> Output Class Initialized
INFO - 2024-10-09 16:10:16 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:16 --> Input Class Initialized
INFO - 2024-10-09 16:10:16 --> Language Class Initialized
INFO - 2024-10-09 16:10:16 --> Language Class Initialized
INFO - 2024-10-09 16:10:16 --> Config Class Initialized
INFO - 2024-10-09 16:10:16 --> Loader Class Initialized
INFO - 2024-10-09 16:10:16 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:16 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:16 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:16 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:16 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:16 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:16 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:16 --> Total execution time: 0.0746
INFO - 2024-10-09 16:10:18 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:18 --> Total execution time: 3.0739
INFO - 2024-10-09 16:10:23 --> Config Class Initialized
INFO - 2024-10-09 16:10:23 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:23 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:23 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:23 --> URI Class Initialized
INFO - 2024-10-09 16:10:23 --> Router Class Initialized
INFO - 2024-10-09 16:10:23 --> Output Class Initialized
INFO - 2024-10-09 16:10:23 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:23 --> Input Class Initialized
INFO - 2024-10-09 16:10:23 --> Language Class Initialized
INFO - 2024-10-09 16:10:23 --> Language Class Initialized
INFO - 2024-10-09 16:10:23 --> Config Class Initialized
INFO - 2024-10-09 16:10:23 --> Loader Class Initialized
INFO - 2024-10-09 16:10:23 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:23 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:23 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:23 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:23 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:23 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 16:10:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:23 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:23 --> Total execution time: 0.0434
INFO - 2024-10-09 16:10:23 --> Config Class Initialized
INFO - 2024-10-09 16:10:23 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:23 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:23 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:23 --> URI Class Initialized
INFO - 2024-10-09 16:10:23 --> Router Class Initialized
INFO - 2024-10-09 16:10:23 --> Output Class Initialized
INFO - 2024-10-09 16:10:23 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:23 --> Input Class Initialized
INFO - 2024-10-09 16:10:23 --> Language Class Initialized
INFO - 2024-10-09 16:10:23 --> Language Class Initialized
INFO - 2024-10-09 16:10:23 --> Config Class Initialized
INFO - 2024-10-09 16:10:23 --> Loader Class Initialized
INFO - 2024-10-09 16:10:23 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:23 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:23 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:23 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:23 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:23 --> Controller Class Initialized
INFO - 2024-10-09 16:10:27 --> Config Class Initialized
INFO - 2024-10-09 16:10:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:27 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:27 --> URI Class Initialized
INFO - 2024-10-09 16:10:27 --> Router Class Initialized
INFO - 2024-10-09 16:10:27 --> Output Class Initialized
INFO - 2024-10-09 16:10:27 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:27 --> Input Class Initialized
INFO - 2024-10-09 16:10:27 --> Language Class Initialized
INFO - 2024-10-09 16:10:27 --> Language Class Initialized
INFO - 2024-10-09 16:10:27 --> Config Class Initialized
INFO - 2024-10-09 16:10:27 --> Loader Class Initialized
INFO - 2024-10-09 16:10:27 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:27 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:27 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:27 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:27 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:27 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:27 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:27 --> Total execution time: 0.0618
INFO - 2024-10-09 16:10:36 --> Config Class Initialized
INFO - 2024-10-09 16:10:36 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:36 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:36 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:36 --> URI Class Initialized
INFO - 2024-10-09 16:10:36 --> Router Class Initialized
INFO - 2024-10-09 16:10:36 --> Output Class Initialized
INFO - 2024-10-09 16:10:36 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:36 --> Input Class Initialized
INFO - 2024-10-09 16:10:36 --> Language Class Initialized
INFO - 2024-10-09 16:10:36 --> Language Class Initialized
INFO - 2024-10-09 16:10:36 --> Config Class Initialized
INFO - 2024-10-09 16:10:36 --> Loader Class Initialized
INFO - 2024-10-09 16:10:36 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:36 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:36 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:36 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:36 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:36 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:10:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:36 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:36 --> Total execution time: 0.0337
INFO - 2024-10-09 16:10:48 --> Config Class Initialized
INFO - 2024-10-09 16:10:48 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:48 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:48 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:48 --> URI Class Initialized
INFO - 2024-10-09 16:10:48 --> Router Class Initialized
INFO - 2024-10-09 16:10:48 --> Output Class Initialized
INFO - 2024-10-09 16:10:48 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:48 --> Input Class Initialized
INFO - 2024-10-09 16:10:48 --> Language Class Initialized
INFO - 2024-10-09 16:10:48 --> Language Class Initialized
INFO - 2024-10-09 16:10:48 --> Config Class Initialized
INFO - 2024-10-09 16:10:48 --> Loader Class Initialized
INFO - 2024-10-09 16:10:48 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:48 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:48 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:48 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:48 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:48 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 16:10:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:48 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:48 --> Total execution time: 0.0398
INFO - 2024-10-09 16:10:48 --> Config Class Initialized
INFO - 2024-10-09 16:10:48 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:48 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:48 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:48 --> URI Class Initialized
INFO - 2024-10-09 16:10:48 --> Router Class Initialized
INFO - 2024-10-09 16:10:48 --> Output Class Initialized
INFO - 2024-10-09 16:10:48 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:48 --> Input Class Initialized
INFO - 2024-10-09 16:10:48 --> Language Class Initialized
INFO - 2024-10-09 16:10:48 --> Language Class Initialized
INFO - 2024-10-09 16:10:48 --> Config Class Initialized
INFO - 2024-10-09 16:10:48 --> Loader Class Initialized
INFO - 2024-10-09 16:10:48 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:48 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:48 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:48 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:48 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:48 --> Controller Class Initialized
INFO - 2024-10-09 16:10:51 --> Config Class Initialized
INFO - 2024-10-09 16:10:51 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:51 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:51 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:51 --> URI Class Initialized
INFO - 2024-10-09 16:10:51 --> Router Class Initialized
INFO - 2024-10-09 16:10:51 --> Output Class Initialized
INFO - 2024-10-09 16:10:51 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:51 --> Input Class Initialized
INFO - 2024-10-09 16:10:51 --> Language Class Initialized
INFO - 2024-10-09 16:10:51 --> Language Class Initialized
INFO - 2024-10-09 16:10:51 --> Config Class Initialized
INFO - 2024-10-09 16:10:51 --> Loader Class Initialized
INFO - 2024-10-09 16:10:51 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:51 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:51 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:51 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:51 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:51 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:10:53 --> Config Class Initialized
INFO - 2024-10-09 16:10:53 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:53 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:53 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:53 --> URI Class Initialized
INFO - 2024-10-09 16:10:53 --> Router Class Initialized
INFO - 2024-10-09 16:10:53 --> Output Class Initialized
INFO - 2024-10-09 16:10:53 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:53 --> Input Class Initialized
INFO - 2024-10-09 16:10:53 --> Language Class Initialized
INFO - 2024-10-09 16:10:53 --> Language Class Initialized
INFO - 2024-10-09 16:10:53 --> Config Class Initialized
INFO - 2024-10-09 16:10:53 --> Loader Class Initialized
INFO - 2024-10-09 16:10:53 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:53 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:53 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:53 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:53 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:53 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:10:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:53 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:53 --> Total execution time: 0.0886
INFO - 2024-10-09 16:10:54 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:54 --> Total execution time: 3.2396
INFO - 2024-10-09 16:10:55 --> Config Class Initialized
INFO - 2024-10-09 16:10:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:55 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:55 --> URI Class Initialized
INFO - 2024-10-09 16:10:55 --> Router Class Initialized
INFO - 2024-10-09 16:10:55 --> Output Class Initialized
INFO - 2024-10-09 16:10:55 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:55 --> Input Class Initialized
INFO - 2024-10-09 16:10:55 --> Language Class Initialized
INFO - 2024-10-09 16:10:55 --> Language Class Initialized
INFO - 2024-10-09 16:10:55 --> Config Class Initialized
INFO - 2024-10-09 16:10:55 --> Loader Class Initialized
INFO - 2024-10-09 16:10:55 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:55 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:55 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:55 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:55 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:55 --> Controller Class Initialized
DEBUG - 2024-10-09 16:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 16:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:10:55 --> Final output sent to browser
DEBUG - 2024-10-09 16:10:55 --> Total execution time: 0.0366
INFO - 2024-10-09 16:10:55 --> Config Class Initialized
INFO - 2024-10-09 16:10:55 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:10:55 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:10:55 --> Utf8 Class Initialized
INFO - 2024-10-09 16:10:55 --> URI Class Initialized
INFO - 2024-10-09 16:10:55 --> Router Class Initialized
INFO - 2024-10-09 16:10:55 --> Output Class Initialized
INFO - 2024-10-09 16:10:55 --> Security Class Initialized
DEBUG - 2024-10-09 16:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:10:55 --> Input Class Initialized
INFO - 2024-10-09 16:10:55 --> Language Class Initialized
INFO - 2024-10-09 16:10:55 --> Language Class Initialized
INFO - 2024-10-09 16:10:55 --> Config Class Initialized
INFO - 2024-10-09 16:10:55 --> Loader Class Initialized
INFO - 2024-10-09 16:10:55 --> Helper loaded: url_helper
INFO - 2024-10-09 16:10:55 --> Helper loaded: file_helper
INFO - 2024-10-09 16:10:55 --> Helper loaded: form_helper
INFO - 2024-10-09 16:10:55 --> Helper loaded: my_helper
INFO - 2024-10-09 16:10:55 --> Database Driver Class Initialized
INFO - 2024-10-09 16:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:10:55 --> Controller Class Initialized
INFO - 2024-10-09 16:11:00 --> Config Class Initialized
INFO - 2024-10-09 16:11:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:11:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:11:00 --> Utf8 Class Initialized
INFO - 2024-10-09 16:11:00 --> URI Class Initialized
INFO - 2024-10-09 16:11:00 --> Router Class Initialized
INFO - 2024-10-09 16:11:00 --> Output Class Initialized
INFO - 2024-10-09 16:11:00 --> Security Class Initialized
DEBUG - 2024-10-09 16:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:11:00 --> Input Class Initialized
INFO - 2024-10-09 16:11:00 --> Language Class Initialized
INFO - 2024-10-09 16:11:00 --> Language Class Initialized
INFO - 2024-10-09 16:11:00 --> Config Class Initialized
INFO - 2024-10-09 16:11:00 --> Loader Class Initialized
INFO - 2024-10-09 16:11:00 --> Helper loaded: url_helper
INFO - 2024-10-09 16:11:00 --> Helper loaded: file_helper
INFO - 2024-10-09 16:11:00 --> Helper loaded: form_helper
INFO - 2024-10-09 16:11:00 --> Helper loaded: my_helper
INFO - 2024-10-09 16:11:00 --> Database Driver Class Initialized
INFO - 2024-10-09 16:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:11:00 --> Controller Class Initialized
INFO - 2024-10-09 16:11:00 --> Final output sent to browser
DEBUG - 2024-10-09 16:11:00 --> Total execution time: 0.0369
INFO - 2024-10-09 16:11:15 --> Config Class Initialized
INFO - 2024-10-09 16:11:15 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:11:15 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:11:15 --> Utf8 Class Initialized
INFO - 2024-10-09 16:11:15 --> URI Class Initialized
INFO - 2024-10-09 16:11:15 --> Router Class Initialized
INFO - 2024-10-09 16:11:15 --> Output Class Initialized
INFO - 2024-10-09 16:11:15 --> Security Class Initialized
DEBUG - 2024-10-09 16:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:11:15 --> Input Class Initialized
INFO - 2024-10-09 16:11:15 --> Language Class Initialized
INFO - 2024-10-09 16:11:15 --> Language Class Initialized
INFO - 2024-10-09 16:11:15 --> Config Class Initialized
INFO - 2024-10-09 16:11:15 --> Loader Class Initialized
INFO - 2024-10-09 16:11:15 --> Helper loaded: url_helper
INFO - 2024-10-09 16:11:15 --> Helper loaded: file_helper
INFO - 2024-10-09 16:11:15 --> Helper loaded: form_helper
INFO - 2024-10-09 16:11:15 --> Helper loaded: my_helper
INFO - 2024-10-09 16:11:15 --> Database Driver Class Initialized
INFO - 2024-10-09 16:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:11:15 --> Controller Class Initialized
INFO - 2024-10-09 16:11:15 --> Final output sent to browser
DEBUG - 2024-10-09 16:11:15 --> Total execution time: 0.0322
INFO - 2024-10-09 16:12:18 --> Config Class Initialized
INFO - 2024-10-09 16:12:18 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:18 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:18 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:18 --> URI Class Initialized
INFO - 2024-10-09 16:12:18 --> Router Class Initialized
INFO - 2024-10-09 16:12:18 --> Output Class Initialized
INFO - 2024-10-09 16:12:18 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:18 --> Input Class Initialized
INFO - 2024-10-09 16:12:18 --> Language Class Initialized
INFO - 2024-10-09 16:12:18 --> Language Class Initialized
INFO - 2024-10-09 16:12:18 --> Config Class Initialized
INFO - 2024-10-09 16:12:18 --> Loader Class Initialized
INFO - 2024-10-09 16:12:18 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:18 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:18 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:18 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:18 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:18 --> Controller Class Initialized
INFO - 2024-10-09 16:12:18 --> Final output sent to browser
DEBUG - 2024-10-09 16:12:18 --> Total execution time: 0.0546
INFO - 2024-10-09 16:12:18 --> Config Class Initialized
INFO - 2024-10-09 16:12:18 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:18 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:18 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:18 --> URI Class Initialized
INFO - 2024-10-09 16:12:18 --> Router Class Initialized
INFO - 2024-10-09 16:12:18 --> Output Class Initialized
INFO - 2024-10-09 16:12:18 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:18 --> Input Class Initialized
INFO - 2024-10-09 16:12:18 --> Language Class Initialized
INFO - 2024-10-09 16:12:18 --> Language Class Initialized
INFO - 2024-10-09 16:12:18 --> Config Class Initialized
INFO - 2024-10-09 16:12:18 --> Loader Class Initialized
INFO - 2024-10-09 16:12:18 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:18 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:18 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:18 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:18 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:18 --> Controller Class Initialized
INFO - 2024-10-09 16:12:27 --> Config Class Initialized
INFO - 2024-10-09 16:12:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:27 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:27 --> URI Class Initialized
INFO - 2024-10-09 16:12:27 --> Router Class Initialized
INFO - 2024-10-09 16:12:27 --> Output Class Initialized
INFO - 2024-10-09 16:12:27 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:27 --> Input Class Initialized
INFO - 2024-10-09 16:12:27 --> Language Class Initialized
INFO - 2024-10-09 16:12:27 --> Language Class Initialized
INFO - 2024-10-09 16:12:27 --> Config Class Initialized
INFO - 2024-10-09 16:12:27 --> Loader Class Initialized
INFO - 2024-10-09 16:12:27 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:27 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:27 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:27 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:27 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:27 --> Controller Class Initialized
INFO - 2024-10-09 16:12:27 --> Final output sent to browser
DEBUG - 2024-10-09 16:12:27 --> Total execution time: 0.0334
INFO - 2024-10-09 16:12:28 --> Config Class Initialized
INFO - 2024-10-09 16:12:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:28 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:28 --> URI Class Initialized
INFO - 2024-10-09 16:12:28 --> Router Class Initialized
INFO - 2024-10-09 16:12:28 --> Output Class Initialized
INFO - 2024-10-09 16:12:28 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:28 --> Input Class Initialized
INFO - 2024-10-09 16:12:28 --> Language Class Initialized
INFO - 2024-10-09 16:12:28 --> Language Class Initialized
INFO - 2024-10-09 16:12:28 --> Config Class Initialized
INFO - 2024-10-09 16:12:28 --> Loader Class Initialized
INFO - 2024-10-09 16:12:28 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:28 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:28 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:28 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:28 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:28 --> Controller Class Initialized
INFO - 2024-10-09 16:12:28 --> Final output sent to browser
DEBUG - 2024-10-09 16:12:28 --> Total execution time: 0.0343
INFO - 2024-10-09 16:12:28 --> Config Class Initialized
INFO - 2024-10-09 16:12:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:28 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:28 --> URI Class Initialized
INFO - 2024-10-09 16:12:28 --> Router Class Initialized
INFO - 2024-10-09 16:12:28 --> Output Class Initialized
INFO - 2024-10-09 16:12:28 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:28 --> Input Class Initialized
INFO - 2024-10-09 16:12:28 --> Language Class Initialized
INFO - 2024-10-09 16:12:28 --> Language Class Initialized
INFO - 2024-10-09 16:12:28 --> Config Class Initialized
INFO - 2024-10-09 16:12:28 --> Loader Class Initialized
INFO - 2024-10-09 16:12:28 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:28 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:28 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:28 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:28 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:28 --> Controller Class Initialized
INFO - 2024-10-09 16:12:31 --> Config Class Initialized
INFO - 2024-10-09 16:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:31 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:31 --> URI Class Initialized
INFO - 2024-10-09 16:12:31 --> Router Class Initialized
INFO - 2024-10-09 16:12:31 --> Output Class Initialized
INFO - 2024-10-09 16:12:31 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:31 --> Input Class Initialized
INFO - 2024-10-09 16:12:31 --> Language Class Initialized
INFO - 2024-10-09 16:12:31 --> Language Class Initialized
INFO - 2024-10-09 16:12:31 --> Config Class Initialized
INFO - 2024-10-09 16:12:31 --> Loader Class Initialized
INFO - 2024-10-09 16:12:31 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:31 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:31 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:31 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:31 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:31 --> Controller Class Initialized
INFO - 2024-10-09 16:12:31 --> Final output sent to browser
DEBUG - 2024-10-09 16:12:31 --> Total execution time: 0.0320
INFO - 2024-10-09 16:12:31 --> Config Class Initialized
INFO - 2024-10-09 16:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:31 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:31 --> URI Class Initialized
INFO - 2024-10-09 16:12:31 --> Router Class Initialized
INFO - 2024-10-09 16:12:31 --> Output Class Initialized
INFO - 2024-10-09 16:12:31 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:31 --> Input Class Initialized
INFO - 2024-10-09 16:12:31 --> Language Class Initialized
INFO - 2024-10-09 16:12:31 --> Language Class Initialized
INFO - 2024-10-09 16:12:31 --> Config Class Initialized
INFO - 2024-10-09 16:12:31 --> Loader Class Initialized
INFO - 2024-10-09 16:12:31 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:31 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:31 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:31 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:32 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:32 --> Controller Class Initialized
DEBUG - 2024-10-09 16:12:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:12:34 --> Final output sent to browser
DEBUG - 2024-10-09 16:12:34 --> Total execution time: 2.9005
INFO - 2024-10-09 16:12:44 --> Config Class Initialized
INFO - 2024-10-09 16:12:44 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:44 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:44 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:44 --> URI Class Initialized
INFO - 2024-10-09 16:12:44 --> Router Class Initialized
INFO - 2024-10-09 16:12:44 --> Output Class Initialized
INFO - 2024-10-09 16:12:44 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:44 --> Input Class Initialized
INFO - 2024-10-09 16:12:44 --> Language Class Initialized
INFO - 2024-10-09 16:12:44 --> Language Class Initialized
INFO - 2024-10-09 16:12:44 --> Config Class Initialized
INFO - 2024-10-09 16:12:44 --> Loader Class Initialized
INFO - 2024-10-09 16:12:44 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:44 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:44 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:44 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:44 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:44 --> Controller Class Initialized
DEBUG - 2024-10-09 16:12:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:12:46 --> Final output sent to browser
DEBUG - 2024-10-09 16:12:46 --> Total execution time: 2.8600
INFO - 2024-10-09 16:12:58 --> Config Class Initialized
INFO - 2024-10-09 16:12:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:12:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:12:58 --> Utf8 Class Initialized
INFO - 2024-10-09 16:12:58 --> URI Class Initialized
INFO - 2024-10-09 16:12:58 --> Router Class Initialized
INFO - 2024-10-09 16:12:58 --> Output Class Initialized
INFO - 2024-10-09 16:12:58 --> Security Class Initialized
DEBUG - 2024-10-09 16:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:12:58 --> Input Class Initialized
INFO - 2024-10-09 16:12:58 --> Language Class Initialized
INFO - 2024-10-09 16:12:58 --> Language Class Initialized
INFO - 2024-10-09 16:12:58 --> Config Class Initialized
INFO - 2024-10-09 16:12:58 --> Loader Class Initialized
INFO - 2024-10-09 16:12:58 --> Helper loaded: url_helper
INFO - 2024-10-09 16:12:58 --> Helper loaded: file_helper
INFO - 2024-10-09 16:12:58 --> Helper loaded: form_helper
INFO - 2024-10-09 16:12:58 --> Helper loaded: my_helper
INFO - 2024-10-09 16:12:58 --> Database Driver Class Initialized
INFO - 2024-10-09 16:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:12:58 --> Controller Class Initialized
DEBUG - 2024-10-09 16:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:13:01 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:01 --> Total execution time: 3.5961
INFO - 2024-10-09 16:13:04 --> Config Class Initialized
INFO - 2024-10-09 16:13:04 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:04 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:04 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:04 --> URI Class Initialized
INFO - 2024-10-09 16:13:04 --> Router Class Initialized
INFO - 2024-10-09 16:13:04 --> Output Class Initialized
INFO - 2024-10-09 16:13:04 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:04 --> Input Class Initialized
INFO - 2024-10-09 16:13:04 --> Language Class Initialized
INFO - 2024-10-09 16:13:04 --> Language Class Initialized
INFO - 2024-10-09 16:13:04 --> Config Class Initialized
INFO - 2024-10-09 16:13:04 --> Loader Class Initialized
INFO - 2024-10-09 16:13:04 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:04 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:04 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:04 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:04 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:04 --> Controller Class Initialized
DEBUG - 2024-10-09 16:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:13:07 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:07 --> Total execution time: 2.8336
INFO - 2024-10-09 16:13:28 --> Config Class Initialized
INFO - 2024-10-09 16:13:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:28 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:28 --> URI Class Initialized
INFO - 2024-10-09 16:13:28 --> Router Class Initialized
INFO - 2024-10-09 16:13:28 --> Output Class Initialized
INFO - 2024-10-09 16:13:28 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:28 --> Input Class Initialized
INFO - 2024-10-09 16:13:28 --> Language Class Initialized
INFO - 2024-10-09 16:13:28 --> Language Class Initialized
INFO - 2024-10-09 16:13:28 --> Config Class Initialized
INFO - 2024-10-09 16:13:28 --> Loader Class Initialized
INFO - 2024-10-09 16:13:28 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:28 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:28 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:28 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:28 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:28 --> Controller Class Initialized
DEBUG - 2024-10-09 16:13:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:13:32 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:32 --> Total execution time: 3.6722
INFO - 2024-10-09 16:13:37 --> Config Class Initialized
INFO - 2024-10-09 16:13:37 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:37 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:37 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:37 --> URI Class Initialized
INFO - 2024-10-09 16:13:37 --> Router Class Initialized
INFO - 2024-10-09 16:13:37 --> Output Class Initialized
INFO - 2024-10-09 16:13:37 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:37 --> Input Class Initialized
INFO - 2024-10-09 16:13:37 --> Language Class Initialized
INFO - 2024-10-09 16:13:37 --> Language Class Initialized
INFO - 2024-10-09 16:13:37 --> Config Class Initialized
INFO - 2024-10-09 16:13:37 --> Loader Class Initialized
INFO - 2024-10-09 16:13:37 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:37 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:37 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:37 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:37 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:37 --> Controller Class Initialized
INFO - 2024-10-09 16:13:37 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:37 --> Total execution time: 0.0402
INFO - 2024-10-09 16:13:38 --> Config Class Initialized
INFO - 2024-10-09 16:13:38 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:38 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:38 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:38 --> URI Class Initialized
INFO - 2024-10-09 16:13:38 --> Router Class Initialized
INFO - 2024-10-09 16:13:38 --> Output Class Initialized
INFO - 2024-10-09 16:13:38 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:38 --> Input Class Initialized
INFO - 2024-10-09 16:13:38 --> Language Class Initialized
INFO - 2024-10-09 16:13:38 --> Language Class Initialized
INFO - 2024-10-09 16:13:38 --> Config Class Initialized
INFO - 2024-10-09 16:13:38 --> Loader Class Initialized
INFO - 2024-10-09 16:13:38 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:38 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:38 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:38 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:38 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:38 --> Controller Class Initialized
INFO - 2024-10-09 16:13:38 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:38 --> Total execution time: 0.0391
INFO - 2024-10-09 16:13:47 --> Config Class Initialized
INFO - 2024-10-09 16:13:47 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:47 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:47 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:47 --> URI Class Initialized
INFO - 2024-10-09 16:13:47 --> Router Class Initialized
INFO - 2024-10-09 16:13:47 --> Output Class Initialized
INFO - 2024-10-09 16:13:47 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:47 --> Input Class Initialized
INFO - 2024-10-09 16:13:47 --> Language Class Initialized
INFO - 2024-10-09 16:13:47 --> Language Class Initialized
INFO - 2024-10-09 16:13:47 --> Config Class Initialized
INFO - 2024-10-09 16:13:47 --> Loader Class Initialized
INFO - 2024-10-09 16:13:47 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:47 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:47 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:47 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:47 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:47 --> Controller Class Initialized
INFO - 2024-10-09 16:13:47 --> Config Class Initialized
INFO - 2024-10-09 16:13:47 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:47 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:47 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:47 --> URI Class Initialized
INFO - 2024-10-09 16:13:47 --> Router Class Initialized
DEBUG - 2024-10-09 16:13:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:13:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:13:47 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:47 --> Total execution time: 0.0937
INFO - 2024-10-09 16:13:47 --> Output Class Initialized
INFO - 2024-10-09 16:13:47 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:47 --> Input Class Initialized
INFO - 2024-10-09 16:13:47 --> Language Class Initialized
INFO - 2024-10-09 16:13:47 --> Language Class Initialized
INFO - 2024-10-09 16:13:47 --> Config Class Initialized
INFO - 2024-10-09 16:13:47 --> Loader Class Initialized
INFO - 2024-10-09 16:13:47 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:47 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:47 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:47 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:47 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:47 --> Controller Class Initialized
DEBUG - 2024-10-09 16:13:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:13:50 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:50 --> Total execution time: 3.3232
INFO - 2024-10-09 16:13:54 --> Config Class Initialized
INFO - 2024-10-09 16:13:54 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:54 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:54 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:54 --> URI Class Initialized
INFO - 2024-10-09 16:13:54 --> Router Class Initialized
INFO - 2024-10-09 16:13:54 --> Output Class Initialized
INFO - 2024-10-09 16:13:54 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:54 --> Input Class Initialized
INFO - 2024-10-09 16:13:54 --> Language Class Initialized
INFO - 2024-10-09 16:13:54 --> Language Class Initialized
INFO - 2024-10-09 16:13:54 --> Config Class Initialized
INFO - 2024-10-09 16:13:54 --> Loader Class Initialized
INFO - 2024-10-09 16:13:54 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:54 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:54 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:54 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:54 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:54 --> Controller Class Initialized
DEBUG - 2024-10-09 16:13:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-09 16:13:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:13:54 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:54 --> Total execution time: 0.0345
INFO - 2024-10-09 16:13:54 --> Config Class Initialized
INFO - 2024-10-09 16:13:54 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:54 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:54 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:54 --> URI Class Initialized
INFO - 2024-10-09 16:13:54 --> Router Class Initialized
INFO - 2024-10-09 16:13:54 --> Output Class Initialized
INFO - 2024-10-09 16:13:54 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:54 --> Input Class Initialized
INFO - 2024-10-09 16:13:54 --> Language Class Initialized
INFO - 2024-10-09 16:13:54 --> Language Class Initialized
INFO - 2024-10-09 16:13:54 --> Config Class Initialized
INFO - 2024-10-09 16:13:54 --> Loader Class Initialized
INFO - 2024-10-09 16:13:54 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:54 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:54 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:54 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:54 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:54 --> Controller Class Initialized
INFO - 2024-10-09 16:13:58 --> Config Class Initialized
INFO - 2024-10-09 16:13:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:13:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:13:58 --> Utf8 Class Initialized
INFO - 2024-10-09 16:13:58 --> URI Class Initialized
INFO - 2024-10-09 16:13:58 --> Router Class Initialized
INFO - 2024-10-09 16:13:58 --> Output Class Initialized
INFO - 2024-10-09 16:13:58 --> Security Class Initialized
DEBUG - 2024-10-09 16:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:13:58 --> Input Class Initialized
INFO - 2024-10-09 16:13:58 --> Language Class Initialized
INFO - 2024-10-09 16:13:58 --> Language Class Initialized
INFO - 2024-10-09 16:13:58 --> Config Class Initialized
INFO - 2024-10-09 16:13:58 --> Loader Class Initialized
INFO - 2024-10-09 16:13:58 --> Helper loaded: url_helper
INFO - 2024-10-09 16:13:58 --> Helper loaded: file_helper
INFO - 2024-10-09 16:13:58 --> Helper loaded: form_helper
INFO - 2024-10-09 16:13:58 --> Helper loaded: my_helper
INFO - 2024-10-09 16:13:58 --> Database Driver Class Initialized
INFO - 2024-10-09 16:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:13:58 --> Controller Class Initialized
INFO - 2024-10-09 16:13:58 --> Final output sent to browser
DEBUG - 2024-10-09 16:13:58 --> Total execution time: 0.0345
INFO - 2024-10-09 16:14:00 --> Config Class Initialized
INFO - 2024-10-09 16:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:14:00 --> Utf8 Class Initialized
INFO - 2024-10-09 16:14:00 --> URI Class Initialized
INFO - 2024-10-09 16:14:00 --> Router Class Initialized
INFO - 2024-10-09 16:14:00 --> Output Class Initialized
INFO - 2024-10-09 16:14:00 --> Security Class Initialized
DEBUG - 2024-10-09 16:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:14:00 --> Input Class Initialized
INFO - 2024-10-09 16:14:00 --> Language Class Initialized
INFO - 2024-10-09 16:14:00 --> Language Class Initialized
INFO - 2024-10-09 16:14:00 --> Config Class Initialized
INFO - 2024-10-09 16:14:00 --> Loader Class Initialized
INFO - 2024-10-09 16:14:00 --> Helper loaded: url_helper
INFO - 2024-10-09 16:14:00 --> Helper loaded: file_helper
INFO - 2024-10-09 16:14:00 --> Helper loaded: form_helper
INFO - 2024-10-09 16:14:00 --> Helper loaded: my_helper
INFO - 2024-10-09 16:14:00 --> Database Driver Class Initialized
INFO - 2024-10-09 16:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:14:00 --> Controller Class Initialized
INFO - 2024-10-09 16:14:00 --> Final output sent to browser
DEBUG - 2024-10-09 16:14:00 --> Total execution time: 0.1755
INFO - 2024-10-09 16:14:02 --> Config Class Initialized
INFO - 2024-10-09 16:14:02 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:14:02 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:14:02 --> Utf8 Class Initialized
INFO - 2024-10-09 16:14:02 --> URI Class Initialized
INFO - 2024-10-09 16:14:02 --> Router Class Initialized
INFO - 2024-10-09 16:14:02 --> Output Class Initialized
INFO - 2024-10-09 16:14:02 --> Security Class Initialized
DEBUG - 2024-10-09 16:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:14:02 --> Input Class Initialized
INFO - 2024-10-09 16:14:02 --> Language Class Initialized
INFO - 2024-10-09 16:14:02 --> Language Class Initialized
INFO - 2024-10-09 16:14:02 --> Config Class Initialized
INFO - 2024-10-09 16:14:02 --> Loader Class Initialized
INFO - 2024-10-09 16:14:02 --> Helper loaded: url_helper
INFO - 2024-10-09 16:14:02 --> Helper loaded: file_helper
INFO - 2024-10-09 16:14:02 --> Helper loaded: form_helper
INFO - 2024-10-09 16:14:02 --> Helper loaded: my_helper
INFO - 2024-10-09 16:14:02 --> Database Driver Class Initialized
INFO - 2024-10-09 16:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:14:02 --> Controller Class Initialized
DEBUG - 2024-10-09 16:14:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-09 16:14:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 16:14:02 --> Final output sent to browser
DEBUG - 2024-10-09 16:14:02 --> Total execution time: 0.0354
INFO - 2024-10-09 16:14:54 --> Config Class Initialized
INFO - 2024-10-09 16:14:54 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:14:54 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:14:54 --> Utf8 Class Initialized
INFO - 2024-10-09 16:14:54 --> URI Class Initialized
INFO - 2024-10-09 16:14:54 --> Router Class Initialized
INFO - 2024-10-09 16:14:54 --> Output Class Initialized
INFO - 2024-10-09 16:14:54 --> Security Class Initialized
DEBUG - 2024-10-09 16:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:14:54 --> Input Class Initialized
INFO - 2024-10-09 16:14:54 --> Language Class Initialized
INFO - 2024-10-09 16:14:54 --> Language Class Initialized
INFO - 2024-10-09 16:14:54 --> Config Class Initialized
INFO - 2024-10-09 16:14:54 --> Loader Class Initialized
INFO - 2024-10-09 16:14:54 --> Helper loaded: url_helper
INFO - 2024-10-09 16:14:54 --> Helper loaded: file_helper
INFO - 2024-10-09 16:14:54 --> Helper loaded: form_helper
INFO - 2024-10-09 16:14:54 --> Helper loaded: my_helper
INFO - 2024-10-09 16:14:54 --> Database Driver Class Initialized
INFO - 2024-10-09 16:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:14:54 --> Controller Class Initialized
DEBUG - 2024-10-09 16:14:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:14:57 --> Final output sent to browser
DEBUG - 2024-10-09 16:14:57 --> Total execution time: 3.2988
INFO - 2024-10-09 16:15:27 --> Config Class Initialized
INFO - 2024-10-09 16:15:27 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:15:27 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:15:27 --> Utf8 Class Initialized
INFO - 2024-10-09 16:15:27 --> URI Class Initialized
INFO - 2024-10-09 16:15:27 --> Router Class Initialized
INFO - 2024-10-09 16:15:27 --> Output Class Initialized
INFO - 2024-10-09 16:15:27 --> Security Class Initialized
DEBUG - 2024-10-09 16:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:15:27 --> Input Class Initialized
INFO - 2024-10-09 16:15:27 --> Language Class Initialized
INFO - 2024-10-09 16:15:27 --> Language Class Initialized
INFO - 2024-10-09 16:15:27 --> Config Class Initialized
INFO - 2024-10-09 16:15:27 --> Loader Class Initialized
INFO - 2024-10-09 16:15:27 --> Helper loaded: url_helper
INFO - 2024-10-09 16:15:27 --> Helper loaded: file_helper
INFO - 2024-10-09 16:15:27 --> Helper loaded: form_helper
INFO - 2024-10-09 16:15:27 --> Helper loaded: my_helper
INFO - 2024-10-09 16:15:27 --> Database Driver Class Initialized
INFO - 2024-10-09 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:15:28 --> Controller Class Initialized
DEBUG - 2024-10-09 16:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:15:31 --> Final output sent to browser
DEBUG - 2024-10-09 16:15:31 --> Total execution time: 3.0457
INFO - 2024-10-09 16:15:39 --> Config Class Initialized
INFO - 2024-10-09 16:15:39 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:15:39 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:15:39 --> Utf8 Class Initialized
INFO - 2024-10-09 16:15:39 --> URI Class Initialized
INFO - 2024-10-09 16:15:39 --> Router Class Initialized
INFO - 2024-10-09 16:15:39 --> Output Class Initialized
INFO - 2024-10-09 16:15:39 --> Security Class Initialized
DEBUG - 2024-10-09 16:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:15:39 --> Input Class Initialized
INFO - 2024-10-09 16:15:39 --> Language Class Initialized
INFO - 2024-10-09 16:15:39 --> Language Class Initialized
INFO - 2024-10-09 16:15:39 --> Config Class Initialized
INFO - 2024-10-09 16:15:39 --> Loader Class Initialized
INFO - 2024-10-09 16:15:39 --> Helper loaded: url_helper
INFO - 2024-10-09 16:15:39 --> Helper loaded: file_helper
INFO - 2024-10-09 16:15:39 --> Helper loaded: form_helper
INFO - 2024-10-09 16:15:39 --> Helper loaded: my_helper
INFO - 2024-10-09 16:15:39 --> Database Driver Class Initialized
INFO - 2024-10-09 16:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:15:39 --> Controller Class Initialized
DEBUG - 2024-10-09 16:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:15:42 --> Final output sent to browser
DEBUG - 2024-10-09 16:15:42 --> Total execution time: 2.9156
INFO - 2024-10-09 16:15:43 --> Config Class Initialized
INFO - 2024-10-09 16:15:43 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:15:43 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:15:43 --> Utf8 Class Initialized
INFO - 2024-10-09 16:15:43 --> URI Class Initialized
INFO - 2024-10-09 16:15:43 --> Router Class Initialized
INFO - 2024-10-09 16:15:43 --> Output Class Initialized
INFO - 2024-10-09 16:15:43 --> Security Class Initialized
DEBUG - 2024-10-09 16:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:15:43 --> Input Class Initialized
INFO - 2024-10-09 16:15:43 --> Language Class Initialized
INFO - 2024-10-09 16:15:43 --> Language Class Initialized
INFO - 2024-10-09 16:15:43 --> Config Class Initialized
INFO - 2024-10-09 16:15:43 --> Loader Class Initialized
INFO - 2024-10-09 16:15:43 --> Helper loaded: url_helper
INFO - 2024-10-09 16:15:43 --> Helper loaded: file_helper
INFO - 2024-10-09 16:15:43 --> Helper loaded: form_helper
INFO - 2024-10-09 16:15:43 --> Helper loaded: my_helper
INFO - 2024-10-09 16:15:43 --> Database Driver Class Initialized
INFO - 2024-10-09 16:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:15:43 --> Controller Class Initialized
DEBUG - 2024-10-09 16:15:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:15:46 --> Final output sent to browser
DEBUG - 2024-10-09 16:15:46 --> Total execution time: 2.7937
INFO - 2024-10-09 16:16:01 --> Config Class Initialized
INFO - 2024-10-09 16:16:01 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:16:01 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:16:01 --> Utf8 Class Initialized
INFO - 2024-10-09 16:16:01 --> URI Class Initialized
INFO - 2024-10-09 16:16:01 --> Router Class Initialized
INFO - 2024-10-09 16:16:01 --> Output Class Initialized
INFO - 2024-10-09 16:16:01 --> Security Class Initialized
DEBUG - 2024-10-09 16:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:16:01 --> Input Class Initialized
INFO - 2024-10-09 16:16:01 --> Language Class Initialized
INFO - 2024-10-09 16:16:01 --> Language Class Initialized
INFO - 2024-10-09 16:16:01 --> Config Class Initialized
INFO - 2024-10-09 16:16:01 --> Loader Class Initialized
INFO - 2024-10-09 16:16:01 --> Helper loaded: url_helper
INFO - 2024-10-09 16:16:01 --> Helper loaded: file_helper
INFO - 2024-10-09 16:16:01 --> Helper loaded: form_helper
INFO - 2024-10-09 16:16:01 --> Helper loaded: my_helper
INFO - 2024-10-09 16:16:01 --> Database Driver Class Initialized
INFO - 2024-10-09 16:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:16:01 --> Controller Class Initialized
DEBUG - 2024-10-09 16:16:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:16:04 --> Final output sent to browser
DEBUG - 2024-10-09 16:16:04 --> Total execution time: 3.5397
INFO - 2024-10-09 16:16:13 --> Config Class Initialized
INFO - 2024-10-09 16:16:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:16:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:16:13 --> Utf8 Class Initialized
INFO - 2024-10-09 16:16:13 --> URI Class Initialized
INFO - 2024-10-09 16:16:13 --> Router Class Initialized
INFO - 2024-10-09 16:16:13 --> Output Class Initialized
INFO - 2024-10-09 16:16:13 --> Security Class Initialized
DEBUG - 2024-10-09 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:16:13 --> Input Class Initialized
INFO - 2024-10-09 16:16:13 --> Language Class Initialized
INFO - 2024-10-09 16:16:13 --> Language Class Initialized
INFO - 2024-10-09 16:16:13 --> Config Class Initialized
INFO - 2024-10-09 16:16:13 --> Loader Class Initialized
INFO - 2024-10-09 16:16:13 --> Helper loaded: url_helper
INFO - 2024-10-09 16:16:13 --> Helper loaded: file_helper
INFO - 2024-10-09 16:16:13 --> Helper loaded: form_helper
INFO - 2024-10-09 16:16:13 --> Helper loaded: my_helper
INFO - 2024-10-09 16:16:13 --> Database Driver Class Initialized
INFO - 2024-10-09 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:16:13 --> Controller Class Initialized
DEBUG - 2024-10-09 16:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:16:16 --> Final output sent to browser
DEBUG - 2024-10-09 16:16:16 --> Total execution time: 3.3885
INFO - 2024-10-09 16:16:35 --> Config Class Initialized
INFO - 2024-10-09 16:16:35 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:16:35 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:16:35 --> Utf8 Class Initialized
INFO - 2024-10-09 16:16:35 --> URI Class Initialized
INFO - 2024-10-09 16:16:35 --> Router Class Initialized
INFO - 2024-10-09 16:16:35 --> Output Class Initialized
INFO - 2024-10-09 16:16:35 --> Security Class Initialized
DEBUG - 2024-10-09 16:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:16:35 --> Input Class Initialized
INFO - 2024-10-09 16:16:35 --> Language Class Initialized
INFO - 2024-10-09 16:16:35 --> Language Class Initialized
INFO - 2024-10-09 16:16:35 --> Config Class Initialized
INFO - 2024-10-09 16:16:35 --> Loader Class Initialized
INFO - 2024-10-09 16:16:35 --> Helper loaded: url_helper
INFO - 2024-10-09 16:16:35 --> Helper loaded: file_helper
INFO - 2024-10-09 16:16:35 --> Helper loaded: form_helper
INFO - 2024-10-09 16:16:35 --> Helper loaded: my_helper
INFO - 2024-10-09 16:16:35 --> Database Driver Class Initialized
INFO - 2024-10-09 16:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:16:35 --> Controller Class Initialized
DEBUG - 2024-10-09 16:16:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:16:38 --> Final output sent to browser
DEBUG - 2024-10-09 16:16:38 --> Total execution time: 2.8074
INFO - 2024-10-09 16:16:51 --> Config Class Initialized
INFO - 2024-10-09 16:16:51 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:16:51 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:16:51 --> Utf8 Class Initialized
INFO - 2024-10-09 16:16:51 --> URI Class Initialized
INFO - 2024-10-09 16:16:51 --> Router Class Initialized
INFO - 2024-10-09 16:16:51 --> Output Class Initialized
INFO - 2024-10-09 16:16:51 --> Security Class Initialized
DEBUG - 2024-10-09 16:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:16:51 --> Input Class Initialized
INFO - 2024-10-09 16:16:51 --> Language Class Initialized
INFO - 2024-10-09 16:16:51 --> Language Class Initialized
INFO - 2024-10-09 16:16:51 --> Config Class Initialized
INFO - 2024-10-09 16:16:51 --> Loader Class Initialized
INFO - 2024-10-09 16:16:51 --> Helper loaded: url_helper
INFO - 2024-10-09 16:16:51 --> Helper loaded: file_helper
INFO - 2024-10-09 16:16:51 --> Helper loaded: form_helper
INFO - 2024-10-09 16:16:51 --> Helper loaded: my_helper
INFO - 2024-10-09 16:16:51 --> Database Driver Class Initialized
INFO - 2024-10-09 16:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:16:51 --> Controller Class Initialized
DEBUG - 2024-10-09 16:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:16:54 --> Final output sent to browser
DEBUG - 2024-10-09 16:16:54 --> Total execution time: 3.0675
INFO - 2024-10-09 16:17:03 --> Config Class Initialized
INFO - 2024-10-09 16:17:03 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:17:03 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:17:03 --> Utf8 Class Initialized
INFO - 2024-10-09 16:17:03 --> URI Class Initialized
INFO - 2024-10-09 16:17:03 --> Router Class Initialized
INFO - 2024-10-09 16:17:03 --> Output Class Initialized
INFO - 2024-10-09 16:17:03 --> Security Class Initialized
DEBUG - 2024-10-09 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:17:03 --> Input Class Initialized
INFO - 2024-10-09 16:17:03 --> Language Class Initialized
INFO - 2024-10-09 16:17:03 --> Language Class Initialized
INFO - 2024-10-09 16:17:03 --> Config Class Initialized
INFO - 2024-10-09 16:17:03 --> Loader Class Initialized
INFO - 2024-10-09 16:17:03 --> Helper loaded: url_helper
INFO - 2024-10-09 16:17:03 --> Helper loaded: file_helper
INFO - 2024-10-09 16:17:03 --> Helper loaded: form_helper
INFO - 2024-10-09 16:17:03 --> Helper loaded: my_helper
INFO - 2024-10-09 16:17:03 --> Database Driver Class Initialized
INFO - 2024-10-09 16:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:17:03 --> Controller Class Initialized
DEBUG - 2024-10-09 16:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:17:06 --> Final output sent to browser
DEBUG - 2024-10-09 16:17:06 --> Total execution time: 3.2569
INFO - 2024-10-09 16:17:13 --> Config Class Initialized
INFO - 2024-10-09 16:17:13 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:17:13 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:17:13 --> Utf8 Class Initialized
INFO - 2024-10-09 16:17:13 --> URI Class Initialized
INFO - 2024-10-09 16:17:13 --> Router Class Initialized
INFO - 2024-10-09 16:17:13 --> Output Class Initialized
INFO - 2024-10-09 16:17:13 --> Security Class Initialized
DEBUG - 2024-10-09 16:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:17:13 --> Input Class Initialized
INFO - 2024-10-09 16:17:13 --> Language Class Initialized
INFO - 2024-10-09 16:17:13 --> Language Class Initialized
INFO - 2024-10-09 16:17:13 --> Config Class Initialized
INFO - 2024-10-09 16:17:13 --> Loader Class Initialized
INFO - 2024-10-09 16:17:13 --> Helper loaded: url_helper
INFO - 2024-10-09 16:17:13 --> Helper loaded: file_helper
INFO - 2024-10-09 16:17:13 --> Helper loaded: form_helper
INFO - 2024-10-09 16:17:13 --> Helper loaded: my_helper
INFO - 2024-10-09 16:17:13 --> Database Driver Class Initialized
INFO - 2024-10-09 16:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:17:13 --> Controller Class Initialized
DEBUG - 2024-10-09 16:17:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:17:17 --> Final output sent to browser
DEBUG - 2024-10-09 16:17:17 --> Total execution time: 3.7461
INFO - 2024-10-09 16:17:25 --> Config Class Initialized
INFO - 2024-10-09 16:17:25 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:17:25 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:17:25 --> Utf8 Class Initialized
INFO - 2024-10-09 16:17:25 --> URI Class Initialized
INFO - 2024-10-09 16:17:25 --> Router Class Initialized
INFO - 2024-10-09 16:17:25 --> Output Class Initialized
INFO - 2024-10-09 16:17:25 --> Security Class Initialized
DEBUG - 2024-10-09 16:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:17:25 --> Input Class Initialized
INFO - 2024-10-09 16:17:25 --> Language Class Initialized
INFO - 2024-10-09 16:17:25 --> Language Class Initialized
INFO - 2024-10-09 16:17:25 --> Config Class Initialized
INFO - 2024-10-09 16:17:25 --> Loader Class Initialized
INFO - 2024-10-09 16:17:25 --> Helper loaded: url_helper
INFO - 2024-10-09 16:17:25 --> Helper loaded: file_helper
INFO - 2024-10-09 16:17:25 --> Helper loaded: form_helper
INFO - 2024-10-09 16:17:25 --> Helper loaded: my_helper
INFO - 2024-10-09 16:17:25 --> Database Driver Class Initialized
INFO - 2024-10-09 16:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:17:25 --> Controller Class Initialized
DEBUG - 2024-10-09 16:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:17:26 --> Config Class Initialized
INFO - 2024-10-09 16:17:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:17:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:17:26 --> Utf8 Class Initialized
INFO - 2024-10-09 16:17:26 --> URI Class Initialized
INFO - 2024-10-09 16:17:26 --> Router Class Initialized
INFO - 2024-10-09 16:17:26 --> Output Class Initialized
INFO - 2024-10-09 16:17:26 --> Security Class Initialized
DEBUG - 2024-10-09 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:17:26 --> Input Class Initialized
INFO - 2024-10-09 16:17:26 --> Language Class Initialized
INFO - 2024-10-09 16:17:26 --> Language Class Initialized
INFO - 2024-10-09 16:17:26 --> Config Class Initialized
INFO - 2024-10-09 16:17:26 --> Loader Class Initialized
INFO - 2024-10-09 16:17:26 --> Helper loaded: url_helper
INFO - 2024-10-09 16:17:26 --> Helper loaded: file_helper
INFO - 2024-10-09 16:17:26 --> Helper loaded: form_helper
INFO - 2024-10-09 16:17:26 --> Helper loaded: my_helper
INFO - 2024-10-09 16:17:26 --> Database Driver Class Initialized
INFO - 2024-10-09 16:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:17:26 --> Controller Class Initialized
DEBUG - 2024-10-09 16:17:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:17:28 --> Config Class Initialized
INFO - 2024-10-09 16:17:28 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:17:28 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:17:28 --> Utf8 Class Initialized
INFO - 2024-10-09 16:17:28 --> URI Class Initialized
INFO - 2024-10-09 16:17:28 --> Router Class Initialized
INFO - 2024-10-09 16:17:28 --> Output Class Initialized
INFO - 2024-10-09 16:17:28 --> Security Class Initialized
DEBUG - 2024-10-09 16:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:17:28 --> Input Class Initialized
INFO - 2024-10-09 16:17:28 --> Language Class Initialized
INFO - 2024-10-09 16:17:28 --> Language Class Initialized
INFO - 2024-10-09 16:17:28 --> Config Class Initialized
INFO - 2024-10-09 16:17:28 --> Loader Class Initialized
INFO - 2024-10-09 16:17:28 --> Helper loaded: url_helper
INFO - 2024-10-09 16:17:28 --> Helper loaded: file_helper
INFO - 2024-10-09 16:17:28 --> Helper loaded: form_helper
INFO - 2024-10-09 16:17:28 --> Helper loaded: my_helper
INFO - 2024-10-09 16:17:28 --> Database Driver Class Initialized
INFO - 2024-10-09 16:17:32 --> Final output sent to browser
DEBUG - 2024-10-09 16:17:32 --> Total execution time: 6.9158
INFO - 2024-10-09 16:17:33 --> Final output sent to browser
DEBUG - 2024-10-09 16:17:33 --> Total execution time: 6.9504
INFO - 2024-10-09 16:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:17:33 --> Controller Class Initialized
DEBUG - 2024-10-09 16:17:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:17:36 --> Final output sent to browser
DEBUG - 2024-10-09 16:17:36 --> Total execution time: 8.1564
INFO - 2024-10-09 16:18:11 --> Config Class Initialized
INFO - 2024-10-09 16:18:11 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:18:11 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:18:11 --> Utf8 Class Initialized
INFO - 2024-10-09 16:18:11 --> URI Class Initialized
INFO - 2024-10-09 16:18:11 --> Router Class Initialized
INFO - 2024-10-09 16:18:11 --> Output Class Initialized
INFO - 2024-10-09 16:18:11 --> Security Class Initialized
DEBUG - 2024-10-09 16:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:18:11 --> Input Class Initialized
INFO - 2024-10-09 16:18:11 --> Language Class Initialized
INFO - 2024-10-09 16:18:11 --> Language Class Initialized
INFO - 2024-10-09 16:18:11 --> Config Class Initialized
INFO - 2024-10-09 16:18:11 --> Loader Class Initialized
INFO - 2024-10-09 16:18:11 --> Helper loaded: url_helper
INFO - 2024-10-09 16:18:11 --> Helper loaded: file_helper
INFO - 2024-10-09 16:18:11 --> Helper loaded: form_helper
INFO - 2024-10-09 16:18:11 --> Helper loaded: my_helper
INFO - 2024-10-09 16:18:11 --> Database Driver Class Initialized
INFO - 2024-10-09 16:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:18:11 --> Controller Class Initialized
DEBUG - 2024-10-09 16:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:18:14 --> Final output sent to browser
DEBUG - 2024-10-09 16:18:14 --> Total execution time: 2.9077
INFO - 2024-10-09 16:20:45 --> Config Class Initialized
INFO - 2024-10-09 16:20:45 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:20:45 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:20:45 --> Utf8 Class Initialized
INFO - 2024-10-09 16:20:45 --> URI Class Initialized
INFO - 2024-10-09 16:20:45 --> Router Class Initialized
INFO - 2024-10-09 16:20:45 --> Output Class Initialized
INFO - 2024-10-09 16:20:45 --> Security Class Initialized
DEBUG - 2024-10-09 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:20:45 --> Input Class Initialized
INFO - 2024-10-09 16:20:45 --> Language Class Initialized
INFO - 2024-10-09 16:20:45 --> Language Class Initialized
INFO - 2024-10-09 16:20:45 --> Config Class Initialized
INFO - 2024-10-09 16:20:45 --> Loader Class Initialized
INFO - 2024-10-09 16:20:45 --> Helper loaded: url_helper
INFO - 2024-10-09 16:20:45 --> Helper loaded: file_helper
INFO - 2024-10-09 16:20:45 --> Helper loaded: form_helper
INFO - 2024-10-09 16:20:45 --> Helper loaded: my_helper
INFO - 2024-10-09 16:20:45 --> Database Driver Class Initialized
INFO - 2024-10-09 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:20:45 --> Controller Class Initialized
DEBUG - 2024-10-09 16:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:20:48 --> Final output sent to browser
DEBUG - 2024-10-09 16:20:48 --> Total execution time: 3.1916
INFO - 2024-10-09 16:22:24 --> Config Class Initialized
INFO - 2024-10-09 16:22:24 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:22:24 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:22:24 --> Utf8 Class Initialized
INFO - 2024-10-09 16:22:24 --> URI Class Initialized
INFO - 2024-10-09 16:22:24 --> Router Class Initialized
INFO - 2024-10-09 16:22:24 --> Output Class Initialized
INFO - 2024-10-09 16:22:24 --> Security Class Initialized
DEBUG - 2024-10-09 16:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:22:24 --> Input Class Initialized
INFO - 2024-10-09 16:22:24 --> Language Class Initialized
INFO - 2024-10-09 16:22:24 --> Language Class Initialized
INFO - 2024-10-09 16:22:24 --> Config Class Initialized
INFO - 2024-10-09 16:22:24 --> Loader Class Initialized
INFO - 2024-10-09 16:22:24 --> Helper loaded: url_helper
INFO - 2024-10-09 16:22:24 --> Helper loaded: file_helper
INFO - 2024-10-09 16:22:24 --> Helper loaded: form_helper
INFO - 2024-10-09 16:22:24 --> Helper loaded: my_helper
INFO - 2024-10-09 16:22:24 --> Database Driver Class Initialized
INFO - 2024-10-09 16:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:22:24 --> Controller Class Initialized
DEBUG - 2024-10-09 16:22:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:22:28 --> Final output sent to browser
DEBUG - 2024-10-09 16:22:28 --> Total execution time: 3.2729
INFO - 2024-10-09 16:22:39 --> Config Class Initialized
INFO - 2024-10-09 16:22:39 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:22:39 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:22:39 --> Utf8 Class Initialized
INFO - 2024-10-09 16:22:39 --> URI Class Initialized
INFO - 2024-10-09 16:22:39 --> Router Class Initialized
INFO - 2024-10-09 16:22:39 --> Output Class Initialized
INFO - 2024-10-09 16:22:39 --> Security Class Initialized
DEBUG - 2024-10-09 16:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:22:39 --> Input Class Initialized
INFO - 2024-10-09 16:22:39 --> Language Class Initialized
INFO - 2024-10-09 16:22:39 --> Language Class Initialized
INFO - 2024-10-09 16:22:39 --> Config Class Initialized
INFO - 2024-10-09 16:22:39 --> Loader Class Initialized
INFO - 2024-10-09 16:22:39 --> Helper loaded: url_helper
INFO - 2024-10-09 16:22:39 --> Helper loaded: file_helper
INFO - 2024-10-09 16:22:39 --> Helper loaded: form_helper
INFO - 2024-10-09 16:22:39 --> Helper loaded: my_helper
INFO - 2024-10-09 16:22:39 --> Database Driver Class Initialized
INFO - 2024-10-09 16:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:22:39 --> Controller Class Initialized
DEBUG - 2024-10-09 16:22:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:22:42 --> Final output sent to browser
DEBUG - 2024-10-09 16:22:42 --> Total execution time: 3.0179
INFO - 2024-10-09 16:24:25 --> Config Class Initialized
INFO - 2024-10-09 16:24:25 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:24:25 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:24:25 --> Utf8 Class Initialized
INFO - 2024-10-09 16:24:25 --> URI Class Initialized
INFO - 2024-10-09 16:24:25 --> Router Class Initialized
INFO - 2024-10-09 16:24:25 --> Output Class Initialized
INFO - 2024-10-09 16:24:25 --> Security Class Initialized
DEBUG - 2024-10-09 16:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:24:25 --> Input Class Initialized
INFO - 2024-10-09 16:24:25 --> Language Class Initialized
INFO - 2024-10-09 16:24:25 --> Language Class Initialized
INFO - 2024-10-09 16:24:25 --> Config Class Initialized
INFO - 2024-10-09 16:24:25 --> Loader Class Initialized
INFO - 2024-10-09 16:24:25 --> Helper loaded: url_helper
INFO - 2024-10-09 16:24:25 --> Helper loaded: file_helper
INFO - 2024-10-09 16:24:25 --> Helper loaded: form_helper
INFO - 2024-10-09 16:24:25 --> Helper loaded: my_helper
INFO - 2024-10-09 16:24:26 --> Database Driver Class Initialized
INFO - 2024-10-09 16:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:24:26 --> Controller Class Initialized
DEBUG - 2024-10-09 16:24:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:24:30 --> Final output sent to browser
DEBUG - 2024-10-09 16:24:30 --> Total execution time: 4.2635
INFO - 2024-10-09 16:26:26 --> Config Class Initialized
INFO - 2024-10-09 16:26:26 --> Hooks Class Initialized
DEBUG - 2024-10-09 16:26:26 --> UTF-8 Support Enabled
INFO - 2024-10-09 16:26:26 --> Utf8 Class Initialized
INFO - 2024-10-09 16:26:26 --> URI Class Initialized
INFO - 2024-10-09 16:26:26 --> Router Class Initialized
INFO - 2024-10-09 16:26:26 --> Output Class Initialized
INFO - 2024-10-09 16:26:26 --> Security Class Initialized
DEBUG - 2024-10-09 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 16:26:26 --> Input Class Initialized
INFO - 2024-10-09 16:26:26 --> Language Class Initialized
INFO - 2024-10-09 16:26:26 --> Language Class Initialized
INFO - 2024-10-09 16:26:26 --> Config Class Initialized
INFO - 2024-10-09 16:26:26 --> Loader Class Initialized
INFO - 2024-10-09 16:26:26 --> Helper loaded: url_helper
INFO - 2024-10-09 16:26:26 --> Helper loaded: file_helper
INFO - 2024-10-09 16:26:26 --> Helper loaded: form_helper
INFO - 2024-10-09 16:26:26 --> Helper loaded: my_helper
INFO - 2024-10-09 16:26:26 --> Database Driver Class Initialized
INFO - 2024-10-09 16:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 16:26:26 --> Controller Class Initialized
DEBUG - 2024-10-09 16:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-09 16:26:29 --> Final output sent to browser
DEBUG - 2024-10-09 16:26:29 --> Total execution time: 2.8579
INFO - 2024-10-09 19:20:32 --> Config Class Initialized
INFO - 2024-10-09 19:20:32 --> Hooks Class Initialized
DEBUG - 2024-10-09 19:20:32 --> UTF-8 Support Enabled
INFO - 2024-10-09 19:20:32 --> Utf8 Class Initialized
INFO - 2024-10-09 19:20:32 --> URI Class Initialized
INFO - 2024-10-09 19:20:32 --> Router Class Initialized
INFO - 2024-10-09 19:20:32 --> Output Class Initialized
INFO - 2024-10-09 19:20:32 --> Security Class Initialized
DEBUG - 2024-10-09 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 19:20:32 --> Input Class Initialized
INFO - 2024-10-09 19:20:32 --> Language Class Initialized
INFO - 2024-10-09 19:20:32 --> Language Class Initialized
INFO - 2024-10-09 19:20:32 --> Config Class Initialized
INFO - 2024-10-09 19:20:32 --> Loader Class Initialized
INFO - 2024-10-09 19:20:32 --> Helper loaded: url_helper
INFO - 2024-10-09 19:20:32 --> Helper loaded: file_helper
INFO - 2024-10-09 19:20:32 --> Helper loaded: form_helper
INFO - 2024-10-09 19:20:32 --> Helper loaded: my_helper
INFO - 2024-10-09 19:20:32 --> Database Driver Class Initialized
INFO - 2024-10-09 19:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 19:20:32 --> Controller Class Initialized
INFO - 2024-10-09 19:20:32 --> Config Class Initialized
INFO - 2024-10-09 19:20:32 --> Hooks Class Initialized
DEBUG - 2024-10-09 19:20:32 --> UTF-8 Support Enabled
INFO - 2024-10-09 19:20:32 --> Utf8 Class Initialized
INFO - 2024-10-09 19:20:32 --> URI Class Initialized
INFO - 2024-10-09 19:20:32 --> Router Class Initialized
INFO - 2024-10-09 19:20:32 --> Output Class Initialized
INFO - 2024-10-09 19:20:32 --> Security Class Initialized
DEBUG - 2024-10-09 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 19:20:32 --> Input Class Initialized
INFO - 2024-10-09 19:20:32 --> Language Class Initialized
INFO - 2024-10-09 19:20:32 --> Language Class Initialized
INFO - 2024-10-09 19:20:32 --> Config Class Initialized
INFO - 2024-10-09 19:20:32 --> Loader Class Initialized
INFO - 2024-10-09 19:20:32 --> Helper loaded: url_helper
INFO - 2024-10-09 19:20:32 --> Helper loaded: file_helper
INFO - 2024-10-09 19:20:32 --> Helper loaded: form_helper
INFO - 2024-10-09 19:20:32 --> Helper loaded: my_helper
INFO - 2024-10-09 19:20:32 --> Database Driver Class Initialized
INFO - 2024-10-09 19:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 19:20:32 --> Controller Class Initialized
DEBUG - 2024-10-09 19:20:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-09 19:20:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-09 19:20:32 --> Final output sent to browser
DEBUG - 2024-10-09 19:20:32 --> Total execution time: 0.0331
