<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-08 08:26:40 --> Config Class Initialized
INFO - 2023-12-08 08:26:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 08:26:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 08:26:40 --> Utf8 Class Initialized
INFO - 2023-12-08 08:26:40 --> URI Class Initialized
INFO - 2023-12-08 08:26:40 --> Router Class Initialized
INFO - 2023-12-08 08:26:40 --> Output Class Initialized
INFO - 2023-12-08 08:26:40 --> Security Class Initialized
DEBUG - 2023-12-08 08:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 08:26:40 --> Input Class Initialized
INFO - 2023-12-08 08:26:40 --> Language Class Initialized
INFO - 2023-12-08 08:26:40 --> Language Class Initialized
INFO - 2023-12-08 08:26:40 --> Config Class Initialized
INFO - 2023-12-08 08:26:40 --> Loader Class Initialized
INFO - 2023-12-08 08:26:40 --> Helper loaded: url_helper
INFO - 2023-12-08 08:26:40 --> Helper loaded: file_helper
INFO - 2023-12-08 08:26:40 --> Helper loaded: form_helper
INFO - 2023-12-08 08:26:40 --> Helper loaded: my_helper
INFO - 2023-12-08 08:26:40 --> Database Driver Class Initialized
INFO - 2023-12-08 08:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 08:26:40 --> Controller Class Initialized
DEBUG - 2023-12-08 08:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 08:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 08:26:40 --> Final output sent to browser
DEBUG - 2023-12-08 08:26:40 --> Total execution time: 0.0632
INFO - 2023-12-08 09:50:15 --> Config Class Initialized
INFO - 2023-12-08 09:50:15 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:16 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:16 --> URI Class Initialized
INFO - 2023-12-08 09:50:16 --> Router Class Initialized
INFO - 2023-12-08 09:50:16 --> Output Class Initialized
INFO - 2023-12-08 09:50:16 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:16 --> Input Class Initialized
INFO - 2023-12-08 09:50:16 --> Language Class Initialized
INFO - 2023-12-08 09:50:16 --> Language Class Initialized
INFO - 2023-12-08 09:50:16 --> Config Class Initialized
INFO - 2023-12-08 09:50:16 --> Loader Class Initialized
INFO - 2023-12-08 09:50:16 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:16 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:16 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:16 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:16 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:16 --> Controller Class Initialized
INFO - 2023-12-08 09:50:16 --> Config Class Initialized
INFO - 2023-12-08 09:50:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:16 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:16 --> URI Class Initialized
INFO - 2023-12-08 09:50:16 --> Router Class Initialized
INFO - 2023-12-08 09:50:16 --> Output Class Initialized
INFO - 2023-12-08 09:50:16 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:16 --> Input Class Initialized
INFO - 2023-12-08 09:50:16 --> Language Class Initialized
INFO - 2023-12-08 09:50:16 --> Language Class Initialized
INFO - 2023-12-08 09:50:16 --> Config Class Initialized
INFO - 2023-12-08 09:50:16 --> Loader Class Initialized
INFO - 2023-12-08 09:50:16 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:16 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:16 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:16 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:16 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:16 --> Controller Class Initialized
DEBUG - 2023-12-08 09:50:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 09:50:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:50:16 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:16 --> Total execution time: 0.0438
INFO - 2023-12-08 09:50:19 --> Config Class Initialized
INFO - 2023-12-08 09:50:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:19 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:19 --> URI Class Initialized
INFO - 2023-12-08 09:50:19 --> Router Class Initialized
INFO - 2023-12-08 09:50:19 --> Output Class Initialized
INFO - 2023-12-08 09:50:19 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:19 --> Input Class Initialized
INFO - 2023-12-08 09:50:19 --> Language Class Initialized
INFO - 2023-12-08 09:50:19 --> Language Class Initialized
INFO - 2023-12-08 09:50:19 --> Config Class Initialized
INFO - 2023-12-08 09:50:19 --> Loader Class Initialized
INFO - 2023-12-08 09:50:19 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:19 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:19 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:19 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:19 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:19 --> Controller Class Initialized
INFO - 2023-12-08 09:50:20 --> Helper loaded: cookie_helper
INFO - 2023-12-08 09:50:20 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:20 --> Total execution time: 0.1156
INFO - 2023-12-08 09:50:20 --> Config Class Initialized
INFO - 2023-12-08 09:50:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:20 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:20 --> URI Class Initialized
INFO - 2023-12-08 09:50:20 --> Router Class Initialized
INFO - 2023-12-08 09:50:20 --> Output Class Initialized
INFO - 2023-12-08 09:50:20 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:20 --> Input Class Initialized
INFO - 2023-12-08 09:50:20 --> Language Class Initialized
INFO - 2023-12-08 09:50:20 --> Language Class Initialized
INFO - 2023-12-08 09:50:20 --> Config Class Initialized
INFO - 2023-12-08 09:50:20 --> Loader Class Initialized
INFO - 2023-12-08 09:50:20 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:20 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:20 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:20 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:20 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:20 --> Controller Class Initialized
DEBUG - 2023-12-08 09:50:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 09:50:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:50:20 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:20 --> Total execution time: 0.0629
INFO - 2023-12-08 09:50:22 --> Config Class Initialized
INFO - 2023-12-08 09:50:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:22 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:22 --> URI Class Initialized
INFO - 2023-12-08 09:50:22 --> Router Class Initialized
INFO - 2023-12-08 09:50:22 --> Output Class Initialized
INFO - 2023-12-08 09:50:22 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:22 --> Input Class Initialized
INFO - 2023-12-08 09:50:22 --> Language Class Initialized
INFO - 2023-12-08 09:50:22 --> Language Class Initialized
INFO - 2023-12-08 09:50:22 --> Config Class Initialized
INFO - 2023-12-08 09:50:22 --> Loader Class Initialized
INFO - 2023-12-08 09:50:22 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:22 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:22 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:22 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:22 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:22 --> Controller Class Initialized
DEBUG - 2023-12-08 09:50:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 09:50:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:50:22 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:22 --> Total execution time: 0.0613
INFO - 2023-12-08 09:50:27 --> Config Class Initialized
INFO - 2023-12-08 09:50:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:27 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:27 --> URI Class Initialized
INFO - 2023-12-08 09:50:27 --> Router Class Initialized
INFO - 2023-12-08 09:50:27 --> Output Class Initialized
INFO - 2023-12-08 09:50:27 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:27 --> Input Class Initialized
INFO - 2023-12-08 09:50:27 --> Language Class Initialized
INFO - 2023-12-08 09:50:27 --> Language Class Initialized
INFO - 2023-12-08 09:50:27 --> Config Class Initialized
INFO - 2023-12-08 09:50:27 --> Loader Class Initialized
INFO - 2023-12-08 09:50:27 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:27 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:27 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:27 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:27 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:27 --> Controller Class Initialized
DEBUG - 2023-12-08 09:50:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 09:50:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:50:27 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:27 --> Total execution time: 0.0909
INFO - 2023-12-08 09:50:27 --> Config Class Initialized
INFO - 2023-12-08 09:50:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:27 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:27 --> URI Class Initialized
INFO - 2023-12-08 09:50:27 --> Router Class Initialized
INFO - 2023-12-08 09:50:27 --> Output Class Initialized
INFO - 2023-12-08 09:50:27 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:27 --> Input Class Initialized
INFO - 2023-12-08 09:50:27 --> Language Class Initialized
INFO - 2023-12-08 09:50:27 --> Language Class Initialized
INFO - 2023-12-08 09:50:27 --> Config Class Initialized
INFO - 2023-12-08 09:50:27 --> Loader Class Initialized
INFO - 2023-12-08 09:50:27 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:27 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:27 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:27 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:27 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:27 --> Controller Class Initialized
INFO - 2023-12-08 09:50:30 --> Config Class Initialized
INFO - 2023-12-08 09:50:30 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:30 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:30 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:30 --> URI Class Initialized
INFO - 2023-12-08 09:50:30 --> Router Class Initialized
INFO - 2023-12-08 09:50:30 --> Output Class Initialized
INFO - 2023-12-08 09:50:30 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:30 --> Input Class Initialized
INFO - 2023-12-08 09:50:30 --> Language Class Initialized
INFO - 2023-12-08 09:50:30 --> Language Class Initialized
INFO - 2023-12-08 09:50:30 --> Config Class Initialized
INFO - 2023-12-08 09:50:30 --> Loader Class Initialized
INFO - 2023-12-08 09:50:30 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:30 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:30 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:30 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:30 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:30 --> Controller Class Initialized
DEBUG - 2023-12-08 09:50:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 09:50:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:50:30 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:30 --> Total execution time: 0.0824
INFO - 2023-12-08 09:50:40 --> Config Class Initialized
INFO - 2023-12-08 09:50:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:41 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:41 --> URI Class Initialized
INFO - 2023-12-08 09:50:41 --> Router Class Initialized
INFO - 2023-12-08 09:50:41 --> Output Class Initialized
INFO - 2023-12-08 09:50:41 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:41 --> Input Class Initialized
INFO - 2023-12-08 09:50:41 --> Language Class Initialized
INFO - 2023-12-08 09:50:41 --> Language Class Initialized
INFO - 2023-12-08 09:50:41 --> Config Class Initialized
INFO - 2023-12-08 09:50:41 --> Loader Class Initialized
INFO - 2023-12-08 09:50:41 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:41 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:41 --> Controller Class Initialized
INFO - 2023-12-08 09:50:41 --> Config Class Initialized
INFO - 2023-12-08 09:50:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:41 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:41 --> URI Class Initialized
INFO - 2023-12-08 09:50:41 --> Router Class Initialized
INFO - 2023-12-08 09:50:41 --> Output Class Initialized
INFO - 2023-12-08 09:50:41 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:41 --> Input Class Initialized
INFO - 2023-12-08 09:50:41 --> Language Class Initialized
INFO - 2023-12-08 09:50:41 --> Language Class Initialized
INFO - 2023-12-08 09:50:41 --> Config Class Initialized
INFO - 2023-12-08 09:50:41 --> Loader Class Initialized
INFO - 2023-12-08 09:50:41 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:41 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:41 --> Controller Class Initialized
DEBUG - 2023-12-08 09:50:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 09:50:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:50:41 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:41 --> Total execution time: 0.0443
INFO - 2023-12-08 09:50:41 --> Config Class Initialized
INFO - 2023-12-08 09:50:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:41 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:41 --> URI Class Initialized
INFO - 2023-12-08 09:50:41 --> Router Class Initialized
INFO - 2023-12-08 09:50:41 --> Output Class Initialized
INFO - 2023-12-08 09:50:41 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:41 --> Input Class Initialized
INFO - 2023-12-08 09:50:41 --> Language Class Initialized
INFO - 2023-12-08 09:50:41 --> Language Class Initialized
INFO - 2023-12-08 09:50:41 --> Config Class Initialized
INFO - 2023-12-08 09:50:41 --> Loader Class Initialized
INFO - 2023-12-08 09:50:41 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:41 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:41 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:41 --> Controller Class Initialized
INFO - 2023-12-08 09:50:43 --> Config Class Initialized
INFO - 2023-12-08 09:50:43 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:43 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:43 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:43 --> URI Class Initialized
INFO - 2023-12-08 09:50:43 --> Router Class Initialized
INFO - 2023-12-08 09:50:43 --> Output Class Initialized
INFO - 2023-12-08 09:50:43 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:43 --> Input Class Initialized
INFO - 2023-12-08 09:50:43 --> Language Class Initialized
INFO - 2023-12-08 09:50:43 --> Language Class Initialized
INFO - 2023-12-08 09:50:43 --> Config Class Initialized
INFO - 2023-12-08 09:50:43 --> Loader Class Initialized
INFO - 2023-12-08 09:50:43 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:43 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:43 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:43 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:43 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:43 --> Controller Class Initialized
INFO - 2023-12-08 09:50:43 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:43 --> Total execution time: 0.0487
INFO - 2023-12-08 09:50:49 --> Config Class Initialized
INFO - 2023-12-08 09:50:49 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:49 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:49 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:49 --> URI Class Initialized
INFO - 2023-12-08 09:50:49 --> Router Class Initialized
INFO - 2023-12-08 09:50:49 --> Output Class Initialized
INFO - 2023-12-08 09:50:49 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:49 --> Input Class Initialized
INFO - 2023-12-08 09:50:49 --> Language Class Initialized
INFO - 2023-12-08 09:50:49 --> Language Class Initialized
INFO - 2023-12-08 09:50:49 --> Config Class Initialized
INFO - 2023-12-08 09:50:49 --> Loader Class Initialized
INFO - 2023-12-08 09:50:49 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:49 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:49 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:49 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:49 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:49 --> Controller Class Initialized
INFO - 2023-12-08 09:50:49 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:49 --> Total execution time: 0.1060
INFO - 2023-12-08 09:50:53 --> Config Class Initialized
INFO - 2023-12-08 09:50:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:53 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:53 --> URI Class Initialized
INFO - 2023-12-08 09:50:53 --> Router Class Initialized
INFO - 2023-12-08 09:50:53 --> Output Class Initialized
INFO - 2023-12-08 09:50:53 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:53 --> Input Class Initialized
INFO - 2023-12-08 09:50:53 --> Language Class Initialized
INFO - 2023-12-08 09:50:53 --> Language Class Initialized
INFO - 2023-12-08 09:50:53 --> Config Class Initialized
INFO - 2023-12-08 09:50:53 --> Loader Class Initialized
INFO - 2023-12-08 09:50:53 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:53 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:53 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:53 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:53 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:53 --> Controller Class Initialized
INFO - 2023-12-08 09:50:53 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:53 --> Total execution time: 0.0656
INFO - 2023-12-08 09:50:59 --> Config Class Initialized
INFO - 2023-12-08 09:50:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:50:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:50:59 --> Utf8 Class Initialized
INFO - 2023-12-08 09:50:59 --> URI Class Initialized
INFO - 2023-12-08 09:50:59 --> Router Class Initialized
INFO - 2023-12-08 09:50:59 --> Output Class Initialized
INFO - 2023-12-08 09:50:59 --> Security Class Initialized
DEBUG - 2023-12-08 09:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:50:59 --> Input Class Initialized
INFO - 2023-12-08 09:50:59 --> Language Class Initialized
INFO - 2023-12-08 09:50:59 --> Language Class Initialized
INFO - 2023-12-08 09:50:59 --> Config Class Initialized
INFO - 2023-12-08 09:50:59 --> Loader Class Initialized
INFO - 2023-12-08 09:50:59 --> Helper loaded: url_helper
INFO - 2023-12-08 09:50:59 --> Helper loaded: file_helper
INFO - 2023-12-08 09:50:59 --> Helper loaded: form_helper
INFO - 2023-12-08 09:50:59 --> Helper loaded: my_helper
INFO - 2023-12-08 09:50:59 --> Database Driver Class Initialized
INFO - 2023-12-08 09:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:50:59 --> Controller Class Initialized
INFO - 2023-12-08 09:50:59 --> Final output sent to browser
DEBUG - 2023-12-08 09:50:59 --> Total execution time: 0.0375
INFO - 2023-12-08 09:51:06 --> Config Class Initialized
INFO - 2023-12-08 09:51:06 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:51:06 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:51:06 --> Utf8 Class Initialized
INFO - 2023-12-08 09:51:06 --> URI Class Initialized
INFO - 2023-12-08 09:51:06 --> Router Class Initialized
INFO - 2023-12-08 09:51:06 --> Output Class Initialized
INFO - 2023-12-08 09:51:06 --> Security Class Initialized
DEBUG - 2023-12-08 09:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:51:06 --> Input Class Initialized
INFO - 2023-12-08 09:51:06 --> Language Class Initialized
INFO - 2023-12-08 09:51:06 --> Language Class Initialized
INFO - 2023-12-08 09:51:06 --> Config Class Initialized
INFO - 2023-12-08 09:51:06 --> Loader Class Initialized
INFO - 2023-12-08 09:51:06 --> Helper loaded: url_helper
INFO - 2023-12-08 09:51:06 --> Helper loaded: file_helper
INFO - 2023-12-08 09:51:06 --> Helper loaded: form_helper
INFO - 2023-12-08 09:51:06 --> Helper loaded: my_helper
INFO - 2023-12-08 09:51:06 --> Database Driver Class Initialized
INFO - 2023-12-08 09:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:51:06 --> Controller Class Initialized
INFO - 2023-12-08 09:51:06 --> Final output sent to browser
DEBUG - 2023-12-08 09:51:06 --> Total execution time: 0.0457
INFO - 2023-12-08 09:51:09 --> Config Class Initialized
INFO - 2023-12-08 09:51:09 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:51:09 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:51:09 --> Utf8 Class Initialized
INFO - 2023-12-08 09:51:09 --> URI Class Initialized
INFO - 2023-12-08 09:51:09 --> Router Class Initialized
INFO - 2023-12-08 09:51:09 --> Output Class Initialized
INFO - 2023-12-08 09:51:09 --> Security Class Initialized
DEBUG - 2023-12-08 09:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:51:09 --> Input Class Initialized
INFO - 2023-12-08 09:51:09 --> Language Class Initialized
INFO - 2023-12-08 09:51:09 --> Language Class Initialized
INFO - 2023-12-08 09:51:09 --> Config Class Initialized
INFO - 2023-12-08 09:51:09 --> Loader Class Initialized
INFO - 2023-12-08 09:51:09 --> Helper loaded: url_helper
INFO - 2023-12-08 09:51:09 --> Helper loaded: file_helper
INFO - 2023-12-08 09:51:09 --> Helper loaded: form_helper
INFO - 2023-12-08 09:51:09 --> Helper loaded: my_helper
INFO - 2023-12-08 09:51:09 --> Database Driver Class Initialized
INFO - 2023-12-08 09:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:51:09 --> Controller Class Initialized
INFO - 2023-12-08 09:51:09 --> Final output sent to browser
DEBUG - 2023-12-08 09:51:09 --> Total execution time: 0.0831
INFO - 2023-12-08 09:51:13 --> Config Class Initialized
INFO - 2023-12-08 09:51:13 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:51:13 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:51:13 --> Utf8 Class Initialized
INFO - 2023-12-08 09:51:13 --> URI Class Initialized
INFO - 2023-12-08 09:51:13 --> Router Class Initialized
INFO - 2023-12-08 09:51:13 --> Output Class Initialized
INFO - 2023-12-08 09:51:13 --> Security Class Initialized
DEBUG - 2023-12-08 09:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:51:13 --> Input Class Initialized
INFO - 2023-12-08 09:51:13 --> Language Class Initialized
INFO - 2023-12-08 09:51:13 --> Language Class Initialized
INFO - 2023-12-08 09:51:13 --> Config Class Initialized
INFO - 2023-12-08 09:51:13 --> Loader Class Initialized
INFO - 2023-12-08 09:51:13 --> Helper loaded: url_helper
INFO - 2023-12-08 09:51:13 --> Helper loaded: file_helper
INFO - 2023-12-08 09:51:13 --> Helper loaded: form_helper
INFO - 2023-12-08 09:51:13 --> Helper loaded: my_helper
INFO - 2023-12-08 09:51:13 --> Database Driver Class Initialized
INFO - 2023-12-08 09:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:51:13 --> Controller Class Initialized
INFO - 2023-12-08 09:51:13 --> Final output sent to browser
DEBUG - 2023-12-08 09:51:13 --> Total execution time: 0.0665
INFO - 2023-12-08 09:51:24 --> Config Class Initialized
INFO - 2023-12-08 09:51:24 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:51:24 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:51:24 --> Utf8 Class Initialized
INFO - 2023-12-08 09:51:24 --> URI Class Initialized
INFO - 2023-12-08 09:51:24 --> Router Class Initialized
INFO - 2023-12-08 09:51:24 --> Output Class Initialized
INFO - 2023-12-08 09:51:24 --> Security Class Initialized
DEBUG - 2023-12-08 09:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:51:24 --> Input Class Initialized
INFO - 2023-12-08 09:51:24 --> Language Class Initialized
INFO - 2023-12-08 09:51:24 --> Language Class Initialized
INFO - 2023-12-08 09:51:24 --> Config Class Initialized
INFO - 2023-12-08 09:51:24 --> Loader Class Initialized
INFO - 2023-12-08 09:51:24 --> Helper loaded: url_helper
INFO - 2023-12-08 09:51:24 --> Helper loaded: file_helper
INFO - 2023-12-08 09:51:24 --> Helper loaded: form_helper
INFO - 2023-12-08 09:51:24 --> Helper loaded: my_helper
INFO - 2023-12-08 09:51:24 --> Database Driver Class Initialized
INFO - 2023-12-08 09:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:51:24 --> Controller Class Initialized
INFO - 2023-12-08 09:51:25 --> Final output sent to browser
DEBUG - 2023-12-08 09:51:25 --> Total execution time: 0.0988
INFO - 2023-12-08 09:51:27 --> Config Class Initialized
INFO - 2023-12-08 09:51:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 09:51:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 09:51:27 --> Utf8 Class Initialized
INFO - 2023-12-08 09:51:27 --> URI Class Initialized
INFO - 2023-12-08 09:51:27 --> Router Class Initialized
INFO - 2023-12-08 09:51:27 --> Output Class Initialized
INFO - 2023-12-08 09:51:27 --> Security Class Initialized
DEBUG - 2023-12-08 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 09:51:27 --> Input Class Initialized
INFO - 2023-12-08 09:51:27 --> Language Class Initialized
INFO - 2023-12-08 09:51:27 --> Language Class Initialized
INFO - 2023-12-08 09:51:27 --> Config Class Initialized
INFO - 2023-12-08 09:51:27 --> Loader Class Initialized
INFO - 2023-12-08 09:51:27 --> Helper loaded: url_helper
INFO - 2023-12-08 09:51:27 --> Helper loaded: file_helper
INFO - 2023-12-08 09:51:27 --> Helper loaded: form_helper
INFO - 2023-12-08 09:51:27 --> Helper loaded: my_helper
INFO - 2023-12-08 09:51:27 --> Database Driver Class Initialized
INFO - 2023-12-08 09:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 09:51:27 --> Controller Class Initialized
DEBUG - 2023-12-08 09:51:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 09:51:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 09:51:27 --> Final output sent to browser
DEBUG - 2023-12-08 09:51:27 --> Total execution time: 0.0327
INFO - 2023-12-08 10:40:13 --> Config Class Initialized
INFO - 2023-12-08 10:40:13 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:40:13 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:40:13 --> Utf8 Class Initialized
INFO - 2023-12-08 10:40:13 --> URI Class Initialized
INFO - 2023-12-08 10:40:13 --> Router Class Initialized
INFO - 2023-12-08 10:40:13 --> Output Class Initialized
INFO - 2023-12-08 10:40:13 --> Security Class Initialized
DEBUG - 2023-12-08 10:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:40:13 --> Input Class Initialized
INFO - 2023-12-08 10:40:13 --> Language Class Initialized
INFO - 2023-12-08 10:40:13 --> Language Class Initialized
INFO - 2023-12-08 10:40:13 --> Config Class Initialized
INFO - 2023-12-08 10:40:13 --> Loader Class Initialized
INFO - 2023-12-08 10:40:13 --> Helper loaded: url_helper
INFO - 2023-12-08 10:40:13 --> Helper loaded: file_helper
INFO - 2023-12-08 10:40:13 --> Helper loaded: form_helper
INFO - 2023-12-08 10:40:13 --> Helper loaded: my_helper
INFO - 2023-12-08 10:40:13 --> Database Driver Class Initialized
INFO - 2023-12-08 10:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:40:13 --> Controller Class Initialized
DEBUG - 2023-12-08 10:40:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 10:40:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 10:40:13 --> Final output sent to browser
DEBUG - 2023-12-08 10:40:13 --> Total execution time: 0.1118
INFO - 2023-12-08 10:40:57 --> Config Class Initialized
INFO - 2023-12-08 10:40:57 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:40:57 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:40:57 --> Utf8 Class Initialized
INFO - 2023-12-08 10:40:57 --> URI Class Initialized
INFO - 2023-12-08 10:40:57 --> Router Class Initialized
INFO - 2023-12-08 10:40:57 --> Output Class Initialized
INFO - 2023-12-08 10:40:57 --> Security Class Initialized
DEBUG - 2023-12-08 10:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:40:57 --> Input Class Initialized
INFO - 2023-12-08 10:40:57 --> Language Class Initialized
INFO - 2023-12-08 10:40:57 --> Language Class Initialized
INFO - 2023-12-08 10:40:57 --> Config Class Initialized
INFO - 2023-12-08 10:40:57 --> Loader Class Initialized
INFO - 2023-12-08 10:40:57 --> Helper loaded: url_helper
INFO - 2023-12-08 10:40:57 --> Helper loaded: file_helper
INFO - 2023-12-08 10:40:57 --> Helper loaded: form_helper
INFO - 2023-12-08 10:40:57 --> Helper loaded: my_helper
INFO - 2023-12-08 10:40:57 --> Database Driver Class Initialized
INFO - 2023-12-08 10:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:40:57 --> Controller Class Initialized
DEBUG - 2023-12-08 10:40:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 10:40:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 10:40:57 --> Final output sent to browser
DEBUG - 2023-12-08 10:40:57 --> Total execution time: 0.2454
INFO - 2023-12-08 10:40:57 --> Config Class Initialized
INFO - 2023-12-08 10:40:57 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:40:57 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:40:57 --> Utf8 Class Initialized
INFO - 2023-12-08 10:40:57 --> URI Class Initialized
INFO - 2023-12-08 10:40:57 --> Router Class Initialized
INFO - 2023-12-08 10:40:57 --> Output Class Initialized
INFO - 2023-12-08 10:40:57 --> Security Class Initialized
DEBUG - 2023-12-08 10:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:40:57 --> Input Class Initialized
INFO - 2023-12-08 10:40:57 --> Language Class Initialized
INFO - 2023-12-08 10:40:57 --> Language Class Initialized
INFO - 2023-12-08 10:40:57 --> Config Class Initialized
INFO - 2023-12-08 10:40:57 --> Loader Class Initialized
INFO - 2023-12-08 10:40:57 --> Helper loaded: url_helper
INFO - 2023-12-08 10:40:57 --> Helper loaded: file_helper
INFO - 2023-12-08 10:40:57 --> Helper loaded: form_helper
INFO - 2023-12-08 10:40:57 --> Helper loaded: my_helper
INFO - 2023-12-08 10:40:57 --> Database Driver Class Initialized
INFO - 2023-12-08 10:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:40:57 --> Controller Class Initialized
INFO - 2023-12-08 10:41:01 --> Config Class Initialized
INFO - 2023-12-08 10:41:01 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:41:01 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:41:01 --> Utf8 Class Initialized
INFO - 2023-12-08 10:41:01 --> URI Class Initialized
INFO - 2023-12-08 10:41:01 --> Router Class Initialized
INFO - 2023-12-08 10:41:01 --> Output Class Initialized
INFO - 2023-12-08 10:41:01 --> Security Class Initialized
DEBUG - 2023-12-08 10:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:41:01 --> Input Class Initialized
INFO - 2023-12-08 10:41:01 --> Language Class Initialized
INFO - 2023-12-08 10:41:01 --> Language Class Initialized
INFO - 2023-12-08 10:41:01 --> Config Class Initialized
INFO - 2023-12-08 10:41:01 --> Loader Class Initialized
INFO - 2023-12-08 10:41:01 --> Helper loaded: url_helper
INFO - 2023-12-08 10:41:01 --> Helper loaded: file_helper
INFO - 2023-12-08 10:41:01 --> Helper loaded: form_helper
INFO - 2023-12-08 10:41:01 --> Helper loaded: my_helper
INFO - 2023-12-08 10:41:01 --> Database Driver Class Initialized
INFO - 2023-12-08 10:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:41:01 --> Controller Class Initialized
INFO - 2023-12-08 10:46:04 --> Config Class Initialized
INFO - 2023-12-08 10:46:04 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:46:04 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:46:04 --> Utf8 Class Initialized
INFO - 2023-12-08 10:46:04 --> URI Class Initialized
INFO - 2023-12-08 10:46:04 --> Router Class Initialized
INFO - 2023-12-08 10:46:04 --> Output Class Initialized
INFO - 2023-12-08 10:46:04 --> Security Class Initialized
DEBUG - 2023-12-08 10:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:46:04 --> Input Class Initialized
INFO - 2023-12-08 10:46:04 --> Language Class Initialized
INFO - 2023-12-08 10:46:05 --> Language Class Initialized
INFO - 2023-12-08 10:46:05 --> Config Class Initialized
INFO - 2023-12-08 10:46:05 --> Loader Class Initialized
INFO - 2023-12-08 10:46:05 --> Helper loaded: url_helper
INFO - 2023-12-08 10:46:05 --> Helper loaded: file_helper
INFO - 2023-12-08 10:46:05 --> Helper loaded: form_helper
INFO - 2023-12-08 10:46:05 --> Helper loaded: my_helper
INFO - 2023-12-08 10:46:05 --> Database Driver Class Initialized
INFO - 2023-12-08 10:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:46:05 --> Controller Class Initialized
DEBUG - 2023-12-08 10:46:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 10:46:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 10:46:05 --> Final output sent to browser
DEBUG - 2023-12-08 10:46:05 --> Total execution time: 0.0645
INFO - 2023-12-08 10:46:16 --> Config Class Initialized
INFO - 2023-12-08 10:46:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:46:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:46:16 --> Utf8 Class Initialized
INFO - 2023-12-08 10:46:16 --> URI Class Initialized
INFO - 2023-12-08 10:46:16 --> Router Class Initialized
INFO - 2023-12-08 10:46:16 --> Output Class Initialized
INFO - 2023-12-08 10:46:16 --> Security Class Initialized
DEBUG - 2023-12-08 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:46:16 --> Input Class Initialized
INFO - 2023-12-08 10:46:16 --> Language Class Initialized
INFO - 2023-12-08 10:46:16 --> Language Class Initialized
INFO - 2023-12-08 10:46:16 --> Config Class Initialized
INFO - 2023-12-08 10:46:16 --> Loader Class Initialized
INFO - 2023-12-08 10:46:16 --> Helper loaded: url_helper
INFO - 2023-12-08 10:46:16 --> Helper loaded: file_helper
INFO - 2023-12-08 10:46:16 --> Helper loaded: form_helper
INFO - 2023-12-08 10:46:16 --> Helper loaded: my_helper
INFO - 2023-12-08 10:46:16 --> Database Driver Class Initialized
INFO - 2023-12-08 10:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:46:16 --> Controller Class Initialized
INFO - 2023-12-08 10:46:16 --> Config Class Initialized
INFO - 2023-12-08 10:46:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:46:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:46:16 --> Utf8 Class Initialized
INFO - 2023-12-08 10:46:16 --> URI Class Initialized
INFO - 2023-12-08 10:46:17 --> Router Class Initialized
INFO - 2023-12-08 10:46:17 --> Output Class Initialized
INFO - 2023-12-08 10:46:17 --> Security Class Initialized
DEBUG - 2023-12-08 10:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:46:17 --> Input Class Initialized
INFO - 2023-12-08 10:46:17 --> Language Class Initialized
INFO - 2023-12-08 10:46:17 --> Language Class Initialized
INFO - 2023-12-08 10:46:17 --> Config Class Initialized
INFO - 2023-12-08 10:46:17 --> Loader Class Initialized
INFO - 2023-12-08 10:46:17 --> Helper loaded: url_helper
INFO - 2023-12-08 10:46:17 --> Helper loaded: file_helper
INFO - 2023-12-08 10:46:17 --> Helper loaded: form_helper
INFO - 2023-12-08 10:46:17 --> Helper loaded: my_helper
INFO - 2023-12-08 10:46:17 --> Database Driver Class Initialized
INFO - 2023-12-08 10:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:46:17 --> Controller Class Initialized
DEBUG - 2023-12-08 10:46:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 10:46:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 10:46:17 --> Final output sent to browser
DEBUG - 2023-12-08 10:46:17 --> Total execution time: 0.0777
INFO - 2023-12-08 10:46:17 --> Config Class Initialized
INFO - 2023-12-08 10:46:17 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:46:17 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:46:17 --> Utf8 Class Initialized
INFO - 2023-12-08 10:46:17 --> URI Class Initialized
INFO - 2023-12-08 10:46:17 --> Router Class Initialized
INFO - 2023-12-08 10:46:17 --> Output Class Initialized
INFO - 2023-12-08 10:46:17 --> Security Class Initialized
DEBUG - 2023-12-08 10:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:46:17 --> Input Class Initialized
INFO - 2023-12-08 10:46:17 --> Language Class Initialized
INFO - 2023-12-08 10:46:17 --> Language Class Initialized
INFO - 2023-12-08 10:46:17 --> Config Class Initialized
INFO - 2023-12-08 10:46:17 --> Loader Class Initialized
INFO - 2023-12-08 10:46:17 --> Helper loaded: url_helper
INFO - 2023-12-08 10:46:17 --> Helper loaded: file_helper
INFO - 2023-12-08 10:46:17 --> Helper loaded: form_helper
INFO - 2023-12-08 10:46:17 --> Helper loaded: my_helper
INFO - 2023-12-08 10:46:17 --> Database Driver Class Initialized
INFO - 2023-12-08 10:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:46:17 --> Controller Class Initialized
INFO - 2023-12-08 10:46:19 --> Config Class Initialized
INFO - 2023-12-08 10:46:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:46:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:46:19 --> Utf8 Class Initialized
INFO - 2023-12-08 10:46:19 --> URI Class Initialized
INFO - 2023-12-08 10:46:19 --> Router Class Initialized
INFO - 2023-12-08 10:46:19 --> Output Class Initialized
INFO - 2023-12-08 10:46:19 --> Security Class Initialized
DEBUG - 2023-12-08 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:46:19 --> Input Class Initialized
INFO - 2023-12-08 10:46:19 --> Language Class Initialized
INFO - 2023-12-08 10:46:19 --> Language Class Initialized
INFO - 2023-12-08 10:46:19 --> Config Class Initialized
INFO - 2023-12-08 10:46:19 --> Loader Class Initialized
INFO - 2023-12-08 10:46:19 --> Helper loaded: url_helper
INFO - 2023-12-08 10:46:19 --> Helper loaded: file_helper
INFO - 2023-12-08 10:46:19 --> Helper loaded: form_helper
INFO - 2023-12-08 10:46:19 --> Helper loaded: my_helper
INFO - 2023-12-08 10:46:19 --> Database Driver Class Initialized
INFO - 2023-12-08 10:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:46:19 --> Controller Class Initialized
INFO - 2023-12-08 10:46:19 --> Final output sent to browser
DEBUG - 2023-12-08 10:46:19 --> Total execution time: 0.0449
INFO - 2023-12-08 10:46:22 --> Config Class Initialized
INFO - 2023-12-08 10:46:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 10:46:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 10:46:22 --> Utf8 Class Initialized
INFO - 2023-12-08 10:46:22 --> URI Class Initialized
INFO - 2023-12-08 10:46:22 --> Router Class Initialized
INFO - 2023-12-08 10:46:22 --> Output Class Initialized
INFO - 2023-12-08 10:46:22 --> Security Class Initialized
DEBUG - 2023-12-08 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 10:46:22 --> Input Class Initialized
INFO - 2023-12-08 10:46:22 --> Language Class Initialized
INFO - 2023-12-08 10:46:22 --> Language Class Initialized
INFO - 2023-12-08 10:46:22 --> Config Class Initialized
INFO - 2023-12-08 10:46:22 --> Loader Class Initialized
INFO - 2023-12-08 10:46:22 --> Helper loaded: url_helper
INFO - 2023-12-08 10:46:22 --> Helper loaded: file_helper
INFO - 2023-12-08 10:46:22 --> Helper loaded: form_helper
INFO - 2023-12-08 10:46:22 --> Helper loaded: my_helper
INFO - 2023-12-08 10:46:22 --> Database Driver Class Initialized
INFO - 2023-12-08 10:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 10:46:22 --> Controller Class Initialized
INFO - 2023-12-08 10:46:22 --> Final output sent to browser
DEBUG - 2023-12-08 10:46:22 --> Total execution time: 0.0955
INFO - 2023-12-08 11:21:23 --> Config Class Initialized
INFO - 2023-12-08 11:21:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:21:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:21:23 --> Utf8 Class Initialized
INFO - 2023-12-08 11:21:23 --> URI Class Initialized
INFO - 2023-12-08 11:21:23 --> Router Class Initialized
INFO - 2023-12-08 11:21:23 --> Output Class Initialized
INFO - 2023-12-08 11:21:23 --> Security Class Initialized
DEBUG - 2023-12-08 11:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:21:23 --> Input Class Initialized
INFO - 2023-12-08 11:21:23 --> Language Class Initialized
INFO - 2023-12-08 11:21:23 --> Language Class Initialized
INFO - 2023-12-08 11:21:23 --> Config Class Initialized
INFO - 2023-12-08 11:21:23 --> Loader Class Initialized
INFO - 2023-12-08 11:21:23 --> Helper loaded: url_helper
INFO - 2023-12-08 11:21:23 --> Helper loaded: file_helper
INFO - 2023-12-08 11:21:23 --> Helper loaded: form_helper
INFO - 2023-12-08 11:21:23 --> Helper loaded: my_helper
INFO - 2023-12-08 11:21:23 --> Database Driver Class Initialized
INFO - 2023-12-08 11:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:21:23 --> Controller Class Initialized
DEBUG - 2023-12-08 11:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 11:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 11:21:23 --> Final output sent to browser
DEBUG - 2023-12-08 11:21:23 --> Total execution time: 0.1198
INFO - 2023-12-08 11:21:23 --> Config Class Initialized
INFO - 2023-12-08 11:21:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:21:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:21:23 --> Utf8 Class Initialized
INFO - 2023-12-08 11:21:23 --> URI Class Initialized
INFO - 2023-12-08 11:21:23 --> Router Class Initialized
INFO - 2023-12-08 11:21:23 --> Output Class Initialized
INFO - 2023-12-08 11:21:23 --> Security Class Initialized
DEBUG - 2023-12-08 11:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:21:23 --> Input Class Initialized
INFO - 2023-12-08 11:21:23 --> Language Class Initialized
INFO - 2023-12-08 11:21:23 --> Language Class Initialized
INFO - 2023-12-08 11:21:23 --> Config Class Initialized
INFO - 2023-12-08 11:21:23 --> Loader Class Initialized
INFO - 2023-12-08 11:21:23 --> Helper loaded: url_helper
INFO - 2023-12-08 11:21:23 --> Helper loaded: file_helper
INFO - 2023-12-08 11:21:23 --> Helper loaded: form_helper
INFO - 2023-12-08 11:21:23 --> Helper loaded: my_helper
INFO - 2023-12-08 11:21:23 --> Database Driver Class Initialized
INFO - 2023-12-08 11:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:21:23 --> Controller Class Initialized
INFO - 2023-12-08 11:21:31 --> Config Class Initialized
INFO - 2023-12-08 11:21:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:21:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:21:31 --> Utf8 Class Initialized
INFO - 2023-12-08 11:21:31 --> URI Class Initialized
INFO - 2023-12-08 11:21:31 --> Router Class Initialized
INFO - 2023-12-08 11:21:31 --> Output Class Initialized
INFO - 2023-12-08 11:21:31 --> Security Class Initialized
DEBUG - 2023-12-08 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:21:31 --> Input Class Initialized
INFO - 2023-12-08 11:21:31 --> Language Class Initialized
INFO - 2023-12-08 11:21:31 --> Language Class Initialized
INFO - 2023-12-08 11:21:31 --> Config Class Initialized
INFO - 2023-12-08 11:21:31 --> Loader Class Initialized
INFO - 2023-12-08 11:21:31 --> Helper loaded: url_helper
INFO - 2023-12-08 11:21:31 --> Helper loaded: file_helper
INFO - 2023-12-08 11:21:31 --> Helper loaded: form_helper
INFO - 2023-12-08 11:21:31 --> Helper loaded: my_helper
INFO - 2023-12-08 11:21:31 --> Database Driver Class Initialized
INFO - 2023-12-08 11:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:21:31 --> Controller Class Initialized
INFO - 2023-12-08 11:21:31 --> Final output sent to browser
DEBUG - 2023-12-08 11:21:31 --> Total execution time: 0.0392
INFO - 2023-12-08 11:29:28 --> Config Class Initialized
INFO - 2023-12-08 11:29:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:29:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:29:28 --> Utf8 Class Initialized
INFO - 2023-12-08 11:29:28 --> URI Class Initialized
INFO - 2023-12-08 11:29:28 --> Router Class Initialized
INFO - 2023-12-08 11:29:28 --> Output Class Initialized
INFO - 2023-12-08 11:29:28 --> Security Class Initialized
DEBUG - 2023-12-08 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:29:28 --> Input Class Initialized
INFO - 2023-12-08 11:29:28 --> Language Class Initialized
INFO - 2023-12-08 11:29:28 --> Language Class Initialized
INFO - 2023-12-08 11:29:28 --> Config Class Initialized
INFO - 2023-12-08 11:29:28 --> Loader Class Initialized
INFO - 2023-12-08 11:29:28 --> Helper loaded: url_helper
INFO - 2023-12-08 11:29:28 --> Helper loaded: file_helper
INFO - 2023-12-08 11:29:28 --> Helper loaded: form_helper
INFO - 2023-12-08 11:29:28 --> Helper loaded: my_helper
INFO - 2023-12-08 11:29:28 --> Database Driver Class Initialized
INFO - 2023-12-08 11:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:29:28 --> Controller Class Initialized
DEBUG - 2023-12-08 11:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 11:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 11:29:28 --> Final output sent to browser
DEBUG - 2023-12-08 11:29:28 --> Total execution time: 0.0870
INFO - 2023-12-08 11:29:29 --> Config Class Initialized
INFO - 2023-12-08 11:29:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:29:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:29:29 --> Utf8 Class Initialized
INFO - 2023-12-08 11:29:29 --> URI Class Initialized
INFO - 2023-12-08 11:29:29 --> Router Class Initialized
INFO - 2023-12-08 11:29:29 --> Output Class Initialized
INFO - 2023-12-08 11:29:29 --> Security Class Initialized
DEBUG - 2023-12-08 11:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:29:29 --> Input Class Initialized
INFO - 2023-12-08 11:29:29 --> Language Class Initialized
INFO - 2023-12-08 11:29:29 --> Language Class Initialized
INFO - 2023-12-08 11:29:29 --> Config Class Initialized
INFO - 2023-12-08 11:29:29 --> Loader Class Initialized
INFO - 2023-12-08 11:29:29 --> Helper loaded: url_helper
INFO - 2023-12-08 11:29:29 --> Helper loaded: file_helper
INFO - 2023-12-08 11:29:29 --> Helper loaded: form_helper
INFO - 2023-12-08 11:29:29 --> Helper loaded: my_helper
INFO - 2023-12-08 11:29:29 --> Database Driver Class Initialized
INFO - 2023-12-08 11:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:29:29 --> Controller Class Initialized
INFO - 2023-12-08 11:29:47 --> Config Class Initialized
INFO - 2023-12-08 11:29:47 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:29:47 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:29:47 --> Utf8 Class Initialized
INFO - 2023-12-08 11:29:47 --> URI Class Initialized
INFO - 2023-12-08 11:29:47 --> Router Class Initialized
INFO - 2023-12-08 11:29:47 --> Output Class Initialized
INFO - 2023-12-08 11:29:47 --> Security Class Initialized
DEBUG - 2023-12-08 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:29:47 --> Input Class Initialized
INFO - 2023-12-08 11:29:47 --> Language Class Initialized
INFO - 2023-12-08 11:29:47 --> Language Class Initialized
INFO - 2023-12-08 11:29:47 --> Config Class Initialized
INFO - 2023-12-08 11:29:47 --> Loader Class Initialized
INFO - 2023-12-08 11:29:47 --> Helper loaded: url_helper
INFO - 2023-12-08 11:29:47 --> Helper loaded: file_helper
INFO - 2023-12-08 11:29:47 --> Helper loaded: form_helper
INFO - 2023-12-08 11:29:47 --> Helper loaded: my_helper
INFO - 2023-12-08 11:29:47 --> Database Driver Class Initialized
INFO - 2023-12-08 11:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:29:47 --> Controller Class Initialized
INFO - 2023-12-08 11:29:47 --> Final output sent to browser
DEBUG - 2023-12-08 11:29:47 --> Total execution time: 0.0480
INFO - 2023-12-08 11:29:51 --> Config Class Initialized
INFO - 2023-12-08 11:29:51 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:29:51 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:29:51 --> Utf8 Class Initialized
INFO - 2023-12-08 11:29:51 --> URI Class Initialized
INFO - 2023-12-08 11:29:51 --> Router Class Initialized
INFO - 2023-12-08 11:29:51 --> Output Class Initialized
INFO - 2023-12-08 11:29:51 --> Security Class Initialized
DEBUG - 2023-12-08 11:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:29:51 --> Input Class Initialized
INFO - 2023-12-08 11:29:51 --> Language Class Initialized
INFO - 2023-12-08 11:29:51 --> Language Class Initialized
INFO - 2023-12-08 11:29:51 --> Config Class Initialized
INFO - 2023-12-08 11:29:51 --> Loader Class Initialized
INFO - 2023-12-08 11:29:51 --> Helper loaded: url_helper
INFO - 2023-12-08 11:29:51 --> Helper loaded: file_helper
INFO - 2023-12-08 11:29:51 --> Helper loaded: form_helper
INFO - 2023-12-08 11:29:51 --> Helper loaded: my_helper
INFO - 2023-12-08 11:29:51 --> Database Driver Class Initialized
INFO - 2023-12-08 11:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:29:51 --> Controller Class Initialized
INFO - 2023-12-08 11:30:14 --> Config Class Initialized
INFO - 2023-12-08 11:30:14 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:30:14 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:30:14 --> Utf8 Class Initialized
INFO - 2023-12-08 11:30:14 --> URI Class Initialized
INFO - 2023-12-08 11:30:14 --> Router Class Initialized
INFO - 2023-12-08 11:30:14 --> Output Class Initialized
INFO - 2023-12-08 11:30:14 --> Security Class Initialized
DEBUG - 2023-12-08 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:30:14 --> Input Class Initialized
INFO - 2023-12-08 11:30:14 --> Language Class Initialized
INFO - 2023-12-08 11:30:14 --> Language Class Initialized
INFO - 2023-12-08 11:30:14 --> Config Class Initialized
INFO - 2023-12-08 11:30:14 --> Loader Class Initialized
INFO - 2023-12-08 11:30:14 --> Helper loaded: url_helper
INFO - 2023-12-08 11:30:14 --> Helper loaded: file_helper
INFO - 2023-12-08 11:30:14 --> Helper loaded: form_helper
INFO - 2023-12-08 11:30:14 --> Helper loaded: my_helper
INFO - 2023-12-08 11:30:14 --> Database Driver Class Initialized
INFO - 2023-12-08 11:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:30:14 --> Controller Class Initialized
DEBUG - 2023-12-08 11:30:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 11:30:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 11:30:14 --> Final output sent to browser
DEBUG - 2023-12-08 11:30:14 --> Total execution time: 0.0380
INFO - 2023-12-08 11:30:14 --> Config Class Initialized
INFO - 2023-12-08 11:30:14 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:30:14 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:30:14 --> Utf8 Class Initialized
INFO - 2023-12-08 11:30:14 --> URI Class Initialized
INFO - 2023-12-08 11:30:14 --> Router Class Initialized
INFO - 2023-12-08 11:30:14 --> Output Class Initialized
INFO - 2023-12-08 11:30:14 --> Security Class Initialized
DEBUG - 2023-12-08 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:30:14 --> Input Class Initialized
INFO - 2023-12-08 11:30:14 --> Language Class Initialized
INFO - 2023-12-08 11:30:14 --> Language Class Initialized
INFO - 2023-12-08 11:30:14 --> Config Class Initialized
INFO - 2023-12-08 11:30:14 --> Loader Class Initialized
INFO - 2023-12-08 11:30:14 --> Helper loaded: url_helper
INFO - 2023-12-08 11:30:14 --> Helper loaded: file_helper
INFO - 2023-12-08 11:30:14 --> Helper loaded: form_helper
INFO - 2023-12-08 11:30:14 --> Helper loaded: my_helper
INFO - 2023-12-08 11:30:14 --> Database Driver Class Initialized
INFO - 2023-12-08 11:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:30:14 --> Controller Class Initialized
INFO - 2023-12-08 11:31:35 --> Config Class Initialized
INFO - 2023-12-08 11:31:35 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:35 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:35 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:35 --> URI Class Initialized
INFO - 2023-12-08 11:31:35 --> Router Class Initialized
INFO - 2023-12-08 11:31:35 --> Output Class Initialized
INFO - 2023-12-08 11:31:35 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:35 --> Input Class Initialized
INFO - 2023-12-08 11:31:35 --> Language Class Initialized
INFO - 2023-12-08 11:31:35 --> Language Class Initialized
INFO - 2023-12-08 11:31:35 --> Config Class Initialized
INFO - 2023-12-08 11:31:35 --> Loader Class Initialized
INFO - 2023-12-08 11:31:35 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:35 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:35 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:35 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:35 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:35 --> Controller Class Initialized
INFO - 2023-12-08 11:31:41 --> Config Class Initialized
INFO - 2023-12-08 11:31:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:41 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:41 --> URI Class Initialized
INFO - 2023-12-08 11:31:41 --> Router Class Initialized
INFO - 2023-12-08 11:31:41 --> Output Class Initialized
INFO - 2023-12-08 11:31:41 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:41 --> Input Class Initialized
INFO - 2023-12-08 11:31:41 --> Language Class Initialized
INFO - 2023-12-08 11:31:41 --> Language Class Initialized
INFO - 2023-12-08 11:31:41 --> Config Class Initialized
INFO - 2023-12-08 11:31:41 --> Loader Class Initialized
INFO - 2023-12-08 11:31:41 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:41 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:41 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:41 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:41 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:41 --> Controller Class Initialized
DEBUG - 2023-12-08 11:31:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 11:31:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 11:31:41 --> Final output sent to browser
DEBUG - 2023-12-08 11:31:41 --> Total execution time: 0.0374
INFO - 2023-12-08 11:31:41 --> Config Class Initialized
INFO - 2023-12-08 11:31:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:41 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:41 --> URI Class Initialized
INFO - 2023-12-08 11:31:41 --> Router Class Initialized
INFO - 2023-12-08 11:31:41 --> Output Class Initialized
INFO - 2023-12-08 11:31:41 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:41 --> Input Class Initialized
INFO - 2023-12-08 11:31:41 --> Language Class Initialized
INFO - 2023-12-08 11:31:41 --> Language Class Initialized
INFO - 2023-12-08 11:31:41 --> Config Class Initialized
INFO - 2023-12-08 11:31:41 --> Loader Class Initialized
INFO - 2023-12-08 11:31:41 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:41 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:41 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:41 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:41 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:41 --> Controller Class Initialized
INFO - 2023-12-08 11:31:47 --> Config Class Initialized
INFO - 2023-12-08 11:31:47 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:47 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:47 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:47 --> URI Class Initialized
INFO - 2023-12-08 11:31:47 --> Router Class Initialized
INFO - 2023-12-08 11:31:47 --> Output Class Initialized
INFO - 2023-12-08 11:31:47 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:47 --> Input Class Initialized
INFO - 2023-12-08 11:31:47 --> Language Class Initialized
INFO - 2023-12-08 11:31:47 --> Language Class Initialized
INFO - 2023-12-08 11:31:47 --> Config Class Initialized
INFO - 2023-12-08 11:31:47 --> Loader Class Initialized
INFO - 2023-12-08 11:31:47 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:47 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:47 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:47 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:47 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:47 --> Controller Class Initialized
INFO - 2023-12-08 11:31:47 --> Final output sent to browser
DEBUG - 2023-12-08 11:31:47 --> Total execution time: 0.1284
INFO - 2023-12-08 11:31:50 --> Config Class Initialized
INFO - 2023-12-08 11:31:50 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:50 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:50 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:50 --> URI Class Initialized
INFO - 2023-12-08 11:31:50 --> Router Class Initialized
INFO - 2023-12-08 11:31:50 --> Output Class Initialized
INFO - 2023-12-08 11:31:50 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:50 --> Input Class Initialized
INFO - 2023-12-08 11:31:50 --> Language Class Initialized
INFO - 2023-12-08 11:31:50 --> Language Class Initialized
INFO - 2023-12-08 11:31:50 --> Config Class Initialized
INFO - 2023-12-08 11:31:50 --> Loader Class Initialized
INFO - 2023-12-08 11:31:50 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:50 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:50 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:50 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:50 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:50 --> Controller Class Initialized
INFO - 2023-12-08 11:31:50 --> Final output sent to browser
DEBUG - 2023-12-08 11:31:50 --> Total execution time: 0.0395
INFO - 2023-12-08 11:31:52 --> Config Class Initialized
INFO - 2023-12-08 11:31:52 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:52 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:52 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:52 --> URI Class Initialized
INFO - 2023-12-08 11:31:52 --> Router Class Initialized
INFO - 2023-12-08 11:31:52 --> Output Class Initialized
INFO - 2023-12-08 11:31:52 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:52 --> Input Class Initialized
INFO - 2023-12-08 11:31:52 --> Language Class Initialized
INFO - 2023-12-08 11:31:52 --> Language Class Initialized
INFO - 2023-12-08 11:31:52 --> Config Class Initialized
INFO - 2023-12-08 11:31:52 --> Loader Class Initialized
INFO - 2023-12-08 11:31:52 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:52 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:52 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:52 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:52 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:52 --> Controller Class Initialized
INFO - 2023-12-08 11:31:55 --> Config Class Initialized
INFO - 2023-12-08 11:31:55 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:55 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:55 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:55 --> URI Class Initialized
INFO - 2023-12-08 11:31:55 --> Router Class Initialized
INFO - 2023-12-08 11:31:55 --> Output Class Initialized
INFO - 2023-12-08 11:31:55 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:55 --> Input Class Initialized
INFO - 2023-12-08 11:31:55 --> Language Class Initialized
INFO - 2023-12-08 11:31:55 --> Language Class Initialized
INFO - 2023-12-08 11:31:55 --> Config Class Initialized
INFO - 2023-12-08 11:31:55 --> Loader Class Initialized
INFO - 2023-12-08 11:31:55 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:55 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:55 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:55 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:55 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:55 --> Controller Class Initialized
DEBUG - 2023-12-08 11:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 11:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 11:31:55 --> Final output sent to browser
DEBUG - 2023-12-08 11:31:55 --> Total execution time: 0.0396
INFO - 2023-12-08 11:31:55 --> Config Class Initialized
INFO - 2023-12-08 11:31:55 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:55 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:55 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:55 --> URI Class Initialized
INFO - 2023-12-08 11:31:55 --> Router Class Initialized
INFO - 2023-12-08 11:31:55 --> Output Class Initialized
INFO - 2023-12-08 11:31:55 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:55 --> Input Class Initialized
INFO - 2023-12-08 11:31:55 --> Language Class Initialized
INFO - 2023-12-08 11:31:55 --> Language Class Initialized
INFO - 2023-12-08 11:31:55 --> Config Class Initialized
INFO - 2023-12-08 11:31:55 --> Loader Class Initialized
INFO - 2023-12-08 11:31:55 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:55 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:55 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:55 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:55 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:55 --> Controller Class Initialized
INFO - 2023-12-08 11:31:59 --> Config Class Initialized
INFO - 2023-12-08 11:31:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:31:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:31:59 --> Utf8 Class Initialized
INFO - 2023-12-08 11:31:59 --> URI Class Initialized
INFO - 2023-12-08 11:31:59 --> Router Class Initialized
INFO - 2023-12-08 11:31:59 --> Output Class Initialized
INFO - 2023-12-08 11:31:59 --> Security Class Initialized
DEBUG - 2023-12-08 11:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:31:59 --> Input Class Initialized
INFO - 2023-12-08 11:31:59 --> Language Class Initialized
INFO - 2023-12-08 11:31:59 --> Language Class Initialized
INFO - 2023-12-08 11:31:59 --> Config Class Initialized
INFO - 2023-12-08 11:31:59 --> Loader Class Initialized
INFO - 2023-12-08 11:31:59 --> Helper loaded: url_helper
INFO - 2023-12-08 11:31:59 --> Helper loaded: file_helper
INFO - 2023-12-08 11:31:59 --> Helper loaded: form_helper
INFO - 2023-12-08 11:31:59 --> Helper loaded: my_helper
INFO - 2023-12-08 11:31:59 --> Database Driver Class Initialized
INFO - 2023-12-08 11:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:31:59 --> Controller Class Initialized
INFO - 2023-12-08 11:31:59 --> Final output sent to browser
DEBUG - 2023-12-08 11:31:59 --> Total execution time: 0.1113
INFO - 2023-12-08 11:32:09 --> Config Class Initialized
INFO - 2023-12-08 11:32:09 --> Hooks Class Initialized
DEBUG - 2023-12-08 11:32:09 --> UTF-8 Support Enabled
INFO - 2023-12-08 11:32:09 --> Utf8 Class Initialized
INFO - 2023-12-08 11:32:09 --> URI Class Initialized
INFO - 2023-12-08 11:32:09 --> Router Class Initialized
INFO - 2023-12-08 11:32:09 --> Output Class Initialized
INFO - 2023-12-08 11:32:09 --> Security Class Initialized
DEBUG - 2023-12-08 11:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 11:32:09 --> Input Class Initialized
INFO - 2023-12-08 11:32:09 --> Language Class Initialized
INFO - 2023-12-08 11:32:09 --> Language Class Initialized
INFO - 2023-12-08 11:32:09 --> Config Class Initialized
INFO - 2023-12-08 11:32:09 --> Loader Class Initialized
INFO - 2023-12-08 11:32:09 --> Helper loaded: url_helper
INFO - 2023-12-08 11:32:09 --> Helper loaded: file_helper
INFO - 2023-12-08 11:32:09 --> Helper loaded: form_helper
INFO - 2023-12-08 11:32:09 --> Helper loaded: my_helper
INFO - 2023-12-08 11:32:09 --> Database Driver Class Initialized
INFO - 2023-12-08 11:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 11:32:09 --> Controller Class Initialized
INFO - 2023-12-08 12:03:11 --> Config Class Initialized
INFO - 2023-12-08 12:03:11 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:11 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:11 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:11 --> URI Class Initialized
INFO - 2023-12-08 12:03:11 --> Router Class Initialized
INFO - 2023-12-08 12:03:11 --> Output Class Initialized
INFO - 2023-12-08 12:03:11 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:11 --> Input Class Initialized
INFO - 2023-12-08 12:03:11 --> Language Class Initialized
INFO - 2023-12-08 12:03:11 --> Language Class Initialized
INFO - 2023-12-08 12:03:11 --> Config Class Initialized
INFO - 2023-12-08 12:03:11 --> Loader Class Initialized
INFO - 2023-12-08 12:03:11 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:11 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:11 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:11 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:11 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:11 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 12:03:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:11 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:11 --> Total execution time: 0.0785
INFO - 2023-12-08 12:03:12 --> Config Class Initialized
INFO - 2023-12-08 12:03:12 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:12 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:12 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:12 --> URI Class Initialized
INFO - 2023-12-08 12:03:12 --> Router Class Initialized
INFO - 2023-12-08 12:03:12 --> Output Class Initialized
INFO - 2023-12-08 12:03:12 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:12 --> Input Class Initialized
INFO - 2023-12-08 12:03:12 --> Language Class Initialized
INFO - 2023-12-08 12:03:12 --> Language Class Initialized
INFO - 2023-12-08 12:03:12 --> Config Class Initialized
INFO - 2023-12-08 12:03:12 --> Loader Class Initialized
INFO - 2023-12-08 12:03:12 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:12 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:12 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:12 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:12 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:12 --> Controller Class Initialized
INFO - 2023-12-08 12:03:16 --> Config Class Initialized
INFO - 2023-12-08 12:03:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:16 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:16 --> URI Class Initialized
DEBUG - 2023-12-08 12:03:16 --> No URI present. Default controller set.
INFO - 2023-12-08 12:03:16 --> Router Class Initialized
INFO - 2023-12-08 12:03:16 --> Output Class Initialized
INFO - 2023-12-08 12:03:16 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:16 --> Input Class Initialized
INFO - 2023-12-08 12:03:16 --> Language Class Initialized
INFO - 2023-12-08 12:03:16 --> Language Class Initialized
INFO - 2023-12-08 12:03:16 --> Config Class Initialized
INFO - 2023-12-08 12:03:16 --> Loader Class Initialized
INFO - 2023-12-08 12:03:16 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:16 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:16 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:16 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:16 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:16 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 12:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:16 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:16 --> Total execution time: 0.0491
INFO - 2023-12-08 12:03:17 --> Config Class Initialized
INFO - 2023-12-08 12:03:17 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:17 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:17 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:17 --> URI Class Initialized
INFO - 2023-12-08 12:03:17 --> Router Class Initialized
INFO - 2023-12-08 12:03:17 --> Output Class Initialized
INFO - 2023-12-08 12:03:17 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:17 --> Input Class Initialized
INFO - 2023-12-08 12:03:17 --> Language Class Initialized
INFO - 2023-12-08 12:03:17 --> Language Class Initialized
INFO - 2023-12-08 12:03:17 --> Config Class Initialized
INFO - 2023-12-08 12:03:17 --> Loader Class Initialized
INFO - 2023-12-08 12:03:17 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:17 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:17 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:17 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:17 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:17 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 12:03:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:17 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:17 --> Total execution time: 0.0677
INFO - 2023-12-08 12:03:20 --> Config Class Initialized
INFO - 2023-12-08 12:03:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:20 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:20 --> URI Class Initialized
INFO - 2023-12-08 12:03:20 --> Router Class Initialized
INFO - 2023-12-08 12:03:20 --> Output Class Initialized
INFO - 2023-12-08 12:03:20 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:20 --> Input Class Initialized
INFO - 2023-12-08 12:03:20 --> Language Class Initialized
INFO - 2023-12-08 12:03:20 --> Language Class Initialized
INFO - 2023-12-08 12:03:20 --> Config Class Initialized
INFO - 2023-12-08 12:03:20 --> Loader Class Initialized
INFO - 2023-12-08 12:03:20 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:20 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:20 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:20 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:20 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:20 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 12:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:20 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:20 --> Total execution time: 0.0784
INFO - 2023-12-08 12:03:23 --> Config Class Initialized
INFO - 2023-12-08 12:03:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:23 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:23 --> URI Class Initialized
DEBUG - 2023-12-08 12:03:23 --> No URI present. Default controller set.
INFO - 2023-12-08 12:03:23 --> Router Class Initialized
INFO - 2023-12-08 12:03:23 --> Output Class Initialized
INFO - 2023-12-08 12:03:23 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:23 --> Input Class Initialized
INFO - 2023-12-08 12:03:23 --> Language Class Initialized
INFO - 2023-12-08 12:03:23 --> Language Class Initialized
INFO - 2023-12-08 12:03:23 --> Config Class Initialized
INFO - 2023-12-08 12:03:23 --> Loader Class Initialized
INFO - 2023-12-08 12:03:23 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:23 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:23 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:23 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:23 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:23 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 12:03:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:23 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:23 --> Total execution time: 0.0742
INFO - 2023-12-08 12:03:28 --> Config Class Initialized
INFO - 2023-12-08 12:03:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:28 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:28 --> URI Class Initialized
INFO - 2023-12-08 12:03:28 --> Router Class Initialized
INFO - 2023-12-08 12:03:28 --> Output Class Initialized
INFO - 2023-12-08 12:03:28 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:28 --> Input Class Initialized
INFO - 2023-12-08 12:03:28 --> Language Class Initialized
INFO - 2023-12-08 12:03:28 --> Language Class Initialized
INFO - 2023-12-08 12:03:28 --> Config Class Initialized
INFO - 2023-12-08 12:03:28 --> Loader Class Initialized
INFO - 2023-12-08 12:03:28 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:28 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:28 --> Controller Class Initialized
INFO - 2023-12-08 12:03:28 --> Helper loaded: cookie_helper
INFO - 2023-12-08 12:03:28 --> Config Class Initialized
INFO - 2023-12-08 12:03:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:28 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:28 --> URI Class Initialized
INFO - 2023-12-08 12:03:28 --> Router Class Initialized
INFO - 2023-12-08 12:03:28 --> Output Class Initialized
INFO - 2023-12-08 12:03:28 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:28 --> Input Class Initialized
INFO - 2023-12-08 12:03:28 --> Language Class Initialized
INFO - 2023-12-08 12:03:28 --> Language Class Initialized
INFO - 2023-12-08 12:03:28 --> Config Class Initialized
INFO - 2023-12-08 12:03:28 --> Loader Class Initialized
INFO - 2023-12-08 12:03:28 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:28 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:28 --> Controller Class Initialized
INFO - 2023-12-08 12:03:28 --> Config Class Initialized
INFO - 2023-12-08 12:03:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:28 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:28 --> URI Class Initialized
INFO - 2023-12-08 12:03:28 --> Router Class Initialized
INFO - 2023-12-08 12:03:28 --> Output Class Initialized
INFO - 2023-12-08 12:03:28 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:28 --> Input Class Initialized
INFO - 2023-12-08 12:03:28 --> Language Class Initialized
INFO - 2023-12-08 12:03:28 --> Language Class Initialized
INFO - 2023-12-08 12:03:28 --> Config Class Initialized
INFO - 2023-12-08 12:03:28 --> Loader Class Initialized
INFO - 2023-12-08 12:03:28 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:28 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:28 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:28 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 12:03:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:28 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:28 --> Total execution time: 0.0450
INFO - 2023-12-08 12:03:29 --> Config Class Initialized
INFO - 2023-12-08 12:03:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:29 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:29 --> URI Class Initialized
INFO - 2023-12-08 12:03:29 --> Router Class Initialized
INFO - 2023-12-08 12:03:29 --> Output Class Initialized
INFO - 2023-12-08 12:03:29 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:29 --> Input Class Initialized
INFO - 2023-12-08 12:03:29 --> Language Class Initialized
INFO - 2023-12-08 12:03:29 --> Language Class Initialized
INFO - 2023-12-08 12:03:29 --> Config Class Initialized
INFO - 2023-12-08 12:03:29 --> Loader Class Initialized
INFO - 2023-12-08 12:03:29 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:29 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:29 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:29 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:29 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:29 --> Controller Class Initialized
INFO - 2023-12-08 12:03:29 --> Helper loaded: cookie_helper
INFO - 2023-12-08 12:03:29 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:29 --> Total execution time: 0.0414
INFO - 2023-12-08 12:03:29 --> Config Class Initialized
INFO - 2023-12-08 12:03:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:29 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:29 --> URI Class Initialized
INFO - 2023-12-08 12:03:29 --> Router Class Initialized
INFO - 2023-12-08 12:03:29 --> Output Class Initialized
INFO - 2023-12-08 12:03:29 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:29 --> Input Class Initialized
INFO - 2023-12-08 12:03:29 --> Language Class Initialized
INFO - 2023-12-08 12:03:29 --> Language Class Initialized
INFO - 2023-12-08 12:03:29 --> Config Class Initialized
INFO - 2023-12-08 12:03:29 --> Loader Class Initialized
INFO - 2023-12-08 12:03:29 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:29 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:29 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:29 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:30 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:30 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 12:03:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:30 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:30 --> Total execution time: 0.0908
INFO - 2023-12-08 12:03:31 --> Config Class Initialized
INFO - 2023-12-08 12:03:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:31 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:31 --> URI Class Initialized
INFO - 2023-12-08 12:03:31 --> Router Class Initialized
INFO - 2023-12-08 12:03:31 --> Output Class Initialized
INFO - 2023-12-08 12:03:31 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:31 --> Input Class Initialized
INFO - 2023-12-08 12:03:31 --> Language Class Initialized
INFO - 2023-12-08 12:03:31 --> Language Class Initialized
INFO - 2023-12-08 12:03:31 --> Config Class Initialized
INFO - 2023-12-08 12:03:31 --> Loader Class Initialized
INFO - 2023-12-08 12:03:31 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:31 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:31 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:31 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:31 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:31 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 12:03:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:31 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:31 --> Total execution time: 0.0727
INFO - 2023-12-08 12:03:34 --> Config Class Initialized
INFO - 2023-12-08 12:03:34 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:34 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:34 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:34 --> URI Class Initialized
INFO - 2023-12-08 12:03:34 --> Router Class Initialized
INFO - 2023-12-08 12:03:34 --> Output Class Initialized
INFO - 2023-12-08 12:03:34 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:34 --> Input Class Initialized
INFO - 2023-12-08 12:03:34 --> Language Class Initialized
INFO - 2023-12-08 12:03:34 --> Language Class Initialized
INFO - 2023-12-08 12:03:34 --> Config Class Initialized
INFO - 2023-12-08 12:03:34 --> Loader Class Initialized
INFO - 2023-12-08 12:03:34 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:34 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:34 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:34 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:34 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:34 --> Controller Class Initialized
DEBUG - 2023-12-08 12:03:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 12:03:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 12:03:34 --> Final output sent to browser
DEBUG - 2023-12-08 12:03:34 --> Total execution time: 0.0671
INFO - 2023-12-08 12:03:34 --> Config Class Initialized
INFO - 2023-12-08 12:03:34 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:03:34 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:03:34 --> Utf8 Class Initialized
INFO - 2023-12-08 12:03:34 --> URI Class Initialized
INFO - 2023-12-08 12:03:34 --> Router Class Initialized
INFO - 2023-12-08 12:03:34 --> Output Class Initialized
INFO - 2023-12-08 12:03:34 --> Security Class Initialized
DEBUG - 2023-12-08 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:03:34 --> Input Class Initialized
INFO - 2023-12-08 12:03:34 --> Language Class Initialized
INFO - 2023-12-08 12:03:34 --> Language Class Initialized
INFO - 2023-12-08 12:03:34 --> Config Class Initialized
INFO - 2023-12-08 12:03:34 --> Loader Class Initialized
INFO - 2023-12-08 12:03:34 --> Helper loaded: url_helper
INFO - 2023-12-08 12:03:34 --> Helper loaded: file_helper
INFO - 2023-12-08 12:03:34 --> Helper loaded: form_helper
INFO - 2023-12-08 12:03:34 --> Helper loaded: my_helper
INFO - 2023-12-08 12:03:34 --> Database Driver Class Initialized
INFO - 2023-12-08 12:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:03:34 --> Controller Class Initialized
INFO - 2023-12-08 12:06:46 --> Config Class Initialized
INFO - 2023-12-08 12:06:46 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:06:46 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:06:46 --> Utf8 Class Initialized
INFO - 2023-12-08 12:06:46 --> URI Class Initialized
INFO - 2023-12-08 12:06:46 --> Router Class Initialized
INFO - 2023-12-08 12:06:46 --> Output Class Initialized
INFO - 2023-12-08 12:06:46 --> Security Class Initialized
DEBUG - 2023-12-08 12:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:06:46 --> Input Class Initialized
INFO - 2023-12-08 12:06:46 --> Language Class Initialized
INFO - 2023-12-08 12:06:46 --> Language Class Initialized
INFO - 2023-12-08 12:06:46 --> Config Class Initialized
INFO - 2023-12-08 12:06:46 --> Loader Class Initialized
INFO - 2023-12-08 12:06:46 --> Helper loaded: url_helper
INFO - 2023-12-08 12:06:46 --> Helper loaded: file_helper
INFO - 2023-12-08 12:06:46 --> Helper loaded: form_helper
INFO - 2023-12-08 12:06:46 --> Helper loaded: my_helper
INFO - 2023-12-08 12:06:46 --> Database Driver Class Initialized
INFO - 2023-12-08 12:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:06:46 --> Controller Class Initialized
INFO - 2023-12-08 12:06:46 --> Final output sent to browser
DEBUG - 2023-12-08 12:06:46 --> Total execution time: 0.0927
INFO - 2023-12-08 12:07:09 --> Config Class Initialized
INFO - 2023-12-08 12:07:09 --> Hooks Class Initialized
DEBUG - 2023-12-08 12:07:09 --> UTF-8 Support Enabled
INFO - 2023-12-08 12:07:09 --> Utf8 Class Initialized
INFO - 2023-12-08 12:07:09 --> URI Class Initialized
INFO - 2023-12-08 12:07:09 --> Router Class Initialized
INFO - 2023-12-08 12:07:09 --> Output Class Initialized
INFO - 2023-12-08 12:07:09 --> Security Class Initialized
DEBUG - 2023-12-08 12:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 12:07:09 --> Input Class Initialized
INFO - 2023-12-08 12:07:09 --> Language Class Initialized
INFO - 2023-12-08 12:07:09 --> Language Class Initialized
INFO - 2023-12-08 12:07:09 --> Config Class Initialized
INFO - 2023-12-08 12:07:09 --> Loader Class Initialized
INFO - 2023-12-08 12:07:09 --> Helper loaded: url_helper
INFO - 2023-12-08 12:07:09 --> Helper loaded: file_helper
INFO - 2023-12-08 12:07:09 --> Helper loaded: form_helper
INFO - 2023-12-08 12:07:09 --> Helper loaded: my_helper
INFO - 2023-12-08 12:07:09 --> Database Driver Class Initialized
INFO - 2023-12-08 12:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 12:07:09 --> Controller Class Initialized
INFO - 2023-12-08 13:48:03 --> Config Class Initialized
INFO - 2023-12-08 13:48:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:48:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:48:03 --> Utf8 Class Initialized
INFO - 2023-12-08 13:48:03 --> URI Class Initialized
INFO - 2023-12-08 13:48:03 --> Router Class Initialized
INFO - 2023-12-08 13:48:03 --> Output Class Initialized
INFO - 2023-12-08 13:48:03 --> Security Class Initialized
DEBUG - 2023-12-08 13:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:48:03 --> Input Class Initialized
INFO - 2023-12-08 13:48:03 --> Language Class Initialized
INFO - 2023-12-08 13:48:03 --> Language Class Initialized
INFO - 2023-12-08 13:48:03 --> Config Class Initialized
INFO - 2023-12-08 13:48:03 --> Loader Class Initialized
INFO - 2023-12-08 13:48:03 --> Helper loaded: url_helper
INFO - 2023-12-08 13:48:03 --> Helper loaded: file_helper
INFO - 2023-12-08 13:48:03 --> Helper loaded: form_helper
INFO - 2023-12-08 13:48:03 --> Helper loaded: my_helper
INFO - 2023-12-08 13:48:03 --> Database Driver Class Initialized
INFO - 2023-12-08 13:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:48:03 --> Controller Class Initialized
DEBUG - 2023-12-08 13:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 13:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 13:48:03 --> Final output sent to browser
DEBUG - 2023-12-08 13:48:03 --> Total execution time: 0.1017
INFO - 2023-12-08 13:48:04 --> Config Class Initialized
INFO - 2023-12-08 13:48:04 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:48:04 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:48:04 --> Utf8 Class Initialized
INFO - 2023-12-08 13:48:04 --> URI Class Initialized
INFO - 2023-12-08 13:48:04 --> Router Class Initialized
INFO - 2023-12-08 13:48:04 --> Output Class Initialized
INFO - 2023-12-08 13:48:04 --> Security Class Initialized
DEBUG - 2023-12-08 13:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:48:04 --> Input Class Initialized
INFO - 2023-12-08 13:48:04 --> Language Class Initialized
INFO - 2023-12-08 13:48:04 --> Language Class Initialized
INFO - 2023-12-08 13:48:04 --> Config Class Initialized
INFO - 2023-12-08 13:48:04 --> Loader Class Initialized
INFO - 2023-12-08 13:48:04 --> Helper loaded: url_helper
INFO - 2023-12-08 13:48:04 --> Helper loaded: file_helper
INFO - 2023-12-08 13:48:04 --> Helper loaded: form_helper
INFO - 2023-12-08 13:48:04 --> Helper loaded: my_helper
INFO - 2023-12-08 13:48:04 --> Database Driver Class Initialized
INFO - 2023-12-08 13:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:48:04 --> Controller Class Initialized
INFO - 2023-12-08 13:49:51 --> Config Class Initialized
INFO - 2023-12-08 13:49:51 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:49:51 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:49:51 --> Utf8 Class Initialized
INFO - 2023-12-08 13:49:51 --> URI Class Initialized
INFO - 2023-12-08 13:49:51 --> Router Class Initialized
INFO - 2023-12-08 13:49:51 --> Output Class Initialized
INFO - 2023-12-08 13:49:51 --> Security Class Initialized
DEBUG - 2023-12-08 13:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:49:51 --> Input Class Initialized
INFO - 2023-12-08 13:49:51 --> Language Class Initialized
INFO - 2023-12-08 13:49:51 --> Language Class Initialized
INFO - 2023-12-08 13:49:51 --> Config Class Initialized
INFO - 2023-12-08 13:49:51 --> Loader Class Initialized
INFO - 2023-12-08 13:49:51 --> Helper loaded: url_helper
INFO - 2023-12-08 13:49:51 --> Helper loaded: file_helper
INFO - 2023-12-08 13:49:51 --> Helper loaded: form_helper
INFO - 2023-12-08 13:49:51 --> Helper loaded: my_helper
INFO - 2023-12-08 13:49:51 --> Database Driver Class Initialized
INFO - 2023-12-08 13:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:49:51 --> Controller Class Initialized
DEBUG - 2023-12-08 13:49:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 13:49:52 --> Final output sent to browser
DEBUG - 2023-12-08 13:49:52 --> Total execution time: 0.1979
INFO - 2023-12-08 13:53:19 --> Config Class Initialized
INFO - 2023-12-08 13:53:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:53:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:53:19 --> Utf8 Class Initialized
INFO - 2023-12-08 13:53:19 --> URI Class Initialized
INFO - 2023-12-08 13:53:19 --> Router Class Initialized
INFO - 2023-12-08 13:53:19 --> Output Class Initialized
INFO - 2023-12-08 13:53:19 --> Security Class Initialized
DEBUG - 2023-12-08 13:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:53:19 --> Input Class Initialized
INFO - 2023-12-08 13:53:19 --> Language Class Initialized
INFO - 2023-12-08 13:53:19 --> Language Class Initialized
INFO - 2023-12-08 13:53:19 --> Config Class Initialized
INFO - 2023-12-08 13:53:19 --> Loader Class Initialized
INFO - 2023-12-08 13:53:19 --> Helper loaded: url_helper
INFO - 2023-12-08 13:53:19 --> Helper loaded: file_helper
INFO - 2023-12-08 13:53:19 --> Helper loaded: form_helper
INFO - 2023-12-08 13:53:19 --> Helper loaded: my_helper
INFO - 2023-12-08 13:53:19 --> Database Driver Class Initialized
INFO - 2023-12-08 13:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:53:19 --> Controller Class Initialized
DEBUG - 2023-12-08 13:53:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 13:53:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 13:53:19 --> Final output sent to browser
DEBUG - 2023-12-08 13:53:19 --> Total execution time: 0.0778
INFO - 2023-12-08 13:53:25 --> Config Class Initialized
INFO - 2023-12-08 13:53:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:53:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:53:25 --> Utf8 Class Initialized
INFO - 2023-12-08 13:53:25 --> URI Class Initialized
INFO - 2023-12-08 13:53:25 --> Router Class Initialized
INFO - 2023-12-08 13:53:25 --> Output Class Initialized
INFO - 2023-12-08 13:53:25 --> Security Class Initialized
DEBUG - 2023-12-08 13:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:53:25 --> Input Class Initialized
INFO - 2023-12-08 13:53:25 --> Language Class Initialized
INFO - 2023-12-08 13:53:25 --> Language Class Initialized
INFO - 2023-12-08 13:53:25 --> Config Class Initialized
INFO - 2023-12-08 13:53:25 --> Loader Class Initialized
INFO - 2023-12-08 13:53:25 --> Helper loaded: url_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: file_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: form_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: my_helper
INFO - 2023-12-08 13:53:25 --> Database Driver Class Initialized
INFO - 2023-12-08 13:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:53:25 --> Controller Class Initialized
INFO - 2023-12-08 13:53:25 --> Config Class Initialized
INFO - 2023-12-08 13:53:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:53:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:53:25 --> Utf8 Class Initialized
INFO - 2023-12-08 13:53:25 --> URI Class Initialized
INFO - 2023-12-08 13:53:25 --> Router Class Initialized
INFO - 2023-12-08 13:53:25 --> Output Class Initialized
INFO - 2023-12-08 13:53:25 --> Security Class Initialized
DEBUG - 2023-12-08 13:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:53:25 --> Input Class Initialized
INFO - 2023-12-08 13:53:25 --> Language Class Initialized
INFO - 2023-12-08 13:53:25 --> Language Class Initialized
INFO - 2023-12-08 13:53:25 --> Config Class Initialized
INFO - 2023-12-08 13:53:25 --> Loader Class Initialized
INFO - 2023-12-08 13:53:25 --> Helper loaded: url_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: file_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: form_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: my_helper
INFO - 2023-12-08 13:53:25 --> Database Driver Class Initialized
INFO - 2023-12-08 13:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:53:25 --> Controller Class Initialized
DEBUG - 2023-12-08 13:53:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 13:53:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 13:53:25 --> Final output sent to browser
DEBUG - 2023-12-08 13:53:25 --> Total execution time: 0.0736
INFO - 2023-12-08 13:53:25 --> Config Class Initialized
INFO - 2023-12-08 13:53:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:53:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:53:25 --> Utf8 Class Initialized
INFO - 2023-12-08 13:53:25 --> URI Class Initialized
INFO - 2023-12-08 13:53:25 --> Router Class Initialized
INFO - 2023-12-08 13:53:25 --> Output Class Initialized
INFO - 2023-12-08 13:53:25 --> Security Class Initialized
DEBUG - 2023-12-08 13:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:53:25 --> Input Class Initialized
INFO - 2023-12-08 13:53:25 --> Language Class Initialized
INFO - 2023-12-08 13:53:25 --> Language Class Initialized
INFO - 2023-12-08 13:53:25 --> Config Class Initialized
INFO - 2023-12-08 13:53:25 --> Loader Class Initialized
INFO - 2023-12-08 13:53:25 --> Helper loaded: url_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: file_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: form_helper
INFO - 2023-12-08 13:53:25 --> Helper loaded: my_helper
INFO - 2023-12-08 13:53:25 --> Database Driver Class Initialized
INFO - 2023-12-08 13:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:53:25 --> Controller Class Initialized
INFO - 2023-12-08 13:53:28 --> Config Class Initialized
INFO - 2023-12-08 13:53:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:53:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:53:28 --> Utf8 Class Initialized
INFO - 2023-12-08 13:53:28 --> URI Class Initialized
INFO - 2023-12-08 13:53:28 --> Router Class Initialized
INFO - 2023-12-08 13:53:28 --> Output Class Initialized
INFO - 2023-12-08 13:53:28 --> Security Class Initialized
DEBUG - 2023-12-08 13:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:53:28 --> Input Class Initialized
INFO - 2023-12-08 13:53:28 --> Language Class Initialized
INFO - 2023-12-08 13:53:28 --> Language Class Initialized
INFO - 2023-12-08 13:53:28 --> Config Class Initialized
INFO - 2023-12-08 13:53:28 --> Loader Class Initialized
INFO - 2023-12-08 13:53:28 --> Helper loaded: url_helper
INFO - 2023-12-08 13:53:28 --> Helper loaded: file_helper
INFO - 2023-12-08 13:53:28 --> Helper loaded: form_helper
INFO - 2023-12-08 13:53:28 --> Helper loaded: my_helper
INFO - 2023-12-08 13:53:28 --> Database Driver Class Initialized
INFO - 2023-12-08 13:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:53:28 --> Controller Class Initialized
DEBUG - 2023-12-08 13:53:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 13:53:28 --> Final output sent to browser
DEBUG - 2023-12-08 13:53:28 --> Total execution time: 0.1134
INFO - 2023-12-08 13:56:31 --> Config Class Initialized
INFO - 2023-12-08 13:56:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:56:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:56:31 --> Utf8 Class Initialized
INFO - 2023-12-08 13:56:31 --> URI Class Initialized
INFO - 2023-12-08 13:56:31 --> Router Class Initialized
INFO - 2023-12-08 13:56:31 --> Output Class Initialized
INFO - 2023-12-08 13:56:31 --> Security Class Initialized
DEBUG - 2023-12-08 13:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:56:31 --> Input Class Initialized
INFO - 2023-12-08 13:56:31 --> Language Class Initialized
INFO - 2023-12-08 13:56:31 --> Language Class Initialized
INFO - 2023-12-08 13:56:31 --> Config Class Initialized
INFO - 2023-12-08 13:56:31 --> Loader Class Initialized
INFO - 2023-12-08 13:56:31 --> Helper loaded: url_helper
INFO - 2023-12-08 13:56:31 --> Helper loaded: file_helper
INFO - 2023-12-08 13:56:31 --> Helper loaded: form_helper
INFO - 2023-12-08 13:56:31 --> Helper loaded: my_helper
INFO - 2023-12-08 13:56:31 --> Database Driver Class Initialized
INFO - 2023-12-08 13:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:56:31 --> Controller Class Initialized
DEBUG - 2023-12-08 13:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 13:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 13:56:31 --> Final output sent to browser
DEBUG - 2023-12-08 13:56:31 --> Total execution time: 0.0549
INFO - 2023-12-08 13:56:36 --> Config Class Initialized
INFO - 2023-12-08 13:56:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:56:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:56:36 --> Utf8 Class Initialized
INFO - 2023-12-08 13:56:36 --> URI Class Initialized
INFO - 2023-12-08 13:56:36 --> Router Class Initialized
INFO - 2023-12-08 13:56:36 --> Output Class Initialized
INFO - 2023-12-08 13:56:36 --> Security Class Initialized
DEBUG - 2023-12-08 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:56:36 --> Input Class Initialized
INFO - 2023-12-08 13:56:36 --> Language Class Initialized
INFO - 2023-12-08 13:56:36 --> Language Class Initialized
INFO - 2023-12-08 13:56:36 --> Config Class Initialized
INFO - 2023-12-08 13:56:36 --> Loader Class Initialized
INFO - 2023-12-08 13:56:36 --> Helper loaded: url_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: file_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: form_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: my_helper
INFO - 2023-12-08 13:56:36 --> Database Driver Class Initialized
INFO - 2023-12-08 13:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:56:36 --> Controller Class Initialized
INFO - 2023-12-08 13:56:36 --> Config Class Initialized
INFO - 2023-12-08 13:56:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:56:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:56:36 --> Utf8 Class Initialized
INFO - 2023-12-08 13:56:36 --> URI Class Initialized
INFO - 2023-12-08 13:56:36 --> Router Class Initialized
INFO - 2023-12-08 13:56:36 --> Output Class Initialized
INFO - 2023-12-08 13:56:36 --> Security Class Initialized
DEBUG - 2023-12-08 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:56:36 --> Input Class Initialized
INFO - 2023-12-08 13:56:36 --> Language Class Initialized
INFO - 2023-12-08 13:56:36 --> Language Class Initialized
INFO - 2023-12-08 13:56:36 --> Config Class Initialized
INFO - 2023-12-08 13:56:36 --> Loader Class Initialized
INFO - 2023-12-08 13:56:36 --> Helper loaded: url_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: file_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: form_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: my_helper
INFO - 2023-12-08 13:56:36 --> Database Driver Class Initialized
INFO - 2023-12-08 13:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:56:36 --> Controller Class Initialized
DEBUG - 2023-12-08 13:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 13:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 13:56:36 --> Final output sent to browser
DEBUG - 2023-12-08 13:56:36 --> Total execution time: 0.0681
INFO - 2023-12-08 13:56:36 --> Config Class Initialized
INFO - 2023-12-08 13:56:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:56:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:56:36 --> Utf8 Class Initialized
INFO - 2023-12-08 13:56:36 --> URI Class Initialized
INFO - 2023-12-08 13:56:36 --> Router Class Initialized
INFO - 2023-12-08 13:56:36 --> Output Class Initialized
INFO - 2023-12-08 13:56:36 --> Security Class Initialized
DEBUG - 2023-12-08 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:56:36 --> Input Class Initialized
INFO - 2023-12-08 13:56:36 --> Language Class Initialized
INFO - 2023-12-08 13:56:36 --> Language Class Initialized
INFO - 2023-12-08 13:56:36 --> Config Class Initialized
INFO - 2023-12-08 13:56:36 --> Loader Class Initialized
INFO - 2023-12-08 13:56:36 --> Helper loaded: url_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: file_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: form_helper
INFO - 2023-12-08 13:56:36 --> Helper loaded: my_helper
INFO - 2023-12-08 13:56:36 --> Database Driver Class Initialized
INFO - 2023-12-08 13:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:56:36 --> Controller Class Initialized
INFO - 2023-12-08 13:56:38 --> Config Class Initialized
INFO - 2023-12-08 13:56:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 13:56:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 13:56:38 --> Utf8 Class Initialized
INFO - 2023-12-08 13:56:38 --> URI Class Initialized
INFO - 2023-12-08 13:56:38 --> Router Class Initialized
INFO - 2023-12-08 13:56:38 --> Output Class Initialized
INFO - 2023-12-08 13:56:38 --> Security Class Initialized
DEBUG - 2023-12-08 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 13:56:38 --> Input Class Initialized
INFO - 2023-12-08 13:56:38 --> Language Class Initialized
INFO - 2023-12-08 13:56:38 --> Language Class Initialized
INFO - 2023-12-08 13:56:38 --> Config Class Initialized
INFO - 2023-12-08 13:56:38 --> Loader Class Initialized
INFO - 2023-12-08 13:56:38 --> Helper loaded: url_helper
INFO - 2023-12-08 13:56:38 --> Helper loaded: file_helper
INFO - 2023-12-08 13:56:38 --> Helper loaded: form_helper
INFO - 2023-12-08 13:56:38 --> Helper loaded: my_helper
INFO - 2023-12-08 13:56:38 --> Database Driver Class Initialized
INFO - 2023-12-08 13:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 13:56:38 --> Controller Class Initialized
DEBUG - 2023-12-08 13:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 13:56:38 --> Final output sent to browser
DEBUG - 2023-12-08 13:56:38 --> Total execution time: 0.2099
INFO - 2023-12-08 14:04:11 --> Config Class Initialized
INFO - 2023-12-08 14:04:11 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:11 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:11 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:11 --> URI Class Initialized
INFO - 2023-12-08 14:04:11 --> Router Class Initialized
INFO - 2023-12-08 14:04:11 --> Output Class Initialized
INFO - 2023-12-08 14:04:11 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:11 --> Input Class Initialized
INFO - 2023-12-08 14:04:11 --> Language Class Initialized
INFO - 2023-12-08 14:04:11 --> Language Class Initialized
INFO - 2023-12-08 14:04:11 --> Config Class Initialized
INFO - 2023-12-08 14:04:11 --> Loader Class Initialized
INFO - 2023-12-08 14:04:11 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:11 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:11 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:11 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:11 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:11 --> Controller Class Initialized
DEBUG - 2023-12-08 14:04:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 14:04:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:04:11 --> Final output sent to browser
DEBUG - 2023-12-08 14:04:11 --> Total execution time: 0.0574
INFO - 2023-12-08 14:04:15 --> Config Class Initialized
INFO - 2023-12-08 14:04:15 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:15 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:15 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:15 --> URI Class Initialized
INFO - 2023-12-08 14:04:15 --> Router Class Initialized
INFO - 2023-12-08 14:04:15 --> Output Class Initialized
INFO - 2023-12-08 14:04:15 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:15 --> Input Class Initialized
INFO - 2023-12-08 14:04:15 --> Language Class Initialized
INFO - 2023-12-08 14:04:15 --> Language Class Initialized
INFO - 2023-12-08 14:04:15 --> Config Class Initialized
INFO - 2023-12-08 14:04:15 --> Loader Class Initialized
INFO - 2023-12-08 14:04:15 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:15 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:15 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:16 --> Controller Class Initialized
INFO - 2023-12-08 14:04:16 --> Config Class Initialized
INFO - 2023-12-08 14:04:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:16 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:16 --> URI Class Initialized
INFO - 2023-12-08 14:04:16 --> Router Class Initialized
INFO - 2023-12-08 14:04:16 --> Output Class Initialized
INFO - 2023-12-08 14:04:16 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:16 --> Input Class Initialized
INFO - 2023-12-08 14:04:16 --> Language Class Initialized
INFO - 2023-12-08 14:04:16 --> Language Class Initialized
INFO - 2023-12-08 14:04:16 --> Config Class Initialized
INFO - 2023-12-08 14:04:16 --> Loader Class Initialized
INFO - 2023-12-08 14:04:16 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:16 --> Controller Class Initialized
DEBUG - 2023-12-08 14:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:04:16 --> Final output sent to browser
DEBUG - 2023-12-08 14:04:16 --> Total execution time: 0.0910
INFO - 2023-12-08 14:04:16 --> Config Class Initialized
INFO - 2023-12-08 14:04:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:16 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:16 --> URI Class Initialized
INFO - 2023-12-08 14:04:16 --> Router Class Initialized
INFO - 2023-12-08 14:04:16 --> Output Class Initialized
INFO - 2023-12-08 14:04:16 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:16 --> Input Class Initialized
INFO - 2023-12-08 14:04:16 --> Language Class Initialized
INFO - 2023-12-08 14:04:16 --> Language Class Initialized
INFO - 2023-12-08 14:04:16 --> Config Class Initialized
INFO - 2023-12-08 14:04:16 --> Loader Class Initialized
INFO - 2023-12-08 14:04:16 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:16 --> Controller Class Initialized
INFO - 2023-12-08 14:04:20 --> Config Class Initialized
INFO - 2023-12-08 14:04:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:20 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:20 --> URI Class Initialized
INFO - 2023-12-08 14:04:20 --> Router Class Initialized
INFO - 2023-12-08 14:04:20 --> Output Class Initialized
INFO - 2023-12-08 14:04:20 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:20 --> Input Class Initialized
INFO - 2023-12-08 14:04:20 --> Language Class Initialized
INFO - 2023-12-08 14:04:20 --> Language Class Initialized
INFO - 2023-12-08 14:04:20 --> Config Class Initialized
INFO - 2023-12-08 14:04:20 --> Loader Class Initialized
INFO - 2023-12-08 14:04:20 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:20 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:20 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:20 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:20 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:21 --> Controller Class Initialized
DEBUG - 2023-12-08 14:04:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:04:21 --> Final output sent to browser
DEBUG - 2023-12-08 14:04:21 --> Total execution time: 0.6307
INFO - 2023-12-08 14:04:21 --> Config Class Initialized
INFO - 2023-12-08 14:04:21 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:21 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:21 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:21 --> URI Class Initialized
INFO - 2023-12-08 14:04:21 --> Router Class Initialized
INFO - 2023-12-08 14:04:21 --> Output Class Initialized
INFO - 2023-12-08 14:04:21 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:21 --> Input Class Initialized
INFO - 2023-12-08 14:04:21 --> Language Class Initialized
INFO - 2023-12-08 14:04:21 --> Language Class Initialized
INFO - 2023-12-08 14:04:21 --> Config Class Initialized
INFO - 2023-12-08 14:04:21 --> Loader Class Initialized
INFO - 2023-12-08 14:04:21 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:21 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:21 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:21 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:21 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:21 --> Controller Class Initialized
DEBUG - 2023-12-08 14:04:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:04:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:04:21 --> Final output sent to browser
DEBUG - 2023-12-08 14:04:21 --> Total execution time: 0.1961
INFO - 2023-12-08 14:04:22 --> Config Class Initialized
INFO - 2023-12-08 14:04:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:22 --> URI Class Initialized
INFO - 2023-12-08 14:04:22 --> Router Class Initialized
INFO - 2023-12-08 14:04:22 --> Output Class Initialized
INFO - 2023-12-08 14:04:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:22 --> Input Class Initialized
INFO - 2023-12-08 14:04:22 --> Language Class Initialized
INFO - 2023-12-08 14:04:22 --> Language Class Initialized
INFO - 2023-12-08 14:04:22 --> Config Class Initialized
INFO - 2023-12-08 14:04:22 --> Loader Class Initialized
INFO - 2023-12-08 14:04:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:22 --> Controller Class Initialized
INFO - 2023-12-08 14:04:26 --> Config Class Initialized
INFO - 2023-12-08 14:04:26 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:26 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:26 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:26 --> URI Class Initialized
INFO - 2023-12-08 14:04:26 --> Router Class Initialized
INFO - 2023-12-08 14:04:26 --> Output Class Initialized
INFO - 2023-12-08 14:04:26 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:26 --> Input Class Initialized
INFO - 2023-12-08 14:04:26 --> Language Class Initialized
INFO - 2023-12-08 14:04:26 --> Language Class Initialized
INFO - 2023-12-08 14:04:26 --> Config Class Initialized
INFO - 2023-12-08 14:04:26 --> Loader Class Initialized
INFO - 2023-12-08 14:04:26 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:26 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:26 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:27 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:27 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:27 --> Controller Class Initialized
INFO - 2023-12-08 14:04:29 --> Config Class Initialized
INFO - 2023-12-08 14:04:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:29 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:29 --> URI Class Initialized
INFO - 2023-12-08 14:04:29 --> Router Class Initialized
INFO - 2023-12-08 14:04:29 --> Output Class Initialized
INFO - 2023-12-08 14:04:29 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:29 --> Input Class Initialized
INFO - 2023-12-08 14:04:29 --> Language Class Initialized
INFO - 2023-12-08 14:04:29 --> Language Class Initialized
INFO - 2023-12-08 14:04:29 --> Config Class Initialized
INFO - 2023-12-08 14:04:29 --> Loader Class Initialized
INFO - 2023-12-08 14:04:29 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:29 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:29 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:29 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:29 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:29 --> Controller Class Initialized
DEBUG - 2023-12-08 14:04:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:04:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:04:29 --> Final output sent to browser
DEBUG - 2023-12-08 14:04:29 --> Total execution time: 0.0413
INFO - 2023-12-08 14:04:29 --> Config Class Initialized
INFO - 2023-12-08 14:04:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:04:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:04:29 --> Utf8 Class Initialized
INFO - 2023-12-08 14:04:29 --> URI Class Initialized
INFO - 2023-12-08 14:04:29 --> Router Class Initialized
INFO - 2023-12-08 14:04:29 --> Output Class Initialized
INFO - 2023-12-08 14:04:29 --> Security Class Initialized
DEBUG - 2023-12-08 14:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:04:29 --> Input Class Initialized
INFO - 2023-12-08 14:04:29 --> Language Class Initialized
INFO - 2023-12-08 14:04:29 --> Language Class Initialized
INFO - 2023-12-08 14:04:29 --> Config Class Initialized
INFO - 2023-12-08 14:04:29 --> Loader Class Initialized
INFO - 2023-12-08 14:04:29 --> Helper loaded: url_helper
INFO - 2023-12-08 14:04:29 --> Helper loaded: file_helper
INFO - 2023-12-08 14:04:29 --> Helper loaded: form_helper
INFO - 2023-12-08 14:04:29 --> Helper loaded: my_helper
INFO - 2023-12-08 14:04:29 --> Database Driver Class Initialized
INFO - 2023-12-08 14:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:04:29 --> Controller Class Initialized
INFO - 2023-12-08 14:05:37 --> Config Class Initialized
INFO - 2023-12-08 14:05:37 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:05:37 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:05:37 --> Utf8 Class Initialized
INFO - 2023-12-08 14:05:37 --> URI Class Initialized
INFO - 2023-12-08 14:05:37 --> Router Class Initialized
INFO - 2023-12-08 14:05:37 --> Output Class Initialized
INFO - 2023-12-08 14:05:37 --> Security Class Initialized
DEBUG - 2023-12-08 14:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:05:37 --> Input Class Initialized
INFO - 2023-12-08 14:05:37 --> Language Class Initialized
INFO - 2023-12-08 14:05:37 --> Language Class Initialized
INFO - 2023-12-08 14:05:37 --> Config Class Initialized
INFO - 2023-12-08 14:05:37 --> Loader Class Initialized
INFO - 2023-12-08 14:05:37 --> Helper loaded: url_helper
INFO - 2023-12-08 14:05:37 --> Helper loaded: file_helper
INFO - 2023-12-08 14:05:37 --> Helper loaded: form_helper
INFO - 2023-12-08 14:05:37 --> Helper loaded: my_helper
INFO - 2023-12-08 14:05:37 --> Database Driver Class Initialized
INFO - 2023-12-08 14:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:05:37 --> Controller Class Initialized
INFO - 2023-12-08 14:05:37 --> Final output sent to browser
DEBUG - 2023-12-08 14:05:37 --> Total execution time: 0.0954
INFO - 2023-12-08 14:06:26 --> Config Class Initialized
INFO - 2023-12-08 14:06:26 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:06:26 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:06:26 --> Utf8 Class Initialized
INFO - 2023-12-08 14:06:26 --> URI Class Initialized
INFO - 2023-12-08 14:06:26 --> Router Class Initialized
INFO - 2023-12-08 14:06:26 --> Output Class Initialized
INFO - 2023-12-08 14:06:26 --> Security Class Initialized
DEBUG - 2023-12-08 14:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:06:26 --> Input Class Initialized
INFO - 2023-12-08 14:06:26 --> Language Class Initialized
INFO - 2023-12-08 14:06:26 --> Language Class Initialized
INFO - 2023-12-08 14:06:26 --> Config Class Initialized
INFO - 2023-12-08 14:06:26 --> Loader Class Initialized
INFO - 2023-12-08 14:06:26 --> Helper loaded: url_helper
INFO - 2023-12-08 14:06:26 --> Helper loaded: file_helper
INFO - 2023-12-08 14:06:26 --> Helper loaded: form_helper
INFO - 2023-12-08 14:06:26 --> Helper loaded: my_helper
INFO - 2023-12-08 14:06:26 --> Database Driver Class Initialized
INFO - 2023-12-08 14:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:06:26 --> Controller Class Initialized
INFO - 2023-12-08 14:06:26 --> Final output sent to browser
DEBUG - 2023-12-08 14:06:26 --> Total execution time: 0.2129
INFO - 2023-12-08 14:07:51 --> Config Class Initialized
INFO - 2023-12-08 14:07:51 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:07:51 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:07:51 --> Utf8 Class Initialized
INFO - 2023-12-08 14:07:51 --> URI Class Initialized
INFO - 2023-12-08 14:07:51 --> Router Class Initialized
INFO - 2023-12-08 14:07:51 --> Output Class Initialized
INFO - 2023-12-08 14:07:51 --> Security Class Initialized
DEBUG - 2023-12-08 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:07:51 --> Input Class Initialized
INFO - 2023-12-08 14:07:51 --> Language Class Initialized
INFO - 2023-12-08 14:07:51 --> Language Class Initialized
INFO - 2023-12-08 14:07:51 --> Config Class Initialized
INFO - 2023-12-08 14:07:51 --> Loader Class Initialized
INFO - 2023-12-08 14:07:51 --> Helper loaded: url_helper
INFO - 2023-12-08 14:07:51 --> Helper loaded: file_helper
INFO - 2023-12-08 14:07:51 --> Helper loaded: form_helper
INFO - 2023-12-08 14:07:51 --> Helper loaded: my_helper
INFO - 2023-12-08 14:07:51 --> Database Driver Class Initialized
INFO - 2023-12-08 14:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:07:51 --> Controller Class Initialized
ERROR - 2023-12-08 14:07:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai SET catatan = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', catatan_mid = '-' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:07:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:08:22 --> Config Class Initialized
INFO - 2023-12-08 14:08:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:22 --> URI Class Initialized
INFO - 2023-12-08 14:08:22 --> Router Class Initialized
INFO - 2023-12-08 14:08:22 --> Output Class Initialized
INFO - 2023-12-08 14:08:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:22 --> Input Class Initialized
INFO - 2023-12-08 14:08:22 --> Language Class Initialized
INFO - 2023-12-08 14:08:22 --> Language Class Initialized
INFO - 2023-12-08 14:08:22 --> Config Class Initialized
INFO - 2023-12-08 14:08:22 --> Loader Class Initialized
INFO - 2023-12-08 14:08:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:22 --> Controller Class Initialized
DEBUG - 2023-12-08 14:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:08:22 --> Final output sent to browser
DEBUG - 2023-12-08 14:08:22 --> Total execution time: 0.0417
INFO - 2023-12-08 14:08:22 --> Config Class Initialized
INFO - 2023-12-08 14:08:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:22 --> URI Class Initialized
INFO - 2023-12-08 14:08:22 --> Router Class Initialized
INFO - 2023-12-08 14:08:22 --> Output Class Initialized
INFO - 2023-12-08 14:08:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:22 --> Input Class Initialized
INFO - 2023-12-08 14:08:22 --> Language Class Initialized
INFO - 2023-12-08 14:08:22 --> Language Class Initialized
INFO - 2023-12-08 14:08:22 --> Config Class Initialized
INFO - 2023-12-08 14:08:22 --> Loader Class Initialized
INFO - 2023-12-08 14:08:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:22 --> Controller Class Initialized
INFO - 2023-12-08 14:08:25 --> Config Class Initialized
INFO - 2023-12-08 14:08:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:25 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:25 --> URI Class Initialized
INFO - 2023-12-08 14:08:25 --> Router Class Initialized
INFO - 2023-12-08 14:08:25 --> Output Class Initialized
INFO - 2023-12-08 14:08:25 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:25 --> Input Class Initialized
INFO - 2023-12-08 14:08:25 --> Language Class Initialized
INFO - 2023-12-08 14:08:25 --> Language Class Initialized
INFO - 2023-12-08 14:08:25 --> Config Class Initialized
INFO - 2023-12-08 14:08:25 --> Loader Class Initialized
INFO - 2023-12-08 14:08:25 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:25 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:25 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:25 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:25 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:25 --> Controller Class Initialized
INFO - 2023-12-08 14:08:25 --> Final output sent to browser
DEBUG - 2023-12-08 14:08:25 --> Total execution time: 0.1389
INFO - 2023-12-08 14:08:42 --> Config Class Initialized
INFO - 2023-12-08 14:08:42 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:42 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:42 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:42 --> URI Class Initialized
INFO - 2023-12-08 14:08:42 --> Router Class Initialized
INFO - 2023-12-08 14:08:42 --> Output Class Initialized
INFO - 2023-12-08 14:08:42 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:42 --> Input Class Initialized
INFO - 2023-12-08 14:08:42 --> Language Class Initialized
INFO - 2023-12-08 14:08:42 --> Language Class Initialized
INFO - 2023-12-08 14:08:42 --> Config Class Initialized
INFO - 2023-12-08 14:08:42 --> Loader Class Initialized
INFO - 2023-12-08 14:08:42 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:42 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:42 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:42 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:42 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:42 --> Controller Class Initialized
DEBUG - 2023-12-08 14:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:08:42 --> Final output sent to browser
DEBUG - 2023-12-08 14:08:42 --> Total execution time: 0.1153
INFO - 2023-12-08 14:08:54 --> Config Class Initialized
INFO - 2023-12-08 14:08:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:54 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:54 --> URI Class Initialized
DEBUG - 2023-12-08 14:08:54 --> No URI present. Default controller set.
INFO - 2023-12-08 14:08:54 --> Router Class Initialized
INFO - 2023-12-08 14:08:54 --> Output Class Initialized
INFO - 2023-12-08 14:08:54 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:54 --> Input Class Initialized
INFO - 2023-12-08 14:08:54 --> Language Class Initialized
INFO - 2023-12-08 14:08:54 --> Language Class Initialized
INFO - 2023-12-08 14:08:54 --> Config Class Initialized
INFO - 2023-12-08 14:08:54 --> Loader Class Initialized
INFO - 2023-12-08 14:08:54 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:54 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:54 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:54 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:54 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:54 --> Controller Class Initialized
DEBUG - 2023-12-08 14:08:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 14:08:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:08:54 --> Final output sent to browser
DEBUG - 2023-12-08 14:08:54 --> Total execution time: 0.0781
INFO - 2023-12-08 14:08:56 --> Config Class Initialized
INFO - 2023-12-08 14:08:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:56 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:56 --> URI Class Initialized
INFO - 2023-12-08 14:08:56 --> Router Class Initialized
INFO - 2023-12-08 14:08:56 --> Output Class Initialized
INFO - 2023-12-08 14:08:56 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:56 --> Input Class Initialized
INFO - 2023-12-08 14:08:56 --> Language Class Initialized
INFO - 2023-12-08 14:08:56 --> Language Class Initialized
INFO - 2023-12-08 14:08:56 --> Config Class Initialized
INFO - 2023-12-08 14:08:56 --> Loader Class Initialized
INFO - 2023-12-08 14:08:56 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:56 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:56 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:56 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:56 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:56 --> Controller Class Initialized
DEBUG - 2023-12-08 14:08:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:08:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:08:56 --> Final output sent to browser
DEBUG - 2023-12-08 14:08:56 --> Total execution time: 0.0389
INFO - 2023-12-08 14:08:58 --> Config Class Initialized
INFO - 2023-12-08 14:08:58 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:08:58 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:08:58 --> Utf8 Class Initialized
INFO - 2023-12-08 14:08:58 --> URI Class Initialized
INFO - 2023-12-08 14:08:58 --> Router Class Initialized
INFO - 2023-12-08 14:08:58 --> Output Class Initialized
INFO - 2023-12-08 14:08:58 --> Security Class Initialized
DEBUG - 2023-12-08 14:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:08:58 --> Input Class Initialized
INFO - 2023-12-08 14:08:58 --> Language Class Initialized
INFO - 2023-12-08 14:08:58 --> Language Class Initialized
INFO - 2023-12-08 14:08:58 --> Config Class Initialized
INFO - 2023-12-08 14:08:58 --> Loader Class Initialized
INFO - 2023-12-08 14:08:58 --> Helper loaded: url_helper
INFO - 2023-12-08 14:08:58 --> Helper loaded: file_helper
INFO - 2023-12-08 14:08:58 --> Helper loaded: form_helper
INFO - 2023-12-08 14:08:58 --> Helper loaded: my_helper
INFO - 2023-12-08 14:08:58 --> Database Driver Class Initialized
INFO - 2023-12-08 14:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:08:58 --> Controller Class Initialized
DEBUG - 2023-12-08 14:08:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:08:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:08:58 --> Final output sent to browser
DEBUG - 2023-12-08 14:08:58 --> Total execution time: 0.0506
INFO - 2023-12-08 14:09:02 --> Config Class Initialized
INFO - 2023-12-08 14:09:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:09:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:09:02 --> Utf8 Class Initialized
INFO - 2023-12-08 14:09:02 --> URI Class Initialized
INFO - 2023-12-08 14:09:02 --> Router Class Initialized
INFO - 2023-12-08 14:09:02 --> Output Class Initialized
INFO - 2023-12-08 14:09:02 --> Security Class Initialized
DEBUG - 2023-12-08 14:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:09:02 --> Input Class Initialized
INFO - 2023-12-08 14:09:02 --> Language Class Initialized
INFO - 2023-12-08 14:09:02 --> Language Class Initialized
INFO - 2023-12-08 14:09:02 --> Config Class Initialized
INFO - 2023-12-08 14:09:02 --> Loader Class Initialized
INFO - 2023-12-08 14:09:02 --> Helper loaded: url_helper
INFO - 2023-12-08 14:09:02 --> Helper loaded: file_helper
INFO - 2023-12-08 14:09:02 --> Helper loaded: form_helper
INFO - 2023-12-08 14:09:02 --> Helper loaded: my_helper
INFO - 2023-12-08 14:09:02 --> Database Driver Class Initialized
INFO - 2023-12-08 14:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:09:02 --> Controller Class Initialized
INFO - 2023-12-08 14:09:02 --> Final output sent to browser
DEBUG - 2023-12-08 14:09:02 --> Total execution time: 0.2274
INFO - 2023-12-08 14:11:48 --> Config Class Initialized
INFO - 2023-12-08 14:11:48 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:11:48 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:11:48 --> Utf8 Class Initialized
INFO - 2023-12-08 14:11:48 --> URI Class Initialized
INFO - 2023-12-08 14:11:48 --> Router Class Initialized
INFO - 2023-12-08 14:11:48 --> Output Class Initialized
INFO - 2023-12-08 14:11:48 --> Security Class Initialized
DEBUG - 2023-12-08 14:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:11:48 --> Input Class Initialized
INFO - 2023-12-08 14:11:48 --> Language Class Initialized
INFO - 2023-12-08 14:11:48 --> Language Class Initialized
INFO - 2023-12-08 14:11:48 --> Config Class Initialized
INFO - 2023-12-08 14:11:48 --> Loader Class Initialized
INFO - 2023-12-08 14:11:48 --> Helper loaded: url_helper
INFO - 2023-12-08 14:11:48 --> Helper loaded: file_helper
INFO - 2023-12-08 14:11:48 --> Helper loaded: form_helper
INFO - 2023-12-08 14:11:48 --> Helper loaded: my_helper
INFO - 2023-12-08 14:11:48 --> Database Driver Class Initialized
INFO - 2023-12-08 14:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:11:48 --> Controller Class Initialized
ERROR - 2023-12-08 14:11:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:11:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:11:52 --> Config Class Initialized
INFO - 2023-12-08 14:11:52 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:11:52 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:11:52 --> Utf8 Class Initialized
INFO - 2023-12-08 14:11:52 --> URI Class Initialized
INFO - 2023-12-08 14:11:52 --> Router Class Initialized
INFO - 2023-12-08 14:11:52 --> Output Class Initialized
INFO - 2023-12-08 14:11:52 --> Security Class Initialized
DEBUG - 2023-12-08 14:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:11:52 --> Input Class Initialized
INFO - 2023-12-08 14:11:52 --> Language Class Initialized
INFO - 2023-12-08 14:11:52 --> Language Class Initialized
INFO - 2023-12-08 14:11:52 --> Config Class Initialized
INFO - 2023-12-08 14:11:52 --> Loader Class Initialized
INFO - 2023-12-08 14:11:52 --> Helper loaded: url_helper
INFO - 2023-12-08 14:11:52 --> Helper loaded: file_helper
INFO - 2023-12-08 14:11:52 --> Helper loaded: form_helper
INFO - 2023-12-08 14:11:52 --> Helper loaded: my_helper
INFO - 2023-12-08 14:11:52 --> Database Driver Class Initialized
INFO - 2023-12-08 14:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:11:52 --> Controller Class Initialized
ERROR - 2023-12-08 14:11:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:11:52 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:11:53 --> Config Class Initialized
INFO - 2023-12-08 14:11:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:11:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:11:53 --> Utf8 Class Initialized
INFO - 2023-12-08 14:11:53 --> URI Class Initialized
INFO - 2023-12-08 14:11:53 --> Router Class Initialized
INFO - 2023-12-08 14:11:53 --> Output Class Initialized
INFO - 2023-12-08 14:11:53 --> Security Class Initialized
DEBUG - 2023-12-08 14:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:11:53 --> Input Class Initialized
INFO - 2023-12-08 14:11:53 --> Language Class Initialized
INFO - 2023-12-08 14:11:53 --> Language Class Initialized
INFO - 2023-12-08 14:11:53 --> Config Class Initialized
INFO - 2023-12-08 14:11:53 --> Loader Class Initialized
INFO - 2023-12-08 14:11:53 --> Helper loaded: url_helper
INFO - 2023-12-08 14:11:53 --> Helper loaded: file_helper
INFO - 2023-12-08 14:11:53 --> Helper loaded: form_helper
INFO - 2023-12-08 14:11:53 --> Helper loaded: my_helper
INFO - 2023-12-08 14:11:53 --> Database Driver Class Initialized
INFO - 2023-12-08 14:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:11:53 --> Controller Class Initialized
ERROR - 2023-12-08 14:11:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:11:53 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:11:54 --> Config Class Initialized
INFO - 2023-12-08 14:11:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:11:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:11:54 --> Utf8 Class Initialized
INFO - 2023-12-08 14:11:54 --> URI Class Initialized
INFO - 2023-12-08 14:11:54 --> Router Class Initialized
INFO - 2023-12-08 14:11:54 --> Output Class Initialized
INFO - 2023-12-08 14:11:54 --> Security Class Initialized
DEBUG - 2023-12-08 14:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:11:54 --> Input Class Initialized
INFO - 2023-12-08 14:11:54 --> Language Class Initialized
INFO - 2023-12-08 14:11:54 --> Language Class Initialized
INFO - 2023-12-08 14:11:54 --> Config Class Initialized
INFO - 2023-12-08 14:11:54 --> Loader Class Initialized
INFO - 2023-12-08 14:11:54 --> Helper loaded: url_helper
INFO - 2023-12-08 14:11:54 --> Helper loaded: file_helper
INFO - 2023-12-08 14:11:54 --> Helper loaded: form_helper
INFO - 2023-12-08 14:11:54 --> Helper loaded: my_helper
INFO - 2023-12-08 14:11:54 --> Database Driver Class Initialized
INFO - 2023-12-08 14:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:11:54 --> Controller Class Initialized
ERROR - 2023-12-08 14:11:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:11:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:11:59 --> Config Class Initialized
INFO - 2023-12-08 14:11:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:11:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:11:59 --> Utf8 Class Initialized
INFO - 2023-12-08 14:11:59 --> URI Class Initialized
INFO - 2023-12-08 14:11:59 --> Router Class Initialized
INFO - 2023-12-08 14:11:59 --> Output Class Initialized
INFO - 2023-12-08 14:11:59 --> Security Class Initialized
DEBUG - 2023-12-08 14:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:11:59 --> Input Class Initialized
INFO - 2023-12-08 14:11:59 --> Language Class Initialized
INFO - 2023-12-08 14:11:59 --> Language Class Initialized
INFO - 2023-12-08 14:11:59 --> Config Class Initialized
INFO - 2023-12-08 14:11:59 --> Loader Class Initialized
INFO - 2023-12-08 14:11:59 --> Helper loaded: url_helper
INFO - 2023-12-08 14:11:59 --> Helper loaded: file_helper
INFO - 2023-12-08 14:11:59 --> Helper loaded: form_helper
INFO - 2023-12-08 14:11:59 --> Helper loaded: my_helper
INFO - 2023-12-08 14:11:59 --> Database Driver Class Initialized
INFO - 2023-12-08 14:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:11:59 --> Controller Class Initialized
DEBUG - 2023-12-08 14:11:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:11:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:11:59 --> Final output sent to browser
DEBUG - 2023-12-08 14:11:59 --> Total execution time: 0.0481
INFO - 2023-12-08 14:12:00 --> Config Class Initialized
INFO - 2023-12-08 14:12:00 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:12:00 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:12:00 --> Utf8 Class Initialized
INFO - 2023-12-08 14:12:00 --> URI Class Initialized
INFO - 2023-12-08 14:12:00 --> Router Class Initialized
INFO - 2023-12-08 14:12:00 --> Output Class Initialized
INFO - 2023-12-08 14:12:00 --> Security Class Initialized
DEBUG - 2023-12-08 14:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:12:00 --> Input Class Initialized
INFO - 2023-12-08 14:12:00 --> Language Class Initialized
INFO - 2023-12-08 14:12:00 --> Language Class Initialized
INFO - 2023-12-08 14:12:00 --> Config Class Initialized
INFO - 2023-12-08 14:12:00 --> Loader Class Initialized
INFO - 2023-12-08 14:12:00 --> Helper loaded: url_helper
INFO - 2023-12-08 14:12:00 --> Helper loaded: file_helper
INFO - 2023-12-08 14:12:00 --> Helper loaded: form_helper
INFO - 2023-12-08 14:12:00 --> Helper loaded: my_helper
INFO - 2023-12-08 14:12:00 --> Database Driver Class Initialized
INFO - 2023-12-08 14:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:12:00 --> Controller Class Initialized
INFO - 2023-12-08 14:12:02 --> Config Class Initialized
INFO - 2023-12-08 14:12:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:12:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:12:02 --> Utf8 Class Initialized
INFO - 2023-12-08 14:12:02 --> URI Class Initialized
INFO - 2023-12-08 14:12:02 --> Router Class Initialized
INFO - 2023-12-08 14:12:03 --> Output Class Initialized
INFO - 2023-12-08 14:12:03 --> Security Class Initialized
DEBUG - 2023-12-08 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:12:03 --> Input Class Initialized
INFO - 2023-12-08 14:12:03 --> Language Class Initialized
INFO - 2023-12-08 14:12:03 --> Language Class Initialized
INFO - 2023-12-08 14:12:03 --> Config Class Initialized
INFO - 2023-12-08 14:12:03 --> Loader Class Initialized
INFO - 2023-12-08 14:12:03 --> Helper loaded: url_helper
INFO - 2023-12-08 14:12:03 --> Helper loaded: file_helper
INFO - 2023-12-08 14:12:03 --> Helper loaded: form_helper
INFO - 2023-12-08 14:12:03 --> Helper loaded: my_helper
INFO - 2023-12-08 14:12:03 --> Database Driver Class Initialized
INFO - 2023-12-08 14:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:12:03 --> Controller Class Initialized
ERROR - 2023-12-08 14:12:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:12:03 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:12:03 --> Config Class Initialized
INFO - 2023-12-08 14:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:12:03 --> Utf8 Class Initialized
INFO - 2023-12-08 14:12:03 --> URI Class Initialized
INFO - 2023-12-08 14:12:03 --> Router Class Initialized
INFO - 2023-12-08 14:12:03 --> Output Class Initialized
INFO - 2023-12-08 14:12:03 --> Security Class Initialized
DEBUG - 2023-12-08 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:12:03 --> Input Class Initialized
INFO - 2023-12-08 14:12:03 --> Language Class Initialized
INFO - 2023-12-08 14:12:03 --> Language Class Initialized
INFO - 2023-12-08 14:12:03 --> Config Class Initialized
INFO - 2023-12-08 14:12:03 --> Loader Class Initialized
INFO - 2023-12-08 14:12:03 --> Helper loaded: url_helper
INFO - 2023-12-08 14:12:03 --> Helper loaded: file_helper
INFO - 2023-12-08 14:12:03 --> Helper loaded: form_helper
INFO - 2023-12-08 14:12:03 --> Helper loaded: my_helper
INFO - 2023-12-08 14:12:03 --> Database Driver Class Initialized
INFO - 2023-12-08 14:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:12:03 --> Controller Class Initialized
ERROR - 2023-12-08 14:12:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:12:03 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:13:22 --> Config Class Initialized
INFO - 2023-12-08 14:13:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:13:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:13:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:13:22 --> URI Class Initialized
INFO - 2023-12-08 14:13:22 --> Router Class Initialized
INFO - 2023-12-08 14:13:22 --> Output Class Initialized
INFO - 2023-12-08 14:13:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:13:22 --> Input Class Initialized
INFO - 2023-12-08 14:13:22 --> Language Class Initialized
INFO - 2023-12-08 14:13:22 --> Language Class Initialized
INFO - 2023-12-08 14:13:22 --> Config Class Initialized
INFO - 2023-12-08 14:13:22 --> Loader Class Initialized
INFO - 2023-12-08 14:13:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:13:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:13:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:13:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:13:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:13:22 --> Controller Class Initialized
ERROR - 2023-12-08 14:13:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:13:22 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:13:29 --> Config Class Initialized
INFO - 2023-12-08 14:13:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:13:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:13:29 --> Utf8 Class Initialized
INFO - 2023-12-08 14:13:29 --> URI Class Initialized
INFO - 2023-12-08 14:13:29 --> Router Class Initialized
INFO - 2023-12-08 14:13:29 --> Output Class Initialized
INFO - 2023-12-08 14:13:29 --> Security Class Initialized
DEBUG - 2023-12-08 14:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:13:29 --> Input Class Initialized
INFO - 2023-12-08 14:13:29 --> Language Class Initialized
INFO - 2023-12-08 14:13:29 --> Language Class Initialized
INFO - 2023-12-08 14:13:29 --> Config Class Initialized
INFO - 2023-12-08 14:13:29 --> Loader Class Initialized
INFO - 2023-12-08 14:13:29 --> Helper loaded: url_helper
INFO - 2023-12-08 14:13:29 --> Helper loaded: file_helper
INFO - 2023-12-08 14:13:29 --> Helper loaded: form_helper
INFO - 2023-12-08 14:13:29 --> Helper loaded: my_helper
INFO - 2023-12-08 14:13:29 --> Database Driver Class Initialized
INFO - 2023-12-08 14:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:13:29 --> Controller Class Initialized
DEBUG - 2023-12-08 14:13:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:13:29 --> Final output sent to browser
DEBUG - 2023-12-08 14:13:29 --> Total execution time: 0.0425
INFO - 2023-12-08 14:13:40 --> Config Class Initialized
INFO - 2023-12-08 14:13:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:13:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:13:40 --> Utf8 Class Initialized
INFO - 2023-12-08 14:13:40 --> URI Class Initialized
INFO - 2023-12-08 14:13:40 --> Router Class Initialized
INFO - 2023-12-08 14:13:40 --> Output Class Initialized
INFO - 2023-12-08 14:13:40 --> Security Class Initialized
DEBUG - 2023-12-08 14:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:13:40 --> Input Class Initialized
INFO - 2023-12-08 14:13:40 --> Language Class Initialized
INFO - 2023-12-08 14:13:40 --> Language Class Initialized
INFO - 2023-12-08 14:13:40 --> Config Class Initialized
INFO - 2023-12-08 14:13:40 --> Loader Class Initialized
INFO - 2023-12-08 14:13:40 --> Helper loaded: url_helper
INFO - 2023-12-08 14:13:40 --> Helper loaded: file_helper
INFO - 2023-12-08 14:13:40 --> Helper loaded: form_helper
INFO - 2023-12-08 14:13:40 --> Helper loaded: my_helper
INFO - 2023-12-08 14:13:40 --> Database Driver Class Initialized
INFO - 2023-12-08 14:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:13:40 --> Controller Class Initialized
DEBUG - 2023-12-08 14:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-12-08 14:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:13:40 --> Final output sent to browser
DEBUG - 2023-12-08 14:13:40 --> Total execution time: 0.1668
INFO - 2023-12-08 14:13:51 --> Config Class Initialized
INFO - 2023-12-08 14:13:51 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:13:51 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:13:51 --> Utf8 Class Initialized
INFO - 2023-12-08 14:13:51 --> URI Class Initialized
INFO - 2023-12-08 14:13:51 --> Router Class Initialized
INFO - 2023-12-08 14:13:51 --> Output Class Initialized
INFO - 2023-12-08 14:13:51 --> Security Class Initialized
DEBUG - 2023-12-08 14:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:13:51 --> Input Class Initialized
INFO - 2023-12-08 14:13:51 --> Language Class Initialized
INFO - 2023-12-08 14:13:51 --> Language Class Initialized
INFO - 2023-12-08 14:13:51 --> Config Class Initialized
INFO - 2023-12-08 14:13:51 --> Loader Class Initialized
INFO - 2023-12-08 14:13:51 --> Helper loaded: url_helper
INFO - 2023-12-08 14:13:51 --> Helper loaded: file_helper
INFO - 2023-12-08 14:13:51 --> Helper loaded: form_helper
INFO - 2023-12-08 14:13:51 --> Helper loaded: my_helper
INFO - 2023-12-08 14:13:51 --> Database Driver Class Initialized
INFO - 2023-12-08 14:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:13:51 --> Controller Class Initialized
DEBUG - 2023-12-08 14:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:13:51 --> Final output sent to browser
DEBUG - 2023-12-08 14:13:51 --> Total execution time: 0.0548
INFO - 2023-12-08 14:13:54 --> Config Class Initialized
INFO - 2023-12-08 14:13:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:13:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:13:54 --> Utf8 Class Initialized
INFO - 2023-12-08 14:13:54 --> URI Class Initialized
INFO - 2023-12-08 14:13:54 --> Router Class Initialized
INFO - 2023-12-08 14:13:54 --> Output Class Initialized
INFO - 2023-12-08 14:13:54 --> Security Class Initialized
DEBUG - 2023-12-08 14:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:13:54 --> Input Class Initialized
INFO - 2023-12-08 14:13:54 --> Language Class Initialized
INFO - 2023-12-08 14:13:54 --> Language Class Initialized
INFO - 2023-12-08 14:13:54 --> Config Class Initialized
INFO - 2023-12-08 14:13:54 --> Loader Class Initialized
INFO - 2023-12-08 14:13:54 --> Helper loaded: url_helper
INFO - 2023-12-08 14:13:54 --> Helper loaded: file_helper
INFO - 2023-12-08 14:13:54 --> Helper loaded: form_helper
INFO - 2023-12-08 14:13:54 --> Helper loaded: my_helper
INFO - 2023-12-08 14:13:54 --> Database Driver Class Initialized
INFO - 2023-12-08 14:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:13:54 --> Controller Class Initialized
INFO - 2023-12-08 14:14:32 --> Config Class Initialized
INFO - 2023-12-08 14:14:32 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:14:32 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:14:32 --> Utf8 Class Initialized
INFO - 2023-12-08 14:14:32 --> URI Class Initialized
INFO - 2023-12-08 14:14:32 --> Router Class Initialized
INFO - 2023-12-08 14:14:32 --> Output Class Initialized
INFO - 2023-12-08 14:14:32 --> Security Class Initialized
DEBUG - 2023-12-08 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:14:32 --> Input Class Initialized
INFO - 2023-12-08 14:14:32 --> Language Class Initialized
INFO - 2023-12-08 14:14:32 --> Language Class Initialized
INFO - 2023-12-08 14:14:32 --> Config Class Initialized
INFO - 2023-12-08 14:14:32 --> Loader Class Initialized
INFO - 2023-12-08 14:14:32 --> Helper loaded: url_helper
INFO - 2023-12-08 14:14:32 --> Helper loaded: file_helper
INFO - 2023-12-08 14:14:32 --> Helper loaded: form_helper
INFO - 2023-12-08 14:14:32 --> Helper loaded: my_helper
INFO - 2023-12-08 14:14:32 --> Database Driver Class Initialized
INFO - 2023-12-08 14:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:14:32 --> Controller Class Initialized
DEBUG - 2023-12-08 14:14:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:14:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:14:32 --> Final output sent to browser
DEBUG - 2023-12-08 14:14:32 --> Total execution time: 0.1367
INFO - 2023-12-08 14:14:32 --> Config Class Initialized
INFO - 2023-12-08 14:14:32 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:14:32 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:14:32 --> Utf8 Class Initialized
INFO - 2023-12-08 14:14:32 --> URI Class Initialized
INFO - 2023-12-08 14:14:32 --> Router Class Initialized
INFO - 2023-12-08 14:14:32 --> Output Class Initialized
INFO - 2023-12-08 14:14:32 --> Security Class Initialized
DEBUG - 2023-12-08 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:14:32 --> Input Class Initialized
INFO - 2023-12-08 14:14:32 --> Language Class Initialized
INFO - 2023-12-08 14:14:32 --> Language Class Initialized
INFO - 2023-12-08 14:14:32 --> Config Class Initialized
INFO - 2023-12-08 14:14:32 --> Loader Class Initialized
INFO - 2023-12-08 14:14:32 --> Helper loaded: url_helper
INFO - 2023-12-08 14:14:32 --> Helper loaded: file_helper
INFO - 2023-12-08 14:14:32 --> Helper loaded: form_helper
INFO - 2023-12-08 14:14:32 --> Helper loaded: my_helper
INFO - 2023-12-08 14:14:32 --> Database Driver Class Initialized
INFO - 2023-12-08 14:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:14:32 --> Controller Class Initialized
INFO - 2023-12-08 14:14:38 --> Config Class Initialized
INFO - 2023-12-08 14:14:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:14:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:14:38 --> Utf8 Class Initialized
INFO - 2023-12-08 14:14:38 --> URI Class Initialized
INFO - 2023-12-08 14:14:38 --> Router Class Initialized
INFO - 2023-12-08 14:14:38 --> Output Class Initialized
INFO - 2023-12-08 14:14:38 --> Security Class Initialized
DEBUG - 2023-12-08 14:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:14:38 --> Input Class Initialized
INFO - 2023-12-08 14:14:38 --> Language Class Initialized
INFO - 2023-12-08 14:14:38 --> Language Class Initialized
INFO - 2023-12-08 14:14:38 --> Config Class Initialized
INFO - 2023-12-08 14:14:38 --> Loader Class Initialized
INFO - 2023-12-08 14:14:38 --> Helper loaded: url_helper
INFO - 2023-12-08 14:14:38 --> Helper loaded: file_helper
INFO - 2023-12-08 14:14:38 --> Helper loaded: form_helper
INFO - 2023-12-08 14:14:38 --> Helper loaded: my_helper
INFO - 2023-12-08 14:14:38 --> Database Driver Class Initialized
INFO - 2023-12-08 14:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:14:38 --> Controller Class Initialized
INFO - 2023-12-08 14:14:38 --> Final output sent to browser
DEBUG - 2023-12-08 14:14:38 --> Total execution time: 0.0855
INFO - 2023-12-08 14:16:50 --> Config Class Initialized
INFO - 2023-12-08 14:16:50 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:50 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:50 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:50 --> URI Class Initialized
INFO - 2023-12-08 14:16:50 --> Router Class Initialized
INFO - 2023-12-08 14:16:50 --> Output Class Initialized
INFO - 2023-12-08 14:16:50 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:50 --> Input Class Initialized
INFO - 2023-12-08 14:16:50 --> Language Class Initialized
INFO - 2023-12-08 14:16:50 --> Language Class Initialized
INFO - 2023-12-08 14:16:50 --> Config Class Initialized
INFO - 2023-12-08 14:16:50 --> Loader Class Initialized
INFO - 2023-12-08 14:16:50 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:50 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:50 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:50 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:50 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:50 --> Controller Class Initialized
INFO - 2023-12-08 14:16:50 --> Config Class Initialized
INFO - 2023-12-08 14:16:50 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:50 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:50 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:50 --> URI Class Initialized
INFO - 2023-12-08 14:16:50 --> Router Class Initialized
INFO - 2023-12-08 14:16:50 --> Output Class Initialized
INFO - 2023-12-08 14:16:50 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:50 --> Input Class Initialized
INFO - 2023-12-08 14:16:50 --> Language Class Initialized
INFO - 2023-12-08 14:16:50 --> Language Class Initialized
INFO - 2023-12-08 14:16:50 --> Config Class Initialized
INFO - 2023-12-08 14:16:50 --> Loader Class Initialized
INFO - 2023-12-08 14:16:50 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:50 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:50 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:50 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:50 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:51 --> Controller Class Initialized
DEBUG - 2023-12-08 14:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 14:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:16:51 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:51 --> Total execution time: 0.1130
INFO - 2023-12-08 14:16:53 --> Config Class Initialized
INFO - 2023-12-08 14:16:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:53 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:53 --> URI Class Initialized
INFO - 2023-12-08 14:16:53 --> Router Class Initialized
INFO - 2023-12-08 14:16:53 --> Output Class Initialized
INFO - 2023-12-08 14:16:53 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:53 --> Input Class Initialized
INFO - 2023-12-08 14:16:53 --> Language Class Initialized
INFO - 2023-12-08 14:16:53 --> Language Class Initialized
INFO - 2023-12-08 14:16:53 --> Config Class Initialized
INFO - 2023-12-08 14:16:53 --> Loader Class Initialized
INFO - 2023-12-08 14:16:53 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:53 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:53 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:53 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:53 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:53 --> Controller Class Initialized
DEBUG - 2023-12-08 14:16:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:16:53 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:53 --> Total execution time: 0.0937
INFO - 2023-12-08 14:16:54 --> Config Class Initialized
INFO - 2023-12-08 14:16:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:54 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:54 --> URI Class Initialized
INFO - 2023-12-08 14:16:54 --> Router Class Initialized
INFO - 2023-12-08 14:16:54 --> Output Class Initialized
INFO - 2023-12-08 14:16:54 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:54 --> Input Class Initialized
INFO - 2023-12-08 14:16:54 --> Language Class Initialized
INFO - 2023-12-08 14:16:54 --> Language Class Initialized
INFO - 2023-12-08 14:16:54 --> Config Class Initialized
INFO - 2023-12-08 14:16:54 --> Loader Class Initialized
INFO - 2023-12-08 14:16:54 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:54 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:54 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:54 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:55 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:55 --> Controller Class Initialized
INFO - 2023-12-08 14:16:55 --> Helper loaded: cookie_helper
INFO - 2023-12-08 14:16:55 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:55 --> Total execution time: 0.0916
INFO - 2023-12-08 14:16:55 --> Config Class Initialized
INFO - 2023-12-08 14:16:55 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:55 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:55 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:55 --> URI Class Initialized
INFO - 2023-12-08 14:16:55 --> Router Class Initialized
INFO - 2023-12-08 14:16:55 --> Output Class Initialized
INFO - 2023-12-08 14:16:55 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:55 --> Input Class Initialized
INFO - 2023-12-08 14:16:55 --> Language Class Initialized
INFO - 2023-12-08 14:16:55 --> Language Class Initialized
INFO - 2023-12-08 14:16:55 --> Config Class Initialized
INFO - 2023-12-08 14:16:55 --> Loader Class Initialized
INFO - 2023-12-08 14:16:55 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:55 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:55 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:55 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:55 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:55 --> Controller Class Initialized
DEBUG - 2023-12-08 14:16:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 14:16:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:16:55 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:55 --> Total execution time: 0.0402
INFO - 2023-12-08 14:16:57 --> Config Class Initialized
INFO - 2023-12-08 14:16:57 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:57 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:57 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:57 --> URI Class Initialized
INFO - 2023-12-08 14:16:57 --> Router Class Initialized
INFO - 2023-12-08 14:16:57 --> Output Class Initialized
INFO - 2023-12-08 14:16:57 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:57 --> Input Class Initialized
INFO - 2023-12-08 14:16:57 --> Language Class Initialized
INFO - 2023-12-08 14:16:57 --> Language Class Initialized
INFO - 2023-12-08 14:16:57 --> Config Class Initialized
INFO - 2023-12-08 14:16:57 --> Loader Class Initialized
INFO - 2023-12-08 14:16:57 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:57 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:57 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:57 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:57 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:57 --> Controller Class Initialized
DEBUG - 2023-12-08 14:16:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:16:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:16:57 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:57 --> Total execution time: 0.0593
INFO - 2023-12-08 14:16:58 --> Config Class Initialized
INFO - 2023-12-08 14:16:58 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:58 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:58 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:58 --> URI Class Initialized
INFO - 2023-12-08 14:16:58 --> Router Class Initialized
INFO - 2023-12-08 14:16:58 --> Output Class Initialized
INFO - 2023-12-08 14:16:58 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:58 --> Input Class Initialized
INFO - 2023-12-08 14:16:58 --> Language Class Initialized
INFO - 2023-12-08 14:16:58 --> Language Class Initialized
INFO - 2023-12-08 14:16:58 --> Config Class Initialized
INFO - 2023-12-08 14:16:58 --> Loader Class Initialized
INFO - 2023-12-08 14:16:58 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:58 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:58 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:58 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:58 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:58 --> Controller Class Initialized
INFO - 2023-12-08 14:16:58 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:58 --> Total execution time: 0.0693
INFO - 2023-12-08 14:16:59 --> Config Class Initialized
INFO - 2023-12-08 14:16:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:16:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:16:59 --> Utf8 Class Initialized
INFO - 2023-12-08 14:16:59 --> URI Class Initialized
INFO - 2023-12-08 14:16:59 --> Router Class Initialized
INFO - 2023-12-08 14:16:59 --> Output Class Initialized
INFO - 2023-12-08 14:16:59 --> Security Class Initialized
DEBUG - 2023-12-08 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:16:59 --> Input Class Initialized
INFO - 2023-12-08 14:16:59 --> Language Class Initialized
INFO - 2023-12-08 14:16:59 --> Language Class Initialized
INFO - 2023-12-08 14:16:59 --> Config Class Initialized
INFO - 2023-12-08 14:16:59 --> Loader Class Initialized
INFO - 2023-12-08 14:16:59 --> Helper loaded: url_helper
INFO - 2023-12-08 14:16:59 --> Helper loaded: file_helper
INFO - 2023-12-08 14:16:59 --> Helper loaded: form_helper
INFO - 2023-12-08 14:16:59 --> Helper loaded: my_helper
INFO - 2023-12-08 14:16:59 --> Database Driver Class Initialized
INFO - 2023-12-08 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:16:59 --> Controller Class Initialized
DEBUG - 2023-12-08 14:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:16:59 --> Final output sent to browser
DEBUG - 2023-12-08 14:16:59 --> Total execution time: 0.0931
INFO - 2023-12-08 14:17:01 --> Config Class Initialized
INFO - 2023-12-08 14:17:01 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:01 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:01 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:01 --> URI Class Initialized
INFO - 2023-12-08 14:17:01 --> Router Class Initialized
INFO - 2023-12-08 14:17:01 --> Output Class Initialized
INFO - 2023-12-08 14:17:01 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:01 --> Input Class Initialized
INFO - 2023-12-08 14:17:01 --> Language Class Initialized
INFO - 2023-12-08 14:17:01 --> Language Class Initialized
INFO - 2023-12-08 14:17:01 --> Config Class Initialized
INFO - 2023-12-08 14:17:01 --> Loader Class Initialized
INFO - 2023-12-08 14:17:01 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:01 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:01 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:01 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:01 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:01 --> Controller Class Initialized
INFO - 2023-12-08 14:17:01 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:01 --> Total execution time: 0.0744
INFO - 2023-12-08 14:17:16 --> Config Class Initialized
INFO - 2023-12-08 14:17:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:16 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:16 --> URI Class Initialized
INFO - 2023-12-08 14:17:16 --> Router Class Initialized
INFO - 2023-12-08 14:17:16 --> Output Class Initialized
INFO - 2023-12-08 14:17:16 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:16 --> Input Class Initialized
INFO - 2023-12-08 14:17:16 --> Language Class Initialized
INFO - 2023-12-08 14:17:16 --> Language Class Initialized
INFO - 2023-12-08 14:17:16 --> Config Class Initialized
INFO - 2023-12-08 14:17:16 --> Loader Class Initialized
INFO - 2023-12-08 14:17:16 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:16 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:16 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:16 --> Controller Class Initialized
INFO - 2023-12-08 14:17:16 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:16 --> Total execution time: 0.0424
INFO - 2023-12-08 14:17:21 --> Config Class Initialized
INFO - 2023-12-08 14:17:21 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:21 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:21 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:21 --> URI Class Initialized
INFO - 2023-12-08 14:17:21 --> Router Class Initialized
INFO - 2023-12-08 14:17:21 --> Output Class Initialized
INFO - 2023-12-08 14:17:21 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:21 --> Input Class Initialized
INFO - 2023-12-08 14:17:21 --> Language Class Initialized
INFO - 2023-12-08 14:17:21 --> Language Class Initialized
INFO - 2023-12-08 14:17:21 --> Config Class Initialized
INFO - 2023-12-08 14:17:21 --> Loader Class Initialized
INFO - 2023-12-08 14:17:21 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:21 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:21 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:21 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:21 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:21 --> Controller Class Initialized
INFO - 2023-12-08 14:17:21 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:21 --> Total execution time: 0.2224
INFO - 2023-12-08 14:17:21 --> Config Class Initialized
INFO - 2023-12-08 14:17:21 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:21 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:21 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:21 --> URI Class Initialized
INFO - 2023-12-08 14:17:21 --> Router Class Initialized
INFO - 2023-12-08 14:17:21 --> Output Class Initialized
INFO - 2023-12-08 14:17:21 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:21 --> Input Class Initialized
INFO - 2023-12-08 14:17:21 --> Language Class Initialized
INFO - 2023-12-08 14:17:21 --> Language Class Initialized
INFO - 2023-12-08 14:17:21 --> Config Class Initialized
INFO - 2023-12-08 14:17:21 --> Loader Class Initialized
INFO - 2023-12-08 14:17:21 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:21 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:21 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:21 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:21 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:21 --> Controller Class Initialized
INFO - 2023-12-08 14:17:22 --> Config Class Initialized
INFO - 2023-12-08 14:17:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:22 --> URI Class Initialized
INFO - 2023-12-08 14:17:22 --> Router Class Initialized
INFO - 2023-12-08 14:17:22 --> Output Class Initialized
INFO - 2023-12-08 14:17:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:22 --> Input Class Initialized
INFO - 2023-12-08 14:17:22 --> Language Class Initialized
INFO - 2023-12-08 14:17:22 --> Language Class Initialized
INFO - 2023-12-08 14:17:22 --> Config Class Initialized
INFO - 2023-12-08 14:17:22 --> Loader Class Initialized
INFO - 2023-12-08 14:17:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:22 --> Controller Class Initialized
INFO - 2023-12-08 14:17:22 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:22 --> Total execution time: 0.0422
INFO - 2023-12-08 14:17:24 --> Config Class Initialized
INFO - 2023-12-08 14:17:24 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:24 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:24 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:24 --> URI Class Initialized
INFO - 2023-12-08 14:17:24 --> Router Class Initialized
INFO - 2023-12-08 14:17:24 --> Output Class Initialized
INFO - 2023-12-08 14:17:24 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:24 --> Input Class Initialized
INFO - 2023-12-08 14:17:24 --> Language Class Initialized
INFO - 2023-12-08 14:17:24 --> Language Class Initialized
INFO - 2023-12-08 14:17:24 --> Config Class Initialized
INFO - 2023-12-08 14:17:24 --> Loader Class Initialized
INFO - 2023-12-08 14:17:24 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:24 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:24 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:24 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:24 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:24 --> Controller Class Initialized
INFO - 2023-12-08 14:17:24 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:24 --> Total execution time: 0.0449
INFO - 2023-12-08 14:17:45 --> Config Class Initialized
INFO - 2023-12-08 14:17:45 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:45 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:45 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:45 --> URI Class Initialized
INFO - 2023-12-08 14:17:45 --> Router Class Initialized
INFO - 2023-12-08 14:17:45 --> Output Class Initialized
INFO - 2023-12-08 14:17:45 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:45 --> Input Class Initialized
INFO - 2023-12-08 14:17:45 --> Language Class Initialized
INFO - 2023-12-08 14:17:45 --> Language Class Initialized
INFO - 2023-12-08 14:17:45 --> Config Class Initialized
INFO - 2023-12-08 14:17:45 --> Loader Class Initialized
INFO - 2023-12-08 14:17:45 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:45 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:45 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:45 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:45 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:45 --> Controller Class Initialized
INFO - 2023-12-08 14:17:46 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:46 --> Total execution time: 0.4331
INFO - 2023-12-08 14:17:47 --> Config Class Initialized
INFO - 2023-12-08 14:17:47 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:47 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:47 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:47 --> URI Class Initialized
INFO - 2023-12-08 14:17:47 --> Router Class Initialized
INFO - 2023-12-08 14:17:47 --> Output Class Initialized
INFO - 2023-12-08 14:17:47 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:47 --> Input Class Initialized
INFO - 2023-12-08 14:17:47 --> Language Class Initialized
INFO - 2023-12-08 14:17:47 --> Language Class Initialized
INFO - 2023-12-08 14:17:47 --> Config Class Initialized
INFO - 2023-12-08 14:17:47 --> Loader Class Initialized
INFO - 2023-12-08 14:17:47 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:47 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:47 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:47 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:47 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:47 --> Controller Class Initialized
ERROR - 2023-12-08 14:17:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've noticed, and I understand that it may lead to a lesser inclination towards ma' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:17:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:17:48 --> Config Class Initialized
INFO - 2023-12-08 14:17:48 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:48 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:48 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:48 --> URI Class Initialized
INFO - 2023-12-08 14:17:48 --> Router Class Initialized
INFO - 2023-12-08 14:17:48 --> Output Class Initialized
INFO - 2023-12-08 14:17:48 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:48 --> Input Class Initialized
INFO - 2023-12-08 14:17:48 --> Language Class Initialized
INFO - 2023-12-08 14:17:48 --> Language Class Initialized
INFO - 2023-12-08 14:17:48 --> Config Class Initialized
INFO - 2023-12-08 14:17:48 --> Loader Class Initialized
INFO - 2023-12-08 14:17:48 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:48 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:48 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:48 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:48 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:48 --> Controller Class Initialized
DEBUG - 2023-12-08 14:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:17:48 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:48 --> Total execution time: 0.0460
INFO - 2023-12-08 14:17:52 --> Config Class Initialized
INFO - 2023-12-08 14:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:52 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:52 --> URI Class Initialized
INFO - 2023-12-08 14:17:52 --> Router Class Initialized
INFO - 2023-12-08 14:17:52 --> Output Class Initialized
INFO - 2023-12-08 14:17:52 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:52 --> Input Class Initialized
INFO - 2023-12-08 14:17:52 --> Language Class Initialized
INFO - 2023-12-08 14:17:52 --> Language Class Initialized
INFO - 2023-12-08 14:17:52 --> Config Class Initialized
INFO - 2023-12-08 14:17:52 --> Loader Class Initialized
INFO - 2023-12-08 14:17:52 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:52 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:52 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:52 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:52 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:52 --> Controller Class Initialized
DEBUG - 2023-12-08 14:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:17:52 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:52 --> Total execution time: 0.0452
INFO - 2023-12-08 14:17:56 --> Config Class Initialized
INFO - 2023-12-08 14:17:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:17:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:17:56 --> Utf8 Class Initialized
INFO - 2023-12-08 14:17:56 --> URI Class Initialized
INFO - 2023-12-08 14:17:56 --> Router Class Initialized
INFO - 2023-12-08 14:17:56 --> Output Class Initialized
INFO - 2023-12-08 14:17:56 --> Security Class Initialized
DEBUG - 2023-12-08 14:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:17:56 --> Input Class Initialized
INFO - 2023-12-08 14:17:56 --> Language Class Initialized
INFO - 2023-12-08 14:17:56 --> Language Class Initialized
INFO - 2023-12-08 14:17:56 --> Config Class Initialized
INFO - 2023-12-08 14:17:56 --> Loader Class Initialized
INFO - 2023-12-08 14:17:56 --> Helper loaded: url_helper
INFO - 2023-12-08 14:17:56 --> Helper loaded: file_helper
INFO - 2023-12-08 14:17:56 --> Helper loaded: form_helper
INFO - 2023-12-08 14:17:56 --> Helper loaded: my_helper
INFO - 2023-12-08 14:17:56 --> Database Driver Class Initialized
INFO - 2023-12-08 14:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:17:56 --> Controller Class Initialized
INFO - 2023-12-08 14:17:56 --> Final output sent to browser
DEBUG - 2023-12-08 14:17:56 --> Total execution time: 0.0389
INFO - 2023-12-08 14:18:03 --> Config Class Initialized
INFO - 2023-12-08 14:18:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:03 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:03 --> URI Class Initialized
INFO - 2023-12-08 14:18:03 --> Router Class Initialized
INFO - 2023-12-08 14:18:03 --> Output Class Initialized
INFO - 2023-12-08 14:18:03 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:03 --> Input Class Initialized
INFO - 2023-12-08 14:18:03 --> Language Class Initialized
INFO - 2023-12-08 14:18:03 --> Language Class Initialized
INFO - 2023-12-08 14:18:03 --> Config Class Initialized
INFO - 2023-12-08 14:18:03 --> Loader Class Initialized
INFO - 2023-12-08 14:18:03 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:03 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:03 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:03 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:03 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:03 --> Controller Class Initialized
INFO - 2023-12-08 14:18:03 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:03 --> Total execution time: 0.0428
INFO - 2023-12-08 14:18:10 --> Config Class Initialized
INFO - 2023-12-08 14:18:10 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:10 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:10 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:10 --> URI Class Initialized
INFO - 2023-12-08 14:18:10 --> Router Class Initialized
INFO - 2023-12-08 14:18:10 --> Output Class Initialized
INFO - 2023-12-08 14:18:10 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:10 --> Input Class Initialized
INFO - 2023-12-08 14:18:10 --> Language Class Initialized
INFO - 2023-12-08 14:18:10 --> Language Class Initialized
INFO - 2023-12-08 14:18:10 --> Config Class Initialized
INFO - 2023-12-08 14:18:10 --> Loader Class Initialized
INFO - 2023-12-08 14:18:10 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:10 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:10 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:10 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:10 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:10 --> Controller Class Initialized
INFO - 2023-12-08 14:18:10 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:10 --> Total execution time: 0.1162
INFO - 2023-12-08 14:18:14 --> Config Class Initialized
INFO - 2023-12-08 14:18:14 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:14 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:14 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:14 --> URI Class Initialized
INFO - 2023-12-08 14:18:14 --> Router Class Initialized
INFO - 2023-12-08 14:18:14 --> Output Class Initialized
INFO - 2023-12-08 14:18:14 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:14 --> Input Class Initialized
INFO - 2023-12-08 14:18:14 --> Language Class Initialized
INFO - 2023-12-08 14:18:14 --> Language Class Initialized
INFO - 2023-12-08 14:18:14 --> Config Class Initialized
INFO - 2023-12-08 14:18:14 --> Loader Class Initialized
INFO - 2023-12-08 14:18:14 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:14 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:14 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:14 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:14 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:14 --> Controller Class Initialized
DEBUG - 2023-12-08 14:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:18:14 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:14 --> Total execution time: 0.1507
INFO - 2023-12-08 14:18:16 --> Config Class Initialized
INFO - 2023-12-08 14:18:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:16 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:16 --> URI Class Initialized
INFO - 2023-12-08 14:18:16 --> Router Class Initialized
INFO - 2023-12-08 14:18:16 --> Output Class Initialized
INFO - 2023-12-08 14:18:16 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:16 --> Input Class Initialized
INFO - 2023-12-08 14:18:16 --> Language Class Initialized
INFO - 2023-12-08 14:18:16 --> Language Class Initialized
INFO - 2023-12-08 14:18:16 --> Config Class Initialized
INFO - 2023-12-08 14:18:16 --> Loader Class Initialized
INFO - 2023-12-08 14:18:16 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:16 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:16 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:16 --> Controller Class Initialized
DEBUG - 2023-12-08 14:18:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:18:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:18:16 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:16 --> Total execution time: 0.0400
INFO - 2023-12-08 14:18:19 --> Config Class Initialized
INFO - 2023-12-08 14:18:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:19 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:19 --> URI Class Initialized
INFO - 2023-12-08 14:18:19 --> Router Class Initialized
INFO - 2023-12-08 14:18:19 --> Output Class Initialized
INFO - 2023-12-08 14:18:19 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:19 --> Input Class Initialized
INFO - 2023-12-08 14:18:19 --> Language Class Initialized
INFO - 2023-12-08 14:18:19 --> Language Class Initialized
INFO - 2023-12-08 14:18:19 --> Config Class Initialized
INFO - 2023-12-08 14:18:19 --> Loader Class Initialized
INFO - 2023-12-08 14:18:19 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:19 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:19 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:19 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:19 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:19 --> Controller Class Initialized
INFO - 2023-12-08 14:18:19 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:19 --> Total execution time: 0.0444
INFO - 2023-12-08 14:18:19 --> Config Class Initialized
INFO - 2023-12-08 14:18:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:19 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:19 --> URI Class Initialized
INFO - 2023-12-08 14:18:19 --> Router Class Initialized
INFO - 2023-12-08 14:18:19 --> Output Class Initialized
INFO - 2023-12-08 14:18:19 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:19 --> Input Class Initialized
INFO - 2023-12-08 14:18:19 --> Language Class Initialized
INFO - 2023-12-08 14:18:19 --> Language Class Initialized
INFO - 2023-12-08 14:18:19 --> Config Class Initialized
INFO - 2023-12-08 14:18:19 --> Loader Class Initialized
INFO - 2023-12-08 14:18:19 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:19 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:19 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:19 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:19 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:19 --> Controller Class Initialized
ERROR - 2023-12-08 14:18:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've noticed, and I understand that it may lead to a lesser inclination towards ma' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = '-', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:18:19 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:18:22 --> Config Class Initialized
INFO - 2023-12-08 14:18:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:22 --> URI Class Initialized
INFO - 2023-12-08 14:18:22 --> Router Class Initialized
INFO - 2023-12-08 14:18:22 --> Output Class Initialized
INFO - 2023-12-08 14:18:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:22 --> Input Class Initialized
INFO - 2023-12-08 14:18:22 --> Language Class Initialized
INFO - 2023-12-08 14:18:22 --> Language Class Initialized
INFO - 2023-12-08 14:18:22 --> Config Class Initialized
INFO - 2023-12-08 14:18:22 --> Loader Class Initialized
INFO - 2023-12-08 14:18:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:23 --> Controller Class Initialized
DEBUG - 2023-12-08 14:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:18:23 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:23 --> Total execution time: 0.2208
INFO - 2023-12-08 14:18:23 --> Config Class Initialized
INFO - 2023-12-08 14:18:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:23 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:23 --> URI Class Initialized
INFO - 2023-12-08 14:18:23 --> Router Class Initialized
INFO - 2023-12-08 14:18:23 --> Output Class Initialized
INFO - 2023-12-08 14:18:23 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:23 --> Input Class Initialized
INFO - 2023-12-08 14:18:23 --> Language Class Initialized
INFO - 2023-12-08 14:18:23 --> Language Class Initialized
INFO - 2023-12-08 14:18:23 --> Config Class Initialized
INFO - 2023-12-08 14:18:23 --> Loader Class Initialized
INFO - 2023-12-08 14:18:23 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:23 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:23 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:23 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:23 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:23 --> Controller Class Initialized
INFO - 2023-12-08 14:18:23 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:23 --> Total execution time: 0.0649
INFO - 2023-12-08 14:18:23 --> Config Class Initialized
INFO - 2023-12-08 14:18:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:23 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:23 --> URI Class Initialized
INFO - 2023-12-08 14:18:23 --> Router Class Initialized
INFO - 2023-12-08 14:18:23 --> Output Class Initialized
INFO - 2023-12-08 14:18:23 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:23 --> Input Class Initialized
INFO - 2023-12-08 14:18:23 --> Language Class Initialized
INFO - 2023-12-08 14:18:23 --> Language Class Initialized
INFO - 2023-12-08 14:18:23 --> Config Class Initialized
INFO - 2023-12-08 14:18:23 --> Loader Class Initialized
INFO - 2023-12-08 14:18:23 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:23 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:23 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:23 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:23 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:23 --> Controller Class Initialized
INFO - 2023-12-08 14:18:28 --> Config Class Initialized
INFO - 2023-12-08 14:18:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:28 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:28 --> URI Class Initialized
INFO - 2023-12-08 14:18:28 --> Router Class Initialized
INFO - 2023-12-08 14:18:28 --> Output Class Initialized
INFO - 2023-12-08 14:18:28 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:28 --> Input Class Initialized
INFO - 2023-12-08 14:18:28 --> Language Class Initialized
INFO - 2023-12-08 14:18:28 --> Language Class Initialized
INFO - 2023-12-08 14:18:28 --> Config Class Initialized
INFO - 2023-12-08 14:18:28 --> Loader Class Initialized
INFO - 2023-12-08 14:18:28 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:28 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:28 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:28 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:28 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:28 --> Controller Class Initialized
DEBUG - 2023-12-08 14:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:18:28 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:28 --> Total execution time: 0.1129
INFO - 2023-12-08 14:18:29 --> Config Class Initialized
INFO - 2023-12-08 14:18:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:29 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:29 --> URI Class Initialized
INFO - 2023-12-08 14:18:29 --> Router Class Initialized
INFO - 2023-12-08 14:18:29 --> Output Class Initialized
INFO - 2023-12-08 14:18:29 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:29 --> Input Class Initialized
INFO - 2023-12-08 14:18:29 --> Language Class Initialized
INFO - 2023-12-08 14:18:29 --> Language Class Initialized
INFO - 2023-12-08 14:18:29 --> Config Class Initialized
INFO - 2023-12-08 14:18:29 --> Loader Class Initialized
INFO - 2023-12-08 14:18:30 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:30 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:30 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:30 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:30 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:30 --> Controller Class Initialized
DEBUG - 2023-12-08 14:18:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:18:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:18:30 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:30 --> Total execution time: 0.0902
INFO - 2023-12-08 14:18:31 --> Config Class Initialized
INFO - 2023-12-08 14:18:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:31 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:31 --> URI Class Initialized
INFO - 2023-12-08 14:18:31 --> Router Class Initialized
INFO - 2023-12-08 14:18:31 --> Output Class Initialized
INFO - 2023-12-08 14:18:31 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:31 --> Input Class Initialized
INFO - 2023-12-08 14:18:31 --> Language Class Initialized
INFO - 2023-12-08 14:18:31 --> Language Class Initialized
INFO - 2023-12-08 14:18:31 --> Config Class Initialized
INFO - 2023-12-08 14:18:31 --> Loader Class Initialized
INFO - 2023-12-08 14:18:31 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:31 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:31 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:31 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:31 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:31 --> Controller Class Initialized
INFO - 2023-12-08 14:18:31 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:31 --> Total execution time: 0.1763
INFO - 2023-12-08 14:18:44 --> Config Class Initialized
INFO - 2023-12-08 14:18:44 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:44 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:44 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:44 --> URI Class Initialized
INFO - 2023-12-08 14:18:44 --> Router Class Initialized
INFO - 2023-12-08 14:18:44 --> Output Class Initialized
INFO - 2023-12-08 14:18:44 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:44 --> Input Class Initialized
INFO - 2023-12-08 14:18:44 --> Language Class Initialized
INFO - 2023-12-08 14:18:44 --> Language Class Initialized
INFO - 2023-12-08 14:18:44 --> Config Class Initialized
INFO - 2023-12-08 14:18:44 --> Loader Class Initialized
INFO - 2023-12-08 14:18:44 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:44 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:44 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:44 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:44 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:44 --> Controller Class Initialized
INFO - 2023-12-08 14:18:44 --> Final output sent to browser
DEBUG - 2023-12-08 14:18:44 --> Total execution time: 0.0678
INFO - 2023-12-08 14:18:56 --> Config Class Initialized
INFO - 2023-12-08 14:18:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:18:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:18:56 --> Utf8 Class Initialized
INFO - 2023-12-08 14:18:56 --> URI Class Initialized
INFO - 2023-12-08 14:18:56 --> Router Class Initialized
INFO - 2023-12-08 14:18:56 --> Output Class Initialized
INFO - 2023-12-08 14:18:56 --> Security Class Initialized
DEBUG - 2023-12-08 14:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:18:56 --> Input Class Initialized
INFO - 2023-12-08 14:18:56 --> Language Class Initialized
INFO - 2023-12-08 14:18:56 --> Language Class Initialized
INFO - 2023-12-08 14:18:56 --> Config Class Initialized
INFO - 2023-12-08 14:18:56 --> Loader Class Initialized
INFO - 2023-12-08 14:18:56 --> Helper loaded: url_helper
INFO - 2023-12-08 14:18:56 --> Helper loaded: file_helper
INFO - 2023-12-08 14:18:56 --> Helper loaded: form_helper
INFO - 2023-12-08 14:18:56 --> Helper loaded: my_helper
INFO - 2023-12-08 14:18:56 --> Database Driver Class Initialized
INFO - 2023-12-08 14:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:18:56 --> Controller Class Initialized
ERROR - 2023-12-08 14:18:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've demonstrated commendable progress, particularly in number skills and angles a' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You've demonstrated commendable progress, particularly in number skills and angles and shapes. Nevertheless, there's room for improvement in algebra, fractions, decimals, percentages, and ratio and proportion. Enhancing your concentration will contribute significantly to advancing your knowledge in these areas. Direct your attention to focused learning in the classroom, ensuring a solid understanding of the material from its foundational concepts. Stay motivated, Kenzie!', nilai_mid = 'Your happy personality and right-brain dominance are something I've noticed, and I understand that it may lead to a lesser inclination towards mathematics. However, a bit of effort won't hurt. You do have reasonably quick reasoning skills. It's just that, because you're less interested, you might not be inclined to put in more effort. You tend to be passive in your learning, but when I directly ask you, you can provide very good answers. What you should work on is improving your focus and giving it another shot so that you can perform well in exam questions, at the very least.' WHERE id_guru_mapel = '4' AND id_mapel_kd = '6' AND id_siswa = '2' AND jenis = 'c'
INFO - 2023-12-08 14:18:56 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-08 14:19:03 --> Config Class Initialized
INFO - 2023-12-08 14:19:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:03 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:03 --> URI Class Initialized
INFO - 2023-12-08 14:19:03 --> Router Class Initialized
INFO - 2023-12-08 14:19:03 --> Output Class Initialized
INFO - 2023-12-08 14:19:03 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:03 --> Input Class Initialized
INFO - 2023-12-08 14:19:03 --> Language Class Initialized
INFO - 2023-12-08 14:19:03 --> Language Class Initialized
INFO - 2023-12-08 14:19:03 --> Config Class Initialized
INFO - 2023-12-08 14:19:03 --> Loader Class Initialized
INFO - 2023-12-08 14:19:03 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:03 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:03 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:03 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:03 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:03 --> Controller Class Initialized
INFO - 2023-12-08 14:19:03 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:03 --> Total execution time: 0.0614
INFO - 2023-12-08 14:19:03 --> Config Class Initialized
INFO - 2023-12-08 14:19:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:03 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:03 --> URI Class Initialized
INFO - 2023-12-08 14:19:03 --> Router Class Initialized
INFO - 2023-12-08 14:19:03 --> Output Class Initialized
INFO - 2023-12-08 14:19:03 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:03 --> Input Class Initialized
INFO - 2023-12-08 14:19:03 --> Language Class Initialized
INFO - 2023-12-08 14:19:03 --> Language Class Initialized
INFO - 2023-12-08 14:19:03 --> Config Class Initialized
INFO - 2023-12-08 14:19:03 --> Loader Class Initialized
INFO - 2023-12-08 14:19:03 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:03 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:03 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:03 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:03 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:03 --> Controller Class Initialized
INFO - 2023-12-08 14:19:07 --> Config Class Initialized
INFO - 2023-12-08 14:19:07 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:07 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:07 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:07 --> URI Class Initialized
INFO - 2023-12-08 14:19:07 --> Router Class Initialized
INFO - 2023-12-08 14:19:07 --> Output Class Initialized
INFO - 2023-12-08 14:19:07 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:07 --> Input Class Initialized
INFO - 2023-12-08 14:19:07 --> Language Class Initialized
INFO - 2023-12-08 14:19:07 --> Language Class Initialized
INFO - 2023-12-08 14:19:07 --> Config Class Initialized
INFO - 2023-12-08 14:19:07 --> Loader Class Initialized
INFO - 2023-12-08 14:19:07 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:07 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:07 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:07 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:07 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:07 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:19:07 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:07 --> Total execution time: 0.1343
INFO - 2023-12-08 14:19:15 --> Config Class Initialized
INFO - 2023-12-08 14:19:15 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:15 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:15 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:15 --> URI Class Initialized
INFO - 2023-12-08 14:19:15 --> Router Class Initialized
INFO - 2023-12-08 14:19:15 --> Output Class Initialized
INFO - 2023-12-08 14:19:15 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:15 --> Input Class Initialized
INFO - 2023-12-08 14:19:15 --> Language Class Initialized
INFO - 2023-12-08 14:19:16 --> Language Class Initialized
INFO - 2023-12-08 14:19:16 --> Config Class Initialized
INFO - 2023-12-08 14:19:16 --> Loader Class Initialized
INFO - 2023-12-08 14:19:16 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:16 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:16 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:16 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:19:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:19:16 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:16 --> Total execution time: 0.2243
INFO - 2023-12-08 14:19:16 --> Config Class Initialized
INFO - 2023-12-08 14:19:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:16 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:16 --> URI Class Initialized
INFO - 2023-12-08 14:19:16 --> Router Class Initialized
INFO - 2023-12-08 14:19:16 --> Output Class Initialized
INFO - 2023-12-08 14:19:16 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:16 --> Input Class Initialized
INFO - 2023-12-08 14:19:16 --> Language Class Initialized
INFO - 2023-12-08 14:19:16 --> Language Class Initialized
INFO - 2023-12-08 14:19:16 --> Config Class Initialized
INFO - 2023-12-08 14:19:16 --> Loader Class Initialized
INFO - 2023-12-08 14:19:16 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:16 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:16 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:16 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:16 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:16 --> Controller Class Initialized
INFO - 2023-12-08 14:19:20 --> Config Class Initialized
INFO - 2023-12-08 14:19:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:20 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:20 --> URI Class Initialized
INFO - 2023-12-08 14:19:20 --> Router Class Initialized
INFO - 2023-12-08 14:19:20 --> Output Class Initialized
INFO - 2023-12-08 14:19:20 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:20 --> Input Class Initialized
INFO - 2023-12-08 14:19:20 --> Language Class Initialized
INFO - 2023-12-08 14:19:20 --> Language Class Initialized
INFO - 2023-12-08 14:19:20 --> Config Class Initialized
INFO - 2023-12-08 14:19:20 --> Loader Class Initialized
INFO - 2023-12-08 14:19:20 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:20 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:20 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:20 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:20 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:20 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:19:20 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:20 --> Total execution time: 0.0459
INFO - 2023-12-08 14:19:28 --> Config Class Initialized
INFO - 2023-12-08 14:19:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:28 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:28 --> URI Class Initialized
INFO - 2023-12-08 14:19:28 --> Router Class Initialized
INFO - 2023-12-08 14:19:28 --> Output Class Initialized
INFO - 2023-12-08 14:19:28 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:28 --> Input Class Initialized
INFO - 2023-12-08 14:19:28 --> Language Class Initialized
INFO - 2023-12-08 14:19:28 --> Language Class Initialized
INFO - 2023-12-08 14:19:28 --> Config Class Initialized
INFO - 2023-12-08 14:19:28 --> Loader Class Initialized
INFO - 2023-12-08 14:19:28 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:28 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:28 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:28 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:28 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:28 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:19:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:19:28 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:28 --> Total execution time: 0.0643
INFO - 2023-12-08 14:19:33 --> Config Class Initialized
INFO - 2023-12-08 14:19:33 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:33 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:33 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:33 --> URI Class Initialized
INFO - 2023-12-08 14:19:33 --> Router Class Initialized
INFO - 2023-12-08 14:19:33 --> Output Class Initialized
INFO - 2023-12-08 14:19:33 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:33 --> Input Class Initialized
INFO - 2023-12-08 14:19:33 --> Language Class Initialized
INFO - 2023-12-08 14:19:33 --> Language Class Initialized
INFO - 2023-12-08 14:19:33 --> Config Class Initialized
INFO - 2023-12-08 14:19:33 --> Loader Class Initialized
INFO - 2023-12-08 14:19:33 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:33 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:33 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:33 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:33 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:33 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:19:33 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:33 --> Total execution time: 0.0536
INFO - 2023-12-08 14:19:33 --> Config Class Initialized
INFO - 2023-12-08 14:19:33 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:33 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:33 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:33 --> URI Class Initialized
INFO - 2023-12-08 14:19:33 --> Router Class Initialized
INFO - 2023-12-08 14:19:33 --> Output Class Initialized
INFO - 2023-12-08 14:19:33 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:33 --> Input Class Initialized
INFO - 2023-12-08 14:19:33 --> Language Class Initialized
INFO - 2023-12-08 14:19:33 --> Language Class Initialized
INFO - 2023-12-08 14:19:33 --> Config Class Initialized
INFO - 2023-12-08 14:19:33 --> Loader Class Initialized
INFO - 2023-12-08 14:19:33 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:33 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:33 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:33 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:33 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:33 --> Controller Class Initialized
INFO - 2023-12-08 14:19:36 --> Config Class Initialized
INFO - 2023-12-08 14:19:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:36 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:36 --> URI Class Initialized
INFO - 2023-12-08 14:19:36 --> Router Class Initialized
INFO - 2023-12-08 14:19:36 --> Output Class Initialized
INFO - 2023-12-08 14:19:36 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:36 --> Input Class Initialized
INFO - 2023-12-08 14:19:36 --> Language Class Initialized
INFO - 2023-12-08 14:19:36 --> Language Class Initialized
INFO - 2023-12-08 14:19:36 --> Config Class Initialized
INFO - 2023-12-08 14:19:36 --> Loader Class Initialized
INFO - 2023-12-08 14:19:36 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:36 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:36 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:36 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:36 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:36 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:19:36 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:36 --> Total execution time: 0.1600
INFO - 2023-12-08 14:19:46 --> Config Class Initialized
INFO - 2023-12-08 14:19:46 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:46 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:46 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:46 --> URI Class Initialized
INFO - 2023-12-08 14:19:46 --> Router Class Initialized
INFO - 2023-12-08 14:19:46 --> Output Class Initialized
INFO - 2023-12-08 14:19:46 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:46 --> Input Class Initialized
INFO - 2023-12-08 14:19:46 --> Language Class Initialized
INFO - 2023-12-08 14:19:46 --> Language Class Initialized
INFO - 2023-12-08 14:19:46 --> Config Class Initialized
INFO - 2023-12-08 14:19:46 --> Loader Class Initialized
INFO - 2023-12-08 14:19:46 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:46 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:46 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:46 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:46 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:46 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:19:46 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:46 --> Total execution time: 0.0379
INFO - 2023-12-08 14:19:47 --> Config Class Initialized
INFO - 2023-12-08 14:19:47 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:47 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:47 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:47 --> URI Class Initialized
INFO - 2023-12-08 14:19:47 --> Router Class Initialized
INFO - 2023-12-08 14:19:47 --> Output Class Initialized
INFO - 2023-12-08 14:19:47 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:47 --> Input Class Initialized
INFO - 2023-12-08 14:19:47 --> Language Class Initialized
INFO - 2023-12-08 14:19:47 --> Language Class Initialized
INFO - 2023-12-08 14:19:47 --> Config Class Initialized
INFO - 2023-12-08 14:19:47 --> Loader Class Initialized
INFO - 2023-12-08 14:19:47 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:47 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:47 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:47 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:47 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:47 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:19:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:19:47 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:47 --> Total execution time: 0.0466
INFO - 2023-12-08 14:19:48 --> Config Class Initialized
INFO - 2023-12-08 14:19:48 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:48 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:48 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:48 --> URI Class Initialized
INFO - 2023-12-08 14:19:48 --> Router Class Initialized
INFO - 2023-12-08 14:19:48 --> Output Class Initialized
INFO - 2023-12-08 14:19:48 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:48 --> Input Class Initialized
INFO - 2023-12-08 14:19:48 --> Language Class Initialized
INFO - 2023-12-08 14:19:48 --> Language Class Initialized
INFO - 2023-12-08 14:19:48 --> Config Class Initialized
INFO - 2023-12-08 14:19:48 --> Loader Class Initialized
INFO - 2023-12-08 14:19:48 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:48 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:48 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:48 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:48 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:48 --> Controller Class Initialized
INFO - 2023-12-08 14:19:49 --> Config Class Initialized
INFO - 2023-12-08 14:19:49 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:49 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:49 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:49 --> URI Class Initialized
INFO - 2023-12-08 14:19:49 --> Router Class Initialized
INFO - 2023-12-08 14:19:49 --> Output Class Initialized
INFO - 2023-12-08 14:19:49 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:49 --> Input Class Initialized
INFO - 2023-12-08 14:19:49 --> Language Class Initialized
INFO - 2023-12-08 14:19:49 --> Language Class Initialized
INFO - 2023-12-08 14:19:49 --> Config Class Initialized
INFO - 2023-12-08 14:19:49 --> Loader Class Initialized
INFO - 2023-12-08 14:19:49 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:49 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:49 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:49 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:49 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:49 --> Controller Class Initialized
INFO - 2023-12-08 14:19:50 --> Config Class Initialized
INFO - 2023-12-08 14:19:50 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:19:50 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:19:50 --> Utf8 Class Initialized
INFO - 2023-12-08 14:19:50 --> URI Class Initialized
INFO - 2023-12-08 14:19:50 --> Router Class Initialized
INFO - 2023-12-08 14:19:50 --> Output Class Initialized
INFO - 2023-12-08 14:19:50 --> Security Class Initialized
DEBUG - 2023-12-08 14:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:19:50 --> Input Class Initialized
INFO - 2023-12-08 14:19:50 --> Language Class Initialized
INFO - 2023-12-08 14:19:50 --> Language Class Initialized
INFO - 2023-12-08 14:19:50 --> Config Class Initialized
INFO - 2023-12-08 14:19:50 --> Loader Class Initialized
INFO - 2023-12-08 14:19:50 --> Helper loaded: url_helper
INFO - 2023-12-08 14:19:50 --> Helper loaded: file_helper
INFO - 2023-12-08 14:19:50 --> Helper loaded: form_helper
INFO - 2023-12-08 14:19:50 --> Helper loaded: my_helper
INFO - 2023-12-08 14:19:50 --> Database Driver Class Initialized
INFO - 2023-12-08 14:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:19:50 --> Controller Class Initialized
DEBUG - 2023-12-08 14:19:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:19:50 --> Final output sent to browser
DEBUG - 2023-12-08 14:19:50 --> Total execution time: 0.1193
INFO - 2023-12-08 14:20:02 --> Config Class Initialized
INFO - 2023-12-08 14:20:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:20:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:20:02 --> Utf8 Class Initialized
INFO - 2023-12-08 14:20:02 --> URI Class Initialized
INFO - 2023-12-08 14:20:02 --> Router Class Initialized
INFO - 2023-12-08 14:20:02 --> Output Class Initialized
INFO - 2023-12-08 14:20:02 --> Security Class Initialized
DEBUG - 2023-12-08 14:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:20:02 --> Input Class Initialized
INFO - 2023-12-08 14:20:02 --> Language Class Initialized
INFO - 2023-12-08 14:20:02 --> Language Class Initialized
INFO - 2023-12-08 14:20:02 --> Config Class Initialized
INFO - 2023-12-08 14:20:02 --> Loader Class Initialized
INFO - 2023-12-08 14:20:02 --> Helper loaded: url_helper
INFO - 2023-12-08 14:20:02 --> Helper loaded: file_helper
INFO - 2023-12-08 14:20:02 --> Helper loaded: form_helper
INFO - 2023-12-08 14:20:02 --> Helper loaded: my_helper
INFO - 2023-12-08 14:20:02 --> Database Driver Class Initialized
INFO - 2023-12-08 14:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:20:02 --> Controller Class Initialized
INFO - 2023-12-08 14:20:02 --> Final output sent to browser
DEBUG - 2023-12-08 14:20:02 --> Total execution time: 0.0594
INFO - 2023-12-08 14:20:13 --> Config Class Initialized
INFO - 2023-12-08 14:20:13 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:20:13 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:20:13 --> Utf8 Class Initialized
INFO - 2023-12-08 14:20:13 --> URI Class Initialized
INFO - 2023-12-08 14:20:13 --> Router Class Initialized
INFO - 2023-12-08 14:20:13 --> Output Class Initialized
INFO - 2023-12-08 14:20:13 --> Security Class Initialized
DEBUG - 2023-12-08 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:20:13 --> Input Class Initialized
INFO - 2023-12-08 14:20:13 --> Language Class Initialized
INFO - 2023-12-08 14:20:13 --> Language Class Initialized
INFO - 2023-12-08 14:20:13 --> Config Class Initialized
INFO - 2023-12-08 14:20:13 --> Loader Class Initialized
INFO - 2023-12-08 14:20:13 --> Helper loaded: url_helper
INFO - 2023-12-08 14:20:13 --> Helper loaded: file_helper
INFO - 2023-12-08 14:20:13 --> Helper loaded: form_helper
INFO - 2023-12-08 14:20:13 --> Helper loaded: my_helper
INFO - 2023-12-08 14:20:13 --> Database Driver Class Initialized
INFO - 2023-12-08 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:20:13 --> Controller Class Initialized
INFO - 2023-12-08 14:20:13 --> Final output sent to browser
DEBUG - 2023-12-08 14:20:13 --> Total execution time: 0.0756
INFO - 2023-12-08 14:20:20 --> Config Class Initialized
INFO - 2023-12-08 14:20:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:20:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:20:20 --> Utf8 Class Initialized
INFO - 2023-12-08 14:20:20 --> URI Class Initialized
INFO - 2023-12-08 14:20:20 --> Router Class Initialized
INFO - 2023-12-08 14:20:21 --> Output Class Initialized
INFO - 2023-12-08 14:20:21 --> Security Class Initialized
DEBUG - 2023-12-08 14:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:20:21 --> Input Class Initialized
INFO - 2023-12-08 14:20:21 --> Language Class Initialized
INFO - 2023-12-08 14:20:21 --> Language Class Initialized
INFO - 2023-12-08 14:20:21 --> Config Class Initialized
INFO - 2023-12-08 14:20:21 --> Loader Class Initialized
INFO - 2023-12-08 14:20:21 --> Helper loaded: url_helper
INFO - 2023-12-08 14:20:21 --> Helper loaded: file_helper
INFO - 2023-12-08 14:20:21 --> Helper loaded: form_helper
INFO - 2023-12-08 14:20:21 --> Helper loaded: my_helper
INFO - 2023-12-08 14:20:21 --> Database Driver Class Initialized
INFO - 2023-12-08 14:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:20:21 --> Controller Class Initialized
INFO - 2023-12-08 14:20:21 --> Final output sent to browser
DEBUG - 2023-12-08 14:20:21 --> Total execution time: 0.0472
INFO - 2023-12-08 14:20:21 --> Config Class Initialized
INFO - 2023-12-08 14:20:21 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:20:21 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:20:21 --> Utf8 Class Initialized
INFO - 2023-12-08 14:20:21 --> URI Class Initialized
INFO - 2023-12-08 14:20:21 --> Router Class Initialized
INFO - 2023-12-08 14:20:21 --> Output Class Initialized
INFO - 2023-12-08 14:20:21 --> Security Class Initialized
DEBUG - 2023-12-08 14:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:20:21 --> Input Class Initialized
INFO - 2023-12-08 14:20:21 --> Language Class Initialized
INFO - 2023-12-08 14:20:21 --> Language Class Initialized
INFO - 2023-12-08 14:20:21 --> Config Class Initialized
INFO - 2023-12-08 14:20:21 --> Loader Class Initialized
INFO - 2023-12-08 14:20:21 --> Helper loaded: url_helper
INFO - 2023-12-08 14:20:21 --> Helper loaded: file_helper
INFO - 2023-12-08 14:20:21 --> Helper loaded: form_helper
INFO - 2023-12-08 14:20:21 --> Helper loaded: my_helper
INFO - 2023-12-08 14:20:21 --> Database Driver Class Initialized
INFO - 2023-12-08 14:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:20:21 --> Controller Class Initialized
INFO - 2023-12-08 14:21:03 --> Config Class Initialized
INFO - 2023-12-08 14:21:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:03 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:03 --> URI Class Initialized
INFO - 2023-12-08 14:21:03 --> Router Class Initialized
INFO - 2023-12-08 14:21:03 --> Output Class Initialized
INFO - 2023-12-08 14:21:03 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:03 --> Input Class Initialized
INFO - 2023-12-08 14:21:03 --> Language Class Initialized
INFO - 2023-12-08 14:21:03 --> Language Class Initialized
INFO - 2023-12-08 14:21:03 --> Config Class Initialized
INFO - 2023-12-08 14:21:03 --> Loader Class Initialized
INFO - 2023-12-08 14:21:03 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:03 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:03 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:03 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:03 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:03 --> Controller Class Initialized
DEBUG - 2023-12-08 14:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:21:03 --> Final output sent to browser
DEBUG - 2023-12-08 14:21:03 --> Total execution time: 0.4695
INFO - 2023-12-08 14:21:12 --> Config Class Initialized
INFO - 2023-12-08 14:21:12 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:12 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:12 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:12 --> URI Class Initialized
INFO - 2023-12-08 14:21:12 --> Router Class Initialized
INFO - 2023-12-08 14:21:12 --> Output Class Initialized
INFO - 2023-12-08 14:21:12 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:12 --> Input Class Initialized
INFO - 2023-12-08 14:21:12 --> Language Class Initialized
INFO - 2023-12-08 14:21:12 --> Language Class Initialized
INFO - 2023-12-08 14:21:12 --> Config Class Initialized
INFO - 2023-12-08 14:21:12 --> Loader Class Initialized
INFO - 2023-12-08 14:21:12 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:12 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:12 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:12 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:12 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:12 --> Controller Class Initialized
INFO - 2023-12-08 14:21:12 --> Final output sent to browser
DEBUG - 2023-12-08 14:21:12 --> Total execution time: 0.0481
INFO - 2023-12-08 14:21:27 --> Config Class Initialized
INFO - 2023-12-08 14:21:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:27 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:27 --> URI Class Initialized
INFO - 2023-12-08 14:21:27 --> Router Class Initialized
INFO - 2023-12-08 14:21:27 --> Output Class Initialized
INFO - 2023-12-08 14:21:27 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:27 --> Input Class Initialized
INFO - 2023-12-08 14:21:27 --> Language Class Initialized
INFO - 2023-12-08 14:21:27 --> Language Class Initialized
INFO - 2023-12-08 14:21:27 --> Config Class Initialized
INFO - 2023-12-08 14:21:27 --> Loader Class Initialized
INFO - 2023-12-08 14:21:27 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:27 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:27 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:27 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:27 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:27 --> Controller Class Initialized
INFO - 2023-12-08 14:21:27 --> Final output sent to browser
DEBUG - 2023-12-08 14:21:27 --> Total execution time: 0.0560
INFO - 2023-12-08 14:21:27 --> Config Class Initialized
INFO - 2023-12-08 14:21:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:27 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:27 --> URI Class Initialized
INFO - 2023-12-08 14:21:27 --> Router Class Initialized
INFO - 2023-12-08 14:21:27 --> Output Class Initialized
INFO - 2023-12-08 14:21:27 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:27 --> Input Class Initialized
INFO - 2023-12-08 14:21:27 --> Language Class Initialized
INFO - 2023-12-08 14:21:27 --> Language Class Initialized
INFO - 2023-12-08 14:21:27 --> Config Class Initialized
INFO - 2023-12-08 14:21:27 --> Loader Class Initialized
INFO - 2023-12-08 14:21:27 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:27 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:27 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:27 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:27 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:27 --> Controller Class Initialized
INFO - 2023-12-08 14:21:31 --> Config Class Initialized
INFO - 2023-12-08 14:21:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:31 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:31 --> URI Class Initialized
INFO - 2023-12-08 14:21:31 --> Router Class Initialized
INFO - 2023-12-08 14:21:31 --> Output Class Initialized
INFO - 2023-12-08 14:21:31 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:31 --> Input Class Initialized
INFO - 2023-12-08 14:21:31 --> Language Class Initialized
INFO - 2023-12-08 14:21:31 --> Language Class Initialized
INFO - 2023-12-08 14:21:31 --> Config Class Initialized
INFO - 2023-12-08 14:21:31 --> Loader Class Initialized
INFO - 2023-12-08 14:21:31 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:31 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:31 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:31 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:31 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:31 --> Controller Class Initialized
INFO - 2023-12-08 14:21:31 --> Final output sent to browser
DEBUG - 2023-12-08 14:21:31 --> Total execution time: 0.0707
INFO - 2023-12-08 14:21:35 --> Config Class Initialized
INFO - 2023-12-08 14:21:35 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:35 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:35 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:35 --> URI Class Initialized
INFO - 2023-12-08 14:21:35 --> Router Class Initialized
INFO - 2023-12-08 14:21:35 --> Output Class Initialized
INFO - 2023-12-08 14:21:35 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:35 --> Input Class Initialized
INFO - 2023-12-08 14:21:35 --> Language Class Initialized
INFO - 2023-12-08 14:21:35 --> Language Class Initialized
INFO - 2023-12-08 14:21:35 --> Config Class Initialized
INFO - 2023-12-08 14:21:35 --> Loader Class Initialized
INFO - 2023-12-08 14:21:35 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:35 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:35 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:35 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:35 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:35 --> Controller Class Initialized
INFO - 2023-12-08 14:21:35 --> Final output sent to browser
DEBUG - 2023-12-08 14:21:35 --> Total execution time: 0.1640
INFO - 2023-12-08 14:21:40 --> Config Class Initialized
INFO - 2023-12-08 14:21:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:21:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:21:40 --> Utf8 Class Initialized
INFO - 2023-12-08 14:21:40 --> URI Class Initialized
INFO - 2023-12-08 14:21:40 --> Router Class Initialized
INFO - 2023-12-08 14:21:40 --> Output Class Initialized
INFO - 2023-12-08 14:21:40 --> Security Class Initialized
DEBUG - 2023-12-08 14:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:21:40 --> Input Class Initialized
INFO - 2023-12-08 14:21:40 --> Language Class Initialized
INFO - 2023-12-08 14:21:40 --> Language Class Initialized
INFO - 2023-12-08 14:21:40 --> Config Class Initialized
INFO - 2023-12-08 14:21:40 --> Loader Class Initialized
INFO - 2023-12-08 14:21:40 --> Helper loaded: url_helper
INFO - 2023-12-08 14:21:40 --> Helper loaded: file_helper
INFO - 2023-12-08 14:21:40 --> Helper loaded: form_helper
INFO - 2023-12-08 14:21:40 --> Helper loaded: my_helper
INFO - 2023-12-08 14:21:40 --> Database Driver Class Initialized
INFO - 2023-12-08 14:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:21:40 --> Controller Class Initialized
INFO - 2023-12-08 14:22:36 --> Config Class Initialized
INFO - 2023-12-08 14:22:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:22:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:22:36 --> Utf8 Class Initialized
INFO - 2023-12-08 14:22:36 --> URI Class Initialized
INFO - 2023-12-08 14:22:36 --> Router Class Initialized
INFO - 2023-12-08 14:22:36 --> Output Class Initialized
INFO - 2023-12-08 14:22:36 --> Security Class Initialized
DEBUG - 2023-12-08 14:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:22:36 --> Input Class Initialized
INFO - 2023-12-08 14:22:36 --> Language Class Initialized
INFO - 2023-12-08 14:22:36 --> Language Class Initialized
INFO - 2023-12-08 14:22:36 --> Config Class Initialized
INFO - 2023-12-08 14:22:36 --> Loader Class Initialized
INFO - 2023-12-08 14:22:36 --> Helper loaded: url_helper
INFO - 2023-12-08 14:22:36 --> Helper loaded: file_helper
INFO - 2023-12-08 14:22:36 --> Helper loaded: form_helper
INFO - 2023-12-08 14:22:36 --> Helper loaded: my_helper
INFO - 2023-12-08 14:22:36 --> Database Driver Class Initialized
INFO - 2023-12-08 14:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:22:36 --> Controller Class Initialized
DEBUG - 2023-12-08 14:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:22:36 --> Final output sent to browser
DEBUG - 2023-12-08 14:22:36 --> Total execution time: 0.0517
INFO - 2023-12-08 14:22:38 --> Config Class Initialized
INFO - 2023-12-08 14:22:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:22:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:22:38 --> Utf8 Class Initialized
INFO - 2023-12-08 14:22:38 --> URI Class Initialized
INFO - 2023-12-08 14:22:38 --> Router Class Initialized
INFO - 2023-12-08 14:22:38 --> Output Class Initialized
INFO - 2023-12-08 14:22:38 --> Security Class Initialized
DEBUG - 2023-12-08 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:22:38 --> Input Class Initialized
INFO - 2023-12-08 14:22:38 --> Language Class Initialized
INFO - 2023-12-08 14:22:38 --> Language Class Initialized
INFO - 2023-12-08 14:22:38 --> Config Class Initialized
INFO - 2023-12-08 14:22:38 --> Loader Class Initialized
INFO - 2023-12-08 14:22:38 --> Helper loaded: url_helper
INFO - 2023-12-08 14:22:38 --> Helper loaded: file_helper
INFO - 2023-12-08 14:22:38 --> Helper loaded: form_helper
INFO - 2023-12-08 14:22:38 --> Helper loaded: my_helper
INFO - 2023-12-08 14:22:38 --> Database Driver Class Initialized
INFO - 2023-12-08 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:22:38 --> Controller Class Initialized
DEBUG - 2023-12-08 14:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:22:38 --> Final output sent to browser
DEBUG - 2023-12-08 14:22:38 --> Total execution time: 0.0487
INFO - 2023-12-08 14:22:38 --> Config Class Initialized
INFO - 2023-12-08 14:22:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:22:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:22:38 --> Utf8 Class Initialized
INFO - 2023-12-08 14:22:38 --> URI Class Initialized
INFO - 2023-12-08 14:22:38 --> Router Class Initialized
INFO - 2023-12-08 14:22:38 --> Output Class Initialized
INFO - 2023-12-08 14:22:38 --> Security Class Initialized
DEBUG - 2023-12-08 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:22:38 --> Input Class Initialized
INFO - 2023-12-08 14:22:38 --> Language Class Initialized
INFO - 2023-12-08 14:22:38 --> Language Class Initialized
INFO - 2023-12-08 14:22:38 --> Config Class Initialized
INFO - 2023-12-08 14:22:38 --> Loader Class Initialized
INFO - 2023-12-08 14:22:38 --> Helper loaded: url_helper
INFO - 2023-12-08 14:22:38 --> Helper loaded: file_helper
INFO - 2023-12-08 14:22:38 --> Helper loaded: form_helper
INFO - 2023-12-08 14:22:38 --> Helper loaded: my_helper
INFO - 2023-12-08 14:22:38 --> Database Driver Class Initialized
INFO - 2023-12-08 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:22:38 --> Controller Class Initialized
INFO - 2023-12-08 14:22:39 --> Config Class Initialized
INFO - 2023-12-08 14:22:39 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:22:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:22:40 --> Utf8 Class Initialized
INFO - 2023-12-08 14:22:40 --> URI Class Initialized
INFO - 2023-12-08 14:22:40 --> Router Class Initialized
INFO - 2023-12-08 14:22:40 --> Output Class Initialized
INFO - 2023-12-08 14:22:40 --> Security Class Initialized
DEBUG - 2023-12-08 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:22:40 --> Input Class Initialized
INFO - 2023-12-08 14:22:40 --> Language Class Initialized
INFO - 2023-12-08 14:22:40 --> Language Class Initialized
INFO - 2023-12-08 14:22:40 --> Config Class Initialized
INFO - 2023-12-08 14:22:40 --> Loader Class Initialized
INFO - 2023-12-08 14:22:40 --> Helper loaded: url_helper
INFO - 2023-12-08 14:22:40 --> Helper loaded: file_helper
INFO - 2023-12-08 14:22:40 --> Helper loaded: form_helper
INFO - 2023-12-08 14:22:40 --> Helper loaded: my_helper
INFO - 2023-12-08 14:22:40 --> Database Driver Class Initialized
INFO - 2023-12-08 14:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:22:40 --> Controller Class Initialized
INFO - 2023-12-08 14:33:07 --> Config Class Initialized
INFO - 2023-12-08 14:33:07 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:33:07 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:33:07 --> Utf8 Class Initialized
INFO - 2023-12-08 14:33:07 --> URI Class Initialized
INFO - 2023-12-08 14:33:08 --> Router Class Initialized
INFO - 2023-12-08 14:33:08 --> Output Class Initialized
INFO - 2023-12-08 14:33:08 --> Security Class Initialized
DEBUG - 2023-12-08 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:33:08 --> Input Class Initialized
INFO - 2023-12-08 14:33:08 --> Language Class Initialized
INFO - 2023-12-08 14:33:08 --> Language Class Initialized
INFO - 2023-12-08 14:33:08 --> Config Class Initialized
INFO - 2023-12-08 14:33:08 --> Loader Class Initialized
INFO - 2023-12-08 14:33:08 --> Helper loaded: url_helper
INFO - 2023-12-08 14:33:08 --> Helper loaded: file_helper
INFO - 2023-12-08 14:33:08 --> Helper loaded: form_helper
INFO - 2023-12-08 14:33:08 --> Helper loaded: my_helper
INFO - 2023-12-08 14:33:08 --> Database Driver Class Initialized
INFO - 2023-12-08 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:33:08 --> Controller Class Initialized
DEBUG - 2023-12-08 14:33:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:33:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:33:08 --> Final output sent to browser
DEBUG - 2023-12-08 14:33:08 --> Total execution time: 0.1379
INFO - 2023-12-08 14:33:09 --> Config Class Initialized
INFO - 2023-12-08 14:33:09 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:33:09 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:33:09 --> Utf8 Class Initialized
INFO - 2023-12-08 14:33:09 --> URI Class Initialized
INFO - 2023-12-08 14:33:09 --> Router Class Initialized
INFO - 2023-12-08 14:33:09 --> Output Class Initialized
INFO - 2023-12-08 14:33:09 --> Security Class Initialized
DEBUG - 2023-12-08 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:33:09 --> Input Class Initialized
INFO - 2023-12-08 14:33:09 --> Language Class Initialized
INFO - 2023-12-08 14:33:09 --> Language Class Initialized
INFO - 2023-12-08 14:33:09 --> Config Class Initialized
INFO - 2023-12-08 14:33:09 --> Loader Class Initialized
INFO - 2023-12-08 14:33:09 --> Helper loaded: url_helper
INFO - 2023-12-08 14:33:09 --> Helper loaded: file_helper
INFO - 2023-12-08 14:33:09 --> Helper loaded: form_helper
INFO - 2023-12-08 14:33:09 --> Helper loaded: my_helper
INFO - 2023-12-08 14:33:09 --> Database Driver Class Initialized
INFO - 2023-12-08 14:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:33:09 --> Controller Class Initialized
DEBUG - 2023-12-08 14:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:33:09 --> Final output sent to browser
DEBUG - 2023-12-08 14:33:09 --> Total execution time: 0.1232
INFO - 2023-12-08 14:33:10 --> Config Class Initialized
INFO - 2023-12-08 14:33:10 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:33:10 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:33:10 --> Utf8 Class Initialized
INFO - 2023-12-08 14:33:10 --> URI Class Initialized
INFO - 2023-12-08 14:33:10 --> Router Class Initialized
INFO - 2023-12-08 14:33:10 --> Output Class Initialized
INFO - 2023-12-08 14:33:10 --> Security Class Initialized
DEBUG - 2023-12-08 14:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:33:10 --> Input Class Initialized
INFO - 2023-12-08 14:33:10 --> Language Class Initialized
INFO - 2023-12-08 14:33:10 --> Language Class Initialized
INFO - 2023-12-08 14:33:10 --> Config Class Initialized
INFO - 2023-12-08 14:33:10 --> Loader Class Initialized
INFO - 2023-12-08 14:33:10 --> Helper loaded: url_helper
INFO - 2023-12-08 14:33:10 --> Helper loaded: file_helper
INFO - 2023-12-08 14:33:10 --> Helper loaded: form_helper
INFO - 2023-12-08 14:33:10 --> Helper loaded: my_helper
INFO - 2023-12-08 14:33:10 --> Database Driver Class Initialized
INFO - 2023-12-08 14:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:33:10 --> Controller Class Initialized
INFO - 2023-12-08 14:33:22 --> Config Class Initialized
INFO - 2023-12-08 14:33:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:33:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:33:22 --> Utf8 Class Initialized
INFO - 2023-12-08 14:33:22 --> URI Class Initialized
INFO - 2023-12-08 14:33:22 --> Router Class Initialized
INFO - 2023-12-08 14:33:22 --> Output Class Initialized
INFO - 2023-12-08 14:33:22 --> Security Class Initialized
DEBUG - 2023-12-08 14:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:33:22 --> Input Class Initialized
INFO - 2023-12-08 14:33:22 --> Language Class Initialized
INFO - 2023-12-08 14:33:22 --> Language Class Initialized
INFO - 2023-12-08 14:33:22 --> Config Class Initialized
INFO - 2023-12-08 14:33:22 --> Loader Class Initialized
INFO - 2023-12-08 14:33:22 --> Helper loaded: url_helper
INFO - 2023-12-08 14:33:22 --> Helper loaded: file_helper
INFO - 2023-12-08 14:33:22 --> Helper loaded: form_helper
INFO - 2023-12-08 14:33:22 --> Helper loaded: my_helper
INFO - 2023-12-08 14:33:22 --> Database Driver Class Initialized
INFO - 2023-12-08 14:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:33:22 --> Controller Class Initialized
INFO - 2023-12-08 14:34:05 --> Config Class Initialized
INFO - 2023-12-08 14:34:05 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:05 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:05 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:05 --> URI Class Initialized
DEBUG - 2023-12-08 14:34:05 --> No URI present. Default controller set.
INFO - 2023-12-08 14:34:05 --> Router Class Initialized
INFO - 2023-12-08 14:34:05 --> Output Class Initialized
INFO - 2023-12-08 14:34:05 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:05 --> Input Class Initialized
INFO - 2023-12-08 14:34:05 --> Language Class Initialized
INFO - 2023-12-08 14:34:05 --> Language Class Initialized
INFO - 2023-12-08 14:34:05 --> Config Class Initialized
INFO - 2023-12-08 14:34:05 --> Loader Class Initialized
INFO - 2023-12-08 14:34:05 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:05 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:05 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:05 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:05 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:05 --> Controller Class Initialized
INFO - 2023-12-08 14:34:05 --> Config Class Initialized
INFO - 2023-12-08 14:34:05 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:05 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:05 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:05 --> URI Class Initialized
INFO - 2023-12-08 14:34:05 --> Router Class Initialized
INFO - 2023-12-08 14:34:05 --> Output Class Initialized
INFO - 2023-12-08 14:34:05 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:05 --> Input Class Initialized
INFO - 2023-12-08 14:34:05 --> Language Class Initialized
INFO - 2023-12-08 14:34:05 --> Language Class Initialized
INFO - 2023-12-08 14:34:05 --> Config Class Initialized
INFO - 2023-12-08 14:34:05 --> Loader Class Initialized
INFO - 2023-12-08 14:34:05 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:05 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:05 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:05 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:05 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:05 --> Controller Class Initialized
DEBUG - 2023-12-08 14:34:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 14:34:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:34:05 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:05 --> Total execution time: 0.0504
INFO - 2023-12-08 14:34:08 --> Config Class Initialized
INFO - 2023-12-08 14:34:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:08 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:08 --> URI Class Initialized
INFO - 2023-12-08 14:34:08 --> Router Class Initialized
INFO - 2023-12-08 14:34:08 --> Output Class Initialized
INFO - 2023-12-08 14:34:08 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:08 --> Input Class Initialized
INFO - 2023-12-08 14:34:08 --> Language Class Initialized
INFO - 2023-12-08 14:34:08 --> Language Class Initialized
INFO - 2023-12-08 14:34:08 --> Config Class Initialized
INFO - 2023-12-08 14:34:08 --> Loader Class Initialized
INFO - 2023-12-08 14:34:08 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:08 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:08 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:08 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:08 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:08 --> Controller Class Initialized
INFO - 2023-12-08 14:34:08 --> Helper loaded: cookie_helper
INFO - 2023-12-08 14:34:08 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:08 --> Total execution time: 0.3808
INFO - 2023-12-08 14:34:11 --> Config Class Initialized
INFO - 2023-12-08 14:34:11 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:11 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:11 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:11 --> URI Class Initialized
INFO - 2023-12-08 14:34:11 --> Router Class Initialized
INFO - 2023-12-08 14:34:11 --> Output Class Initialized
INFO - 2023-12-08 14:34:11 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:11 --> Input Class Initialized
INFO - 2023-12-08 14:34:11 --> Language Class Initialized
INFO - 2023-12-08 14:34:11 --> Language Class Initialized
INFO - 2023-12-08 14:34:11 --> Config Class Initialized
INFO - 2023-12-08 14:34:11 --> Loader Class Initialized
INFO - 2023-12-08 14:34:11 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:11 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:11 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:11 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:11 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:11 --> Controller Class Initialized
DEBUG - 2023-12-08 14:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 14:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:34:11 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:11 --> Total execution time: 0.1082
INFO - 2023-12-08 14:34:14 --> Config Class Initialized
INFO - 2023-12-08 14:34:14 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:14 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:14 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:14 --> URI Class Initialized
INFO - 2023-12-08 14:34:14 --> Router Class Initialized
INFO - 2023-12-08 14:34:14 --> Output Class Initialized
INFO - 2023-12-08 14:34:14 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:14 --> Input Class Initialized
INFO - 2023-12-08 14:34:14 --> Language Class Initialized
INFO - 2023-12-08 14:34:14 --> Language Class Initialized
INFO - 2023-12-08 14:34:14 --> Config Class Initialized
INFO - 2023-12-08 14:34:14 --> Loader Class Initialized
INFO - 2023-12-08 14:34:14 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:14 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:14 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:14 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:14 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:14 --> Controller Class Initialized
DEBUG - 2023-12-08 14:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:34:14 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:14 --> Total execution time: 0.1319
INFO - 2023-12-08 14:34:18 --> Config Class Initialized
INFO - 2023-12-08 14:34:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:18 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:18 --> URI Class Initialized
INFO - 2023-12-08 14:34:18 --> Router Class Initialized
INFO - 2023-12-08 14:34:18 --> Output Class Initialized
INFO - 2023-12-08 14:34:18 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:18 --> Input Class Initialized
INFO - 2023-12-08 14:34:18 --> Language Class Initialized
INFO - 2023-12-08 14:34:18 --> Language Class Initialized
INFO - 2023-12-08 14:34:18 --> Config Class Initialized
INFO - 2023-12-08 14:34:18 --> Loader Class Initialized
INFO - 2023-12-08 14:34:18 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:18 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:18 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:18 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:18 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:18 --> Controller Class Initialized
DEBUG - 2023-12-08 14:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:34:19 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:19 --> Total execution time: 0.4062
INFO - 2023-12-08 14:34:19 --> Config Class Initialized
INFO - 2023-12-08 14:34:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:19 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:19 --> URI Class Initialized
INFO - 2023-12-08 14:34:19 --> Router Class Initialized
INFO - 2023-12-08 14:34:19 --> Output Class Initialized
INFO - 2023-12-08 14:34:19 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:19 --> Input Class Initialized
INFO - 2023-12-08 14:34:19 --> Language Class Initialized
INFO - 2023-12-08 14:34:19 --> Language Class Initialized
INFO - 2023-12-08 14:34:19 --> Config Class Initialized
INFO - 2023-12-08 14:34:19 --> Loader Class Initialized
INFO - 2023-12-08 14:34:19 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:19 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:19 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:19 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:19 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:19 --> Controller Class Initialized
INFO - 2023-12-08 14:34:26 --> Config Class Initialized
INFO - 2023-12-08 14:34:26 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:26 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:26 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:26 --> URI Class Initialized
INFO - 2023-12-08 14:34:26 --> Router Class Initialized
INFO - 2023-12-08 14:34:26 --> Output Class Initialized
INFO - 2023-12-08 14:34:26 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:26 --> Input Class Initialized
INFO - 2023-12-08 14:34:26 --> Language Class Initialized
INFO - 2023-12-08 14:34:26 --> Language Class Initialized
INFO - 2023-12-08 14:34:26 --> Config Class Initialized
INFO - 2023-12-08 14:34:26 --> Loader Class Initialized
INFO - 2023-12-08 14:34:26 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:26 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:26 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:26 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:26 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:26 --> Controller Class Initialized
INFO - 2023-12-08 14:34:26 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:26 --> Total execution time: 0.0738
INFO - 2023-12-08 14:34:30 --> Config Class Initialized
INFO - 2023-12-08 14:34:30 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:30 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:30 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:30 --> URI Class Initialized
INFO - 2023-12-08 14:34:30 --> Router Class Initialized
INFO - 2023-12-08 14:34:30 --> Output Class Initialized
INFO - 2023-12-08 14:34:30 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:30 --> Input Class Initialized
INFO - 2023-12-08 14:34:30 --> Language Class Initialized
INFO - 2023-12-08 14:34:30 --> Language Class Initialized
INFO - 2023-12-08 14:34:30 --> Config Class Initialized
INFO - 2023-12-08 14:34:30 --> Loader Class Initialized
INFO - 2023-12-08 14:34:30 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:30 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:30 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:30 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:30 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:30 --> Controller Class Initialized
DEBUG - 2023-12-08 14:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 14:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:34:30 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:30 --> Total execution time: 0.2242
INFO - 2023-12-08 14:34:41 --> Config Class Initialized
INFO - 2023-12-08 14:34:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:41 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:41 --> URI Class Initialized
INFO - 2023-12-08 14:34:41 --> Router Class Initialized
INFO - 2023-12-08 14:34:41 --> Output Class Initialized
INFO - 2023-12-08 14:34:41 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:41 --> Input Class Initialized
INFO - 2023-12-08 14:34:41 --> Language Class Initialized
INFO - 2023-12-08 14:34:41 --> Language Class Initialized
INFO - 2023-12-08 14:34:41 --> Config Class Initialized
INFO - 2023-12-08 14:34:41 --> Loader Class Initialized
INFO - 2023-12-08 14:34:41 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:41 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:41 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:41 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:41 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:41 --> Controller Class Initialized
INFO - 2023-12-08 14:34:42 --> Config Class Initialized
INFO - 2023-12-08 14:34:42 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:42 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:42 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:42 --> URI Class Initialized
INFO - 2023-12-08 14:34:42 --> Router Class Initialized
INFO - 2023-12-08 14:34:42 --> Output Class Initialized
INFO - 2023-12-08 14:34:42 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:42 --> Input Class Initialized
INFO - 2023-12-08 14:34:42 --> Language Class Initialized
INFO - 2023-12-08 14:34:42 --> Language Class Initialized
INFO - 2023-12-08 14:34:42 --> Config Class Initialized
INFO - 2023-12-08 14:34:42 --> Loader Class Initialized
INFO - 2023-12-08 14:34:42 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:42 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:42 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:42 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:42 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:42 --> Controller Class Initialized
DEBUG - 2023-12-08 14:34:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:34:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:34:42 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:42 --> Total execution time: 0.0424
INFO - 2023-12-08 14:34:42 --> Config Class Initialized
INFO - 2023-12-08 14:34:42 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:42 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:42 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:42 --> URI Class Initialized
INFO - 2023-12-08 14:34:42 --> Router Class Initialized
INFO - 2023-12-08 14:34:42 --> Output Class Initialized
INFO - 2023-12-08 14:34:42 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:42 --> Input Class Initialized
INFO - 2023-12-08 14:34:42 --> Language Class Initialized
INFO - 2023-12-08 14:34:42 --> Language Class Initialized
INFO - 2023-12-08 14:34:42 --> Config Class Initialized
INFO - 2023-12-08 14:34:42 --> Loader Class Initialized
INFO - 2023-12-08 14:34:42 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:42 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:42 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:42 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:42 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:42 --> Controller Class Initialized
INFO - 2023-12-08 14:34:48 --> Config Class Initialized
INFO - 2023-12-08 14:34:48 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:48 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:48 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:48 --> URI Class Initialized
INFO - 2023-12-08 14:34:49 --> Router Class Initialized
INFO - 2023-12-08 14:34:49 --> Output Class Initialized
INFO - 2023-12-08 14:34:49 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:49 --> Input Class Initialized
INFO - 2023-12-08 14:34:49 --> Language Class Initialized
INFO - 2023-12-08 14:34:49 --> Language Class Initialized
INFO - 2023-12-08 14:34:49 --> Config Class Initialized
INFO - 2023-12-08 14:34:49 --> Loader Class Initialized
INFO - 2023-12-08 14:34:49 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:49 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:49 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:49 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:49 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:49 --> Controller Class Initialized
INFO - 2023-12-08 14:34:49 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:49 --> Total execution time: 0.2262
INFO - 2023-12-08 14:34:51 --> Config Class Initialized
INFO - 2023-12-08 14:34:51 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:34:51 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:34:51 --> Utf8 Class Initialized
INFO - 2023-12-08 14:34:51 --> URI Class Initialized
INFO - 2023-12-08 14:34:51 --> Router Class Initialized
INFO - 2023-12-08 14:34:51 --> Output Class Initialized
INFO - 2023-12-08 14:34:51 --> Security Class Initialized
DEBUG - 2023-12-08 14:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:34:51 --> Input Class Initialized
INFO - 2023-12-08 14:34:51 --> Language Class Initialized
INFO - 2023-12-08 14:34:51 --> Language Class Initialized
INFO - 2023-12-08 14:34:51 --> Config Class Initialized
INFO - 2023-12-08 14:34:51 --> Loader Class Initialized
INFO - 2023-12-08 14:34:51 --> Helper loaded: url_helper
INFO - 2023-12-08 14:34:51 --> Helper loaded: file_helper
INFO - 2023-12-08 14:34:51 --> Helper loaded: form_helper
INFO - 2023-12-08 14:34:51 --> Helper loaded: my_helper
INFO - 2023-12-08 14:34:51 --> Database Driver Class Initialized
INFO - 2023-12-08 14:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:34:51 --> Controller Class Initialized
INFO - 2023-12-08 14:34:51 --> Final output sent to browser
DEBUG - 2023-12-08 14:34:51 --> Total execution time: 0.0881
INFO - 2023-12-08 14:35:04 --> Config Class Initialized
INFO - 2023-12-08 14:35:04 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:04 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:04 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:04 --> URI Class Initialized
INFO - 2023-12-08 14:35:04 --> Router Class Initialized
INFO - 2023-12-08 14:35:04 --> Output Class Initialized
INFO - 2023-12-08 14:35:04 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:04 --> Input Class Initialized
INFO - 2023-12-08 14:35:04 --> Language Class Initialized
INFO - 2023-12-08 14:35:04 --> Language Class Initialized
INFO - 2023-12-08 14:35:04 --> Config Class Initialized
INFO - 2023-12-08 14:35:04 --> Loader Class Initialized
INFO - 2023-12-08 14:35:04 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:04 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:04 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:04 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:04 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:04 --> Controller Class Initialized
DEBUG - 2023-12-08 14:35:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:35:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:35:04 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:04 --> Total execution time: 0.0904
INFO - 2023-12-08 14:35:04 --> Config Class Initialized
INFO - 2023-12-08 14:35:04 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:04 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:04 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:04 --> URI Class Initialized
INFO - 2023-12-08 14:35:04 --> Router Class Initialized
INFO - 2023-12-08 14:35:04 --> Output Class Initialized
INFO - 2023-12-08 14:35:04 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:04 --> Input Class Initialized
INFO - 2023-12-08 14:35:04 --> Language Class Initialized
INFO - 2023-12-08 14:35:04 --> Language Class Initialized
INFO - 2023-12-08 14:35:04 --> Config Class Initialized
INFO - 2023-12-08 14:35:04 --> Loader Class Initialized
INFO - 2023-12-08 14:35:04 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:04 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:04 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:04 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:04 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:04 --> Controller Class Initialized
INFO - 2023-12-08 14:35:08 --> Config Class Initialized
INFO - 2023-12-08 14:35:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:08 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:08 --> URI Class Initialized
INFO - 2023-12-08 14:35:08 --> Router Class Initialized
INFO - 2023-12-08 14:35:08 --> Output Class Initialized
INFO - 2023-12-08 14:35:08 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:08 --> Input Class Initialized
INFO - 2023-12-08 14:35:08 --> Language Class Initialized
INFO - 2023-12-08 14:35:08 --> Language Class Initialized
INFO - 2023-12-08 14:35:08 --> Config Class Initialized
INFO - 2023-12-08 14:35:08 --> Loader Class Initialized
INFO - 2023-12-08 14:35:08 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:08 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:08 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:08 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:08 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:08 --> Controller Class Initialized
INFO - 2023-12-08 14:35:08 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:08 --> Total execution time: 0.1170
INFO - 2023-12-08 14:35:11 --> Config Class Initialized
INFO - 2023-12-08 14:35:11 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:11 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:11 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:11 --> URI Class Initialized
INFO - 2023-12-08 14:35:11 --> Router Class Initialized
INFO - 2023-12-08 14:35:11 --> Output Class Initialized
INFO - 2023-12-08 14:35:11 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:11 --> Input Class Initialized
INFO - 2023-12-08 14:35:11 --> Language Class Initialized
INFO - 2023-12-08 14:35:11 --> Language Class Initialized
INFO - 2023-12-08 14:35:11 --> Config Class Initialized
INFO - 2023-12-08 14:35:11 --> Loader Class Initialized
INFO - 2023-12-08 14:35:11 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:11 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:11 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:11 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:11 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:11 --> Controller Class Initialized
INFO - 2023-12-08 14:35:11 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:11 --> Total execution time: 0.2800
INFO - 2023-12-08 14:35:26 --> Config Class Initialized
INFO - 2023-12-08 14:35:26 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:26 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:26 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:26 --> URI Class Initialized
INFO - 2023-12-08 14:35:26 --> Router Class Initialized
INFO - 2023-12-08 14:35:26 --> Output Class Initialized
INFO - 2023-12-08 14:35:26 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:26 --> Input Class Initialized
INFO - 2023-12-08 14:35:26 --> Language Class Initialized
INFO - 2023-12-08 14:35:26 --> Language Class Initialized
INFO - 2023-12-08 14:35:26 --> Config Class Initialized
INFO - 2023-12-08 14:35:26 --> Loader Class Initialized
INFO - 2023-12-08 14:35:26 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:26 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:26 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:26 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:26 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:26 --> Controller Class Initialized
DEBUG - 2023-12-08 14:35:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 14:35:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:35:26 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:26 --> Total execution time: 0.0750
INFO - 2023-12-08 14:35:36 --> Config Class Initialized
INFO - 2023-12-08 14:35:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:36 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:36 --> URI Class Initialized
INFO - 2023-12-08 14:35:36 --> Router Class Initialized
INFO - 2023-12-08 14:35:36 --> Output Class Initialized
INFO - 2023-12-08 14:35:36 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:36 --> Input Class Initialized
INFO - 2023-12-08 14:35:36 --> Language Class Initialized
INFO - 2023-12-08 14:35:36 --> Language Class Initialized
INFO - 2023-12-08 14:35:36 --> Config Class Initialized
INFO - 2023-12-08 14:35:36 --> Loader Class Initialized
INFO - 2023-12-08 14:35:36 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:36 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:36 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:36 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:36 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:36 --> Controller Class Initialized
INFO - 2023-12-08 14:35:36 --> Config Class Initialized
INFO - 2023-12-08 14:35:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:36 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:36 --> URI Class Initialized
INFO - 2023-12-08 14:35:36 --> Router Class Initialized
INFO - 2023-12-08 14:35:36 --> Output Class Initialized
INFO - 2023-12-08 14:35:36 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:36 --> Input Class Initialized
INFO - 2023-12-08 14:35:36 --> Language Class Initialized
INFO - 2023-12-08 14:35:36 --> Language Class Initialized
INFO - 2023-12-08 14:35:36 --> Config Class Initialized
INFO - 2023-12-08 14:35:36 --> Loader Class Initialized
INFO - 2023-12-08 14:35:36 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:36 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:36 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:36 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:36 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:36 --> Controller Class Initialized
DEBUG - 2023-12-08 14:35:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:35:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:35:36 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:36 --> Total execution time: 0.0653
INFO - 2023-12-08 14:35:37 --> Config Class Initialized
INFO - 2023-12-08 14:35:37 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:37 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:37 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:37 --> URI Class Initialized
INFO - 2023-12-08 14:35:37 --> Router Class Initialized
INFO - 2023-12-08 14:35:37 --> Output Class Initialized
INFO - 2023-12-08 14:35:37 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:37 --> Input Class Initialized
INFO - 2023-12-08 14:35:37 --> Language Class Initialized
INFO - 2023-12-08 14:35:37 --> Language Class Initialized
INFO - 2023-12-08 14:35:37 --> Config Class Initialized
INFO - 2023-12-08 14:35:37 --> Loader Class Initialized
INFO - 2023-12-08 14:35:37 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:37 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:37 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:37 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:37 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:37 --> Controller Class Initialized
INFO - 2023-12-08 14:35:41 --> Config Class Initialized
INFO - 2023-12-08 14:35:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:41 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:41 --> URI Class Initialized
INFO - 2023-12-08 14:35:41 --> Router Class Initialized
INFO - 2023-12-08 14:35:41 --> Output Class Initialized
INFO - 2023-12-08 14:35:41 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:41 --> Input Class Initialized
INFO - 2023-12-08 14:35:41 --> Language Class Initialized
INFO - 2023-12-08 14:35:41 --> Language Class Initialized
INFO - 2023-12-08 14:35:41 --> Config Class Initialized
INFO - 2023-12-08 14:35:41 --> Loader Class Initialized
INFO - 2023-12-08 14:35:41 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:41 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:41 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:41 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:41 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:41 --> Controller Class Initialized
INFO - 2023-12-08 14:35:41 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:41 --> Total execution time: 0.1371
INFO - 2023-12-08 14:35:48 --> Config Class Initialized
INFO - 2023-12-08 14:35:48 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:48 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:48 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:48 --> URI Class Initialized
INFO - 2023-12-08 14:35:48 --> Router Class Initialized
INFO - 2023-12-08 14:35:48 --> Output Class Initialized
INFO - 2023-12-08 14:35:48 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:48 --> Input Class Initialized
INFO - 2023-12-08 14:35:48 --> Language Class Initialized
INFO - 2023-12-08 14:35:48 --> Language Class Initialized
INFO - 2023-12-08 14:35:48 --> Config Class Initialized
INFO - 2023-12-08 14:35:48 --> Loader Class Initialized
INFO - 2023-12-08 14:35:48 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:48 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:48 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:48 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:48 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:48 --> Controller Class Initialized
DEBUG - 2023-12-08 14:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:35:48 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:48 --> Total execution time: 0.0808
INFO - 2023-12-08 14:35:54 --> Config Class Initialized
INFO - 2023-12-08 14:35:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:35:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:35:54 --> Utf8 Class Initialized
INFO - 2023-12-08 14:35:54 --> URI Class Initialized
INFO - 2023-12-08 14:35:54 --> Router Class Initialized
INFO - 2023-12-08 14:35:54 --> Output Class Initialized
INFO - 2023-12-08 14:35:54 --> Security Class Initialized
DEBUG - 2023-12-08 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:35:54 --> Input Class Initialized
INFO - 2023-12-08 14:35:54 --> Language Class Initialized
INFO - 2023-12-08 14:35:54 --> Language Class Initialized
INFO - 2023-12-08 14:35:54 --> Config Class Initialized
INFO - 2023-12-08 14:35:54 --> Loader Class Initialized
INFO - 2023-12-08 14:35:54 --> Helper loaded: url_helper
INFO - 2023-12-08 14:35:54 --> Helper loaded: file_helper
INFO - 2023-12-08 14:35:54 --> Helper loaded: form_helper
INFO - 2023-12-08 14:35:54 --> Helper loaded: my_helper
INFO - 2023-12-08 14:35:54 --> Database Driver Class Initialized
INFO - 2023-12-08 14:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:35:54 --> Controller Class Initialized
DEBUG - 2023-12-08 14:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 14:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:35:54 --> Final output sent to browser
DEBUG - 2023-12-08 14:35:54 --> Total execution time: 0.1110
INFO - 2023-12-08 14:36:00 --> Config Class Initialized
INFO - 2023-12-08 14:36:00 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:36:00 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:36:00 --> Utf8 Class Initialized
INFO - 2023-12-08 14:36:00 --> URI Class Initialized
INFO - 2023-12-08 14:36:00 --> Router Class Initialized
INFO - 2023-12-08 14:36:00 --> Output Class Initialized
INFO - 2023-12-08 14:36:00 --> Security Class Initialized
DEBUG - 2023-12-08 14:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:36:00 --> Input Class Initialized
INFO - 2023-12-08 14:36:00 --> Language Class Initialized
INFO - 2023-12-08 14:36:00 --> Language Class Initialized
INFO - 2023-12-08 14:36:00 --> Config Class Initialized
INFO - 2023-12-08 14:36:00 --> Loader Class Initialized
INFO - 2023-12-08 14:36:00 --> Helper loaded: url_helper
INFO - 2023-12-08 14:36:00 --> Helper loaded: file_helper
INFO - 2023-12-08 14:36:00 --> Helper loaded: form_helper
INFO - 2023-12-08 14:36:00 --> Helper loaded: my_helper
INFO - 2023-12-08 14:36:00 --> Database Driver Class Initialized
INFO - 2023-12-08 14:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:36:00 --> Controller Class Initialized
INFO - 2023-12-08 14:36:00 --> Final output sent to browser
DEBUG - 2023-12-08 14:36:00 --> Total execution time: 0.0554
INFO - 2023-12-08 14:37:41 --> Config Class Initialized
INFO - 2023-12-08 14:37:41 --> Hooks Class Initialized
INFO - 2023-12-08 14:37:41 --> Config Class Initialized
INFO - 2023-12-08 14:37:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:37:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:37:41 --> Utf8 Class Initialized
DEBUG - 2023-12-08 14:37:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:37:41 --> Utf8 Class Initialized
INFO - 2023-12-08 14:37:41 --> URI Class Initialized
INFO - 2023-12-08 14:37:41 --> URI Class Initialized
INFO - 2023-12-08 14:37:41 --> Router Class Initialized
INFO - 2023-12-08 14:37:41 --> Router Class Initialized
INFO - 2023-12-08 14:37:41 --> Output Class Initialized
INFO - 2023-12-08 14:37:41 --> Output Class Initialized
INFO - 2023-12-08 14:37:41 --> Security Class Initialized
INFO - 2023-12-08 14:37:41 --> Security Class Initialized
DEBUG - 2023-12-08 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:37:41 --> Input Class Initialized
DEBUG - 2023-12-08 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:37:41 --> Input Class Initialized
INFO - 2023-12-08 14:37:41 --> Language Class Initialized
INFO - 2023-12-08 14:37:41 --> Language Class Initialized
INFO - 2023-12-08 14:37:41 --> Language Class Initialized
INFO - 2023-12-08 14:37:41 --> Config Class Initialized
INFO - 2023-12-08 14:37:41 --> Loader Class Initialized
INFO - 2023-12-08 14:37:41 --> Language Class Initialized
INFO - 2023-12-08 14:37:41 --> Config Class Initialized
INFO - 2023-12-08 14:37:41 --> Loader Class Initialized
INFO - 2023-12-08 14:37:41 --> Helper loaded: url_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: url_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: file_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: file_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: form_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: form_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: my_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: my_helper
INFO - 2023-12-08 14:37:41 --> Database Driver Class Initialized
INFO - 2023-12-08 14:37:41 --> Database Driver Class Initialized
INFO - 2023-12-08 14:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:37:41 --> Controller Class Initialized
DEBUG - 2023-12-08 14:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:37:41 --> Final output sent to browser
DEBUG - 2023-12-08 14:37:41 --> Total execution time: 0.1986
INFO - 2023-12-08 14:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:37:41 --> Controller Class Initialized
DEBUG - 2023-12-08 14:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:37:41 --> Final output sent to browser
DEBUG - 2023-12-08 14:37:41 --> Total execution time: 0.2233
INFO - 2023-12-08 14:37:41 --> Config Class Initialized
INFO - 2023-12-08 14:37:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:37:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:37:41 --> Utf8 Class Initialized
INFO - 2023-12-08 14:37:41 --> URI Class Initialized
INFO - 2023-12-08 14:37:41 --> Router Class Initialized
INFO - 2023-12-08 14:37:41 --> Output Class Initialized
INFO - 2023-12-08 14:37:41 --> Security Class Initialized
DEBUG - 2023-12-08 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:37:41 --> Input Class Initialized
INFO - 2023-12-08 14:37:41 --> Language Class Initialized
INFO - 2023-12-08 14:37:41 --> Language Class Initialized
INFO - 2023-12-08 14:37:41 --> Config Class Initialized
INFO - 2023-12-08 14:37:41 --> Loader Class Initialized
INFO - 2023-12-08 14:37:41 --> Helper loaded: url_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: file_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: form_helper
INFO - 2023-12-08 14:37:41 --> Helper loaded: my_helper
INFO - 2023-12-08 14:37:41 --> Database Driver Class Initialized
INFO - 2023-12-08 14:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:37:41 --> Controller Class Initialized
DEBUG - 2023-12-08 14:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 14:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:37:41 --> Final output sent to browser
DEBUG - 2023-12-08 14:37:41 --> Total execution time: 0.1103
INFO - 2023-12-08 14:38:20 --> Config Class Initialized
INFO - 2023-12-08 14:38:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:38:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:38:20 --> Utf8 Class Initialized
INFO - 2023-12-08 14:38:20 --> URI Class Initialized
INFO - 2023-12-08 14:38:20 --> Router Class Initialized
INFO - 2023-12-08 14:38:20 --> Output Class Initialized
INFO - 2023-12-08 14:38:20 --> Security Class Initialized
DEBUG - 2023-12-08 14:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:38:20 --> Input Class Initialized
INFO - 2023-12-08 14:38:20 --> Language Class Initialized
INFO - 2023-12-08 14:38:20 --> Language Class Initialized
INFO - 2023-12-08 14:38:20 --> Config Class Initialized
INFO - 2023-12-08 14:38:20 --> Loader Class Initialized
INFO - 2023-12-08 14:38:20 --> Helper loaded: url_helper
INFO - 2023-12-08 14:38:20 --> Helper loaded: file_helper
INFO - 2023-12-08 14:38:20 --> Helper loaded: form_helper
INFO - 2023-12-08 14:38:20 --> Helper loaded: my_helper
INFO - 2023-12-08 14:38:20 --> Database Driver Class Initialized
INFO - 2023-12-08 14:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:38:21 --> Controller Class Initialized
DEBUG - 2023-12-08 14:38:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:38:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:38:21 --> Final output sent to browser
DEBUG - 2023-12-08 14:38:21 --> Total execution time: 0.5205
INFO - 2023-12-08 14:54:19 --> Config Class Initialized
INFO - 2023-12-08 14:54:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:19 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:19 --> URI Class Initialized
INFO - 2023-12-08 14:54:19 --> Router Class Initialized
INFO - 2023-12-08 14:54:19 --> Output Class Initialized
INFO - 2023-12-08 14:54:19 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:19 --> Input Class Initialized
INFO - 2023-12-08 14:54:19 --> Language Class Initialized
INFO - 2023-12-08 14:54:19 --> Language Class Initialized
INFO - 2023-12-08 14:54:19 --> Config Class Initialized
INFO - 2023-12-08 14:54:19 --> Loader Class Initialized
INFO - 2023-12-08 14:54:19 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:19 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:19 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:19 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:19 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:19 --> Controller Class Initialized
DEBUG - 2023-12-08 14:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 14:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:54:19 --> Final output sent to browser
DEBUG - 2023-12-08 14:54:19 --> Total execution time: 0.1330
INFO - 2023-12-08 14:54:27 --> Config Class Initialized
INFO - 2023-12-08 14:54:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:27 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:27 --> URI Class Initialized
DEBUG - 2023-12-08 14:54:27 --> No URI present. Default controller set.
INFO - 2023-12-08 14:54:27 --> Router Class Initialized
INFO - 2023-12-08 14:54:27 --> Output Class Initialized
INFO - 2023-12-08 14:54:27 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:27 --> Input Class Initialized
INFO - 2023-12-08 14:54:27 --> Language Class Initialized
INFO - 2023-12-08 14:54:27 --> Language Class Initialized
INFO - 2023-12-08 14:54:27 --> Config Class Initialized
INFO - 2023-12-08 14:54:27 --> Loader Class Initialized
INFO - 2023-12-08 14:54:27 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:27 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:27 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:27 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:27 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:27 --> Controller Class Initialized
DEBUG - 2023-12-08 14:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 14:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:54:27 --> Final output sent to browser
DEBUG - 2023-12-08 14:54:27 --> Total execution time: 0.1359
INFO - 2023-12-08 14:54:29 --> Config Class Initialized
INFO - 2023-12-08 14:54:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:29 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:29 --> URI Class Initialized
INFO - 2023-12-08 14:54:29 --> Router Class Initialized
INFO - 2023-12-08 14:54:29 --> Output Class Initialized
INFO - 2023-12-08 14:54:29 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:29 --> Input Class Initialized
INFO - 2023-12-08 14:54:29 --> Language Class Initialized
INFO - 2023-12-08 14:54:29 --> Language Class Initialized
INFO - 2023-12-08 14:54:29 --> Config Class Initialized
INFO - 2023-12-08 14:54:29 --> Loader Class Initialized
INFO - 2023-12-08 14:54:29 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:29 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:29 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:29 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:29 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:29 --> Controller Class Initialized
DEBUG - 2023-12-08 14:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 14:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:54:29 --> Final output sent to browser
DEBUG - 2023-12-08 14:54:29 --> Total execution time: 0.0557
INFO - 2023-12-08 14:54:31 --> Config Class Initialized
INFO - 2023-12-08 14:54:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:31 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:31 --> URI Class Initialized
INFO - 2023-12-08 14:54:31 --> Router Class Initialized
INFO - 2023-12-08 14:54:31 --> Output Class Initialized
INFO - 2023-12-08 14:54:31 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:31 --> Input Class Initialized
INFO - 2023-12-08 14:54:31 --> Language Class Initialized
INFO - 2023-12-08 14:54:31 --> Language Class Initialized
INFO - 2023-12-08 14:54:31 --> Config Class Initialized
INFO - 2023-12-08 14:54:31 --> Loader Class Initialized
INFO - 2023-12-08 14:54:31 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:31 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:31 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:31 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:31 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:31 --> Controller Class Initialized
DEBUG - 2023-12-08 14:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:54:31 --> Final output sent to browser
DEBUG - 2023-12-08 14:54:31 --> Total execution time: 0.0653
INFO - 2023-12-08 14:54:31 --> Config Class Initialized
INFO - 2023-12-08 14:54:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:31 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:31 --> URI Class Initialized
INFO - 2023-12-08 14:54:31 --> Router Class Initialized
INFO - 2023-12-08 14:54:31 --> Output Class Initialized
INFO - 2023-12-08 14:54:31 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:31 --> Input Class Initialized
INFO - 2023-12-08 14:54:31 --> Language Class Initialized
INFO - 2023-12-08 14:54:31 --> Language Class Initialized
INFO - 2023-12-08 14:54:31 --> Config Class Initialized
INFO - 2023-12-08 14:54:31 --> Loader Class Initialized
INFO - 2023-12-08 14:54:31 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:31 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:31 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:31 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:31 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:31 --> Controller Class Initialized
INFO - 2023-12-08 14:54:34 --> Config Class Initialized
INFO - 2023-12-08 14:54:34 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:34 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:34 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:34 --> URI Class Initialized
INFO - 2023-12-08 14:54:34 --> Router Class Initialized
INFO - 2023-12-08 14:54:34 --> Output Class Initialized
INFO - 2023-12-08 14:54:34 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:34 --> Input Class Initialized
INFO - 2023-12-08 14:54:34 --> Language Class Initialized
INFO - 2023-12-08 14:54:34 --> Language Class Initialized
INFO - 2023-12-08 14:54:34 --> Config Class Initialized
INFO - 2023-12-08 14:54:34 --> Loader Class Initialized
INFO - 2023-12-08 14:54:34 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:34 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:34 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:34 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:34 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:34 --> Controller Class Initialized
INFO - 2023-12-08 14:54:34 --> Final output sent to browser
DEBUG - 2023-12-08 14:54:34 --> Total execution time: 0.3993
INFO - 2023-12-08 14:54:46 --> Config Class Initialized
INFO - 2023-12-08 14:54:46 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:46 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:46 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:46 --> URI Class Initialized
INFO - 2023-12-08 14:54:46 --> Router Class Initialized
INFO - 2023-12-08 14:54:46 --> Output Class Initialized
INFO - 2023-12-08 14:54:46 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:46 --> Input Class Initialized
INFO - 2023-12-08 14:54:46 --> Language Class Initialized
INFO - 2023-12-08 14:54:46 --> Language Class Initialized
INFO - 2023-12-08 14:54:46 --> Config Class Initialized
INFO - 2023-12-08 14:54:46 --> Loader Class Initialized
INFO - 2023-12-08 14:54:46 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:46 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:46 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:46 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:46 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:46 --> Controller Class Initialized
DEBUG - 2023-12-08 14:54:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 14:54:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:54:47 --> Final output sent to browser
DEBUG - 2023-12-08 14:54:47 --> Total execution time: 0.6675
INFO - 2023-12-08 14:54:59 --> Config Class Initialized
INFO - 2023-12-08 14:54:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:54:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:54:59 --> Utf8 Class Initialized
INFO - 2023-12-08 14:54:59 --> URI Class Initialized
INFO - 2023-12-08 14:54:59 --> Router Class Initialized
INFO - 2023-12-08 14:54:59 --> Output Class Initialized
INFO - 2023-12-08 14:54:59 --> Security Class Initialized
DEBUG - 2023-12-08 14:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:54:59 --> Input Class Initialized
INFO - 2023-12-08 14:54:59 --> Language Class Initialized
INFO - 2023-12-08 14:54:59 --> Language Class Initialized
INFO - 2023-12-08 14:54:59 --> Config Class Initialized
INFO - 2023-12-08 14:54:59 --> Loader Class Initialized
INFO - 2023-12-08 14:54:59 --> Helper loaded: url_helper
INFO - 2023-12-08 14:54:59 --> Helper loaded: file_helper
INFO - 2023-12-08 14:54:59 --> Helper loaded: form_helper
INFO - 2023-12-08 14:54:59 --> Helper loaded: my_helper
INFO - 2023-12-08 14:54:59 --> Database Driver Class Initialized
INFO - 2023-12-08 14:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:54:59 --> Controller Class Initialized
INFO - 2023-12-08 14:55:00 --> Config Class Initialized
INFO - 2023-12-08 14:55:00 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:55:00 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:55:00 --> Utf8 Class Initialized
INFO - 2023-12-08 14:55:00 --> URI Class Initialized
INFO - 2023-12-08 14:55:00 --> Router Class Initialized
INFO - 2023-12-08 14:55:00 --> Output Class Initialized
INFO - 2023-12-08 14:55:00 --> Security Class Initialized
DEBUG - 2023-12-08 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:55:00 --> Input Class Initialized
INFO - 2023-12-08 14:55:00 --> Language Class Initialized
INFO - 2023-12-08 14:55:00 --> Language Class Initialized
INFO - 2023-12-08 14:55:00 --> Config Class Initialized
INFO - 2023-12-08 14:55:00 --> Loader Class Initialized
INFO - 2023-12-08 14:55:00 --> Helper loaded: url_helper
INFO - 2023-12-08 14:55:00 --> Helper loaded: file_helper
INFO - 2023-12-08 14:55:00 --> Helper loaded: form_helper
INFO - 2023-12-08 14:55:00 --> Helper loaded: my_helper
INFO - 2023-12-08 14:55:00 --> Database Driver Class Initialized
INFO - 2023-12-08 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:55:00 --> Controller Class Initialized
DEBUG - 2023-12-08 14:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 14:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 14:55:00 --> Final output sent to browser
DEBUG - 2023-12-08 14:55:00 --> Total execution time: 0.0409
INFO - 2023-12-08 14:55:00 --> Config Class Initialized
INFO - 2023-12-08 14:55:00 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:55:00 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:55:00 --> Utf8 Class Initialized
INFO - 2023-12-08 14:55:00 --> URI Class Initialized
INFO - 2023-12-08 14:55:00 --> Router Class Initialized
INFO - 2023-12-08 14:55:00 --> Output Class Initialized
INFO - 2023-12-08 14:55:00 --> Security Class Initialized
DEBUG - 2023-12-08 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:55:00 --> Input Class Initialized
INFO - 2023-12-08 14:55:00 --> Language Class Initialized
INFO - 2023-12-08 14:55:00 --> Language Class Initialized
INFO - 2023-12-08 14:55:00 --> Config Class Initialized
INFO - 2023-12-08 14:55:00 --> Loader Class Initialized
INFO - 2023-12-08 14:55:00 --> Helper loaded: url_helper
INFO - 2023-12-08 14:55:00 --> Helper loaded: file_helper
INFO - 2023-12-08 14:55:00 --> Helper loaded: form_helper
INFO - 2023-12-08 14:55:00 --> Helper loaded: my_helper
INFO - 2023-12-08 14:55:00 --> Database Driver Class Initialized
INFO - 2023-12-08 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:55:00 --> Controller Class Initialized
INFO - 2023-12-08 14:55:02 --> Config Class Initialized
INFO - 2023-12-08 14:55:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:55:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:55:02 --> Utf8 Class Initialized
INFO - 2023-12-08 14:55:02 --> URI Class Initialized
INFO - 2023-12-08 14:55:02 --> Router Class Initialized
INFO - 2023-12-08 14:55:02 --> Output Class Initialized
INFO - 2023-12-08 14:55:02 --> Security Class Initialized
DEBUG - 2023-12-08 14:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:55:02 --> Input Class Initialized
INFO - 2023-12-08 14:55:02 --> Language Class Initialized
INFO - 2023-12-08 14:55:02 --> Language Class Initialized
INFO - 2023-12-08 14:55:02 --> Config Class Initialized
INFO - 2023-12-08 14:55:02 --> Loader Class Initialized
INFO - 2023-12-08 14:55:02 --> Helper loaded: url_helper
INFO - 2023-12-08 14:55:02 --> Helper loaded: file_helper
INFO - 2023-12-08 14:55:02 --> Helper loaded: form_helper
INFO - 2023-12-08 14:55:02 --> Helper loaded: my_helper
INFO - 2023-12-08 14:55:02 --> Database Driver Class Initialized
INFO - 2023-12-08 14:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:55:02 --> Controller Class Initialized
DEBUG - 2023-12-08 14:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 14:55:02 --> Final output sent to browser
DEBUG - 2023-12-08 14:55:02 --> Total execution time: 0.1524
INFO - 2023-12-08 14:59:50 --> Config Class Initialized
INFO - 2023-12-08 14:59:50 --> Hooks Class Initialized
DEBUG - 2023-12-08 14:59:50 --> UTF-8 Support Enabled
INFO - 2023-12-08 14:59:50 --> Utf8 Class Initialized
INFO - 2023-12-08 14:59:50 --> URI Class Initialized
INFO - 2023-12-08 14:59:50 --> Router Class Initialized
INFO - 2023-12-08 14:59:50 --> Output Class Initialized
INFO - 2023-12-08 14:59:50 --> Security Class Initialized
DEBUG - 2023-12-08 14:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 14:59:50 --> Input Class Initialized
INFO - 2023-12-08 14:59:50 --> Language Class Initialized
INFO - 2023-12-08 14:59:50 --> Language Class Initialized
INFO - 2023-12-08 14:59:50 --> Config Class Initialized
INFO - 2023-12-08 14:59:50 --> Loader Class Initialized
INFO - 2023-12-08 14:59:50 --> Helper loaded: url_helper
INFO - 2023-12-08 14:59:50 --> Helper loaded: file_helper
INFO - 2023-12-08 14:59:50 --> Helper loaded: form_helper
INFO - 2023-12-08 14:59:50 --> Helper loaded: my_helper
INFO - 2023-12-08 14:59:50 --> Database Driver Class Initialized
INFO - 2023-12-08 14:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 14:59:50 --> Controller Class Initialized
INFO - 2023-12-08 14:59:50 --> Final output sent to browser
DEBUG - 2023-12-08 14:59:50 --> Total execution time: 0.0796
INFO - 2023-12-08 15:00:01 --> Config Class Initialized
INFO - 2023-12-08 15:00:01 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:00:01 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:00:01 --> Utf8 Class Initialized
INFO - 2023-12-08 15:00:01 --> URI Class Initialized
INFO - 2023-12-08 15:00:02 --> Router Class Initialized
INFO - 2023-12-08 15:00:02 --> Output Class Initialized
INFO - 2023-12-08 15:00:02 --> Security Class Initialized
DEBUG - 2023-12-08 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:00:02 --> Input Class Initialized
INFO - 2023-12-08 15:00:02 --> Language Class Initialized
INFO - 2023-12-08 15:00:02 --> Language Class Initialized
INFO - 2023-12-08 15:00:02 --> Config Class Initialized
INFO - 2023-12-08 15:00:02 --> Loader Class Initialized
INFO - 2023-12-08 15:00:02 --> Helper loaded: url_helper
INFO - 2023-12-08 15:00:02 --> Helper loaded: file_helper
INFO - 2023-12-08 15:00:02 --> Helper loaded: form_helper
INFO - 2023-12-08 15:00:02 --> Helper loaded: my_helper
INFO - 2023-12-08 15:00:02 --> Database Driver Class Initialized
INFO - 2023-12-08 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:00:02 --> Controller Class Initialized
INFO - 2023-12-08 15:00:02 --> Final output sent to browser
DEBUG - 2023-12-08 15:00:02 --> Total execution time: 0.5202
INFO - 2023-12-08 15:00:02 --> Config Class Initialized
INFO - 2023-12-08 15:00:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:00:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:00:02 --> Utf8 Class Initialized
INFO - 2023-12-08 15:00:02 --> URI Class Initialized
INFO - 2023-12-08 15:00:02 --> Router Class Initialized
INFO - 2023-12-08 15:00:02 --> Output Class Initialized
INFO - 2023-12-08 15:00:02 --> Security Class Initialized
DEBUG - 2023-12-08 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:00:02 --> Input Class Initialized
INFO - 2023-12-08 15:00:02 --> Language Class Initialized
INFO - 2023-12-08 15:00:02 --> Language Class Initialized
INFO - 2023-12-08 15:00:02 --> Config Class Initialized
INFO - 2023-12-08 15:00:02 --> Loader Class Initialized
INFO - 2023-12-08 15:00:02 --> Helper loaded: url_helper
INFO - 2023-12-08 15:00:02 --> Helper loaded: file_helper
INFO - 2023-12-08 15:00:02 --> Helper loaded: form_helper
INFO - 2023-12-08 15:00:02 --> Helper loaded: my_helper
INFO - 2023-12-08 15:00:02 --> Database Driver Class Initialized
INFO - 2023-12-08 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:00:02 --> Controller Class Initialized
INFO - 2023-12-08 15:00:04 --> Config Class Initialized
INFO - 2023-12-08 15:00:04 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:00:04 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:00:04 --> Utf8 Class Initialized
INFO - 2023-12-08 15:00:04 --> URI Class Initialized
INFO - 2023-12-08 15:00:04 --> Router Class Initialized
INFO - 2023-12-08 15:00:04 --> Output Class Initialized
INFO - 2023-12-08 15:00:04 --> Security Class Initialized
DEBUG - 2023-12-08 15:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:00:04 --> Input Class Initialized
INFO - 2023-12-08 15:00:04 --> Language Class Initialized
INFO - 2023-12-08 15:00:04 --> Language Class Initialized
INFO - 2023-12-08 15:00:04 --> Config Class Initialized
INFO - 2023-12-08 15:00:04 --> Loader Class Initialized
INFO - 2023-12-08 15:00:04 --> Helper loaded: url_helper
INFO - 2023-12-08 15:00:04 --> Helper loaded: file_helper
INFO - 2023-12-08 15:00:04 --> Helper loaded: form_helper
INFO - 2023-12-08 15:00:04 --> Helper loaded: my_helper
INFO - 2023-12-08 15:00:04 --> Database Driver Class Initialized
INFO - 2023-12-08 15:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:00:04 --> Controller Class Initialized
INFO - 2023-12-08 15:10:25 --> Config Class Initialized
INFO - 2023-12-08 15:10:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:10:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:10:25 --> Utf8 Class Initialized
INFO - 2023-12-08 15:10:25 --> URI Class Initialized
INFO - 2023-12-08 15:10:25 --> Router Class Initialized
INFO - 2023-12-08 15:10:25 --> Output Class Initialized
INFO - 2023-12-08 15:10:25 --> Security Class Initialized
DEBUG - 2023-12-08 15:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:10:25 --> Input Class Initialized
INFO - 2023-12-08 15:10:25 --> Language Class Initialized
INFO - 2023-12-08 15:10:25 --> Language Class Initialized
INFO - 2023-12-08 15:10:25 --> Config Class Initialized
INFO - 2023-12-08 15:10:25 --> Loader Class Initialized
INFO - 2023-12-08 15:10:25 --> Helper loaded: url_helper
INFO - 2023-12-08 15:10:25 --> Helper loaded: file_helper
INFO - 2023-12-08 15:10:25 --> Helper loaded: form_helper
INFO - 2023-12-08 15:10:25 --> Helper loaded: my_helper
INFO - 2023-12-08 15:10:25 --> Database Driver Class Initialized
INFO - 2023-12-08 15:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:10:25 --> Controller Class Initialized
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:25 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2023-12-08 15:10:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 15:10:25 --> Final output sent to browser
DEBUG - 2023-12-08 15:10:25 --> Total execution time: 0.2775
INFO - 2023-12-08 15:10:29 --> Config Class Initialized
INFO - 2023-12-08 15:10:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:10:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:10:29 --> Utf8 Class Initialized
INFO - 2023-12-08 15:10:29 --> URI Class Initialized
INFO - 2023-12-08 15:10:29 --> Router Class Initialized
INFO - 2023-12-08 15:10:29 --> Output Class Initialized
INFO - 2023-12-08 15:10:29 --> Security Class Initialized
DEBUG - 2023-12-08 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:10:29 --> Input Class Initialized
INFO - 2023-12-08 15:10:29 --> Language Class Initialized
INFO - 2023-12-08 15:10:29 --> Language Class Initialized
INFO - 2023-12-08 15:10:29 --> Config Class Initialized
INFO - 2023-12-08 15:10:29 --> Loader Class Initialized
INFO - 2023-12-08 15:10:29 --> Helper loaded: url_helper
INFO - 2023-12-08 15:10:29 --> Helper loaded: file_helper
INFO - 2023-12-08 15:10:29 --> Helper loaded: form_helper
INFO - 2023-12-08 15:10:29 --> Helper loaded: my_helper
INFO - 2023-12-08 15:10:29 --> Database Driver Class Initialized
INFO - 2023-12-08 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:10:29 --> Controller Class Initialized
DEBUG - 2023-12-08 15:10:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:10:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:10:29 --> Final output sent to browser
DEBUG - 2023-12-08 15:10:29 --> Total execution time: 0.0735
INFO - 2023-12-08 15:10:29 --> Config Class Initialized
INFO - 2023-12-08 15:10:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:10:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:10:29 --> Utf8 Class Initialized
INFO - 2023-12-08 15:10:29 --> URI Class Initialized
INFO - 2023-12-08 15:10:29 --> Router Class Initialized
INFO - 2023-12-08 15:10:29 --> Output Class Initialized
INFO - 2023-12-08 15:10:29 --> Security Class Initialized
DEBUG - 2023-12-08 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:10:29 --> Input Class Initialized
INFO - 2023-12-08 15:10:29 --> Language Class Initialized
INFO - 2023-12-08 15:10:29 --> Language Class Initialized
INFO - 2023-12-08 15:10:29 --> Config Class Initialized
INFO - 2023-12-08 15:10:29 --> Loader Class Initialized
INFO - 2023-12-08 15:10:29 --> Helper loaded: url_helper
INFO - 2023-12-08 15:10:29 --> Helper loaded: file_helper
INFO - 2023-12-08 15:10:29 --> Helper loaded: form_helper
INFO - 2023-12-08 15:10:29 --> Helper loaded: my_helper
INFO - 2023-12-08 15:10:29 --> Database Driver Class Initialized
INFO - 2023-12-08 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:10:29 --> Controller Class Initialized
INFO - 2023-12-08 15:10:34 --> Config Class Initialized
INFO - 2023-12-08 15:10:34 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:10:34 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:10:34 --> Utf8 Class Initialized
INFO - 2023-12-08 15:10:34 --> URI Class Initialized
INFO - 2023-12-08 15:10:34 --> Router Class Initialized
INFO - 2023-12-08 15:10:34 --> Output Class Initialized
INFO - 2023-12-08 15:10:34 --> Security Class Initialized
DEBUG - 2023-12-08 15:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:10:34 --> Input Class Initialized
INFO - 2023-12-08 15:10:34 --> Language Class Initialized
INFO - 2023-12-08 15:10:34 --> Language Class Initialized
INFO - 2023-12-08 15:10:34 --> Config Class Initialized
INFO - 2023-12-08 15:10:34 --> Loader Class Initialized
INFO - 2023-12-08 15:10:34 --> Helper loaded: url_helper
INFO - 2023-12-08 15:10:34 --> Helper loaded: file_helper
INFO - 2023-12-08 15:10:34 --> Helper loaded: form_helper
INFO - 2023-12-08 15:10:34 --> Helper loaded: my_helper
INFO - 2023-12-08 15:10:34 --> Database Driver Class Initialized
INFO - 2023-12-08 15:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:10:34 --> Controller Class Initialized
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-08 15:10:34 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2023-12-08 15:10:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 15:10:34 --> Final output sent to browser
DEBUG - 2023-12-08 15:10:34 --> Total execution time: 0.1355
INFO - 2023-12-08 15:12:28 --> Config Class Initialized
INFO - 2023-12-08 15:12:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:12:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:12:28 --> Utf8 Class Initialized
INFO - 2023-12-08 15:12:28 --> URI Class Initialized
INFO - 2023-12-08 15:12:28 --> Router Class Initialized
INFO - 2023-12-08 15:12:28 --> Output Class Initialized
INFO - 2023-12-08 15:12:28 --> Security Class Initialized
DEBUG - 2023-12-08 15:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:12:28 --> Input Class Initialized
INFO - 2023-12-08 15:12:28 --> Language Class Initialized
INFO - 2023-12-08 15:12:28 --> Language Class Initialized
INFO - 2023-12-08 15:12:28 --> Config Class Initialized
INFO - 2023-12-08 15:12:28 --> Loader Class Initialized
INFO - 2023-12-08 15:12:28 --> Helper loaded: url_helper
INFO - 2023-12-08 15:12:28 --> Helper loaded: file_helper
INFO - 2023-12-08 15:12:28 --> Helper loaded: form_helper
INFO - 2023-12-08 15:12:28 --> Helper loaded: my_helper
INFO - 2023-12-08 15:12:28 --> Database Driver Class Initialized
INFO - 2023-12-08 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:12:29 --> Controller Class Initialized
DEBUG - 2023-12-08 15:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 15:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:12:29 --> Final output sent to browser
DEBUG - 2023-12-08 15:12:29 --> Total execution time: 0.6682
INFO - 2023-12-08 15:12:41 --> Config Class Initialized
INFO - 2023-12-08 15:12:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:12:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:12:41 --> Utf8 Class Initialized
INFO - 2023-12-08 15:12:41 --> URI Class Initialized
INFO - 2023-12-08 15:12:41 --> Router Class Initialized
INFO - 2023-12-08 15:12:41 --> Output Class Initialized
INFO - 2023-12-08 15:12:41 --> Security Class Initialized
DEBUG - 2023-12-08 15:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:12:41 --> Input Class Initialized
INFO - 2023-12-08 15:12:41 --> Language Class Initialized
INFO - 2023-12-08 15:12:41 --> Language Class Initialized
INFO - 2023-12-08 15:12:41 --> Config Class Initialized
INFO - 2023-12-08 15:12:41 --> Loader Class Initialized
INFO - 2023-12-08 15:12:41 --> Helper loaded: url_helper
INFO - 2023-12-08 15:12:41 --> Helper loaded: file_helper
INFO - 2023-12-08 15:12:41 --> Helper loaded: form_helper
INFO - 2023-12-08 15:12:41 --> Helper loaded: my_helper
INFO - 2023-12-08 15:12:41 --> Database Driver Class Initialized
INFO - 2023-12-08 15:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:12:41 --> Controller Class Initialized
INFO - 2023-12-08 15:12:42 --> Config Class Initialized
INFO - 2023-12-08 15:12:42 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:12:42 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:12:42 --> Utf8 Class Initialized
INFO - 2023-12-08 15:12:42 --> URI Class Initialized
INFO - 2023-12-08 15:12:42 --> Router Class Initialized
INFO - 2023-12-08 15:12:42 --> Output Class Initialized
INFO - 2023-12-08 15:12:42 --> Security Class Initialized
DEBUG - 2023-12-08 15:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:12:42 --> Input Class Initialized
INFO - 2023-12-08 15:12:42 --> Language Class Initialized
INFO - 2023-12-08 15:12:42 --> Language Class Initialized
INFO - 2023-12-08 15:12:42 --> Config Class Initialized
INFO - 2023-12-08 15:12:42 --> Loader Class Initialized
INFO - 2023-12-08 15:12:42 --> Helper loaded: url_helper
INFO - 2023-12-08 15:12:42 --> Helper loaded: file_helper
INFO - 2023-12-08 15:12:42 --> Helper loaded: form_helper
INFO - 2023-12-08 15:12:42 --> Helper loaded: my_helper
INFO - 2023-12-08 15:12:42 --> Database Driver Class Initialized
INFO - 2023-12-08 15:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:12:42 --> Controller Class Initialized
DEBUG - 2023-12-08 15:12:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:12:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:12:42 --> Final output sent to browser
DEBUG - 2023-12-08 15:12:42 --> Total execution time: 0.0642
INFO - 2023-12-08 15:12:42 --> Config Class Initialized
INFO - 2023-12-08 15:12:42 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:12:42 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:12:42 --> Utf8 Class Initialized
INFO - 2023-12-08 15:12:42 --> URI Class Initialized
INFO - 2023-12-08 15:12:42 --> Router Class Initialized
INFO - 2023-12-08 15:12:42 --> Output Class Initialized
INFO - 2023-12-08 15:12:42 --> Security Class Initialized
DEBUG - 2023-12-08 15:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:12:42 --> Input Class Initialized
INFO - 2023-12-08 15:12:42 --> Language Class Initialized
INFO - 2023-12-08 15:12:42 --> Language Class Initialized
INFO - 2023-12-08 15:12:42 --> Config Class Initialized
INFO - 2023-12-08 15:12:42 --> Loader Class Initialized
INFO - 2023-12-08 15:12:42 --> Helper loaded: url_helper
INFO - 2023-12-08 15:12:42 --> Helper loaded: file_helper
INFO - 2023-12-08 15:12:42 --> Helper loaded: form_helper
INFO - 2023-12-08 15:12:42 --> Helper loaded: my_helper
INFO - 2023-12-08 15:12:42 --> Database Driver Class Initialized
INFO - 2023-12-08 15:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:12:42 --> Controller Class Initialized
INFO - 2023-12-08 15:12:44 --> Config Class Initialized
INFO - 2023-12-08 15:12:44 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:12:44 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:12:44 --> Utf8 Class Initialized
INFO - 2023-12-08 15:12:44 --> URI Class Initialized
INFO - 2023-12-08 15:12:44 --> Router Class Initialized
INFO - 2023-12-08 15:12:44 --> Output Class Initialized
INFO - 2023-12-08 15:12:44 --> Security Class Initialized
DEBUG - 2023-12-08 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:12:44 --> Input Class Initialized
INFO - 2023-12-08 15:12:44 --> Language Class Initialized
INFO - 2023-12-08 15:12:44 --> Language Class Initialized
INFO - 2023-12-08 15:12:44 --> Config Class Initialized
INFO - 2023-12-08 15:12:44 --> Loader Class Initialized
INFO - 2023-12-08 15:12:44 --> Helper loaded: url_helper
INFO - 2023-12-08 15:12:44 --> Helper loaded: file_helper
INFO - 2023-12-08 15:12:44 --> Helper loaded: form_helper
INFO - 2023-12-08 15:12:44 --> Helper loaded: my_helper
INFO - 2023-12-08 15:12:44 --> Database Driver Class Initialized
INFO - 2023-12-08 15:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:12:44 --> Controller Class Initialized
DEBUG - 2023-12-08 15:12:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-08 15:12:44 --> Final output sent to browser
DEBUG - 2023-12-08 15:12:44 --> Total execution time: 0.3980
INFO - 2023-12-08 15:24:57 --> Config Class Initialized
INFO - 2023-12-08 15:24:57 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:24:57 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:24:57 --> Utf8 Class Initialized
INFO - 2023-12-08 15:24:57 --> URI Class Initialized
INFO - 2023-12-08 15:24:57 --> Router Class Initialized
INFO - 2023-12-08 15:24:57 --> Output Class Initialized
INFO - 2023-12-08 15:24:57 --> Security Class Initialized
DEBUG - 2023-12-08 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:24:57 --> Input Class Initialized
INFO - 2023-12-08 15:24:57 --> Language Class Initialized
INFO - 2023-12-08 15:24:57 --> Language Class Initialized
INFO - 2023-12-08 15:24:57 --> Config Class Initialized
INFO - 2023-12-08 15:24:57 --> Loader Class Initialized
INFO - 2023-12-08 15:24:57 --> Helper loaded: url_helper
INFO - 2023-12-08 15:24:57 --> Helper loaded: file_helper
INFO - 2023-12-08 15:24:57 --> Helper loaded: form_helper
INFO - 2023-12-08 15:24:57 --> Helper loaded: my_helper
INFO - 2023-12-08 15:24:57 --> Database Driver Class Initialized
INFO - 2023-12-08 15:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:24:57 --> Controller Class Initialized
DEBUG - 2023-12-08 15:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 15:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:24:57 --> Final output sent to browser
DEBUG - 2023-12-08 15:24:57 --> Total execution time: 0.0784
INFO - 2023-12-08 15:34:03 --> Config Class Initialized
INFO - 2023-12-08 15:34:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:34:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:34:03 --> Utf8 Class Initialized
INFO - 2023-12-08 15:34:03 --> URI Class Initialized
INFO - 2023-12-08 15:34:03 --> Router Class Initialized
INFO - 2023-12-08 15:34:03 --> Output Class Initialized
INFO - 2023-12-08 15:34:03 --> Security Class Initialized
DEBUG - 2023-12-08 15:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:34:03 --> Input Class Initialized
INFO - 2023-12-08 15:34:03 --> Language Class Initialized
INFO - 2023-12-08 15:34:03 --> Language Class Initialized
INFO - 2023-12-08 15:34:03 --> Config Class Initialized
INFO - 2023-12-08 15:34:03 --> Loader Class Initialized
INFO - 2023-12-08 15:34:03 --> Helper loaded: url_helper
INFO - 2023-12-08 15:34:03 --> Helper loaded: file_helper
INFO - 2023-12-08 15:34:03 --> Helper loaded: form_helper
INFO - 2023-12-08 15:34:03 --> Helper loaded: my_helper
INFO - 2023-12-08 15:34:03 --> Database Driver Class Initialized
INFO - 2023-12-08 15:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:34:04 --> Controller Class Initialized
DEBUG - 2023-12-08 15:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 15:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:34:04 --> Final output sent to browser
DEBUG - 2023-12-08 15:34:04 --> Total execution time: 0.6197
INFO - 2023-12-08 15:55:45 --> Config Class Initialized
INFO - 2023-12-08 15:55:45 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:55:45 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:55:45 --> Utf8 Class Initialized
INFO - 2023-12-08 15:55:45 --> URI Class Initialized
INFO - 2023-12-08 15:55:45 --> Router Class Initialized
INFO - 2023-12-08 15:55:45 --> Output Class Initialized
INFO - 2023-12-08 15:55:45 --> Security Class Initialized
DEBUG - 2023-12-08 15:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:55:45 --> Input Class Initialized
INFO - 2023-12-08 15:55:45 --> Language Class Initialized
INFO - 2023-12-08 15:55:45 --> Language Class Initialized
INFO - 2023-12-08 15:55:45 --> Config Class Initialized
INFO - 2023-12-08 15:55:45 --> Loader Class Initialized
INFO - 2023-12-08 15:55:45 --> Helper loaded: url_helper
INFO - 2023-12-08 15:55:45 --> Helper loaded: file_helper
INFO - 2023-12-08 15:55:45 --> Helper loaded: form_helper
INFO - 2023-12-08 15:55:45 --> Helper loaded: my_helper
INFO - 2023-12-08 15:55:45 --> Database Driver Class Initialized
INFO - 2023-12-08 15:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:55:45 --> Controller Class Initialized
DEBUG - 2023-12-08 15:55:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:55:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:55:45 --> Final output sent to browser
DEBUG - 2023-12-08 15:55:45 --> Total execution time: 0.0995
INFO - 2023-12-08 15:55:46 --> Config Class Initialized
INFO - 2023-12-08 15:55:46 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:55:46 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:55:46 --> Utf8 Class Initialized
INFO - 2023-12-08 15:55:46 --> URI Class Initialized
INFO - 2023-12-08 15:55:46 --> Router Class Initialized
INFO - 2023-12-08 15:55:46 --> Output Class Initialized
INFO - 2023-12-08 15:55:46 --> Security Class Initialized
DEBUG - 2023-12-08 15:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:55:46 --> Input Class Initialized
INFO - 2023-12-08 15:55:46 --> Language Class Initialized
INFO - 2023-12-08 15:55:46 --> Language Class Initialized
INFO - 2023-12-08 15:55:46 --> Config Class Initialized
INFO - 2023-12-08 15:55:46 --> Loader Class Initialized
INFO - 2023-12-08 15:55:46 --> Helper loaded: url_helper
INFO - 2023-12-08 15:55:46 --> Helper loaded: file_helper
INFO - 2023-12-08 15:55:46 --> Helper loaded: form_helper
INFO - 2023-12-08 15:55:46 --> Helper loaded: my_helper
INFO - 2023-12-08 15:55:46 --> Database Driver Class Initialized
INFO - 2023-12-08 15:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:55:46 --> Controller Class Initialized
INFO - 2023-12-08 15:55:50 --> Config Class Initialized
INFO - 2023-12-08 15:55:50 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:55:50 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:55:50 --> Utf8 Class Initialized
INFO - 2023-12-08 15:55:50 --> URI Class Initialized
INFO - 2023-12-08 15:55:50 --> Router Class Initialized
INFO - 2023-12-08 15:55:50 --> Output Class Initialized
INFO - 2023-12-08 15:55:50 --> Security Class Initialized
DEBUG - 2023-12-08 15:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:55:50 --> Input Class Initialized
INFO - 2023-12-08 15:55:50 --> Language Class Initialized
INFO - 2023-12-08 15:55:50 --> Language Class Initialized
INFO - 2023-12-08 15:55:50 --> Config Class Initialized
INFO - 2023-12-08 15:55:50 --> Loader Class Initialized
INFO - 2023-12-08 15:55:50 --> Helper loaded: url_helper
INFO - 2023-12-08 15:55:50 --> Helper loaded: file_helper
INFO - 2023-12-08 15:55:50 --> Helper loaded: form_helper
INFO - 2023-12-08 15:55:50 --> Helper loaded: my_helper
INFO - 2023-12-08 15:55:50 --> Database Driver Class Initialized
INFO - 2023-12-08 15:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:55:50 --> Controller Class Initialized
DEBUG - 2023-12-08 15:55:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 15:55:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:55:50 --> Final output sent to browser
DEBUG - 2023-12-08 15:55:50 --> Total execution time: 0.0866
INFO - 2023-12-08 15:55:53 --> Config Class Initialized
INFO - 2023-12-08 15:55:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:55:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:55:53 --> Utf8 Class Initialized
INFO - 2023-12-08 15:55:53 --> URI Class Initialized
INFO - 2023-12-08 15:55:53 --> Router Class Initialized
INFO - 2023-12-08 15:55:53 --> Output Class Initialized
INFO - 2023-12-08 15:55:53 --> Security Class Initialized
DEBUG - 2023-12-08 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:55:53 --> Input Class Initialized
INFO - 2023-12-08 15:55:53 --> Language Class Initialized
INFO - 2023-12-08 15:55:53 --> Language Class Initialized
INFO - 2023-12-08 15:55:53 --> Config Class Initialized
INFO - 2023-12-08 15:55:53 --> Loader Class Initialized
INFO - 2023-12-08 15:55:53 --> Helper loaded: url_helper
INFO - 2023-12-08 15:55:53 --> Helper loaded: file_helper
INFO - 2023-12-08 15:55:53 --> Helper loaded: form_helper
INFO - 2023-12-08 15:55:53 --> Helper loaded: my_helper
INFO - 2023-12-08 15:55:53 --> Database Driver Class Initialized
INFO - 2023-12-08 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:55:53 --> Controller Class Initialized
DEBUG - 2023-12-08 15:55:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:55:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:55:53 --> Final output sent to browser
DEBUG - 2023-12-08 15:55:53 --> Total execution time: 0.0712
INFO - 2023-12-08 15:55:53 --> Config Class Initialized
INFO - 2023-12-08 15:55:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:55:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:55:53 --> Utf8 Class Initialized
INFO - 2023-12-08 15:55:53 --> URI Class Initialized
INFO - 2023-12-08 15:55:53 --> Router Class Initialized
INFO - 2023-12-08 15:55:53 --> Output Class Initialized
INFO - 2023-12-08 15:55:53 --> Security Class Initialized
DEBUG - 2023-12-08 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:55:53 --> Input Class Initialized
INFO - 2023-12-08 15:55:53 --> Language Class Initialized
INFO - 2023-12-08 15:55:53 --> Language Class Initialized
INFO - 2023-12-08 15:55:53 --> Config Class Initialized
INFO - 2023-12-08 15:55:53 --> Loader Class Initialized
INFO - 2023-12-08 15:55:53 --> Helper loaded: url_helper
INFO - 2023-12-08 15:55:53 --> Helper loaded: file_helper
INFO - 2023-12-08 15:55:53 --> Helper loaded: form_helper
INFO - 2023-12-08 15:55:53 --> Helper loaded: my_helper
INFO - 2023-12-08 15:55:53 --> Database Driver Class Initialized
INFO - 2023-12-08 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:55:53 --> Controller Class Initialized
INFO - 2023-12-08 15:55:58 --> Config Class Initialized
INFO - 2023-12-08 15:55:58 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:55:58 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:55:58 --> Utf8 Class Initialized
INFO - 2023-12-08 15:55:58 --> URI Class Initialized
INFO - 2023-12-08 15:55:58 --> Router Class Initialized
INFO - 2023-12-08 15:55:58 --> Output Class Initialized
INFO - 2023-12-08 15:55:58 --> Security Class Initialized
DEBUG - 2023-12-08 15:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:55:58 --> Input Class Initialized
INFO - 2023-12-08 15:55:58 --> Language Class Initialized
INFO - 2023-12-08 15:55:58 --> Language Class Initialized
INFO - 2023-12-08 15:55:58 --> Config Class Initialized
INFO - 2023-12-08 15:55:58 --> Loader Class Initialized
INFO - 2023-12-08 15:55:58 --> Helper loaded: url_helper
INFO - 2023-12-08 15:55:58 --> Helper loaded: file_helper
INFO - 2023-12-08 15:55:58 --> Helper loaded: form_helper
INFO - 2023-12-08 15:55:58 --> Helper loaded: my_helper
INFO - 2023-12-08 15:55:58 --> Database Driver Class Initialized
INFO - 2023-12-08 15:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:55:58 --> Controller Class Initialized
INFO - 2023-12-08 15:55:58 --> Final output sent to browser
DEBUG - 2023-12-08 15:55:58 --> Total execution time: 0.4343
INFO - 2023-12-08 15:56:08 --> Config Class Initialized
INFO - 2023-12-08 15:56:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:08 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:08 --> URI Class Initialized
INFO - 2023-12-08 15:56:08 --> Router Class Initialized
INFO - 2023-12-08 15:56:08 --> Output Class Initialized
INFO - 2023-12-08 15:56:08 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:08 --> Input Class Initialized
INFO - 2023-12-08 15:56:08 --> Language Class Initialized
INFO - 2023-12-08 15:56:08 --> Language Class Initialized
INFO - 2023-12-08 15:56:08 --> Config Class Initialized
INFO - 2023-12-08 15:56:08 --> Loader Class Initialized
INFO - 2023-12-08 15:56:08 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:08 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:08 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:08 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:08 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:08 --> Controller Class Initialized
DEBUG - 2023-12-08 15:56:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 15:56:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:56:08 --> Final output sent to browser
DEBUG - 2023-12-08 15:56:08 --> Total execution time: 0.1874
INFO - 2023-12-08 15:56:17 --> Config Class Initialized
INFO - 2023-12-08 15:56:17 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:17 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:17 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:17 --> URI Class Initialized
INFO - 2023-12-08 15:56:17 --> Router Class Initialized
INFO - 2023-12-08 15:56:17 --> Output Class Initialized
INFO - 2023-12-08 15:56:17 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:17 --> Input Class Initialized
INFO - 2023-12-08 15:56:17 --> Language Class Initialized
INFO - 2023-12-08 15:56:17 --> Language Class Initialized
INFO - 2023-12-08 15:56:17 --> Config Class Initialized
INFO - 2023-12-08 15:56:17 --> Loader Class Initialized
INFO - 2023-12-08 15:56:17 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:17 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:17 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:17 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:17 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:17 --> Controller Class Initialized
INFO - 2023-12-08 15:56:17 --> Config Class Initialized
INFO - 2023-12-08 15:56:17 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:17 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:17 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:17 --> URI Class Initialized
INFO - 2023-12-08 15:56:17 --> Router Class Initialized
INFO - 2023-12-08 15:56:17 --> Output Class Initialized
INFO - 2023-12-08 15:56:17 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:17 --> Input Class Initialized
INFO - 2023-12-08 15:56:17 --> Language Class Initialized
INFO - 2023-12-08 15:56:17 --> Language Class Initialized
INFO - 2023-12-08 15:56:17 --> Config Class Initialized
INFO - 2023-12-08 15:56:17 --> Loader Class Initialized
INFO - 2023-12-08 15:56:17 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:17 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:17 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:17 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:17 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:18 --> Controller Class Initialized
DEBUG - 2023-12-08 15:56:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:56:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:56:18 --> Final output sent to browser
DEBUG - 2023-12-08 15:56:18 --> Total execution time: 0.2940
INFO - 2023-12-08 15:56:18 --> Config Class Initialized
INFO - 2023-12-08 15:56:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:18 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:18 --> URI Class Initialized
INFO - 2023-12-08 15:56:18 --> Router Class Initialized
INFO - 2023-12-08 15:56:18 --> Output Class Initialized
INFO - 2023-12-08 15:56:18 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:18 --> Input Class Initialized
INFO - 2023-12-08 15:56:18 --> Language Class Initialized
INFO - 2023-12-08 15:56:18 --> Language Class Initialized
INFO - 2023-12-08 15:56:18 --> Config Class Initialized
INFO - 2023-12-08 15:56:18 --> Loader Class Initialized
INFO - 2023-12-08 15:56:18 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:18 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:18 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:18 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:18 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:18 --> Controller Class Initialized
INFO - 2023-12-08 15:56:25 --> Config Class Initialized
INFO - 2023-12-08 15:56:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:25 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:25 --> URI Class Initialized
INFO - 2023-12-08 15:56:25 --> Router Class Initialized
INFO - 2023-12-08 15:56:25 --> Output Class Initialized
INFO - 2023-12-08 15:56:25 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:25 --> Input Class Initialized
INFO - 2023-12-08 15:56:25 --> Language Class Initialized
INFO - 2023-12-08 15:56:25 --> Language Class Initialized
INFO - 2023-12-08 15:56:25 --> Config Class Initialized
INFO - 2023-12-08 15:56:25 --> Loader Class Initialized
INFO - 2023-12-08 15:56:25 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:25 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:25 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:25 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:25 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:26 --> Controller Class Initialized
INFO - 2023-12-08 15:56:26 --> Final output sent to browser
DEBUG - 2023-12-08 15:56:26 --> Total execution time: 0.3648
INFO - 2023-12-08 15:56:28 --> Config Class Initialized
INFO - 2023-12-08 15:56:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:28 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:28 --> URI Class Initialized
INFO - 2023-12-08 15:56:28 --> Router Class Initialized
INFO - 2023-12-08 15:56:28 --> Output Class Initialized
INFO - 2023-12-08 15:56:28 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:28 --> Input Class Initialized
INFO - 2023-12-08 15:56:28 --> Language Class Initialized
INFO - 2023-12-08 15:56:28 --> Language Class Initialized
INFO - 2023-12-08 15:56:28 --> Config Class Initialized
INFO - 2023-12-08 15:56:28 --> Loader Class Initialized
INFO - 2023-12-08 15:56:28 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:28 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:28 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:28 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:28 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:28 --> Controller Class Initialized
INFO - 2023-12-08 15:56:28 --> Final output sent to browser
DEBUG - 2023-12-08 15:56:28 --> Total execution time: 0.0466
INFO - 2023-12-08 15:56:31 --> Config Class Initialized
INFO - 2023-12-08 15:56:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:31 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:31 --> URI Class Initialized
INFO - 2023-12-08 15:56:31 --> Router Class Initialized
INFO - 2023-12-08 15:56:31 --> Output Class Initialized
INFO - 2023-12-08 15:56:31 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:31 --> Input Class Initialized
INFO - 2023-12-08 15:56:31 --> Language Class Initialized
INFO - 2023-12-08 15:56:31 --> Language Class Initialized
INFO - 2023-12-08 15:56:31 --> Config Class Initialized
INFO - 2023-12-08 15:56:31 --> Loader Class Initialized
INFO - 2023-12-08 15:56:31 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:31 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:31 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:31 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:31 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:31 --> Controller Class Initialized
INFO - 2023-12-08 15:56:31 --> Final output sent to browser
DEBUG - 2023-12-08 15:56:31 --> Total execution time: 0.2603
INFO - 2023-12-08 15:56:38 --> Config Class Initialized
INFO - 2023-12-08 15:56:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:56:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:56:38 --> Utf8 Class Initialized
INFO - 2023-12-08 15:56:38 --> URI Class Initialized
INFO - 2023-12-08 15:56:38 --> Router Class Initialized
INFO - 2023-12-08 15:56:38 --> Output Class Initialized
INFO - 2023-12-08 15:56:38 --> Security Class Initialized
DEBUG - 2023-12-08 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:56:38 --> Input Class Initialized
INFO - 2023-12-08 15:56:38 --> Language Class Initialized
INFO - 2023-12-08 15:56:38 --> Language Class Initialized
INFO - 2023-12-08 15:56:38 --> Config Class Initialized
INFO - 2023-12-08 15:56:38 --> Loader Class Initialized
INFO - 2023-12-08 15:56:38 --> Helper loaded: url_helper
INFO - 2023-12-08 15:56:38 --> Helper loaded: file_helper
INFO - 2023-12-08 15:56:38 --> Helper loaded: form_helper
INFO - 2023-12-08 15:56:38 --> Helper loaded: my_helper
INFO - 2023-12-08 15:56:38 --> Database Driver Class Initialized
INFO - 2023-12-08 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:56:38 --> Controller Class Initialized
INFO - 2023-12-08 15:56:38 --> Final output sent to browser
DEBUG - 2023-12-08 15:56:38 --> Total execution time: 0.0735
INFO - 2023-12-08 15:57:39 --> Config Class Initialized
INFO - 2023-12-08 15:57:39 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:39 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:39 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:39 --> URI Class Initialized
INFO - 2023-12-08 15:57:39 --> Router Class Initialized
INFO - 2023-12-08 15:57:39 --> Output Class Initialized
INFO - 2023-12-08 15:57:39 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:39 --> Input Class Initialized
INFO - 2023-12-08 15:57:39 --> Language Class Initialized
INFO - 2023-12-08 15:57:39 --> Language Class Initialized
INFO - 2023-12-08 15:57:39 --> Config Class Initialized
INFO - 2023-12-08 15:57:39 --> Loader Class Initialized
INFO - 2023-12-08 15:57:39 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:39 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:39 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:39 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:39 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:39 --> Controller Class Initialized
DEBUG - 2023-12-08 15:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:57:39 --> Final output sent to browser
DEBUG - 2023-12-08 15:57:39 --> Total execution time: 0.0657
INFO - 2023-12-08 15:57:39 --> Config Class Initialized
INFO - 2023-12-08 15:57:39 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:39 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:39 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:39 --> URI Class Initialized
INFO - 2023-12-08 15:57:39 --> Router Class Initialized
INFO - 2023-12-08 15:57:39 --> Output Class Initialized
INFO - 2023-12-08 15:57:39 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:39 --> Input Class Initialized
INFO - 2023-12-08 15:57:39 --> Language Class Initialized
INFO - 2023-12-08 15:57:39 --> Language Class Initialized
INFO - 2023-12-08 15:57:39 --> Config Class Initialized
INFO - 2023-12-08 15:57:39 --> Loader Class Initialized
INFO - 2023-12-08 15:57:39 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:39 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:39 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:39 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:40 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:40 --> Controller Class Initialized
INFO - 2023-12-08 15:57:49 --> Config Class Initialized
INFO - 2023-12-08 15:57:49 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:49 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:49 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:49 --> URI Class Initialized
INFO - 2023-12-08 15:57:49 --> Router Class Initialized
INFO - 2023-12-08 15:57:49 --> Output Class Initialized
INFO - 2023-12-08 15:57:49 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:49 --> Input Class Initialized
INFO - 2023-12-08 15:57:49 --> Language Class Initialized
INFO - 2023-12-08 15:57:49 --> Language Class Initialized
INFO - 2023-12-08 15:57:49 --> Config Class Initialized
INFO - 2023-12-08 15:57:49 --> Loader Class Initialized
INFO - 2023-12-08 15:57:49 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:49 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:49 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:49 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:49 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:49 --> Controller Class Initialized
DEBUG - 2023-12-08 15:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 15:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:57:49 --> Final output sent to browser
DEBUG - 2023-12-08 15:57:49 --> Total execution time: 0.0787
INFO - 2023-12-08 15:57:49 --> Config Class Initialized
INFO - 2023-12-08 15:57:49 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:49 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:49 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:49 --> URI Class Initialized
INFO - 2023-12-08 15:57:49 --> Router Class Initialized
INFO - 2023-12-08 15:57:49 --> Output Class Initialized
INFO - 2023-12-08 15:57:49 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:49 --> Input Class Initialized
INFO - 2023-12-08 15:57:49 --> Language Class Initialized
INFO - 2023-12-08 15:57:49 --> Language Class Initialized
INFO - 2023-12-08 15:57:49 --> Config Class Initialized
INFO - 2023-12-08 15:57:49 --> Loader Class Initialized
INFO - 2023-12-08 15:57:49 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:49 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:49 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:49 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:49 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:49 --> Controller Class Initialized
INFO - 2023-12-08 15:57:54 --> Config Class Initialized
INFO - 2023-12-08 15:57:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:54 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:54 --> URI Class Initialized
INFO - 2023-12-08 15:57:54 --> Router Class Initialized
INFO - 2023-12-08 15:57:54 --> Output Class Initialized
INFO - 2023-12-08 15:57:54 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:54 --> Input Class Initialized
INFO - 2023-12-08 15:57:54 --> Language Class Initialized
INFO - 2023-12-08 15:57:54 --> Language Class Initialized
INFO - 2023-12-08 15:57:54 --> Config Class Initialized
INFO - 2023-12-08 15:57:54 --> Loader Class Initialized
INFO - 2023-12-08 15:57:54 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:54 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:54 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:54 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:54 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:54 --> Controller Class Initialized
INFO - 2023-12-08 15:57:54 --> Final output sent to browser
DEBUG - 2023-12-08 15:57:54 --> Total execution time: 0.0426
INFO - 2023-12-08 15:57:56 --> Config Class Initialized
INFO - 2023-12-08 15:57:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:56 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:56 --> URI Class Initialized
DEBUG - 2023-12-08 15:57:56 --> No URI present. Default controller set.
INFO - 2023-12-08 15:57:56 --> Router Class Initialized
INFO - 2023-12-08 15:57:56 --> Output Class Initialized
INFO - 2023-12-08 15:57:56 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:56 --> Input Class Initialized
INFO - 2023-12-08 15:57:56 --> Language Class Initialized
INFO - 2023-12-08 15:57:56 --> Language Class Initialized
INFO - 2023-12-08 15:57:56 --> Config Class Initialized
INFO - 2023-12-08 15:57:56 --> Loader Class Initialized
INFO - 2023-12-08 15:57:56 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:56 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:56 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:56 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:56 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:56 --> Controller Class Initialized
INFO - 2023-12-08 15:57:56 --> Config Class Initialized
INFO - 2023-12-08 15:57:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:57:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:57:56 --> Utf8 Class Initialized
INFO - 2023-12-08 15:57:56 --> URI Class Initialized
INFO - 2023-12-08 15:57:56 --> Router Class Initialized
INFO - 2023-12-08 15:57:56 --> Output Class Initialized
INFO - 2023-12-08 15:57:56 --> Security Class Initialized
DEBUG - 2023-12-08 15:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:57:56 --> Input Class Initialized
INFO - 2023-12-08 15:57:56 --> Language Class Initialized
INFO - 2023-12-08 15:57:56 --> Language Class Initialized
INFO - 2023-12-08 15:57:56 --> Config Class Initialized
INFO - 2023-12-08 15:57:56 --> Loader Class Initialized
INFO - 2023-12-08 15:57:56 --> Helper loaded: url_helper
INFO - 2023-12-08 15:57:56 --> Helper loaded: file_helper
INFO - 2023-12-08 15:57:56 --> Helper loaded: form_helper
INFO - 2023-12-08 15:57:56 --> Helper loaded: my_helper
INFO - 2023-12-08 15:57:56 --> Database Driver Class Initialized
INFO - 2023-12-08 15:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:57:56 --> Controller Class Initialized
DEBUG - 2023-12-08 15:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 15:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:57:56 --> Final output sent to browser
DEBUG - 2023-12-08 15:57:56 --> Total execution time: 0.0590
INFO - 2023-12-08 15:58:08 --> Config Class Initialized
INFO - 2023-12-08 15:58:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:58:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:58:08 --> Utf8 Class Initialized
INFO - 2023-12-08 15:58:08 --> URI Class Initialized
INFO - 2023-12-08 15:58:08 --> Router Class Initialized
INFO - 2023-12-08 15:58:08 --> Output Class Initialized
INFO - 2023-12-08 15:58:08 --> Security Class Initialized
DEBUG - 2023-12-08 15:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:58:08 --> Input Class Initialized
INFO - 2023-12-08 15:58:08 --> Language Class Initialized
INFO - 2023-12-08 15:58:08 --> Language Class Initialized
INFO - 2023-12-08 15:58:08 --> Config Class Initialized
INFO - 2023-12-08 15:58:08 --> Loader Class Initialized
INFO - 2023-12-08 15:58:08 --> Helper loaded: url_helper
INFO - 2023-12-08 15:58:08 --> Helper loaded: file_helper
INFO - 2023-12-08 15:58:08 --> Helper loaded: form_helper
INFO - 2023-12-08 15:58:08 --> Helper loaded: my_helper
INFO - 2023-12-08 15:58:08 --> Database Driver Class Initialized
INFO - 2023-12-08 15:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:58:08 --> Controller Class Initialized
INFO - 2023-12-08 15:58:09 --> Helper loaded: cookie_helper
INFO - 2023-12-08 15:58:09 --> Final output sent to browser
DEBUG - 2023-12-08 15:58:09 --> Total execution time: 0.6122
INFO - 2023-12-08 15:58:09 --> Config Class Initialized
INFO - 2023-12-08 15:58:09 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:58:09 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:58:09 --> Utf8 Class Initialized
INFO - 2023-12-08 15:58:09 --> URI Class Initialized
INFO - 2023-12-08 15:58:09 --> Router Class Initialized
INFO - 2023-12-08 15:58:09 --> Output Class Initialized
INFO - 2023-12-08 15:58:09 --> Security Class Initialized
DEBUG - 2023-12-08 15:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:58:09 --> Input Class Initialized
INFO - 2023-12-08 15:58:09 --> Language Class Initialized
INFO - 2023-12-08 15:58:09 --> Language Class Initialized
INFO - 2023-12-08 15:58:09 --> Config Class Initialized
INFO - 2023-12-08 15:58:09 --> Loader Class Initialized
INFO - 2023-12-08 15:58:09 --> Helper loaded: url_helper
INFO - 2023-12-08 15:58:09 --> Helper loaded: file_helper
INFO - 2023-12-08 15:58:09 --> Helper loaded: form_helper
INFO - 2023-12-08 15:58:09 --> Helper loaded: my_helper
INFO - 2023-12-08 15:58:09 --> Database Driver Class Initialized
INFO - 2023-12-08 15:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:58:09 --> Controller Class Initialized
DEBUG - 2023-12-08 15:58:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 15:58:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:58:09 --> Final output sent to browser
DEBUG - 2023-12-08 15:58:09 --> Total execution time: 0.1186
INFO - 2023-12-08 15:58:16 --> Config Class Initialized
INFO - 2023-12-08 15:58:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:58:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:58:16 --> Utf8 Class Initialized
INFO - 2023-12-08 15:58:16 --> URI Class Initialized
INFO - 2023-12-08 15:58:16 --> Router Class Initialized
INFO - 2023-12-08 15:58:16 --> Output Class Initialized
INFO - 2023-12-08 15:58:16 --> Security Class Initialized
DEBUG - 2023-12-08 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:58:16 --> Input Class Initialized
INFO - 2023-12-08 15:58:16 --> Language Class Initialized
INFO - 2023-12-08 15:58:16 --> Language Class Initialized
INFO - 2023-12-08 15:58:16 --> Config Class Initialized
INFO - 2023-12-08 15:58:16 --> Loader Class Initialized
INFO - 2023-12-08 15:58:16 --> Helper loaded: url_helper
INFO - 2023-12-08 15:58:16 --> Helper loaded: file_helper
INFO - 2023-12-08 15:58:16 --> Helper loaded: form_helper
INFO - 2023-12-08 15:58:16 --> Helper loaded: my_helper
INFO - 2023-12-08 15:58:16 --> Database Driver Class Initialized
INFO - 2023-12-08 15:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:58:16 --> Controller Class Initialized
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 15:58:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-08 15:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-08 15:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:58:16 --> Final output sent to browser
DEBUG - 2023-12-08 15:58:16 --> Total execution time: 0.1700
INFO - 2023-12-08 15:58:19 --> Config Class Initialized
INFO - 2023-12-08 15:58:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:58:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:58:19 --> Utf8 Class Initialized
INFO - 2023-12-08 15:58:19 --> URI Class Initialized
INFO - 2023-12-08 15:58:19 --> Router Class Initialized
INFO - 2023-12-08 15:58:19 --> Output Class Initialized
INFO - 2023-12-08 15:58:19 --> Security Class Initialized
DEBUG - 2023-12-08 15:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:58:19 --> Input Class Initialized
INFO - 2023-12-08 15:58:19 --> Language Class Initialized
INFO - 2023-12-08 15:58:19 --> Language Class Initialized
INFO - 2023-12-08 15:58:19 --> Config Class Initialized
INFO - 2023-12-08 15:58:19 --> Loader Class Initialized
INFO - 2023-12-08 15:58:19 --> Helper loaded: url_helper
INFO - 2023-12-08 15:58:19 --> Helper loaded: file_helper
INFO - 2023-12-08 15:58:19 --> Helper loaded: form_helper
INFO - 2023-12-08 15:58:19 --> Helper loaded: my_helper
INFO - 2023-12-08 15:58:19 --> Database Driver Class Initialized
INFO - 2023-12-08 15:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:58:19 --> Controller Class Initialized
DEBUG - 2023-12-08 15:58:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 15:58:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 15:58:20 --> Final output sent to browser
DEBUG - 2023-12-08 15:58:20 --> Total execution time: 0.0702
INFO - 2023-12-08 15:58:20 --> Config Class Initialized
INFO - 2023-12-08 15:58:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:58:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:58:20 --> Utf8 Class Initialized
INFO - 2023-12-08 15:58:20 --> URI Class Initialized
INFO - 2023-12-08 15:58:20 --> Router Class Initialized
INFO - 2023-12-08 15:58:20 --> Output Class Initialized
INFO - 2023-12-08 15:58:20 --> Security Class Initialized
DEBUG - 2023-12-08 15:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:58:20 --> Input Class Initialized
INFO - 2023-12-08 15:58:20 --> Language Class Initialized
INFO - 2023-12-08 15:58:20 --> Language Class Initialized
INFO - 2023-12-08 15:58:20 --> Config Class Initialized
INFO - 2023-12-08 15:58:20 --> Loader Class Initialized
INFO - 2023-12-08 15:58:20 --> Helper loaded: url_helper
INFO - 2023-12-08 15:58:20 --> Helper loaded: file_helper
INFO - 2023-12-08 15:58:20 --> Helper loaded: form_helper
INFO - 2023-12-08 15:58:20 --> Helper loaded: my_helper
INFO - 2023-12-08 15:58:20 --> Database Driver Class Initialized
INFO - 2023-12-08 15:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:58:20 --> Controller Class Initialized
INFO - 2023-12-08 15:58:26 --> Config Class Initialized
INFO - 2023-12-08 15:58:26 --> Hooks Class Initialized
DEBUG - 2023-12-08 15:58:26 --> UTF-8 Support Enabled
INFO - 2023-12-08 15:58:26 --> Utf8 Class Initialized
INFO - 2023-12-08 15:58:26 --> URI Class Initialized
INFO - 2023-12-08 15:58:26 --> Router Class Initialized
INFO - 2023-12-08 15:58:26 --> Output Class Initialized
INFO - 2023-12-08 15:58:26 --> Security Class Initialized
DEBUG - 2023-12-08 15:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 15:58:26 --> Input Class Initialized
INFO - 2023-12-08 15:58:26 --> Language Class Initialized
INFO - 2023-12-08 15:58:26 --> Language Class Initialized
INFO - 2023-12-08 15:58:26 --> Config Class Initialized
INFO - 2023-12-08 15:58:26 --> Loader Class Initialized
INFO - 2023-12-08 15:58:26 --> Helper loaded: url_helper
INFO - 2023-12-08 15:58:26 --> Helper loaded: file_helper
INFO - 2023-12-08 15:58:26 --> Helper loaded: form_helper
INFO - 2023-12-08 15:58:26 --> Helper loaded: my_helper
INFO - 2023-12-08 15:58:26 --> Database Driver Class Initialized
INFO - 2023-12-08 15:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 15:58:26 --> Controller Class Initialized
INFO - 2023-12-08 15:58:26 --> Final output sent to browser
DEBUG - 2023-12-08 15:58:26 --> Total execution time: 0.0634
INFO - 2023-12-08 16:02:22 --> Config Class Initialized
INFO - 2023-12-08 16:02:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:02:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:02:22 --> Utf8 Class Initialized
INFO - 2023-12-08 16:02:22 --> URI Class Initialized
INFO - 2023-12-08 16:02:23 --> Router Class Initialized
INFO - 2023-12-08 16:02:23 --> Output Class Initialized
INFO - 2023-12-08 16:02:23 --> Security Class Initialized
DEBUG - 2023-12-08 16:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:02:23 --> Input Class Initialized
INFO - 2023-12-08 16:02:23 --> Language Class Initialized
INFO - 2023-12-08 16:02:23 --> Language Class Initialized
INFO - 2023-12-08 16:02:23 --> Config Class Initialized
INFO - 2023-12-08 16:02:23 --> Loader Class Initialized
INFO - 2023-12-08 16:02:23 --> Helper loaded: url_helper
INFO - 2023-12-08 16:02:23 --> Helper loaded: file_helper
INFO - 2023-12-08 16:02:23 --> Helper loaded: form_helper
INFO - 2023-12-08 16:02:23 --> Helper loaded: my_helper
INFO - 2023-12-08 16:02:23 --> Database Driver Class Initialized
INFO - 2023-12-08 16:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:02:23 --> Controller Class Initialized
INFO - 2023-12-08 16:06:54 --> Config Class Initialized
INFO - 2023-12-08 16:06:54 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:06:54 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:06:54 --> Utf8 Class Initialized
INFO - 2023-12-08 16:06:54 --> URI Class Initialized
INFO - 2023-12-08 16:06:54 --> Router Class Initialized
INFO - 2023-12-08 16:06:54 --> Output Class Initialized
INFO - 2023-12-08 16:06:54 --> Security Class Initialized
DEBUG - 2023-12-08 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:06:54 --> Input Class Initialized
INFO - 2023-12-08 16:06:54 --> Language Class Initialized
INFO - 2023-12-08 16:06:54 --> Language Class Initialized
INFO - 2023-12-08 16:06:54 --> Config Class Initialized
INFO - 2023-12-08 16:06:54 --> Loader Class Initialized
INFO - 2023-12-08 16:06:54 --> Helper loaded: url_helper
INFO - 2023-12-08 16:06:54 --> Helper loaded: file_helper
INFO - 2023-12-08 16:06:54 --> Helper loaded: form_helper
INFO - 2023-12-08 16:06:54 --> Helper loaded: my_helper
INFO - 2023-12-08 16:06:54 --> Database Driver Class Initialized
INFO - 2023-12-08 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:06:54 --> Controller Class Initialized
DEBUG - 2023-12-08 16:06:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:06:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:06:54 --> Final output sent to browser
DEBUG - 2023-12-08 16:06:54 --> Total execution time: 0.1611
INFO - 2023-12-08 16:07:00 --> Config Class Initialized
INFO - 2023-12-08 16:07:00 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:00 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:00 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:00 --> URI Class Initialized
INFO - 2023-12-08 16:07:00 --> Router Class Initialized
INFO - 2023-12-08 16:07:00 --> Output Class Initialized
INFO - 2023-12-08 16:07:00 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:00 --> Input Class Initialized
INFO - 2023-12-08 16:07:00 --> Language Class Initialized
INFO - 2023-12-08 16:07:00 --> Language Class Initialized
INFO - 2023-12-08 16:07:00 --> Config Class Initialized
INFO - 2023-12-08 16:07:00 --> Loader Class Initialized
INFO - 2023-12-08 16:07:00 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:00 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:00 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:00 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:00 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:00 --> Controller Class Initialized
INFO - 2023-12-08 16:07:00 --> Config Class Initialized
INFO - 2023-12-08 16:07:00 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:00 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:00 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:00 --> URI Class Initialized
INFO - 2023-12-08 16:07:00 --> Router Class Initialized
INFO - 2023-12-08 16:07:00 --> Output Class Initialized
INFO - 2023-12-08 16:07:00 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:00 --> Input Class Initialized
INFO - 2023-12-08 16:07:00 --> Language Class Initialized
INFO - 2023-12-08 16:07:00 --> Language Class Initialized
INFO - 2023-12-08 16:07:00 --> Config Class Initialized
INFO - 2023-12-08 16:07:00 --> Loader Class Initialized
INFO - 2023-12-08 16:07:00 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:00 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:00 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:00 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:00 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:01 --> Controller Class Initialized
DEBUG - 2023-12-08 16:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:07:01 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:01 --> Total execution time: 0.0480
INFO - 2023-12-08 16:07:01 --> Config Class Initialized
INFO - 2023-12-08 16:07:01 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:01 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:01 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:01 --> URI Class Initialized
INFO - 2023-12-08 16:07:01 --> Router Class Initialized
INFO - 2023-12-08 16:07:01 --> Output Class Initialized
INFO - 2023-12-08 16:07:01 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:01 --> Input Class Initialized
INFO - 2023-12-08 16:07:01 --> Language Class Initialized
INFO - 2023-12-08 16:07:01 --> Language Class Initialized
INFO - 2023-12-08 16:07:01 --> Config Class Initialized
INFO - 2023-12-08 16:07:01 --> Loader Class Initialized
INFO - 2023-12-08 16:07:01 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:01 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:01 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:01 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:01 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:01 --> Controller Class Initialized
INFO - 2023-12-08 16:07:02 --> Config Class Initialized
INFO - 2023-12-08 16:07:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:02 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:02 --> URI Class Initialized
INFO - 2023-12-08 16:07:02 --> Router Class Initialized
INFO - 2023-12-08 16:07:02 --> Output Class Initialized
INFO - 2023-12-08 16:07:02 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:02 --> Input Class Initialized
INFO - 2023-12-08 16:07:02 --> Language Class Initialized
INFO - 2023-12-08 16:07:02 --> Language Class Initialized
INFO - 2023-12-08 16:07:02 --> Config Class Initialized
INFO - 2023-12-08 16:07:02 --> Loader Class Initialized
INFO - 2023-12-08 16:07:02 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:02 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:02 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:02 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:02 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:02 --> Controller Class Initialized
ERROR - 2023-12-08 16:07:02 --> Severity: Notice --> Undefined variable: q_siswa_kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/controllers/N_kelompok.php 115
ERROR - 2023-12-08 16:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/controllers/N_kelompok.php 115
DEBUG - 2023-12-08 16:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/cetak.php
INFO - 2023-12-08 16:07:02 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:02 --> Total execution time: 0.4223
INFO - 2023-12-08 16:07:06 --> Config Class Initialized
INFO - 2023-12-08 16:07:06 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:06 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:06 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:06 --> URI Class Initialized
INFO - 2023-12-08 16:07:06 --> Router Class Initialized
INFO - 2023-12-08 16:07:06 --> Output Class Initialized
INFO - 2023-12-08 16:07:06 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:06 --> Input Class Initialized
INFO - 2023-12-08 16:07:06 --> Language Class Initialized
INFO - 2023-12-08 16:07:06 --> Language Class Initialized
INFO - 2023-12-08 16:07:06 --> Config Class Initialized
INFO - 2023-12-08 16:07:06 --> Loader Class Initialized
INFO - 2023-12-08 16:07:06 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:06 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:06 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:06 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:06 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:06 --> Controller Class Initialized
DEBUG - 2023-12-08 16:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:07:06 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:06 --> Total execution time: 0.0803
INFO - 2023-12-08 16:07:06 --> Config Class Initialized
INFO - 2023-12-08 16:07:06 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:06 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:06 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:06 --> URI Class Initialized
INFO - 2023-12-08 16:07:06 --> Router Class Initialized
INFO - 2023-12-08 16:07:06 --> Output Class Initialized
INFO - 2023-12-08 16:07:06 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:06 --> Input Class Initialized
INFO - 2023-12-08 16:07:06 --> Language Class Initialized
INFO - 2023-12-08 16:07:06 --> Language Class Initialized
INFO - 2023-12-08 16:07:06 --> Config Class Initialized
INFO - 2023-12-08 16:07:06 --> Loader Class Initialized
INFO - 2023-12-08 16:07:06 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:06 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:06 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:06 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:06 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:06 --> Controller Class Initialized
INFO - 2023-12-08 16:07:07 --> Config Class Initialized
INFO - 2023-12-08 16:07:07 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:07 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:07 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:07 --> URI Class Initialized
INFO - 2023-12-08 16:07:07 --> Router Class Initialized
INFO - 2023-12-08 16:07:07 --> Output Class Initialized
INFO - 2023-12-08 16:07:07 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:07 --> Input Class Initialized
INFO - 2023-12-08 16:07:07 --> Language Class Initialized
INFO - 2023-12-08 16:07:07 --> Language Class Initialized
INFO - 2023-12-08 16:07:07 --> Config Class Initialized
INFO - 2023-12-08 16:07:07 --> Loader Class Initialized
INFO - 2023-12-08 16:07:07 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:07 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:07 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:07 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:07 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:07 --> Controller Class Initialized
ERROR - 2023-12-08 16:07:07 --> Severity: Notice --> Undefined variable: q_siswa_kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/controllers/N_kelompok.php 115
ERROR - 2023-12-08 16:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/controllers/N_kelompok.php 115
DEBUG - 2023-12-08 16:07:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/cetak.php
INFO - 2023-12-08 16:07:07 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:07 --> Total execution time: 0.0428
INFO - 2023-12-08 16:07:11 --> Config Class Initialized
INFO - 2023-12-08 16:07:11 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:11 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:11 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:11 --> URI Class Initialized
INFO - 2023-12-08 16:07:11 --> Router Class Initialized
INFO - 2023-12-08 16:07:11 --> Output Class Initialized
INFO - 2023-12-08 16:07:11 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:11 --> Input Class Initialized
INFO - 2023-12-08 16:07:11 --> Language Class Initialized
INFO - 2023-12-08 16:07:11 --> Language Class Initialized
INFO - 2023-12-08 16:07:11 --> Config Class Initialized
INFO - 2023-12-08 16:07:11 --> Loader Class Initialized
INFO - 2023-12-08 16:07:11 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:11 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:11 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:11 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:11 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:11 --> Controller Class Initialized
INFO - 2023-12-08 16:07:11 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:11 --> Total execution time: 0.1936
INFO - 2023-12-08 16:07:17 --> Config Class Initialized
INFO - 2023-12-08 16:07:17 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:17 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:17 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:17 --> URI Class Initialized
INFO - 2023-12-08 16:07:17 --> Router Class Initialized
INFO - 2023-12-08 16:07:17 --> Output Class Initialized
INFO - 2023-12-08 16:07:17 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:17 --> Input Class Initialized
INFO - 2023-12-08 16:07:17 --> Language Class Initialized
INFO - 2023-12-08 16:07:17 --> Language Class Initialized
INFO - 2023-12-08 16:07:17 --> Config Class Initialized
INFO - 2023-12-08 16:07:17 --> Loader Class Initialized
INFO - 2023-12-08 16:07:17 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:17 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:17 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:17 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:17 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:17 --> Controller Class Initialized
DEBUG - 2023-12-08 16:07:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:07:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:07:17 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:17 --> Total execution time: 0.0728
INFO - 2023-12-08 16:07:18 --> Config Class Initialized
INFO - 2023-12-08 16:07:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:18 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:18 --> URI Class Initialized
INFO - 2023-12-08 16:07:18 --> Router Class Initialized
INFO - 2023-12-08 16:07:18 --> Output Class Initialized
INFO - 2023-12-08 16:07:18 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:18 --> Input Class Initialized
INFO - 2023-12-08 16:07:18 --> Language Class Initialized
INFO - 2023-12-08 16:07:18 --> Language Class Initialized
INFO - 2023-12-08 16:07:18 --> Config Class Initialized
INFO - 2023-12-08 16:07:18 --> Loader Class Initialized
INFO - 2023-12-08 16:07:18 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:18 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:18 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:18 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:18 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:18 --> Controller Class Initialized
DEBUG - 2023-12-08 16:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:07:18 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:18 --> Total execution time: 0.0914
INFO - 2023-12-08 16:07:18 --> Config Class Initialized
INFO - 2023-12-08 16:07:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:18 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:18 --> URI Class Initialized
INFO - 2023-12-08 16:07:18 --> Router Class Initialized
INFO - 2023-12-08 16:07:18 --> Output Class Initialized
INFO - 2023-12-08 16:07:18 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:18 --> Input Class Initialized
INFO - 2023-12-08 16:07:18 --> Language Class Initialized
INFO - 2023-12-08 16:07:18 --> Language Class Initialized
INFO - 2023-12-08 16:07:18 --> Config Class Initialized
INFO - 2023-12-08 16:07:18 --> Loader Class Initialized
INFO - 2023-12-08 16:07:18 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:18 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:18 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:18 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:18 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:18 --> Controller Class Initialized
INFO - 2023-12-08 16:07:20 --> Config Class Initialized
INFO - 2023-12-08 16:07:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:20 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:20 --> URI Class Initialized
INFO - 2023-12-08 16:07:20 --> Router Class Initialized
INFO - 2023-12-08 16:07:20 --> Output Class Initialized
INFO - 2023-12-08 16:07:20 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:20 --> Input Class Initialized
INFO - 2023-12-08 16:07:20 --> Language Class Initialized
INFO - 2023-12-08 16:07:20 --> Language Class Initialized
INFO - 2023-12-08 16:07:20 --> Config Class Initialized
INFO - 2023-12-08 16:07:20 --> Loader Class Initialized
INFO - 2023-12-08 16:07:20 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:20 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:20 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:20 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:20 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:20 --> Controller Class Initialized
INFO - 2023-12-08 16:07:20 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:20 --> Total execution time: 0.2095
INFO - 2023-12-08 16:07:22 --> Config Class Initialized
INFO - 2023-12-08 16:07:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:22 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:22 --> URI Class Initialized
INFO - 2023-12-08 16:07:22 --> Router Class Initialized
INFO - 2023-12-08 16:07:22 --> Output Class Initialized
INFO - 2023-12-08 16:07:22 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:22 --> Input Class Initialized
INFO - 2023-12-08 16:07:22 --> Language Class Initialized
INFO - 2023-12-08 16:07:22 --> Language Class Initialized
INFO - 2023-12-08 16:07:22 --> Config Class Initialized
INFO - 2023-12-08 16:07:22 --> Loader Class Initialized
INFO - 2023-12-08 16:07:22 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:22 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:22 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:22 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:22 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:22 --> Controller Class Initialized
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:07:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-08 16:07:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-08 16:07:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:07:22 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:22 --> Total execution time: 0.0899
INFO - 2023-12-08 16:07:26 --> Config Class Initialized
INFO - 2023-12-08 16:07:26 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:26 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:26 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:26 --> URI Class Initialized
INFO - 2023-12-08 16:07:26 --> Router Class Initialized
INFO - 2023-12-08 16:07:26 --> Output Class Initialized
INFO - 2023-12-08 16:07:26 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:26 --> Input Class Initialized
INFO - 2023-12-08 16:07:26 --> Language Class Initialized
INFO - 2023-12-08 16:07:26 --> Language Class Initialized
INFO - 2023-12-08 16:07:26 --> Config Class Initialized
INFO - 2023-12-08 16:07:26 --> Loader Class Initialized
INFO - 2023-12-08 16:07:26 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:26 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:26 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:26 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:26 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:26 --> Controller Class Initialized
DEBUG - 2023-12-08 16:07:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:07:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:07:26 --> Final output sent to browser
DEBUG - 2023-12-08 16:07:26 --> Total execution time: 0.1021
INFO - 2023-12-08 16:07:27 --> Config Class Initialized
INFO - 2023-12-08 16:07:27 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:27 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:27 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:27 --> URI Class Initialized
INFO - 2023-12-08 16:07:27 --> Router Class Initialized
INFO - 2023-12-08 16:07:27 --> Output Class Initialized
INFO - 2023-12-08 16:07:27 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:27 --> Input Class Initialized
INFO - 2023-12-08 16:07:27 --> Language Class Initialized
INFO - 2023-12-08 16:07:27 --> Language Class Initialized
INFO - 2023-12-08 16:07:27 --> Config Class Initialized
INFO - 2023-12-08 16:07:27 --> Loader Class Initialized
INFO - 2023-12-08 16:07:27 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:27 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:27 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:27 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:27 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:27 --> Controller Class Initialized
INFO - 2023-12-08 16:07:38 --> Config Class Initialized
INFO - 2023-12-08 16:07:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:07:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:07:38 --> Utf8 Class Initialized
INFO - 2023-12-08 16:07:38 --> URI Class Initialized
INFO - 2023-12-08 16:07:38 --> Router Class Initialized
INFO - 2023-12-08 16:07:38 --> Output Class Initialized
INFO - 2023-12-08 16:07:38 --> Security Class Initialized
DEBUG - 2023-12-08 16:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:07:38 --> Input Class Initialized
INFO - 2023-12-08 16:07:38 --> Language Class Initialized
INFO - 2023-12-08 16:07:38 --> Language Class Initialized
INFO - 2023-12-08 16:07:38 --> Config Class Initialized
INFO - 2023-12-08 16:07:38 --> Loader Class Initialized
INFO - 2023-12-08 16:07:38 --> Helper loaded: url_helper
INFO - 2023-12-08 16:07:38 --> Helper loaded: file_helper
INFO - 2023-12-08 16:07:38 --> Helper loaded: form_helper
INFO - 2023-12-08 16:07:38 --> Helper loaded: my_helper
INFO - 2023-12-08 16:07:39 --> Database Driver Class Initialized
INFO - 2023-12-08 16:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:07:39 --> Controller Class Initialized
INFO - 2023-12-08 16:11:53 --> Config Class Initialized
INFO - 2023-12-08 16:11:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:11:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:11:53 --> Utf8 Class Initialized
INFO - 2023-12-08 16:11:53 --> URI Class Initialized
INFO - 2023-12-08 16:11:53 --> Router Class Initialized
INFO - 2023-12-08 16:11:53 --> Output Class Initialized
INFO - 2023-12-08 16:11:53 --> Security Class Initialized
DEBUG - 2023-12-08 16:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:11:53 --> Input Class Initialized
INFO - 2023-12-08 16:11:53 --> Language Class Initialized
INFO - 2023-12-08 16:11:53 --> Language Class Initialized
INFO - 2023-12-08 16:11:53 --> Config Class Initialized
INFO - 2023-12-08 16:11:53 --> Loader Class Initialized
INFO - 2023-12-08 16:11:53 --> Helper loaded: url_helper
INFO - 2023-12-08 16:11:53 --> Helper loaded: file_helper
INFO - 2023-12-08 16:11:53 --> Helper loaded: form_helper
INFO - 2023-12-08 16:11:53 --> Helper loaded: my_helper
INFO - 2023-12-08 16:11:53 --> Database Driver Class Initialized
INFO - 2023-12-08 16:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:11:53 --> Controller Class Initialized
DEBUG - 2023-12-08 16:11:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:11:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:11:53 --> Final output sent to browser
DEBUG - 2023-12-08 16:11:53 --> Total execution time: 0.0662
INFO - 2023-12-08 16:11:59 --> Config Class Initialized
INFO - 2023-12-08 16:11:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:11:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:11:59 --> Utf8 Class Initialized
INFO - 2023-12-08 16:11:59 --> URI Class Initialized
INFO - 2023-12-08 16:11:59 --> Router Class Initialized
INFO - 2023-12-08 16:11:59 --> Output Class Initialized
INFO - 2023-12-08 16:11:59 --> Security Class Initialized
DEBUG - 2023-12-08 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:11:59 --> Input Class Initialized
INFO - 2023-12-08 16:11:59 --> Language Class Initialized
INFO - 2023-12-08 16:11:59 --> Language Class Initialized
INFO - 2023-12-08 16:11:59 --> Config Class Initialized
INFO - 2023-12-08 16:11:59 --> Loader Class Initialized
INFO - 2023-12-08 16:11:59 --> Helper loaded: url_helper
INFO - 2023-12-08 16:11:59 --> Helper loaded: file_helper
INFO - 2023-12-08 16:11:59 --> Helper loaded: form_helper
INFO - 2023-12-08 16:11:59 --> Helper loaded: my_helper
INFO - 2023-12-08 16:11:59 --> Database Driver Class Initialized
INFO - 2023-12-08 16:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:11:59 --> Controller Class Initialized
INFO - 2023-12-08 16:11:59 --> Config Class Initialized
INFO - 2023-12-08 16:11:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:11:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:11:59 --> Utf8 Class Initialized
INFO - 2023-12-08 16:11:59 --> URI Class Initialized
INFO - 2023-12-08 16:11:59 --> Router Class Initialized
INFO - 2023-12-08 16:11:59 --> Output Class Initialized
INFO - 2023-12-08 16:11:59 --> Security Class Initialized
DEBUG - 2023-12-08 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:11:59 --> Input Class Initialized
INFO - 2023-12-08 16:11:59 --> Language Class Initialized
INFO - 2023-12-08 16:11:59 --> Language Class Initialized
INFO - 2023-12-08 16:11:59 --> Config Class Initialized
INFO - 2023-12-08 16:11:59 --> Loader Class Initialized
INFO - 2023-12-08 16:11:59 --> Helper loaded: url_helper
INFO - 2023-12-08 16:11:59 --> Helper loaded: file_helper
INFO - 2023-12-08 16:11:59 --> Helper loaded: form_helper
INFO - 2023-12-08 16:11:59 --> Helper loaded: my_helper
INFO - 2023-12-08 16:11:59 --> Database Driver Class Initialized
INFO - 2023-12-08 16:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:11:59 --> Controller Class Initialized
DEBUG - 2023-12-08 16:11:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:11:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:11:59 --> Final output sent to browser
DEBUG - 2023-12-08 16:11:59 --> Total execution time: 0.0568
INFO - 2023-12-08 16:11:59 --> Config Class Initialized
INFO - 2023-12-08 16:11:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:11:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:11:59 --> Utf8 Class Initialized
INFO - 2023-12-08 16:11:59 --> URI Class Initialized
INFO - 2023-12-08 16:11:59 --> Router Class Initialized
INFO - 2023-12-08 16:11:59 --> Output Class Initialized
INFO - 2023-12-08 16:11:59 --> Security Class Initialized
DEBUG - 2023-12-08 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:11:59 --> Input Class Initialized
INFO - 2023-12-08 16:11:59 --> Language Class Initialized
INFO - 2023-12-08 16:11:59 --> Language Class Initialized
INFO - 2023-12-08 16:11:59 --> Config Class Initialized
INFO - 2023-12-08 16:11:59 --> Loader Class Initialized
INFO - 2023-12-08 16:12:00 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:00 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:00 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:00 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:00 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:00 --> Controller Class Initialized
INFO - 2023-12-08 16:12:03 --> Config Class Initialized
INFO - 2023-12-08 16:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:03 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:03 --> URI Class Initialized
INFO - 2023-12-08 16:12:03 --> Router Class Initialized
INFO - 2023-12-08 16:12:03 --> Output Class Initialized
INFO - 2023-12-08 16:12:03 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:03 --> Input Class Initialized
INFO - 2023-12-08 16:12:03 --> Language Class Initialized
INFO - 2023-12-08 16:12:03 --> Language Class Initialized
INFO - 2023-12-08 16:12:03 --> Config Class Initialized
INFO - 2023-12-08 16:12:03 --> Loader Class Initialized
INFO - 2023-12-08 16:12:03 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:03 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:03 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:03 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:03 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:03 --> Controller Class Initialized
INFO - 2023-12-08 16:12:04 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:04 --> Total execution time: 1.2858
INFO - 2023-12-08 16:12:08 --> Config Class Initialized
INFO - 2023-12-08 16:12:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:08 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:08 --> URI Class Initialized
INFO - 2023-12-08 16:12:08 --> Router Class Initialized
INFO - 2023-12-08 16:12:08 --> Output Class Initialized
INFO - 2023-12-08 16:12:08 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:08 --> Input Class Initialized
INFO - 2023-12-08 16:12:08 --> Language Class Initialized
INFO - 2023-12-08 16:12:08 --> Language Class Initialized
INFO - 2023-12-08 16:12:08 --> Config Class Initialized
INFO - 2023-12-08 16:12:08 --> Loader Class Initialized
INFO - 2023-12-08 16:12:08 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:08 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:08 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:08 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:08 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:08 --> Controller Class Initialized
ERROR - 2023-12-08 16:12:08 --> Severity: Notice --> Undefined variable: q_siswa_kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/controllers/N_kelompok.php 115
ERROR - 2023-12-08 16:12:08 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/controllers/N_kelompok.php 115
DEBUG - 2023-12-08 16:12:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/cetak.php
INFO - 2023-12-08 16:12:08 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:08 --> Total execution time: 0.1217
INFO - 2023-12-08 16:12:10 --> Config Class Initialized
INFO - 2023-12-08 16:12:10 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:10 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:10 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:10 --> URI Class Initialized
INFO - 2023-12-08 16:12:10 --> Router Class Initialized
INFO - 2023-12-08 16:12:10 --> Output Class Initialized
INFO - 2023-12-08 16:12:10 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:10 --> Input Class Initialized
INFO - 2023-12-08 16:12:10 --> Language Class Initialized
INFO - 2023-12-08 16:12:10 --> Language Class Initialized
INFO - 2023-12-08 16:12:10 --> Config Class Initialized
INFO - 2023-12-08 16:12:10 --> Loader Class Initialized
INFO - 2023-12-08 16:12:10 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:10 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:10 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:10 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:10 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:10 --> Controller Class Initialized
DEBUG - 2023-12-08 16:12:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:12:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:10 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:10 --> Total execution time: 0.1866
INFO - 2023-12-08 16:12:11 --> Config Class Initialized
INFO - 2023-12-08 16:12:11 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:11 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:11 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:11 --> URI Class Initialized
INFO - 2023-12-08 16:12:11 --> Router Class Initialized
INFO - 2023-12-08 16:12:11 --> Output Class Initialized
INFO - 2023-12-08 16:12:11 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:11 --> Input Class Initialized
INFO - 2023-12-08 16:12:11 --> Language Class Initialized
INFO - 2023-12-08 16:12:11 --> Language Class Initialized
INFO - 2023-12-08 16:12:11 --> Config Class Initialized
INFO - 2023-12-08 16:12:11 --> Loader Class Initialized
INFO - 2023-12-08 16:12:11 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:11 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:11 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:11 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:11 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:11 --> Controller Class Initialized
INFO - 2023-12-08 16:12:16 --> Config Class Initialized
INFO - 2023-12-08 16:12:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:16 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:16 --> URI Class Initialized
INFO - 2023-12-08 16:12:16 --> Router Class Initialized
INFO - 2023-12-08 16:12:16 --> Output Class Initialized
INFO - 2023-12-08 16:12:16 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:16 --> Input Class Initialized
INFO - 2023-12-08 16:12:16 --> Language Class Initialized
INFO - 2023-12-08 16:12:16 --> Language Class Initialized
INFO - 2023-12-08 16:12:16 --> Config Class Initialized
INFO - 2023-12-08 16:12:16 --> Loader Class Initialized
INFO - 2023-12-08 16:12:16 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:16 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:16 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:16 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:16 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:16 --> Controller Class Initialized
DEBUG - 2023-12-08 16:12:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:12:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:16 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:16 --> Total execution time: 0.2263
INFO - 2023-12-08 16:12:21 --> Config Class Initialized
INFO - 2023-12-08 16:12:21 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:21 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:21 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:21 --> URI Class Initialized
INFO - 2023-12-08 16:12:21 --> Router Class Initialized
INFO - 2023-12-08 16:12:21 --> Output Class Initialized
INFO - 2023-12-08 16:12:21 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:21 --> Input Class Initialized
INFO - 2023-12-08 16:12:21 --> Language Class Initialized
INFO - 2023-12-08 16:12:22 --> Language Class Initialized
INFO - 2023-12-08 16:12:22 --> Config Class Initialized
INFO - 2023-12-08 16:12:22 --> Loader Class Initialized
INFO - 2023-12-08 16:12:22 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:22 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:22 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:22 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:22 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:22 --> Controller Class Initialized
INFO - 2023-12-08 16:12:23 --> Config Class Initialized
INFO - 2023-12-08 16:12:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:23 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:23 --> URI Class Initialized
INFO - 2023-12-08 16:12:23 --> Router Class Initialized
INFO - 2023-12-08 16:12:23 --> Output Class Initialized
INFO - 2023-12-08 16:12:23 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:23 --> Input Class Initialized
INFO - 2023-12-08 16:12:23 --> Language Class Initialized
INFO - 2023-12-08 16:12:23 --> Language Class Initialized
INFO - 2023-12-08 16:12:23 --> Config Class Initialized
INFO - 2023-12-08 16:12:23 --> Loader Class Initialized
INFO - 2023-12-08 16:12:23 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:23 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:23 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:23 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:23 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:23 --> Controller Class Initialized
DEBUG - 2023-12-08 16:12:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:12:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:23 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:23 --> Total execution time: 0.0609
INFO - 2023-12-08 16:12:23 --> Config Class Initialized
INFO - 2023-12-08 16:12:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:23 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:23 --> URI Class Initialized
INFO - 2023-12-08 16:12:23 --> Router Class Initialized
INFO - 2023-12-08 16:12:23 --> Output Class Initialized
INFO - 2023-12-08 16:12:23 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:23 --> Input Class Initialized
INFO - 2023-12-08 16:12:23 --> Language Class Initialized
INFO - 2023-12-08 16:12:23 --> Language Class Initialized
INFO - 2023-12-08 16:12:23 --> Config Class Initialized
INFO - 2023-12-08 16:12:23 --> Loader Class Initialized
INFO - 2023-12-08 16:12:23 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:23 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:23 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:23 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:24 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:24 --> Controller Class Initialized
INFO - 2023-12-08 16:12:25 --> Config Class Initialized
INFO - 2023-12-08 16:12:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:25 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:25 --> URI Class Initialized
INFO - 2023-12-08 16:12:25 --> Router Class Initialized
INFO - 2023-12-08 16:12:25 --> Output Class Initialized
INFO - 2023-12-08 16:12:25 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:25 --> Input Class Initialized
INFO - 2023-12-08 16:12:25 --> Language Class Initialized
INFO - 2023-12-08 16:12:25 --> Language Class Initialized
INFO - 2023-12-08 16:12:25 --> Config Class Initialized
INFO - 2023-12-08 16:12:25 --> Loader Class Initialized
INFO - 2023-12-08 16:12:25 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:25 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:25 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:25 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:25 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:25 --> Controller Class Initialized
INFO - 2023-12-08 16:12:25 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:25 --> Total execution time: 0.3119
INFO - 2023-12-08 16:12:35 --> Config Class Initialized
INFO - 2023-12-08 16:12:35 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:35 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:35 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:35 --> URI Class Initialized
INFO - 2023-12-08 16:12:35 --> Router Class Initialized
INFO - 2023-12-08 16:12:35 --> Output Class Initialized
INFO - 2023-12-08 16:12:35 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:35 --> Input Class Initialized
INFO - 2023-12-08 16:12:35 --> Language Class Initialized
INFO - 2023-12-08 16:12:35 --> Language Class Initialized
INFO - 2023-12-08 16:12:35 --> Config Class Initialized
INFO - 2023-12-08 16:12:35 --> Loader Class Initialized
INFO - 2023-12-08 16:12:35 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:35 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:35 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:35 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:35 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:35 --> Controller Class Initialized
DEBUG - 2023-12-08 16:12:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:12:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:35 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:35 --> Total execution time: 0.1703
INFO - 2023-12-08 16:12:40 --> Config Class Initialized
INFO - 2023-12-08 16:12:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:40 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:40 --> URI Class Initialized
INFO - 2023-12-08 16:12:40 --> Router Class Initialized
INFO - 2023-12-08 16:12:40 --> Output Class Initialized
INFO - 2023-12-08 16:12:40 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:40 --> Input Class Initialized
INFO - 2023-12-08 16:12:40 --> Language Class Initialized
INFO - 2023-12-08 16:12:40 --> Language Class Initialized
INFO - 2023-12-08 16:12:40 --> Config Class Initialized
INFO - 2023-12-08 16:12:40 --> Loader Class Initialized
INFO - 2023-12-08 16:12:40 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:40 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:40 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:40 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:40 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:40 --> Controller Class Initialized
INFO - 2023-12-08 16:12:41 --> Config Class Initialized
INFO - 2023-12-08 16:12:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:41 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:41 --> URI Class Initialized
INFO - 2023-12-08 16:12:41 --> Router Class Initialized
INFO - 2023-12-08 16:12:41 --> Output Class Initialized
INFO - 2023-12-08 16:12:41 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:41 --> Input Class Initialized
INFO - 2023-12-08 16:12:41 --> Language Class Initialized
INFO - 2023-12-08 16:12:41 --> Language Class Initialized
INFO - 2023-12-08 16:12:41 --> Config Class Initialized
INFO - 2023-12-08 16:12:41 --> Loader Class Initialized
INFO - 2023-12-08 16:12:41 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:41 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:41 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:41 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:41 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:41 --> Controller Class Initialized
DEBUG - 2023-12-08 16:12:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:12:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:41 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:41 --> Total execution time: 0.2888
INFO - 2023-12-08 16:12:41 --> Config Class Initialized
INFO - 2023-12-08 16:12:41 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:41 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:41 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:41 --> URI Class Initialized
INFO - 2023-12-08 16:12:41 --> Router Class Initialized
INFO - 2023-12-08 16:12:41 --> Output Class Initialized
INFO - 2023-12-08 16:12:41 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:41 --> Input Class Initialized
INFO - 2023-12-08 16:12:41 --> Language Class Initialized
INFO - 2023-12-08 16:12:41 --> Language Class Initialized
INFO - 2023-12-08 16:12:41 --> Config Class Initialized
INFO - 2023-12-08 16:12:41 --> Loader Class Initialized
INFO - 2023-12-08 16:12:41 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:41 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:41 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:41 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:41 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:41 --> Controller Class Initialized
INFO - 2023-12-08 16:12:44 --> Config Class Initialized
INFO - 2023-12-08 16:12:44 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:44 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:44 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:44 --> URI Class Initialized
INFO - 2023-12-08 16:12:44 --> Router Class Initialized
INFO - 2023-12-08 16:12:44 --> Output Class Initialized
INFO - 2023-12-08 16:12:44 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:44 --> Input Class Initialized
INFO - 2023-12-08 16:12:44 --> Language Class Initialized
INFO - 2023-12-08 16:12:44 --> Language Class Initialized
INFO - 2023-12-08 16:12:44 --> Config Class Initialized
INFO - 2023-12-08 16:12:44 --> Loader Class Initialized
INFO - 2023-12-08 16:12:44 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:44 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:44 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:44 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:44 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:44 --> Controller Class Initialized
INFO - 2023-12-08 16:12:44 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:44 --> Total execution time: 0.2219
INFO - 2023-12-08 16:12:52 --> Config Class Initialized
INFO - 2023-12-08 16:12:52 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:52 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:52 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:52 --> URI Class Initialized
INFO - 2023-12-08 16:12:52 --> Router Class Initialized
INFO - 2023-12-08 16:12:52 --> Output Class Initialized
INFO - 2023-12-08 16:12:52 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:52 --> Input Class Initialized
INFO - 2023-12-08 16:12:52 --> Language Class Initialized
INFO - 2023-12-08 16:12:52 --> Language Class Initialized
INFO - 2023-12-08 16:12:52 --> Config Class Initialized
INFO - 2023-12-08 16:12:52 --> Loader Class Initialized
INFO - 2023-12-08 16:12:52 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:52 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:52 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:52 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:52 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:52 --> Controller Class Initialized
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:12:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-08 16:12:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-08 16:12:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:52 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:52 --> Total execution time: 0.0838
INFO - 2023-12-08 16:12:56 --> Config Class Initialized
INFO - 2023-12-08 16:12:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:56 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:56 --> URI Class Initialized
INFO - 2023-12-08 16:12:56 --> Router Class Initialized
INFO - 2023-12-08 16:12:56 --> Output Class Initialized
INFO - 2023-12-08 16:12:56 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:56 --> Input Class Initialized
INFO - 2023-12-08 16:12:56 --> Language Class Initialized
INFO - 2023-12-08 16:12:56 --> Language Class Initialized
INFO - 2023-12-08 16:12:56 --> Config Class Initialized
INFO - 2023-12-08 16:12:56 --> Loader Class Initialized
INFO - 2023-12-08 16:12:56 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:56 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:56 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:56 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:56 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:56 --> Controller Class Initialized
DEBUG - 2023-12-08 16:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:12:56 --> Final output sent to browser
DEBUG - 2023-12-08 16:12:56 --> Total execution time: 0.0546
INFO - 2023-12-08 16:12:56 --> Config Class Initialized
INFO - 2023-12-08 16:12:56 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:56 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:56 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:56 --> URI Class Initialized
INFO - 2023-12-08 16:12:56 --> Router Class Initialized
INFO - 2023-12-08 16:12:56 --> Output Class Initialized
INFO - 2023-12-08 16:12:56 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:56 --> Input Class Initialized
INFO - 2023-12-08 16:12:56 --> Language Class Initialized
INFO - 2023-12-08 16:12:56 --> Language Class Initialized
INFO - 2023-12-08 16:12:56 --> Config Class Initialized
INFO - 2023-12-08 16:12:56 --> Loader Class Initialized
INFO - 2023-12-08 16:12:56 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:56 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:56 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:56 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:56 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:56 --> Controller Class Initialized
INFO - 2023-12-08 16:12:58 --> Config Class Initialized
INFO - 2023-12-08 16:12:58 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:12:58 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:12:58 --> Utf8 Class Initialized
INFO - 2023-12-08 16:12:58 --> URI Class Initialized
INFO - 2023-12-08 16:12:58 --> Router Class Initialized
INFO - 2023-12-08 16:12:58 --> Output Class Initialized
INFO - 2023-12-08 16:12:58 --> Security Class Initialized
DEBUG - 2023-12-08 16:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:12:58 --> Input Class Initialized
INFO - 2023-12-08 16:12:58 --> Language Class Initialized
INFO - 2023-12-08 16:12:58 --> Language Class Initialized
INFO - 2023-12-08 16:12:58 --> Config Class Initialized
INFO - 2023-12-08 16:12:58 --> Loader Class Initialized
INFO - 2023-12-08 16:12:58 --> Helper loaded: url_helper
INFO - 2023-12-08 16:12:58 --> Helper loaded: file_helper
INFO - 2023-12-08 16:12:58 --> Helper loaded: form_helper
INFO - 2023-12-08 16:12:58 --> Helper loaded: my_helper
INFO - 2023-12-08 16:12:58 --> Database Driver Class Initialized
INFO - 2023-12-08 16:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:12:58 --> Controller Class Initialized
INFO - 2023-12-08 16:15:12 --> Config Class Initialized
INFO - 2023-12-08 16:15:12 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:12 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:12 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:12 --> URI Class Initialized
INFO - 2023-12-08 16:15:12 --> Router Class Initialized
INFO - 2023-12-08 16:15:12 --> Output Class Initialized
INFO - 2023-12-08 16:15:12 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:12 --> Input Class Initialized
INFO - 2023-12-08 16:15:12 --> Language Class Initialized
INFO - 2023-12-08 16:15:12 --> Language Class Initialized
INFO - 2023-12-08 16:15:12 --> Config Class Initialized
INFO - 2023-12-08 16:15:12 --> Loader Class Initialized
INFO - 2023-12-08 16:15:12 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:12 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:12 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:12 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:12 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:12 --> Controller Class Initialized
DEBUG - 2023-12-08 16:15:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:15:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:15:12 --> Final output sent to browser
DEBUG - 2023-12-08 16:15:12 --> Total execution time: 0.1197
INFO - 2023-12-08 16:15:18 --> Config Class Initialized
INFO - 2023-12-08 16:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:18 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:18 --> URI Class Initialized
INFO - 2023-12-08 16:15:18 --> Router Class Initialized
INFO - 2023-12-08 16:15:18 --> Output Class Initialized
INFO - 2023-12-08 16:15:18 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:18 --> Input Class Initialized
INFO - 2023-12-08 16:15:18 --> Language Class Initialized
INFO - 2023-12-08 16:15:18 --> Language Class Initialized
INFO - 2023-12-08 16:15:18 --> Config Class Initialized
INFO - 2023-12-08 16:15:18 --> Loader Class Initialized
INFO - 2023-12-08 16:15:18 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:18 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:18 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:18 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:18 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:18 --> Controller Class Initialized
INFO - 2023-12-08 16:15:19 --> Config Class Initialized
INFO - 2023-12-08 16:15:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:19 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:19 --> URI Class Initialized
INFO - 2023-12-08 16:15:19 --> Router Class Initialized
INFO - 2023-12-08 16:15:19 --> Output Class Initialized
INFO - 2023-12-08 16:15:19 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:19 --> Input Class Initialized
INFO - 2023-12-08 16:15:19 --> Language Class Initialized
INFO - 2023-12-08 16:15:19 --> Language Class Initialized
INFO - 2023-12-08 16:15:19 --> Config Class Initialized
INFO - 2023-12-08 16:15:19 --> Loader Class Initialized
INFO - 2023-12-08 16:15:19 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:19 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:19 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:19 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:19 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:19 --> Controller Class Initialized
DEBUG - 2023-12-08 16:15:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:15:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:15:19 --> Final output sent to browser
DEBUG - 2023-12-08 16:15:19 --> Total execution time: 0.1109
INFO - 2023-12-08 16:15:19 --> Config Class Initialized
INFO - 2023-12-08 16:15:19 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:19 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:19 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:19 --> URI Class Initialized
INFO - 2023-12-08 16:15:19 --> Router Class Initialized
INFO - 2023-12-08 16:15:19 --> Output Class Initialized
INFO - 2023-12-08 16:15:19 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:19 --> Input Class Initialized
INFO - 2023-12-08 16:15:19 --> Language Class Initialized
INFO - 2023-12-08 16:15:19 --> Language Class Initialized
INFO - 2023-12-08 16:15:19 --> Config Class Initialized
INFO - 2023-12-08 16:15:19 --> Loader Class Initialized
INFO - 2023-12-08 16:15:19 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:19 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:19 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:19 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:19 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:19 --> Controller Class Initialized
INFO - 2023-12-08 16:15:21 --> Config Class Initialized
INFO - 2023-12-08 16:15:21 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:21 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:21 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:21 --> URI Class Initialized
INFO - 2023-12-08 16:15:21 --> Router Class Initialized
INFO - 2023-12-08 16:15:21 --> Output Class Initialized
INFO - 2023-12-08 16:15:21 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:21 --> Input Class Initialized
INFO - 2023-12-08 16:15:21 --> Language Class Initialized
INFO - 2023-12-08 16:15:21 --> Language Class Initialized
INFO - 2023-12-08 16:15:21 --> Config Class Initialized
INFO - 2023-12-08 16:15:21 --> Loader Class Initialized
INFO - 2023-12-08 16:15:21 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:21 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:21 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:21 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:21 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:21 --> Controller Class Initialized
INFO - 2023-12-08 16:15:21 --> Final output sent to browser
DEBUG - 2023-12-08 16:15:21 --> Total execution time: 0.2537
INFO - 2023-12-08 16:15:25 --> Config Class Initialized
INFO - 2023-12-08 16:15:25 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:25 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:25 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:25 --> URI Class Initialized
INFO - 2023-12-08 16:15:25 --> Router Class Initialized
INFO - 2023-12-08 16:15:25 --> Output Class Initialized
INFO - 2023-12-08 16:15:25 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:25 --> Input Class Initialized
INFO - 2023-12-08 16:15:25 --> Language Class Initialized
INFO - 2023-12-08 16:15:25 --> Language Class Initialized
INFO - 2023-12-08 16:15:25 --> Config Class Initialized
INFO - 2023-12-08 16:15:25 --> Loader Class Initialized
INFO - 2023-12-08 16:15:25 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:25 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:25 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:25 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:25 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:25 --> Controller Class Initialized
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-08 16:15:25 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-08 16:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-08 16:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:15:25 --> Final output sent to browser
DEBUG - 2023-12-08 16:15:25 --> Total execution time: 0.0478
INFO - 2023-12-08 16:15:28 --> Config Class Initialized
INFO - 2023-12-08 16:15:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:28 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:28 --> URI Class Initialized
INFO - 2023-12-08 16:15:28 --> Router Class Initialized
INFO - 2023-12-08 16:15:28 --> Output Class Initialized
INFO - 2023-12-08 16:15:28 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:28 --> Input Class Initialized
INFO - 2023-12-08 16:15:28 --> Language Class Initialized
INFO - 2023-12-08 16:15:28 --> Language Class Initialized
INFO - 2023-12-08 16:15:28 --> Config Class Initialized
INFO - 2023-12-08 16:15:28 --> Loader Class Initialized
INFO - 2023-12-08 16:15:28 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:28 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:28 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:28 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:28 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:28 --> Controller Class Initialized
DEBUG - 2023-12-08 16:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:15:28 --> Final output sent to browser
DEBUG - 2023-12-08 16:15:28 --> Total execution time: 0.0373
INFO - 2023-12-08 16:15:28 --> Config Class Initialized
INFO - 2023-12-08 16:15:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:28 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:28 --> URI Class Initialized
INFO - 2023-12-08 16:15:28 --> Router Class Initialized
INFO - 2023-12-08 16:15:28 --> Output Class Initialized
INFO - 2023-12-08 16:15:28 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:28 --> Input Class Initialized
INFO - 2023-12-08 16:15:28 --> Language Class Initialized
INFO - 2023-12-08 16:15:28 --> Language Class Initialized
INFO - 2023-12-08 16:15:28 --> Config Class Initialized
INFO - 2023-12-08 16:15:28 --> Loader Class Initialized
INFO - 2023-12-08 16:15:28 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:28 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:28 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:28 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:28 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:28 --> Controller Class Initialized
INFO - 2023-12-08 16:15:30 --> Config Class Initialized
INFO - 2023-12-08 16:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:15:30 --> Utf8 Class Initialized
INFO - 2023-12-08 16:15:30 --> URI Class Initialized
INFO - 2023-12-08 16:15:30 --> Router Class Initialized
INFO - 2023-12-08 16:15:30 --> Output Class Initialized
INFO - 2023-12-08 16:15:30 --> Security Class Initialized
DEBUG - 2023-12-08 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:15:30 --> Input Class Initialized
INFO - 2023-12-08 16:15:30 --> Language Class Initialized
INFO - 2023-12-08 16:15:30 --> Language Class Initialized
INFO - 2023-12-08 16:15:30 --> Config Class Initialized
INFO - 2023-12-08 16:15:30 --> Loader Class Initialized
INFO - 2023-12-08 16:15:30 --> Helper loaded: url_helper
INFO - 2023-12-08 16:15:30 --> Helper loaded: file_helper
INFO - 2023-12-08 16:15:30 --> Helper loaded: form_helper
INFO - 2023-12-08 16:15:30 --> Helper loaded: my_helper
INFO - 2023-12-08 16:15:30 --> Database Driver Class Initialized
INFO - 2023-12-08 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:15:30 --> Controller Class Initialized
INFO - 2023-12-08 16:17:24 --> Config Class Initialized
INFO - 2023-12-08 16:17:24 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:17:24 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:17:24 --> Utf8 Class Initialized
INFO - 2023-12-08 16:17:24 --> URI Class Initialized
INFO - 2023-12-08 16:17:24 --> Router Class Initialized
INFO - 2023-12-08 16:17:24 --> Output Class Initialized
INFO - 2023-12-08 16:17:24 --> Security Class Initialized
DEBUG - 2023-12-08 16:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:17:24 --> Input Class Initialized
INFO - 2023-12-08 16:17:24 --> Language Class Initialized
INFO - 2023-12-08 16:17:24 --> Language Class Initialized
INFO - 2023-12-08 16:17:24 --> Config Class Initialized
INFO - 2023-12-08 16:17:24 --> Loader Class Initialized
INFO - 2023-12-08 16:17:24 --> Helper loaded: url_helper
INFO - 2023-12-08 16:17:24 --> Helper loaded: file_helper
INFO - 2023-12-08 16:17:24 --> Helper loaded: form_helper
INFO - 2023-12-08 16:17:24 --> Helper loaded: my_helper
INFO - 2023-12-08 16:17:24 --> Database Driver Class Initialized
INFO - 2023-12-08 16:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:17:24 --> Controller Class Initialized
DEBUG - 2023-12-08 16:17:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/form.php
DEBUG - 2023-12-08 16:17:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:17:24 --> Final output sent to browser
DEBUG - 2023-12-08 16:17:24 --> Total execution time: 0.2442
INFO - 2023-12-08 16:17:29 --> Config Class Initialized
INFO - 2023-12-08 16:17:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:17:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:17:29 --> Utf8 Class Initialized
INFO - 2023-12-08 16:17:29 --> URI Class Initialized
INFO - 2023-12-08 16:17:29 --> Router Class Initialized
INFO - 2023-12-08 16:17:29 --> Output Class Initialized
INFO - 2023-12-08 16:17:29 --> Security Class Initialized
DEBUG - 2023-12-08 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:17:29 --> Input Class Initialized
INFO - 2023-12-08 16:17:29 --> Language Class Initialized
INFO - 2023-12-08 16:17:29 --> Language Class Initialized
INFO - 2023-12-08 16:17:29 --> Config Class Initialized
INFO - 2023-12-08 16:17:29 --> Loader Class Initialized
INFO - 2023-12-08 16:17:29 --> Helper loaded: url_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: file_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: form_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: my_helper
INFO - 2023-12-08 16:17:29 --> Database Driver Class Initialized
INFO - 2023-12-08 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:17:29 --> Controller Class Initialized
INFO - 2023-12-08 16:17:29 --> Config Class Initialized
INFO - 2023-12-08 16:17:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:17:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:17:29 --> Utf8 Class Initialized
INFO - 2023-12-08 16:17:29 --> URI Class Initialized
INFO - 2023-12-08 16:17:29 --> Router Class Initialized
INFO - 2023-12-08 16:17:29 --> Output Class Initialized
INFO - 2023-12-08 16:17:29 --> Security Class Initialized
DEBUG - 2023-12-08 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:17:29 --> Input Class Initialized
INFO - 2023-12-08 16:17:29 --> Language Class Initialized
INFO - 2023-12-08 16:17:29 --> Language Class Initialized
INFO - 2023-12-08 16:17:29 --> Config Class Initialized
INFO - 2023-12-08 16:17:29 --> Loader Class Initialized
INFO - 2023-12-08 16:17:29 --> Helper loaded: url_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: file_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: form_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: my_helper
INFO - 2023-12-08 16:17:29 --> Database Driver Class Initialized
INFO - 2023-12-08 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:17:29 --> Controller Class Initialized
DEBUG - 2023-12-08 16:17:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-08 16:17:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:17:29 --> Final output sent to browser
DEBUG - 2023-12-08 16:17:29 --> Total execution time: 0.0754
INFO - 2023-12-08 16:17:29 --> Config Class Initialized
INFO - 2023-12-08 16:17:29 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:17:29 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:17:29 --> Utf8 Class Initialized
INFO - 2023-12-08 16:17:29 --> URI Class Initialized
INFO - 2023-12-08 16:17:29 --> Router Class Initialized
INFO - 2023-12-08 16:17:29 --> Output Class Initialized
INFO - 2023-12-08 16:17:29 --> Security Class Initialized
DEBUG - 2023-12-08 16:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:17:29 --> Input Class Initialized
INFO - 2023-12-08 16:17:29 --> Language Class Initialized
INFO - 2023-12-08 16:17:29 --> Language Class Initialized
INFO - 2023-12-08 16:17:29 --> Config Class Initialized
INFO - 2023-12-08 16:17:29 --> Loader Class Initialized
INFO - 2023-12-08 16:17:29 --> Helper loaded: url_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: file_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: form_helper
INFO - 2023-12-08 16:17:29 --> Helper loaded: my_helper
INFO - 2023-12-08 16:17:29 --> Database Driver Class Initialized
INFO - 2023-12-08 16:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:17:29 --> Controller Class Initialized
INFO - 2023-12-08 16:17:36 --> Config Class Initialized
INFO - 2023-12-08 16:17:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:17:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:17:36 --> Utf8 Class Initialized
INFO - 2023-12-08 16:17:36 --> URI Class Initialized
INFO - 2023-12-08 16:17:36 --> Router Class Initialized
INFO - 2023-12-08 16:17:36 --> Output Class Initialized
INFO - 2023-12-08 16:17:36 --> Security Class Initialized
DEBUG - 2023-12-08 16:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:17:36 --> Input Class Initialized
INFO - 2023-12-08 16:17:36 --> Language Class Initialized
INFO - 2023-12-08 16:17:36 --> Language Class Initialized
INFO - 2023-12-08 16:17:36 --> Config Class Initialized
INFO - 2023-12-08 16:17:36 --> Loader Class Initialized
INFO - 2023-12-08 16:17:36 --> Helper loaded: url_helper
INFO - 2023-12-08 16:17:36 --> Helper loaded: file_helper
INFO - 2023-12-08 16:17:36 --> Helper loaded: form_helper
INFO - 2023-12-08 16:17:36 --> Helper loaded: my_helper
INFO - 2023-12-08 16:17:36 --> Database Driver Class Initialized
INFO - 2023-12-08 16:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:17:36 --> Controller Class Initialized
DEBUG - 2023-12-08 16:17:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_projek/views/list.php
DEBUG - 2023-12-08 16:17:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:17:37 --> Final output sent to browser
DEBUG - 2023-12-08 16:17:37 --> Total execution time: 0.6020
INFO - 2023-12-08 16:17:38 --> Config Class Initialized
INFO - 2023-12-08 16:17:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:17:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:17:38 --> Utf8 Class Initialized
INFO - 2023-12-08 16:17:38 --> URI Class Initialized
INFO - 2023-12-08 16:17:38 --> Router Class Initialized
INFO - 2023-12-08 16:17:38 --> Output Class Initialized
INFO - 2023-12-08 16:17:38 --> Security Class Initialized
DEBUG - 2023-12-08 16:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:17:38 --> Input Class Initialized
INFO - 2023-12-08 16:17:38 --> Language Class Initialized
INFO - 2023-12-08 16:17:38 --> Language Class Initialized
INFO - 2023-12-08 16:17:38 --> Config Class Initialized
INFO - 2023-12-08 16:17:38 --> Loader Class Initialized
INFO - 2023-12-08 16:17:38 --> Helper loaded: url_helper
INFO - 2023-12-08 16:17:38 --> Helper loaded: file_helper
INFO - 2023-12-08 16:17:38 --> Helper loaded: form_helper
INFO - 2023-12-08 16:17:38 --> Helper loaded: my_helper
INFO - 2023-12-08 16:17:38 --> Database Driver Class Initialized
INFO - 2023-12-08 16:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:17:39 --> Controller Class Initialized
DEBUG - 2023-12-08 16:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kelompok/views/list.php
DEBUG - 2023-12-08 16:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:17:39 --> Final output sent to browser
DEBUG - 2023-12-08 16:17:39 --> Total execution time: 0.2157
INFO - 2023-12-08 16:19:30 --> Config Class Initialized
INFO - 2023-12-08 16:19:30 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:19:30 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:19:30 --> Utf8 Class Initialized
INFO - 2023-12-08 16:19:30 --> URI Class Initialized
INFO - 2023-12-08 16:19:30 --> Router Class Initialized
INFO - 2023-12-08 16:19:30 --> Output Class Initialized
INFO - 2023-12-08 16:19:30 --> Security Class Initialized
DEBUG - 2023-12-08 16:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:19:30 --> Input Class Initialized
INFO - 2023-12-08 16:19:30 --> Language Class Initialized
INFO - 2023-12-08 16:19:30 --> Language Class Initialized
INFO - 2023-12-08 16:19:30 --> Config Class Initialized
INFO - 2023-12-08 16:19:30 --> Loader Class Initialized
INFO - 2023-12-08 16:19:30 --> Helper loaded: url_helper
INFO - 2023-12-08 16:19:30 --> Helper loaded: file_helper
INFO - 2023-12-08 16:19:30 --> Helper loaded: form_helper
INFO - 2023-12-08 16:19:30 --> Helper loaded: my_helper
INFO - 2023-12-08 16:19:30 --> Database Driver Class Initialized
INFO - 2023-12-08 16:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:19:30 --> Controller Class Initialized
DEBUG - 2023-12-08 16:19:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 16:19:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:19:30 --> Final output sent to browser
DEBUG - 2023-12-08 16:19:30 --> Total execution time: 0.0839
INFO - 2023-12-08 16:19:31 --> Config Class Initialized
INFO - 2023-12-08 16:19:31 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:19:31 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:19:31 --> Utf8 Class Initialized
INFO - 2023-12-08 16:19:31 --> URI Class Initialized
INFO - 2023-12-08 16:19:31 --> Router Class Initialized
INFO - 2023-12-08 16:19:31 --> Output Class Initialized
INFO - 2023-12-08 16:19:31 --> Security Class Initialized
DEBUG - 2023-12-08 16:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:19:31 --> Input Class Initialized
INFO - 2023-12-08 16:19:31 --> Language Class Initialized
INFO - 2023-12-08 16:19:31 --> Language Class Initialized
INFO - 2023-12-08 16:19:31 --> Config Class Initialized
INFO - 2023-12-08 16:19:31 --> Loader Class Initialized
INFO - 2023-12-08 16:19:31 --> Helper loaded: url_helper
INFO - 2023-12-08 16:19:31 --> Helper loaded: file_helper
INFO - 2023-12-08 16:19:31 --> Helper loaded: form_helper
INFO - 2023-12-08 16:19:31 --> Helper loaded: my_helper
INFO - 2023-12-08 16:19:31 --> Database Driver Class Initialized
INFO - 2023-12-08 16:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:19:31 --> Controller Class Initialized
INFO - 2023-12-08 16:19:33 --> Config Class Initialized
INFO - 2023-12-08 16:19:33 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:19:33 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:19:33 --> Utf8 Class Initialized
INFO - 2023-12-08 16:19:33 --> URI Class Initialized
INFO - 2023-12-08 16:19:33 --> Router Class Initialized
INFO - 2023-12-08 16:19:33 --> Output Class Initialized
INFO - 2023-12-08 16:19:33 --> Security Class Initialized
DEBUG - 2023-12-08 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:19:33 --> Input Class Initialized
INFO - 2023-12-08 16:19:33 --> Language Class Initialized
INFO - 2023-12-08 16:19:33 --> Language Class Initialized
INFO - 2023-12-08 16:19:33 --> Config Class Initialized
INFO - 2023-12-08 16:19:33 --> Loader Class Initialized
INFO - 2023-12-08 16:19:33 --> Helper loaded: url_helper
INFO - 2023-12-08 16:19:33 --> Helper loaded: file_helper
INFO - 2023-12-08 16:19:33 --> Helper loaded: form_helper
INFO - 2023-12-08 16:19:33 --> Helper loaded: my_helper
INFO - 2023-12-08 16:19:33 --> Database Driver Class Initialized
INFO - 2023-12-08 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:19:33 --> Controller Class Initialized
DEBUG - 2023-12-08 16:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:19:33 --> Final output sent to browser
DEBUG - 2023-12-08 16:19:33 --> Total execution time: 0.0766
INFO - 2023-12-08 16:19:36 --> Config Class Initialized
INFO - 2023-12-08 16:19:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:19:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:19:36 --> Utf8 Class Initialized
INFO - 2023-12-08 16:19:36 --> URI Class Initialized
INFO - 2023-12-08 16:19:36 --> Router Class Initialized
INFO - 2023-12-08 16:19:36 --> Output Class Initialized
INFO - 2023-12-08 16:19:36 --> Security Class Initialized
DEBUG - 2023-12-08 16:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:19:36 --> Input Class Initialized
INFO - 2023-12-08 16:19:36 --> Language Class Initialized
INFO - 2023-12-08 16:19:36 --> Language Class Initialized
INFO - 2023-12-08 16:19:36 --> Config Class Initialized
INFO - 2023-12-08 16:19:36 --> Loader Class Initialized
INFO - 2023-12-08 16:19:36 --> Helper loaded: url_helper
INFO - 2023-12-08 16:19:36 --> Helper loaded: file_helper
INFO - 2023-12-08 16:19:36 --> Helper loaded: form_helper
INFO - 2023-12-08 16:19:36 --> Helper loaded: my_helper
INFO - 2023-12-08 16:19:36 --> Database Driver Class Initialized
INFO - 2023-12-08 16:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:19:36 --> Controller Class Initialized
DEBUG - 2023-12-08 16:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 16:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:19:36 --> Final output sent to browser
DEBUG - 2023-12-08 16:19:36 --> Total execution time: 0.0659
INFO - 2023-12-08 16:19:36 --> Config Class Initialized
INFO - 2023-12-08 16:19:36 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:19:36 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:19:36 --> Utf8 Class Initialized
INFO - 2023-12-08 16:19:36 --> URI Class Initialized
INFO - 2023-12-08 16:19:36 --> Router Class Initialized
INFO - 2023-12-08 16:19:36 --> Output Class Initialized
INFO - 2023-12-08 16:19:36 --> Security Class Initialized
DEBUG - 2023-12-08 16:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:19:36 --> Input Class Initialized
INFO - 2023-12-08 16:19:36 --> Language Class Initialized
INFO - 2023-12-08 16:19:36 --> Language Class Initialized
INFO - 2023-12-08 16:19:36 --> Config Class Initialized
INFO - 2023-12-08 16:19:36 --> Loader Class Initialized
INFO - 2023-12-08 16:19:36 --> Helper loaded: url_helper
INFO - 2023-12-08 16:19:36 --> Helper loaded: file_helper
INFO - 2023-12-08 16:19:36 --> Helper loaded: form_helper
INFO - 2023-12-08 16:19:36 --> Helper loaded: my_helper
INFO - 2023-12-08 16:19:36 --> Database Driver Class Initialized
INFO - 2023-12-08 16:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:19:36 --> Controller Class Initialized
INFO - 2023-12-08 16:23:30 --> Config Class Initialized
INFO - 2023-12-08 16:23:30 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:30 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:30 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:30 --> URI Class Initialized
INFO - 2023-12-08 16:23:30 --> Router Class Initialized
INFO - 2023-12-08 16:23:30 --> Output Class Initialized
INFO - 2023-12-08 16:23:30 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:30 --> Input Class Initialized
INFO - 2023-12-08 16:23:30 --> Language Class Initialized
INFO - 2023-12-08 16:23:30 --> Language Class Initialized
INFO - 2023-12-08 16:23:30 --> Config Class Initialized
INFO - 2023-12-08 16:23:30 --> Loader Class Initialized
INFO - 2023-12-08 16:23:30 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:30 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:30 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:30 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:30 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:31 --> Controller Class Initialized
INFO - 2023-12-08 16:23:31 --> Final output sent to browser
DEBUG - 2023-12-08 16:23:31 --> Total execution time: 1.2167
INFO - 2023-12-08 16:23:35 --> Config Class Initialized
INFO - 2023-12-08 16:23:35 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:35 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:35 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:35 --> URI Class Initialized
INFO - 2023-12-08 16:23:35 --> Router Class Initialized
INFO - 2023-12-08 16:23:35 --> Output Class Initialized
INFO - 2023-12-08 16:23:35 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:35 --> Input Class Initialized
INFO - 2023-12-08 16:23:35 --> Language Class Initialized
INFO - 2023-12-08 16:23:35 --> Language Class Initialized
INFO - 2023-12-08 16:23:35 --> Config Class Initialized
INFO - 2023-12-08 16:23:35 --> Loader Class Initialized
INFO - 2023-12-08 16:23:35 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:35 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:35 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:35 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:35 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:35 --> Controller Class Initialized
DEBUG - 2023-12-08 16:23:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 16:23:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:23:35 --> Final output sent to browser
DEBUG - 2023-12-08 16:23:35 --> Total execution time: 0.0645
INFO - 2023-12-08 16:23:40 --> Config Class Initialized
INFO - 2023-12-08 16:23:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:40 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:40 --> URI Class Initialized
DEBUG - 2023-12-08 16:23:40 --> No URI present. Default controller set.
INFO - 2023-12-08 16:23:40 --> Router Class Initialized
INFO - 2023-12-08 16:23:40 --> Output Class Initialized
INFO - 2023-12-08 16:23:40 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:40 --> Input Class Initialized
INFO - 2023-12-08 16:23:40 --> Language Class Initialized
INFO - 2023-12-08 16:23:40 --> Language Class Initialized
INFO - 2023-12-08 16:23:40 --> Config Class Initialized
INFO - 2023-12-08 16:23:40 --> Loader Class Initialized
INFO - 2023-12-08 16:23:40 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:40 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:40 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:40 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:40 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:40 --> Controller Class Initialized
INFO - 2023-12-08 16:23:40 --> Config Class Initialized
INFO - 2023-12-08 16:23:40 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:40 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:40 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:40 --> URI Class Initialized
INFO - 2023-12-08 16:23:40 --> Router Class Initialized
INFO - 2023-12-08 16:23:40 --> Output Class Initialized
INFO - 2023-12-08 16:23:40 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:40 --> Input Class Initialized
INFO - 2023-12-08 16:23:40 --> Language Class Initialized
INFO - 2023-12-08 16:23:40 --> Language Class Initialized
INFO - 2023-12-08 16:23:40 --> Config Class Initialized
INFO - 2023-12-08 16:23:40 --> Loader Class Initialized
INFO - 2023-12-08 16:23:40 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:40 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:40 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:40 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:40 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:40 --> Controller Class Initialized
DEBUG - 2023-12-08 16:23:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 16:23:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:23:40 --> Final output sent to browser
DEBUG - 2023-12-08 16:23:40 --> Total execution time: 0.0434
INFO - 2023-12-08 16:23:53 --> Config Class Initialized
INFO - 2023-12-08 16:23:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:53 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:53 --> URI Class Initialized
INFO - 2023-12-08 16:23:53 --> Router Class Initialized
INFO - 2023-12-08 16:23:53 --> Output Class Initialized
INFO - 2023-12-08 16:23:53 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:53 --> Input Class Initialized
INFO - 2023-12-08 16:23:53 --> Language Class Initialized
INFO - 2023-12-08 16:23:53 --> Language Class Initialized
INFO - 2023-12-08 16:23:53 --> Config Class Initialized
INFO - 2023-12-08 16:23:53 --> Loader Class Initialized
INFO - 2023-12-08 16:23:53 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:53 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:53 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:53 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:53 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:53 --> Controller Class Initialized
INFO - 2023-12-08 16:23:53 --> Helper loaded: cookie_helper
INFO - 2023-12-08 16:23:53 --> Final output sent to browser
DEBUG - 2023-12-08 16:23:53 --> Total execution time: 0.0954
INFO - 2023-12-08 16:23:53 --> Config Class Initialized
INFO - 2023-12-08 16:23:53 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:53 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:53 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:53 --> URI Class Initialized
INFO - 2023-12-08 16:23:53 --> Router Class Initialized
INFO - 2023-12-08 16:23:53 --> Output Class Initialized
INFO - 2023-12-08 16:23:53 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:53 --> Input Class Initialized
INFO - 2023-12-08 16:23:53 --> Language Class Initialized
INFO - 2023-12-08 16:23:53 --> Language Class Initialized
INFO - 2023-12-08 16:23:53 --> Config Class Initialized
INFO - 2023-12-08 16:23:53 --> Loader Class Initialized
INFO - 2023-12-08 16:23:53 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:53 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:53 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:53 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:53 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:53 --> Controller Class Initialized
DEBUG - 2023-12-08 16:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 16:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:23:53 --> Final output sent to browser
DEBUG - 2023-12-08 16:23:53 --> Total execution time: 0.0494
INFO - 2023-12-08 16:23:59 --> Config Class Initialized
INFO - 2023-12-08 16:23:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:23:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:23:59 --> Utf8 Class Initialized
INFO - 2023-12-08 16:23:59 --> URI Class Initialized
INFO - 2023-12-08 16:23:59 --> Router Class Initialized
INFO - 2023-12-08 16:23:59 --> Output Class Initialized
INFO - 2023-12-08 16:23:59 --> Security Class Initialized
DEBUG - 2023-12-08 16:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:23:59 --> Input Class Initialized
INFO - 2023-12-08 16:23:59 --> Language Class Initialized
INFO - 2023-12-08 16:23:59 --> Language Class Initialized
INFO - 2023-12-08 16:23:59 --> Config Class Initialized
INFO - 2023-12-08 16:23:59 --> Loader Class Initialized
INFO - 2023-12-08 16:23:59 --> Helper loaded: url_helper
INFO - 2023-12-08 16:23:59 --> Helper loaded: file_helper
INFO - 2023-12-08 16:23:59 --> Helper loaded: form_helper
INFO - 2023-12-08 16:23:59 --> Helper loaded: my_helper
INFO - 2023-12-08 16:23:59 --> Database Driver Class Initialized
INFO - 2023-12-08 16:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:23:59 --> Controller Class Initialized
DEBUG - 2023-12-08 16:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:23:59 --> Final output sent to browser
DEBUG - 2023-12-08 16:23:59 --> Total execution time: 0.1093
INFO - 2023-12-08 16:26:58 --> Config Class Initialized
INFO - 2023-12-08 16:26:58 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:26:58 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:26:58 --> Utf8 Class Initialized
INFO - 2023-12-08 16:26:58 --> URI Class Initialized
INFO - 2023-12-08 16:26:58 --> Router Class Initialized
INFO - 2023-12-08 16:26:58 --> Output Class Initialized
INFO - 2023-12-08 16:26:58 --> Security Class Initialized
DEBUG - 2023-12-08 16:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:26:58 --> Input Class Initialized
INFO - 2023-12-08 16:26:58 --> Language Class Initialized
INFO - 2023-12-08 16:26:58 --> Language Class Initialized
INFO - 2023-12-08 16:26:58 --> Config Class Initialized
INFO - 2023-12-08 16:26:58 --> Loader Class Initialized
INFO - 2023-12-08 16:26:58 --> Helper loaded: url_helper
INFO - 2023-12-08 16:26:58 --> Helper loaded: file_helper
INFO - 2023-12-08 16:26:58 --> Helper loaded: form_helper
INFO - 2023-12-08 16:26:58 --> Helper loaded: my_helper
INFO - 2023-12-08 16:26:58 --> Database Driver Class Initialized
INFO - 2023-12-08 16:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:26:58 --> Controller Class Initialized
DEBUG - 2023-12-08 16:26:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-12-08 16:26:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:26:58 --> Final output sent to browser
DEBUG - 2023-12-08 16:26:58 --> Total execution time: 0.0985
INFO - 2023-12-08 16:26:59 --> Config Class Initialized
INFO - 2023-12-08 16:26:59 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:26:59 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:26:59 --> Utf8 Class Initialized
INFO - 2023-12-08 16:26:59 --> URI Class Initialized
INFO - 2023-12-08 16:26:59 --> Router Class Initialized
INFO - 2023-12-08 16:26:59 --> Output Class Initialized
INFO - 2023-12-08 16:26:59 --> Security Class Initialized
DEBUG - 2023-12-08 16:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:26:59 --> Input Class Initialized
INFO - 2023-12-08 16:26:59 --> Language Class Initialized
INFO - 2023-12-08 16:26:59 --> Language Class Initialized
INFO - 2023-12-08 16:26:59 --> Config Class Initialized
INFO - 2023-12-08 16:26:59 --> Loader Class Initialized
INFO - 2023-12-08 16:26:59 --> Helper loaded: url_helper
INFO - 2023-12-08 16:26:59 --> Helper loaded: file_helper
INFO - 2023-12-08 16:26:59 --> Helper loaded: form_helper
INFO - 2023-12-08 16:26:59 --> Helper loaded: my_helper
INFO - 2023-12-08 16:26:59 --> Database Driver Class Initialized
INFO - 2023-12-08 16:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:26:59 --> Controller Class Initialized
INFO - 2023-12-08 16:27:02 --> Config Class Initialized
INFO - 2023-12-08 16:27:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:02 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:02 --> URI Class Initialized
INFO - 2023-12-08 16:27:02 --> Router Class Initialized
INFO - 2023-12-08 16:27:02 --> Output Class Initialized
INFO - 2023-12-08 16:27:02 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:02 --> Input Class Initialized
INFO - 2023-12-08 16:27:02 --> Language Class Initialized
INFO - 2023-12-08 16:27:02 --> Language Class Initialized
INFO - 2023-12-08 16:27:02 --> Config Class Initialized
INFO - 2023-12-08 16:27:02 --> Loader Class Initialized
INFO - 2023-12-08 16:27:02 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:02 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:02 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:02 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:02 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:02 --> Controller Class Initialized
INFO - 2023-12-08 16:27:02 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:02 --> Total execution time: 0.3774
INFO - 2023-12-08 16:27:18 --> Config Class Initialized
INFO - 2023-12-08 16:27:18 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:18 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:18 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:18 --> URI Class Initialized
INFO - 2023-12-08 16:27:18 --> Router Class Initialized
INFO - 2023-12-08 16:27:18 --> Output Class Initialized
INFO - 2023-12-08 16:27:18 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:18 --> Input Class Initialized
INFO - 2023-12-08 16:27:18 --> Language Class Initialized
INFO - 2023-12-08 16:27:18 --> Language Class Initialized
INFO - 2023-12-08 16:27:18 --> Config Class Initialized
INFO - 2023-12-08 16:27:18 --> Loader Class Initialized
INFO - 2023-12-08 16:27:18 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:18 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:18 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:18 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:18 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:18 --> Controller Class Initialized
DEBUG - 2023-12-08 16:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:27:18 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:18 --> Total execution time: 0.0729
INFO - 2023-12-08 16:27:20 --> Config Class Initialized
INFO - 2023-12-08 16:27:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:20 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:20 --> URI Class Initialized
INFO - 2023-12-08 16:27:20 --> Router Class Initialized
INFO - 2023-12-08 16:27:20 --> Output Class Initialized
INFO - 2023-12-08 16:27:20 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:20 --> Input Class Initialized
INFO - 2023-12-08 16:27:20 --> Language Class Initialized
INFO - 2023-12-08 16:27:20 --> Language Class Initialized
INFO - 2023-12-08 16:27:20 --> Config Class Initialized
INFO - 2023-12-08 16:27:20 --> Loader Class Initialized
INFO - 2023-12-08 16:27:20 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:20 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:20 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:20 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:20 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:20 --> Controller Class Initialized
DEBUG - 2023-12-08 16:27:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2023-12-08 16:27:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:27:20 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:20 --> Total execution time: 0.1368
INFO - 2023-12-08 16:27:20 --> Config Class Initialized
INFO - 2023-12-08 16:27:20 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:20 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:20 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:20 --> URI Class Initialized
INFO - 2023-12-08 16:27:20 --> Router Class Initialized
INFO - 2023-12-08 16:27:20 --> Output Class Initialized
INFO - 2023-12-08 16:27:20 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:20 --> Input Class Initialized
INFO - 2023-12-08 16:27:20 --> Language Class Initialized
INFO - 2023-12-08 16:27:20 --> Language Class Initialized
INFO - 2023-12-08 16:27:20 --> Config Class Initialized
INFO - 2023-12-08 16:27:20 --> Loader Class Initialized
INFO - 2023-12-08 16:27:20 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:20 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:20 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:20 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:21 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:21 --> Controller Class Initialized
INFO - 2023-12-08 16:27:23 --> Config Class Initialized
INFO - 2023-12-08 16:27:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:23 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:23 --> URI Class Initialized
INFO - 2023-12-08 16:27:23 --> Router Class Initialized
INFO - 2023-12-08 16:27:23 --> Output Class Initialized
INFO - 2023-12-08 16:27:23 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:23 --> Input Class Initialized
INFO - 2023-12-08 16:27:23 --> Language Class Initialized
INFO - 2023-12-08 16:27:23 --> Language Class Initialized
INFO - 2023-12-08 16:27:23 --> Config Class Initialized
INFO - 2023-12-08 16:27:23 --> Loader Class Initialized
INFO - 2023-12-08 16:27:23 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:23 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:23 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:23 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:23 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:23 --> Controller Class Initialized
INFO - 2023-12-08 16:27:23 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:23 --> Total execution time: 0.0950
INFO - 2023-12-08 16:27:28 --> Config Class Initialized
INFO - 2023-12-08 16:27:28 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:28 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:28 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:28 --> URI Class Initialized
INFO - 2023-12-08 16:27:28 --> Router Class Initialized
INFO - 2023-12-08 16:27:28 --> Output Class Initialized
INFO - 2023-12-08 16:27:28 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:28 --> Input Class Initialized
INFO - 2023-12-08 16:27:28 --> Language Class Initialized
INFO - 2023-12-08 16:27:28 --> Language Class Initialized
INFO - 2023-12-08 16:27:28 --> Config Class Initialized
INFO - 2023-12-08 16:27:28 --> Loader Class Initialized
INFO - 2023-12-08 16:27:28 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:28 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:28 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:28 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:28 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:28 --> Controller Class Initialized
DEBUG - 2023-12-08 16:27:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:27:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:27:28 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:28 --> Total execution time: 0.0349
INFO - 2023-12-08 16:27:33 --> Config Class Initialized
INFO - 2023-12-08 16:27:33 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:33 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:33 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:33 --> URI Class Initialized
INFO - 2023-12-08 16:27:33 --> Router Class Initialized
INFO - 2023-12-08 16:27:33 --> Output Class Initialized
INFO - 2023-12-08 16:27:33 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:33 --> Input Class Initialized
INFO - 2023-12-08 16:27:33 --> Language Class Initialized
INFO - 2023-12-08 16:27:33 --> Language Class Initialized
INFO - 2023-12-08 16:27:33 --> Config Class Initialized
INFO - 2023-12-08 16:27:33 --> Loader Class Initialized
INFO - 2023-12-08 16:27:33 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:33 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:33 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:33 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:33 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:33 --> Controller Class Initialized
DEBUG - 2023-12-08 16:27:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2023-12-08 16:27:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:27:33 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:33 --> Total execution time: 0.0512
INFO - 2023-12-08 16:27:33 --> Config Class Initialized
INFO - 2023-12-08 16:27:33 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:33 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:33 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:33 --> URI Class Initialized
INFO - 2023-12-08 16:27:33 --> Router Class Initialized
INFO - 2023-12-08 16:27:33 --> Output Class Initialized
INFO - 2023-12-08 16:27:33 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:33 --> Input Class Initialized
INFO - 2023-12-08 16:27:33 --> Language Class Initialized
INFO - 2023-12-08 16:27:33 --> Language Class Initialized
INFO - 2023-12-08 16:27:33 --> Config Class Initialized
INFO - 2023-12-08 16:27:33 --> Loader Class Initialized
INFO - 2023-12-08 16:27:33 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:33 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:33 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:33 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:33 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:33 --> Controller Class Initialized
INFO - 2023-12-08 16:27:38 --> Config Class Initialized
INFO - 2023-12-08 16:27:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:27:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:27:38 --> Utf8 Class Initialized
INFO - 2023-12-08 16:27:38 --> URI Class Initialized
INFO - 2023-12-08 16:27:38 --> Router Class Initialized
INFO - 2023-12-08 16:27:38 --> Output Class Initialized
INFO - 2023-12-08 16:27:38 --> Security Class Initialized
DEBUG - 2023-12-08 16:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:27:38 --> Input Class Initialized
INFO - 2023-12-08 16:27:38 --> Language Class Initialized
INFO - 2023-12-08 16:27:38 --> Language Class Initialized
INFO - 2023-12-08 16:27:38 --> Config Class Initialized
INFO - 2023-12-08 16:27:38 --> Loader Class Initialized
INFO - 2023-12-08 16:27:38 --> Helper loaded: url_helper
INFO - 2023-12-08 16:27:38 --> Helper loaded: file_helper
INFO - 2023-12-08 16:27:38 --> Helper loaded: form_helper
INFO - 2023-12-08 16:27:38 --> Helper loaded: my_helper
INFO - 2023-12-08 16:27:38 --> Database Driver Class Initialized
INFO - 2023-12-08 16:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:27:38 --> Controller Class Initialized
DEBUG - 2023-12-08 16:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:27:38 --> Final output sent to browser
DEBUG - 2023-12-08 16:27:38 --> Total execution time: 0.0410
INFO - 2023-12-08 16:28:02 --> Config Class Initialized
INFO - 2023-12-08 16:28:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:28:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:28:02 --> Utf8 Class Initialized
INFO - 2023-12-08 16:28:02 --> URI Class Initialized
INFO - 2023-12-08 16:28:02 --> Router Class Initialized
INFO - 2023-12-08 16:28:02 --> Output Class Initialized
INFO - 2023-12-08 16:28:02 --> Security Class Initialized
DEBUG - 2023-12-08 16:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:28:02 --> Input Class Initialized
INFO - 2023-12-08 16:28:02 --> Language Class Initialized
INFO - 2023-12-08 16:28:02 --> Language Class Initialized
INFO - 2023-12-08 16:28:02 --> Config Class Initialized
INFO - 2023-12-08 16:28:02 --> Loader Class Initialized
INFO - 2023-12-08 16:28:02 --> Helper loaded: url_helper
INFO - 2023-12-08 16:28:02 --> Helper loaded: file_helper
INFO - 2023-12-08 16:28:02 --> Helper loaded: form_helper
INFO - 2023-12-08 16:28:02 --> Helper loaded: my_helper
INFO - 2023-12-08 16:28:02 --> Database Driver Class Initialized
INFO - 2023-12-08 16:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:28:02 --> Controller Class Initialized
DEBUG - 2023-12-08 16:28:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2023-12-08 16:28:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:28:02 --> Final output sent to browser
DEBUG - 2023-12-08 16:28:02 --> Total execution time: 0.5605
INFO - 2023-12-08 16:28:03 --> Config Class Initialized
INFO - 2023-12-08 16:28:03 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:28:03 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:28:03 --> Utf8 Class Initialized
INFO - 2023-12-08 16:28:03 --> URI Class Initialized
INFO - 2023-12-08 16:28:03 --> Router Class Initialized
INFO - 2023-12-08 16:28:03 --> Output Class Initialized
INFO - 2023-12-08 16:28:03 --> Security Class Initialized
DEBUG - 2023-12-08 16:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:28:03 --> Input Class Initialized
INFO - 2023-12-08 16:28:03 --> Language Class Initialized
INFO - 2023-12-08 16:28:03 --> Language Class Initialized
INFO - 2023-12-08 16:28:03 --> Config Class Initialized
INFO - 2023-12-08 16:28:03 --> Loader Class Initialized
INFO - 2023-12-08 16:28:03 --> Helper loaded: url_helper
INFO - 2023-12-08 16:28:03 --> Helper loaded: file_helper
INFO - 2023-12-08 16:28:03 --> Helper loaded: form_helper
INFO - 2023-12-08 16:28:03 --> Helper loaded: my_helper
INFO - 2023-12-08 16:28:03 --> Database Driver Class Initialized
INFO - 2023-12-08 16:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:28:03 --> Controller Class Initialized
INFO - 2023-12-08 16:28:05 --> Config Class Initialized
INFO - 2023-12-08 16:28:05 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:28:05 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:28:05 --> Utf8 Class Initialized
INFO - 2023-12-08 16:28:05 --> URI Class Initialized
INFO - 2023-12-08 16:28:05 --> Router Class Initialized
INFO - 2023-12-08 16:28:05 --> Output Class Initialized
INFO - 2023-12-08 16:28:05 --> Security Class Initialized
DEBUG - 2023-12-08 16:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:28:05 --> Input Class Initialized
INFO - 2023-12-08 16:28:05 --> Language Class Initialized
INFO - 2023-12-08 16:28:05 --> Language Class Initialized
INFO - 2023-12-08 16:28:05 --> Config Class Initialized
INFO - 2023-12-08 16:28:05 --> Loader Class Initialized
INFO - 2023-12-08 16:28:05 --> Helper loaded: url_helper
INFO - 2023-12-08 16:28:05 --> Helper loaded: file_helper
INFO - 2023-12-08 16:28:05 --> Helper loaded: form_helper
INFO - 2023-12-08 16:28:05 --> Helper loaded: my_helper
INFO - 2023-12-08 16:28:05 --> Database Driver Class Initialized
INFO - 2023-12-08 16:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:28:05 --> Controller Class Initialized
INFO - 2023-12-08 16:28:06 --> Final output sent to browser
DEBUG - 2023-12-08 16:28:06 --> Total execution time: 0.8400
INFO - 2023-12-08 16:28:08 --> Config Class Initialized
INFO - 2023-12-08 16:28:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:28:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:28:08 --> Utf8 Class Initialized
INFO - 2023-12-08 16:28:08 --> URI Class Initialized
INFO - 2023-12-08 16:28:08 --> Router Class Initialized
INFO - 2023-12-08 16:28:08 --> Output Class Initialized
INFO - 2023-12-08 16:28:08 --> Security Class Initialized
DEBUG - 2023-12-08 16:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:28:08 --> Input Class Initialized
INFO - 2023-12-08 16:28:08 --> Language Class Initialized
INFO - 2023-12-08 16:28:08 --> Language Class Initialized
INFO - 2023-12-08 16:28:08 --> Config Class Initialized
INFO - 2023-12-08 16:28:08 --> Loader Class Initialized
INFO - 2023-12-08 16:28:08 --> Helper loaded: url_helper
INFO - 2023-12-08 16:28:08 --> Helper loaded: file_helper
INFO - 2023-12-08 16:28:08 --> Helper loaded: form_helper
INFO - 2023-12-08 16:28:08 --> Helper loaded: my_helper
INFO - 2023-12-08 16:28:08 --> Database Driver Class Initialized
INFO - 2023-12-08 16:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:28:08 --> Controller Class Initialized
DEBUG - 2023-12-08 16:28:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:28:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:28:08 --> Final output sent to browser
DEBUG - 2023-12-08 16:28:08 --> Total execution time: 0.3913
INFO - 2023-12-08 16:48:42 --> Config Class Initialized
INFO - 2023-12-08 16:48:42 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:48:42 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:48:42 --> Utf8 Class Initialized
INFO - 2023-12-08 16:48:43 --> URI Class Initialized
INFO - 2023-12-08 16:48:43 --> Router Class Initialized
INFO - 2023-12-08 16:48:43 --> Output Class Initialized
INFO - 2023-12-08 16:48:43 --> Security Class Initialized
DEBUG - 2023-12-08 16:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:48:43 --> Input Class Initialized
INFO - 2023-12-08 16:48:43 --> Language Class Initialized
INFO - 2023-12-08 16:48:43 --> Language Class Initialized
INFO - 2023-12-08 16:48:43 --> Config Class Initialized
INFO - 2023-12-08 16:48:43 --> Loader Class Initialized
INFO - 2023-12-08 16:48:43 --> Helper loaded: url_helper
INFO - 2023-12-08 16:48:43 --> Helper loaded: file_helper
INFO - 2023-12-08 16:48:43 --> Helper loaded: form_helper
INFO - 2023-12-08 16:48:43 --> Helper loaded: my_helper
INFO - 2023-12-08 16:48:43 --> Database Driver Class Initialized
INFO - 2023-12-08 16:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:48:43 --> Controller Class Initialized
INFO - 2023-12-08 16:48:43 --> Final output sent to browser
DEBUG - 2023-12-08 16:48:43 --> Total execution time: 1.0817
INFO - 2023-12-08 16:49:22 --> Config Class Initialized
INFO - 2023-12-08 16:49:22 --> Hooks Class Initialized
DEBUG - 2023-12-08 16:49:22 --> UTF-8 Support Enabled
INFO - 2023-12-08 16:49:22 --> Utf8 Class Initialized
INFO - 2023-12-08 16:49:22 --> URI Class Initialized
INFO - 2023-12-08 16:49:22 --> Router Class Initialized
INFO - 2023-12-08 16:49:22 --> Output Class Initialized
INFO - 2023-12-08 16:49:22 --> Security Class Initialized
DEBUG - 2023-12-08 16:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 16:49:22 --> Input Class Initialized
INFO - 2023-12-08 16:49:22 --> Language Class Initialized
INFO - 2023-12-08 16:49:22 --> Language Class Initialized
INFO - 2023-12-08 16:49:22 --> Config Class Initialized
INFO - 2023-12-08 16:49:22 --> Loader Class Initialized
INFO - 2023-12-08 16:49:22 --> Helper loaded: url_helper
INFO - 2023-12-08 16:49:22 --> Helper loaded: file_helper
INFO - 2023-12-08 16:49:22 --> Helper loaded: form_helper
INFO - 2023-12-08 16:49:22 --> Helper loaded: my_helper
INFO - 2023-12-08 16:49:22 --> Database Driver Class Initialized
INFO - 2023-12-08 16:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 16:49:22 --> Controller Class Initialized
DEBUG - 2023-12-08 16:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 16:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 16:49:22 --> Final output sent to browser
DEBUG - 2023-12-08 16:49:22 --> Total execution time: 0.0748
INFO - 2023-12-08 18:54:55 --> Config Class Initialized
INFO - 2023-12-08 18:54:55 --> Hooks Class Initialized
DEBUG - 2023-12-08 18:54:55 --> UTF-8 Support Enabled
INFO - 2023-12-08 18:54:55 --> Utf8 Class Initialized
INFO - 2023-12-08 18:54:55 --> URI Class Initialized
INFO - 2023-12-08 18:54:55 --> Router Class Initialized
INFO - 2023-12-08 18:54:55 --> Output Class Initialized
INFO - 2023-12-08 18:54:55 --> Security Class Initialized
DEBUG - 2023-12-08 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 18:54:55 --> Input Class Initialized
INFO - 2023-12-08 18:54:55 --> Language Class Initialized
INFO - 2023-12-08 18:54:55 --> Language Class Initialized
INFO - 2023-12-08 18:54:55 --> Config Class Initialized
INFO - 2023-12-08 18:54:55 --> Loader Class Initialized
INFO - 2023-12-08 18:54:55 --> Helper loaded: url_helper
INFO - 2023-12-08 18:54:55 --> Helper loaded: file_helper
INFO - 2023-12-08 18:54:55 --> Helper loaded: form_helper
INFO - 2023-12-08 18:54:55 --> Helper loaded: my_helper
INFO - 2023-12-08 18:54:55 --> Database Driver Class Initialized
INFO - 2023-12-08 18:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 18:54:55 --> Controller Class Initialized
DEBUG - 2023-12-08 18:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 18:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 18:54:55 --> Final output sent to browser
DEBUG - 2023-12-08 18:54:55 --> Total execution time: 0.4583
INFO - 2023-12-08 18:55:05 --> Config Class Initialized
INFO - 2023-12-08 18:55:05 --> Hooks Class Initialized
DEBUG - 2023-12-08 18:55:05 --> UTF-8 Support Enabled
INFO - 2023-12-08 18:55:05 --> Utf8 Class Initialized
INFO - 2023-12-08 18:55:05 --> URI Class Initialized
DEBUG - 2023-12-08 18:55:05 --> No URI present. Default controller set.
INFO - 2023-12-08 18:55:05 --> Router Class Initialized
INFO - 2023-12-08 18:55:05 --> Output Class Initialized
INFO - 2023-12-08 18:55:06 --> Security Class Initialized
DEBUG - 2023-12-08 18:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 18:55:06 --> Input Class Initialized
INFO - 2023-12-08 18:55:06 --> Language Class Initialized
INFO - 2023-12-08 18:55:06 --> Language Class Initialized
INFO - 2023-12-08 18:55:06 --> Config Class Initialized
INFO - 2023-12-08 18:55:06 --> Loader Class Initialized
INFO - 2023-12-08 18:55:06 --> Helper loaded: url_helper
INFO - 2023-12-08 18:55:06 --> Helper loaded: file_helper
INFO - 2023-12-08 18:55:06 --> Helper loaded: form_helper
INFO - 2023-12-08 18:55:06 --> Helper loaded: my_helper
INFO - 2023-12-08 18:55:06 --> Database Driver Class Initialized
INFO - 2023-12-08 18:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 18:55:06 --> Controller Class Initialized
INFO - 2023-12-08 18:55:06 --> Config Class Initialized
INFO - 2023-12-08 18:55:06 --> Hooks Class Initialized
DEBUG - 2023-12-08 18:55:06 --> UTF-8 Support Enabled
INFO - 2023-12-08 18:55:06 --> Utf8 Class Initialized
INFO - 2023-12-08 18:55:06 --> URI Class Initialized
DEBUG - 2023-12-08 18:55:06 --> No URI present. Default controller set.
INFO - 2023-12-08 18:55:06 --> Router Class Initialized
INFO - 2023-12-08 18:55:06 --> Output Class Initialized
INFO - 2023-12-08 18:55:06 --> Security Class Initialized
DEBUG - 2023-12-08 18:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 18:55:06 --> Input Class Initialized
INFO - 2023-12-08 18:55:06 --> Language Class Initialized
INFO - 2023-12-08 18:55:06 --> Language Class Initialized
INFO - 2023-12-08 18:55:06 --> Config Class Initialized
INFO - 2023-12-08 18:55:06 --> Loader Class Initialized
INFO - 2023-12-08 18:55:06 --> Helper loaded: url_helper
INFO - 2023-12-08 18:55:06 --> Helper loaded: file_helper
INFO - 2023-12-08 18:55:07 --> Helper loaded: form_helper
INFO - 2023-12-08 18:55:07 --> Helper loaded: my_helper
INFO - 2023-12-08 18:55:07 --> Database Driver Class Initialized
INFO - 2023-12-08 18:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 18:55:07 --> Controller Class Initialized
INFO - 2023-12-08 18:55:07 --> Config Class Initialized
INFO - 2023-12-08 18:55:07 --> Hooks Class Initialized
DEBUG - 2023-12-08 18:55:07 --> UTF-8 Support Enabled
INFO - 2023-12-08 18:55:07 --> Utf8 Class Initialized
INFO - 2023-12-08 18:55:07 --> URI Class Initialized
INFO - 2023-12-08 18:55:07 --> Router Class Initialized
INFO - 2023-12-08 18:55:07 --> Output Class Initialized
INFO - 2023-12-08 18:55:07 --> Security Class Initialized
DEBUG - 2023-12-08 18:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 18:55:07 --> Input Class Initialized
INFO - 2023-12-08 18:55:07 --> Language Class Initialized
INFO - 2023-12-08 18:55:08 --> Language Class Initialized
INFO - 2023-12-08 18:55:08 --> Config Class Initialized
INFO - 2023-12-08 18:55:08 --> Loader Class Initialized
INFO - 2023-12-08 18:55:08 --> Helper loaded: url_helper
INFO - 2023-12-08 18:55:08 --> Helper loaded: file_helper
INFO - 2023-12-08 18:55:08 --> Helper loaded: form_helper
INFO - 2023-12-08 18:55:08 --> Helper loaded: my_helper
INFO - 2023-12-08 18:55:08 --> Database Driver Class Initialized
INFO - 2023-12-08 18:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 18:55:08 --> Controller Class Initialized
DEBUG - 2023-12-08 18:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 18:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 18:55:08 --> Final output sent to browser
DEBUG - 2023-12-08 18:55:08 --> Total execution time: 0.1654
INFO - 2023-12-08 18:55:08 --> Config Class Initialized
INFO - 2023-12-08 18:55:08 --> Hooks Class Initialized
DEBUG - 2023-12-08 18:55:08 --> UTF-8 Support Enabled
INFO - 2023-12-08 18:55:08 --> Utf8 Class Initialized
INFO - 2023-12-08 18:55:08 --> URI Class Initialized
INFO - 2023-12-08 18:55:08 --> Router Class Initialized
INFO - 2023-12-08 18:55:09 --> Output Class Initialized
INFO - 2023-12-08 18:55:09 --> Security Class Initialized
DEBUG - 2023-12-08 18:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 18:55:09 --> Input Class Initialized
INFO - 2023-12-08 18:55:09 --> Language Class Initialized
INFO - 2023-12-08 18:55:09 --> Language Class Initialized
INFO - 2023-12-08 18:55:09 --> Config Class Initialized
INFO - 2023-12-08 18:55:09 --> Loader Class Initialized
INFO - 2023-12-08 18:55:09 --> Helper loaded: url_helper
INFO - 2023-12-08 18:55:09 --> Helper loaded: file_helper
INFO - 2023-12-08 18:55:09 --> Helper loaded: form_helper
INFO - 2023-12-08 18:55:09 --> Helper loaded: my_helper
INFO - 2023-12-08 18:55:09 --> Database Driver Class Initialized
INFO - 2023-12-08 18:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 18:55:09 --> Controller Class Initialized
DEBUG - 2023-12-08 18:55:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 18:55:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 18:55:09 --> Final output sent to browser
DEBUG - 2023-12-08 18:55:09 --> Total execution time: 0.5487
INFO - 2023-12-08 20:10:32 --> Config Class Initialized
INFO - 2023-12-08 20:10:32 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:32 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:32 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:32 --> URI Class Initialized
INFO - 2023-12-08 20:10:32 --> Router Class Initialized
INFO - 2023-12-08 20:10:32 --> Output Class Initialized
INFO - 2023-12-08 20:10:32 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:32 --> Input Class Initialized
INFO - 2023-12-08 20:10:32 --> Language Class Initialized
INFO - 2023-12-08 20:10:32 --> Language Class Initialized
INFO - 2023-12-08 20:10:32 --> Config Class Initialized
INFO - 2023-12-08 20:10:32 --> Loader Class Initialized
INFO - 2023-12-08 20:10:32 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:32 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:32 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:32 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:32 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:32 --> Controller Class Initialized
DEBUG - 2023-12-08 20:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 20:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:10:32 --> Final output sent to browser
DEBUG - 2023-12-08 20:10:32 --> Total execution time: 0.1527
INFO - 2023-12-08 20:10:33 --> Config Class Initialized
INFO - 2023-12-08 20:10:33 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:33 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:33 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:33 --> URI Class Initialized
INFO - 2023-12-08 20:10:33 --> Router Class Initialized
INFO - 2023-12-08 20:10:33 --> Output Class Initialized
INFO - 2023-12-08 20:10:33 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:33 --> Input Class Initialized
INFO - 2023-12-08 20:10:33 --> Language Class Initialized
INFO - 2023-12-08 20:10:33 --> Language Class Initialized
INFO - 2023-12-08 20:10:33 --> Config Class Initialized
INFO - 2023-12-08 20:10:33 --> Loader Class Initialized
INFO - 2023-12-08 20:10:33 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:33 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:33 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:33 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:33 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:33 --> Controller Class Initialized
INFO - 2023-12-08 20:10:47 --> Config Class Initialized
INFO - 2023-12-08 20:10:47 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:47 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:47 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:47 --> URI Class Initialized
INFO - 2023-12-08 20:10:47 --> Router Class Initialized
INFO - 2023-12-08 20:10:47 --> Output Class Initialized
INFO - 2023-12-08 20:10:47 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:47 --> Input Class Initialized
INFO - 2023-12-08 20:10:47 --> Language Class Initialized
INFO - 2023-12-08 20:10:47 --> Language Class Initialized
INFO - 2023-12-08 20:10:47 --> Config Class Initialized
INFO - 2023-12-08 20:10:47 --> Loader Class Initialized
INFO - 2023-12-08 20:10:47 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:47 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:47 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:47 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:47 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:47 --> Controller Class Initialized
INFO - 2023-12-08 20:10:47 --> Config Class Initialized
INFO - 2023-12-08 20:10:47 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:47 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:47 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:47 --> URI Class Initialized
INFO - 2023-12-08 20:10:47 --> Router Class Initialized
INFO - 2023-12-08 20:10:47 --> Output Class Initialized
INFO - 2023-12-08 20:10:47 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:47 --> Input Class Initialized
INFO - 2023-12-08 20:10:47 --> Language Class Initialized
INFO - 2023-12-08 20:10:47 --> Language Class Initialized
INFO - 2023-12-08 20:10:47 --> Config Class Initialized
INFO - 2023-12-08 20:10:47 --> Loader Class Initialized
INFO - 2023-12-08 20:10:47 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:47 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:47 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:47 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:47 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:47 --> Controller Class Initialized
DEBUG - 2023-12-08 20:10:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-08 20:10:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:10:47 --> Final output sent to browser
DEBUG - 2023-12-08 20:10:47 --> Total execution time: 0.4112
INFO - 2023-12-08 20:10:55 --> Config Class Initialized
INFO - 2023-12-08 20:10:55 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:55 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:55 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:55 --> URI Class Initialized
INFO - 2023-12-08 20:10:55 --> Router Class Initialized
INFO - 2023-12-08 20:10:55 --> Output Class Initialized
INFO - 2023-12-08 20:10:55 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:55 --> Input Class Initialized
INFO - 2023-12-08 20:10:55 --> Language Class Initialized
INFO - 2023-12-08 20:10:55 --> Language Class Initialized
INFO - 2023-12-08 20:10:55 --> Config Class Initialized
INFO - 2023-12-08 20:10:55 --> Loader Class Initialized
INFO - 2023-12-08 20:10:55 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:55 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:55 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:55 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:55 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:55 --> Controller Class Initialized
INFO - 2023-12-08 20:10:55 --> Helper loaded: cookie_helper
INFO - 2023-12-08 20:10:55 --> Final output sent to browser
DEBUG - 2023-12-08 20:10:55 --> Total execution time: 0.1632
INFO - 2023-12-08 20:10:55 --> Config Class Initialized
INFO - 2023-12-08 20:10:55 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:55 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:55 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:55 --> URI Class Initialized
INFO - 2023-12-08 20:10:55 --> Router Class Initialized
INFO - 2023-12-08 20:10:56 --> Output Class Initialized
INFO - 2023-12-08 20:10:56 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:56 --> Input Class Initialized
INFO - 2023-12-08 20:10:56 --> Language Class Initialized
INFO - 2023-12-08 20:10:56 --> Language Class Initialized
INFO - 2023-12-08 20:10:56 --> Config Class Initialized
INFO - 2023-12-08 20:10:56 --> Loader Class Initialized
INFO - 2023-12-08 20:10:56 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:56 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:56 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:56 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:56 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:56 --> Controller Class Initialized
DEBUG - 2023-12-08 20:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-08 20:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:10:56 --> Final output sent to browser
DEBUG - 2023-12-08 20:10:56 --> Total execution time: 0.0460
INFO - 2023-12-08 20:10:58 --> Config Class Initialized
INFO - 2023-12-08 20:10:58 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:10:58 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:10:58 --> Utf8 Class Initialized
INFO - 2023-12-08 20:10:58 --> URI Class Initialized
INFO - 2023-12-08 20:10:58 --> Router Class Initialized
INFO - 2023-12-08 20:10:58 --> Output Class Initialized
INFO - 2023-12-08 20:10:58 --> Security Class Initialized
DEBUG - 2023-12-08 20:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:10:58 --> Input Class Initialized
INFO - 2023-12-08 20:10:58 --> Language Class Initialized
INFO - 2023-12-08 20:10:58 --> Language Class Initialized
INFO - 2023-12-08 20:10:58 --> Config Class Initialized
INFO - 2023-12-08 20:10:58 --> Loader Class Initialized
INFO - 2023-12-08 20:10:58 --> Helper loaded: url_helper
INFO - 2023-12-08 20:10:58 --> Helper loaded: file_helper
INFO - 2023-12-08 20:10:58 --> Helper loaded: form_helper
INFO - 2023-12-08 20:10:58 --> Helper loaded: my_helper
INFO - 2023-12-08 20:10:58 --> Database Driver Class Initialized
INFO - 2023-12-08 20:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:10:58 --> Controller Class Initialized
DEBUG - 2023-12-08 20:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 20:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:10:58 --> Final output sent to browser
DEBUG - 2023-12-08 20:10:58 --> Total execution time: 0.0450
INFO - 2023-12-08 20:11:02 --> Config Class Initialized
INFO - 2023-12-08 20:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:02 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:02 --> URI Class Initialized
INFO - 2023-12-08 20:11:02 --> Router Class Initialized
INFO - 2023-12-08 20:11:02 --> Output Class Initialized
INFO - 2023-12-08 20:11:02 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:02 --> Input Class Initialized
INFO - 2023-12-08 20:11:02 --> Language Class Initialized
INFO - 2023-12-08 20:11:02 --> Language Class Initialized
INFO - 2023-12-08 20:11:02 --> Config Class Initialized
INFO - 2023-12-08 20:11:02 --> Loader Class Initialized
INFO - 2023-12-08 20:11:02 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:02 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:02 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:02 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:02 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:03 --> Controller Class Initialized
DEBUG - 2023-12-08 20:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-08 20:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:11:03 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:03 --> Total execution time: 0.6477
INFO - 2023-12-08 20:11:05 --> Config Class Initialized
INFO - 2023-12-08 20:11:05 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:05 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:05 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:05 --> URI Class Initialized
INFO - 2023-12-08 20:11:05 --> Router Class Initialized
INFO - 2023-12-08 20:11:05 --> Output Class Initialized
INFO - 2023-12-08 20:11:05 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:05 --> Input Class Initialized
INFO - 2023-12-08 20:11:05 --> Language Class Initialized
INFO - 2023-12-08 20:11:05 --> Language Class Initialized
INFO - 2023-12-08 20:11:05 --> Config Class Initialized
INFO - 2023-12-08 20:11:05 --> Loader Class Initialized
INFO - 2023-12-08 20:11:05 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:05 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:05 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:05 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:05 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:05 --> Controller Class Initialized
DEBUG - 2023-12-08 20:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-08 20:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:11:05 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:05 --> Total execution time: 0.0503
INFO - 2023-12-08 20:11:06 --> Config Class Initialized
INFO - 2023-12-08 20:11:06 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:06 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:06 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:06 --> URI Class Initialized
INFO - 2023-12-08 20:11:06 --> Router Class Initialized
INFO - 2023-12-08 20:11:06 --> Output Class Initialized
INFO - 2023-12-08 20:11:06 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:06 --> Input Class Initialized
INFO - 2023-12-08 20:11:06 --> Language Class Initialized
INFO - 2023-12-08 20:11:06 --> Language Class Initialized
INFO - 2023-12-08 20:11:06 --> Config Class Initialized
INFO - 2023-12-08 20:11:06 --> Loader Class Initialized
INFO - 2023-12-08 20:11:06 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:06 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:06 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:06 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:06 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:06 --> Controller Class Initialized
DEBUG - 2023-12-08 20:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 20:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:11:06 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:06 --> Total execution time: 0.0482
INFO - 2023-12-08 20:11:07 --> Config Class Initialized
INFO - 2023-12-08 20:11:07 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:07 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:07 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:07 --> URI Class Initialized
INFO - 2023-12-08 20:11:07 --> Router Class Initialized
INFO - 2023-12-08 20:11:07 --> Output Class Initialized
INFO - 2023-12-08 20:11:07 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:07 --> Input Class Initialized
INFO - 2023-12-08 20:11:07 --> Language Class Initialized
INFO - 2023-12-08 20:11:07 --> Language Class Initialized
INFO - 2023-12-08 20:11:07 --> Config Class Initialized
INFO - 2023-12-08 20:11:07 --> Loader Class Initialized
INFO - 2023-12-08 20:11:07 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:07 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:07 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:07 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:07 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:07 --> Controller Class Initialized
INFO - 2023-12-08 20:11:14 --> Config Class Initialized
INFO - 2023-12-08 20:11:14 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:14 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:14 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:14 --> URI Class Initialized
INFO - 2023-12-08 20:11:14 --> Router Class Initialized
INFO - 2023-12-08 20:11:14 --> Output Class Initialized
INFO - 2023-12-08 20:11:14 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:14 --> Input Class Initialized
INFO - 2023-12-08 20:11:14 --> Language Class Initialized
INFO - 2023-12-08 20:11:14 --> Language Class Initialized
INFO - 2023-12-08 20:11:14 --> Config Class Initialized
INFO - 2023-12-08 20:11:14 --> Loader Class Initialized
INFO - 2023-12-08 20:11:14 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:14 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:14 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:14 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:14 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:14 --> Controller Class Initialized
INFO - 2023-12-08 20:11:14 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:14 --> Total execution time: 0.1994
INFO - 2023-12-08 20:11:17 --> Config Class Initialized
INFO - 2023-12-08 20:11:17 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:17 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:17 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:17 --> URI Class Initialized
INFO - 2023-12-08 20:11:17 --> Router Class Initialized
INFO - 2023-12-08 20:11:17 --> Output Class Initialized
INFO - 2023-12-08 20:11:17 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:17 --> Input Class Initialized
INFO - 2023-12-08 20:11:17 --> Language Class Initialized
INFO - 2023-12-08 20:11:17 --> Language Class Initialized
INFO - 2023-12-08 20:11:17 --> Config Class Initialized
INFO - 2023-12-08 20:11:17 --> Loader Class Initialized
INFO - 2023-12-08 20:11:17 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:17 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:17 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:17 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:17 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:17 --> Controller Class Initialized
INFO - 2023-12-08 20:11:18 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:18 --> Total execution time: 0.3552
INFO - 2023-12-08 20:11:23 --> Config Class Initialized
INFO - 2023-12-08 20:11:23 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:23 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:23 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:23 --> URI Class Initialized
INFO - 2023-12-08 20:11:23 --> Router Class Initialized
INFO - 2023-12-08 20:11:23 --> Output Class Initialized
INFO - 2023-12-08 20:11:23 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:23 --> Input Class Initialized
INFO - 2023-12-08 20:11:23 --> Language Class Initialized
INFO - 2023-12-08 20:11:23 --> Language Class Initialized
INFO - 2023-12-08 20:11:23 --> Config Class Initialized
INFO - 2023-12-08 20:11:23 --> Loader Class Initialized
INFO - 2023-12-08 20:11:23 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:23 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:23 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:23 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:23 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:23 --> Controller Class Initialized
DEBUG - 2023-12-08 20:11:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-08 20:11:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:11:23 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:23 --> Total execution time: 0.3010
INFO - 2023-12-08 20:11:37 --> Config Class Initialized
INFO - 2023-12-08 20:11:37 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:37 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:37 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:37 --> URI Class Initialized
INFO - 2023-12-08 20:11:37 --> Router Class Initialized
INFO - 2023-12-08 20:11:37 --> Output Class Initialized
INFO - 2023-12-08 20:11:37 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:37 --> Input Class Initialized
INFO - 2023-12-08 20:11:37 --> Language Class Initialized
INFO - 2023-12-08 20:11:37 --> Language Class Initialized
INFO - 2023-12-08 20:11:37 --> Config Class Initialized
INFO - 2023-12-08 20:11:37 --> Loader Class Initialized
INFO - 2023-12-08 20:11:37 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:37 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:37 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:37 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:37 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:37 --> Controller Class Initialized
INFO - 2023-12-08 20:11:38 --> Config Class Initialized
INFO - 2023-12-08 20:11:38 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:38 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:38 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:38 --> URI Class Initialized
INFO - 2023-12-08 20:11:38 --> Router Class Initialized
INFO - 2023-12-08 20:11:38 --> Output Class Initialized
INFO - 2023-12-08 20:11:38 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:38 --> Input Class Initialized
INFO - 2023-12-08 20:11:38 --> Language Class Initialized
INFO - 2023-12-08 20:11:38 --> Language Class Initialized
INFO - 2023-12-08 20:11:38 --> Config Class Initialized
INFO - 2023-12-08 20:11:38 --> Loader Class Initialized
INFO - 2023-12-08 20:11:38 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:38 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:38 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:38 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:38 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:39 --> Controller Class Initialized
DEBUG - 2023-12-08 20:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-08 20:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-08 20:11:39 --> Final output sent to browser
DEBUG - 2023-12-08 20:11:39 --> Total execution time: 0.1897
INFO - 2023-12-08 20:11:39 --> Config Class Initialized
INFO - 2023-12-08 20:11:39 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:11:39 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:11:39 --> Utf8 Class Initialized
INFO - 2023-12-08 20:11:39 --> URI Class Initialized
INFO - 2023-12-08 20:11:39 --> Router Class Initialized
INFO - 2023-12-08 20:11:39 --> Output Class Initialized
INFO - 2023-12-08 20:11:39 --> Security Class Initialized
DEBUG - 2023-12-08 20:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:11:39 --> Input Class Initialized
INFO - 2023-12-08 20:11:39 --> Language Class Initialized
INFO - 2023-12-08 20:11:39 --> Language Class Initialized
INFO - 2023-12-08 20:11:39 --> Config Class Initialized
INFO - 2023-12-08 20:11:39 --> Loader Class Initialized
INFO - 2023-12-08 20:11:39 --> Helper loaded: url_helper
INFO - 2023-12-08 20:11:39 --> Helper loaded: file_helper
INFO - 2023-12-08 20:11:39 --> Helper loaded: form_helper
INFO - 2023-12-08 20:11:39 --> Helper loaded: my_helper
INFO - 2023-12-08 20:11:39 --> Database Driver Class Initialized
INFO - 2023-12-08 20:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:11:39 --> Controller Class Initialized
INFO - 2023-12-08 20:12:16 --> Config Class Initialized
INFO - 2023-12-08 20:12:16 --> Hooks Class Initialized
DEBUG - 2023-12-08 20:12:16 --> UTF-8 Support Enabled
INFO - 2023-12-08 20:12:16 --> Utf8 Class Initialized
INFO - 2023-12-08 20:12:16 --> URI Class Initialized
INFO - 2023-12-08 20:12:16 --> Router Class Initialized
INFO - 2023-12-08 20:12:16 --> Output Class Initialized
INFO - 2023-12-08 20:12:16 --> Security Class Initialized
DEBUG - 2023-12-08 20:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-08 20:12:16 --> Input Class Initialized
INFO - 2023-12-08 20:12:16 --> Language Class Initialized
INFO - 2023-12-08 20:12:16 --> Language Class Initialized
INFO - 2023-12-08 20:12:16 --> Config Class Initialized
INFO - 2023-12-08 20:12:16 --> Loader Class Initialized
INFO - 2023-12-08 20:12:16 --> Helper loaded: url_helper
INFO - 2023-12-08 20:12:16 --> Helper loaded: file_helper
INFO - 2023-12-08 20:12:16 --> Helper loaded: form_helper
INFO - 2023-12-08 20:12:16 --> Helper loaded: my_helper
INFO - 2023-12-08 20:12:16 --> Database Driver Class Initialized
INFO - 2023-12-08 20:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-08 20:12:16 --> Controller Class Initialized
INFO - 2023-12-08 20:12:16 --> Final output sent to browser
DEBUG - 2023-12-08 20:12:16 --> Total execution time: 0.1291
