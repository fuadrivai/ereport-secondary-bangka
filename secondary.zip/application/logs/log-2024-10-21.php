<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-21 09:51:08 --> Config Class Initialized
INFO - 2024-10-21 09:51:08 --> Hooks Class Initialized
DEBUG - 2024-10-21 09:51:08 --> UTF-8 Support Enabled
INFO - 2024-10-21 09:51:08 --> Utf8 Class Initialized
INFO - 2024-10-21 09:51:08 --> URI Class Initialized
INFO - 2024-10-21 09:51:08 --> Router Class Initialized
INFO - 2024-10-21 09:51:08 --> Output Class Initialized
INFO - 2024-10-21 09:51:08 --> Security Class Initialized
DEBUG - 2024-10-21 09:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 09:51:08 --> Input Class Initialized
INFO - 2024-10-21 09:51:08 --> Language Class Initialized
INFO - 2024-10-21 09:51:08 --> Language Class Initialized
INFO - 2024-10-21 09:51:08 --> Config Class Initialized
INFO - 2024-10-21 09:51:08 --> Loader Class Initialized
INFO - 2024-10-21 09:51:08 --> Helper loaded: url_helper
INFO - 2024-10-21 09:51:08 --> Helper loaded: file_helper
INFO - 2024-10-21 09:51:08 --> Helper loaded: form_helper
INFO - 2024-10-21 09:51:08 --> Helper loaded: my_helper
INFO - 2024-10-21 09:51:08 --> Database Driver Class Initialized
INFO - 2024-10-21 09:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 09:51:08 --> Controller Class Initialized
DEBUG - 2024-10-21 09:51:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-21 09:51:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 09:51:08 --> Final output sent to browser
DEBUG - 2024-10-21 09:51:08 --> Total execution time: 0.3189
INFO - 2024-10-21 09:52:10 --> Config Class Initialized
INFO - 2024-10-21 09:52:10 --> Hooks Class Initialized
DEBUG - 2024-10-21 09:52:10 --> UTF-8 Support Enabled
INFO - 2024-10-21 09:52:10 --> Utf8 Class Initialized
INFO - 2024-10-21 09:52:10 --> URI Class Initialized
INFO - 2024-10-21 09:52:10 --> Router Class Initialized
INFO - 2024-10-21 09:52:10 --> Output Class Initialized
INFO - 2024-10-21 09:52:11 --> Security Class Initialized
DEBUG - 2024-10-21 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 09:52:11 --> Input Class Initialized
INFO - 2024-10-21 09:52:11 --> Language Class Initialized
INFO - 2024-10-21 09:52:11 --> Language Class Initialized
INFO - 2024-10-21 09:52:11 --> Config Class Initialized
INFO - 2024-10-21 09:52:11 --> Loader Class Initialized
INFO - 2024-10-21 09:52:11 --> Helper loaded: url_helper
INFO - 2024-10-21 09:52:11 --> Helper loaded: file_helper
INFO - 2024-10-21 09:52:11 --> Helper loaded: form_helper
INFO - 2024-10-21 09:52:11 --> Helper loaded: my_helper
INFO - 2024-10-21 09:52:11 --> Database Driver Class Initialized
INFO - 2024-10-21 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 09:52:11 --> Controller Class Initialized
INFO - 2024-10-21 09:52:11 --> Helper loaded: cookie_helper
INFO - 2024-10-21 09:52:11 --> Final output sent to browser
DEBUG - 2024-10-21 09:52:11 --> Total execution time: 1.0315
INFO - 2024-10-21 09:52:12 --> Config Class Initialized
INFO - 2024-10-21 09:52:12 --> Hooks Class Initialized
DEBUG - 2024-10-21 09:52:12 --> UTF-8 Support Enabled
INFO - 2024-10-21 09:52:12 --> Utf8 Class Initialized
INFO - 2024-10-21 09:52:12 --> URI Class Initialized
INFO - 2024-10-21 09:52:12 --> Router Class Initialized
INFO - 2024-10-21 09:52:12 --> Output Class Initialized
INFO - 2024-10-21 09:52:12 --> Security Class Initialized
DEBUG - 2024-10-21 09:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 09:52:12 --> Input Class Initialized
INFO - 2024-10-21 09:52:12 --> Language Class Initialized
INFO - 2024-10-21 09:52:12 --> Language Class Initialized
INFO - 2024-10-21 09:52:12 --> Config Class Initialized
INFO - 2024-10-21 09:52:12 --> Loader Class Initialized
INFO - 2024-10-21 09:52:12 --> Helper loaded: url_helper
INFO - 2024-10-21 09:52:12 --> Helper loaded: file_helper
INFO - 2024-10-21 09:52:12 --> Helper loaded: form_helper
INFO - 2024-10-21 09:52:12 --> Helper loaded: my_helper
INFO - 2024-10-21 09:52:12 --> Database Driver Class Initialized
INFO - 2024-10-21 09:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 09:52:12 --> Controller Class Initialized
INFO - 2024-10-21 09:52:13 --> Helper loaded: cookie_helper
INFO - 2024-10-21 09:52:13 --> Config Class Initialized
INFO - 2024-10-21 09:52:13 --> Hooks Class Initialized
DEBUG - 2024-10-21 09:52:13 --> UTF-8 Support Enabled
INFO - 2024-10-21 09:52:13 --> Utf8 Class Initialized
INFO - 2024-10-21 09:52:13 --> URI Class Initialized
INFO - 2024-10-21 09:52:13 --> Router Class Initialized
INFO - 2024-10-21 09:52:13 --> Output Class Initialized
INFO - 2024-10-21 09:52:13 --> Security Class Initialized
DEBUG - 2024-10-21 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 09:52:13 --> Input Class Initialized
INFO - 2024-10-21 09:52:13 --> Language Class Initialized
INFO - 2024-10-21 09:52:13 --> Language Class Initialized
INFO - 2024-10-21 09:52:13 --> Config Class Initialized
INFO - 2024-10-21 09:52:13 --> Loader Class Initialized
INFO - 2024-10-21 09:52:13 --> Helper loaded: url_helper
INFO - 2024-10-21 09:52:13 --> Helper loaded: file_helper
INFO - 2024-10-21 09:52:13 --> Helper loaded: form_helper
INFO - 2024-10-21 09:52:13 --> Helper loaded: my_helper
INFO - 2024-10-21 09:52:13 --> Database Driver Class Initialized
INFO - 2024-10-21 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 09:52:13 --> Controller Class Initialized
DEBUG - 2024-10-21 09:52:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 09:52:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 09:52:13 --> Final output sent to browser
DEBUG - 2024-10-21 09:52:13 --> Total execution time: 0.2380
INFO - 2024-10-21 09:52:18 --> Config Class Initialized
INFO - 2024-10-21 09:52:18 --> Hooks Class Initialized
DEBUG - 2024-10-21 09:52:18 --> UTF-8 Support Enabled
INFO - 2024-10-21 09:52:18 --> Utf8 Class Initialized
INFO - 2024-10-21 09:52:18 --> URI Class Initialized
INFO - 2024-10-21 09:52:18 --> Router Class Initialized
INFO - 2024-10-21 09:52:18 --> Output Class Initialized
INFO - 2024-10-21 09:52:18 --> Security Class Initialized
DEBUG - 2024-10-21 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 09:52:18 --> Input Class Initialized
INFO - 2024-10-21 09:52:18 --> Language Class Initialized
INFO - 2024-10-21 09:52:18 --> Language Class Initialized
INFO - 2024-10-21 09:52:18 --> Config Class Initialized
INFO - 2024-10-21 09:52:18 --> Loader Class Initialized
INFO - 2024-10-21 09:52:18 --> Helper loaded: url_helper
INFO - 2024-10-21 09:52:18 --> Helper loaded: file_helper
INFO - 2024-10-21 09:52:18 --> Helper loaded: form_helper
INFO - 2024-10-21 09:52:18 --> Helper loaded: my_helper
INFO - 2024-10-21 09:52:18 --> Database Driver Class Initialized
INFO - 2024-10-21 09:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 09:52:19 --> Controller Class Initialized
ERROR - 2024-10-21 09:52:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-21 09:52:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-21 09:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-21 09:52:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-21 09:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 09:52:28 --> Final output sent to browser
DEBUG - 2024-10-21 09:52:28 --> Total execution time: 9.2019
INFO - 2024-10-21 10:00:38 --> Config Class Initialized
INFO - 2024-10-21 10:00:38 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:00:38 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:00:38 --> Utf8 Class Initialized
INFO - 2024-10-21 10:00:38 --> URI Class Initialized
INFO - 2024-10-21 10:00:38 --> Router Class Initialized
INFO - 2024-10-21 10:00:39 --> Output Class Initialized
INFO - 2024-10-21 10:00:39 --> Security Class Initialized
DEBUG - 2024-10-21 10:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:00:39 --> Input Class Initialized
INFO - 2024-10-21 10:00:39 --> Language Class Initialized
INFO - 2024-10-21 10:00:39 --> Language Class Initialized
INFO - 2024-10-21 10:00:39 --> Config Class Initialized
INFO - 2024-10-21 10:00:39 --> Loader Class Initialized
INFO - 2024-10-21 10:00:39 --> Helper loaded: url_helper
INFO - 2024-10-21 10:00:39 --> Helper loaded: file_helper
INFO - 2024-10-21 10:00:39 --> Helper loaded: form_helper
INFO - 2024-10-21 10:00:39 --> Helper loaded: my_helper
INFO - 2024-10-21 10:00:39 --> Database Driver Class Initialized
INFO - 2024-10-21 10:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:00:39 --> Controller Class Initialized
INFO - 2024-10-21 10:00:39 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:00:39 --> Final output sent to browser
DEBUG - 2024-10-21 10:00:39 --> Total execution time: 0.4839
INFO - 2024-10-21 10:00:39 --> Config Class Initialized
INFO - 2024-10-21 10:00:39 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:00:39 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:00:39 --> Utf8 Class Initialized
INFO - 2024-10-21 10:00:39 --> URI Class Initialized
INFO - 2024-10-21 10:00:39 --> Router Class Initialized
INFO - 2024-10-21 10:00:39 --> Output Class Initialized
INFO - 2024-10-21 10:00:39 --> Security Class Initialized
DEBUG - 2024-10-21 10:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:00:39 --> Input Class Initialized
INFO - 2024-10-21 10:00:39 --> Language Class Initialized
INFO - 2024-10-21 10:00:39 --> Language Class Initialized
INFO - 2024-10-21 10:00:39 --> Config Class Initialized
INFO - 2024-10-21 10:00:39 --> Loader Class Initialized
INFO - 2024-10-21 10:00:39 --> Helper loaded: url_helper
INFO - 2024-10-21 10:00:39 --> Helper loaded: file_helper
INFO - 2024-10-21 10:00:39 --> Helper loaded: form_helper
INFO - 2024-10-21 10:00:39 --> Helper loaded: my_helper
INFO - 2024-10-21 10:00:39 --> Database Driver Class Initialized
INFO - 2024-10-21 10:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:00:39 --> Controller Class Initialized
INFO - 2024-10-21 10:00:40 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:00:40 --> Config Class Initialized
INFO - 2024-10-21 10:00:40 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:00:40 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:00:40 --> Utf8 Class Initialized
INFO - 2024-10-21 10:00:40 --> URI Class Initialized
INFO - 2024-10-21 10:00:40 --> Router Class Initialized
INFO - 2024-10-21 10:00:40 --> Output Class Initialized
INFO - 2024-10-21 10:00:40 --> Security Class Initialized
DEBUG - 2024-10-21 10:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:00:40 --> Input Class Initialized
INFO - 2024-10-21 10:00:40 --> Language Class Initialized
INFO - 2024-10-21 10:00:40 --> Language Class Initialized
INFO - 2024-10-21 10:00:40 --> Config Class Initialized
INFO - 2024-10-21 10:00:40 --> Loader Class Initialized
INFO - 2024-10-21 10:00:40 --> Helper loaded: url_helper
INFO - 2024-10-21 10:00:40 --> Helper loaded: file_helper
INFO - 2024-10-21 10:00:40 --> Helper loaded: form_helper
INFO - 2024-10-21 10:00:40 --> Helper loaded: my_helper
INFO - 2024-10-21 10:00:40 --> Database Driver Class Initialized
INFO - 2024-10-21 10:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:00:40 --> Controller Class Initialized
DEBUG - 2024-10-21 10:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 10:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:00:40 --> Final output sent to browser
DEBUG - 2024-10-21 10:00:40 --> Total execution time: 0.2591
INFO - 2024-10-21 10:00:44 --> Config Class Initialized
INFO - 2024-10-21 10:00:44 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:00:44 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:00:44 --> Utf8 Class Initialized
INFO - 2024-10-21 10:00:44 --> URI Class Initialized
INFO - 2024-10-21 10:00:44 --> Router Class Initialized
INFO - 2024-10-21 10:00:44 --> Output Class Initialized
INFO - 2024-10-21 10:00:44 --> Security Class Initialized
DEBUG - 2024-10-21 10:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:00:44 --> Input Class Initialized
INFO - 2024-10-21 10:00:44 --> Language Class Initialized
INFO - 2024-10-21 10:00:44 --> Language Class Initialized
INFO - 2024-10-21 10:00:44 --> Config Class Initialized
INFO - 2024-10-21 10:00:44 --> Loader Class Initialized
INFO - 2024-10-21 10:00:44 --> Helper loaded: url_helper
INFO - 2024-10-21 10:00:44 --> Helper loaded: file_helper
INFO - 2024-10-21 10:00:44 --> Helper loaded: form_helper
INFO - 2024-10-21 10:00:44 --> Helper loaded: my_helper
INFO - 2024-10-21 10:00:44 --> Database Driver Class Initialized
INFO - 2024-10-21 10:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:00:44 --> Controller Class Initialized
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-21 10:00:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-21 10:00:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:00:53 --> Final output sent to browser
DEBUG - 2024-10-21 10:00:53 --> Total execution time: 9.6841
INFO - 2024-10-21 10:01:01 --> Config Class Initialized
INFO - 2024-10-21 10:01:01 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:01:02 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:01:02 --> Utf8 Class Initialized
INFO - 2024-10-21 10:01:02 --> URI Class Initialized
INFO - 2024-10-21 10:01:02 --> Router Class Initialized
INFO - 2024-10-21 10:01:02 --> Output Class Initialized
INFO - 2024-10-21 10:01:02 --> Security Class Initialized
DEBUG - 2024-10-21 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:01:02 --> Input Class Initialized
INFO - 2024-10-21 10:01:02 --> Language Class Initialized
INFO - 2024-10-21 10:01:02 --> Language Class Initialized
INFO - 2024-10-21 10:01:02 --> Config Class Initialized
INFO - 2024-10-21 10:01:02 --> Loader Class Initialized
INFO - 2024-10-21 10:01:02 --> Helper loaded: url_helper
INFO - 2024-10-21 10:01:02 --> Helper loaded: file_helper
INFO - 2024-10-21 10:01:02 --> Helper loaded: form_helper
INFO - 2024-10-21 10:01:02 --> Helper loaded: my_helper
INFO - 2024-10-21 10:01:02 --> Database Driver Class Initialized
INFO - 2024-10-21 10:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:01:02 --> Controller Class Initialized
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-21 10:01:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-21 10:01:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-21 10:01:11 --> Final output sent to browser
DEBUG - 2024-10-21 10:01:11 --> Total execution time: 9.5524
INFO - 2024-10-21 10:01:58 --> Config Class Initialized
INFO - 2024-10-21 10:01:58 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:01:58 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:01:58 --> Utf8 Class Initialized
INFO - 2024-10-21 10:01:58 --> URI Class Initialized
INFO - 2024-10-21 10:01:58 --> Router Class Initialized
INFO - 2024-10-21 10:01:58 --> Output Class Initialized
INFO - 2024-10-21 10:01:58 --> Security Class Initialized
DEBUG - 2024-10-21 10:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:01:58 --> Input Class Initialized
INFO - 2024-10-21 10:01:58 --> Language Class Initialized
INFO - 2024-10-21 10:01:58 --> Language Class Initialized
INFO - 2024-10-21 10:01:58 --> Config Class Initialized
INFO - 2024-10-21 10:01:58 --> Loader Class Initialized
INFO - 2024-10-21 10:01:58 --> Helper loaded: url_helper
INFO - 2024-10-21 10:01:58 --> Helper loaded: file_helper
INFO - 2024-10-21 10:01:58 --> Helper loaded: form_helper
INFO - 2024-10-21 10:01:58 --> Helper loaded: my_helper
INFO - 2024-10-21 10:01:58 --> Database Driver Class Initialized
INFO - 2024-10-21 10:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:01:59 --> Controller Class Initialized
INFO - 2024-10-21 10:01:59 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:01:59 --> Final output sent to browser
DEBUG - 2024-10-21 10:01:59 --> Total execution time: 0.5972
INFO - 2024-10-21 10:01:59 --> Config Class Initialized
INFO - 2024-10-21 10:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:01:59 --> Utf8 Class Initialized
INFO - 2024-10-21 10:01:59 --> URI Class Initialized
INFO - 2024-10-21 10:01:59 --> Router Class Initialized
INFO - 2024-10-21 10:01:59 --> Output Class Initialized
INFO - 2024-10-21 10:01:59 --> Security Class Initialized
DEBUG - 2024-10-21 10:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:01:59 --> Input Class Initialized
INFO - 2024-10-21 10:01:59 --> Language Class Initialized
INFO - 2024-10-21 10:01:59 --> Language Class Initialized
INFO - 2024-10-21 10:01:59 --> Config Class Initialized
INFO - 2024-10-21 10:01:59 --> Loader Class Initialized
INFO - 2024-10-21 10:01:59 --> Helper loaded: url_helper
INFO - 2024-10-21 10:01:59 --> Helper loaded: file_helper
INFO - 2024-10-21 10:01:59 --> Helper loaded: form_helper
INFO - 2024-10-21 10:01:59 --> Helper loaded: my_helper
INFO - 2024-10-21 10:01:59 --> Database Driver Class Initialized
INFO - 2024-10-21 10:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:01:59 --> Controller Class Initialized
INFO - 2024-10-21 10:01:59 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:01:59 --> Config Class Initialized
INFO - 2024-10-21 10:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:01:59 --> Utf8 Class Initialized
INFO - 2024-10-21 10:01:59 --> URI Class Initialized
INFO - 2024-10-21 10:01:59 --> Router Class Initialized
INFO - 2024-10-21 10:01:59 --> Output Class Initialized
INFO - 2024-10-21 10:01:59 --> Security Class Initialized
DEBUG - 2024-10-21 10:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:01:59 --> Input Class Initialized
INFO - 2024-10-21 10:01:59 --> Language Class Initialized
INFO - 2024-10-21 10:01:59 --> Language Class Initialized
INFO - 2024-10-21 10:01:59 --> Config Class Initialized
INFO - 2024-10-21 10:01:59 --> Loader Class Initialized
INFO - 2024-10-21 10:01:59 --> Helper loaded: url_helper
INFO - 2024-10-21 10:01:59 --> Helper loaded: file_helper
INFO - 2024-10-21 10:01:59 --> Helper loaded: form_helper
INFO - 2024-10-21 10:01:59 --> Helper loaded: my_helper
INFO - 2024-10-21 10:01:59 --> Database Driver Class Initialized
INFO - 2024-10-21 10:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:01:59 --> Controller Class Initialized
DEBUG - 2024-10-21 10:02:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 10:02:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:02:00 --> Final output sent to browser
DEBUG - 2024-10-21 10:02:00 --> Total execution time: 0.1581
INFO - 2024-10-21 10:02:01 --> Config Class Initialized
INFO - 2024-10-21 10:02:01 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:02:01 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:02:01 --> Utf8 Class Initialized
INFO - 2024-10-21 10:02:01 --> URI Class Initialized
INFO - 2024-10-21 10:02:01 --> Router Class Initialized
INFO - 2024-10-21 10:02:01 --> Output Class Initialized
INFO - 2024-10-21 10:02:01 --> Security Class Initialized
DEBUG - 2024-10-21 10:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:02:01 --> Input Class Initialized
INFO - 2024-10-21 10:02:01 --> Language Class Initialized
INFO - 2024-10-21 10:02:01 --> Language Class Initialized
INFO - 2024-10-21 10:02:01 --> Config Class Initialized
INFO - 2024-10-21 10:02:01 --> Loader Class Initialized
INFO - 2024-10-21 10:02:01 --> Helper loaded: url_helper
INFO - 2024-10-21 10:02:01 --> Helper loaded: file_helper
INFO - 2024-10-21 10:02:01 --> Helper loaded: form_helper
INFO - 2024-10-21 10:02:01 --> Helper loaded: my_helper
INFO - 2024-10-21 10:02:01 --> Database Driver Class Initialized
INFO - 2024-10-21 10:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:02:01 --> Controller Class Initialized
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-21 10:02:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-21 10:02:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:02:12 --> Final output sent to browser
DEBUG - 2024-10-21 10:02:12 --> Total execution time: 10.8153
INFO - 2024-10-21 10:02:48 --> Config Class Initialized
INFO - 2024-10-21 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:02:48 --> Utf8 Class Initialized
INFO - 2024-10-21 10:02:48 --> URI Class Initialized
INFO - 2024-10-21 10:02:48 --> Router Class Initialized
INFO - 2024-10-21 10:02:48 --> Output Class Initialized
INFO - 2024-10-21 10:02:48 --> Security Class Initialized
DEBUG - 2024-10-21 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:02:48 --> Input Class Initialized
INFO - 2024-10-21 10:02:48 --> Language Class Initialized
INFO - 2024-10-21 10:02:48 --> Language Class Initialized
INFO - 2024-10-21 10:02:48 --> Config Class Initialized
INFO - 2024-10-21 10:02:48 --> Loader Class Initialized
INFO - 2024-10-21 10:02:48 --> Helper loaded: url_helper
INFO - 2024-10-21 10:02:48 --> Helper loaded: file_helper
INFO - 2024-10-21 10:02:48 --> Helper loaded: form_helper
INFO - 2024-10-21 10:02:48 --> Helper loaded: my_helper
INFO - 2024-10-21 10:02:48 --> Database Driver Class Initialized
INFO - 2024-10-21 10:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:02:48 --> Controller Class Initialized
INFO - 2024-10-21 10:02:48 --> Config Class Initialized
INFO - 2024-10-21 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:02:48 --> Utf8 Class Initialized
INFO - 2024-10-21 10:02:48 --> URI Class Initialized
INFO - 2024-10-21 10:02:48 --> Router Class Initialized
INFO - 2024-10-21 10:02:48 --> Output Class Initialized
INFO - 2024-10-21 10:02:48 --> Security Class Initialized
DEBUG - 2024-10-21 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:02:48 --> Input Class Initialized
INFO - 2024-10-21 10:02:48 --> Language Class Initialized
INFO - 2024-10-21 10:02:48 --> Language Class Initialized
INFO - 2024-10-21 10:02:48 --> Config Class Initialized
INFO - 2024-10-21 10:02:48 --> Loader Class Initialized
INFO - 2024-10-21 10:02:48 --> Helper loaded: url_helper
INFO - 2024-10-21 10:02:48 --> Helper loaded: file_helper
INFO - 2024-10-21 10:02:48 --> Helper loaded: form_helper
INFO - 2024-10-21 10:02:48 --> Helper loaded: my_helper
INFO - 2024-10-21 10:02:48 --> Database Driver Class Initialized
INFO - 2024-10-21 10:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:02:48 --> Controller Class Initialized
DEBUG - 2024-10-21 10:02:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-21 10:02:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:02:48 --> Final output sent to browser
DEBUG - 2024-10-21 10:02:48 --> Total execution time: 0.1246
INFO - 2024-10-21 10:02:50 --> Config Class Initialized
INFO - 2024-10-21 10:02:50 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:02:50 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:02:50 --> Utf8 Class Initialized
INFO - 2024-10-21 10:02:50 --> URI Class Initialized
INFO - 2024-10-21 10:02:50 --> Router Class Initialized
INFO - 2024-10-21 10:02:50 --> Output Class Initialized
INFO - 2024-10-21 10:02:50 --> Security Class Initialized
DEBUG - 2024-10-21 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:02:50 --> Input Class Initialized
INFO - 2024-10-21 10:02:50 --> Language Class Initialized
INFO - 2024-10-21 10:02:50 --> Language Class Initialized
INFO - 2024-10-21 10:02:50 --> Config Class Initialized
INFO - 2024-10-21 10:02:50 --> Loader Class Initialized
INFO - 2024-10-21 10:02:50 --> Helper loaded: url_helper
INFO - 2024-10-21 10:02:50 --> Helper loaded: file_helper
INFO - 2024-10-21 10:02:50 --> Helper loaded: form_helper
INFO - 2024-10-21 10:02:50 --> Helper loaded: my_helper
INFO - 2024-10-21 10:02:50 --> Database Driver Class Initialized
INFO - 2024-10-21 10:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:02:50 --> Controller Class Initialized
INFO - 2024-10-21 10:02:51 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:02:51 --> Final output sent to browser
DEBUG - 2024-10-21 10:02:51 --> Total execution time: 0.3320
INFO - 2024-10-21 10:02:51 --> Config Class Initialized
INFO - 2024-10-21 10:02:51 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:02:51 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:02:51 --> Utf8 Class Initialized
INFO - 2024-10-21 10:02:51 --> URI Class Initialized
INFO - 2024-10-21 10:02:51 --> Router Class Initialized
INFO - 2024-10-21 10:02:51 --> Output Class Initialized
INFO - 2024-10-21 10:02:51 --> Security Class Initialized
DEBUG - 2024-10-21 10:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:02:51 --> Input Class Initialized
INFO - 2024-10-21 10:02:51 --> Language Class Initialized
INFO - 2024-10-21 10:02:51 --> Language Class Initialized
INFO - 2024-10-21 10:02:51 --> Config Class Initialized
INFO - 2024-10-21 10:02:51 --> Loader Class Initialized
INFO - 2024-10-21 10:02:51 --> Helper loaded: url_helper
INFO - 2024-10-21 10:02:51 --> Helper loaded: file_helper
INFO - 2024-10-21 10:02:51 --> Helper loaded: form_helper
INFO - 2024-10-21 10:02:51 --> Helper loaded: my_helper
INFO - 2024-10-21 10:02:51 --> Database Driver Class Initialized
INFO - 2024-10-21 10:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:02:51 --> Controller Class Initialized
DEBUG - 2024-10-21 10:02:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-21 10:02:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:02:51 --> Final output sent to browser
DEBUG - 2024-10-21 10:02:51 --> Total execution time: 0.5067
INFO - 2024-10-21 10:02:57 --> Config Class Initialized
INFO - 2024-10-21 10:02:57 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:02:57 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:02:57 --> Utf8 Class Initialized
INFO - 2024-10-21 10:02:57 --> URI Class Initialized
INFO - 2024-10-21 10:02:57 --> Router Class Initialized
INFO - 2024-10-21 10:02:57 --> Output Class Initialized
INFO - 2024-10-21 10:02:57 --> Security Class Initialized
DEBUG - 2024-10-21 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:02:57 --> Input Class Initialized
INFO - 2024-10-21 10:02:57 --> Language Class Initialized
INFO - 2024-10-21 10:02:57 --> Language Class Initialized
INFO - 2024-10-21 10:02:57 --> Config Class Initialized
INFO - 2024-10-21 10:02:57 --> Loader Class Initialized
INFO - 2024-10-21 10:02:57 --> Helper loaded: url_helper
INFO - 2024-10-21 10:02:57 --> Helper loaded: file_helper
INFO - 2024-10-21 10:02:57 --> Helper loaded: form_helper
INFO - 2024-10-21 10:02:57 --> Helper loaded: my_helper
INFO - 2024-10-21 10:02:57 --> Database Driver Class Initialized
INFO - 2024-10-21 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:02:57 --> Controller Class Initialized
DEBUG - 2024-10-21 10:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-21 10:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:02:57 --> Final output sent to browser
DEBUG - 2024-10-21 10:02:57 --> Total execution time: 0.2547
INFO - 2024-10-21 10:03:02 --> Config Class Initialized
INFO - 2024-10-21 10:03:02 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:03:02 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:03:02 --> Utf8 Class Initialized
INFO - 2024-10-21 10:03:02 --> URI Class Initialized
INFO - 2024-10-21 10:03:02 --> Router Class Initialized
INFO - 2024-10-21 10:03:02 --> Output Class Initialized
INFO - 2024-10-21 10:03:02 --> Security Class Initialized
DEBUG - 2024-10-21 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:03:02 --> Input Class Initialized
INFO - 2024-10-21 10:03:02 --> Language Class Initialized
INFO - 2024-10-21 10:03:02 --> Language Class Initialized
INFO - 2024-10-21 10:03:02 --> Config Class Initialized
INFO - 2024-10-21 10:03:02 --> Loader Class Initialized
INFO - 2024-10-21 10:03:02 --> Helper loaded: url_helper
INFO - 2024-10-21 10:03:02 --> Helper loaded: file_helper
INFO - 2024-10-21 10:03:02 --> Helper loaded: form_helper
INFO - 2024-10-21 10:03:02 --> Helper loaded: my_helper
INFO - 2024-10-21 10:03:02 --> Database Driver Class Initialized
INFO - 2024-10-21 10:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:03:02 --> Controller Class Initialized
DEBUG - 2024-10-21 10:03:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:03:14 --> Final output sent to browser
DEBUG - 2024-10-21 10:03:14 --> Total execution time: 12.4392
INFO - 2024-10-21 10:04:01 --> Config Class Initialized
INFO - 2024-10-21 10:04:01 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:04:01 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:04:01 --> Utf8 Class Initialized
INFO - 2024-10-21 10:04:01 --> URI Class Initialized
INFO - 2024-10-21 10:04:01 --> Router Class Initialized
INFO - 2024-10-21 10:04:01 --> Output Class Initialized
INFO - 2024-10-21 10:04:01 --> Security Class Initialized
DEBUG - 2024-10-21 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:04:01 --> Input Class Initialized
INFO - 2024-10-21 10:04:01 --> Language Class Initialized
INFO - 2024-10-21 10:04:01 --> Language Class Initialized
INFO - 2024-10-21 10:04:01 --> Config Class Initialized
INFO - 2024-10-21 10:04:01 --> Loader Class Initialized
INFO - 2024-10-21 10:04:01 --> Helper loaded: url_helper
INFO - 2024-10-21 10:04:01 --> Helper loaded: file_helper
INFO - 2024-10-21 10:04:01 --> Helper loaded: form_helper
INFO - 2024-10-21 10:04:01 --> Helper loaded: my_helper
INFO - 2024-10-21 10:04:01 --> Database Driver Class Initialized
INFO - 2024-10-21 10:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:04:01 --> Controller Class Initialized
DEBUG - 2024-10-21 10:04:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:04:11 --> Final output sent to browser
DEBUG - 2024-10-21 10:04:11 --> Total execution time: 10.5215
INFO - 2024-10-21 10:05:11 --> Config Class Initialized
INFO - 2024-10-21 10:05:11 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:11 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:11 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:11 --> URI Class Initialized
INFO - 2024-10-21 10:05:11 --> Router Class Initialized
INFO - 2024-10-21 10:05:11 --> Output Class Initialized
INFO - 2024-10-21 10:05:11 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:11 --> Input Class Initialized
INFO - 2024-10-21 10:05:11 --> Language Class Initialized
INFO - 2024-10-21 10:05:11 --> Language Class Initialized
INFO - 2024-10-21 10:05:11 --> Config Class Initialized
INFO - 2024-10-21 10:05:11 --> Loader Class Initialized
INFO - 2024-10-21 10:05:11 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:11 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:11 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:11 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:11 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:11 --> Controller Class Initialized
INFO - 2024-10-21 10:05:11 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:05:11 --> Final output sent to browser
DEBUG - 2024-10-21 10:05:11 --> Total execution time: 0.2480
INFO - 2024-10-21 10:05:12 --> Config Class Initialized
INFO - 2024-10-21 10:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:12 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:12 --> URI Class Initialized
INFO - 2024-10-21 10:05:12 --> Router Class Initialized
INFO - 2024-10-21 10:05:12 --> Output Class Initialized
INFO - 2024-10-21 10:05:12 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:12 --> Input Class Initialized
INFO - 2024-10-21 10:05:12 --> Language Class Initialized
INFO - 2024-10-21 10:05:12 --> Language Class Initialized
INFO - 2024-10-21 10:05:12 --> Config Class Initialized
INFO - 2024-10-21 10:05:12 --> Loader Class Initialized
INFO - 2024-10-21 10:05:12 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:12 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:12 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:12 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:12 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:12 --> Controller Class Initialized
INFO - 2024-10-21 10:05:12 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:05:12 --> Config Class Initialized
INFO - 2024-10-21 10:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:12 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:12 --> URI Class Initialized
INFO - 2024-10-21 10:05:12 --> Router Class Initialized
INFO - 2024-10-21 10:05:12 --> Output Class Initialized
INFO - 2024-10-21 10:05:12 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:12 --> Input Class Initialized
INFO - 2024-10-21 10:05:12 --> Language Class Initialized
INFO - 2024-10-21 10:05:12 --> Language Class Initialized
INFO - 2024-10-21 10:05:12 --> Config Class Initialized
INFO - 2024-10-21 10:05:12 --> Loader Class Initialized
INFO - 2024-10-21 10:05:12 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:12 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:12 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:12 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:12 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:12 --> Controller Class Initialized
DEBUG - 2024-10-21 10:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 10:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:05:13 --> Final output sent to browser
DEBUG - 2024-10-21 10:05:13 --> Total execution time: 0.2481
INFO - 2024-10-21 10:05:17 --> Config Class Initialized
INFO - 2024-10-21 10:05:17 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:17 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:17 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:17 --> URI Class Initialized
INFO - 2024-10-21 10:05:17 --> Router Class Initialized
INFO - 2024-10-21 10:05:17 --> Output Class Initialized
INFO - 2024-10-21 10:05:17 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:17 --> Input Class Initialized
INFO - 2024-10-21 10:05:17 --> Language Class Initialized
INFO - 2024-10-21 10:05:17 --> Language Class Initialized
INFO - 2024-10-21 10:05:17 --> Config Class Initialized
INFO - 2024-10-21 10:05:17 --> Loader Class Initialized
INFO - 2024-10-21 10:05:17 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:17 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:17 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:17 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:17 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:18 --> Controller Class Initialized
DEBUG - 2024-10-21 10:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:05:28 --> Final output sent to browser
DEBUG - 2024-10-21 10:05:28 --> Total execution time: 10.6421
INFO - 2024-10-21 10:05:46 --> Config Class Initialized
INFO - 2024-10-21 10:05:46 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:46 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:46 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:46 --> URI Class Initialized
INFO - 2024-10-21 10:05:46 --> Router Class Initialized
INFO - 2024-10-21 10:05:46 --> Output Class Initialized
INFO - 2024-10-21 10:05:46 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:46 --> Input Class Initialized
INFO - 2024-10-21 10:05:46 --> Language Class Initialized
INFO - 2024-10-21 10:05:46 --> Language Class Initialized
INFO - 2024-10-21 10:05:46 --> Config Class Initialized
INFO - 2024-10-21 10:05:46 --> Loader Class Initialized
INFO - 2024-10-21 10:05:46 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:46 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:46 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:46 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:47 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:47 --> Controller Class Initialized
INFO - 2024-10-21 10:05:47 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:05:47 --> Final output sent to browser
DEBUG - 2024-10-21 10:05:47 --> Total execution time: 0.4206
INFO - 2024-10-21 10:05:47 --> Config Class Initialized
INFO - 2024-10-21 10:05:47 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:47 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:47 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:47 --> URI Class Initialized
INFO - 2024-10-21 10:05:47 --> Router Class Initialized
INFO - 2024-10-21 10:05:47 --> Output Class Initialized
INFO - 2024-10-21 10:05:47 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:47 --> Input Class Initialized
INFO - 2024-10-21 10:05:47 --> Language Class Initialized
INFO - 2024-10-21 10:05:47 --> Language Class Initialized
INFO - 2024-10-21 10:05:47 --> Config Class Initialized
INFO - 2024-10-21 10:05:47 --> Loader Class Initialized
INFO - 2024-10-21 10:05:47 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:47 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:47 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:47 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:47 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:47 --> Controller Class Initialized
INFO - 2024-10-21 10:05:47 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:05:47 --> Config Class Initialized
INFO - 2024-10-21 10:05:47 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:47 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:47 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:47 --> URI Class Initialized
INFO - 2024-10-21 10:05:47 --> Router Class Initialized
INFO - 2024-10-21 10:05:47 --> Output Class Initialized
INFO - 2024-10-21 10:05:47 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:47 --> Input Class Initialized
INFO - 2024-10-21 10:05:47 --> Language Class Initialized
INFO - 2024-10-21 10:05:47 --> Language Class Initialized
INFO - 2024-10-21 10:05:47 --> Config Class Initialized
INFO - 2024-10-21 10:05:47 --> Loader Class Initialized
INFO - 2024-10-21 10:05:47 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:47 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:47 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:47 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:47 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:47 --> Controller Class Initialized
DEBUG - 2024-10-21 10:05:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 10:05:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:05:47 --> Final output sent to browser
DEBUG - 2024-10-21 10:05:47 --> Total execution time: 0.1096
INFO - 2024-10-21 10:05:52 --> Config Class Initialized
INFO - 2024-10-21 10:05:52 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:05:52 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:05:52 --> Utf8 Class Initialized
INFO - 2024-10-21 10:05:52 --> URI Class Initialized
INFO - 2024-10-21 10:05:52 --> Router Class Initialized
INFO - 2024-10-21 10:05:52 --> Output Class Initialized
INFO - 2024-10-21 10:05:52 --> Security Class Initialized
DEBUG - 2024-10-21 10:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:05:52 --> Input Class Initialized
INFO - 2024-10-21 10:05:52 --> Language Class Initialized
INFO - 2024-10-21 10:05:52 --> Language Class Initialized
INFO - 2024-10-21 10:05:52 --> Config Class Initialized
INFO - 2024-10-21 10:05:52 --> Loader Class Initialized
INFO - 2024-10-21 10:05:52 --> Helper loaded: url_helper
INFO - 2024-10-21 10:05:52 --> Helper loaded: file_helper
INFO - 2024-10-21 10:05:52 --> Helper loaded: form_helper
INFO - 2024-10-21 10:05:52 --> Helper loaded: my_helper
INFO - 2024-10-21 10:05:52 --> Database Driver Class Initialized
INFO - 2024-10-21 10:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:05:52 --> Controller Class Initialized
DEBUG - 2024-10-21 10:05:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:06:01 --> Final output sent to browser
DEBUG - 2024-10-21 10:06:01 --> Total execution time: 8.6551
INFO - 2024-10-21 10:06:07 --> Config Class Initialized
INFO - 2024-10-21 10:06:07 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:06:07 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:06:07 --> Utf8 Class Initialized
INFO - 2024-10-21 10:06:07 --> URI Class Initialized
INFO - 2024-10-21 10:06:07 --> Router Class Initialized
INFO - 2024-10-21 10:06:07 --> Output Class Initialized
INFO - 2024-10-21 10:06:07 --> Security Class Initialized
DEBUG - 2024-10-21 10:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:06:07 --> Input Class Initialized
INFO - 2024-10-21 10:06:07 --> Language Class Initialized
INFO - 2024-10-21 10:06:07 --> Language Class Initialized
INFO - 2024-10-21 10:06:07 --> Config Class Initialized
INFO - 2024-10-21 10:06:07 --> Loader Class Initialized
INFO - 2024-10-21 10:06:07 --> Helper loaded: url_helper
INFO - 2024-10-21 10:06:07 --> Helper loaded: file_helper
INFO - 2024-10-21 10:06:07 --> Helper loaded: form_helper
INFO - 2024-10-21 10:06:07 --> Helper loaded: my_helper
INFO - 2024-10-21 10:06:07 --> Database Driver Class Initialized
INFO - 2024-10-21 10:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:06:07 --> Controller Class Initialized
INFO - 2024-10-21 10:06:07 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:06:07 --> Final output sent to browser
DEBUG - 2024-10-21 10:06:07 --> Total execution time: 0.3884
INFO - 2024-10-21 10:06:07 --> Config Class Initialized
INFO - 2024-10-21 10:06:07 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:06:07 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:06:07 --> Utf8 Class Initialized
INFO - 2024-10-21 10:06:07 --> URI Class Initialized
INFO - 2024-10-21 10:06:07 --> Router Class Initialized
INFO - 2024-10-21 10:06:07 --> Output Class Initialized
INFO - 2024-10-21 10:06:07 --> Security Class Initialized
DEBUG - 2024-10-21 10:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:06:07 --> Input Class Initialized
INFO - 2024-10-21 10:06:07 --> Language Class Initialized
INFO - 2024-10-21 10:06:07 --> Language Class Initialized
INFO - 2024-10-21 10:06:07 --> Config Class Initialized
INFO - 2024-10-21 10:06:07 --> Loader Class Initialized
INFO - 2024-10-21 10:06:07 --> Helper loaded: url_helper
INFO - 2024-10-21 10:06:07 --> Helper loaded: file_helper
INFO - 2024-10-21 10:06:07 --> Helper loaded: form_helper
INFO - 2024-10-21 10:06:07 --> Helper loaded: my_helper
INFO - 2024-10-21 10:06:08 --> Database Driver Class Initialized
INFO - 2024-10-21 10:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:06:08 --> Controller Class Initialized
INFO - 2024-10-21 10:06:08 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:06:20 --> Config Class Initialized
INFO - 2024-10-21 10:06:20 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:06:20 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:06:20 --> Utf8 Class Initialized
INFO - 2024-10-21 10:06:20 --> URI Class Initialized
INFO - 2024-10-21 10:06:20 --> Router Class Initialized
INFO - 2024-10-21 10:06:20 --> Output Class Initialized
INFO - 2024-10-21 10:06:20 --> Security Class Initialized
DEBUG - 2024-10-21 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:06:20 --> Input Class Initialized
INFO - 2024-10-21 10:06:20 --> Language Class Initialized
INFO - 2024-10-21 10:06:20 --> Language Class Initialized
INFO - 2024-10-21 10:06:20 --> Config Class Initialized
INFO - 2024-10-21 10:06:20 --> Loader Class Initialized
INFO - 2024-10-21 10:06:20 --> Helper loaded: url_helper
INFO - 2024-10-21 10:06:20 --> Helper loaded: file_helper
INFO - 2024-10-21 10:06:20 --> Helper loaded: form_helper
INFO - 2024-10-21 10:06:20 --> Helper loaded: my_helper
INFO - 2024-10-21 10:06:20 --> Database Driver Class Initialized
INFO - 2024-10-21 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:06:20 --> Controller Class Initialized
INFO - 2024-10-21 10:06:20 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:06:20 --> Final output sent to browser
DEBUG - 2024-10-21 10:06:20 --> Total execution time: 0.2571
INFO - 2024-10-21 10:06:21 --> Config Class Initialized
INFO - 2024-10-21 10:06:21 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:06:21 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:06:21 --> Utf8 Class Initialized
INFO - 2024-10-21 10:06:21 --> URI Class Initialized
INFO - 2024-10-21 10:06:21 --> Router Class Initialized
INFO - 2024-10-21 10:06:21 --> Output Class Initialized
INFO - 2024-10-21 10:06:21 --> Security Class Initialized
DEBUG - 2024-10-21 10:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:06:21 --> Input Class Initialized
INFO - 2024-10-21 10:06:21 --> Language Class Initialized
INFO - 2024-10-21 10:06:21 --> Language Class Initialized
INFO - 2024-10-21 10:06:21 --> Config Class Initialized
INFO - 2024-10-21 10:06:21 --> Loader Class Initialized
INFO - 2024-10-21 10:06:21 --> Helper loaded: url_helper
INFO - 2024-10-21 10:06:21 --> Helper loaded: file_helper
INFO - 2024-10-21 10:06:21 --> Helper loaded: form_helper
INFO - 2024-10-21 10:06:21 --> Helper loaded: my_helper
INFO - 2024-10-21 10:06:21 --> Database Driver Class Initialized
INFO - 2024-10-21 10:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:06:21 --> Controller Class Initialized
INFO - 2024-10-21 10:06:21 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:06:21 --> Config Class Initialized
INFO - 2024-10-21 10:06:21 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:06:21 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:06:21 --> Utf8 Class Initialized
INFO - 2024-10-21 10:06:21 --> URI Class Initialized
INFO - 2024-10-21 10:06:21 --> Router Class Initialized
INFO - 2024-10-21 10:06:21 --> Output Class Initialized
INFO - 2024-10-21 10:06:21 --> Security Class Initialized
DEBUG - 2024-10-21 10:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:06:21 --> Input Class Initialized
INFO - 2024-10-21 10:06:21 --> Language Class Initialized
INFO - 2024-10-21 10:06:21 --> Language Class Initialized
INFO - 2024-10-21 10:06:21 --> Config Class Initialized
INFO - 2024-10-21 10:06:21 --> Loader Class Initialized
INFO - 2024-10-21 10:06:21 --> Helper loaded: url_helper
INFO - 2024-10-21 10:06:21 --> Helper loaded: file_helper
INFO - 2024-10-21 10:06:21 --> Helper loaded: form_helper
INFO - 2024-10-21 10:06:21 --> Helper loaded: my_helper
INFO - 2024-10-21 10:06:21 --> Database Driver Class Initialized
INFO - 2024-10-21 10:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:06:21 --> Controller Class Initialized
DEBUG - 2024-10-21 10:06:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 10:06:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:06:21 --> Final output sent to browser
DEBUG - 2024-10-21 10:06:21 --> Total execution time: 0.1557
INFO - 2024-10-21 10:06:34 --> Config Class Initialized
INFO - 2024-10-21 10:06:34 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:06:34 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:06:34 --> Utf8 Class Initialized
INFO - 2024-10-21 10:06:34 --> URI Class Initialized
INFO - 2024-10-21 10:06:34 --> Router Class Initialized
INFO - 2024-10-21 10:06:34 --> Output Class Initialized
INFO - 2024-10-21 10:06:34 --> Security Class Initialized
DEBUG - 2024-10-21 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:06:34 --> Input Class Initialized
INFO - 2024-10-21 10:06:34 --> Language Class Initialized
INFO - 2024-10-21 10:06:34 --> Language Class Initialized
INFO - 2024-10-21 10:06:34 --> Config Class Initialized
INFO - 2024-10-21 10:06:34 --> Loader Class Initialized
INFO - 2024-10-21 10:06:34 --> Helper loaded: url_helper
INFO - 2024-10-21 10:06:34 --> Helper loaded: file_helper
INFO - 2024-10-21 10:06:34 --> Helper loaded: form_helper
INFO - 2024-10-21 10:06:34 --> Helper loaded: my_helper
INFO - 2024-10-21 10:06:34 --> Database Driver Class Initialized
INFO - 2024-10-21 10:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:06:34 --> Controller Class Initialized
DEBUG - 2024-10-21 10:06:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 10:06:44 --> Final output sent to browser
DEBUG - 2024-10-21 10:06:44 --> Total execution time: 10.0173
INFO - 2024-10-21 10:10:27 --> Config Class Initialized
INFO - 2024-10-21 10:10:27 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:10:27 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:10:27 --> Utf8 Class Initialized
INFO - 2024-10-21 10:10:27 --> URI Class Initialized
INFO - 2024-10-21 10:10:27 --> Router Class Initialized
INFO - 2024-10-21 10:10:27 --> Output Class Initialized
INFO - 2024-10-21 10:10:27 --> Security Class Initialized
DEBUG - 2024-10-21 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:10:27 --> Input Class Initialized
INFO - 2024-10-21 10:10:27 --> Language Class Initialized
INFO - 2024-10-21 10:10:27 --> Language Class Initialized
INFO - 2024-10-21 10:10:27 --> Config Class Initialized
INFO - 2024-10-21 10:10:27 --> Loader Class Initialized
INFO - 2024-10-21 10:10:28 --> Helper loaded: url_helper
INFO - 2024-10-21 10:10:28 --> Helper loaded: file_helper
INFO - 2024-10-21 10:10:28 --> Helper loaded: form_helper
INFO - 2024-10-21 10:10:28 --> Helper loaded: my_helper
INFO - 2024-10-21 10:10:28 --> Database Driver Class Initialized
INFO - 2024-10-21 10:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:10:28 --> Controller Class Initialized
DEBUG - 2024-10-21 10:10:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-21 10:10:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:10:28 --> Final output sent to browser
DEBUG - 2024-10-21 10:10:28 --> Total execution time: 0.5520
INFO - 2024-10-21 10:10:35 --> Config Class Initialized
INFO - 2024-10-21 10:10:35 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:10:35 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:10:35 --> Utf8 Class Initialized
INFO - 2024-10-21 10:10:35 --> URI Class Initialized
INFO - 2024-10-21 10:10:35 --> Router Class Initialized
INFO - 2024-10-21 10:10:35 --> Output Class Initialized
INFO - 2024-10-21 10:10:35 --> Security Class Initialized
DEBUG - 2024-10-21 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:10:35 --> Input Class Initialized
INFO - 2024-10-21 10:10:35 --> Language Class Initialized
INFO - 2024-10-21 10:10:35 --> Language Class Initialized
INFO - 2024-10-21 10:10:35 --> Config Class Initialized
INFO - 2024-10-21 10:10:35 --> Loader Class Initialized
INFO - 2024-10-21 10:10:35 --> Helper loaded: url_helper
INFO - 2024-10-21 10:10:35 --> Helper loaded: file_helper
INFO - 2024-10-21 10:10:35 --> Helper loaded: form_helper
INFO - 2024-10-21 10:10:35 --> Helper loaded: my_helper
INFO - 2024-10-21 10:10:35 --> Database Driver Class Initialized
INFO - 2024-10-21 10:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:10:35 --> Controller Class Initialized
INFO - 2024-10-21 10:10:36 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:10:36 --> Final output sent to browser
DEBUG - 2024-10-21 10:10:36 --> Total execution time: 0.9327
INFO - 2024-10-21 10:10:36 --> Config Class Initialized
INFO - 2024-10-21 10:10:36 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:10:36 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:10:36 --> Utf8 Class Initialized
INFO - 2024-10-21 10:10:36 --> URI Class Initialized
INFO - 2024-10-21 10:10:36 --> Router Class Initialized
INFO - 2024-10-21 10:10:36 --> Output Class Initialized
INFO - 2024-10-21 10:10:36 --> Security Class Initialized
DEBUG - 2024-10-21 10:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:10:36 --> Input Class Initialized
INFO - 2024-10-21 10:10:36 --> Language Class Initialized
INFO - 2024-10-21 10:10:36 --> Language Class Initialized
INFO - 2024-10-21 10:10:36 --> Config Class Initialized
INFO - 2024-10-21 10:10:36 --> Loader Class Initialized
INFO - 2024-10-21 10:10:36 --> Helper loaded: url_helper
INFO - 2024-10-21 10:10:36 --> Helper loaded: file_helper
INFO - 2024-10-21 10:10:36 --> Helper loaded: form_helper
INFO - 2024-10-21 10:10:36 --> Helper loaded: my_helper
INFO - 2024-10-21 10:10:36 --> Database Driver Class Initialized
INFO - 2024-10-21 10:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:10:36 --> Controller Class Initialized
DEBUG - 2024-10-21 10:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-21 10:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:10:38 --> Final output sent to browser
DEBUG - 2024-10-21 10:10:38 --> Total execution time: 1.4260
INFO - 2024-10-21 10:10:39 --> Config Class Initialized
INFO - 2024-10-21 10:10:39 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:10:39 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:10:39 --> Utf8 Class Initialized
INFO - 2024-10-21 10:10:39 --> URI Class Initialized
INFO - 2024-10-21 10:10:39 --> Router Class Initialized
INFO - 2024-10-21 10:10:39 --> Output Class Initialized
INFO - 2024-10-21 10:10:39 --> Security Class Initialized
DEBUG - 2024-10-21 10:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:10:39 --> Input Class Initialized
INFO - 2024-10-21 10:10:39 --> Language Class Initialized
INFO - 2024-10-21 10:10:39 --> Language Class Initialized
INFO - 2024-10-21 10:10:39 --> Config Class Initialized
INFO - 2024-10-21 10:10:39 --> Loader Class Initialized
INFO - 2024-10-21 10:10:39 --> Helper loaded: url_helper
INFO - 2024-10-21 10:10:39 --> Helper loaded: file_helper
INFO - 2024-10-21 10:10:39 --> Helper loaded: form_helper
INFO - 2024-10-21 10:10:39 --> Helper loaded: my_helper
INFO - 2024-10-21 10:10:39 --> Database Driver Class Initialized
INFO - 2024-10-21 10:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:10:40 --> Controller Class Initialized
DEBUG - 2024-10-21 10:10:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-21 10:10:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:10:40 --> Final output sent to browser
DEBUG - 2024-10-21 10:10:40 --> Total execution time: 0.3870
INFO - 2024-10-21 10:10:40 --> Config Class Initialized
INFO - 2024-10-21 10:10:40 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:10:40 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:10:40 --> Utf8 Class Initialized
INFO - 2024-10-21 10:10:40 --> URI Class Initialized
INFO - 2024-10-21 10:10:40 --> Router Class Initialized
INFO - 2024-10-21 10:10:40 --> Output Class Initialized
INFO - 2024-10-21 10:10:40 --> Security Class Initialized
DEBUG - 2024-10-21 10:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:10:40 --> Input Class Initialized
INFO - 2024-10-21 10:10:40 --> Language Class Initialized
ERROR - 2024-10-21 10:10:40 --> 404 Page Not Found: /index
INFO - 2024-10-21 10:10:40 --> Config Class Initialized
INFO - 2024-10-21 10:10:40 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:10:40 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:10:40 --> Utf8 Class Initialized
INFO - 2024-10-21 10:10:40 --> URI Class Initialized
INFO - 2024-10-21 10:10:40 --> Router Class Initialized
INFO - 2024-10-21 10:10:40 --> Output Class Initialized
INFO - 2024-10-21 10:10:40 --> Security Class Initialized
DEBUG - 2024-10-21 10:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:10:40 --> Input Class Initialized
INFO - 2024-10-21 10:10:40 --> Language Class Initialized
INFO - 2024-10-21 10:10:40 --> Language Class Initialized
INFO - 2024-10-21 10:10:40 --> Config Class Initialized
INFO - 2024-10-21 10:10:40 --> Loader Class Initialized
INFO - 2024-10-21 10:10:40 --> Helper loaded: url_helper
INFO - 2024-10-21 10:10:40 --> Helper loaded: file_helper
INFO - 2024-10-21 10:10:40 --> Helper loaded: form_helper
INFO - 2024-10-21 10:10:40 --> Helper loaded: my_helper
INFO - 2024-10-21 10:10:40 --> Database Driver Class Initialized
INFO - 2024-10-21 10:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:10:40 --> Controller Class Initialized
INFO - 2024-10-21 10:26:08 --> Config Class Initialized
INFO - 2024-10-21 10:26:08 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:26:08 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:26:08 --> Utf8 Class Initialized
INFO - 2024-10-21 10:26:08 --> URI Class Initialized
INFO - 2024-10-21 10:26:08 --> Router Class Initialized
INFO - 2024-10-21 10:26:08 --> Output Class Initialized
INFO - 2024-10-21 10:26:08 --> Security Class Initialized
DEBUG - 2024-10-21 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:26:09 --> Input Class Initialized
INFO - 2024-10-21 10:26:09 --> Language Class Initialized
INFO - 2024-10-21 10:26:09 --> Language Class Initialized
INFO - 2024-10-21 10:26:09 --> Config Class Initialized
INFO - 2024-10-21 10:26:09 --> Loader Class Initialized
INFO - 2024-10-21 10:26:09 --> Helper loaded: url_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: file_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: form_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: my_helper
INFO - 2024-10-21 10:26:09 --> Database Driver Class Initialized
INFO - 2024-10-21 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:26:09 --> Controller Class Initialized
INFO - 2024-10-21 10:26:09 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:26:09 --> Final output sent to browser
DEBUG - 2024-10-21 10:26:09 --> Total execution time: 0.5470
INFO - 2024-10-21 10:26:09 --> Config Class Initialized
INFO - 2024-10-21 10:26:09 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:26:09 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:26:09 --> Utf8 Class Initialized
INFO - 2024-10-21 10:26:09 --> URI Class Initialized
INFO - 2024-10-21 10:26:09 --> Router Class Initialized
INFO - 2024-10-21 10:26:09 --> Output Class Initialized
INFO - 2024-10-21 10:26:09 --> Security Class Initialized
DEBUG - 2024-10-21 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:26:09 --> Input Class Initialized
INFO - 2024-10-21 10:26:09 --> Language Class Initialized
INFO - 2024-10-21 10:26:09 --> Language Class Initialized
INFO - 2024-10-21 10:26:09 --> Config Class Initialized
INFO - 2024-10-21 10:26:09 --> Loader Class Initialized
INFO - 2024-10-21 10:26:09 --> Helper loaded: url_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: file_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: form_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: my_helper
INFO - 2024-10-21 10:26:09 --> Database Driver Class Initialized
INFO - 2024-10-21 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:26:09 --> Controller Class Initialized
INFO - 2024-10-21 10:26:09 --> Helper loaded: cookie_helper
INFO - 2024-10-21 10:26:09 --> Config Class Initialized
INFO - 2024-10-21 10:26:09 --> Hooks Class Initialized
DEBUG - 2024-10-21 10:26:09 --> UTF-8 Support Enabled
INFO - 2024-10-21 10:26:09 --> Utf8 Class Initialized
INFO - 2024-10-21 10:26:09 --> URI Class Initialized
INFO - 2024-10-21 10:26:09 --> Router Class Initialized
INFO - 2024-10-21 10:26:09 --> Output Class Initialized
INFO - 2024-10-21 10:26:09 --> Security Class Initialized
DEBUG - 2024-10-21 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 10:26:09 --> Input Class Initialized
INFO - 2024-10-21 10:26:09 --> Language Class Initialized
INFO - 2024-10-21 10:26:09 --> Language Class Initialized
INFO - 2024-10-21 10:26:09 --> Config Class Initialized
INFO - 2024-10-21 10:26:09 --> Loader Class Initialized
INFO - 2024-10-21 10:26:09 --> Helper loaded: url_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: file_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: form_helper
INFO - 2024-10-21 10:26:09 --> Helper loaded: my_helper
INFO - 2024-10-21 10:26:09 --> Database Driver Class Initialized
INFO - 2024-10-21 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 10:26:09 --> Controller Class Initialized
DEBUG - 2024-10-21 10:26:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 10:26:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 10:26:09 --> Final output sent to browser
DEBUG - 2024-10-21 10:26:09 --> Total execution time: 0.0837
INFO - 2024-10-21 11:14:56 --> Config Class Initialized
INFO - 2024-10-21 11:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-21 11:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-21 11:14:56 --> Utf8 Class Initialized
INFO - 2024-10-21 11:14:56 --> URI Class Initialized
INFO - 2024-10-21 11:14:56 --> Router Class Initialized
INFO - 2024-10-21 11:14:56 --> Output Class Initialized
INFO - 2024-10-21 11:14:56 --> Security Class Initialized
DEBUG - 2024-10-21 11:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 11:14:56 --> Input Class Initialized
INFO - 2024-10-21 11:14:56 --> Language Class Initialized
INFO - 2024-10-21 11:14:56 --> Language Class Initialized
INFO - 2024-10-21 11:14:56 --> Config Class Initialized
INFO - 2024-10-21 11:14:56 --> Loader Class Initialized
INFO - 2024-10-21 11:14:56 --> Helper loaded: url_helper
INFO - 2024-10-21 11:14:56 --> Helper loaded: file_helper
INFO - 2024-10-21 11:14:56 --> Helper loaded: form_helper
INFO - 2024-10-21 11:14:56 --> Helper loaded: my_helper
INFO - 2024-10-21 11:14:56 --> Database Driver Class Initialized
INFO - 2024-10-21 11:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 11:14:56 --> Controller Class Initialized
DEBUG - 2024-10-21 11:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-21 11:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 11:14:56 --> Final output sent to browser
DEBUG - 2024-10-21 11:14:56 --> Total execution time: 0.0521
INFO - 2024-10-21 13:28:35 --> Config Class Initialized
INFO - 2024-10-21 13:28:35 --> Hooks Class Initialized
DEBUG - 2024-10-21 13:28:35 --> UTF-8 Support Enabled
INFO - 2024-10-21 13:28:35 --> Utf8 Class Initialized
INFO - 2024-10-21 13:28:35 --> URI Class Initialized
INFO - 2024-10-21 13:28:35 --> Router Class Initialized
INFO - 2024-10-21 13:28:35 --> Output Class Initialized
INFO - 2024-10-21 13:28:35 --> Security Class Initialized
DEBUG - 2024-10-21 13:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 13:28:35 --> Input Class Initialized
INFO - 2024-10-21 13:28:35 --> Language Class Initialized
INFO - 2024-10-21 13:28:35 --> Language Class Initialized
INFO - 2024-10-21 13:28:35 --> Config Class Initialized
INFO - 2024-10-21 13:28:35 --> Loader Class Initialized
INFO - 2024-10-21 13:28:35 --> Helper loaded: url_helper
INFO - 2024-10-21 13:28:35 --> Helper loaded: file_helper
INFO - 2024-10-21 13:28:35 --> Helper loaded: form_helper
INFO - 2024-10-21 13:28:35 --> Helper loaded: my_helper
INFO - 2024-10-21 13:28:35 --> Database Driver Class Initialized
INFO - 2024-10-21 13:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 13:28:35 --> Controller Class Initialized
DEBUG - 2024-10-21 13:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-21 13:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 13:28:35 --> Final output sent to browser
DEBUG - 2024-10-21 13:28:35 --> Total execution time: 0.0706
INFO - 2024-10-21 13:28:36 --> Config Class Initialized
INFO - 2024-10-21 13:28:36 --> Hooks Class Initialized
DEBUG - 2024-10-21 13:28:36 --> UTF-8 Support Enabled
INFO - 2024-10-21 13:28:36 --> Utf8 Class Initialized
INFO - 2024-10-21 13:28:36 --> URI Class Initialized
INFO - 2024-10-21 13:28:36 --> Router Class Initialized
INFO - 2024-10-21 13:28:36 --> Output Class Initialized
INFO - 2024-10-21 13:28:36 --> Security Class Initialized
DEBUG - 2024-10-21 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 13:28:36 --> Input Class Initialized
INFO - 2024-10-21 13:28:36 --> Language Class Initialized
ERROR - 2024-10-21 13:28:36 --> 404 Page Not Found: /index
INFO - 2024-10-21 13:28:36 --> Config Class Initialized
INFO - 2024-10-21 13:28:36 --> Hooks Class Initialized
DEBUG - 2024-10-21 13:28:36 --> UTF-8 Support Enabled
INFO - 2024-10-21 13:28:36 --> Utf8 Class Initialized
INFO - 2024-10-21 13:28:36 --> URI Class Initialized
INFO - 2024-10-21 13:28:36 --> Router Class Initialized
INFO - 2024-10-21 13:28:36 --> Output Class Initialized
INFO - 2024-10-21 13:28:36 --> Security Class Initialized
DEBUG - 2024-10-21 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 13:28:36 --> Input Class Initialized
INFO - 2024-10-21 13:28:36 --> Language Class Initialized
INFO - 2024-10-21 13:28:36 --> Language Class Initialized
INFO - 2024-10-21 13:28:36 --> Config Class Initialized
INFO - 2024-10-21 13:28:36 --> Loader Class Initialized
INFO - 2024-10-21 13:28:36 --> Helper loaded: url_helper
INFO - 2024-10-21 13:28:36 --> Helper loaded: file_helper
INFO - 2024-10-21 13:28:36 --> Helper loaded: form_helper
INFO - 2024-10-21 13:28:36 --> Helper loaded: my_helper
INFO - 2024-10-21 13:28:36 --> Database Driver Class Initialized
INFO - 2024-10-21 13:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 13:28:36 --> Controller Class Initialized
INFO - 2024-10-21 13:28:46 --> Config Class Initialized
INFO - 2024-10-21 13:28:46 --> Hooks Class Initialized
DEBUG - 2024-10-21 13:28:46 --> UTF-8 Support Enabled
INFO - 2024-10-21 13:28:46 --> Utf8 Class Initialized
INFO - 2024-10-21 13:28:46 --> URI Class Initialized
INFO - 2024-10-21 13:28:46 --> Router Class Initialized
INFO - 2024-10-21 13:28:46 --> Output Class Initialized
INFO - 2024-10-21 13:28:46 --> Security Class Initialized
DEBUG - 2024-10-21 13:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 13:28:46 --> Input Class Initialized
INFO - 2024-10-21 13:28:46 --> Language Class Initialized
INFO - 2024-10-21 13:28:46 --> Language Class Initialized
INFO - 2024-10-21 13:28:46 --> Config Class Initialized
INFO - 2024-10-21 13:28:46 --> Loader Class Initialized
INFO - 2024-10-21 13:28:46 --> Helper loaded: url_helper
INFO - 2024-10-21 13:28:46 --> Helper loaded: file_helper
INFO - 2024-10-21 13:28:46 --> Helper loaded: form_helper
INFO - 2024-10-21 13:28:46 --> Helper loaded: my_helper
INFO - 2024-10-21 13:28:46 --> Database Driver Class Initialized
INFO - 2024-10-21 13:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 13:28:46 --> Controller Class Initialized
INFO - 2024-10-21 13:28:46 --> Helper loaded: cookie_helper
INFO - 2024-10-21 13:28:46 --> Final output sent to browser
DEBUG - 2024-10-21 13:28:46 --> Total execution time: 0.0358
INFO - 2024-10-21 13:28:47 --> Config Class Initialized
INFO - 2024-10-21 13:28:47 --> Hooks Class Initialized
DEBUG - 2024-10-21 13:28:47 --> UTF-8 Support Enabled
INFO - 2024-10-21 13:28:47 --> Utf8 Class Initialized
INFO - 2024-10-21 13:28:47 --> URI Class Initialized
INFO - 2024-10-21 13:28:47 --> Router Class Initialized
INFO - 2024-10-21 13:28:47 --> Output Class Initialized
INFO - 2024-10-21 13:28:47 --> Security Class Initialized
DEBUG - 2024-10-21 13:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 13:28:47 --> Input Class Initialized
INFO - 2024-10-21 13:28:47 --> Language Class Initialized
INFO - 2024-10-21 13:28:47 --> Language Class Initialized
INFO - 2024-10-21 13:28:47 --> Config Class Initialized
INFO - 2024-10-21 13:28:47 --> Loader Class Initialized
INFO - 2024-10-21 13:28:47 --> Helper loaded: url_helper
INFO - 2024-10-21 13:28:47 --> Helper loaded: file_helper
INFO - 2024-10-21 13:28:47 --> Helper loaded: form_helper
INFO - 2024-10-21 13:28:47 --> Helper loaded: my_helper
INFO - 2024-10-21 13:28:47 --> Database Driver Class Initialized
INFO - 2024-10-21 13:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 13:28:47 --> Controller Class Initialized
INFO - 2024-10-21 13:28:47 --> Helper loaded: cookie_helper
INFO - 2024-10-21 13:28:47 --> Config Class Initialized
INFO - 2024-10-21 13:28:47 --> Hooks Class Initialized
DEBUG - 2024-10-21 13:28:47 --> UTF-8 Support Enabled
INFO - 2024-10-21 13:28:47 --> Utf8 Class Initialized
INFO - 2024-10-21 13:28:47 --> URI Class Initialized
INFO - 2024-10-21 13:28:47 --> Router Class Initialized
INFO - 2024-10-21 13:28:47 --> Output Class Initialized
INFO - 2024-10-21 13:28:47 --> Security Class Initialized
DEBUG - 2024-10-21 13:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 13:28:47 --> Input Class Initialized
INFO - 2024-10-21 13:28:47 --> Language Class Initialized
INFO - 2024-10-21 13:28:47 --> Language Class Initialized
INFO - 2024-10-21 13:28:47 --> Config Class Initialized
INFO - 2024-10-21 13:28:47 --> Loader Class Initialized
INFO - 2024-10-21 13:28:47 --> Helper loaded: url_helper
INFO - 2024-10-21 13:28:47 --> Helper loaded: file_helper
INFO - 2024-10-21 13:28:47 --> Helper loaded: form_helper
INFO - 2024-10-21 13:28:47 --> Helper loaded: my_helper
INFO - 2024-10-21 13:28:47 --> Database Driver Class Initialized
INFO - 2024-10-21 13:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 13:28:47 --> Controller Class Initialized
DEBUG - 2024-10-21 13:28:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 13:28:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 13:28:47 --> Final output sent to browser
DEBUG - 2024-10-21 13:28:47 --> Total execution time: 0.0346
INFO - 2024-10-21 18:20:37 --> Config Class Initialized
INFO - 2024-10-21 18:20:37 --> Hooks Class Initialized
DEBUG - 2024-10-21 18:20:37 --> UTF-8 Support Enabled
INFO - 2024-10-21 18:20:37 --> Utf8 Class Initialized
INFO - 2024-10-21 18:20:37 --> URI Class Initialized
INFO - 2024-10-21 18:20:37 --> Router Class Initialized
INFO - 2024-10-21 18:20:37 --> Output Class Initialized
INFO - 2024-10-21 18:20:37 --> Security Class Initialized
DEBUG - 2024-10-21 18:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 18:20:37 --> Input Class Initialized
INFO - 2024-10-21 18:20:37 --> Language Class Initialized
INFO - 2024-10-21 18:20:37 --> Language Class Initialized
INFO - 2024-10-21 18:20:37 --> Config Class Initialized
INFO - 2024-10-21 18:20:37 --> Loader Class Initialized
INFO - 2024-10-21 18:20:37 --> Helper loaded: url_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: file_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: form_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: my_helper
INFO - 2024-10-21 18:20:37 --> Database Driver Class Initialized
INFO - 2024-10-21 18:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 18:20:37 --> Controller Class Initialized
INFO - 2024-10-21 18:20:37 --> Helper loaded: cookie_helper
INFO - 2024-10-21 18:20:37 --> Final output sent to browser
DEBUG - 2024-10-21 18:20:37 --> Total execution time: 0.0455
INFO - 2024-10-21 18:20:37 --> Config Class Initialized
INFO - 2024-10-21 18:20:37 --> Hooks Class Initialized
DEBUG - 2024-10-21 18:20:37 --> UTF-8 Support Enabled
INFO - 2024-10-21 18:20:37 --> Utf8 Class Initialized
INFO - 2024-10-21 18:20:37 --> URI Class Initialized
INFO - 2024-10-21 18:20:37 --> Router Class Initialized
INFO - 2024-10-21 18:20:37 --> Output Class Initialized
INFO - 2024-10-21 18:20:37 --> Security Class Initialized
DEBUG - 2024-10-21 18:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 18:20:37 --> Input Class Initialized
INFO - 2024-10-21 18:20:37 --> Language Class Initialized
INFO - 2024-10-21 18:20:37 --> Language Class Initialized
INFO - 2024-10-21 18:20:37 --> Config Class Initialized
INFO - 2024-10-21 18:20:37 --> Loader Class Initialized
INFO - 2024-10-21 18:20:37 --> Helper loaded: url_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: file_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: form_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: my_helper
INFO - 2024-10-21 18:20:37 --> Database Driver Class Initialized
INFO - 2024-10-21 18:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 18:20:37 --> Controller Class Initialized
INFO - 2024-10-21 18:20:37 --> Helper loaded: cookie_helper
INFO - 2024-10-21 18:20:37 --> Config Class Initialized
INFO - 2024-10-21 18:20:37 --> Hooks Class Initialized
DEBUG - 2024-10-21 18:20:37 --> UTF-8 Support Enabled
INFO - 2024-10-21 18:20:37 --> Utf8 Class Initialized
INFO - 2024-10-21 18:20:37 --> URI Class Initialized
INFO - 2024-10-21 18:20:37 --> Router Class Initialized
INFO - 2024-10-21 18:20:37 --> Output Class Initialized
INFO - 2024-10-21 18:20:37 --> Security Class Initialized
DEBUG - 2024-10-21 18:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 18:20:37 --> Input Class Initialized
INFO - 2024-10-21 18:20:37 --> Language Class Initialized
INFO - 2024-10-21 18:20:37 --> Language Class Initialized
INFO - 2024-10-21 18:20:37 --> Config Class Initialized
INFO - 2024-10-21 18:20:37 --> Loader Class Initialized
INFO - 2024-10-21 18:20:37 --> Helper loaded: url_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: file_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: form_helper
INFO - 2024-10-21 18:20:37 --> Helper loaded: my_helper
INFO - 2024-10-21 18:20:37 --> Database Driver Class Initialized
INFO - 2024-10-21 18:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 18:20:37 --> Controller Class Initialized
DEBUG - 2024-10-21 18:20:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 18:20:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 18:20:37 --> Final output sent to browser
DEBUG - 2024-10-21 18:20:37 --> Total execution time: 0.0346
INFO - 2024-10-21 23:21:17 --> Config Class Initialized
INFO - 2024-10-21 23:21:17 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:21:17 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:21:17 --> Utf8 Class Initialized
INFO - 2024-10-21 23:21:17 --> URI Class Initialized
DEBUG - 2024-10-21 23:21:18 --> No URI present. Default controller set.
INFO - 2024-10-21 23:21:18 --> Router Class Initialized
INFO - 2024-10-21 23:21:18 --> Output Class Initialized
INFO - 2024-10-21 23:21:18 --> Security Class Initialized
DEBUG - 2024-10-21 23:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:21:18 --> Input Class Initialized
INFO - 2024-10-21 23:21:18 --> Language Class Initialized
INFO - 2024-10-21 23:21:18 --> Language Class Initialized
INFO - 2024-10-21 23:21:18 --> Config Class Initialized
INFO - 2024-10-21 23:21:18 --> Loader Class Initialized
INFO - 2024-10-21 23:21:18 --> Helper loaded: url_helper
INFO - 2024-10-21 23:21:18 --> Helper loaded: file_helper
INFO - 2024-10-21 23:21:18 --> Helper loaded: form_helper
INFO - 2024-10-21 23:21:18 --> Helper loaded: my_helper
INFO - 2024-10-21 23:21:18 --> Database Driver Class Initialized
INFO - 2024-10-21 23:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:21:18 --> Controller Class Initialized
INFO - 2024-10-21 23:21:18 --> Config Class Initialized
INFO - 2024-10-21 23:21:18 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:21:18 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:21:18 --> Utf8 Class Initialized
INFO - 2024-10-21 23:21:18 --> URI Class Initialized
INFO - 2024-10-21 23:21:18 --> Router Class Initialized
INFO - 2024-10-21 23:21:18 --> Output Class Initialized
INFO - 2024-10-21 23:21:18 --> Security Class Initialized
DEBUG - 2024-10-21 23:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:21:18 --> Input Class Initialized
INFO - 2024-10-21 23:21:18 --> Language Class Initialized
INFO - 2024-10-21 23:21:18 --> Language Class Initialized
INFO - 2024-10-21 23:21:18 --> Config Class Initialized
INFO - 2024-10-21 23:21:18 --> Loader Class Initialized
INFO - 2024-10-21 23:21:18 --> Helper loaded: url_helper
INFO - 2024-10-21 23:21:18 --> Helper loaded: file_helper
INFO - 2024-10-21 23:21:18 --> Helper loaded: form_helper
INFO - 2024-10-21 23:21:18 --> Helper loaded: my_helper
INFO - 2024-10-21 23:21:18 --> Database Driver Class Initialized
INFO - 2024-10-21 23:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:21:18 --> Controller Class Initialized
DEBUG - 2024-10-21 23:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-21 23:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:21:18 --> Final output sent to browser
DEBUG - 2024-10-21 23:21:18 --> Total execution time: 0.0979
INFO - 2024-10-21 23:21:38 --> Config Class Initialized
INFO - 2024-10-21 23:21:38 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:21:38 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:21:38 --> Utf8 Class Initialized
INFO - 2024-10-21 23:21:38 --> URI Class Initialized
DEBUG - 2024-10-21 23:21:38 --> No URI present. Default controller set.
INFO - 2024-10-21 23:21:38 --> Router Class Initialized
INFO - 2024-10-21 23:21:38 --> Output Class Initialized
INFO - 2024-10-21 23:21:38 --> Security Class Initialized
DEBUG - 2024-10-21 23:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:21:38 --> Input Class Initialized
INFO - 2024-10-21 23:21:38 --> Language Class Initialized
INFO - 2024-10-21 23:21:38 --> Language Class Initialized
INFO - 2024-10-21 23:21:38 --> Config Class Initialized
INFO - 2024-10-21 23:21:38 --> Loader Class Initialized
INFO - 2024-10-21 23:21:38 --> Helper loaded: url_helper
INFO - 2024-10-21 23:21:38 --> Helper loaded: file_helper
INFO - 2024-10-21 23:21:38 --> Helper loaded: form_helper
INFO - 2024-10-21 23:21:38 --> Helper loaded: my_helper
INFO - 2024-10-21 23:21:38 --> Database Driver Class Initialized
INFO - 2024-10-21 23:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:21:39 --> Controller Class Initialized
INFO - 2024-10-21 23:21:39 --> Config Class Initialized
INFO - 2024-10-21 23:21:39 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:21:39 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:21:39 --> Utf8 Class Initialized
INFO - 2024-10-21 23:21:39 --> URI Class Initialized
INFO - 2024-10-21 23:21:39 --> Router Class Initialized
INFO - 2024-10-21 23:21:39 --> Output Class Initialized
INFO - 2024-10-21 23:21:39 --> Security Class Initialized
DEBUG - 2024-10-21 23:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:21:39 --> Input Class Initialized
INFO - 2024-10-21 23:21:39 --> Language Class Initialized
INFO - 2024-10-21 23:21:39 --> Language Class Initialized
INFO - 2024-10-21 23:21:39 --> Config Class Initialized
INFO - 2024-10-21 23:21:39 --> Loader Class Initialized
INFO - 2024-10-21 23:21:39 --> Helper loaded: url_helper
INFO - 2024-10-21 23:21:39 --> Helper loaded: file_helper
INFO - 2024-10-21 23:21:39 --> Helper loaded: form_helper
INFO - 2024-10-21 23:21:39 --> Helper loaded: my_helper
INFO - 2024-10-21 23:21:39 --> Database Driver Class Initialized
INFO - 2024-10-21 23:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:21:39 --> Controller Class Initialized
DEBUG - 2024-10-21 23:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-21 23:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:21:39 --> Final output sent to browser
DEBUG - 2024-10-21 23:21:39 --> Total execution time: 0.0729
INFO - 2024-10-21 23:21:47 --> Config Class Initialized
INFO - 2024-10-21 23:21:47 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:21:47 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:21:47 --> Utf8 Class Initialized
INFO - 2024-10-21 23:21:47 --> URI Class Initialized
INFO - 2024-10-21 23:21:47 --> Router Class Initialized
INFO - 2024-10-21 23:21:47 --> Output Class Initialized
INFO - 2024-10-21 23:21:47 --> Security Class Initialized
DEBUG - 2024-10-21 23:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:21:47 --> Input Class Initialized
INFO - 2024-10-21 23:21:47 --> Language Class Initialized
INFO - 2024-10-21 23:21:47 --> Language Class Initialized
INFO - 2024-10-21 23:21:47 --> Config Class Initialized
INFO - 2024-10-21 23:21:47 --> Loader Class Initialized
INFO - 2024-10-21 23:21:47 --> Helper loaded: url_helper
INFO - 2024-10-21 23:21:47 --> Helper loaded: file_helper
INFO - 2024-10-21 23:21:47 --> Helper loaded: form_helper
INFO - 2024-10-21 23:21:47 --> Helper loaded: my_helper
INFO - 2024-10-21 23:21:47 --> Database Driver Class Initialized
INFO - 2024-10-21 23:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:21:47 --> Controller Class Initialized
INFO - 2024-10-21 23:21:47 --> Helper loaded: cookie_helper
INFO - 2024-10-21 23:21:47 --> Final output sent to browser
DEBUG - 2024-10-21 23:21:47 --> Total execution time: 0.2908
INFO - 2024-10-21 23:21:47 --> Config Class Initialized
INFO - 2024-10-21 23:21:47 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:21:47 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:21:47 --> Utf8 Class Initialized
INFO - 2024-10-21 23:21:47 --> URI Class Initialized
INFO - 2024-10-21 23:21:47 --> Router Class Initialized
INFO - 2024-10-21 23:21:47 --> Output Class Initialized
INFO - 2024-10-21 23:21:47 --> Security Class Initialized
DEBUG - 2024-10-21 23:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:21:47 --> Input Class Initialized
INFO - 2024-10-21 23:21:47 --> Language Class Initialized
INFO - 2024-10-21 23:21:47 --> Language Class Initialized
INFO - 2024-10-21 23:21:47 --> Config Class Initialized
INFO - 2024-10-21 23:21:47 --> Loader Class Initialized
INFO - 2024-10-21 23:21:47 --> Helper loaded: url_helper
INFO - 2024-10-21 23:21:47 --> Helper loaded: file_helper
INFO - 2024-10-21 23:21:47 --> Helper loaded: form_helper
INFO - 2024-10-21 23:21:47 --> Helper loaded: my_helper
INFO - 2024-10-21 23:21:47 --> Database Driver Class Initialized
INFO - 2024-10-21 23:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:21:47 --> Controller Class Initialized
DEBUG - 2024-10-21 23:21:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-21 23:21:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:21:47 --> Final output sent to browser
DEBUG - 2024-10-21 23:21:47 --> Total execution time: 0.1606
INFO - 2024-10-21 23:22:06 --> Config Class Initialized
INFO - 2024-10-21 23:22:06 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:06 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:06 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:06 --> URI Class Initialized
INFO - 2024-10-21 23:22:06 --> Router Class Initialized
INFO - 2024-10-21 23:22:06 --> Output Class Initialized
INFO - 2024-10-21 23:22:06 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:06 --> Input Class Initialized
INFO - 2024-10-21 23:22:06 --> Language Class Initialized
INFO - 2024-10-21 23:22:06 --> Language Class Initialized
INFO - 2024-10-21 23:22:06 --> Config Class Initialized
INFO - 2024-10-21 23:22:06 --> Loader Class Initialized
INFO - 2024-10-21 23:22:06 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:06 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:06 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:06 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:06 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:06 --> Controller Class Initialized
DEBUG - 2024-10-21 23:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-21 23:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:22:06 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:06 --> Total execution time: 0.0313
INFO - 2024-10-21 23:22:06 --> Config Class Initialized
INFO - 2024-10-21 23:22:06 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:06 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:06 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:06 --> URI Class Initialized
INFO - 2024-10-21 23:22:06 --> Router Class Initialized
INFO - 2024-10-21 23:22:06 --> Output Class Initialized
INFO - 2024-10-21 23:22:06 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:06 --> Input Class Initialized
INFO - 2024-10-21 23:22:06 --> Language Class Initialized
ERROR - 2024-10-21 23:22:06 --> 404 Page Not Found: /index
INFO - 2024-10-21 23:22:07 --> Config Class Initialized
INFO - 2024-10-21 23:22:07 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:07 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:07 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:07 --> URI Class Initialized
INFO - 2024-10-21 23:22:07 --> Router Class Initialized
INFO - 2024-10-21 23:22:07 --> Output Class Initialized
INFO - 2024-10-21 23:22:07 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:07 --> Input Class Initialized
INFO - 2024-10-21 23:22:07 --> Language Class Initialized
INFO - 2024-10-21 23:22:07 --> Language Class Initialized
INFO - 2024-10-21 23:22:07 --> Config Class Initialized
INFO - 2024-10-21 23:22:07 --> Loader Class Initialized
INFO - 2024-10-21 23:22:07 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:07 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:07 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:07 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:07 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:07 --> Controller Class Initialized
INFO - 2024-10-21 23:22:08 --> Config Class Initialized
INFO - 2024-10-21 23:22:08 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:08 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:08 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:08 --> URI Class Initialized
INFO - 2024-10-21 23:22:08 --> Router Class Initialized
INFO - 2024-10-21 23:22:08 --> Output Class Initialized
INFO - 2024-10-21 23:22:08 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:08 --> Input Class Initialized
INFO - 2024-10-21 23:22:08 --> Language Class Initialized
INFO - 2024-10-21 23:22:08 --> Language Class Initialized
INFO - 2024-10-21 23:22:08 --> Config Class Initialized
INFO - 2024-10-21 23:22:08 --> Loader Class Initialized
INFO - 2024-10-21 23:22:08 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:08 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:08 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:08 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:08 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:08 --> Controller Class Initialized
INFO - 2024-10-21 23:22:09 --> Config Class Initialized
INFO - 2024-10-21 23:22:09 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:09 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:09 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:09 --> URI Class Initialized
INFO - 2024-10-21 23:22:09 --> Router Class Initialized
INFO - 2024-10-21 23:22:09 --> Output Class Initialized
INFO - 2024-10-21 23:22:09 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:09 --> Input Class Initialized
INFO - 2024-10-21 23:22:09 --> Language Class Initialized
INFO - 2024-10-21 23:22:09 --> Language Class Initialized
INFO - 2024-10-21 23:22:09 --> Config Class Initialized
INFO - 2024-10-21 23:22:09 --> Loader Class Initialized
INFO - 2024-10-21 23:22:09 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:09 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:09 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:09 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:09 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:09 --> Controller Class Initialized
INFO - 2024-10-21 23:22:10 --> Config Class Initialized
INFO - 2024-10-21 23:22:10 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:10 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:10 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:10 --> URI Class Initialized
INFO - 2024-10-21 23:22:10 --> Router Class Initialized
INFO - 2024-10-21 23:22:10 --> Output Class Initialized
INFO - 2024-10-21 23:22:10 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:10 --> Input Class Initialized
INFO - 2024-10-21 23:22:10 --> Language Class Initialized
INFO - 2024-10-21 23:22:10 --> Language Class Initialized
INFO - 2024-10-21 23:22:10 --> Config Class Initialized
INFO - 2024-10-21 23:22:10 --> Loader Class Initialized
INFO - 2024-10-21 23:22:10 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:10 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:10 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:10 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:10 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:10 --> Controller Class Initialized
INFO - 2024-10-21 23:22:22 --> Config Class Initialized
INFO - 2024-10-21 23:22:22 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:22 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:22 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:22 --> URI Class Initialized
INFO - 2024-10-21 23:22:22 --> Router Class Initialized
INFO - 2024-10-21 23:22:22 --> Output Class Initialized
INFO - 2024-10-21 23:22:22 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:22 --> Input Class Initialized
INFO - 2024-10-21 23:22:22 --> Language Class Initialized
INFO - 2024-10-21 23:22:22 --> Language Class Initialized
INFO - 2024-10-21 23:22:22 --> Config Class Initialized
INFO - 2024-10-21 23:22:22 --> Loader Class Initialized
INFO - 2024-10-21 23:22:22 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:22 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:22 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:22 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:22 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:22 --> Controller Class Initialized
INFO - 2024-10-21 23:22:22 --> Helper loaded: cookie_helper
INFO - 2024-10-21 23:22:22 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:22 --> Total execution time: 0.0427
INFO - 2024-10-21 23:22:22 --> Config Class Initialized
INFO - 2024-10-21 23:22:22 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:22 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:22 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:22 --> URI Class Initialized
INFO - 2024-10-21 23:22:22 --> Router Class Initialized
INFO - 2024-10-21 23:22:22 --> Output Class Initialized
INFO - 2024-10-21 23:22:22 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:22 --> Input Class Initialized
INFO - 2024-10-21 23:22:22 --> Language Class Initialized
INFO - 2024-10-21 23:22:22 --> Language Class Initialized
INFO - 2024-10-21 23:22:22 --> Config Class Initialized
INFO - 2024-10-21 23:22:22 --> Loader Class Initialized
INFO - 2024-10-21 23:22:22 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:22 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:22 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:22 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:22 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:22 --> Controller Class Initialized
DEBUG - 2024-10-21 23:22:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-21 23:22:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:22:22 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:22 --> Total execution time: 0.0340
INFO - 2024-10-21 23:22:24 --> Config Class Initialized
INFO - 2024-10-21 23:22:24 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:24 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:24 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:24 --> URI Class Initialized
INFO - 2024-10-21 23:22:24 --> Router Class Initialized
INFO - 2024-10-21 23:22:24 --> Output Class Initialized
INFO - 2024-10-21 23:22:24 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:24 --> Input Class Initialized
INFO - 2024-10-21 23:22:24 --> Language Class Initialized
INFO - 2024-10-21 23:22:24 --> Language Class Initialized
INFO - 2024-10-21 23:22:24 --> Config Class Initialized
INFO - 2024-10-21 23:22:24 --> Loader Class Initialized
INFO - 2024-10-21 23:22:24 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:24 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:24 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:24 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:24 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:24 --> Controller Class Initialized
DEBUG - 2024-10-21 23:22:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 23:22:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:22:24 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:24 --> Total execution time: 0.0799
INFO - 2024-10-21 23:22:50 --> Config Class Initialized
INFO - 2024-10-21 23:22:50 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:50 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:50 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:50 --> URI Class Initialized
INFO - 2024-10-21 23:22:50 --> Router Class Initialized
INFO - 2024-10-21 23:22:50 --> Output Class Initialized
INFO - 2024-10-21 23:22:51 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:51 --> Input Class Initialized
INFO - 2024-10-21 23:22:51 --> Language Class Initialized
INFO - 2024-10-21 23:22:51 --> Language Class Initialized
INFO - 2024-10-21 23:22:51 --> Config Class Initialized
INFO - 2024-10-21 23:22:51 --> Loader Class Initialized
INFO - 2024-10-21 23:22:51 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:51 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:51 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:51 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:51 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:51 --> Controller Class Initialized
DEBUG - 2024-10-21 23:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-10-21 23:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:22:51 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:51 --> Total execution time: 0.4005
INFO - 2024-10-21 23:22:51 --> Config Class Initialized
INFO - 2024-10-21 23:22:51 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:51 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:51 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:51 --> URI Class Initialized
INFO - 2024-10-21 23:22:51 --> Router Class Initialized
INFO - 2024-10-21 23:22:51 --> Output Class Initialized
INFO - 2024-10-21 23:22:51 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:51 --> Input Class Initialized
INFO - 2024-10-21 23:22:51 --> Language Class Initialized
ERROR - 2024-10-21 23:22:51 --> 404 Page Not Found: /index
INFO - 2024-10-21 23:22:51 --> Config Class Initialized
INFO - 2024-10-21 23:22:51 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:51 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:51 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:51 --> URI Class Initialized
INFO - 2024-10-21 23:22:51 --> Router Class Initialized
INFO - 2024-10-21 23:22:51 --> Output Class Initialized
INFO - 2024-10-21 23:22:51 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:51 --> Input Class Initialized
INFO - 2024-10-21 23:22:51 --> Language Class Initialized
INFO - 2024-10-21 23:22:51 --> Language Class Initialized
INFO - 2024-10-21 23:22:51 --> Config Class Initialized
INFO - 2024-10-21 23:22:51 --> Loader Class Initialized
INFO - 2024-10-21 23:22:51 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:51 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:51 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:51 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:51 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:51 --> Controller Class Initialized
INFO - 2024-10-21 23:22:56 --> Config Class Initialized
INFO - 2024-10-21 23:22:56 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:56 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:56 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:56 --> URI Class Initialized
INFO - 2024-10-21 23:22:56 --> Router Class Initialized
INFO - 2024-10-21 23:22:56 --> Output Class Initialized
INFO - 2024-10-21 23:22:56 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:56 --> Input Class Initialized
INFO - 2024-10-21 23:22:56 --> Language Class Initialized
INFO - 2024-10-21 23:22:56 --> Language Class Initialized
INFO - 2024-10-21 23:22:56 --> Config Class Initialized
INFO - 2024-10-21 23:22:56 --> Loader Class Initialized
INFO - 2024-10-21 23:22:56 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:56 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:56 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:56 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:56 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:56 --> Controller Class Initialized
DEBUG - 2024-10-21 23:22:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-21 23:22:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:22:56 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:56 --> Total execution time: 0.0308
INFO - 2024-10-21 23:22:56 --> Config Class Initialized
INFO - 2024-10-21 23:22:56 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:56 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:56 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:56 --> URI Class Initialized
INFO - 2024-10-21 23:22:56 --> Router Class Initialized
INFO - 2024-10-21 23:22:56 --> Output Class Initialized
INFO - 2024-10-21 23:22:56 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:56 --> Input Class Initialized
INFO - 2024-10-21 23:22:56 --> Language Class Initialized
ERROR - 2024-10-21 23:22:56 --> 404 Page Not Found: /index
INFO - 2024-10-21 23:22:56 --> Config Class Initialized
INFO - 2024-10-21 23:22:56 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:56 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:56 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:56 --> URI Class Initialized
INFO - 2024-10-21 23:22:56 --> Router Class Initialized
INFO - 2024-10-21 23:22:56 --> Output Class Initialized
INFO - 2024-10-21 23:22:56 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:56 --> Input Class Initialized
INFO - 2024-10-21 23:22:56 --> Language Class Initialized
INFO - 2024-10-21 23:22:56 --> Language Class Initialized
INFO - 2024-10-21 23:22:56 --> Config Class Initialized
INFO - 2024-10-21 23:22:56 --> Loader Class Initialized
INFO - 2024-10-21 23:22:56 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:56 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:56 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:56 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:56 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:56 --> Controller Class Initialized
INFO - 2024-10-21 23:22:57 --> Config Class Initialized
INFO - 2024-10-21 23:22:57 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:57 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:57 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:57 --> URI Class Initialized
INFO - 2024-10-21 23:22:57 --> Router Class Initialized
INFO - 2024-10-21 23:22:57 --> Output Class Initialized
INFO - 2024-10-21 23:22:57 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:57 --> Input Class Initialized
INFO - 2024-10-21 23:22:57 --> Language Class Initialized
INFO - 2024-10-21 23:22:57 --> Language Class Initialized
INFO - 2024-10-21 23:22:57 --> Config Class Initialized
INFO - 2024-10-21 23:22:57 --> Loader Class Initialized
INFO - 2024-10-21 23:22:57 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:57 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:57 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:57 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:57 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:57 --> Controller Class Initialized
DEBUG - 2024-10-21 23:22:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-21 23:22:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:22:57 --> Final output sent to browser
DEBUG - 2024-10-21 23:22:57 --> Total execution time: 0.0738
INFO - 2024-10-21 23:22:57 --> Config Class Initialized
INFO - 2024-10-21 23:22:57 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:57 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:57 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:57 --> URI Class Initialized
INFO - 2024-10-21 23:22:57 --> Router Class Initialized
INFO - 2024-10-21 23:22:57 --> Output Class Initialized
INFO - 2024-10-21 23:22:57 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:57 --> Input Class Initialized
INFO - 2024-10-21 23:22:57 --> Language Class Initialized
ERROR - 2024-10-21 23:22:57 --> 404 Page Not Found: /index
INFO - 2024-10-21 23:22:57 --> Config Class Initialized
INFO - 2024-10-21 23:22:57 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:22:57 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:22:57 --> Utf8 Class Initialized
INFO - 2024-10-21 23:22:57 --> URI Class Initialized
INFO - 2024-10-21 23:22:57 --> Router Class Initialized
INFO - 2024-10-21 23:22:57 --> Output Class Initialized
INFO - 2024-10-21 23:22:57 --> Security Class Initialized
DEBUG - 2024-10-21 23:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:22:57 --> Input Class Initialized
INFO - 2024-10-21 23:22:57 --> Language Class Initialized
INFO - 2024-10-21 23:22:57 --> Language Class Initialized
INFO - 2024-10-21 23:22:57 --> Config Class Initialized
INFO - 2024-10-21 23:22:57 --> Loader Class Initialized
INFO - 2024-10-21 23:22:57 --> Helper loaded: url_helper
INFO - 2024-10-21 23:22:57 --> Helper loaded: file_helper
INFO - 2024-10-21 23:22:57 --> Helper loaded: form_helper
INFO - 2024-10-21 23:22:57 --> Helper loaded: my_helper
INFO - 2024-10-21 23:22:57 --> Database Driver Class Initialized
INFO - 2024-10-21 23:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:22:57 --> Controller Class Initialized
INFO - 2024-10-21 23:23:21 --> Config Class Initialized
INFO - 2024-10-21 23:23:21 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:23:21 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:23:21 --> Utf8 Class Initialized
INFO - 2024-10-21 23:23:21 --> URI Class Initialized
INFO - 2024-10-21 23:23:21 --> Router Class Initialized
INFO - 2024-10-21 23:23:21 --> Output Class Initialized
INFO - 2024-10-21 23:23:21 --> Security Class Initialized
DEBUG - 2024-10-21 23:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:23:21 --> Input Class Initialized
INFO - 2024-10-21 23:23:21 --> Language Class Initialized
INFO - 2024-10-21 23:23:21 --> Language Class Initialized
INFO - 2024-10-21 23:23:21 --> Config Class Initialized
INFO - 2024-10-21 23:23:21 --> Loader Class Initialized
INFO - 2024-10-21 23:23:21 --> Helper loaded: url_helper
INFO - 2024-10-21 23:23:21 --> Helper loaded: file_helper
INFO - 2024-10-21 23:23:21 --> Helper loaded: form_helper
INFO - 2024-10-21 23:23:21 --> Helper loaded: my_helper
INFO - 2024-10-21 23:23:21 --> Database Driver Class Initialized
INFO - 2024-10-21 23:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:23:21 --> Controller Class Initialized
DEBUG - 2024-10-21 23:23:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:23:25 --> Final output sent to browser
DEBUG - 2024-10-21 23:23:25 --> Total execution time: 4.7029
INFO - 2024-10-21 23:24:02 --> Config Class Initialized
INFO - 2024-10-21 23:24:02 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:24:02 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:24:02 --> Utf8 Class Initialized
INFO - 2024-10-21 23:24:02 --> URI Class Initialized
INFO - 2024-10-21 23:24:02 --> Router Class Initialized
INFO - 2024-10-21 23:24:02 --> Output Class Initialized
INFO - 2024-10-21 23:24:02 --> Security Class Initialized
DEBUG - 2024-10-21 23:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:24:02 --> Input Class Initialized
INFO - 2024-10-21 23:24:02 --> Language Class Initialized
INFO - 2024-10-21 23:24:02 --> Language Class Initialized
INFO - 2024-10-21 23:24:02 --> Config Class Initialized
INFO - 2024-10-21 23:24:02 --> Loader Class Initialized
INFO - 2024-10-21 23:24:02 --> Helper loaded: url_helper
INFO - 2024-10-21 23:24:02 --> Helper loaded: file_helper
INFO - 2024-10-21 23:24:02 --> Helper loaded: form_helper
INFO - 2024-10-21 23:24:02 --> Helper loaded: my_helper
INFO - 2024-10-21 23:24:02 --> Database Driver Class Initialized
INFO - 2024-10-21 23:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:24:02 --> Controller Class Initialized
DEBUG - 2024-10-21 23:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-21 23:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:24:03 --> Final output sent to browser
DEBUG - 2024-10-21 23:24:03 --> Total execution time: 0.5640
INFO - 2024-10-21 23:24:17 --> Config Class Initialized
INFO - 2024-10-21 23:24:17 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:24:17 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:24:17 --> Utf8 Class Initialized
INFO - 2024-10-21 23:24:17 --> URI Class Initialized
INFO - 2024-10-21 23:24:17 --> Router Class Initialized
INFO - 2024-10-21 23:24:17 --> Output Class Initialized
INFO - 2024-10-21 23:24:17 --> Security Class Initialized
DEBUG - 2024-10-21 23:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:24:17 --> Input Class Initialized
INFO - 2024-10-21 23:24:17 --> Language Class Initialized
INFO - 2024-10-21 23:24:17 --> Language Class Initialized
INFO - 2024-10-21 23:24:17 --> Config Class Initialized
INFO - 2024-10-21 23:24:17 --> Loader Class Initialized
INFO - 2024-10-21 23:24:17 --> Helper loaded: url_helper
INFO - 2024-10-21 23:24:17 --> Helper loaded: file_helper
INFO - 2024-10-21 23:24:17 --> Helper loaded: form_helper
INFO - 2024-10-21 23:24:17 --> Helper loaded: my_helper
INFO - 2024-10-21 23:24:17 --> Database Driver Class Initialized
INFO - 2024-10-21 23:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:24:17 --> Controller Class Initialized
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-21 23:24:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-21 23:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:24:18 --> Config Class Initialized
INFO - 2024-10-21 23:24:18 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:24:18 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:24:18 --> Utf8 Class Initialized
INFO - 2024-10-21 23:24:18 --> URI Class Initialized
INFO - 2024-10-21 23:24:18 --> Router Class Initialized
INFO - 2024-10-21 23:24:18 --> Output Class Initialized
INFO - 2024-10-21 23:24:18 --> Security Class Initialized
DEBUG - 2024-10-21 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:24:18 --> Input Class Initialized
INFO - 2024-10-21 23:24:18 --> Language Class Initialized
INFO - 2024-10-21 23:24:18 --> Language Class Initialized
INFO - 2024-10-21 23:24:18 --> Config Class Initialized
INFO - 2024-10-21 23:24:18 --> Loader Class Initialized
INFO - 2024-10-21 23:24:18 --> Helper loaded: url_helper
INFO - 2024-10-21 23:24:18 --> Helper loaded: file_helper
INFO - 2024-10-21 23:24:18 --> Helper loaded: form_helper
INFO - 2024-10-21 23:24:18 --> Helper loaded: my_helper
INFO - 2024-10-21 23:24:18 --> Database Driver Class Initialized
INFO - 2024-10-21 23:24:21 --> Final output sent to browser
DEBUG - 2024-10-21 23:24:21 --> Total execution time: 3.6506
INFO - 2024-10-21 23:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:24:21 --> Controller Class Initialized
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-21 23:24:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-21 23:24:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:24:24 --> Final output sent to browser
DEBUG - 2024-10-21 23:24:24 --> Total execution time: 5.3686
INFO - 2024-10-21 23:47:09 --> Config Class Initialized
INFO - 2024-10-21 23:47:09 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:47:09 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:47:09 --> Utf8 Class Initialized
INFO - 2024-10-21 23:47:09 --> URI Class Initialized
INFO - 2024-10-21 23:47:09 --> Router Class Initialized
INFO - 2024-10-21 23:47:09 --> Output Class Initialized
INFO - 2024-10-21 23:47:09 --> Security Class Initialized
DEBUG - 2024-10-21 23:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:47:09 --> Input Class Initialized
INFO - 2024-10-21 23:47:09 --> Language Class Initialized
INFO - 2024-10-21 23:47:09 --> Language Class Initialized
INFO - 2024-10-21 23:47:09 --> Config Class Initialized
INFO - 2024-10-21 23:47:09 --> Loader Class Initialized
INFO - 2024-10-21 23:47:09 --> Helper loaded: url_helper
INFO - 2024-10-21 23:47:09 --> Helper loaded: file_helper
INFO - 2024-10-21 23:47:09 --> Helper loaded: form_helper
INFO - 2024-10-21 23:47:09 --> Helper loaded: my_helper
INFO - 2024-10-21 23:47:09 --> Database Driver Class Initialized
INFO - 2024-10-21 23:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:47:09 --> Controller Class Initialized
ERROR - 2024-10-21 23:47:09 --> Severity: error --> Exception: syntax error, unexpected '>' /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php 29
INFO - 2024-10-21 23:47:31 --> Config Class Initialized
INFO - 2024-10-21 23:47:31 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:47:31 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:47:31 --> Utf8 Class Initialized
INFO - 2024-10-21 23:47:31 --> URI Class Initialized
INFO - 2024-10-21 23:47:31 --> Router Class Initialized
INFO - 2024-10-21 23:47:31 --> Output Class Initialized
INFO - 2024-10-21 23:47:31 --> Security Class Initialized
DEBUG - 2024-10-21 23:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:47:31 --> Input Class Initialized
INFO - 2024-10-21 23:47:31 --> Language Class Initialized
INFO - 2024-10-21 23:47:31 --> Language Class Initialized
INFO - 2024-10-21 23:47:31 --> Config Class Initialized
INFO - 2024-10-21 23:47:31 --> Loader Class Initialized
INFO - 2024-10-21 23:47:31 --> Helper loaded: url_helper
INFO - 2024-10-21 23:47:31 --> Helper loaded: file_helper
INFO - 2024-10-21 23:47:31 --> Helper loaded: form_helper
INFO - 2024-10-21 23:47:31 --> Helper loaded: my_helper
INFO - 2024-10-21 23:47:31 --> Database Driver Class Initialized
INFO - 2024-10-21 23:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:47:31 --> Controller Class Initialized
ERROR - 2024-10-21 23:47:31 --> Severity: Notice --> Undefined variable: thn /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php 53
DEBUG - 2024-10-21 23:47:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 23:47:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:47:31 --> Final output sent to browser
DEBUG - 2024-10-21 23:47:31 --> Total execution time: 0.0496
INFO - 2024-10-21 23:49:55 --> Config Class Initialized
INFO - 2024-10-21 23:49:55 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:49:55 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:49:55 --> Utf8 Class Initialized
INFO - 2024-10-21 23:49:55 --> URI Class Initialized
INFO - 2024-10-21 23:49:55 --> Router Class Initialized
INFO - 2024-10-21 23:49:55 --> Output Class Initialized
INFO - 2024-10-21 23:49:55 --> Security Class Initialized
DEBUG - 2024-10-21 23:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:49:55 --> Input Class Initialized
INFO - 2024-10-21 23:49:55 --> Language Class Initialized
INFO - 2024-10-21 23:49:56 --> Language Class Initialized
INFO - 2024-10-21 23:49:56 --> Config Class Initialized
INFO - 2024-10-21 23:49:56 --> Loader Class Initialized
INFO - 2024-10-21 23:49:56 --> Helper loaded: url_helper
INFO - 2024-10-21 23:49:56 --> Helper loaded: file_helper
INFO - 2024-10-21 23:49:56 --> Helper loaded: form_helper
INFO - 2024-10-21 23:49:56 --> Helper loaded: my_helper
INFO - 2024-10-21 23:49:56 --> Database Driver Class Initialized
INFO - 2024-10-21 23:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:49:56 --> Controller Class Initialized
DEBUG - 2024-10-21 23:49:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 23:49:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:49:56 --> Final output sent to browser
DEBUG - 2024-10-21 23:49:56 --> Total execution time: 0.5445
INFO - 2024-10-21 23:50:12 --> Config Class Initialized
INFO - 2024-10-21 23:50:12 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:50:12 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:50:12 --> Utf8 Class Initialized
INFO - 2024-10-21 23:50:12 --> URI Class Initialized
INFO - 2024-10-21 23:50:12 --> Router Class Initialized
INFO - 2024-10-21 23:50:12 --> Output Class Initialized
INFO - 2024-10-21 23:50:12 --> Security Class Initialized
DEBUG - 2024-10-21 23:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:50:12 --> Input Class Initialized
INFO - 2024-10-21 23:50:12 --> Language Class Initialized
INFO - 2024-10-21 23:50:12 --> Language Class Initialized
INFO - 2024-10-21 23:50:12 --> Config Class Initialized
INFO - 2024-10-21 23:50:12 --> Loader Class Initialized
INFO - 2024-10-21 23:50:12 --> Helper loaded: url_helper
INFO - 2024-10-21 23:50:12 --> Helper loaded: file_helper
INFO - 2024-10-21 23:50:12 --> Helper loaded: form_helper
INFO - 2024-10-21 23:50:12 --> Helper loaded: my_helper
INFO - 2024-10-21 23:50:12 --> Database Driver Class Initialized
INFO - 2024-10-21 23:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:50:12 --> Controller Class Initialized
DEBUG - 2024-10-21 23:50:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:50:16 --> Final output sent to browser
DEBUG - 2024-10-21 23:50:16 --> Total execution time: 3.3598
INFO - 2024-10-21 23:51:03 --> Config Class Initialized
INFO - 2024-10-21 23:51:03 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:51:03 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:51:03 --> Utf8 Class Initialized
INFO - 2024-10-21 23:51:03 --> URI Class Initialized
INFO - 2024-10-21 23:51:03 --> Router Class Initialized
INFO - 2024-10-21 23:51:03 --> Output Class Initialized
INFO - 2024-10-21 23:51:03 --> Security Class Initialized
DEBUG - 2024-10-21 23:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:51:03 --> Input Class Initialized
INFO - 2024-10-21 23:51:03 --> Language Class Initialized
INFO - 2024-10-21 23:51:03 --> Language Class Initialized
INFO - 2024-10-21 23:51:03 --> Config Class Initialized
INFO - 2024-10-21 23:51:03 --> Loader Class Initialized
INFO - 2024-10-21 23:51:03 --> Helper loaded: url_helper
INFO - 2024-10-21 23:51:03 --> Helper loaded: file_helper
INFO - 2024-10-21 23:51:03 --> Helper loaded: form_helper
INFO - 2024-10-21 23:51:03 --> Helper loaded: my_helper
INFO - 2024-10-21 23:51:03 --> Database Driver Class Initialized
INFO - 2024-10-21 23:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:51:03 --> Controller Class Initialized
DEBUG - 2024-10-21 23:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 23:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:51:03 --> Final output sent to browser
DEBUG - 2024-10-21 23:51:03 --> Total execution time: 0.2137
INFO - 2024-10-21 23:51:05 --> Config Class Initialized
INFO - 2024-10-21 23:51:05 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:51:05 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:51:05 --> Utf8 Class Initialized
INFO - 2024-10-21 23:51:05 --> URI Class Initialized
INFO - 2024-10-21 23:51:05 --> Router Class Initialized
INFO - 2024-10-21 23:51:05 --> Output Class Initialized
INFO - 2024-10-21 23:51:05 --> Security Class Initialized
DEBUG - 2024-10-21 23:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:51:05 --> Input Class Initialized
INFO - 2024-10-21 23:51:05 --> Language Class Initialized
INFO - 2024-10-21 23:51:05 --> Language Class Initialized
INFO - 2024-10-21 23:51:05 --> Config Class Initialized
INFO - 2024-10-21 23:51:05 --> Loader Class Initialized
INFO - 2024-10-21 23:51:05 --> Helper loaded: url_helper
INFO - 2024-10-21 23:51:05 --> Helper loaded: file_helper
INFO - 2024-10-21 23:51:05 --> Helper loaded: form_helper
INFO - 2024-10-21 23:51:05 --> Helper loaded: my_helper
INFO - 2024-10-21 23:51:05 --> Database Driver Class Initialized
INFO - 2024-10-21 23:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:51:05 --> Controller Class Initialized
DEBUG - 2024-10-21 23:51:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:51:11 --> Final output sent to browser
DEBUG - 2024-10-21 23:51:11 --> Total execution time: 5.4772
INFO - 2024-10-21 23:52:27 --> Config Class Initialized
INFO - 2024-10-21 23:52:27 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:52:27 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:52:27 --> Utf8 Class Initialized
INFO - 2024-10-21 23:52:27 --> URI Class Initialized
INFO - 2024-10-21 23:52:27 --> Router Class Initialized
INFO - 2024-10-21 23:52:28 --> Output Class Initialized
INFO - 2024-10-21 23:52:28 --> Security Class Initialized
DEBUG - 2024-10-21 23:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:52:28 --> Input Class Initialized
INFO - 2024-10-21 23:52:28 --> Language Class Initialized
INFO - 2024-10-21 23:52:28 --> Language Class Initialized
INFO - 2024-10-21 23:52:28 --> Config Class Initialized
INFO - 2024-10-21 23:52:28 --> Loader Class Initialized
INFO - 2024-10-21 23:52:28 --> Helper loaded: url_helper
INFO - 2024-10-21 23:52:28 --> Helper loaded: file_helper
INFO - 2024-10-21 23:52:28 --> Helper loaded: form_helper
INFO - 2024-10-21 23:52:28 --> Helper loaded: my_helper
INFO - 2024-10-21 23:52:28 --> Database Driver Class Initialized
INFO - 2024-10-21 23:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:52:28 --> Controller Class Initialized
ERROR - 2024-10-21 23:52:28 --> Severity: error --> Exception: syntax error, unexpected '>' /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php 29
INFO - 2024-10-21 23:52:37 --> Config Class Initialized
INFO - 2024-10-21 23:52:37 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:52:37 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:52:37 --> Utf8 Class Initialized
INFO - 2024-10-21 23:52:37 --> URI Class Initialized
INFO - 2024-10-21 23:52:37 --> Router Class Initialized
INFO - 2024-10-21 23:52:37 --> Output Class Initialized
INFO - 2024-10-21 23:52:37 --> Security Class Initialized
DEBUG - 2024-10-21 23:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:52:37 --> Input Class Initialized
INFO - 2024-10-21 23:52:37 --> Language Class Initialized
INFO - 2024-10-21 23:52:37 --> Language Class Initialized
INFO - 2024-10-21 23:52:37 --> Config Class Initialized
INFO - 2024-10-21 23:52:37 --> Loader Class Initialized
INFO - 2024-10-21 23:52:37 --> Helper loaded: url_helper
INFO - 2024-10-21 23:52:37 --> Helper loaded: file_helper
INFO - 2024-10-21 23:52:37 --> Helper loaded: form_helper
INFO - 2024-10-21 23:52:37 --> Helper loaded: my_helper
INFO - 2024-10-21 23:52:37 --> Database Driver Class Initialized
INFO - 2024-10-21 23:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:52:37 --> Controller Class Initialized
DEBUG - 2024-10-21 23:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 23:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:52:37 --> Final output sent to browser
DEBUG - 2024-10-21 23:52:37 --> Total execution time: 0.1716
INFO - 2024-10-21 23:52:39 --> Config Class Initialized
INFO - 2024-10-21 23:52:39 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:52:39 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:52:39 --> Utf8 Class Initialized
INFO - 2024-10-21 23:52:39 --> URI Class Initialized
INFO - 2024-10-21 23:52:39 --> Router Class Initialized
INFO - 2024-10-21 23:52:40 --> Output Class Initialized
INFO - 2024-10-21 23:52:40 --> Security Class Initialized
DEBUG - 2024-10-21 23:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:52:40 --> Input Class Initialized
INFO - 2024-10-21 23:52:40 --> Language Class Initialized
INFO - 2024-10-21 23:52:40 --> Language Class Initialized
INFO - 2024-10-21 23:52:40 --> Config Class Initialized
INFO - 2024-10-21 23:52:40 --> Loader Class Initialized
INFO - 2024-10-21 23:52:40 --> Helper loaded: url_helper
INFO - 2024-10-21 23:52:40 --> Helper loaded: file_helper
INFO - 2024-10-21 23:52:40 --> Helper loaded: form_helper
INFO - 2024-10-21 23:52:40 --> Helper loaded: my_helper
INFO - 2024-10-21 23:52:40 --> Database Driver Class Initialized
INFO - 2024-10-21 23:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:52:40 --> Controller Class Initialized
DEBUG - 2024-10-21 23:52:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:52:44 --> Final output sent to browser
DEBUG - 2024-10-21 23:52:44 --> Total execution time: 4.0745
INFO - 2024-10-21 23:52:54 --> Config Class Initialized
INFO - 2024-10-21 23:52:54 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:52:54 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:52:54 --> Utf8 Class Initialized
INFO - 2024-10-21 23:52:54 --> URI Class Initialized
INFO - 2024-10-21 23:52:54 --> Router Class Initialized
INFO - 2024-10-21 23:52:54 --> Output Class Initialized
INFO - 2024-10-21 23:52:54 --> Security Class Initialized
DEBUG - 2024-10-21 23:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:52:54 --> Input Class Initialized
INFO - 2024-10-21 23:52:54 --> Language Class Initialized
INFO - 2024-10-21 23:52:54 --> Language Class Initialized
INFO - 2024-10-21 23:52:54 --> Config Class Initialized
INFO - 2024-10-21 23:52:54 --> Loader Class Initialized
INFO - 2024-10-21 23:52:54 --> Helper loaded: url_helper
INFO - 2024-10-21 23:52:54 --> Helper loaded: file_helper
INFO - 2024-10-21 23:52:54 --> Helper loaded: form_helper
INFO - 2024-10-21 23:52:54 --> Helper loaded: my_helper
INFO - 2024-10-21 23:52:54 --> Database Driver Class Initialized
INFO - 2024-10-21 23:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:52:55 --> Controller Class Initialized
INFO - 2024-10-21 23:52:55 --> Helper loaded: cookie_helper
INFO - 2024-10-21 23:52:55 --> Config Class Initialized
INFO - 2024-10-21 23:52:55 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:52:55 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:52:55 --> Utf8 Class Initialized
INFO - 2024-10-21 23:52:55 --> URI Class Initialized
INFO - 2024-10-21 23:52:55 --> Router Class Initialized
INFO - 2024-10-21 23:52:55 --> Output Class Initialized
INFO - 2024-10-21 23:52:55 --> Security Class Initialized
DEBUG - 2024-10-21 23:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:52:55 --> Input Class Initialized
INFO - 2024-10-21 23:52:55 --> Language Class Initialized
INFO - 2024-10-21 23:52:55 --> Language Class Initialized
INFO - 2024-10-21 23:52:55 --> Config Class Initialized
INFO - 2024-10-21 23:52:55 --> Loader Class Initialized
INFO - 2024-10-21 23:52:55 --> Helper loaded: url_helper
INFO - 2024-10-21 23:52:55 --> Helper loaded: file_helper
INFO - 2024-10-21 23:52:55 --> Helper loaded: form_helper
INFO - 2024-10-21 23:52:55 --> Helper loaded: my_helper
INFO - 2024-10-21 23:52:55 --> Database Driver Class Initialized
INFO - 2024-10-21 23:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:52:55 --> Controller Class Initialized
INFO - 2024-10-21 23:52:55 --> Config Class Initialized
INFO - 2024-10-21 23:52:55 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:52:55 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:52:55 --> Utf8 Class Initialized
INFO - 2024-10-21 23:52:55 --> URI Class Initialized
INFO - 2024-10-21 23:52:55 --> Router Class Initialized
INFO - 2024-10-21 23:52:55 --> Output Class Initialized
INFO - 2024-10-21 23:52:55 --> Security Class Initialized
DEBUG - 2024-10-21 23:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:52:55 --> Input Class Initialized
INFO - 2024-10-21 23:52:55 --> Language Class Initialized
INFO - 2024-10-21 23:52:55 --> Language Class Initialized
INFO - 2024-10-21 23:52:55 --> Config Class Initialized
INFO - 2024-10-21 23:52:55 --> Loader Class Initialized
INFO - 2024-10-21 23:52:55 --> Helper loaded: url_helper
INFO - 2024-10-21 23:52:55 --> Helper loaded: file_helper
INFO - 2024-10-21 23:52:55 --> Helper loaded: form_helper
INFO - 2024-10-21 23:52:55 --> Helper loaded: my_helper
INFO - 2024-10-21 23:52:55 --> Database Driver Class Initialized
INFO - 2024-10-21 23:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:52:55 --> Controller Class Initialized
DEBUG - 2024-10-21 23:52:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-21 23:52:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:52:55 --> Final output sent to browser
DEBUG - 2024-10-21 23:52:55 --> Total execution time: 0.0308
INFO - 2024-10-21 23:53:13 --> Config Class Initialized
INFO - 2024-10-21 23:53:13 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:13 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:13 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:13 --> URI Class Initialized
INFO - 2024-10-21 23:53:13 --> Router Class Initialized
INFO - 2024-10-21 23:53:13 --> Output Class Initialized
INFO - 2024-10-21 23:53:13 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:13 --> Input Class Initialized
INFO - 2024-10-21 23:53:13 --> Language Class Initialized
INFO - 2024-10-21 23:53:13 --> Language Class Initialized
INFO - 2024-10-21 23:53:13 --> Config Class Initialized
INFO - 2024-10-21 23:53:13 --> Loader Class Initialized
INFO - 2024-10-21 23:53:13 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:13 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:13 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:13 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:13 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:13 --> Controller Class Initialized
DEBUG - 2024-10-21 23:53:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-21 23:53:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:53:13 --> Final output sent to browser
DEBUG - 2024-10-21 23:53:13 --> Total execution time: 0.0912
INFO - 2024-10-21 23:53:13 --> Config Class Initialized
INFO - 2024-10-21 23:53:13 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:13 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:13 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:13 --> URI Class Initialized
INFO - 2024-10-21 23:53:13 --> Router Class Initialized
INFO - 2024-10-21 23:53:13 --> Output Class Initialized
INFO - 2024-10-21 23:53:13 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:13 --> Input Class Initialized
INFO - 2024-10-21 23:53:13 --> Language Class Initialized
ERROR - 2024-10-21 23:53:13 --> 404 Page Not Found: /index
INFO - 2024-10-21 23:53:13 --> Config Class Initialized
INFO - 2024-10-21 23:53:13 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:13 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:13 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:13 --> URI Class Initialized
INFO - 2024-10-21 23:53:13 --> Router Class Initialized
INFO - 2024-10-21 23:53:13 --> Output Class Initialized
INFO - 2024-10-21 23:53:13 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:13 --> Input Class Initialized
INFO - 2024-10-21 23:53:13 --> Language Class Initialized
INFO - 2024-10-21 23:53:13 --> Language Class Initialized
INFO - 2024-10-21 23:53:13 --> Config Class Initialized
INFO - 2024-10-21 23:53:13 --> Loader Class Initialized
INFO - 2024-10-21 23:53:13 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:13 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:13 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:13 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:13 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:13 --> Controller Class Initialized
INFO - 2024-10-21 23:53:15 --> Config Class Initialized
INFO - 2024-10-21 23:53:15 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:15 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:15 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:15 --> URI Class Initialized
INFO - 2024-10-21 23:53:15 --> Router Class Initialized
INFO - 2024-10-21 23:53:15 --> Output Class Initialized
INFO - 2024-10-21 23:53:15 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:15 --> Input Class Initialized
INFO - 2024-10-21 23:53:15 --> Language Class Initialized
INFO - 2024-10-21 23:53:15 --> Language Class Initialized
INFO - 2024-10-21 23:53:15 --> Config Class Initialized
INFO - 2024-10-21 23:53:15 --> Loader Class Initialized
INFO - 2024-10-21 23:53:15 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:15 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:15 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:15 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:15 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:16 --> Controller Class Initialized
INFO - 2024-10-21 23:53:16 --> Config Class Initialized
INFO - 2024-10-21 23:53:16 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:16 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:16 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:16 --> URI Class Initialized
INFO - 2024-10-21 23:53:16 --> Router Class Initialized
INFO - 2024-10-21 23:53:16 --> Output Class Initialized
INFO - 2024-10-21 23:53:16 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:16 --> Input Class Initialized
INFO - 2024-10-21 23:53:16 --> Language Class Initialized
INFO - 2024-10-21 23:53:16 --> Language Class Initialized
INFO - 2024-10-21 23:53:16 --> Config Class Initialized
INFO - 2024-10-21 23:53:16 --> Loader Class Initialized
INFO - 2024-10-21 23:53:16 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:16 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:16 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:16 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:16 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:16 --> Controller Class Initialized
INFO - 2024-10-21 23:53:17 --> Config Class Initialized
INFO - 2024-10-21 23:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:17 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:17 --> URI Class Initialized
INFO - 2024-10-21 23:53:17 --> Router Class Initialized
INFO - 2024-10-21 23:53:17 --> Output Class Initialized
INFO - 2024-10-21 23:53:17 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:17 --> Input Class Initialized
INFO - 2024-10-21 23:53:17 --> Language Class Initialized
INFO - 2024-10-21 23:53:17 --> Language Class Initialized
INFO - 2024-10-21 23:53:17 --> Config Class Initialized
INFO - 2024-10-21 23:53:17 --> Loader Class Initialized
INFO - 2024-10-21 23:53:17 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:17 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:17 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:17 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:17 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:17 --> Controller Class Initialized
INFO - 2024-10-21 23:53:17 --> Config Class Initialized
INFO - 2024-10-21 23:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:17 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:17 --> Config Class Initialized
INFO - 2024-10-21 23:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:17 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:17 --> URI Class Initialized
INFO - 2024-10-21 23:53:17 --> Router Class Initialized
INFO - 2024-10-21 23:53:17 --> Output Class Initialized
INFO - 2024-10-21 23:53:17 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:17 --> Input Class Initialized
INFO - 2024-10-21 23:53:17 --> Language Class Initialized
INFO - 2024-10-21 23:53:17 --> URI Class Initialized
INFO - 2024-10-21 23:53:17 --> Language Class Initialized
INFO - 2024-10-21 23:53:17 --> Config Class Initialized
INFO - 2024-10-21 23:53:17 --> Loader Class Initialized
INFO - 2024-10-21 23:53:17 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:17 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:17 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:17 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:17 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:17 --> Controller Class Initialized
INFO - 2024-10-21 23:53:17 --> Router Class Initialized
INFO - 2024-10-21 23:53:18 --> Output Class Initialized
INFO - 2024-10-21 23:53:18 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:18 --> Input Class Initialized
INFO - 2024-10-21 23:53:18 --> Language Class Initialized
INFO - 2024-10-21 23:53:18 --> Language Class Initialized
INFO - 2024-10-21 23:53:18 --> Config Class Initialized
INFO - 2024-10-21 23:53:18 --> Loader Class Initialized
INFO - 2024-10-21 23:53:18 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:18 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:18 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:18 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:18 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:18 --> Controller Class Initialized
INFO - 2024-10-21 23:53:20 --> Config Class Initialized
INFO - 2024-10-21 23:53:20 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:20 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:20 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:20 --> URI Class Initialized
INFO - 2024-10-21 23:53:20 --> Router Class Initialized
INFO - 2024-10-21 23:53:20 --> Output Class Initialized
INFO - 2024-10-21 23:53:20 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:20 --> Input Class Initialized
INFO - 2024-10-21 23:53:20 --> Language Class Initialized
INFO - 2024-10-21 23:53:20 --> Language Class Initialized
INFO - 2024-10-21 23:53:20 --> Config Class Initialized
INFO - 2024-10-21 23:53:20 --> Loader Class Initialized
INFO - 2024-10-21 23:53:20 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:20 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:20 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:20 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:20 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:20 --> Controller Class Initialized
INFO - 2024-10-21 23:53:20 --> Config Class Initialized
INFO - 2024-10-21 23:53:20 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:20 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:20 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:20 --> URI Class Initialized
INFO - 2024-10-21 23:53:20 --> Router Class Initialized
INFO - 2024-10-21 23:53:20 --> Output Class Initialized
INFO - 2024-10-21 23:53:20 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:20 --> Input Class Initialized
INFO - 2024-10-21 23:53:20 --> Language Class Initialized
INFO - 2024-10-21 23:53:20 --> Language Class Initialized
INFO - 2024-10-21 23:53:20 --> Config Class Initialized
INFO - 2024-10-21 23:53:20 --> Loader Class Initialized
INFO - 2024-10-21 23:53:20 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:20 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:20 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:20 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:20 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:20 --> Controller Class Initialized
INFO - 2024-10-21 23:53:37 --> Config Class Initialized
INFO - 2024-10-21 23:53:37 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:37 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:37 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:37 --> URI Class Initialized
INFO - 2024-10-21 23:53:37 --> Router Class Initialized
INFO - 2024-10-21 23:53:37 --> Output Class Initialized
INFO - 2024-10-21 23:53:37 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:37 --> Input Class Initialized
INFO - 2024-10-21 23:53:37 --> Language Class Initialized
INFO - 2024-10-21 23:53:37 --> Language Class Initialized
INFO - 2024-10-21 23:53:37 --> Config Class Initialized
INFO - 2024-10-21 23:53:37 --> Loader Class Initialized
INFO - 2024-10-21 23:53:37 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:37 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:37 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:37 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:37 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:37 --> Controller Class Initialized
DEBUG - 2024-10-21 23:53:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-21 23:53:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:53:37 --> Final output sent to browser
DEBUG - 2024-10-21 23:53:37 --> Total execution time: 0.1761
INFO - 2024-10-21 23:53:44 --> Config Class Initialized
INFO - 2024-10-21 23:53:44 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:44 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:44 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:44 --> URI Class Initialized
INFO - 2024-10-21 23:53:44 --> Router Class Initialized
INFO - 2024-10-21 23:53:44 --> Output Class Initialized
INFO - 2024-10-21 23:53:44 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:44 --> Input Class Initialized
INFO - 2024-10-21 23:53:44 --> Language Class Initialized
INFO - 2024-10-21 23:53:44 --> Language Class Initialized
INFO - 2024-10-21 23:53:44 --> Config Class Initialized
INFO - 2024-10-21 23:53:44 --> Loader Class Initialized
INFO - 2024-10-21 23:53:44 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:44 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:44 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:44 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:44 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:44 --> Controller Class Initialized
DEBUG - 2024-10-21 23:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-21 23:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:53:44 --> Final output sent to browser
DEBUG - 2024-10-21 23:53:44 --> Total execution time: 0.0327
INFO - 2024-10-21 23:53:44 --> Config Class Initialized
INFO - 2024-10-21 23:53:44 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:44 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:44 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:44 --> URI Class Initialized
INFO - 2024-10-21 23:53:44 --> Router Class Initialized
INFO - 2024-10-21 23:53:44 --> Output Class Initialized
INFO - 2024-10-21 23:53:44 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:44 --> Input Class Initialized
INFO - 2024-10-21 23:53:44 --> Language Class Initialized
ERROR - 2024-10-21 23:53:44 --> 404 Page Not Found: /index
INFO - 2024-10-21 23:53:44 --> Config Class Initialized
INFO - 2024-10-21 23:53:44 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:44 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:44 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:44 --> URI Class Initialized
INFO - 2024-10-21 23:53:44 --> Router Class Initialized
INFO - 2024-10-21 23:53:44 --> Output Class Initialized
INFO - 2024-10-21 23:53:44 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:44 --> Input Class Initialized
INFO - 2024-10-21 23:53:44 --> Language Class Initialized
INFO - 2024-10-21 23:53:44 --> Language Class Initialized
INFO - 2024-10-21 23:53:44 --> Config Class Initialized
INFO - 2024-10-21 23:53:44 --> Loader Class Initialized
INFO - 2024-10-21 23:53:44 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:44 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:44 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:44 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:44 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:44 --> Controller Class Initialized
INFO - 2024-10-21 23:53:46 --> Config Class Initialized
INFO - 2024-10-21 23:53:46 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:46 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:46 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:46 --> URI Class Initialized
INFO - 2024-10-21 23:53:46 --> Router Class Initialized
INFO - 2024-10-21 23:53:46 --> Output Class Initialized
INFO - 2024-10-21 23:53:46 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:46 --> Input Class Initialized
INFO - 2024-10-21 23:53:46 --> Language Class Initialized
INFO - 2024-10-21 23:53:46 --> Language Class Initialized
INFO - 2024-10-21 23:53:46 --> Config Class Initialized
INFO - 2024-10-21 23:53:46 --> Loader Class Initialized
INFO - 2024-10-21 23:53:46 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:46 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:46 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:46 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:46 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:46 --> Controller Class Initialized
INFO - 2024-10-21 23:53:53 --> Config Class Initialized
INFO - 2024-10-21 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:53 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:53 --> URI Class Initialized
INFO - 2024-10-21 23:53:53 --> Router Class Initialized
INFO - 2024-10-21 23:53:53 --> Output Class Initialized
INFO - 2024-10-21 23:53:53 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:53 --> Input Class Initialized
INFO - 2024-10-21 23:53:53 --> Language Class Initialized
INFO - 2024-10-21 23:53:53 --> Language Class Initialized
INFO - 2024-10-21 23:53:53 --> Config Class Initialized
INFO - 2024-10-21 23:53:53 --> Loader Class Initialized
INFO - 2024-10-21 23:53:53 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:53 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:53 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:53 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:53 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:53 --> Controller Class Initialized
INFO - 2024-10-21 23:53:53 --> Helper loaded: cookie_helper
INFO - 2024-10-21 23:53:53 --> Final output sent to browser
DEBUG - 2024-10-21 23:53:53 --> Total execution time: 0.0451
INFO - 2024-10-21 23:53:53 --> Config Class Initialized
INFO - 2024-10-21 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:53 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:53 --> URI Class Initialized
INFO - 2024-10-21 23:53:53 --> Router Class Initialized
INFO - 2024-10-21 23:53:53 --> Output Class Initialized
INFO - 2024-10-21 23:53:53 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:53 --> Input Class Initialized
INFO - 2024-10-21 23:53:53 --> Language Class Initialized
INFO - 2024-10-21 23:53:53 --> Language Class Initialized
INFO - 2024-10-21 23:53:53 --> Config Class Initialized
INFO - 2024-10-21 23:53:53 --> Loader Class Initialized
INFO - 2024-10-21 23:53:53 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:53 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:53 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:53 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:53 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:53 --> Controller Class Initialized
DEBUG - 2024-10-21 23:53:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-21 23:53:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:53:53 --> Final output sent to browser
DEBUG - 2024-10-21 23:53:53 --> Total execution time: 0.0315
INFO - 2024-10-21 23:53:55 --> Config Class Initialized
INFO - 2024-10-21 23:53:55 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:55 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:55 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:55 --> URI Class Initialized
INFO - 2024-10-21 23:53:55 --> Router Class Initialized
INFO - 2024-10-21 23:53:55 --> Output Class Initialized
INFO - 2024-10-21 23:53:55 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:55 --> Input Class Initialized
INFO - 2024-10-21 23:53:55 --> Language Class Initialized
INFO - 2024-10-21 23:53:55 --> Language Class Initialized
INFO - 2024-10-21 23:53:55 --> Config Class Initialized
INFO - 2024-10-21 23:53:55 --> Loader Class Initialized
INFO - 2024-10-21 23:53:55 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:55 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:55 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:55 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:55 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:55 --> Controller Class Initialized
DEBUG - 2024-10-21 23:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-21 23:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-21 23:53:55 --> Final output sent to browser
DEBUG - 2024-10-21 23:53:55 --> Total execution time: 0.2874
INFO - 2024-10-21 23:53:56 --> Config Class Initialized
INFO - 2024-10-21 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:53:56 --> Utf8 Class Initialized
INFO - 2024-10-21 23:53:56 --> URI Class Initialized
INFO - 2024-10-21 23:53:56 --> Router Class Initialized
INFO - 2024-10-21 23:53:56 --> Output Class Initialized
INFO - 2024-10-21 23:53:56 --> Security Class Initialized
DEBUG - 2024-10-21 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:53:56 --> Input Class Initialized
INFO - 2024-10-21 23:53:56 --> Language Class Initialized
INFO - 2024-10-21 23:53:56 --> Language Class Initialized
INFO - 2024-10-21 23:53:56 --> Config Class Initialized
INFO - 2024-10-21 23:53:56 --> Loader Class Initialized
INFO - 2024-10-21 23:53:56 --> Helper loaded: url_helper
INFO - 2024-10-21 23:53:56 --> Helper loaded: file_helper
INFO - 2024-10-21 23:53:57 --> Helper loaded: form_helper
INFO - 2024-10-21 23:53:57 --> Helper loaded: my_helper
INFO - 2024-10-21 23:53:57 --> Database Driver Class Initialized
INFO - 2024-10-21 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:53:57 --> Controller Class Initialized
DEBUG - 2024-10-21 23:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:54:02 --> Final output sent to browser
DEBUG - 2024-10-21 23:54:02 --> Total execution time: 5.1733
INFO - 2024-10-21 23:55:35 --> Config Class Initialized
INFO - 2024-10-21 23:55:35 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:55:35 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:55:35 --> Utf8 Class Initialized
INFO - 2024-10-21 23:55:35 --> URI Class Initialized
INFO - 2024-10-21 23:55:35 --> Router Class Initialized
INFO - 2024-10-21 23:55:35 --> Output Class Initialized
INFO - 2024-10-21 23:55:35 --> Security Class Initialized
DEBUG - 2024-10-21 23:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:55:35 --> Input Class Initialized
INFO - 2024-10-21 23:55:35 --> Language Class Initialized
INFO - 2024-10-21 23:55:35 --> Language Class Initialized
INFO - 2024-10-21 23:55:35 --> Config Class Initialized
INFO - 2024-10-21 23:55:35 --> Loader Class Initialized
INFO - 2024-10-21 23:55:35 --> Helper loaded: url_helper
INFO - 2024-10-21 23:55:35 --> Helper loaded: file_helper
INFO - 2024-10-21 23:55:35 --> Helper loaded: form_helper
INFO - 2024-10-21 23:55:35 --> Helper loaded: my_helper
INFO - 2024-10-21 23:55:36 --> Database Driver Class Initialized
INFO - 2024-10-21 23:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:55:36 --> Controller Class Initialized
DEBUG - 2024-10-21 23:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:55:39 --> Final output sent to browser
DEBUG - 2024-10-21 23:55:39 --> Total execution time: 3.5654
INFO - 2024-10-21 23:56:03 --> Config Class Initialized
INFO - 2024-10-21 23:56:03 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:56:03 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:56:03 --> Utf8 Class Initialized
INFO - 2024-10-21 23:56:03 --> URI Class Initialized
INFO - 2024-10-21 23:56:03 --> Router Class Initialized
INFO - 2024-10-21 23:56:03 --> Output Class Initialized
INFO - 2024-10-21 23:56:03 --> Security Class Initialized
DEBUG - 2024-10-21 23:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:56:03 --> Input Class Initialized
INFO - 2024-10-21 23:56:03 --> Language Class Initialized
INFO - 2024-10-21 23:56:03 --> Language Class Initialized
INFO - 2024-10-21 23:56:03 --> Config Class Initialized
INFO - 2024-10-21 23:56:03 --> Loader Class Initialized
INFO - 2024-10-21 23:56:03 --> Helper loaded: url_helper
INFO - 2024-10-21 23:56:03 --> Helper loaded: file_helper
INFO - 2024-10-21 23:56:03 --> Helper loaded: form_helper
INFO - 2024-10-21 23:56:03 --> Helper loaded: my_helper
INFO - 2024-10-21 23:56:03 --> Database Driver Class Initialized
INFO - 2024-10-21 23:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:56:03 --> Controller Class Initialized
DEBUG - 2024-10-21 23:56:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:56:07 --> Final output sent to browser
DEBUG - 2024-10-21 23:56:07 --> Total execution time: 4.1549
INFO - 2024-10-21 23:56:27 --> Config Class Initialized
INFO - 2024-10-21 23:56:27 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:56:27 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:56:27 --> Utf8 Class Initialized
INFO - 2024-10-21 23:56:27 --> URI Class Initialized
INFO - 2024-10-21 23:56:27 --> Router Class Initialized
INFO - 2024-10-21 23:56:27 --> Output Class Initialized
INFO - 2024-10-21 23:56:27 --> Security Class Initialized
DEBUG - 2024-10-21 23:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:56:27 --> Input Class Initialized
INFO - 2024-10-21 23:56:27 --> Language Class Initialized
INFO - 2024-10-21 23:56:27 --> Language Class Initialized
INFO - 2024-10-21 23:56:27 --> Config Class Initialized
INFO - 2024-10-21 23:56:27 --> Loader Class Initialized
INFO - 2024-10-21 23:56:27 --> Helper loaded: url_helper
INFO - 2024-10-21 23:56:27 --> Helper loaded: file_helper
INFO - 2024-10-21 23:56:27 --> Helper loaded: form_helper
INFO - 2024-10-21 23:56:27 --> Helper loaded: my_helper
INFO - 2024-10-21 23:56:27 --> Database Driver Class Initialized
INFO - 2024-10-21 23:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:56:27 --> Controller Class Initialized
DEBUG - 2024-10-21 23:56:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:56:31 --> Final output sent to browser
DEBUG - 2024-10-21 23:56:31 --> Total execution time: 4.5172
INFO - 2024-10-21 23:56:50 --> Config Class Initialized
INFO - 2024-10-21 23:56:50 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:56:50 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:56:50 --> Utf8 Class Initialized
INFO - 2024-10-21 23:56:50 --> URI Class Initialized
INFO - 2024-10-21 23:56:50 --> Router Class Initialized
INFO - 2024-10-21 23:56:50 --> Output Class Initialized
INFO - 2024-10-21 23:56:50 --> Security Class Initialized
DEBUG - 2024-10-21 23:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:56:50 --> Input Class Initialized
INFO - 2024-10-21 23:56:50 --> Language Class Initialized
INFO - 2024-10-21 23:56:50 --> Language Class Initialized
INFO - 2024-10-21 23:56:50 --> Config Class Initialized
INFO - 2024-10-21 23:56:50 --> Loader Class Initialized
INFO - 2024-10-21 23:56:50 --> Helper loaded: url_helper
INFO - 2024-10-21 23:56:50 --> Helper loaded: file_helper
INFO - 2024-10-21 23:56:50 --> Helper loaded: form_helper
INFO - 2024-10-21 23:56:50 --> Helper loaded: my_helper
INFO - 2024-10-21 23:56:50 --> Database Driver Class Initialized
INFO - 2024-10-21 23:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:56:50 --> Controller Class Initialized
DEBUG - 2024-10-21 23:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:56:54 --> Final output sent to browser
DEBUG - 2024-10-21 23:56:54 --> Total execution time: 3.8977
INFO - 2024-10-21 23:57:05 --> Config Class Initialized
INFO - 2024-10-21 23:57:05 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:57:05 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:57:05 --> Utf8 Class Initialized
INFO - 2024-10-21 23:57:05 --> URI Class Initialized
INFO - 2024-10-21 23:57:05 --> Router Class Initialized
INFO - 2024-10-21 23:57:05 --> Output Class Initialized
INFO - 2024-10-21 23:57:05 --> Security Class Initialized
DEBUG - 2024-10-21 23:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:57:05 --> Input Class Initialized
INFO - 2024-10-21 23:57:05 --> Language Class Initialized
INFO - 2024-10-21 23:57:05 --> Language Class Initialized
INFO - 2024-10-21 23:57:05 --> Config Class Initialized
INFO - 2024-10-21 23:57:05 --> Loader Class Initialized
INFO - 2024-10-21 23:57:05 --> Helper loaded: url_helper
INFO - 2024-10-21 23:57:05 --> Helper loaded: file_helper
INFO - 2024-10-21 23:57:05 --> Helper loaded: form_helper
INFO - 2024-10-21 23:57:05 --> Helper loaded: my_helper
INFO - 2024-10-21 23:57:05 --> Database Driver Class Initialized
INFO - 2024-10-21 23:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:57:05 --> Controller Class Initialized
DEBUG - 2024-10-21 23:57:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:57:09 --> Final output sent to browser
DEBUG - 2024-10-21 23:57:09 --> Total execution time: 4.2617
INFO - 2024-10-21 23:57:44 --> Config Class Initialized
INFO - 2024-10-21 23:57:44 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:57:44 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:57:44 --> Utf8 Class Initialized
INFO - 2024-10-21 23:57:44 --> URI Class Initialized
INFO - 2024-10-21 23:57:44 --> Router Class Initialized
INFO - 2024-10-21 23:57:44 --> Output Class Initialized
INFO - 2024-10-21 23:57:44 --> Security Class Initialized
DEBUG - 2024-10-21 23:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:57:44 --> Input Class Initialized
INFO - 2024-10-21 23:57:44 --> Language Class Initialized
INFO - 2024-10-21 23:57:44 --> Language Class Initialized
INFO - 2024-10-21 23:57:44 --> Config Class Initialized
INFO - 2024-10-21 23:57:44 --> Loader Class Initialized
INFO - 2024-10-21 23:57:44 --> Helper loaded: url_helper
INFO - 2024-10-21 23:57:44 --> Helper loaded: file_helper
INFO - 2024-10-21 23:57:44 --> Helper loaded: form_helper
INFO - 2024-10-21 23:57:44 --> Helper loaded: my_helper
INFO - 2024-10-21 23:57:44 --> Database Driver Class Initialized
INFO - 2024-10-21 23:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:57:44 --> Controller Class Initialized
DEBUG - 2024-10-21 23:57:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:57:48 --> Final output sent to browser
DEBUG - 2024-10-21 23:57:48 --> Total execution time: 3.8218
INFO - 2024-10-21 23:58:23 --> Config Class Initialized
INFO - 2024-10-21 23:58:23 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:58:23 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:58:23 --> Utf8 Class Initialized
INFO - 2024-10-21 23:58:23 --> URI Class Initialized
INFO - 2024-10-21 23:58:23 --> Router Class Initialized
INFO - 2024-10-21 23:58:23 --> Output Class Initialized
INFO - 2024-10-21 23:58:23 --> Security Class Initialized
DEBUG - 2024-10-21 23:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:58:23 --> Input Class Initialized
INFO - 2024-10-21 23:58:23 --> Language Class Initialized
INFO - 2024-10-21 23:58:23 --> Language Class Initialized
INFO - 2024-10-21 23:58:23 --> Config Class Initialized
INFO - 2024-10-21 23:58:23 --> Loader Class Initialized
INFO - 2024-10-21 23:58:23 --> Helper loaded: url_helper
INFO - 2024-10-21 23:58:23 --> Helper loaded: file_helper
INFO - 2024-10-21 23:58:23 --> Helper loaded: form_helper
INFO - 2024-10-21 23:58:23 --> Helper loaded: my_helper
INFO - 2024-10-21 23:58:23 --> Database Driver Class Initialized
INFO - 2024-10-21 23:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:58:23 --> Controller Class Initialized
DEBUG - 2024-10-21 23:58:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:58:28 --> Final output sent to browser
DEBUG - 2024-10-21 23:58:28 --> Total execution time: 5.1800
INFO - 2024-10-21 23:58:41 --> Config Class Initialized
INFO - 2024-10-21 23:58:41 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:58:41 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:58:41 --> Utf8 Class Initialized
INFO - 2024-10-21 23:58:41 --> URI Class Initialized
INFO - 2024-10-21 23:58:41 --> Router Class Initialized
INFO - 2024-10-21 23:58:41 --> Output Class Initialized
INFO - 2024-10-21 23:58:41 --> Security Class Initialized
DEBUG - 2024-10-21 23:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:58:41 --> Input Class Initialized
INFO - 2024-10-21 23:58:41 --> Language Class Initialized
INFO - 2024-10-21 23:58:41 --> Language Class Initialized
INFO - 2024-10-21 23:58:41 --> Config Class Initialized
INFO - 2024-10-21 23:58:41 --> Loader Class Initialized
INFO - 2024-10-21 23:58:41 --> Helper loaded: url_helper
INFO - 2024-10-21 23:58:41 --> Helper loaded: file_helper
INFO - 2024-10-21 23:58:41 --> Helper loaded: form_helper
INFO - 2024-10-21 23:58:41 --> Helper loaded: my_helper
INFO - 2024-10-21 23:58:41 --> Database Driver Class Initialized
INFO - 2024-10-21 23:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:58:41 --> Controller Class Initialized
DEBUG - 2024-10-21 23:58:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:58:44 --> Final output sent to browser
DEBUG - 2024-10-21 23:58:44 --> Total execution time: 3.6395
INFO - 2024-10-21 23:59:11 --> Config Class Initialized
INFO - 2024-10-21 23:59:11 --> Hooks Class Initialized
DEBUG - 2024-10-21 23:59:11 --> UTF-8 Support Enabled
INFO - 2024-10-21 23:59:11 --> Utf8 Class Initialized
INFO - 2024-10-21 23:59:11 --> URI Class Initialized
INFO - 2024-10-21 23:59:11 --> Router Class Initialized
INFO - 2024-10-21 23:59:11 --> Output Class Initialized
INFO - 2024-10-21 23:59:11 --> Security Class Initialized
DEBUG - 2024-10-21 23:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 23:59:11 --> Input Class Initialized
INFO - 2024-10-21 23:59:11 --> Language Class Initialized
INFO - 2024-10-21 23:59:11 --> Language Class Initialized
INFO - 2024-10-21 23:59:11 --> Config Class Initialized
INFO - 2024-10-21 23:59:11 --> Loader Class Initialized
INFO - 2024-10-21 23:59:11 --> Helper loaded: url_helper
INFO - 2024-10-21 23:59:11 --> Helper loaded: file_helper
INFO - 2024-10-21 23:59:11 --> Helper loaded: form_helper
INFO - 2024-10-21 23:59:11 --> Helper loaded: my_helper
INFO - 2024-10-21 23:59:11 --> Database Driver Class Initialized
INFO - 2024-10-21 23:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 23:59:11 --> Controller Class Initialized
DEBUG - 2024-10-21 23:59:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-21 23:59:16 --> Final output sent to browser
DEBUG - 2024-10-21 23:59:16 --> Total execution time: 5.2391
