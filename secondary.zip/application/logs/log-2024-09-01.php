<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-01 01:05:03 --> Config Class Initialized
INFO - 2024-09-01 01:05:03 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:03 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:03 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:03 --> URI Class Initialized
INFO - 2024-09-01 01:05:03 --> Router Class Initialized
INFO - 2024-09-01 01:05:03 --> Output Class Initialized
INFO - 2024-09-01 01:05:03 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:03 --> Input Class Initialized
INFO - 2024-09-01 01:05:03 --> Language Class Initialized
INFO - 2024-09-01 01:05:03 --> Language Class Initialized
INFO - 2024-09-01 01:05:03 --> Config Class Initialized
INFO - 2024-09-01 01:05:03 --> Loader Class Initialized
INFO - 2024-09-01 01:05:03 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:03 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:03 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:03 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:03 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:03 --> Controller Class Initialized
INFO - 2024-09-01 01:05:04 --> Helper loaded: cookie_helper
INFO - 2024-09-01 01:05:04 --> Final output sent to browser
DEBUG - 2024-09-01 01:05:04 --> Total execution time: 0.1299
INFO - 2024-09-01 01:05:04 --> Config Class Initialized
INFO - 2024-09-01 01:05:04 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:04 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:04 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:04 --> URI Class Initialized
INFO - 2024-09-01 01:05:04 --> Router Class Initialized
INFO - 2024-09-01 01:05:04 --> Output Class Initialized
INFO - 2024-09-01 01:05:04 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:04 --> Input Class Initialized
INFO - 2024-09-01 01:05:04 --> Language Class Initialized
INFO - 2024-09-01 01:05:04 --> Language Class Initialized
INFO - 2024-09-01 01:05:04 --> Config Class Initialized
INFO - 2024-09-01 01:05:04 --> Loader Class Initialized
INFO - 2024-09-01 01:05:04 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:04 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:04 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:04 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:04 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:04 --> Controller Class Initialized
INFO - 2024-09-01 01:05:04 --> Helper loaded: cookie_helper
INFO - 2024-09-01 01:05:04 --> Config Class Initialized
INFO - 2024-09-01 01:05:04 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:04 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:04 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:04 --> URI Class Initialized
INFO - 2024-09-01 01:05:04 --> Router Class Initialized
INFO - 2024-09-01 01:05:04 --> Output Class Initialized
INFO - 2024-09-01 01:05:04 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:04 --> Input Class Initialized
INFO - 2024-09-01 01:05:04 --> Language Class Initialized
INFO - 2024-09-01 01:05:04 --> Language Class Initialized
INFO - 2024-09-01 01:05:04 --> Config Class Initialized
INFO - 2024-09-01 01:05:04 --> Loader Class Initialized
INFO - 2024-09-01 01:05:04 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:04 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:04 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:04 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:04 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:04 --> Controller Class Initialized
DEBUG - 2024-09-01 01:05:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-01 01:05:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-01 01:05:04 --> Final output sent to browser
DEBUG - 2024-09-01 01:05:04 --> Total execution time: 0.0740
INFO - 2024-09-01 01:05:14 --> Config Class Initialized
INFO - 2024-09-01 01:05:14 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:14 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:14 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:14 --> URI Class Initialized
INFO - 2024-09-01 01:05:14 --> Router Class Initialized
INFO - 2024-09-01 01:05:14 --> Output Class Initialized
INFO - 2024-09-01 01:05:14 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:14 --> Input Class Initialized
INFO - 2024-09-01 01:05:14 --> Language Class Initialized
INFO - 2024-09-01 01:05:14 --> Language Class Initialized
INFO - 2024-09-01 01:05:14 --> Config Class Initialized
INFO - 2024-09-01 01:05:14 --> Loader Class Initialized
INFO - 2024-09-01 01:05:14 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:14 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:14 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:14 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:14 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:14 --> Controller Class Initialized
DEBUG - 2024-09-01 01:05:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-01 01:05:18 --> Final output sent to browser
DEBUG - 2024-09-01 01:05:18 --> Total execution time: 4.1321
INFO - 2024-09-01 01:05:18 --> Config Class Initialized
INFO - 2024-09-01 01:05:18 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:18 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:18 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:18 --> URI Class Initialized
INFO - 2024-09-01 01:05:18 --> Router Class Initialized
INFO - 2024-09-01 01:05:18 --> Output Class Initialized
INFO - 2024-09-01 01:05:18 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:18 --> Input Class Initialized
INFO - 2024-09-01 01:05:18 --> Language Class Initialized
INFO - 2024-09-01 01:05:18 --> Language Class Initialized
INFO - 2024-09-01 01:05:18 --> Config Class Initialized
INFO - 2024-09-01 01:05:18 --> Loader Class Initialized
INFO - 2024-09-01 01:05:18 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:18 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:18 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:18 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:18 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:18 --> Controller Class Initialized
DEBUG - 2024-09-01 01:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-01 01:05:22 --> Final output sent to browser
DEBUG - 2024-09-01 01:05:22 --> Total execution time: 3.4115
INFO - 2024-09-01 01:05:22 --> Config Class Initialized
INFO - 2024-09-01 01:05:22 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:22 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:22 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:22 --> URI Class Initialized
INFO - 2024-09-01 01:05:22 --> Router Class Initialized
INFO - 2024-09-01 01:05:22 --> Output Class Initialized
INFO - 2024-09-01 01:05:22 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:22 --> Input Class Initialized
INFO - 2024-09-01 01:05:22 --> Language Class Initialized
INFO - 2024-09-01 01:05:22 --> Language Class Initialized
INFO - 2024-09-01 01:05:22 --> Config Class Initialized
INFO - 2024-09-01 01:05:22 --> Loader Class Initialized
INFO - 2024-09-01 01:05:22 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:22 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:22 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:22 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:22 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:22 --> Controller Class Initialized
DEBUG - 2024-09-01 01:05:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-01 01:05:22 --> Config Class Initialized
INFO - 2024-09-01 01:05:22 --> Hooks Class Initialized
DEBUG - 2024-09-01 01:05:22 --> UTF-8 Support Enabled
INFO - 2024-09-01 01:05:22 --> Utf8 Class Initialized
INFO - 2024-09-01 01:05:22 --> URI Class Initialized
INFO - 2024-09-01 01:05:22 --> Router Class Initialized
INFO - 2024-09-01 01:05:22 --> Output Class Initialized
INFO - 2024-09-01 01:05:22 --> Security Class Initialized
DEBUG - 2024-09-01 01:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-01 01:05:22 --> Input Class Initialized
INFO - 2024-09-01 01:05:22 --> Language Class Initialized
INFO - 2024-09-01 01:05:22 --> Language Class Initialized
INFO - 2024-09-01 01:05:22 --> Config Class Initialized
INFO - 2024-09-01 01:05:22 --> Loader Class Initialized
INFO - 2024-09-01 01:05:22 --> Helper loaded: url_helper
INFO - 2024-09-01 01:05:22 --> Helper loaded: file_helper
INFO - 2024-09-01 01:05:22 --> Helper loaded: form_helper
INFO - 2024-09-01 01:05:22 --> Helper loaded: my_helper
INFO - 2024-09-01 01:05:22 --> Database Driver Class Initialized
INFO - 2024-09-01 01:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-01 01:05:25 --> Controller Class Initialized
DEBUG - 2024-09-01 01:05:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
