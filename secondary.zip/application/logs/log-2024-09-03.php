<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-03 10:03:38 --> Config Class Initialized
INFO - 2024-09-03 10:03:38 --> Hooks Class Initialized
DEBUG - 2024-09-03 10:03:38 --> UTF-8 Support Enabled
INFO - 2024-09-03 10:03:38 --> Utf8 Class Initialized
INFO - 2024-09-03 10:03:38 --> URI Class Initialized
INFO - 2024-09-03 10:03:38 --> Router Class Initialized
INFO - 2024-09-03 10:03:38 --> Output Class Initialized
INFO - 2024-09-03 10:03:38 --> Security Class Initialized
DEBUG - 2024-09-03 10:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 10:03:38 --> Input Class Initialized
INFO - 2024-09-03 10:03:38 --> Language Class Initialized
INFO - 2024-09-03 10:03:38 --> Language Class Initialized
INFO - 2024-09-03 10:03:38 --> Config Class Initialized
INFO - 2024-09-03 10:03:38 --> Loader Class Initialized
INFO - 2024-09-03 10:03:38 --> Helper loaded: url_helper
INFO - 2024-09-03 10:03:38 --> Helper loaded: file_helper
INFO - 2024-09-03 10:03:38 --> Helper loaded: form_helper
INFO - 2024-09-03 10:03:38 --> Helper loaded: my_helper
INFO - 2024-09-03 10:03:38 --> Database Driver Class Initialized
INFO - 2024-09-03 10:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 10:03:38 --> Controller Class Initialized
INFO - 2024-09-03 10:03:38 --> Helper loaded: cookie_helper
INFO - 2024-09-03 10:03:38 --> Final output sent to browser
DEBUG - 2024-09-03 10:03:38 --> Total execution time: 0.0744
INFO - 2024-09-03 10:03:39 --> Config Class Initialized
INFO - 2024-09-03 10:03:39 --> Hooks Class Initialized
DEBUG - 2024-09-03 10:03:39 --> UTF-8 Support Enabled
INFO - 2024-09-03 10:03:39 --> Utf8 Class Initialized
INFO - 2024-09-03 10:03:39 --> URI Class Initialized
INFO - 2024-09-03 10:03:39 --> Router Class Initialized
INFO - 2024-09-03 10:03:39 --> Output Class Initialized
INFO - 2024-09-03 10:03:39 --> Security Class Initialized
DEBUG - 2024-09-03 10:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 10:03:39 --> Input Class Initialized
INFO - 2024-09-03 10:03:39 --> Language Class Initialized
INFO - 2024-09-03 10:03:39 --> Language Class Initialized
INFO - 2024-09-03 10:03:39 --> Config Class Initialized
INFO - 2024-09-03 10:03:39 --> Loader Class Initialized
INFO - 2024-09-03 10:03:39 --> Helper loaded: url_helper
INFO - 2024-09-03 10:03:39 --> Helper loaded: file_helper
INFO - 2024-09-03 10:03:39 --> Helper loaded: form_helper
INFO - 2024-09-03 10:03:39 --> Helper loaded: my_helper
INFO - 2024-09-03 10:03:39 --> Database Driver Class Initialized
INFO - 2024-09-03 10:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 10:03:39 --> Controller Class Initialized
INFO - 2024-09-03 10:03:39 --> Helper loaded: cookie_helper
INFO - 2024-09-03 10:03:39 --> Config Class Initialized
INFO - 2024-09-03 10:03:39 --> Hooks Class Initialized
DEBUG - 2024-09-03 10:03:39 --> UTF-8 Support Enabled
INFO - 2024-09-03 10:03:39 --> Utf8 Class Initialized
INFO - 2024-09-03 10:03:39 --> URI Class Initialized
INFO - 2024-09-03 10:03:39 --> Router Class Initialized
INFO - 2024-09-03 10:03:39 --> Output Class Initialized
INFO - 2024-09-03 10:03:39 --> Security Class Initialized
DEBUG - 2024-09-03 10:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 10:03:39 --> Input Class Initialized
INFO - 2024-09-03 10:03:39 --> Language Class Initialized
INFO - 2024-09-03 10:03:39 --> Language Class Initialized
INFO - 2024-09-03 10:03:39 --> Config Class Initialized
INFO - 2024-09-03 10:03:39 --> Loader Class Initialized
INFO - 2024-09-03 10:03:39 --> Helper loaded: url_helper
INFO - 2024-09-03 10:03:39 --> Helper loaded: file_helper
INFO - 2024-09-03 10:03:39 --> Helper loaded: form_helper
INFO - 2024-09-03 10:03:39 --> Helper loaded: my_helper
INFO - 2024-09-03 10:03:39 --> Database Driver Class Initialized
INFO - 2024-09-03 10:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 10:03:39 --> Controller Class Initialized
DEBUG - 2024-09-03 10:03:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-03 10:03:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-03 10:03:39 --> Final output sent to browser
DEBUG - 2024-09-03 10:03:39 --> Total execution time: 0.2219
INFO - 2024-09-03 12:49:04 --> Config Class Initialized
INFO - 2024-09-03 12:49:04 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:04 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:04 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:04 --> URI Class Initialized
INFO - 2024-09-03 12:49:04 --> Router Class Initialized
INFO - 2024-09-03 12:49:04 --> Output Class Initialized
INFO - 2024-09-03 12:49:04 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:04 --> Input Class Initialized
INFO - 2024-09-03 12:49:04 --> Language Class Initialized
INFO - 2024-09-03 12:49:04 --> Language Class Initialized
INFO - 2024-09-03 12:49:04 --> Config Class Initialized
INFO - 2024-09-03 12:49:04 --> Loader Class Initialized
INFO - 2024-09-03 12:49:04 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:04 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:04 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:04 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:04 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:04 --> Controller Class Initialized
INFO - 2024-09-03 12:49:04 --> Helper loaded: cookie_helper
INFO - 2024-09-03 12:49:04 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:04 --> Total execution time: 0.0702
INFO - 2024-09-03 12:49:05 --> Config Class Initialized
INFO - 2024-09-03 12:49:05 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:05 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:05 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:05 --> URI Class Initialized
INFO - 2024-09-03 12:49:05 --> Router Class Initialized
INFO - 2024-09-03 12:49:05 --> Output Class Initialized
INFO - 2024-09-03 12:49:05 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:05 --> Input Class Initialized
INFO - 2024-09-03 12:49:05 --> Language Class Initialized
INFO - 2024-09-03 12:49:05 --> Language Class Initialized
INFO - 2024-09-03 12:49:05 --> Config Class Initialized
INFO - 2024-09-03 12:49:05 --> Loader Class Initialized
INFO - 2024-09-03 12:49:05 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:05 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:05 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:05 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:05 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:05 --> Controller Class Initialized
INFO - 2024-09-03 12:49:05 --> Helper loaded: cookie_helper
INFO - 2024-09-03 12:49:05 --> Config Class Initialized
INFO - 2024-09-03 12:49:05 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:05 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:05 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:05 --> URI Class Initialized
INFO - 2024-09-03 12:49:05 --> Router Class Initialized
INFO - 2024-09-03 12:49:05 --> Output Class Initialized
INFO - 2024-09-03 12:49:05 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:05 --> Input Class Initialized
INFO - 2024-09-03 12:49:05 --> Language Class Initialized
INFO - 2024-09-03 12:49:05 --> Language Class Initialized
INFO - 2024-09-03 12:49:05 --> Config Class Initialized
INFO - 2024-09-03 12:49:05 --> Loader Class Initialized
INFO - 2024-09-03 12:49:05 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:05 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:05 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:05 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:05 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:05 --> Controller Class Initialized
DEBUG - 2024-09-03 12:49:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-03 12:49:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-03 12:49:05 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:05 --> Total execution time: 0.0572
INFO - 2024-09-03 12:49:09 --> Config Class Initialized
INFO - 2024-09-03 12:49:09 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:09 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:09 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:09 --> URI Class Initialized
INFO - 2024-09-03 12:49:09 --> Router Class Initialized
INFO - 2024-09-03 12:49:09 --> Output Class Initialized
INFO - 2024-09-03 12:49:09 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:09 --> Input Class Initialized
INFO - 2024-09-03 12:49:09 --> Language Class Initialized
INFO - 2024-09-03 12:49:09 --> Language Class Initialized
INFO - 2024-09-03 12:49:09 --> Config Class Initialized
INFO - 2024-09-03 12:49:09 --> Loader Class Initialized
INFO - 2024-09-03 12:49:09 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:09 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:09 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:09 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:09 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:09 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:12 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:12 --> Total execution time: 3.0921
INFO - 2024-09-03 12:49:12 --> Config Class Initialized
INFO - 2024-09-03 12:49:12 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:12 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:12 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:12 --> URI Class Initialized
INFO - 2024-09-03 12:49:12 --> Router Class Initialized
INFO - 2024-09-03 12:49:12 --> Output Class Initialized
INFO - 2024-09-03 12:49:12 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:12 --> Input Class Initialized
INFO - 2024-09-03 12:49:12 --> Language Class Initialized
INFO - 2024-09-03 12:49:12 --> Language Class Initialized
INFO - 2024-09-03 12:49:12 --> Config Class Initialized
INFO - 2024-09-03 12:49:12 --> Loader Class Initialized
INFO - 2024-09-03 12:49:12 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:12 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:12 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:12 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:12 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:12 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:15 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:15 --> Total execution time: 2.8862
INFO - 2024-09-03 12:49:15 --> Config Class Initialized
INFO - 2024-09-03 12:49:15 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:15 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:15 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:15 --> URI Class Initialized
INFO - 2024-09-03 12:49:15 --> Router Class Initialized
INFO - 2024-09-03 12:49:15 --> Output Class Initialized
INFO - 2024-09-03 12:49:15 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:15 --> Input Class Initialized
INFO - 2024-09-03 12:49:15 --> Language Class Initialized
INFO - 2024-09-03 12:49:15 --> Language Class Initialized
INFO - 2024-09-03 12:49:15 --> Config Class Initialized
INFO - 2024-09-03 12:49:15 --> Loader Class Initialized
INFO - 2024-09-03 12:49:15 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:15 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:15 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:15 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:15 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:15 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:15 --> Config Class Initialized
INFO - 2024-09-03 12:49:15 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:15 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:15 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:15 --> URI Class Initialized
INFO - 2024-09-03 12:49:15 --> Router Class Initialized
INFO - 2024-09-03 12:49:15 --> Output Class Initialized
INFO - 2024-09-03 12:49:15 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:15 --> Input Class Initialized
INFO - 2024-09-03 12:49:15 --> Language Class Initialized
INFO - 2024-09-03 12:49:15 --> Language Class Initialized
INFO - 2024-09-03 12:49:15 --> Config Class Initialized
INFO - 2024-09-03 12:49:15 --> Loader Class Initialized
INFO - 2024-09-03 12:49:15 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:15 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:15 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:15 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:15 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:18 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:18 --> Total execution time: 2.8775
INFO - 2024-09-03 12:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:18 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:20 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:20 --> Total execution time: 5.4386
INFO - 2024-09-03 12:49:21 --> Config Class Initialized
INFO - 2024-09-03 12:49:21 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:21 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:21 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:21 --> URI Class Initialized
INFO - 2024-09-03 12:49:21 --> Router Class Initialized
INFO - 2024-09-03 12:49:21 --> Output Class Initialized
INFO - 2024-09-03 12:49:21 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:21 --> Input Class Initialized
INFO - 2024-09-03 12:49:21 --> Language Class Initialized
INFO - 2024-09-03 12:49:21 --> Language Class Initialized
INFO - 2024-09-03 12:49:21 --> Config Class Initialized
INFO - 2024-09-03 12:49:21 --> Loader Class Initialized
INFO - 2024-09-03 12:49:21 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:21 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:21 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:21 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:21 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:21 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:23 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:23 --> Total execution time: 2.6275
INFO - 2024-09-03 12:49:23 --> Config Class Initialized
INFO - 2024-09-03 12:49:23 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:23 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:23 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:23 --> URI Class Initialized
INFO - 2024-09-03 12:49:23 --> Router Class Initialized
INFO - 2024-09-03 12:49:23 --> Output Class Initialized
INFO - 2024-09-03 12:49:23 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:23 --> Input Class Initialized
INFO - 2024-09-03 12:49:23 --> Language Class Initialized
INFO - 2024-09-03 12:49:23 --> Language Class Initialized
INFO - 2024-09-03 12:49:23 --> Config Class Initialized
INFO - 2024-09-03 12:49:23 --> Loader Class Initialized
INFO - 2024-09-03 12:49:23 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:23 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:23 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:23 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:23 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:23 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:26 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:26 --> Total execution time: 2.9146
INFO - 2024-09-03 12:49:26 --> Config Class Initialized
INFO - 2024-09-03 12:49:26 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:26 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:26 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:26 --> URI Class Initialized
INFO - 2024-09-03 12:49:26 --> Router Class Initialized
INFO - 2024-09-03 12:49:26 --> Output Class Initialized
INFO - 2024-09-03 12:49:26 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:26 --> Input Class Initialized
INFO - 2024-09-03 12:49:26 --> Language Class Initialized
INFO - 2024-09-03 12:49:26 --> Language Class Initialized
INFO - 2024-09-03 12:49:26 --> Config Class Initialized
INFO - 2024-09-03 12:49:26 --> Loader Class Initialized
INFO - 2024-09-03 12:49:26 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:26 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:26 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:26 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:26 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:26 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:29 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:29 --> Total execution time: 3.1233
INFO - 2024-09-03 12:49:30 --> Config Class Initialized
INFO - 2024-09-03 12:49:30 --> Hooks Class Initialized
DEBUG - 2024-09-03 12:49:30 --> UTF-8 Support Enabled
INFO - 2024-09-03 12:49:30 --> Utf8 Class Initialized
INFO - 2024-09-03 12:49:30 --> URI Class Initialized
INFO - 2024-09-03 12:49:30 --> Router Class Initialized
INFO - 2024-09-03 12:49:30 --> Output Class Initialized
INFO - 2024-09-03 12:49:30 --> Security Class Initialized
DEBUG - 2024-09-03 12:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 12:49:30 --> Input Class Initialized
INFO - 2024-09-03 12:49:30 --> Language Class Initialized
INFO - 2024-09-03 12:49:30 --> Language Class Initialized
INFO - 2024-09-03 12:49:30 --> Config Class Initialized
INFO - 2024-09-03 12:49:30 --> Loader Class Initialized
INFO - 2024-09-03 12:49:30 --> Helper loaded: url_helper
INFO - 2024-09-03 12:49:30 --> Helper loaded: file_helper
INFO - 2024-09-03 12:49:30 --> Helper loaded: form_helper
INFO - 2024-09-03 12:49:30 --> Helper loaded: my_helper
INFO - 2024-09-03 12:49:30 --> Database Driver Class Initialized
INFO - 2024-09-03 12:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 12:49:30 --> Controller Class Initialized
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 12:49:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 12:49:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 12:49:33 --> Final output sent to browser
DEBUG - 2024-09-03 12:49:33 --> Total execution time: 2.9314
INFO - 2024-09-03 22:04:01 --> Config Class Initialized
INFO - 2024-09-03 22:04:01 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:01 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:01 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:01 --> URI Class Initialized
INFO - 2024-09-03 22:04:01 --> Router Class Initialized
INFO - 2024-09-03 22:04:01 --> Output Class Initialized
INFO - 2024-09-03 22:04:01 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:01 --> Input Class Initialized
INFO - 2024-09-03 22:04:01 --> Language Class Initialized
INFO - 2024-09-03 22:04:01 --> Language Class Initialized
INFO - 2024-09-03 22:04:01 --> Config Class Initialized
INFO - 2024-09-03 22:04:01 --> Loader Class Initialized
INFO - 2024-09-03 22:04:01 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:01 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:01 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:01 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:01 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:01 --> Controller Class Initialized
INFO - 2024-09-03 22:04:01 --> Helper loaded: cookie_helper
INFO - 2024-09-03 22:04:01 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:01 --> Total execution time: 0.5370
INFO - 2024-09-03 22:04:02 --> Config Class Initialized
INFO - 2024-09-03 22:04:02 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:02 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:02 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:02 --> URI Class Initialized
INFO - 2024-09-03 22:04:02 --> Router Class Initialized
INFO - 2024-09-03 22:04:02 --> Output Class Initialized
INFO - 2024-09-03 22:04:02 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:02 --> Input Class Initialized
INFO - 2024-09-03 22:04:02 --> Language Class Initialized
INFO - 2024-09-03 22:04:02 --> Language Class Initialized
INFO - 2024-09-03 22:04:02 --> Config Class Initialized
INFO - 2024-09-03 22:04:02 --> Loader Class Initialized
INFO - 2024-09-03 22:04:02 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:02 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:02 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:02 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:02 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:02 --> Controller Class Initialized
INFO - 2024-09-03 22:04:02 --> Helper loaded: cookie_helper
INFO - 2024-09-03 22:04:02 --> Config Class Initialized
INFO - 2024-09-03 22:04:02 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:02 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:02 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:02 --> URI Class Initialized
INFO - 2024-09-03 22:04:02 --> Router Class Initialized
INFO - 2024-09-03 22:04:02 --> Output Class Initialized
INFO - 2024-09-03 22:04:02 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:02 --> Input Class Initialized
INFO - 2024-09-03 22:04:02 --> Language Class Initialized
INFO - 2024-09-03 22:04:02 --> Language Class Initialized
INFO - 2024-09-03 22:04:02 --> Config Class Initialized
INFO - 2024-09-03 22:04:02 --> Loader Class Initialized
INFO - 2024-09-03 22:04:02 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:02 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:02 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:02 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:02 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:02 --> Controller Class Initialized
DEBUG - 2024-09-03 22:04:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-03 22:04:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-03 22:04:02 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:02 --> Total execution time: 0.0642
INFO - 2024-09-03 22:04:10 --> Config Class Initialized
INFO - 2024-09-03 22:04:10 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:10 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:10 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:10 --> URI Class Initialized
INFO - 2024-09-03 22:04:10 --> Router Class Initialized
INFO - 2024-09-03 22:04:10 --> Output Class Initialized
INFO - 2024-09-03 22:04:10 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:10 --> Input Class Initialized
INFO - 2024-09-03 22:04:10 --> Language Class Initialized
INFO - 2024-09-03 22:04:10 --> Language Class Initialized
INFO - 2024-09-03 22:04:10 --> Config Class Initialized
INFO - 2024-09-03 22:04:10 --> Loader Class Initialized
INFO - 2024-09-03 22:04:10 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:10 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:10 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:10 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:10 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:10 --> Controller Class Initialized
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 22:04:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 22:04:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 22:04:16 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:16 --> Total execution time: 6.2872
INFO - 2024-09-03 22:04:17 --> Config Class Initialized
INFO - 2024-09-03 22:04:17 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:17 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:17 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:17 --> URI Class Initialized
INFO - 2024-09-03 22:04:17 --> Router Class Initialized
INFO - 2024-09-03 22:04:17 --> Output Class Initialized
INFO - 2024-09-03 22:04:17 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:17 --> Input Class Initialized
INFO - 2024-09-03 22:04:17 --> Language Class Initialized
INFO - 2024-09-03 22:04:17 --> Language Class Initialized
INFO - 2024-09-03 22:04:17 --> Config Class Initialized
INFO - 2024-09-03 22:04:17 --> Loader Class Initialized
INFO - 2024-09-03 22:04:17 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:17 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:17 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:17 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:17 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:17 --> Controller Class Initialized
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 22:04:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 22:04:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 22:04:20 --> Config Class Initialized
INFO - 2024-09-03 22:04:20 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:20 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:20 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:20 --> URI Class Initialized
INFO - 2024-09-03 22:04:20 --> Router Class Initialized
INFO - 2024-09-03 22:04:20 --> Output Class Initialized
INFO - 2024-09-03 22:04:20 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:20 --> Input Class Initialized
INFO - 2024-09-03 22:04:20 --> Language Class Initialized
INFO - 2024-09-03 22:04:20 --> Language Class Initialized
INFO - 2024-09-03 22:04:20 --> Config Class Initialized
INFO - 2024-09-03 22:04:20 --> Loader Class Initialized
INFO - 2024-09-03 22:04:20 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:20 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:20 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:20 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:20 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:22 --> Config Class Initialized
INFO - 2024-09-03 22:04:22 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:22 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:22 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:22 --> URI Class Initialized
INFO - 2024-09-03 22:04:22 --> Router Class Initialized
INFO - 2024-09-03 22:04:22 --> Output Class Initialized
INFO - 2024-09-03 22:04:22 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:22 --> Input Class Initialized
INFO - 2024-09-03 22:04:22 --> Language Class Initialized
INFO - 2024-09-03 22:04:22 --> Language Class Initialized
INFO - 2024-09-03 22:04:22 --> Config Class Initialized
INFO - 2024-09-03 22:04:22 --> Loader Class Initialized
INFO - 2024-09-03 22:04:22 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:22 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:22 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:22 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:22 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:22 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:22 --> Total execution time: 5.8147
INFO - 2024-09-03 22:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:22 --> Controller Class Initialized
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 22:04:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 22:04:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 22:04:24 --> Config Class Initialized
INFO - 2024-09-03 22:04:24 --> Hooks Class Initialized
DEBUG - 2024-09-03 22:04:24 --> UTF-8 Support Enabled
INFO - 2024-09-03 22:04:24 --> Utf8 Class Initialized
INFO - 2024-09-03 22:04:24 --> URI Class Initialized
INFO - 2024-09-03 22:04:24 --> Router Class Initialized
INFO - 2024-09-03 22:04:24 --> Output Class Initialized
INFO - 2024-09-03 22:04:24 --> Security Class Initialized
DEBUG - 2024-09-03 22:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-03 22:04:24 --> Input Class Initialized
INFO - 2024-09-03 22:04:24 --> Language Class Initialized
INFO - 2024-09-03 22:04:24 --> Language Class Initialized
INFO - 2024-09-03 22:04:24 --> Config Class Initialized
INFO - 2024-09-03 22:04:24 --> Loader Class Initialized
INFO - 2024-09-03 22:04:24 --> Helper loaded: url_helper
INFO - 2024-09-03 22:04:24 --> Helper loaded: file_helper
INFO - 2024-09-03 22:04:24 --> Helper loaded: form_helper
INFO - 2024-09-03 22:04:24 --> Helper loaded: my_helper
INFO - 2024-09-03 22:04:24 --> Database Driver Class Initialized
INFO - 2024-09-03 22:04:29 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:29 --> Total execution time: 8.3372
INFO - 2024-09-03 22:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:29 --> Controller Class Initialized
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 22:04:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 22:04:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 22:04:34 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:34 --> Total execution time: 12.5909
INFO - 2024-09-03 22:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-03 22:04:34 --> Controller Class Initialized
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 97
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 747
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 826
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 905
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-03 22:04:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-03 22:04:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-03 22:04:40 --> Final output sent to browser
DEBUG - 2024-09-03 22:04:40 --> Total execution time: 16.1654
