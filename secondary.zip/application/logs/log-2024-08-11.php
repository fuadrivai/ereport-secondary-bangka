<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-11 15:04:38 --> Config Class Initialized
INFO - 2024-08-11 15:04:38 --> Hooks Class Initialized
DEBUG - 2024-08-11 15:04:38 --> UTF-8 Support Enabled
INFO - 2024-08-11 15:04:38 --> Utf8 Class Initialized
INFO - 2024-08-11 15:04:38 --> URI Class Initialized
INFO - 2024-08-11 15:04:38 --> Router Class Initialized
INFO - 2024-08-11 15:04:38 --> Output Class Initialized
INFO - 2024-08-11 15:04:38 --> Security Class Initialized
DEBUG - 2024-08-11 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-11 15:04:38 --> Input Class Initialized
INFO - 2024-08-11 15:04:38 --> Language Class Initialized
INFO - 2024-08-11 15:04:38 --> Language Class Initialized
INFO - 2024-08-11 15:04:38 --> Config Class Initialized
INFO - 2024-08-11 15:04:38 --> Loader Class Initialized
INFO - 2024-08-11 15:04:38 --> Helper loaded: url_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: file_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: form_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: my_helper
INFO - 2024-08-11 15:04:38 --> Database Driver Class Initialized
INFO - 2024-08-11 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-11 15:04:38 --> Controller Class Initialized
INFO - 2024-08-11 15:04:38 --> Helper loaded: cookie_helper
INFO - 2024-08-11 15:04:38 --> Final output sent to browser
DEBUG - 2024-08-11 15:04:38 --> Total execution time: 0.0659
INFO - 2024-08-11 15:04:38 --> Config Class Initialized
INFO - 2024-08-11 15:04:38 --> Hooks Class Initialized
DEBUG - 2024-08-11 15:04:38 --> UTF-8 Support Enabled
INFO - 2024-08-11 15:04:38 --> Utf8 Class Initialized
INFO - 2024-08-11 15:04:38 --> URI Class Initialized
INFO - 2024-08-11 15:04:38 --> Router Class Initialized
INFO - 2024-08-11 15:04:38 --> Output Class Initialized
INFO - 2024-08-11 15:04:38 --> Security Class Initialized
DEBUG - 2024-08-11 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-11 15:04:38 --> Input Class Initialized
INFO - 2024-08-11 15:04:38 --> Language Class Initialized
INFO - 2024-08-11 15:04:38 --> Language Class Initialized
INFO - 2024-08-11 15:04:38 --> Config Class Initialized
INFO - 2024-08-11 15:04:38 --> Loader Class Initialized
INFO - 2024-08-11 15:04:38 --> Helper loaded: url_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: file_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: form_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: my_helper
INFO - 2024-08-11 15:04:38 --> Database Driver Class Initialized
INFO - 2024-08-11 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-11 15:04:38 --> Controller Class Initialized
INFO - 2024-08-11 15:04:38 --> Helper loaded: cookie_helper
INFO - 2024-08-11 15:04:38 --> Config Class Initialized
INFO - 2024-08-11 15:04:38 --> Hooks Class Initialized
DEBUG - 2024-08-11 15:04:38 --> UTF-8 Support Enabled
INFO - 2024-08-11 15:04:38 --> Utf8 Class Initialized
INFO - 2024-08-11 15:04:38 --> URI Class Initialized
INFO - 2024-08-11 15:04:38 --> Router Class Initialized
INFO - 2024-08-11 15:04:38 --> Output Class Initialized
INFO - 2024-08-11 15:04:38 --> Security Class Initialized
DEBUG - 2024-08-11 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-11 15:04:38 --> Input Class Initialized
INFO - 2024-08-11 15:04:38 --> Language Class Initialized
INFO - 2024-08-11 15:04:38 --> Language Class Initialized
INFO - 2024-08-11 15:04:38 --> Config Class Initialized
INFO - 2024-08-11 15:04:38 --> Loader Class Initialized
INFO - 2024-08-11 15:04:38 --> Helper loaded: url_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: file_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: form_helper
INFO - 2024-08-11 15:04:38 --> Helper loaded: my_helper
INFO - 2024-08-11 15:04:38 --> Database Driver Class Initialized
INFO - 2024-08-11 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-11 15:04:38 --> Controller Class Initialized
DEBUG - 2024-08-11 15:04:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-11 15:04:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-11 15:04:38 --> Final output sent to browser
DEBUG - 2024-08-11 15:04:38 --> Total execution time: 0.0457
