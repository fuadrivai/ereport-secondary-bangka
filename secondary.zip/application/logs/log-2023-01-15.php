<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-15 07:39:34 --> Config Class Initialized
INFO - 2023-01-15 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:39:34 --> Utf8 Class Initialized
INFO - 2023-01-15 07:39:34 --> URI Class Initialized
INFO - 2023-01-15 07:39:34 --> Router Class Initialized
INFO - 2023-01-15 07:39:34 --> Output Class Initialized
INFO - 2023-01-15 07:39:34 --> Security Class Initialized
DEBUG - 2023-01-15 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:39:34 --> Input Class Initialized
INFO - 2023-01-15 07:39:34 --> Language Class Initialized
INFO - 2023-01-15 07:39:35 --> Language Class Initialized
INFO - 2023-01-15 07:39:35 --> Config Class Initialized
INFO - 2023-01-15 07:39:35 --> Loader Class Initialized
INFO - 2023-01-15 07:39:35 --> Helper loaded: url_helper
INFO - 2023-01-15 07:39:35 --> Helper loaded: file_helper
INFO - 2023-01-15 07:39:35 --> Helper loaded: form_helper
INFO - 2023-01-15 07:39:35 --> Helper loaded: my_helper
INFO - 2023-01-15 07:39:35 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:39:35 --> Controller Class Initialized
ERROR - 2023-01-15 07:39:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan\controllers\N_catatan.php 19
ERROR - 2023-01-15 07:39:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan\controllers\N_catatan.php 20
DEBUG - 2023-01-15 07:39:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-15 07:39:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 07:39:35 --> Final output sent to browser
DEBUG - 2023-01-15 07:39:35 --> Total execution time: 0.6442
INFO - 2023-01-15 07:39:41 --> Config Class Initialized
INFO - 2023-01-15 07:39:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:39:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:39:41 --> Utf8 Class Initialized
INFO - 2023-01-15 07:39:41 --> URI Class Initialized
DEBUG - 2023-01-15 07:39:41 --> No URI present. Default controller set.
INFO - 2023-01-15 07:39:41 --> Router Class Initialized
INFO - 2023-01-15 07:39:41 --> Output Class Initialized
INFO - 2023-01-15 07:39:41 --> Security Class Initialized
DEBUG - 2023-01-15 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:39:41 --> Input Class Initialized
INFO - 2023-01-15 07:39:41 --> Language Class Initialized
INFO - 2023-01-15 07:39:41 --> Language Class Initialized
INFO - 2023-01-15 07:39:41 --> Config Class Initialized
INFO - 2023-01-15 07:39:41 --> Loader Class Initialized
INFO - 2023-01-15 07:39:41 --> Helper loaded: url_helper
INFO - 2023-01-15 07:39:41 --> Helper loaded: file_helper
INFO - 2023-01-15 07:39:41 --> Helper loaded: form_helper
INFO - 2023-01-15 07:39:41 --> Helper loaded: my_helper
INFO - 2023-01-15 07:39:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:39:41 --> Controller Class Initialized
INFO - 2023-01-15 07:39:41 --> Config Class Initialized
INFO - 2023-01-15 07:39:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:39:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:39:41 --> Utf8 Class Initialized
INFO - 2023-01-15 07:39:41 --> URI Class Initialized
INFO - 2023-01-15 07:39:41 --> Router Class Initialized
INFO - 2023-01-15 07:39:41 --> Output Class Initialized
INFO - 2023-01-15 07:39:41 --> Security Class Initialized
DEBUG - 2023-01-15 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:39:41 --> Input Class Initialized
INFO - 2023-01-15 07:39:41 --> Language Class Initialized
INFO - 2023-01-15 07:39:41 --> Language Class Initialized
INFO - 2023-01-15 07:39:41 --> Config Class Initialized
INFO - 2023-01-15 07:39:41 --> Loader Class Initialized
INFO - 2023-01-15 07:39:41 --> Helper loaded: url_helper
INFO - 2023-01-15 07:39:41 --> Helper loaded: file_helper
INFO - 2023-01-15 07:39:41 --> Helper loaded: form_helper
INFO - 2023-01-15 07:39:41 --> Helper loaded: my_helper
INFO - 2023-01-15 07:39:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:39:41 --> Controller Class Initialized
DEBUG - 2023-01-15 07:39:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-15 07:39:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 07:39:41 --> Final output sent to browser
DEBUG - 2023-01-15 07:39:41 --> Total execution time: 0.0674
INFO - 2023-01-15 07:39:46 --> Config Class Initialized
INFO - 2023-01-15 07:39:46 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:39:46 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:39:46 --> Utf8 Class Initialized
INFO - 2023-01-15 07:39:46 --> URI Class Initialized
INFO - 2023-01-15 07:39:46 --> Router Class Initialized
INFO - 2023-01-15 07:39:46 --> Output Class Initialized
INFO - 2023-01-15 07:39:46 --> Security Class Initialized
DEBUG - 2023-01-15 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:39:46 --> Input Class Initialized
INFO - 2023-01-15 07:39:46 --> Language Class Initialized
INFO - 2023-01-15 07:39:46 --> Language Class Initialized
INFO - 2023-01-15 07:39:46 --> Config Class Initialized
INFO - 2023-01-15 07:39:46 --> Loader Class Initialized
INFO - 2023-01-15 07:39:46 --> Helper loaded: url_helper
INFO - 2023-01-15 07:39:46 --> Helper loaded: file_helper
INFO - 2023-01-15 07:39:46 --> Helper loaded: form_helper
INFO - 2023-01-15 07:39:46 --> Helper loaded: my_helper
INFO - 2023-01-15 07:39:46 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:39:46 --> Controller Class Initialized
INFO - 2023-01-15 07:39:46 --> Helper loaded: cookie_helper
INFO - 2023-01-15 07:39:46 --> Final output sent to browser
DEBUG - 2023-01-15 07:39:46 --> Total execution time: 0.0480
INFO - 2023-01-15 07:39:46 --> Config Class Initialized
INFO - 2023-01-15 07:39:46 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:39:46 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:39:46 --> Utf8 Class Initialized
INFO - 2023-01-15 07:39:46 --> URI Class Initialized
INFO - 2023-01-15 07:39:46 --> Router Class Initialized
INFO - 2023-01-15 07:39:46 --> Output Class Initialized
INFO - 2023-01-15 07:39:46 --> Security Class Initialized
DEBUG - 2023-01-15 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:39:46 --> Input Class Initialized
INFO - 2023-01-15 07:39:46 --> Language Class Initialized
INFO - 2023-01-15 07:39:46 --> Language Class Initialized
INFO - 2023-01-15 07:39:46 --> Config Class Initialized
INFO - 2023-01-15 07:39:46 --> Loader Class Initialized
INFO - 2023-01-15 07:39:46 --> Helper loaded: url_helper
INFO - 2023-01-15 07:39:46 --> Helper loaded: file_helper
INFO - 2023-01-15 07:39:46 --> Helper loaded: form_helper
INFO - 2023-01-15 07:39:46 --> Helper loaded: my_helper
INFO - 2023-01-15 07:39:46 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:39:46 --> Controller Class Initialized
DEBUG - 2023-01-15 07:39:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-15 07:39:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 07:39:46 --> Final output sent to browser
DEBUG - 2023-01-15 07:39:46 --> Total execution time: 0.0654
INFO - 2023-01-15 07:39:50 --> Config Class Initialized
INFO - 2023-01-15 07:39:50 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:39:50 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:39:50 --> Utf8 Class Initialized
INFO - 2023-01-15 07:39:50 --> URI Class Initialized
INFO - 2023-01-15 07:39:50 --> Router Class Initialized
INFO - 2023-01-15 07:39:50 --> Output Class Initialized
INFO - 2023-01-15 07:39:50 --> Security Class Initialized
DEBUG - 2023-01-15 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:39:50 --> Input Class Initialized
INFO - 2023-01-15 07:39:50 --> Language Class Initialized
INFO - 2023-01-15 07:39:50 --> Language Class Initialized
INFO - 2023-01-15 07:39:50 --> Config Class Initialized
INFO - 2023-01-15 07:39:50 --> Loader Class Initialized
INFO - 2023-01-15 07:39:50 --> Helper loaded: url_helper
INFO - 2023-01-15 07:39:50 --> Helper loaded: file_helper
INFO - 2023-01-15 07:39:50 --> Helper loaded: form_helper
INFO - 2023-01-15 07:39:50 --> Helper loaded: my_helper
INFO - 2023-01-15 07:39:50 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:39:50 --> Controller Class Initialized
DEBUG - 2023-01-15 07:39:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-15 07:39:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 07:39:50 --> Final output sent to browser
DEBUG - 2023-01-15 07:39:50 --> Total execution time: 0.0421
INFO - 2023-01-15 07:40:06 --> Config Class Initialized
INFO - 2023-01-15 07:40:06 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:40:06 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:40:06 --> Utf8 Class Initialized
INFO - 2023-01-15 07:40:06 --> URI Class Initialized
INFO - 2023-01-15 07:40:06 --> Router Class Initialized
INFO - 2023-01-15 07:40:06 --> Output Class Initialized
INFO - 2023-01-15 07:40:06 --> Security Class Initialized
DEBUG - 2023-01-15 07:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:40:06 --> Input Class Initialized
INFO - 2023-01-15 07:40:06 --> Language Class Initialized
INFO - 2023-01-15 07:40:06 --> Language Class Initialized
INFO - 2023-01-15 07:40:06 --> Config Class Initialized
INFO - 2023-01-15 07:40:06 --> Loader Class Initialized
INFO - 2023-01-15 07:40:06 --> Helper loaded: url_helper
INFO - 2023-01-15 07:40:06 --> Helper loaded: file_helper
INFO - 2023-01-15 07:40:06 --> Helper loaded: form_helper
INFO - 2023-01-15 07:40:06 --> Helper loaded: my_helper
INFO - 2023-01-15 07:40:06 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:40:06 --> Controller Class Initialized
DEBUG - 2023-01-15 07:40:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:40:08 --> Final output sent to browser
DEBUG - 2023-01-15 07:40:08 --> Total execution time: 2.0503
INFO - 2023-01-15 07:46:00 --> Config Class Initialized
INFO - 2023-01-15 07:46:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:46:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:46:00 --> Utf8 Class Initialized
INFO - 2023-01-15 07:46:00 --> URI Class Initialized
DEBUG - 2023-01-15 07:46:00 --> No URI present. Default controller set.
INFO - 2023-01-15 07:46:00 --> Router Class Initialized
INFO - 2023-01-15 07:46:00 --> Output Class Initialized
INFO - 2023-01-15 07:46:00 --> Security Class Initialized
DEBUG - 2023-01-15 07:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:46:00 --> Input Class Initialized
INFO - 2023-01-15 07:46:00 --> Language Class Initialized
INFO - 2023-01-15 07:46:00 --> Language Class Initialized
INFO - 2023-01-15 07:46:00 --> Config Class Initialized
INFO - 2023-01-15 07:46:00 --> Loader Class Initialized
INFO - 2023-01-15 07:46:00 --> Helper loaded: url_helper
INFO - 2023-01-15 07:46:00 --> Helper loaded: file_helper
INFO - 2023-01-15 07:46:00 --> Helper loaded: form_helper
INFO - 2023-01-15 07:46:00 --> Helper loaded: my_helper
INFO - 2023-01-15 07:46:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:46:00 --> Controller Class Initialized
DEBUG - 2023-01-15 07:46:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-15 07:46:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 07:46:00 --> Final output sent to browser
DEBUG - 2023-01-15 07:46:00 --> Total execution time: 0.6937
INFO - 2023-01-15 07:46:05 --> Config Class Initialized
INFO - 2023-01-15 07:46:05 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:46:05 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:46:05 --> Utf8 Class Initialized
INFO - 2023-01-15 07:46:05 --> URI Class Initialized
INFO - 2023-01-15 07:46:05 --> Router Class Initialized
INFO - 2023-01-15 07:46:05 --> Output Class Initialized
INFO - 2023-01-15 07:46:05 --> Security Class Initialized
DEBUG - 2023-01-15 07:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:46:05 --> Input Class Initialized
INFO - 2023-01-15 07:46:05 --> Language Class Initialized
INFO - 2023-01-15 07:46:05 --> Language Class Initialized
INFO - 2023-01-15 07:46:05 --> Config Class Initialized
INFO - 2023-01-15 07:46:05 --> Loader Class Initialized
INFO - 2023-01-15 07:46:05 --> Helper loaded: url_helper
INFO - 2023-01-15 07:46:05 --> Helper loaded: file_helper
INFO - 2023-01-15 07:46:05 --> Helper loaded: form_helper
INFO - 2023-01-15 07:46:05 --> Helper loaded: my_helper
INFO - 2023-01-15 07:46:05 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:46:05 --> Controller Class Initialized
DEBUG - 2023-01-15 07:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-15 07:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 07:46:05 --> Final output sent to browser
DEBUG - 2023-01-15 07:46:05 --> Total execution time: 0.0553
INFO - 2023-01-15 07:46:07 --> Config Class Initialized
INFO - 2023-01-15 07:46:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:46:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:46:07 --> Utf8 Class Initialized
INFO - 2023-01-15 07:46:07 --> URI Class Initialized
INFO - 2023-01-15 07:46:07 --> Router Class Initialized
INFO - 2023-01-15 07:46:07 --> Output Class Initialized
INFO - 2023-01-15 07:46:07 --> Security Class Initialized
DEBUG - 2023-01-15 07:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:46:07 --> Input Class Initialized
INFO - 2023-01-15 07:46:07 --> Language Class Initialized
INFO - 2023-01-15 07:46:07 --> Language Class Initialized
INFO - 2023-01-15 07:46:07 --> Config Class Initialized
INFO - 2023-01-15 07:46:07 --> Loader Class Initialized
INFO - 2023-01-15 07:46:07 --> Helper loaded: url_helper
INFO - 2023-01-15 07:46:07 --> Helper loaded: file_helper
INFO - 2023-01-15 07:46:07 --> Helper loaded: form_helper
INFO - 2023-01-15 07:46:07 --> Helper loaded: my_helper
INFO - 2023-01-15 07:46:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:46:07 --> Controller Class Initialized
DEBUG - 2023-01-15 07:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:46:09 --> Final output sent to browser
DEBUG - 2023-01-15 07:46:09 --> Total execution time: 1.9506
INFO - 2023-01-15 07:50:25 --> Config Class Initialized
INFO - 2023-01-15 07:50:25 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:50:25 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:50:25 --> Utf8 Class Initialized
INFO - 2023-01-15 07:50:25 --> URI Class Initialized
INFO - 2023-01-15 07:50:25 --> Router Class Initialized
INFO - 2023-01-15 07:50:25 --> Output Class Initialized
INFO - 2023-01-15 07:50:25 --> Security Class Initialized
DEBUG - 2023-01-15 07:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:50:25 --> Input Class Initialized
INFO - 2023-01-15 07:50:25 --> Language Class Initialized
INFO - 2023-01-15 07:50:25 --> Language Class Initialized
INFO - 2023-01-15 07:50:25 --> Config Class Initialized
INFO - 2023-01-15 07:50:25 --> Loader Class Initialized
INFO - 2023-01-15 07:50:25 --> Helper loaded: url_helper
INFO - 2023-01-15 07:50:25 --> Helper loaded: file_helper
INFO - 2023-01-15 07:50:25 --> Helper loaded: form_helper
INFO - 2023-01-15 07:50:25 --> Helper loaded: my_helper
INFO - 2023-01-15 07:50:25 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:50:25 --> Controller Class Initialized
DEBUG - 2023-01-15 07:50:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:50:26 --> Final output sent to browser
DEBUG - 2023-01-15 07:50:26 --> Total execution time: 1.1950
INFO - 2023-01-15 07:50:48 --> Config Class Initialized
INFO - 2023-01-15 07:50:48 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:50:48 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:50:48 --> Utf8 Class Initialized
INFO - 2023-01-15 07:50:48 --> URI Class Initialized
INFO - 2023-01-15 07:50:48 --> Router Class Initialized
INFO - 2023-01-15 07:50:48 --> Output Class Initialized
INFO - 2023-01-15 07:50:48 --> Security Class Initialized
DEBUG - 2023-01-15 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:50:48 --> Input Class Initialized
INFO - 2023-01-15 07:50:48 --> Language Class Initialized
INFO - 2023-01-15 07:50:48 --> Language Class Initialized
INFO - 2023-01-15 07:50:48 --> Config Class Initialized
INFO - 2023-01-15 07:50:48 --> Loader Class Initialized
INFO - 2023-01-15 07:50:48 --> Helper loaded: url_helper
INFO - 2023-01-15 07:50:48 --> Helper loaded: file_helper
INFO - 2023-01-15 07:50:48 --> Helper loaded: form_helper
INFO - 2023-01-15 07:50:48 --> Helper loaded: my_helper
INFO - 2023-01-15 07:50:48 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:50:48 --> Controller Class Initialized
DEBUG - 2023-01-15 07:50:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:50:50 --> Final output sent to browser
DEBUG - 2023-01-15 07:50:50 --> Total execution time: 1.2423
INFO - 2023-01-15 07:51:07 --> Config Class Initialized
INFO - 2023-01-15 07:51:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:51:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:51:07 --> Utf8 Class Initialized
INFO - 2023-01-15 07:51:07 --> URI Class Initialized
INFO - 2023-01-15 07:51:07 --> Router Class Initialized
INFO - 2023-01-15 07:51:07 --> Output Class Initialized
INFO - 2023-01-15 07:51:07 --> Security Class Initialized
DEBUG - 2023-01-15 07:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:51:07 --> Input Class Initialized
INFO - 2023-01-15 07:51:07 --> Language Class Initialized
INFO - 2023-01-15 07:51:07 --> Language Class Initialized
INFO - 2023-01-15 07:51:07 --> Config Class Initialized
INFO - 2023-01-15 07:51:07 --> Loader Class Initialized
INFO - 2023-01-15 07:51:07 --> Helper loaded: url_helper
INFO - 2023-01-15 07:51:07 --> Helper loaded: file_helper
INFO - 2023-01-15 07:51:07 --> Helper loaded: form_helper
INFO - 2023-01-15 07:51:07 --> Helper loaded: my_helper
INFO - 2023-01-15 07:51:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:51:07 --> Controller Class Initialized
DEBUG - 2023-01-15 07:51:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:51:08 --> Final output sent to browser
DEBUG - 2023-01-15 07:51:08 --> Total execution time: 1.1251
INFO - 2023-01-15 07:52:08 --> Config Class Initialized
INFO - 2023-01-15 07:52:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:52:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:52:08 --> Utf8 Class Initialized
INFO - 2023-01-15 07:52:08 --> URI Class Initialized
INFO - 2023-01-15 07:52:08 --> Router Class Initialized
INFO - 2023-01-15 07:52:08 --> Output Class Initialized
INFO - 2023-01-15 07:52:08 --> Security Class Initialized
DEBUG - 2023-01-15 07:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:52:08 --> Input Class Initialized
INFO - 2023-01-15 07:52:08 --> Language Class Initialized
INFO - 2023-01-15 07:52:08 --> Language Class Initialized
INFO - 2023-01-15 07:52:08 --> Config Class Initialized
INFO - 2023-01-15 07:52:08 --> Loader Class Initialized
INFO - 2023-01-15 07:52:08 --> Helper loaded: url_helper
INFO - 2023-01-15 07:52:08 --> Helper loaded: file_helper
INFO - 2023-01-15 07:52:08 --> Helper loaded: form_helper
INFO - 2023-01-15 07:52:08 --> Helper loaded: my_helper
INFO - 2023-01-15 07:52:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:52:08 --> Controller Class Initialized
DEBUG - 2023-01-15 07:52:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:52:09 --> Final output sent to browser
DEBUG - 2023-01-15 07:52:09 --> Total execution time: 1.1211
INFO - 2023-01-15 07:52:42 --> Config Class Initialized
INFO - 2023-01-15 07:52:42 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:52:42 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:52:42 --> Utf8 Class Initialized
INFO - 2023-01-15 07:52:42 --> URI Class Initialized
INFO - 2023-01-15 07:52:42 --> Router Class Initialized
INFO - 2023-01-15 07:52:42 --> Output Class Initialized
INFO - 2023-01-15 07:52:42 --> Security Class Initialized
DEBUG - 2023-01-15 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:52:42 --> Input Class Initialized
INFO - 2023-01-15 07:52:42 --> Language Class Initialized
INFO - 2023-01-15 07:52:42 --> Language Class Initialized
INFO - 2023-01-15 07:52:42 --> Config Class Initialized
INFO - 2023-01-15 07:52:42 --> Loader Class Initialized
INFO - 2023-01-15 07:52:42 --> Helper loaded: url_helper
INFO - 2023-01-15 07:52:42 --> Helper loaded: file_helper
INFO - 2023-01-15 07:52:42 --> Helper loaded: form_helper
INFO - 2023-01-15 07:52:42 --> Helper loaded: my_helper
INFO - 2023-01-15 07:52:42 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:52:42 --> Controller Class Initialized
DEBUG - 2023-01-15 07:52:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:52:43 --> Final output sent to browser
DEBUG - 2023-01-15 07:52:43 --> Total execution time: 1.1526
INFO - 2023-01-15 07:52:56 --> Config Class Initialized
INFO - 2023-01-15 07:52:56 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:52:56 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:52:56 --> Utf8 Class Initialized
INFO - 2023-01-15 07:52:56 --> URI Class Initialized
INFO - 2023-01-15 07:52:56 --> Router Class Initialized
INFO - 2023-01-15 07:52:56 --> Output Class Initialized
INFO - 2023-01-15 07:52:56 --> Security Class Initialized
DEBUG - 2023-01-15 07:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:52:56 --> Input Class Initialized
INFO - 2023-01-15 07:52:56 --> Language Class Initialized
INFO - 2023-01-15 07:52:56 --> Language Class Initialized
INFO - 2023-01-15 07:52:56 --> Config Class Initialized
INFO - 2023-01-15 07:52:56 --> Loader Class Initialized
INFO - 2023-01-15 07:52:56 --> Helper loaded: url_helper
INFO - 2023-01-15 07:52:56 --> Helper loaded: file_helper
INFO - 2023-01-15 07:52:56 --> Helper loaded: form_helper
INFO - 2023-01-15 07:52:56 --> Helper loaded: my_helper
INFO - 2023-01-15 07:52:56 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:52:56 --> Controller Class Initialized
DEBUG - 2023-01-15 07:52:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:52:57 --> Final output sent to browser
DEBUG - 2023-01-15 07:52:57 --> Total execution time: 1.1659
INFO - 2023-01-15 07:53:07 --> Config Class Initialized
INFO - 2023-01-15 07:53:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:53:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:53:07 --> Utf8 Class Initialized
INFO - 2023-01-15 07:53:07 --> URI Class Initialized
INFO - 2023-01-15 07:53:07 --> Router Class Initialized
INFO - 2023-01-15 07:53:07 --> Output Class Initialized
INFO - 2023-01-15 07:53:07 --> Security Class Initialized
DEBUG - 2023-01-15 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:53:07 --> Input Class Initialized
INFO - 2023-01-15 07:53:07 --> Language Class Initialized
INFO - 2023-01-15 07:53:07 --> Language Class Initialized
INFO - 2023-01-15 07:53:07 --> Config Class Initialized
INFO - 2023-01-15 07:53:07 --> Loader Class Initialized
INFO - 2023-01-15 07:53:07 --> Helper loaded: url_helper
INFO - 2023-01-15 07:53:07 --> Helper loaded: file_helper
INFO - 2023-01-15 07:53:07 --> Helper loaded: form_helper
INFO - 2023-01-15 07:53:07 --> Helper loaded: my_helper
INFO - 2023-01-15 07:53:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:53:07 --> Controller Class Initialized
DEBUG - 2023-01-15 07:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:53:08 --> Final output sent to browser
DEBUG - 2023-01-15 07:53:08 --> Total execution time: 1.0859
INFO - 2023-01-15 07:55:06 --> Config Class Initialized
INFO - 2023-01-15 07:55:06 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:55:06 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:55:06 --> Utf8 Class Initialized
INFO - 2023-01-15 07:55:06 --> URI Class Initialized
INFO - 2023-01-15 07:55:06 --> Router Class Initialized
INFO - 2023-01-15 07:55:06 --> Output Class Initialized
INFO - 2023-01-15 07:55:06 --> Security Class Initialized
DEBUG - 2023-01-15 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:55:06 --> Input Class Initialized
INFO - 2023-01-15 07:55:06 --> Language Class Initialized
INFO - 2023-01-15 07:55:06 --> Language Class Initialized
INFO - 2023-01-15 07:55:06 --> Config Class Initialized
INFO - 2023-01-15 07:55:06 --> Loader Class Initialized
INFO - 2023-01-15 07:55:06 --> Helper loaded: url_helper
INFO - 2023-01-15 07:55:06 --> Helper loaded: file_helper
INFO - 2023-01-15 07:55:06 --> Helper loaded: form_helper
INFO - 2023-01-15 07:55:06 --> Helper loaded: my_helper
INFO - 2023-01-15 07:55:06 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:55:06 --> Controller Class Initialized
DEBUG - 2023-01-15 07:55:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:55:07 --> Final output sent to browser
DEBUG - 2023-01-15 07:55:07 --> Total execution time: 1.1673
INFO - 2023-01-15 07:55:51 --> Config Class Initialized
INFO - 2023-01-15 07:55:51 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:55:51 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:55:51 --> Utf8 Class Initialized
INFO - 2023-01-15 07:55:51 --> URI Class Initialized
INFO - 2023-01-15 07:55:51 --> Router Class Initialized
INFO - 2023-01-15 07:55:51 --> Output Class Initialized
INFO - 2023-01-15 07:55:51 --> Security Class Initialized
DEBUG - 2023-01-15 07:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:55:51 --> Input Class Initialized
INFO - 2023-01-15 07:55:51 --> Language Class Initialized
INFO - 2023-01-15 07:55:51 --> Language Class Initialized
INFO - 2023-01-15 07:55:51 --> Config Class Initialized
INFO - 2023-01-15 07:55:51 --> Loader Class Initialized
INFO - 2023-01-15 07:55:51 --> Helper loaded: url_helper
INFO - 2023-01-15 07:55:51 --> Helper loaded: file_helper
INFO - 2023-01-15 07:55:51 --> Helper loaded: form_helper
INFO - 2023-01-15 07:55:51 --> Helper loaded: my_helper
INFO - 2023-01-15 07:55:51 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:55:51 --> Controller Class Initialized
DEBUG - 2023-01-15 07:55:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:55:52 --> Final output sent to browser
DEBUG - 2023-01-15 07:55:52 --> Total execution time: 1.1015
INFO - 2023-01-15 07:56:19 --> Config Class Initialized
INFO - 2023-01-15 07:56:19 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:56:19 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:56:19 --> Utf8 Class Initialized
INFO - 2023-01-15 07:56:19 --> URI Class Initialized
INFO - 2023-01-15 07:56:19 --> Router Class Initialized
INFO - 2023-01-15 07:56:19 --> Output Class Initialized
INFO - 2023-01-15 07:56:19 --> Security Class Initialized
DEBUG - 2023-01-15 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:56:19 --> Input Class Initialized
INFO - 2023-01-15 07:56:19 --> Language Class Initialized
INFO - 2023-01-15 07:56:19 --> Language Class Initialized
INFO - 2023-01-15 07:56:19 --> Config Class Initialized
INFO - 2023-01-15 07:56:19 --> Loader Class Initialized
INFO - 2023-01-15 07:56:19 --> Helper loaded: url_helper
INFO - 2023-01-15 07:56:19 --> Helper loaded: file_helper
INFO - 2023-01-15 07:56:19 --> Helper loaded: form_helper
INFO - 2023-01-15 07:56:19 --> Helper loaded: my_helper
INFO - 2023-01-15 07:56:19 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:56:19 --> Controller Class Initialized
DEBUG - 2023-01-15 07:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:56:20 --> Final output sent to browser
DEBUG - 2023-01-15 07:56:20 --> Total execution time: 1.1377
INFO - 2023-01-15 07:58:56 --> Config Class Initialized
INFO - 2023-01-15 07:58:56 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:58:56 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:58:56 --> Utf8 Class Initialized
INFO - 2023-01-15 07:58:56 --> URI Class Initialized
INFO - 2023-01-15 07:58:56 --> Router Class Initialized
INFO - 2023-01-15 07:58:56 --> Output Class Initialized
INFO - 2023-01-15 07:58:56 --> Security Class Initialized
DEBUG - 2023-01-15 07:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:58:56 --> Input Class Initialized
INFO - 2023-01-15 07:58:56 --> Language Class Initialized
INFO - 2023-01-15 07:58:56 --> Language Class Initialized
INFO - 2023-01-15 07:58:56 --> Config Class Initialized
INFO - 2023-01-15 07:58:56 --> Loader Class Initialized
INFO - 2023-01-15 07:58:56 --> Helper loaded: url_helper
INFO - 2023-01-15 07:58:56 --> Helper loaded: file_helper
INFO - 2023-01-15 07:58:56 --> Helper loaded: form_helper
INFO - 2023-01-15 07:58:56 --> Helper loaded: my_helper
INFO - 2023-01-15 07:58:56 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:58:56 --> Controller Class Initialized
DEBUG - 2023-01-15 07:58:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:58:58 --> Final output sent to browser
DEBUG - 2023-01-15 07:58:58 --> Total execution time: 1.1854
INFO - 2023-01-15 07:59:17 --> Config Class Initialized
INFO - 2023-01-15 07:59:17 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:59:17 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:59:17 --> Utf8 Class Initialized
INFO - 2023-01-15 07:59:17 --> URI Class Initialized
INFO - 2023-01-15 07:59:17 --> Router Class Initialized
INFO - 2023-01-15 07:59:17 --> Output Class Initialized
INFO - 2023-01-15 07:59:17 --> Security Class Initialized
DEBUG - 2023-01-15 07:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:59:17 --> Input Class Initialized
INFO - 2023-01-15 07:59:17 --> Language Class Initialized
INFO - 2023-01-15 07:59:17 --> Language Class Initialized
INFO - 2023-01-15 07:59:17 --> Config Class Initialized
INFO - 2023-01-15 07:59:17 --> Loader Class Initialized
INFO - 2023-01-15 07:59:17 --> Helper loaded: url_helper
INFO - 2023-01-15 07:59:17 --> Helper loaded: file_helper
INFO - 2023-01-15 07:59:17 --> Helper loaded: form_helper
INFO - 2023-01-15 07:59:17 --> Helper loaded: my_helper
INFO - 2023-01-15 07:59:17 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:59:17 --> Controller Class Initialized
DEBUG - 2023-01-15 07:59:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:59:18 --> Final output sent to browser
DEBUG - 2023-01-15 07:59:18 --> Total execution time: 1.1485
INFO - 2023-01-15 07:59:41 --> Config Class Initialized
INFO - 2023-01-15 07:59:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 07:59:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 07:59:41 --> Utf8 Class Initialized
INFO - 2023-01-15 07:59:41 --> URI Class Initialized
INFO - 2023-01-15 07:59:41 --> Router Class Initialized
INFO - 2023-01-15 07:59:41 --> Output Class Initialized
INFO - 2023-01-15 07:59:41 --> Security Class Initialized
DEBUG - 2023-01-15 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 07:59:41 --> Input Class Initialized
INFO - 2023-01-15 07:59:41 --> Language Class Initialized
INFO - 2023-01-15 07:59:41 --> Language Class Initialized
INFO - 2023-01-15 07:59:41 --> Config Class Initialized
INFO - 2023-01-15 07:59:41 --> Loader Class Initialized
INFO - 2023-01-15 07:59:41 --> Helper loaded: url_helper
INFO - 2023-01-15 07:59:41 --> Helper loaded: file_helper
INFO - 2023-01-15 07:59:41 --> Helper loaded: form_helper
INFO - 2023-01-15 07:59:41 --> Helper loaded: my_helper
INFO - 2023-01-15 07:59:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 07:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 07:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 07:59:41 --> Controller Class Initialized
DEBUG - 2023-01-15 07:59:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 07:59:43 --> Final output sent to browser
DEBUG - 2023-01-15 07:59:43 --> Total execution time: 1.1162
INFO - 2023-01-15 08:00:41 --> Config Class Initialized
INFO - 2023-01-15 08:00:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:00:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:00:41 --> Utf8 Class Initialized
INFO - 2023-01-15 08:00:41 --> URI Class Initialized
INFO - 2023-01-15 08:00:41 --> Router Class Initialized
INFO - 2023-01-15 08:00:41 --> Output Class Initialized
INFO - 2023-01-15 08:00:41 --> Security Class Initialized
DEBUG - 2023-01-15 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:00:41 --> Input Class Initialized
INFO - 2023-01-15 08:00:41 --> Language Class Initialized
INFO - 2023-01-15 08:00:41 --> Language Class Initialized
INFO - 2023-01-15 08:00:41 --> Config Class Initialized
INFO - 2023-01-15 08:00:41 --> Loader Class Initialized
INFO - 2023-01-15 08:00:41 --> Helper loaded: url_helper
INFO - 2023-01-15 08:00:41 --> Helper loaded: file_helper
INFO - 2023-01-15 08:00:41 --> Helper loaded: form_helper
INFO - 2023-01-15 08:00:41 --> Helper loaded: my_helper
INFO - 2023-01-15 08:00:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:00:41 --> Controller Class Initialized
DEBUG - 2023-01-15 08:00:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:00:42 --> Final output sent to browser
DEBUG - 2023-01-15 08:00:42 --> Total execution time: 1.0695
INFO - 2023-01-15 08:02:37 --> Config Class Initialized
INFO - 2023-01-15 08:02:37 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:02:37 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:02:37 --> Utf8 Class Initialized
INFO - 2023-01-15 08:02:37 --> URI Class Initialized
INFO - 2023-01-15 08:02:37 --> Router Class Initialized
INFO - 2023-01-15 08:02:37 --> Output Class Initialized
INFO - 2023-01-15 08:02:37 --> Security Class Initialized
DEBUG - 2023-01-15 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:02:37 --> Input Class Initialized
INFO - 2023-01-15 08:02:37 --> Language Class Initialized
INFO - 2023-01-15 08:02:37 --> Language Class Initialized
INFO - 2023-01-15 08:02:37 --> Config Class Initialized
INFO - 2023-01-15 08:02:37 --> Loader Class Initialized
INFO - 2023-01-15 08:02:37 --> Helper loaded: url_helper
INFO - 2023-01-15 08:02:37 --> Helper loaded: file_helper
INFO - 2023-01-15 08:02:37 --> Helper loaded: form_helper
INFO - 2023-01-15 08:02:37 --> Helper loaded: my_helper
INFO - 2023-01-15 08:02:37 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:02:37 --> Controller Class Initialized
DEBUG - 2023-01-15 08:02:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:02:38 --> Final output sent to browser
DEBUG - 2023-01-15 08:02:38 --> Total execution time: 1.1097
INFO - 2023-01-15 08:03:22 --> Config Class Initialized
INFO - 2023-01-15 08:03:22 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:03:22 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:03:22 --> Utf8 Class Initialized
INFO - 2023-01-15 08:03:22 --> URI Class Initialized
INFO - 2023-01-15 08:03:22 --> Router Class Initialized
INFO - 2023-01-15 08:03:22 --> Output Class Initialized
INFO - 2023-01-15 08:03:22 --> Security Class Initialized
DEBUG - 2023-01-15 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:03:22 --> Input Class Initialized
INFO - 2023-01-15 08:03:22 --> Language Class Initialized
INFO - 2023-01-15 08:03:22 --> Language Class Initialized
INFO - 2023-01-15 08:03:22 --> Config Class Initialized
INFO - 2023-01-15 08:03:22 --> Loader Class Initialized
INFO - 2023-01-15 08:03:22 --> Helper loaded: url_helper
INFO - 2023-01-15 08:03:22 --> Helper loaded: file_helper
INFO - 2023-01-15 08:03:22 --> Helper loaded: form_helper
INFO - 2023-01-15 08:03:22 --> Helper loaded: my_helper
INFO - 2023-01-15 08:03:22 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:03:22 --> Controller Class Initialized
DEBUG - 2023-01-15 08:03:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:03:23 --> Final output sent to browser
DEBUG - 2023-01-15 08:03:23 --> Total execution time: 1.0642
INFO - 2023-01-15 08:03:45 --> Config Class Initialized
INFO - 2023-01-15 08:03:45 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:03:45 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:03:45 --> Utf8 Class Initialized
INFO - 2023-01-15 08:03:45 --> URI Class Initialized
INFO - 2023-01-15 08:03:45 --> Router Class Initialized
INFO - 2023-01-15 08:03:45 --> Output Class Initialized
INFO - 2023-01-15 08:03:45 --> Security Class Initialized
DEBUG - 2023-01-15 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:03:45 --> Input Class Initialized
INFO - 2023-01-15 08:03:45 --> Language Class Initialized
INFO - 2023-01-15 08:03:45 --> Language Class Initialized
INFO - 2023-01-15 08:03:45 --> Config Class Initialized
INFO - 2023-01-15 08:03:45 --> Loader Class Initialized
INFO - 2023-01-15 08:03:45 --> Helper loaded: url_helper
INFO - 2023-01-15 08:03:45 --> Helper loaded: file_helper
INFO - 2023-01-15 08:03:45 --> Helper loaded: form_helper
INFO - 2023-01-15 08:03:45 --> Helper loaded: my_helper
INFO - 2023-01-15 08:03:45 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:03:45 --> Controller Class Initialized
DEBUG - 2023-01-15 08:03:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:03:46 --> Final output sent to browser
DEBUG - 2023-01-15 08:03:46 --> Total execution time: 1.0704
INFO - 2023-01-15 08:05:01 --> Config Class Initialized
INFO - 2023-01-15 08:05:01 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:05:01 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:05:01 --> Utf8 Class Initialized
INFO - 2023-01-15 08:05:01 --> URI Class Initialized
INFO - 2023-01-15 08:05:01 --> Router Class Initialized
INFO - 2023-01-15 08:05:01 --> Output Class Initialized
INFO - 2023-01-15 08:05:01 --> Security Class Initialized
DEBUG - 2023-01-15 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:05:01 --> Input Class Initialized
INFO - 2023-01-15 08:05:01 --> Language Class Initialized
INFO - 2023-01-15 08:05:01 --> Language Class Initialized
INFO - 2023-01-15 08:05:01 --> Config Class Initialized
INFO - 2023-01-15 08:05:01 --> Loader Class Initialized
INFO - 2023-01-15 08:05:01 --> Helper loaded: url_helper
INFO - 2023-01-15 08:05:01 --> Helper loaded: file_helper
INFO - 2023-01-15 08:05:01 --> Helper loaded: form_helper
INFO - 2023-01-15 08:05:01 --> Helper loaded: my_helper
INFO - 2023-01-15 08:05:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:05:01 --> Controller Class Initialized
DEBUG - 2023-01-15 08:05:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:05:02 --> Final output sent to browser
DEBUG - 2023-01-15 08:05:02 --> Total execution time: 1.1046
INFO - 2023-01-15 08:06:57 --> Config Class Initialized
INFO - 2023-01-15 08:06:57 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:06:57 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:06:57 --> Utf8 Class Initialized
INFO - 2023-01-15 08:06:57 --> URI Class Initialized
INFO - 2023-01-15 08:06:57 --> Router Class Initialized
INFO - 2023-01-15 08:06:57 --> Output Class Initialized
INFO - 2023-01-15 08:06:57 --> Security Class Initialized
DEBUG - 2023-01-15 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:06:57 --> Input Class Initialized
INFO - 2023-01-15 08:06:57 --> Language Class Initialized
INFO - 2023-01-15 08:06:57 --> Language Class Initialized
INFO - 2023-01-15 08:06:57 --> Config Class Initialized
INFO - 2023-01-15 08:06:57 --> Loader Class Initialized
INFO - 2023-01-15 08:06:57 --> Helper loaded: url_helper
INFO - 2023-01-15 08:06:57 --> Helper loaded: file_helper
INFO - 2023-01-15 08:06:57 --> Helper loaded: form_helper
INFO - 2023-01-15 08:06:57 --> Helper loaded: my_helper
INFO - 2023-01-15 08:06:57 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:06:57 --> Controller Class Initialized
DEBUG - 2023-01-15 08:06:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:06:58 --> Final output sent to browser
DEBUG - 2023-01-15 08:06:58 --> Total execution time: 1.1126
INFO - 2023-01-15 08:07:31 --> Config Class Initialized
INFO - 2023-01-15 08:07:31 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:07:31 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:07:31 --> Utf8 Class Initialized
INFO - 2023-01-15 08:07:31 --> URI Class Initialized
INFO - 2023-01-15 08:07:31 --> Router Class Initialized
INFO - 2023-01-15 08:07:31 --> Output Class Initialized
INFO - 2023-01-15 08:07:31 --> Security Class Initialized
DEBUG - 2023-01-15 08:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:07:31 --> Input Class Initialized
INFO - 2023-01-15 08:07:31 --> Language Class Initialized
INFO - 2023-01-15 08:07:31 --> Language Class Initialized
INFO - 2023-01-15 08:07:31 --> Config Class Initialized
INFO - 2023-01-15 08:07:31 --> Loader Class Initialized
INFO - 2023-01-15 08:07:31 --> Helper loaded: url_helper
INFO - 2023-01-15 08:07:31 --> Helper loaded: file_helper
INFO - 2023-01-15 08:07:31 --> Helper loaded: form_helper
INFO - 2023-01-15 08:07:31 --> Helper loaded: my_helper
INFO - 2023-01-15 08:07:31 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:07:31 --> Controller Class Initialized
DEBUG - 2023-01-15 08:07:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:07:32 --> Final output sent to browser
DEBUG - 2023-01-15 08:07:32 --> Total execution time: 1.0768
INFO - 2023-01-15 08:07:46 --> Config Class Initialized
INFO - 2023-01-15 08:07:46 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:07:46 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:07:46 --> Utf8 Class Initialized
INFO - 2023-01-15 08:07:46 --> URI Class Initialized
INFO - 2023-01-15 08:07:46 --> Router Class Initialized
INFO - 2023-01-15 08:07:46 --> Output Class Initialized
INFO - 2023-01-15 08:07:46 --> Security Class Initialized
DEBUG - 2023-01-15 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:07:46 --> Input Class Initialized
INFO - 2023-01-15 08:07:46 --> Language Class Initialized
INFO - 2023-01-15 08:07:46 --> Language Class Initialized
INFO - 2023-01-15 08:07:46 --> Config Class Initialized
INFO - 2023-01-15 08:07:46 --> Loader Class Initialized
INFO - 2023-01-15 08:07:46 --> Helper loaded: url_helper
INFO - 2023-01-15 08:07:46 --> Helper loaded: file_helper
INFO - 2023-01-15 08:07:46 --> Helper loaded: form_helper
INFO - 2023-01-15 08:07:46 --> Helper loaded: my_helper
INFO - 2023-01-15 08:07:46 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:07:46 --> Controller Class Initialized
DEBUG - 2023-01-15 08:07:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:07:47 --> Final output sent to browser
DEBUG - 2023-01-15 08:07:47 --> Total execution time: 1.0581
INFO - 2023-01-15 08:16:32 --> Config Class Initialized
INFO - 2023-01-15 08:16:32 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:16:32 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:16:32 --> Utf8 Class Initialized
INFO - 2023-01-15 08:16:32 --> URI Class Initialized
INFO - 2023-01-15 08:16:32 --> Router Class Initialized
INFO - 2023-01-15 08:16:32 --> Output Class Initialized
INFO - 2023-01-15 08:16:32 --> Security Class Initialized
DEBUG - 2023-01-15 08:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:16:32 --> Input Class Initialized
INFO - 2023-01-15 08:16:32 --> Language Class Initialized
INFO - 2023-01-15 08:16:32 --> Language Class Initialized
INFO - 2023-01-15 08:16:32 --> Config Class Initialized
INFO - 2023-01-15 08:16:32 --> Loader Class Initialized
INFO - 2023-01-15 08:16:32 --> Helper loaded: url_helper
INFO - 2023-01-15 08:16:32 --> Helper loaded: file_helper
INFO - 2023-01-15 08:16:32 --> Helper loaded: form_helper
INFO - 2023-01-15 08:16:32 --> Helper loaded: my_helper
INFO - 2023-01-15 08:16:32 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:16:32 --> Controller Class Initialized
ERROR - 2023-01-15 08:16:32 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
ERROR - 2023-01-15 08:16:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
DEBUG - 2023-01-15 08:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:16:33 --> Final output sent to browser
DEBUG - 2023-01-15 08:16:33 --> Total execution time: 1.1222
INFO - 2023-01-15 08:17:55 --> Config Class Initialized
INFO - 2023-01-15 08:17:55 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:17:55 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:17:55 --> Utf8 Class Initialized
INFO - 2023-01-15 08:17:55 --> URI Class Initialized
INFO - 2023-01-15 08:17:55 --> Router Class Initialized
INFO - 2023-01-15 08:17:55 --> Output Class Initialized
INFO - 2023-01-15 08:17:55 --> Security Class Initialized
DEBUG - 2023-01-15 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:17:55 --> Input Class Initialized
INFO - 2023-01-15 08:17:55 --> Language Class Initialized
INFO - 2023-01-15 08:17:55 --> Language Class Initialized
INFO - 2023-01-15 08:17:55 --> Config Class Initialized
INFO - 2023-01-15 08:17:55 --> Loader Class Initialized
INFO - 2023-01-15 08:17:55 --> Helper loaded: url_helper
INFO - 2023-01-15 08:17:55 --> Helper loaded: file_helper
INFO - 2023-01-15 08:17:55 --> Helper loaded: form_helper
INFO - 2023-01-15 08:17:55 --> Helper loaded: my_helper
INFO - 2023-01-15 08:17:55 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:17:55 --> Controller Class Initialized
ERROR - 2023-01-15 08:17:55 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
ERROR - 2023-01-15 08:17:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
DEBUG - 2023-01-15 08:17:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:17:56 --> Final output sent to browser
DEBUG - 2023-01-15 08:17:56 --> Total execution time: 1.0667
INFO - 2023-01-15 08:19:12 --> Config Class Initialized
INFO - 2023-01-15 08:19:12 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:19:12 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:19:12 --> Utf8 Class Initialized
INFO - 2023-01-15 08:19:12 --> URI Class Initialized
INFO - 2023-01-15 08:19:12 --> Router Class Initialized
INFO - 2023-01-15 08:19:12 --> Output Class Initialized
INFO - 2023-01-15 08:19:12 --> Security Class Initialized
DEBUG - 2023-01-15 08:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:19:12 --> Input Class Initialized
INFO - 2023-01-15 08:19:12 --> Language Class Initialized
INFO - 2023-01-15 08:19:12 --> Language Class Initialized
INFO - 2023-01-15 08:19:12 --> Config Class Initialized
INFO - 2023-01-15 08:19:12 --> Loader Class Initialized
INFO - 2023-01-15 08:19:12 --> Helper loaded: url_helper
INFO - 2023-01-15 08:19:12 --> Helper loaded: file_helper
INFO - 2023-01-15 08:19:12 --> Helper loaded: form_helper
INFO - 2023-01-15 08:19:12 --> Helper loaded: my_helper
INFO - 2023-01-15 08:19:12 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:19:12 --> Controller Class Initialized
DEBUG - 2023-01-15 08:19:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:19:13 --> Final output sent to browser
DEBUG - 2023-01-15 08:19:13 --> Total execution time: 1.0951
INFO - 2023-01-15 08:19:53 --> Config Class Initialized
INFO - 2023-01-15 08:19:53 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:19:53 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:19:53 --> Utf8 Class Initialized
INFO - 2023-01-15 08:19:53 --> URI Class Initialized
INFO - 2023-01-15 08:19:53 --> Router Class Initialized
INFO - 2023-01-15 08:19:53 --> Output Class Initialized
INFO - 2023-01-15 08:19:53 --> Security Class Initialized
DEBUG - 2023-01-15 08:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:19:53 --> Input Class Initialized
INFO - 2023-01-15 08:19:53 --> Language Class Initialized
INFO - 2023-01-15 08:19:53 --> Language Class Initialized
INFO - 2023-01-15 08:19:53 --> Config Class Initialized
INFO - 2023-01-15 08:19:53 --> Loader Class Initialized
INFO - 2023-01-15 08:19:53 --> Helper loaded: url_helper
INFO - 2023-01-15 08:19:53 --> Helper loaded: file_helper
INFO - 2023-01-15 08:19:53 --> Helper loaded: form_helper
INFO - 2023-01-15 08:19:53 --> Helper loaded: my_helper
INFO - 2023-01-15 08:19:53 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:19:53 --> Controller Class Initialized
ERROR - 2023-01-15 08:19:53 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
ERROR - 2023-01-15 08:19:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
DEBUG - 2023-01-15 08:19:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:19:54 --> Final output sent to browser
DEBUG - 2023-01-15 08:19:54 --> Total execution time: 1.0683
INFO - 2023-01-15 08:20:05 --> Config Class Initialized
INFO - 2023-01-15 08:20:05 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:20:05 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:20:05 --> Utf8 Class Initialized
INFO - 2023-01-15 08:20:05 --> URI Class Initialized
INFO - 2023-01-15 08:20:05 --> Router Class Initialized
INFO - 2023-01-15 08:20:05 --> Output Class Initialized
INFO - 2023-01-15 08:20:05 --> Security Class Initialized
DEBUG - 2023-01-15 08:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:20:05 --> Input Class Initialized
INFO - 2023-01-15 08:20:05 --> Language Class Initialized
INFO - 2023-01-15 08:20:05 --> Language Class Initialized
INFO - 2023-01-15 08:20:05 --> Config Class Initialized
INFO - 2023-01-15 08:20:05 --> Loader Class Initialized
INFO - 2023-01-15 08:20:05 --> Helper loaded: url_helper
INFO - 2023-01-15 08:20:05 --> Helper loaded: file_helper
INFO - 2023-01-15 08:20:05 --> Helper loaded: form_helper
INFO - 2023-01-15 08:20:05 --> Helper loaded: my_helper
INFO - 2023-01-15 08:20:05 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:20:05 --> Controller Class Initialized
ERROR - 2023-01-15 08:20:05 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
ERROR - 2023-01-15 08:20:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
DEBUG - 2023-01-15 08:20:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:20:06 --> Final output sent to browser
DEBUG - 2023-01-15 08:20:06 --> Total execution time: 1.0636
INFO - 2023-01-15 08:20:14 --> Config Class Initialized
INFO - 2023-01-15 08:20:14 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:20:14 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:20:14 --> Utf8 Class Initialized
INFO - 2023-01-15 08:20:14 --> URI Class Initialized
INFO - 2023-01-15 08:20:14 --> Router Class Initialized
INFO - 2023-01-15 08:20:14 --> Output Class Initialized
INFO - 2023-01-15 08:20:14 --> Security Class Initialized
DEBUG - 2023-01-15 08:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:20:14 --> Input Class Initialized
INFO - 2023-01-15 08:20:14 --> Language Class Initialized
INFO - 2023-01-15 08:20:14 --> Language Class Initialized
INFO - 2023-01-15 08:20:14 --> Config Class Initialized
INFO - 2023-01-15 08:20:14 --> Loader Class Initialized
INFO - 2023-01-15 08:20:14 --> Helper loaded: url_helper
INFO - 2023-01-15 08:20:14 --> Helper loaded: file_helper
INFO - 2023-01-15 08:20:14 --> Helper loaded: form_helper
INFO - 2023-01-15 08:20:14 --> Helper loaded: my_helper
INFO - 2023-01-15 08:20:14 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:20:14 --> Controller Class Initialized
ERROR - 2023-01-15 08:20:14 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1342
DEBUG - 2023-01-15 08:20:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:20:15 --> Final output sent to browser
DEBUG - 2023-01-15 08:20:15 --> Total execution time: 1.0507
INFO - 2023-01-15 08:20:24 --> Config Class Initialized
INFO - 2023-01-15 08:20:24 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:20:24 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:20:24 --> Utf8 Class Initialized
INFO - 2023-01-15 08:20:24 --> URI Class Initialized
INFO - 2023-01-15 08:20:24 --> Router Class Initialized
INFO - 2023-01-15 08:20:24 --> Output Class Initialized
INFO - 2023-01-15 08:20:24 --> Security Class Initialized
DEBUG - 2023-01-15 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:20:24 --> Input Class Initialized
INFO - 2023-01-15 08:20:24 --> Language Class Initialized
INFO - 2023-01-15 08:20:24 --> Language Class Initialized
INFO - 2023-01-15 08:20:24 --> Config Class Initialized
INFO - 2023-01-15 08:20:24 --> Loader Class Initialized
INFO - 2023-01-15 08:20:24 --> Helper loaded: url_helper
INFO - 2023-01-15 08:20:24 --> Helper loaded: file_helper
INFO - 2023-01-15 08:20:24 --> Helper loaded: form_helper
INFO - 2023-01-15 08:20:24 --> Helper loaded: my_helper
INFO - 2023-01-15 08:20:24 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:20:24 --> Controller Class Initialized
DEBUG - 2023-01-15 08:20:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:20:25 --> Final output sent to browser
DEBUG - 2023-01-15 08:20:25 --> Total execution time: 1.0897
INFO - 2023-01-15 08:22:05 --> Config Class Initialized
INFO - 2023-01-15 08:22:05 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:22:05 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:22:05 --> Utf8 Class Initialized
INFO - 2023-01-15 08:22:05 --> URI Class Initialized
INFO - 2023-01-15 08:22:05 --> Router Class Initialized
INFO - 2023-01-15 08:22:05 --> Output Class Initialized
INFO - 2023-01-15 08:22:05 --> Security Class Initialized
DEBUG - 2023-01-15 08:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:22:05 --> Input Class Initialized
INFO - 2023-01-15 08:22:05 --> Language Class Initialized
INFO - 2023-01-15 08:22:05 --> Language Class Initialized
INFO - 2023-01-15 08:22:05 --> Config Class Initialized
INFO - 2023-01-15 08:22:05 --> Loader Class Initialized
INFO - 2023-01-15 08:22:05 --> Helper loaded: url_helper
INFO - 2023-01-15 08:22:05 --> Helper loaded: file_helper
INFO - 2023-01-15 08:22:05 --> Helper loaded: form_helper
INFO - 2023-01-15 08:22:05 --> Helper loaded: my_helper
INFO - 2023-01-15 08:22:05 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:22:05 --> Controller Class Initialized
DEBUG - 2023-01-15 08:22:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:22:07 --> Final output sent to browser
DEBUG - 2023-01-15 08:22:07 --> Total execution time: 1.0562
INFO - 2023-01-15 08:22:29 --> Config Class Initialized
INFO - 2023-01-15 08:22:29 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:22:29 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:22:29 --> Utf8 Class Initialized
INFO - 2023-01-15 08:22:29 --> URI Class Initialized
INFO - 2023-01-15 08:22:29 --> Router Class Initialized
INFO - 2023-01-15 08:22:29 --> Output Class Initialized
INFO - 2023-01-15 08:22:29 --> Security Class Initialized
DEBUG - 2023-01-15 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:22:29 --> Input Class Initialized
INFO - 2023-01-15 08:22:29 --> Language Class Initialized
INFO - 2023-01-15 08:22:29 --> Language Class Initialized
INFO - 2023-01-15 08:22:29 --> Config Class Initialized
INFO - 2023-01-15 08:22:29 --> Loader Class Initialized
INFO - 2023-01-15 08:22:29 --> Helper loaded: url_helper
INFO - 2023-01-15 08:22:29 --> Helper loaded: file_helper
INFO - 2023-01-15 08:22:29 --> Helper loaded: form_helper
INFO - 2023-01-15 08:22:29 --> Helper loaded: my_helper
INFO - 2023-01-15 08:22:29 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:22:29 --> Controller Class Initialized
DEBUG - 2023-01-15 08:22:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:22:30 --> Final output sent to browser
DEBUG - 2023-01-15 08:22:30 --> Total execution time: 1.0322
INFO - 2023-01-15 08:23:09 --> Config Class Initialized
INFO - 2023-01-15 08:23:09 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:23:09 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:23:09 --> Utf8 Class Initialized
INFO - 2023-01-15 08:23:09 --> URI Class Initialized
INFO - 2023-01-15 08:23:09 --> Router Class Initialized
INFO - 2023-01-15 08:23:09 --> Output Class Initialized
INFO - 2023-01-15 08:23:09 --> Security Class Initialized
DEBUG - 2023-01-15 08:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:23:09 --> Input Class Initialized
INFO - 2023-01-15 08:23:09 --> Language Class Initialized
INFO - 2023-01-15 08:23:09 --> Language Class Initialized
INFO - 2023-01-15 08:23:09 --> Config Class Initialized
INFO - 2023-01-15 08:23:09 --> Loader Class Initialized
INFO - 2023-01-15 08:23:09 --> Helper loaded: url_helper
INFO - 2023-01-15 08:23:09 --> Helper loaded: file_helper
INFO - 2023-01-15 08:23:09 --> Helper loaded: form_helper
INFO - 2023-01-15 08:23:09 --> Helper loaded: my_helper
INFO - 2023-01-15 08:23:09 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:23:09 --> Controller Class Initialized
DEBUG - 2023-01-15 08:23:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:23:10 --> Final output sent to browser
DEBUG - 2023-01-15 08:23:10 --> Total execution time: 1.0541
INFO - 2023-01-15 08:24:47 --> Config Class Initialized
INFO - 2023-01-15 08:24:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:24:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:24:47 --> Utf8 Class Initialized
INFO - 2023-01-15 08:24:47 --> URI Class Initialized
INFO - 2023-01-15 08:24:47 --> Router Class Initialized
INFO - 2023-01-15 08:24:47 --> Output Class Initialized
INFO - 2023-01-15 08:24:47 --> Security Class Initialized
DEBUG - 2023-01-15 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:24:47 --> Input Class Initialized
INFO - 2023-01-15 08:24:47 --> Language Class Initialized
INFO - 2023-01-15 08:24:47 --> Language Class Initialized
INFO - 2023-01-15 08:24:47 --> Config Class Initialized
INFO - 2023-01-15 08:24:47 --> Loader Class Initialized
INFO - 2023-01-15 08:24:47 --> Helper loaded: url_helper
INFO - 2023-01-15 08:24:47 --> Helper loaded: file_helper
INFO - 2023-01-15 08:24:47 --> Helper loaded: form_helper
INFO - 2023-01-15 08:24:47 --> Helper loaded: my_helper
INFO - 2023-01-15 08:24:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:24:47 --> Controller Class Initialized
ERROR - 2023-01-15 08:24:47 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1343
ERROR - 2023-01-15 08:24:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1343
DEBUG - 2023-01-15 08:24:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:24:48 --> Final output sent to browser
DEBUG - 2023-01-15 08:24:48 --> Total execution time: 1.1374
INFO - 2023-01-15 08:25:04 --> Config Class Initialized
INFO - 2023-01-15 08:25:04 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:25:04 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:25:04 --> Utf8 Class Initialized
INFO - 2023-01-15 08:25:04 --> URI Class Initialized
INFO - 2023-01-15 08:25:04 --> Router Class Initialized
INFO - 2023-01-15 08:25:04 --> Output Class Initialized
INFO - 2023-01-15 08:25:04 --> Security Class Initialized
DEBUG - 2023-01-15 08:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:25:04 --> Input Class Initialized
INFO - 2023-01-15 08:25:04 --> Language Class Initialized
INFO - 2023-01-15 08:25:04 --> Language Class Initialized
INFO - 2023-01-15 08:25:04 --> Config Class Initialized
INFO - 2023-01-15 08:25:04 --> Loader Class Initialized
INFO - 2023-01-15 08:25:04 --> Helper loaded: url_helper
INFO - 2023-01-15 08:25:04 --> Helper loaded: file_helper
INFO - 2023-01-15 08:25:04 --> Helper loaded: form_helper
INFO - 2023-01-15 08:25:04 --> Helper loaded: my_helper
INFO - 2023-01-15 08:25:04 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:25:04 --> Controller Class Initialized
ERROR - 2023-01-15 08:25:04 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1343
DEBUG - 2023-01-15 08:25:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:25:05 --> Final output sent to browser
DEBUG - 2023-01-15 08:25:05 --> Total execution time: 1.1079
INFO - 2023-01-15 08:25:13 --> Config Class Initialized
INFO - 2023-01-15 08:25:13 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:25:13 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:25:13 --> Utf8 Class Initialized
INFO - 2023-01-15 08:25:13 --> URI Class Initialized
INFO - 2023-01-15 08:25:13 --> Router Class Initialized
INFO - 2023-01-15 08:25:13 --> Output Class Initialized
INFO - 2023-01-15 08:25:13 --> Security Class Initialized
DEBUG - 2023-01-15 08:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:25:13 --> Input Class Initialized
INFO - 2023-01-15 08:25:13 --> Language Class Initialized
INFO - 2023-01-15 08:25:13 --> Language Class Initialized
INFO - 2023-01-15 08:25:13 --> Config Class Initialized
INFO - 2023-01-15 08:25:13 --> Loader Class Initialized
INFO - 2023-01-15 08:25:13 --> Helper loaded: url_helper
INFO - 2023-01-15 08:25:13 --> Helper loaded: file_helper
INFO - 2023-01-15 08:25:13 --> Helper loaded: form_helper
INFO - 2023-01-15 08:25:13 --> Helper loaded: my_helper
INFO - 2023-01-15 08:25:13 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:25:13 --> Controller Class Initialized
DEBUG - 2023-01-15 08:25:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:25:14 --> Final output sent to browser
DEBUG - 2023-01-15 08:25:14 --> Total execution time: 1.0745
INFO - 2023-01-15 08:25:43 --> Config Class Initialized
INFO - 2023-01-15 08:25:43 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:25:43 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:25:43 --> Utf8 Class Initialized
INFO - 2023-01-15 08:25:43 --> URI Class Initialized
INFO - 2023-01-15 08:25:43 --> Router Class Initialized
INFO - 2023-01-15 08:25:43 --> Output Class Initialized
INFO - 2023-01-15 08:25:43 --> Security Class Initialized
DEBUG - 2023-01-15 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:25:43 --> Input Class Initialized
INFO - 2023-01-15 08:25:43 --> Language Class Initialized
INFO - 2023-01-15 08:25:43 --> Language Class Initialized
INFO - 2023-01-15 08:25:43 --> Config Class Initialized
INFO - 2023-01-15 08:25:43 --> Loader Class Initialized
INFO - 2023-01-15 08:25:43 --> Helper loaded: url_helper
INFO - 2023-01-15 08:25:43 --> Helper loaded: file_helper
INFO - 2023-01-15 08:25:43 --> Helper loaded: form_helper
INFO - 2023-01-15 08:25:43 --> Helper loaded: my_helper
INFO - 2023-01-15 08:25:43 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:25:43 --> Controller Class Initialized
DEBUG - 2023-01-15 08:25:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:25:44 --> Final output sent to browser
DEBUG - 2023-01-15 08:25:44 --> Total execution time: 1.0929
INFO - 2023-01-15 08:26:36 --> Config Class Initialized
INFO - 2023-01-15 08:26:36 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:26:36 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:26:36 --> Utf8 Class Initialized
INFO - 2023-01-15 08:26:36 --> URI Class Initialized
INFO - 2023-01-15 08:26:36 --> Router Class Initialized
INFO - 2023-01-15 08:26:36 --> Output Class Initialized
INFO - 2023-01-15 08:26:36 --> Security Class Initialized
DEBUG - 2023-01-15 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:26:36 --> Input Class Initialized
INFO - 2023-01-15 08:26:36 --> Language Class Initialized
INFO - 2023-01-15 08:26:36 --> Language Class Initialized
INFO - 2023-01-15 08:26:36 --> Config Class Initialized
INFO - 2023-01-15 08:26:36 --> Loader Class Initialized
INFO - 2023-01-15 08:26:36 --> Helper loaded: url_helper
INFO - 2023-01-15 08:26:36 --> Helper loaded: file_helper
INFO - 2023-01-15 08:26:36 --> Helper loaded: form_helper
INFO - 2023-01-15 08:26:36 --> Helper loaded: my_helper
INFO - 2023-01-15 08:26:36 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:26:36 --> Controller Class Initialized
DEBUG - 2023-01-15 08:26:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:26:37 --> Final output sent to browser
DEBUG - 2023-01-15 08:26:37 --> Total execution time: 1.0648
INFO - 2023-01-15 08:28:02 --> Config Class Initialized
INFO - 2023-01-15 08:28:02 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:28:02 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:28:02 --> Utf8 Class Initialized
INFO - 2023-01-15 08:28:02 --> URI Class Initialized
INFO - 2023-01-15 08:28:02 --> Router Class Initialized
INFO - 2023-01-15 08:28:02 --> Output Class Initialized
INFO - 2023-01-15 08:28:02 --> Security Class Initialized
DEBUG - 2023-01-15 08:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:28:02 --> Input Class Initialized
INFO - 2023-01-15 08:28:02 --> Language Class Initialized
INFO - 2023-01-15 08:28:02 --> Language Class Initialized
INFO - 2023-01-15 08:28:02 --> Config Class Initialized
INFO - 2023-01-15 08:28:02 --> Loader Class Initialized
INFO - 2023-01-15 08:28:02 --> Helper loaded: url_helper
INFO - 2023-01-15 08:28:02 --> Helper loaded: file_helper
INFO - 2023-01-15 08:28:02 --> Helper loaded: form_helper
INFO - 2023-01-15 08:28:02 --> Helper loaded: my_helper
INFO - 2023-01-15 08:28:02 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:28:02 --> Controller Class Initialized
DEBUG - 2023-01-15 08:28:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:28:03 --> Final output sent to browser
DEBUG - 2023-01-15 08:28:03 --> Total execution time: 1.0343
INFO - 2023-01-15 08:28:17 --> Config Class Initialized
INFO - 2023-01-15 08:28:17 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:28:17 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:28:17 --> Utf8 Class Initialized
INFO - 2023-01-15 08:28:17 --> URI Class Initialized
INFO - 2023-01-15 08:28:17 --> Router Class Initialized
INFO - 2023-01-15 08:28:17 --> Output Class Initialized
INFO - 2023-01-15 08:28:17 --> Security Class Initialized
DEBUG - 2023-01-15 08:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:28:17 --> Input Class Initialized
INFO - 2023-01-15 08:28:17 --> Language Class Initialized
INFO - 2023-01-15 08:28:17 --> Language Class Initialized
INFO - 2023-01-15 08:28:17 --> Config Class Initialized
INFO - 2023-01-15 08:28:17 --> Loader Class Initialized
INFO - 2023-01-15 08:28:17 --> Helper loaded: url_helper
INFO - 2023-01-15 08:28:17 --> Helper loaded: file_helper
INFO - 2023-01-15 08:28:17 --> Helper loaded: form_helper
INFO - 2023-01-15 08:28:17 --> Helper loaded: my_helper
INFO - 2023-01-15 08:28:17 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:28:17 --> Controller Class Initialized
DEBUG - 2023-01-15 08:28:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:28:18 --> Final output sent to browser
DEBUG - 2023-01-15 08:28:18 --> Total execution time: 1.0942
INFO - 2023-01-15 08:29:32 --> Config Class Initialized
INFO - 2023-01-15 08:29:32 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:29:32 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:29:32 --> Utf8 Class Initialized
INFO - 2023-01-15 08:29:32 --> URI Class Initialized
INFO - 2023-01-15 08:29:32 --> Router Class Initialized
INFO - 2023-01-15 08:29:32 --> Output Class Initialized
INFO - 2023-01-15 08:29:32 --> Security Class Initialized
DEBUG - 2023-01-15 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:29:32 --> Input Class Initialized
INFO - 2023-01-15 08:29:32 --> Language Class Initialized
INFO - 2023-01-15 08:29:32 --> Language Class Initialized
INFO - 2023-01-15 08:29:32 --> Config Class Initialized
INFO - 2023-01-15 08:29:32 --> Loader Class Initialized
INFO - 2023-01-15 08:29:32 --> Helper loaded: url_helper
INFO - 2023-01-15 08:29:32 --> Helper loaded: file_helper
INFO - 2023-01-15 08:29:32 --> Helper loaded: form_helper
INFO - 2023-01-15 08:29:32 --> Helper loaded: my_helper
INFO - 2023-01-15 08:29:32 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:29:32 --> Controller Class Initialized
ERROR - 2023-01-15 08:29:32 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1100
DEBUG - 2023-01-15 08:29:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:29:33 --> Final output sent to browser
DEBUG - 2023-01-15 08:29:33 --> Total execution time: 1.0893
INFO - 2023-01-15 08:31:55 --> Config Class Initialized
INFO - 2023-01-15 08:31:55 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:31:55 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:31:55 --> Utf8 Class Initialized
INFO - 2023-01-15 08:31:55 --> URI Class Initialized
INFO - 2023-01-15 08:31:55 --> Router Class Initialized
INFO - 2023-01-15 08:31:55 --> Output Class Initialized
INFO - 2023-01-15 08:31:55 --> Security Class Initialized
DEBUG - 2023-01-15 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:31:55 --> Input Class Initialized
INFO - 2023-01-15 08:31:55 --> Language Class Initialized
INFO - 2023-01-15 08:31:55 --> Language Class Initialized
INFO - 2023-01-15 08:31:55 --> Config Class Initialized
INFO - 2023-01-15 08:31:55 --> Loader Class Initialized
INFO - 2023-01-15 08:31:55 --> Helper loaded: url_helper
INFO - 2023-01-15 08:31:55 --> Helper loaded: file_helper
INFO - 2023-01-15 08:31:55 --> Helper loaded: form_helper
INFO - 2023-01-15 08:31:55 --> Helper loaded: my_helper
INFO - 2023-01-15 08:31:55 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:31:55 --> Controller Class Initialized
ERROR - 2023-01-15 08:31:55 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1101
DEBUG - 2023-01-15 08:31:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:31:56 --> Final output sent to browser
DEBUG - 2023-01-15 08:31:56 --> Total execution time: 1.1472
INFO - 2023-01-15 08:36:58 --> Config Class Initialized
INFO - 2023-01-15 08:36:58 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:36:58 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:36:58 --> Utf8 Class Initialized
INFO - 2023-01-15 08:36:58 --> URI Class Initialized
INFO - 2023-01-15 08:36:58 --> Router Class Initialized
INFO - 2023-01-15 08:36:58 --> Output Class Initialized
INFO - 2023-01-15 08:36:58 --> Security Class Initialized
DEBUG - 2023-01-15 08:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:36:58 --> Input Class Initialized
INFO - 2023-01-15 08:36:58 --> Language Class Initialized
INFO - 2023-01-15 08:36:58 --> Language Class Initialized
INFO - 2023-01-15 08:36:58 --> Config Class Initialized
INFO - 2023-01-15 08:36:58 --> Loader Class Initialized
INFO - 2023-01-15 08:36:58 --> Helper loaded: url_helper
INFO - 2023-01-15 08:36:58 --> Helper loaded: file_helper
INFO - 2023-01-15 08:36:58 --> Helper loaded: form_helper
INFO - 2023-01-15 08:36:58 --> Helper loaded: my_helper
INFO - 2023-01-15 08:36:58 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:36:58 --> Controller Class Initialized
DEBUG - 2023-01-15 08:36:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:36:59 --> Final output sent to browser
DEBUG - 2023-01-15 08:36:59 --> Total execution time: 1.0474
INFO - 2023-01-15 08:39:38 --> Config Class Initialized
INFO - 2023-01-15 08:39:38 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:39:38 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:39:38 --> Utf8 Class Initialized
INFO - 2023-01-15 08:39:38 --> URI Class Initialized
INFO - 2023-01-15 08:39:38 --> Router Class Initialized
INFO - 2023-01-15 08:39:38 --> Output Class Initialized
INFO - 2023-01-15 08:39:38 --> Security Class Initialized
DEBUG - 2023-01-15 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:39:38 --> Input Class Initialized
INFO - 2023-01-15 08:39:38 --> Language Class Initialized
INFO - 2023-01-15 08:39:38 --> Language Class Initialized
INFO - 2023-01-15 08:39:38 --> Config Class Initialized
INFO - 2023-01-15 08:39:38 --> Loader Class Initialized
INFO - 2023-01-15 08:39:38 --> Helper loaded: url_helper
INFO - 2023-01-15 08:39:38 --> Helper loaded: file_helper
INFO - 2023-01-15 08:39:38 --> Helper loaded: form_helper
INFO - 2023-01-15 08:39:38 --> Helper loaded: my_helper
INFO - 2023-01-15 08:39:38 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:39:38 --> Controller Class Initialized
ERROR - 2023-01-15 08:39:38 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1350
DEBUG - 2023-01-15 08:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:39:39 --> Final output sent to browser
DEBUG - 2023-01-15 08:39:39 --> Total execution time: 1.0695
INFO - 2023-01-15 08:43:15 --> Config Class Initialized
INFO - 2023-01-15 08:43:15 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:43:15 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:43:15 --> Utf8 Class Initialized
INFO - 2023-01-15 08:43:15 --> URI Class Initialized
INFO - 2023-01-15 08:43:15 --> Router Class Initialized
INFO - 2023-01-15 08:43:15 --> Output Class Initialized
INFO - 2023-01-15 08:43:15 --> Security Class Initialized
DEBUG - 2023-01-15 08:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:43:15 --> Input Class Initialized
INFO - 2023-01-15 08:43:15 --> Language Class Initialized
INFO - 2023-01-15 08:43:15 --> Language Class Initialized
INFO - 2023-01-15 08:43:15 --> Config Class Initialized
INFO - 2023-01-15 08:43:15 --> Loader Class Initialized
INFO - 2023-01-15 08:43:15 --> Helper loaded: url_helper
INFO - 2023-01-15 08:43:15 --> Helper loaded: file_helper
INFO - 2023-01-15 08:43:15 --> Helper loaded: form_helper
INFO - 2023-01-15 08:43:15 --> Helper loaded: my_helper
INFO - 2023-01-15 08:43:15 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:43:15 --> Controller Class Initialized
DEBUG - 2023-01-15 08:43:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:43:16 --> Final output sent to browser
DEBUG - 2023-01-15 08:43:16 --> Total execution time: 1.0729
INFO - 2023-01-15 08:44:43 --> Config Class Initialized
INFO - 2023-01-15 08:44:43 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:44:43 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:44:43 --> Utf8 Class Initialized
INFO - 2023-01-15 08:44:43 --> URI Class Initialized
INFO - 2023-01-15 08:44:43 --> Router Class Initialized
INFO - 2023-01-15 08:44:43 --> Output Class Initialized
INFO - 2023-01-15 08:44:43 --> Security Class Initialized
DEBUG - 2023-01-15 08:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:44:43 --> Input Class Initialized
INFO - 2023-01-15 08:44:43 --> Language Class Initialized
INFO - 2023-01-15 08:44:43 --> Language Class Initialized
INFO - 2023-01-15 08:44:43 --> Config Class Initialized
INFO - 2023-01-15 08:44:43 --> Loader Class Initialized
INFO - 2023-01-15 08:44:43 --> Helper loaded: url_helper
INFO - 2023-01-15 08:44:43 --> Helper loaded: file_helper
INFO - 2023-01-15 08:44:43 --> Helper loaded: form_helper
INFO - 2023-01-15 08:44:43 --> Helper loaded: my_helper
INFO - 2023-01-15 08:44:43 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:44:43 --> Controller Class Initialized
DEBUG - 2023-01-15 08:44:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5265
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: tr_curr C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5265
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-01-15 08:44:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: tfoot C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5279
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5279
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: marge C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: new_page C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5335
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: cases C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-01-15 08:44:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: curr_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5404
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: marge C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5404
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5404
ERROR - 2023-01-15 08:44:43 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5405
ERROR - 2023-01-15 08:44:44 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-01-15 08:44:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-01-15 08:45:21 --> Config Class Initialized
INFO - 2023-01-15 08:45:21 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:45:21 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:45:21 --> Utf8 Class Initialized
INFO - 2023-01-15 08:45:21 --> URI Class Initialized
INFO - 2023-01-15 08:45:21 --> Router Class Initialized
INFO - 2023-01-15 08:45:21 --> Output Class Initialized
INFO - 2023-01-15 08:45:21 --> Security Class Initialized
DEBUG - 2023-01-15 08:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:45:21 --> Input Class Initialized
INFO - 2023-01-15 08:45:21 --> Language Class Initialized
INFO - 2023-01-15 08:45:21 --> Language Class Initialized
INFO - 2023-01-15 08:45:21 --> Config Class Initialized
INFO - 2023-01-15 08:45:21 --> Loader Class Initialized
INFO - 2023-01-15 08:45:21 --> Helper loaded: url_helper
INFO - 2023-01-15 08:45:21 --> Helper loaded: file_helper
INFO - 2023-01-15 08:45:21 --> Helper loaded: form_helper
INFO - 2023-01-15 08:45:21 --> Helper loaded: my_helper
INFO - 2023-01-15 08:45:21 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:45:21 --> Controller Class Initialized
DEBUG - 2023-01-15 08:45:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:45:22 --> Final output sent to browser
DEBUG - 2023-01-15 08:45:22 --> Total execution time: 1.0559
INFO - 2023-01-15 08:46:14 --> Config Class Initialized
INFO - 2023-01-15 08:46:14 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:46:14 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:46:14 --> Utf8 Class Initialized
INFO - 2023-01-15 08:46:14 --> URI Class Initialized
INFO - 2023-01-15 08:46:14 --> Router Class Initialized
INFO - 2023-01-15 08:46:14 --> Output Class Initialized
INFO - 2023-01-15 08:46:14 --> Security Class Initialized
DEBUG - 2023-01-15 08:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:46:14 --> Input Class Initialized
INFO - 2023-01-15 08:46:14 --> Language Class Initialized
INFO - 2023-01-15 08:46:14 --> Language Class Initialized
INFO - 2023-01-15 08:46:14 --> Config Class Initialized
INFO - 2023-01-15 08:46:14 --> Loader Class Initialized
INFO - 2023-01-15 08:46:14 --> Helper loaded: url_helper
INFO - 2023-01-15 08:46:14 --> Helper loaded: file_helper
INFO - 2023-01-15 08:46:14 --> Helper loaded: form_helper
INFO - 2023-01-15 08:46:14 --> Helper loaded: my_helper
INFO - 2023-01-15 08:46:14 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:46:14 --> Controller Class Initialized
DEBUG - 2023-01-15 08:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:46:15 --> Final output sent to browser
DEBUG - 2023-01-15 08:46:15 --> Total execution time: 1.1053
INFO - 2023-01-15 08:46:36 --> Config Class Initialized
INFO - 2023-01-15 08:46:36 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:46:36 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:46:36 --> Utf8 Class Initialized
INFO - 2023-01-15 08:46:36 --> URI Class Initialized
INFO - 2023-01-15 08:46:36 --> Router Class Initialized
INFO - 2023-01-15 08:46:36 --> Output Class Initialized
INFO - 2023-01-15 08:46:36 --> Security Class Initialized
DEBUG - 2023-01-15 08:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:46:36 --> Input Class Initialized
INFO - 2023-01-15 08:46:36 --> Language Class Initialized
INFO - 2023-01-15 08:46:36 --> Language Class Initialized
INFO - 2023-01-15 08:46:36 --> Config Class Initialized
INFO - 2023-01-15 08:46:36 --> Loader Class Initialized
INFO - 2023-01-15 08:46:36 --> Helper loaded: url_helper
INFO - 2023-01-15 08:46:36 --> Helper loaded: file_helper
INFO - 2023-01-15 08:46:36 --> Helper loaded: form_helper
INFO - 2023-01-15 08:46:36 --> Helper loaded: my_helper
INFO - 2023-01-15 08:46:36 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:46:36 --> Controller Class Initialized
DEBUG - 2023-01-15 08:46:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:46:37 --> Final output sent to browser
DEBUG - 2023-01-15 08:46:37 --> Total execution time: 1.1027
INFO - 2023-01-15 08:48:06 --> Config Class Initialized
INFO - 2023-01-15 08:48:06 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:48:06 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:48:06 --> Utf8 Class Initialized
INFO - 2023-01-15 08:48:06 --> URI Class Initialized
INFO - 2023-01-15 08:48:06 --> Router Class Initialized
INFO - 2023-01-15 08:48:06 --> Output Class Initialized
INFO - 2023-01-15 08:48:06 --> Security Class Initialized
DEBUG - 2023-01-15 08:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:48:06 --> Input Class Initialized
INFO - 2023-01-15 08:48:06 --> Language Class Initialized
INFO - 2023-01-15 08:48:06 --> Language Class Initialized
INFO - 2023-01-15 08:48:06 --> Config Class Initialized
INFO - 2023-01-15 08:48:06 --> Loader Class Initialized
INFO - 2023-01-15 08:48:06 --> Helper loaded: url_helper
INFO - 2023-01-15 08:48:06 --> Helper loaded: file_helper
INFO - 2023-01-15 08:48:06 --> Helper loaded: form_helper
INFO - 2023-01-15 08:48:06 --> Helper loaded: my_helper
INFO - 2023-01-15 08:48:06 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:48:06 --> Controller Class Initialized
DEBUG - 2023-01-15 08:48:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:48:07 --> Final output sent to browser
DEBUG - 2023-01-15 08:48:07 --> Total execution time: 1.0587
INFO - 2023-01-15 08:48:18 --> Config Class Initialized
INFO - 2023-01-15 08:48:18 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:48:18 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:48:18 --> Utf8 Class Initialized
INFO - 2023-01-15 08:48:18 --> URI Class Initialized
INFO - 2023-01-15 08:48:18 --> Router Class Initialized
INFO - 2023-01-15 08:48:18 --> Output Class Initialized
INFO - 2023-01-15 08:48:18 --> Security Class Initialized
DEBUG - 2023-01-15 08:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:48:18 --> Input Class Initialized
INFO - 2023-01-15 08:48:18 --> Language Class Initialized
INFO - 2023-01-15 08:48:18 --> Language Class Initialized
INFO - 2023-01-15 08:48:18 --> Config Class Initialized
INFO - 2023-01-15 08:48:18 --> Loader Class Initialized
INFO - 2023-01-15 08:48:18 --> Helper loaded: url_helper
INFO - 2023-01-15 08:48:18 --> Helper loaded: file_helper
INFO - 2023-01-15 08:48:18 --> Helper loaded: form_helper
INFO - 2023-01-15 08:48:18 --> Helper loaded: my_helper
INFO - 2023-01-15 08:48:18 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:48:18 --> Controller Class Initialized
DEBUG - 2023-01-15 08:48:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:48:19 --> Final output sent to browser
DEBUG - 2023-01-15 08:48:19 --> Total execution time: 1.0712
INFO - 2023-01-15 08:49:21 --> Config Class Initialized
INFO - 2023-01-15 08:49:21 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:49:21 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:49:21 --> Utf8 Class Initialized
INFO - 2023-01-15 08:49:21 --> URI Class Initialized
INFO - 2023-01-15 08:49:21 --> Router Class Initialized
INFO - 2023-01-15 08:49:21 --> Output Class Initialized
INFO - 2023-01-15 08:49:21 --> Security Class Initialized
DEBUG - 2023-01-15 08:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:49:21 --> Input Class Initialized
INFO - 2023-01-15 08:49:21 --> Language Class Initialized
INFO - 2023-01-15 08:49:21 --> Language Class Initialized
INFO - 2023-01-15 08:49:21 --> Config Class Initialized
INFO - 2023-01-15 08:49:21 --> Loader Class Initialized
INFO - 2023-01-15 08:49:21 --> Helper loaded: url_helper
INFO - 2023-01-15 08:49:21 --> Helper loaded: file_helper
INFO - 2023-01-15 08:49:21 --> Helper loaded: form_helper
INFO - 2023-01-15 08:49:21 --> Helper loaded: my_helper
INFO - 2023-01-15 08:49:21 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:49:21 --> Controller Class Initialized
DEBUG - 2023-01-15 08:49:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:49:22 --> Final output sent to browser
DEBUG - 2023-01-15 08:49:22 --> Total execution time: 1.0362
INFO - 2023-01-15 08:50:20 --> Config Class Initialized
INFO - 2023-01-15 08:50:20 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:50:20 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:50:20 --> Utf8 Class Initialized
INFO - 2023-01-15 08:50:20 --> URI Class Initialized
INFO - 2023-01-15 08:50:20 --> Router Class Initialized
INFO - 2023-01-15 08:50:20 --> Output Class Initialized
INFO - 2023-01-15 08:50:20 --> Security Class Initialized
DEBUG - 2023-01-15 08:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:50:20 --> Input Class Initialized
INFO - 2023-01-15 08:50:20 --> Language Class Initialized
INFO - 2023-01-15 08:50:20 --> Language Class Initialized
INFO - 2023-01-15 08:50:20 --> Config Class Initialized
INFO - 2023-01-15 08:50:20 --> Loader Class Initialized
INFO - 2023-01-15 08:50:20 --> Helper loaded: url_helper
INFO - 2023-01-15 08:50:20 --> Helper loaded: file_helper
INFO - 2023-01-15 08:50:20 --> Helper loaded: form_helper
INFO - 2023-01-15 08:50:20 --> Helper loaded: my_helper
INFO - 2023-01-15 08:50:20 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:50:20 --> Controller Class Initialized
DEBUG - 2023-01-15 08:50:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:50:21 --> Final output sent to browser
DEBUG - 2023-01-15 08:50:21 --> Total execution time: 1.0990
INFO - 2023-01-15 08:50:42 --> Config Class Initialized
INFO - 2023-01-15 08:50:42 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:50:42 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:50:42 --> Utf8 Class Initialized
INFO - 2023-01-15 08:50:42 --> URI Class Initialized
INFO - 2023-01-15 08:50:42 --> Router Class Initialized
INFO - 2023-01-15 08:50:42 --> Output Class Initialized
INFO - 2023-01-15 08:50:42 --> Security Class Initialized
DEBUG - 2023-01-15 08:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:50:42 --> Input Class Initialized
INFO - 2023-01-15 08:50:42 --> Language Class Initialized
INFO - 2023-01-15 08:50:42 --> Language Class Initialized
INFO - 2023-01-15 08:50:42 --> Config Class Initialized
INFO - 2023-01-15 08:50:42 --> Loader Class Initialized
INFO - 2023-01-15 08:50:42 --> Helper loaded: url_helper
INFO - 2023-01-15 08:50:42 --> Helper loaded: file_helper
INFO - 2023-01-15 08:50:42 --> Helper loaded: form_helper
INFO - 2023-01-15 08:50:42 --> Helper loaded: my_helper
INFO - 2023-01-15 08:50:42 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:50:42 --> Controller Class Initialized
DEBUG - 2023-01-15 08:50:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:50:43 --> Final output sent to browser
DEBUG - 2023-01-15 08:50:43 --> Total execution time: 1.0260
INFO - 2023-01-15 08:54:08 --> Config Class Initialized
INFO - 2023-01-15 08:54:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:54:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:54:08 --> Utf8 Class Initialized
INFO - 2023-01-15 08:54:08 --> URI Class Initialized
INFO - 2023-01-15 08:54:08 --> Router Class Initialized
INFO - 2023-01-15 08:54:08 --> Output Class Initialized
INFO - 2023-01-15 08:54:08 --> Security Class Initialized
DEBUG - 2023-01-15 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:54:08 --> Input Class Initialized
INFO - 2023-01-15 08:54:08 --> Language Class Initialized
INFO - 2023-01-15 08:54:08 --> Language Class Initialized
INFO - 2023-01-15 08:54:08 --> Config Class Initialized
INFO - 2023-01-15 08:54:08 --> Loader Class Initialized
INFO - 2023-01-15 08:54:08 --> Helper loaded: url_helper
INFO - 2023-01-15 08:54:08 --> Helper loaded: file_helper
INFO - 2023-01-15 08:54:08 --> Helper loaded: form_helper
INFO - 2023-01-15 08:54:08 --> Helper loaded: my_helper
INFO - 2023-01-15 08:54:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:54:08 --> Controller Class Initialized
DEBUG - 2023-01-15 08:54:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:54:09 --> Final output sent to browser
DEBUG - 2023-01-15 08:54:09 --> Total execution time: 1.0433
INFO - 2023-01-15 08:54:24 --> Config Class Initialized
INFO - 2023-01-15 08:54:24 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:54:24 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:54:24 --> Utf8 Class Initialized
INFO - 2023-01-15 08:54:24 --> URI Class Initialized
INFO - 2023-01-15 08:54:24 --> Router Class Initialized
INFO - 2023-01-15 08:54:24 --> Output Class Initialized
INFO - 2023-01-15 08:54:24 --> Security Class Initialized
DEBUG - 2023-01-15 08:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:54:24 --> Input Class Initialized
INFO - 2023-01-15 08:54:24 --> Language Class Initialized
INFO - 2023-01-15 08:54:24 --> Language Class Initialized
INFO - 2023-01-15 08:54:24 --> Config Class Initialized
INFO - 2023-01-15 08:54:24 --> Loader Class Initialized
INFO - 2023-01-15 08:54:24 --> Helper loaded: url_helper
INFO - 2023-01-15 08:54:24 --> Helper loaded: file_helper
INFO - 2023-01-15 08:54:24 --> Helper loaded: form_helper
INFO - 2023-01-15 08:54:24 --> Helper loaded: my_helper
INFO - 2023-01-15 08:54:24 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:54:24 --> Controller Class Initialized
DEBUG - 2023-01-15 08:54:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:54:25 --> Final output sent to browser
DEBUG - 2023-01-15 08:54:25 --> Total execution time: 1.0719
INFO - 2023-01-15 08:54:57 --> Config Class Initialized
INFO - 2023-01-15 08:54:57 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:54:57 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:54:57 --> Utf8 Class Initialized
INFO - 2023-01-15 08:54:57 --> URI Class Initialized
INFO - 2023-01-15 08:54:57 --> Router Class Initialized
INFO - 2023-01-15 08:54:57 --> Output Class Initialized
INFO - 2023-01-15 08:54:57 --> Security Class Initialized
DEBUG - 2023-01-15 08:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:54:57 --> Input Class Initialized
INFO - 2023-01-15 08:54:57 --> Language Class Initialized
INFO - 2023-01-15 08:54:57 --> Language Class Initialized
INFO - 2023-01-15 08:54:57 --> Config Class Initialized
INFO - 2023-01-15 08:54:57 --> Loader Class Initialized
INFO - 2023-01-15 08:54:57 --> Helper loaded: url_helper
INFO - 2023-01-15 08:54:57 --> Helper loaded: file_helper
INFO - 2023-01-15 08:54:57 --> Helper loaded: form_helper
INFO - 2023-01-15 08:54:57 --> Helper loaded: my_helper
INFO - 2023-01-15 08:54:57 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:54:57 --> Controller Class Initialized
DEBUG - 2023-01-15 08:54:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:54:58 --> Final output sent to browser
DEBUG - 2023-01-15 08:54:58 --> Total execution time: 1.0807
INFO - 2023-01-15 08:55:15 --> Config Class Initialized
INFO - 2023-01-15 08:55:15 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:55:15 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:55:15 --> Utf8 Class Initialized
INFO - 2023-01-15 08:55:15 --> URI Class Initialized
INFO - 2023-01-15 08:55:15 --> Router Class Initialized
INFO - 2023-01-15 08:55:15 --> Output Class Initialized
INFO - 2023-01-15 08:55:15 --> Security Class Initialized
DEBUG - 2023-01-15 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:55:15 --> Input Class Initialized
INFO - 2023-01-15 08:55:15 --> Language Class Initialized
INFO - 2023-01-15 08:55:15 --> Language Class Initialized
INFO - 2023-01-15 08:55:15 --> Config Class Initialized
INFO - 2023-01-15 08:55:15 --> Loader Class Initialized
INFO - 2023-01-15 08:55:15 --> Helper loaded: url_helper
INFO - 2023-01-15 08:55:15 --> Helper loaded: file_helper
INFO - 2023-01-15 08:55:15 --> Helper loaded: form_helper
INFO - 2023-01-15 08:55:16 --> Helper loaded: my_helper
INFO - 2023-01-15 08:55:16 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:55:16 --> Controller Class Initialized
DEBUG - 2023-01-15 08:55:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:55:17 --> Final output sent to browser
DEBUG - 2023-01-15 08:55:17 --> Total execution time: 1.0959
INFO - 2023-01-15 08:55:58 --> Config Class Initialized
INFO - 2023-01-15 08:55:58 --> Hooks Class Initialized
DEBUG - 2023-01-15 08:55:58 --> UTF-8 Support Enabled
INFO - 2023-01-15 08:55:58 --> Utf8 Class Initialized
INFO - 2023-01-15 08:55:58 --> URI Class Initialized
INFO - 2023-01-15 08:55:58 --> Router Class Initialized
INFO - 2023-01-15 08:55:58 --> Output Class Initialized
INFO - 2023-01-15 08:55:58 --> Security Class Initialized
DEBUG - 2023-01-15 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 08:55:58 --> Input Class Initialized
INFO - 2023-01-15 08:55:58 --> Language Class Initialized
INFO - 2023-01-15 08:55:58 --> Language Class Initialized
INFO - 2023-01-15 08:55:58 --> Config Class Initialized
INFO - 2023-01-15 08:55:58 --> Loader Class Initialized
INFO - 2023-01-15 08:55:58 --> Helper loaded: url_helper
INFO - 2023-01-15 08:55:58 --> Helper loaded: file_helper
INFO - 2023-01-15 08:55:58 --> Helper loaded: form_helper
INFO - 2023-01-15 08:55:58 --> Helper loaded: my_helper
INFO - 2023-01-15 08:55:58 --> Database Driver Class Initialized
DEBUG - 2023-01-15 08:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 08:55:58 --> Controller Class Initialized
DEBUG - 2023-01-15 08:55:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 08:55:59 --> Final output sent to browser
DEBUG - 2023-01-15 08:55:59 --> Total execution time: 1.0931
INFO - 2023-01-15 12:06:11 --> Config Class Initialized
INFO - 2023-01-15 12:06:11 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:06:11 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:06:11 --> Utf8 Class Initialized
INFO - 2023-01-15 12:06:11 --> URI Class Initialized
INFO - 2023-01-15 12:06:11 --> Router Class Initialized
INFO - 2023-01-15 12:06:11 --> Output Class Initialized
INFO - 2023-01-15 12:06:11 --> Security Class Initialized
DEBUG - 2023-01-15 12:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:06:11 --> Input Class Initialized
INFO - 2023-01-15 12:06:11 --> Language Class Initialized
INFO - 2023-01-15 12:06:11 --> Language Class Initialized
INFO - 2023-01-15 12:06:11 --> Config Class Initialized
INFO - 2023-01-15 12:06:11 --> Loader Class Initialized
INFO - 2023-01-15 12:06:11 --> Helper loaded: url_helper
INFO - 2023-01-15 12:06:11 --> Helper loaded: file_helper
INFO - 2023-01-15 12:06:11 --> Helper loaded: form_helper
INFO - 2023-01-15 12:06:11 --> Helper loaded: my_helper
INFO - 2023-01-15 12:06:11 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:06:11 --> Controller Class Initialized
DEBUG - 2023-01-15 12:06:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:06:13 --> Final output sent to browser
DEBUG - 2023-01-15 12:06:13 --> Total execution time: 1.4314
INFO - 2023-01-15 12:09:54 --> Config Class Initialized
INFO - 2023-01-15 12:09:54 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:09:54 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:09:54 --> Utf8 Class Initialized
INFO - 2023-01-15 12:09:54 --> URI Class Initialized
INFO - 2023-01-15 12:09:54 --> Router Class Initialized
INFO - 2023-01-15 12:09:54 --> Output Class Initialized
INFO - 2023-01-15 12:09:54 --> Security Class Initialized
DEBUG - 2023-01-15 12:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:09:54 --> Input Class Initialized
INFO - 2023-01-15 12:09:54 --> Language Class Initialized
INFO - 2023-01-15 12:09:54 --> Language Class Initialized
INFO - 2023-01-15 12:09:54 --> Config Class Initialized
INFO - 2023-01-15 12:09:54 --> Loader Class Initialized
INFO - 2023-01-15 12:09:54 --> Helper loaded: url_helper
INFO - 2023-01-15 12:09:54 --> Helper loaded: file_helper
INFO - 2023-01-15 12:09:54 --> Helper loaded: form_helper
INFO - 2023-01-15 12:09:54 --> Helper loaded: my_helper
INFO - 2023-01-15 12:09:54 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:09:54 --> Controller Class Initialized
DEBUG - 2023-01-15 12:09:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:09:55 --> Final output sent to browser
DEBUG - 2023-01-15 12:09:55 --> Total execution time: 1.4378
INFO - 2023-01-15 12:11:12 --> Config Class Initialized
INFO - 2023-01-15 12:11:12 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:11:12 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:11:12 --> Utf8 Class Initialized
INFO - 2023-01-15 12:11:12 --> URI Class Initialized
INFO - 2023-01-15 12:11:12 --> Router Class Initialized
INFO - 2023-01-15 12:11:12 --> Output Class Initialized
INFO - 2023-01-15 12:11:12 --> Security Class Initialized
DEBUG - 2023-01-15 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:11:12 --> Input Class Initialized
INFO - 2023-01-15 12:11:12 --> Language Class Initialized
INFO - 2023-01-15 12:11:12 --> Language Class Initialized
INFO - 2023-01-15 12:11:12 --> Config Class Initialized
INFO - 2023-01-15 12:11:12 --> Loader Class Initialized
INFO - 2023-01-15 12:11:12 --> Helper loaded: url_helper
INFO - 2023-01-15 12:11:12 --> Helper loaded: file_helper
INFO - 2023-01-15 12:11:12 --> Helper loaded: form_helper
INFO - 2023-01-15 12:11:12 --> Helper loaded: my_helper
INFO - 2023-01-15 12:11:12 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:11:12 --> Controller Class Initialized
DEBUG - 2023-01-15 12:11:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:11:13 --> Final output sent to browser
DEBUG - 2023-01-15 12:11:13 --> Total execution time: 1.4615
INFO - 2023-01-15 12:11:46 --> Config Class Initialized
INFO - 2023-01-15 12:11:46 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:11:46 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:11:46 --> Utf8 Class Initialized
INFO - 2023-01-15 12:11:46 --> URI Class Initialized
INFO - 2023-01-15 12:11:46 --> Router Class Initialized
INFO - 2023-01-15 12:11:46 --> Output Class Initialized
INFO - 2023-01-15 12:11:46 --> Security Class Initialized
DEBUG - 2023-01-15 12:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:11:46 --> Input Class Initialized
INFO - 2023-01-15 12:11:46 --> Language Class Initialized
INFO - 2023-01-15 12:11:46 --> Language Class Initialized
INFO - 2023-01-15 12:11:46 --> Config Class Initialized
INFO - 2023-01-15 12:11:46 --> Loader Class Initialized
INFO - 2023-01-15 12:11:46 --> Helper loaded: url_helper
INFO - 2023-01-15 12:11:46 --> Helper loaded: file_helper
INFO - 2023-01-15 12:11:46 --> Helper loaded: form_helper
INFO - 2023-01-15 12:11:46 --> Helper loaded: my_helper
INFO - 2023-01-15 12:11:46 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:11:46 --> Controller Class Initialized
DEBUG - 2023-01-15 12:11:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:11:47 --> Final output sent to browser
DEBUG - 2023-01-15 12:11:47 --> Total execution time: 1.4993
INFO - 2023-01-15 12:12:42 --> Config Class Initialized
INFO - 2023-01-15 12:12:42 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:12:42 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:12:42 --> Utf8 Class Initialized
INFO - 2023-01-15 12:12:42 --> URI Class Initialized
INFO - 2023-01-15 12:12:42 --> Router Class Initialized
INFO - 2023-01-15 12:12:42 --> Output Class Initialized
INFO - 2023-01-15 12:12:42 --> Security Class Initialized
DEBUG - 2023-01-15 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:12:42 --> Input Class Initialized
INFO - 2023-01-15 12:12:42 --> Language Class Initialized
INFO - 2023-01-15 12:12:42 --> Language Class Initialized
INFO - 2023-01-15 12:12:42 --> Config Class Initialized
INFO - 2023-01-15 12:12:42 --> Loader Class Initialized
INFO - 2023-01-15 12:12:42 --> Helper loaded: url_helper
INFO - 2023-01-15 12:12:42 --> Helper loaded: file_helper
INFO - 2023-01-15 12:12:42 --> Helper loaded: form_helper
INFO - 2023-01-15 12:12:42 --> Helper loaded: my_helper
INFO - 2023-01-15 12:12:42 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:12:42 --> Controller Class Initialized
DEBUG - 2023-01-15 12:12:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:12:43 --> Final output sent to browser
DEBUG - 2023-01-15 12:12:43 --> Total execution time: 1.3442
INFO - 2023-01-15 12:14:36 --> Config Class Initialized
INFO - 2023-01-15 12:14:36 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:14:36 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:14:36 --> Utf8 Class Initialized
INFO - 2023-01-15 12:14:36 --> URI Class Initialized
INFO - 2023-01-15 12:14:36 --> Router Class Initialized
INFO - 2023-01-15 12:14:36 --> Output Class Initialized
INFO - 2023-01-15 12:14:36 --> Security Class Initialized
DEBUG - 2023-01-15 12:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:14:36 --> Input Class Initialized
INFO - 2023-01-15 12:14:36 --> Language Class Initialized
INFO - 2023-01-15 12:14:36 --> Language Class Initialized
INFO - 2023-01-15 12:14:36 --> Config Class Initialized
INFO - 2023-01-15 12:14:36 --> Loader Class Initialized
INFO - 2023-01-15 12:14:36 --> Helper loaded: url_helper
INFO - 2023-01-15 12:14:36 --> Helper loaded: file_helper
INFO - 2023-01-15 12:14:36 --> Helper loaded: form_helper
INFO - 2023-01-15 12:14:36 --> Helper loaded: my_helper
INFO - 2023-01-15 12:14:36 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:14:36 --> Controller Class Initialized
DEBUG - 2023-01-15 12:14:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:14:37 --> Final output sent to browser
DEBUG - 2023-01-15 12:14:37 --> Total execution time: 1.3591
INFO - 2023-01-15 12:15:37 --> Config Class Initialized
INFO - 2023-01-15 12:15:37 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:15:37 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:15:37 --> Utf8 Class Initialized
INFO - 2023-01-15 12:15:37 --> URI Class Initialized
INFO - 2023-01-15 12:15:37 --> Router Class Initialized
INFO - 2023-01-15 12:15:37 --> Output Class Initialized
INFO - 2023-01-15 12:15:37 --> Security Class Initialized
DEBUG - 2023-01-15 12:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:15:37 --> Input Class Initialized
INFO - 2023-01-15 12:15:37 --> Language Class Initialized
INFO - 2023-01-15 12:15:37 --> Language Class Initialized
INFO - 2023-01-15 12:15:37 --> Config Class Initialized
INFO - 2023-01-15 12:15:37 --> Loader Class Initialized
INFO - 2023-01-15 12:15:37 --> Helper loaded: url_helper
INFO - 2023-01-15 12:15:37 --> Helper loaded: file_helper
INFO - 2023-01-15 12:15:37 --> Helper loaded: form_helper
INFO - 2023-01-15 12:15:37 --> Helper loaded: my_helper
INFO - 2023-01-15 12:15:37 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:15:37 --> Controller Class Initialized
DEBUG - 2023-01-15 12:15:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:15:38 --> Final output sent to browser
DEBUG - 2023-01-15 12:15:38 --> Total execution time: 1.4744
INFO - 2023-01-15 12:16:41 --> Config Class Initialized
INFO - 2023-01-15 12:16:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:16:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:16:41 --> Utf8 Class Initialized
INFO - 2023-01-15 12:16:41 --> URI Class Initialized
INFO - 2023-01-15 12:16:41 --> Router Class Initialized
INFO - 2023-01-15 12:16:42 --> Output Class Initialized
INFO - 2023-01-15 12:16:42 --> Security Class Initialized
DEBUG - 2023-01-15 12:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:16:42 --> Input Class Initialized
INFO - 2023-01-15 12:16:42 --> Language Class Initialized
INFO - 2023-01-15 12:16:42 --> Language Class Initialized
INFO - 2023-01-15 12:16:42 --> Config Class Initialized
INFO - 2023-01-15 12:16:42 --> Loader Class Initialized
INFO - 2023-01-15 12:16:42 --> Helper loaded: url_helper
INFO - 2023-01-15 12:16:42 --> Helper loaded: file_helper
INFO - 2023-01-15 12:16:42 --> Helper loaded: form_helper
INFO - 2023-01-15 12:16:42 --> Helper loaded: my_helper
INFO - 2023-01-15 12:16:42 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:16:42 --> Controller Class Initialized
DEBUG - 2023-01-15 12:16:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:16:43 --> Final output sent to browser
DEBUG - 2023-01-15 12:16:43 --> Total execution time: 1.3999
INFO - 2023-01-15 12:41:47 --> Config Class Initialized
INFO - 2023-01-15 12:41:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:41:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:41:47 --> Utf8 Class Initialized
INFO - 2023-01-15 12:41:47 --> URI Class Initialized
INFO - 2023-01-15 12:41:47 --> Router Class Initialized
INFO - 2023-01-15 12:41:47 --> Output Class Initialized
INFO - 2023-01-15 12:41:47 --> Security Class Initialized
DEBUG - 2023-01-15 12:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:41:47 --> Input Class Initialized
INFO - 2023-01-15 12:41:47 --> Language Class Initialized
INFO - 2023-01-15 12:41:47 --> Language Class Initialized
INFO - 2023-01-15 12:41:47 --> Config Class Initialized
INFO - 2023-01-15 12:41:47 --> Loader Class Initialized
INFO - 2023-01-15 12:41:47 --> Helper loaded: url_helper
INFO - 2023-01-15 12:41:47 --> Helper loaded: file_helper
INFO - 2023-01-15 12:41:47 --> Helper loaded: form_helper
INFO - 2023-01-15 12:41:47 --> Helper loaded: my_helper
INFO - 2023-01-15 12:41:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:41:47 --> Controller Class Initialized
ERROR - 2023-01-15 12:41:47 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1118
ERROR - 2023-01-15 12:41:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1118
ERROR - 2023-01-15 12:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1321
ERROR - 2023-01-15 12:41:47 --> Severity: Notice --> Undefined index: nilai C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1326
ERROR - 2023-01-15 12:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1326
DEBUG - 2023-01-15 12:41:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:41:49 --> Final output sent to browser
DEBUG - 2023-01-15 12:41:49 --> Total execution time: 1.5077
INFO - 2023-01-15 12:42:05 --> Config Class Initialized
INFO - 2023-01-15 12:42:05 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:42:05 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:42:05 --> Utf8 Class Initialized
INFO - 2023-01-15 12:42:05 --> URI Class Initialized
INFO - 2023-01-15 12:42:05 --> Router Class Initialized
INFO - 2023-01-15 12:42:05 --> Output Class Initialized
INFO - 2023-01-15 12:42:05 --> Security Class Initialized
DEBUG - 2023-01-15 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:42:05 --> Input Class Initialized
INFO - 2023-01-15 12:42:05 --> Language Class Initialized
INFO - 2023-01-15 12:42:05 --> Language Class Initialized
INFO - 2023-01-15 12:42:05 --> Config Class Initialized
INFO - 2023-01-15 12:42:05 --> Loader Class Initialized
INFO - 2023-01-15 12:42:05 --> Helper loaded: url_helper
INFO - 2023-01-15 12:42:05 --> Helper loaded: file_helper
INFO - 2023-01-15 12:42:05 --> Helper loaded: form_helper
INFO - 2023-01-15 12:42:05 --> Helper loaded: my_helper
INFO - 2023-01-15 12:42:05 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:42:05 --> Controller Class Initialized
ERROR - 2023-01-15 12:42:05 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1118
ERROR - 2023-01-15 12:42:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1118
ERROR - 2023-01-15 12:42:05 --> Severity: Notice --> Undefined index: nilai C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1326
ERROR - 2023-01-15 12:42:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1326
DEBUG - 2023-01-15 12:42:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:42:07 --> Final output sent to browser
DEBUG - 2023-01-15 12:42:07 --> Total execution time: 1.4671
INFO - 2023-01-15 12:50:26 --> Config Class Initialized
INFO - 2023-01-15 12:50:26 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:50:26 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:50:26 --> Utf8 Class Initialized
INFO - 2023-01-15 12:50:26 --> URI Class Initialized
INFO - 2023-01-15 12:50:26 --> Router Class Initialized
INFO - 2023-01-15 12:50:26 --> Output Class Initialized
INFO - 2023-01-15 12:50:26 --> Security Class Initialized
DEBUG - 2023-01-15 12:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:50:26 --> Input Class Initialized
INFO - 2023-01-15 12:50:26 --> Language Class Initialized
INFO - 2023-01-15 12:50:26 --> Language Class Initialized
INFO - 2023-01-15 12:50:26 --> Config Class Initialized
INFO - 2023-01-15 12:50:26 --> Loader Class Initialized
INFO - 2023-01-15 12:50:26 --> Helper loaded: url_helper
INFO - 2023-01-15 12:50:26 --> Helper loaded: file_helper
INFO - 2023-01-15 12:50:26 --> Helper loaded: form_helper
INFO - 2023-01-15 12:50:26 --> Helper loaded: my_helper
INFO - 2023-01-15 12:50:26 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:50:26 --> Controller Class Initialized
DEBUG - 2023-01-15 12:50:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:50:27 --> Final output sent to browser
DEBUG - 2023-01-15 12:50:27 --> Total execution time: 1.4263
INFO - 2023-01-15 12:52:00 --> Config Class Initialized
INFO - 2023-01-15 12:52:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:52:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:52:00 --> Utf8 Class Initialized
INFO - 2023-01-15 12:52:00 --> URI Class Initialized
INFO - 2023-01-15 12:52:00 --> Router Class Initialized
INFO - 2023-01-15 12:52:00 --> Output Class Initialized
INFO - 2023-01-15 12:52:00 --> Security Class Initialized
DEBUG - 2023-01-15 12:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:52:00 --> Input Class Initialized
INFO - 2023-01-15 12:52:00 --> Language Class Initialized
INFO - 2023-01-15 12:52:00 --> Language Class Initialized
INFO - 2023-01-15 12:52:00 --> Config Class Initialized
INFO - 2023-01-15 12:52:00 --> Loader Class Initialized
INFO - 2023-01-15 12:52:00 --> Helper loaded: url_helper
INFO - 2023-01-15 12:52:00 --> Helper loaded: file_helper
INFO - 2023-01-15 12:52:00 --> Helper loaded: form_helper
INFO - 2023-01-15 12:52:00 --> Helper loaded: my_helper
INFO - 2023-01-15 12:52:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:52:01 --> Controller Class Initialized
DEBUG - 2023-01-15 12:52:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:52:02 --> Final output sent to browser
DEBUG - 2023-01-15 12:52:02 --> Total execution time: 1.4306
INFO - 2023-01-15 12:52:30 --> Config Class Initialized
INFO - 2023-01-15 12:52:30 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:52:30 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:52:30 --> Utf8 Class Initialized
INFO - 2023-01-15 12:52:30 --> URI Class Initialized
INFO - 2023-01-15 12:52:30 --> Router Class Initialized
INFO - 2023-01-15 12:52:30 --> Output Class Initialized
INFO - 2023-01-15 12:52:30 --> Security Class Initialized
DEBUG - 2023-01-15 12:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:52:30 --> Input Class Initialized
INFO - 2023-01-15 12:52:30 --> Language Class Initialized
INFO - 2023-01-15 12:52:30 --> Language Class Initialized
INFO - 2023-01-15 12:52:30 --> Config Class Initialized
INFO - 2023-01-15 12:52:30 --> Loader Class Initialized
INFO - 2023-01-15 12:52:30 --> Helper loaded: url_helper
INFO - 2023-01-15 12:52:30 --> Helper loaded: file_helper
INFO - 2023-01-15 12:52:30 --> Helper loaded: form_helper
INFO - 2023-01-15 12:52:30 --> Helper loaded: my_helper
INFO - 2023-01-15 12:52:30 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:52:30 --> Controller Class Initialized
DEBUG - 2023-01-15 12:52:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:52:32 --> Final output sent to browser
DEBUG - 2023-01-15 12:52:32 --> Total execution time: 1.4240
INFO - 2023-01-15 12:52:53 --> Config Class Initialized
INFO - 2023-01-15 12:52:53 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:52:53 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:52:53 --> Utf8 Class Initialized
INFO - 2023-01-15 12:52:53 --> URI Class Initialized
INFO - 2023-01-15 12:52:53 --> Router Class Initialized
INFO - 2023-01-15 12:52:53 --> Output Class Initialized
INFO - 2023-01-15 12:52:53 --> Security Class Initialized
DEBUG - 2023-01-15 12:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:52:53 --> Input Class Initialized
INFO - 2023-01-15 12:52:53 --> Language Class Initialized
INFO - 2023-01-15 12:52:53 --> Language Class Initialized
INFO - 2023-01-15 12:52:53 --> Config Class Initialized
INFO - 2023-01-15 12:52:53 --> Loader Class Initialized
INFO - 2023-01-15 12:52:53 --> Helper loaded: url_helper
INFO - 2023-01-15 12:52:53 --> Helper loaded: file_helper
INFO - 2023-01-15 12:52:53 --> Helper loaded: form_helper
INFO - 2023-01-15 12:52:53 --> Helper loaded: my_helper
INFO - 2023-01-15 12:52:53 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:52:53 --> Controller Class Initialized
DEBUG - 2023-01-15 12:52:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:52:54 --> Final output sent to browser
DEBUG - 2023-01-15 12:52:54 --> Total execution time: 1.4028
INFO - 2023-01-15 12:53:23 --> Config Class Initialized
INFO - 2023-01-15 12:53:23 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:53:23 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:53:23 --> Utf8 Class Initialized
INFO - 2023-01-15 12:53:23 --> URI Class Initialized
INFO - 2023-01-15 12:53:23 --> Router Class Initialized
INFO - 2023-01-15 12:53:23 --> Output Class Initialized
INFO - 2023-01-15 12:53:23 --> Security Class Initialized
DEBUG - 2023-01-15 12:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:53:23 --> Input Class Initialized
INFO - 2023-01-15 12:53:23 --> Language Class Initialized
INFO - 2023-01-15 12:53:23 --> Language Class Initialized
INFO - 2023-01-15 12:53:23 --> Config Class Initialized
INFO - 2023-01-15 12:53:23 --> Loader Class Initialized
INFO - 2023-01-15 12:53:23 --> Helper loaded: url_helper
INFO - 2023-01-15 12:53:23 --> Helper loaded: file_helper
INFO - 2023-01-15 12:53:23 --> Helper loaded: form_helper
INFO - 2023-01-15 12:53:23 --> Helper loaded: my_helper
INFO - 2023-01-15 12:53:23 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:53:23 --> Controller Class Initialized
DEBUG - 2023-01-15 12:53:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:53:24 --> Final output sent to browser
DEBUG - 2023-01-15 12:53:24 --> Total execution time: 1.4172
INFO - 2023-01-15 12:53:51 --> Config Class Initialized
INFO - 2023-01-15 12:53:51 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:53:51 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:53:51 --> Utf8 Class Initialized
INFO - 2023-01-15 12:53:51 --> URI Class Initialized
INFO - 2023-01-15 12:53:51 --> Router Class Initialized
INFO - 2023-01-15 12:53:51 --> Output Class Initialized
INFO - 2023-01-15 12:53:51 --> Security Class Initialized
DEBUG - 2023-01-15 12:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:53:51 --> Input Class Initialized
INFO - 2023-01-15 12:53:51 --> Language Class Initialized
INFO - 2023-01-15 12:53:51 --> Language Class Initialized
INFO - 2023-01-15 12:53:51 --> Config Class Initialized
INFO - 2023-01-15 12:53:51 --> Loader Class Initialized
INFO - 2023-01-15 12:53:51 --> Helper loaded: url_helper
INFO - 2023-01-15 12:53:51 --> Helper loaded: file_helper
INFO - 2023-01-15 12:53:51 --> Helper loaded: form_helper
INFO - 2023-01-15 12:53:51 --> Helper loaded: my_helper
INFO - 2023-01-15 12:53:51 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:53:51 --> Controller Class Initialized
DEBUG - 2023-01-15 12:53:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:53:52 --> Final output sent to browser
DEBUG - 2023-01-15 12:53:52 --> Total execution time: 1.4589
INFO - 2023-01-15 12:53:57 --> Config Class Initialized
INFO - 2023-01-15 12:53:57 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:53:57 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:53:57 --> Utf8 Class Initialized
INFO - 2023-01-15 12:53:57 --> URI Class Initialized
INFO - 2023-01-15 12:53:57 --> Router Class Initialized
INFO - 2023-01-15 12:53:57 --> Output Class Initialized
INFO - 2023-01-15 12:53:57 --> Security Class Initialized
DEBUG - 2023-01-15 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:53:57 --> Input Class Initialized
INFO - 2023-01-15 12:53:57 --> Language Class Initialized
INFO - 2023-01-15 12:53:57 --> Language Class Initialized
INFO - 2023-01-15 12:53:57 --> Config Class Initialized
INFO - 2023-01-15 12:53:57 --> Loader Class Initialized
INFO - 2023-01-15 12:53:57 --> Helper loaded: url_helper
INFO - 2023-01-15 12:53:57 --> Helper loaded: file_helper
INFO - 2023-01-15 12:53:57 --> Helper loaded: form_helper
INFO - 2023-01-15 12:53:57 --> Helper loaded: my_helper
INFO - 2023-01-15 12:53:57 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:53:57 --> Controller Class Initialized
INFO - 2023-01-15 12:53:57 --> Config Class Initialized
INFO - 2023-01-15 12:53:57 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:53:57 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:53:57 --> Utf8 Class Initialized
INFO - 2023-01-15 12:53:57 --> URI Class Initialized
INFO - 2023-01-15 12:53:57 --> Router Class Initialized
INFO - 2023-01-15 12:53:57 --> Output Class Initialized
INFO - 2023-01-15 12:53:57 --> Security Class Initialized
DEBUG - 2023-01-15 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:53:57 --> Input Class Initialized
INFO - 2023-01-15 12:53:57 --> Language Class Initialized
INFO - 2023-01-15 12:53:57 --> Language Class Initialized
INFO - 2023-01-15 12:53:57 --> Config Class Initialized
INFO - 2023-01-15 12:53:57 --> Loader Class Initialized
INFO - 2023-01-15 12:53:57 --> Helper loaded: url_helper
INFO - 2023-01-15 12:53:57 --> Helper loaded: file_helper
INFO - 2023-01-15 12:53:57 --> Helper loaded: form_helper
INFO - 2023-01-15 12:53:57 --> Helper loaded: my_helper
INFO - 2023-01-15 12:53:57 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:53:57 --> Controller Class Initialized
DEBUG - 2023-01-15 12:53:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-15 12:53:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 12:53:57 --> Final output sent to browser
DEBUG - 2023-01-15 12:53:57 --> Total execution time: 0.0747
INFO - 2023-01-15 12:54:01 --> Config Class Initialized
INFO - 2023-01-15 12:54:01 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:01 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:01 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:01 --> URI Class Initialized
INFO - 2023-01-15 12:54:01 --> Router Class Initialized
INFO - 2023-01-15 12:54:01 --> Output Class Initialized
INFO - 2023-01-15 12:54:01 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:01 --> Input Class Initialized
INFO - 2023-01-15 12:54:01 --> Language Class Initialized
INFO - 2023-01-15 12:54:01 --> Language Class Initialized
INFO - 2023-01-15 12:54:01 --> Config Class Initialized
INFO - 2023-01-15 12:54:01 --> Loader Class Initialized
INFO - 2023-01-15 12:54:01 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:01 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:01 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:01 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:01 --> Controller Class Initialized
INFO - 2023-01-15 12:54:01 --> Helper loaded: cookie_helper
INFO - 2023-01-15 12:54:01 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:01 --> Total execution time: 0.0800
INFO - 2023-01-15 12:54:01 --> Config Class Initialized
INFO - 2023-01-15 12:54:01 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:01 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:01 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:01 --> URI Class Initialized
INFO - 2023-01-15 12:54:01 --> Router Class Initialized
INFO - 2023-01-15 12:54:01 --> Output Class Initialized
INFO - 2023-01-15 12:54:01 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:01 --> Input Class Initialized
INFO - 2023-01-15 12:54:01 --> Language Class Initialized
INFO - 2023-01-15 12:54:01 --> Language Class Initialized
INFO - 2023-01-15 12:54:01 --> Config Class Initialized
INFO - 2023-01-15 12:54:01 --> Loader Class Initialized
INFO - 2023-01-15 12:54:01 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:01 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:01 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:01 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:01 --> Controller Class Initialized
DEBUG - 2023-01-15 12:54:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-15 12:54:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 12:54:01 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:01 --> Total execution time: 0.0438
INFO - 2023-01-15 12:54:03 --> Config Class Initialized
INFO - 2023-01-15 12:54:03 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:03 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:03 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:03 --> URI Class Initialized
INFO - 2023-01-15 12:54:03 --> Router Class Initialized
INFO - 2023-01-15 12:54:03 --> Output Class Initialized
INFO - 2023-01-15 12:54:03 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:03 --> Input Class Initialized
INFO - 2023-01-15 12:54:03 --> Language Class Initialized
INFO - 2023-01-15 12:54:03 --> Language Class Initialized
INFO - 2023-01-15 12:54:03 --> Config Class Initialized
INFO - 2023-01-15 12:54:03 --> Loader Class Initialized
INFO - 2023-01-15 12:54:03 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:03 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:03 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:03 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:03 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:03 --> Controller Class Initialized
DEBUG - 2023-01-15 12:54:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 12:54:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 12:54:03 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:03 --> Total execution time: 0.0853
INFO - 2023-01-15 12:54:06 --> Config Class Initialized
INFO - 2023-01-15 12:54:06 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:06 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:06 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:06 --> URI Class Initialized
INFO - 2023-01-15 12:54:06 --> Router Class Initialized
INFO - 2023-01-15 12:54:06 --> Output Class Initialized
INFO - 2023-01-15 12:54:06 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:06 --> Input Class Initialized
INFO - 2023-01-15 12:54:06 --> Language Class Initialized
INFO - 2023-01-15 12:54:06 --> Language Class Initialized
INFO - 2023-01-15 12:54:06 --> Config Class Initialized
INFO - 2023-01-15 12:54:06 --> Loader Class Initialized
INFO - 2023-01-15 12:54:06 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:06 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:06 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:06 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:06 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:06 --> Controller Class Initialized
DEBUG - 2023-01-15 12:54:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 12:54:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 12:54:06 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:06 --> Total execution time: 0.0769
INFO - 2023-01-15 12:54:06 --> Config Class Initialized
INFO - 2023-01-15 12:54:06 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:06 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:06 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:06 --> URI Class Initialized
INFO - 2023-01-15 12:54:06 --> Router Class Initialized
INFO - 2023-01-15 12:54:06 --> Output Class Initialized
INFO - 2023-01-15 12:54:06 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:06 --> Input Class Initialized
INFO - 2023-01-15 12:54:06 --> Language Class Initialized
INFO - 2023-01-15 12:54:06 --> Language Class Initialized
INFO - 2023-01-15 12:54:06 --> Config Class Initialized
INFO - 2023-01-15 12:54:06 --> Loader Class Initialized
INFO - 2023-01-15 12:54:06 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:06 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:06 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:06 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:06 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:06 --> Controller Class Initialized
INFO - 2023-01-15 12:54:08 --> Config Class Initialized
INFO - 2023-01-15 12:54:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:08 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:08 --> URI Class Initialized
INFO - 2023-01-15 12:54:08 --> Router Class Initialized
INFO - 2023-01-15 12:54:08 --> Output Class Initialized
INFO - 2023-01-15 12:54:08 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:08 --> Input Class Initialized
INFO - 2023-01-15 12:54:08 --> Language Class Initialized
INFO - 2023-01-15 12:54:08 --> Language Class Initialized
INFO - 2023-01-15 12:54:08 --> Config Class Initialized
INFO - 2023-01-15 12:54:08 --> Loader Class Initialized
INFO - 2023-01-15 12:54:08 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:08 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:08 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:08 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:08 --> Controller Class Initialized
INFO - 2023-01-15 12:54:08 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:08 --> Total execution time: 0.0395
INFO - 2023-01-15 12:54:13 --> Config Class Initialized
INFO - 2023-01-15 12:54:13 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:13 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:13 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:13 --> URI Class Initialized
INFO - 2023-01-15 12:54:13 --> Router Class Initialized
INFO - 2023-01-15 12:54:13 --> Output Class Initialized
INFO - 2023-01-15 12:54:13 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:13 --> Input Class Initialized
INFO - 2023-01-15 12:54:13 --> Language Class Initialized
INFO - 2023-01-15 12:54:13 --> Language Class Initialized
INFO - 2023-01-15 12:54:13 --> Config Class Initialized
INFO - 2023-01-15 12:54:13 --> Loader Class Initialized
INFO - 2023-01-15 12:54:13 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:13 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:13 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:13 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:13 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:13 --> Controller Class Initialized
INFO - 2023-01-15 12:54:13 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:13 --> Total execution time: 0.0381
INFO - 2023-01-15 12:54:16 --> Config Class Initialized
INFO - 2023-01-15 12:54:16 --> Hooks Class Initialized
DEBUG - 2023-01-15 12:54:16 --> UTF-8 Support Enabled
INFO - 2023-01-15 12:54:16 --> Utf8 Class Initialized
INFO - 2023-01-15 12:54:16 --> URI Class Initialized
INFO - 2023-01-15 12:54:16 --> Router Class Initialized
INFO - 2023-01-15 12:54:16 --> Output Class Initialized
INFO - 2023-01-15 12:54:16 --> Security Class Initialized
DEBUG - 2023-01-15 12:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 12:54:16 --> Input Class Initialized
INFO - 2023-01-15 12:54:16 --> Language Class Initialized
INFO - 2023-01-15 12:54:16 --> Language Class Initialized
INFO - 2023-01-15 12:54:16 --> Config Class Initialized
INFO - 2023-01-15 12:54:16 --> Loader Class Initialized
INFO - 2023-01-15 12:54:16 --> Helper loaded: url_helper
INFO - 2023-01-15 12:54:16 --> Helper loaded: file_helper
INFO - 2023-01-15 12:54:16 --> Helper loaded: form_helper
INFO - 2023-01-15 12:54:16 --> Helper loaded: my_helper
INFO - 2023-01-15 12:54:16 --> Database Driver Class Initialized
DEBUG - 2023-01-15 12:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 12:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 12:54:16 --> Controller Class Initialized
DEBUG - 2023-01-15 12:54:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-15 12:54:18 --> Final output sent to browser
DEBUG - 2023-01-15 12:54:18 --> Total execution time: 1.4754
INFO - 2023-01-15 15:14:15 --> Config Class Initialized
INFO - 2023-01-15 15:14:15 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:15 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:15 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:15 --> URI Class Initialized
INFO - 2023-01-15 15:14:15 --> Router Class Initialized
INFO - 2023-01-15 15:14:15 --> Output Class Initialized
INFO - 2023-01-15 15:14:15 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:15 --> Input Class Initialized
INFO - 2023-01-15 15:14:15 --> Language Class Initialized
INFO - 2023-01-15 15:14:15 --> Language Class Initialized
INFO - 2023-01-15 15:14:15 --> Config Class Initialized
INFO - 2023-01-15 15:14:15 --> Loader Class Initialized
INFO - 2023-01-15 15:14:15 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:15 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:15 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:15 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:15 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:15 --> Controller Class Initialized
INFO - 2023-01-15 15:14:15 --> Helper loaded: cookie_helper
INFO - 2023-01-15 15:14:15 --> Config Class Initialized
INFO - 2023-01-15 15:14:15 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:16 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:16 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:16 --> URI Class Initialized
INFO - 2023-01-15 15:14:16 --> Router Class Initialized
INFO - 2023-01-15 15:14:16 --> Output Class Initialized
INFO - 2023-01-15 15:14:16 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:16 --> Input Class Initialized
INFO - 2023-01-15 15:14:16 --> Language Class Initialized
INFO - 2023-01-15 15:14:16 --> Language Class Initialized
INFO - 2023-01-15 15:14:16 --> Config Class Initialized
INFO - 2023-01-15 15:14:16 --> Loader Class Initialized
INFO - 2023-01-15 15:14:16 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:16 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:16 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:16 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:16 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:16 --> Controller Class Initialized
INFO - 2023-01-15 15:14:16 --> Config Class Initialized
INFO - 2023-01-15 15:14:16 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:16 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:16 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:16 --> URI Class Initialized
INFO - 2023-01-15 15:14:16 --> Router Class Initialized
INFO - 2023-01-15 15:14:16 --> Output Class Initialized
INFO - 2023-01-15 15:14:16 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:16 --> Input Class Initialized
INFO - 2023-01-15 15:14:16 --> Language Class Initialized
INFO - 2023-01-15 15:14:16 --> Language Class Initialized
INFO - 2023-01-15 15:14:16 --> Config Class Initialized
INFO - 2023-01-15 15:14:16 --> Loader Class Initialized
INFO - 2023-01-15 15:14:16 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:16 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:16 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:16 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:16 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:16 --> Controller Class Initialized
DEBUG - 2023-01-15 15:14:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-15 15:14:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:14:16 --> Final output sent to browser
DEBUG - 2023-01-15 15:14:16 --> Total execution time: 0.0471
INFO - 2023-01-15 15:14:20 --> Config Class Initialized
INFO - 2023-01-15 15:14:20 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:20 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:20 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:20 --> URI Class Initialized
INFO - 2023-01-15 15:14:20 --> Router Class Initialized
INFO - 2023-01-15 15:14:20 --> Output Class Initialized
INFO - 2023-01-15 15:14:20 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:20 --> Input Class Initialized
INFO - 2023-01-15 15:14:20 --> Language Class Initialized
INFO - 2023-01-15 15:14:20 --> Language Class Initialized
INFO - 2023-01-15 15:14:20 --> Config Class Initialized
INFO - 2023-01-15 15:14:20 --> Loader Class Initialized
INFO - 2023-01-15 15:14:20 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:20 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:20 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:20 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:20 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:20 --> Controller Class Initialized
INFO - 2023-01-15 15:14:20 --> Helper loaded: cookie_helper
INFO - 2023-01-15 15:14:20 --> Final output sent to browser
DEBUG - 2023-01-15 15:14:20 --> Total execution time: 0.0391
INFO - 2023-01-15 15:14:20 --> Config Class Initialized
INFO - 2023-01-15 15:14:20 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:20 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:20 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:20 --> URI Class Initialized
INFO - 2023-01-15 15:14:20 --> Router Class Initialized
INFO - 2023-01-15 15:14:20 --> Output Class Initialized
INFO - 2023-01-15 15:14:20 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:20 --> Input Class Initialized
INFO - 2023-01-15 15:14:20 --> Language Class Initialized
INFO - 2023-01-15 15:14:20 --> Language Class Initialized
INFO - 2023-01-15 15:14:20 --> Config Class Initialized
INFO - 2023-01-15 15:14:20 --> Loader Class Initialized
INFO - 2023-01-15 15:14:20 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:20 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:20 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:20 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:20 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:20 --> Controller Class Initialized
DEBUG - 2023-01-15 15:14:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-15 15:14:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:14:20 --> Final output sent to browser
DEBUG - 2023-01-15 15:14:20 --> Total execution time: 0.0652
INFO - 2023-01-15 15:14:24 --> Config Class Initialized
INFO - 2023-01-15 15:14:24 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:24 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:24 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:24 --> URI Class Initialized
INFO - 2023-01-15 15:14:24 --> Router Class Initialized
INFO - 2023-01-15 15:14:24 --> Output Class Initialized
INFO - 2023-01-15 15:14:24 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:24 --> Input Class Initialized
INFO - 2023-01-15 15:14:24 --> Language Class Initialized
INFO - 2023-01-15 15:14:24 --> Language Class Initialized
INFO - 2023-01-15 15:14:24 --> Config Class Initialized
INFO - 2023-01-15 15:14:24 --> Loader Class Initialized
INFO - 2023-01-15 15:14:24 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:24 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:24 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:24 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:24 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:24 --> Controller Class Initialized
DEBUG - 2023-01-15 15:14:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-15 15:14:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:14:24 --> Final output sent to browser
DEBUG - 2023-01-15 15:14:24 --> Total execution time: 0.0780
INFO - 2023-01-15 15:14:24 --> Config Class Initialized
INFO - 2023-01-15 15:14:24 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:24 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:24 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:24 --> URI Class Initialized
INFO - 2023-01-15 15:14:24 --> Router Class Initialized
INFO - 2023-01-15 15:14:24 --> Output Class Initialized
INFO - 2023-01-15 15:14:24 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:24 --> Input Class Initialized
INFO - 2023-01-15 15:14:24 --> Language Class Initialized
INFO - 2023-01-15 15:14:24 --> Language Class Initialized
INFO - 2023-01-15 15:14:24 --> Config Class Initialized
INFO - 2023-01-15 15:14:24 --> Loader Class Initialized
INFO - 2023-01-15 15:14:24 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:24 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:24 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:24 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:24 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:24 --> Controller Class Initialized
INFO - 2023-01-15 15:14:30 --> Config Class Initialized
INFO - 2023-01-15 15:14:30 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:14:30 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:14:30 --> Utf8 Class Initialized
INFO - 2023-01-15 15:14:30 --> URI Class Initialized
INFO - 2023-01-15 15:14:30 --> Router Class Initialized
INFO - 2023-01-15 15:14:30 --> Output Class Initialized
INFO - 2023-01-15 15:14:30 --> Security Class Initialized
DEBUG - 2023-01-15 15:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:14:30 --> Input Class Initialized
INFO - 2023-01-15 15:14:30 --> Language Class Initialized
INFO - 2023-01-15 15:14:30 --> Language Class Initialized
INFO - 2023-01-15 15:14:30 --> Config Class Initialized
INFO - 2023-01-15 15:14:30 --> Loader Class Initialized
INFO - 2023-01-15 15:14:30 --> Helper loaded: url_helper
INFO - 2023-01-15 15:14:30 --> Helper loaded: file_helper
INFO - 2023-01-15 15:14:30 --> Helper loaded: form_helper
INFO - 2023-01-15 15:14:30 --> Helper loaded: my_helper
INFO - 2023-01-15 15:14:30 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:14:30 --> Controller Class Initialized
INFO - 2023-01-15 15:14:30 --> Final output sent to browser
DEBUG - 2023-01-15 15:14:30 --> Total execution time: 0.0391
INFO - 2023-01-15 15:15:47 --> Config Class Initialized
INFO - 2023-01-15 15:15:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:15:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:15:47 --> Utf8 Class Initialized
INFO - 2023-01-15 15:15:47 --> URI Class Initialized
INFO - 2023-01-15 15:15:47 --> Router Class Initialized
INFO - 2023-01-15 15:15:47 --> Output Class Initialized
INFO - 2023-01-15 15:15:47 --> Security Class Initialized
DEBUG - 2023-01-15 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:15:47 --> Input Class Initialized
INFO - 2023-01-15 15:15:47 --> Language Class Initialized
INFO - 2023-01-15 15:15:47 --> Language Class Initialized
INFO - 2023-01-15 15:15:47 --> Config Class Initialized
INFO - 2023-01-15 15:15:47 --> Loader Class Initialized
INFO - 2023-01-15 15:15:47 --> Helper loaded: url_helper
INFO - 2023-01-15 15:15:47 --> Helper loaded: file_helper
INFO - 2023-01-15 15:15:47 --> Helper loaded: form_helper
INFO - 2023-01-15 15:15:47 --> Helper loaded: my_helper
INFO - 2023-01-15 15:15:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:15:47 --> Controller Class Initialized
DEBUG - 2023-01-15 15:15:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-15 15:15:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:15:47 --> Final output sent to browser
DEBUG - 2023-01-15 15:15:47 --> Total execution time: 0.0391
INFO - 2023-01-15 15:15:47 --> Config Class Initialized
INFO - 2023-01-15 15:15:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:15:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:15:47 --> Utf8 Class Initialized
INFO - 2023-01-15 15:15:47 --> URI Class Initialized
INFO - 2023-01-15 15:15:47 --> Router Class Initialized
INFO - 2023-01-15 15:15:47 --> Output Class Initialized
INFO - 2023-01-15 15:15:47 --> Security Class Initialized
DEBUG - 2023-01-15 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:15:47 --> Input Class Initialized
INFO - 2023-01-15 15:15:47 --> Language Class Initialized
INFO - 2023-01-15 15:15:47 --> Language Class Initialized
INFO - 2023-01-15 15:15:47 --> Config Class Initialized
INFO - 2023-01-15 15:15:47 --> Loader Class Initialized
INFO - 2023-01-15 15:15:47 --> Helper loaded: url_helper
INFO - 2023-01-15 15:15:47 --> Helper loaded: file_helper
INFO - 2023-01-15 15:15:47 --> Helper loaded: form_helper
INFO - 2023-01-15 15:15:47 --> Helper loaded: my_helper
INFO - 2023-01-15 15:15:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:15:47 --> Controller Class Initialized
INFO - 2023-01-15 15:15:48 --> Config Class Initialized
INFO - 2023-01-15 15:15:48 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:15:48 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:15:48 --> Utf8 Class Initialized
INFO - 2023-01-15 15:15:48 --> URI Class Initialized
INFO - 2023-01-15 15:15:48 --> Router Class Initialized
INFO - 2023-01-15 15:15:48 --> Output Class Initialized
INFO - 2023-01-15 15:15:48 --> Security Class Initialized
DEBUG - 2023-01-15 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:15:48 --> Input Class Initialized
INFO - 2023-01-15 15:15:48 --> Language Class Initialized
INFO - 2023-01-15 15:15:48 --> Language Class Initialized
INFO - 2023-01-15 15:15:48 --> Config Class Initialized
INFO - 2023-01-15 15:15:48 --> Loader Class Initialized
INFO - 2023-01-15 15:15:48 --> Helper loaded: url_helper
INFO - 2023-01-15 15:15:48 --> Helper loaded: file_helper
INFO - 2023-01-15 15:15:48 --> Helper loaded: form_helper
INFO - 2023-01-15 15:15:48 --> Helper loaded: my_helper
INFO - 2023-01-15 15:15:48 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:15:49 --> Controller Class Initialized
INFO - 2023-01-15 15:15:49 --> Final output sent to browser
DEBUG - 2023-01-15 15:15:49 --> Total execution time: 0.0575
INFO - 2023-01-15 15:17:09 --> Config Class Initialized
INFO - 2023-01-15 15:17:09 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:09 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:09 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:09 --> URI Class Initialized
INFO - 2023-01-15 15:17:09 --> Router Class Initialized
INFO - 2023-01-15 15:17:09 --> Output Class Initialized
INFO - 2023-01-15 15:17:09 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:09 --> Input Class Initialized
INFO - 2023-01-15 15:17:09 --> Language Class Initialized
INFO - 2023-01-15 15:17:09 --> Language Class Initialized
INFO - 2023-01-15 15:17:09 --> Config Class Initialized
INFO - 2023-01-15 15:17:09 --> Loader Class Initialized
INFO - 2023-01-15 15:17:09 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:09 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:09 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:09 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:09 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:09 --> Controller Class Initialized
DEBUG - 2023-01-15 15:17:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-15 15:17:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:17:09 --> Final output sent to browser
DEBUG - 2023-01-15 15:17:09 --> Total execution time: 0.0561
INFO - 2023-01-15 15:17:09 --> Config Class Initialized
INFO - 2023-01-15 15:17:09 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:09 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:09 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:09 --> URI Class Initialized
INFO - 2023-01-15 15:17:09 --> Router Class Initialized
INFO - 2023-01-15 15:17:09 --> Output Class Initialized
INFO - 2023-01-15 15:17:09 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:09 --> Input Class Initialized
INFO - 2023-01-15 15:17:09 --> Language Class Initialized
INFO - 2023-01-15 15:17:09 --> Language Class Initialized
INFO - 2023-01-15 15:17:09 --> Config Class Initialized
INFO - 2023-01-15 15:17:09 --> Loader Class Initialized
INFO - 2023-01-15 15:17:09 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:09 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:09 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:09 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:09 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:09 --> Controller Class Initialized
INFO - 2023-01-15 15:17:11 --> Config Class Initialized
INFO - 2023-01-15 15:17:11 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:11 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:11 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:11 --> URI Class Initialized
INFO - 2023-01-15 15:17:11 --> Router Class Initialized
INFO - 2023-01-15 15:17:11 --> Output Class Initialized
INFO - 2023-01-15 15:17:11 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:11 --> Input Class Initialized
INFO - 2023-01-15 15:17:11 --> Language Class Initialized
INFO - 2023-01-15 15:17:11 --> Language Class Initialized
INFO - 2023-01-15 15:17:11 --> Config Class Initialized
INFO - 2023-01-15 15:17:11 --> Loader Class Initialized
INFO - 2023-01-15 15:17:11 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:11 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:11 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:11 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:11 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:11 --> Controller Class Initialized
INFO - 2023-01-15 15:17:11 --> Final output sent to browser
DEBUG - 2023-01-15 15:17:11 --> Total execution time: 0.0569
INFO - 2023-01-15 15:17:16 --> Config Class Initialized
INFO - 2023-01-15 15:17:16 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:16 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:16 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:16 --> URI Class Initialized
INFO - 2023-01-15 15:17:16 --> Router Class Initialized
INFO - 2023-01-15 15:17:16 --> Output Class Initialized
INFO - 2023-01-15 15:17:16 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:16 --> Input Class Initialized
INFO - 2023-01-15 15:17:16 --> Language Class Initialized
INFO - 2023-01-15 15:17:16 --> Language Class Initialized
INFO - 2023-01-15 15:17:16 --> Config Class Initialized
INFO - 2023-01-15 15:17:16 --> Loader Class Initialized
INFO - 2023-01-15 15:17:16 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:16 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:16 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:16 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:16 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:16 --> Controller Class Initialized
INFO - 2023-01-15 15:17:16 --> Final output sent to browser
DEBUG - 2023-01-15 15:17:16 --> Total execution time: 0.0586
INFO - 2023-01-15 15:17:20 --> Config Class Initialized
INFO - 2023-01-15 15:17:20 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:20 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:20 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:20 --> URI Class Initialized
INFO - 2023-01-15 15:17:20 --> Router Class Initialized
INFO - 2023-01-15 15:17:20 --> Output Class Initialized
INFO - 2023-01-15 15:17:20 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:20 --> Input Class Initialized
INFO - 2023-01-15 15:17:20 --> Language Class Initialized
INFO - 2023-01-15 15:17:20 --> Language Class Initialized
INFO - 2023-01-15 15:17:20 --> Config Class Initialized
INFO - 2023-01-15 15:17:20 --> Loader Class Initialized
INFO - 2023-01-15 15:17:20 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:20 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:20 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:20 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:20 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:20 --> Controller Class Initialized
INFO - 2023-01-15 15:17:20 --> Final output sent to browser
DEBUG - 2023-01-15 15:17:20 --> Total execution time: 0.0563
INFO - 2023-01-15 15:17:52 --> Config Class Initialized
INFO - 2023-01-15 15:17:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:52 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:52 --> URI Class Initialized
INFO - 2023-01-15 15:17:52 --> Router Class Initialized
INFO - 2023-01-15 15:17:52 --> Output Class Initialized
INFO - 2023-01-15 15:17:52 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:52 --> Input Class Initialized
INFO - 2023-01-15 15:17:52 --> Language Class Initialized
INFO - 2023-01-15 15:17:52 --> Language Class Initialized
INFO - 2023-01-15 15:17:52 --> Config Class Initialized
INFO - 2023-01-15 15:17:52 --> Loader Class Initialized
INFO - 2023-01-15 15:17:52 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:52 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:52 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:52 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:52 --> Controller Class Initialized
INFO - 2023-01-15 15:17:52 --> Final output sent to browser
DEBUG - 2023-01-15 15:17:52 --> Total execution time: 0.0587
INFO - 2023-01-15 15:17:52 --> Config Class Initialized
INFO - 2023-01-15 15:17:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:52 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:52 --> URI Class Initialized
INFO - 2023-01-15 15:17:52 --> Router Class Initialized
INFO - 2023-01-15 15:17:52 --> Output Class Initialized
INFO - 2023-01-15 15:17:52 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:52 --> Input Class Initialized
INFO - 2023-01-15 15:17:52 --> Language Class Initialized
INFO - 2023-01-15 15:17:52 --> Language Class Initialized
INFO - 2023-01-15 15:17:52 --> Config Class Initialized
INFO - 2023-01-15 15:17:52 --> Loader Class Initialized
INFO - 2023-01-15 15:17:52 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:52 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:52 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:52 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:52 --> Controller Class Initialized
INFO - 2023-01-15 15:17:54 --> Config Class Initialized
INFO - 2023-01-15 15:17:54 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:17:54 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:17:54 --> Utf8 Class Initialized
INFO - 2023-01-15 15:17:54 --> URI Class Initialized
INFO - 2023-01-15 15:17:54 --> Router Class Initialized
INFO - 2023-01-15 15:17:54 --> Output Class Initialized
INFO - 2023-01-15 15:17:54 --> Security Class Initialized
DEBUG - 2023-01-15 15:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:17:54 --> Input Class Initialized
INFO - 2023-01-15 15:17:54 --> Language Class Initialized
INFO - 2023-01-15 15:17:54 --> Language Class Initialized
INFO - 2023-01-15 15:17:54 --> Config Class Initialized
INFO - 2023-01-15 15:17:54 --> Loader Class Initialized
INFO - 2023-01-15 15:17:54 --> Helper loaded: url_helper
INFO - 2023-01-15 15:17:54 --> Helper loaded: file_helper
INFO - 2023-01-15 15:17:54 --> Helper loaded: form_helper
INFO - 2023-01-15 15:17:54 --> Helper loaded: my_helper
INFO - 2023-01-15 15:17:54 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:17:54 --> Controller Class Initialized
INFO - 2023-01-15 15:17:54 --> Final output sent to browser
DEBUG - 2023-01-15 15:17:54 --> Total execution time: 0.0579
INFO - 2023-01-15 15:18:17 --> Config Class Initialized
INFO - 2023-01-15 15:18:17 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:18:17 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:18:17 --> Utf8 Class Initialized
INFO - 2023-01-15 15:18:17 --> URI Class Initialized
INFO - 2023-01-15 15:18:17 --> Router Class Initialized
INFO - 2023-01-15 15:18:17 --> Output Class Initialized
INFO - 2023-01-15 15:18:17 --> Security Class Initialized
DEBUG - 2023-01-15 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:18:17 --> Input Class Initialized
INFO - 2023-01-15 15:18:17 --> Language Class Initialized
INFO - 2023-01-15 15:18:17 --> Language Class Initialized
INFO - 2023-01-15 15:18:17 --> Config Class Initialized
INFO - 2023-01-15 15:18:17 --> Loader Class Initialized
INFO - 2023-01-15 15:18:17 --> Helper loaded: url_helper
INFO - 2023-01-15 15:18:17 --> Helper loaded: file_helper
INFO - 2023-01-15 15:18:17 --> Helper loaded: form_helper
INFO - 2023-01-15 15:18:17 --> Helper loaded: my_helper
INFO - 2023-01-15 15:18:17 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:18:17 --> Controller Class Initialized
INFO - 2023-01-15 15:18:17 --> Final output sent to browser
DEBUG - 2023-01-15 15:18:17 --> Total execution time: 0.0567
INFO - 2023-01-15 15:18:17 --> Config Class Initialized
INFO - 2023-01-15 15:18:17 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:18:17 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:18:17 --> Utf8 Class Initialized
INFO - 2023-01-15 15:18:17 --> URI Class Initialized
INFO - 2023-01-15 15:18:17 --> Router Class Initialized
INFO - 2023-01-15 15:18:17 --> Output Class Initialized
INFO - 2023-01-15 15:18:17 --> Security Class Initialized
DEBUG - 2023-01-15 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:18:17 --> Input Class Initialized
INFO - 2023-01-15 15:18:17 --> Language Class Initialized
INFO - 2023-01-15 15:18:17 --> Language Class Initialized
INFO - 2023-01-15 15:18:17 --> Config Class Initialized
INFO - 2023-01-15 15:18:17 --> Loader Class Initialized
INFO - 2023-01-15 15:18:17 --> Helper loaded: url_helper
INFO - 2023-01-15 15:18:17 --> Helper loaded: file_helper
INFO - 2023-01-15 15:18:17 --> Helper loaded: form_helper
INFO - 2023-01-15 15:18:17 --> Helper loaded: my_helper
INFO - 2023-01-15 15:18:17 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:18:17 --> Controller Class Initialized
INFO - 2023-01-15 15:18:21 --> Config Class Initialized
INFO - 2023-01-15 15:18:21 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:18:21 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:18:21 --> Utf8 Class Initialized
INFO - 2023-01-15 15:18:21 --> URI Class Initialized
INFO - 2023-01-15 15:18:21 --> Router Class Initialized
INFO - 2023-01-15 15:18:21 --> Output Class Initialized
INFO - 2023-01-15 15:18:21 --> Security Class Initialized
DEBUG - 2023-01-15 15:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:18:21 --> Input Class Initialized
INFO - 2023-01-15 15:18:21 --> Language Class Initialized
INFO - 2023-01-15 15:18:21 --> Language Class Initialized
INFO - 2023-01-15 15:18:21 --> Config Class Initialized
INFO - 2023-01-15 15:18:21 --> Loader Class Initialized
INFO - 2023-01-15 15:18:21 --> Helper loaded: url_helper
INFO - 2023-01-15 15:18:21 --> Helper loaded: file_helper
INFO - 2023-01-15 15:18:21 --> Helper loaded: form_helper
INFO - 2023-01-15 15:18:21 --> Helper loaded: my_helper
INFO - 2023-01-15 15:18:21 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:18:21 --> Controller Class Initialized
INFO - 2023-01-15 15:18:21 --> Final output sent to browser
DEBUG - 2023-01-15 15:18:21 --> Total execution time: 0.0375
INFO - 2023-01-15 15:18:43 --> Config Class Initialized
INFO - 2023-01-15 15:18:43 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:18:43 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:18:43 --> Utf8 Class Initialized
INFO - 2023-01-15 15:18:43 --> URI Class Initialized
INFO - 2023-01-15 15:18:43 --> Router Class Initialized
INFO - 2023-01-15 15:18:43 --> Output Class Initialized
INFO - 2023-01-15 15:18:43 --> Security Class Initialized
DEBUG - 2023-01-15 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:18:43 --> Input Class Initialized
INFO - 2023-01-15 15:18:43 --> Language Class Initialized
INFO - 2023-01-15 15:18:43 --> Language Class Initialized
INFO - 2023-01-15 15:18:43 --> Config Class Initialized
INFO - 2023-01-15 15:18:43 --> Loader Class Initialized
INFO - 2023-01-15 15:18:43 --> Helper loaded: url_helper
INFO - 2023-01-15 15:18:43 --> Helper loaded: file_helper
INFO - 2023-01-15 15:18:43 --> Helper loaded: form_helper
INFO - 2023-01-15 15:18:43 --> Helper loaded: my_helper
INFO - 2023-01-15 15:18:43 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:18:43 --> Controller Class Initialized
INFO - 2023-01-15 15:18:43 --> Final output sent to browser
DEBUG - 2023-01-15 15:18:43 --> Total execution time: 0.0370
INFO - 2023-01-15 15:18:43 --> Config Class Initialized
INFO - 2023-01-15 15:18:43 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:18:43 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:18:43 --> Utf8 Class Initialized
INFO - 2023-01-15 15:18:43 --> URI Class Initialized
INFO - 2023-01-15 15:18:43 --> Router Class Initialized
INFO - 2023-01-15 15:18:43 --> Output Class Initialized
INFO - 2023-01-15 15:18:43 --> Security Class Initialized
DEBUG - 2023-01-15 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:18:43 --> Input Class Initialized
INFO - 2023-01-15 15:18:43 --> Language Class Initialized
INFO - 2023-01-15 15:18:43 --> Language Class Initialized
INFO - 2023-01-15 15:18:43 --> Config Class Initialized
INFO - 2023-01-15 15:18:43 --> Loader Class Initialized
INFO - 2023-01-15 15:18:43 --> Helper loaded: url_helper
INFO - 2023-01-15 15:18:43 --> Helper loaded: file_helper
INFO - 2023-01-15 15:18:43 --> Helper loaded: form_helper
INFO - 2023-01-15 15:18:43 --> Helper loaded: my_helper
INFO - 2023-01-15 15:18:43 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:18:43 --> Controller Class Initialized
INFO - 2023-01-15 15:18:44 --> Config Class Initialized
INFO - 2023-01-15 15:18:44 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:18:44 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:18:44 --> Utf8 Class Initialized
INFO - 2023-01-15 15:18:44 --> URI Class Initialized
INFO - 2023-01-15 15:18:44 --> Router Class Initialized
INFO - 2023-01-15 15:18:44 --> Output Class Initialized
INFO - 2023-01-15 15:18:44 --> Security Class Initialized
DEBUG - 2023-01-15 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:18:44 --> Input Class Initialized
INFO - 2023-01-15 15:18:44 --> Language Class Initialized
INFO - 2023-01-15 15:18:44 --> Language Class Initialized
INFO - 2023-01-15 15:18:44 --> Config Class Initialized
INFO - 2023-01-15 15:18:44 --> Loader Class Initialized
INFO - 2023-01-15 15:18:44 --> Helper loaded: url_helper
INFO - 2023-01-15 15:18:44 --> Helper loaded: file_helper
INFO - 2023-01-15 15:18:44 --> Helper loaded: form_helper
INFO - 2023-01-15 15:18:44 --> Helper loaded: my_helper
INFO - 2023-01-15 15:18:44 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:18:44 --> Controller Class Initialized
INFO - 2023-01-15 15:18:44 --> Final output sent to browser
DEBUG - 2023-01-15 15:18:44 --> Total execution time: 0.0565
INFO - 2023-01-15 15:19:00 --> Config Class Initialized
INFO - 2023-01-15 15:19:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:00 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:00 --> URI Class Initialized
INFO - 2023-01-15 15:19:00 --> Router Class Initialized
INFO - 2023-01-15 15:19:00 --> Output Class Initialized
INFO - 2023-01-15 15:19:00 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:00 --> Input Class Initialized
INFO - 2023-01-15 15:19:00 --> Language Class Initialized
INFO - 2023-01-15 15:19:00 --> Language Class Initialized
INFO - 2023-01-15 15:19:00 --> Config Class Initialized
INFO - 2023-01-15 15:19:00 --> Loader Class Initialized
INFO - 2023-01-15 15:19:00 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:00 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:00 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:00 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:00 --> Controller Class Initialized
INFO - 2023-01-15 15:19:00 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:00 --> Total execution time: 0.0600
INFO - 2023-01-15 15:19:00 --> Config Class Initialized
INFO - 2023-01-15 15:19:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:00 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:00 --> URI Class Initialized
INFO - 2023-01-15 15:19:00 --> Router Class Initialized
INFO - 2023-01-15 15:19:00 --> Output Class Initialized
INFO - 2023-01-15 15:19:00 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:00 --> Input Class Initialized
INFO - 2023-01-15 15:19:00 --> Language Class Initialized
INFO - 2023-01-15 15:19:00 --> Language Class Initialized
INFO - 2023-01-15 15:19:00 --> Config Class Initialized
INFO - 2023-01-15 15:19:00 --> Loader Class Initialized
INFO - 2023-01-15 15:19:00 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:00 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:00 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:00 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:00 --> Controller Class Initialized
INFO - 2023-01-15 15:19:03 --> Config Class Initialized
INFO - 2023-01-15 15:19:03 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:03 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:03 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:03 --> URI Class Initialized
INFO - 2023-01-15 15:19:03 --> Router Class Initialized
INFO - 2023-01-15 15:19:03 --> Output Class Initialized
INFO - 2023-01-15 15:19:03 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:03 --> Input Class Initialized
INFO - 2023-01-15 15:19:03 --> Language Class Initialized
INFO - 2023-01-15 15:19:03 --> Language Class Initialized
INFO - 2023-01-15 15:19:03 --> Config Class Initialized
INFO - 2023-01-15 15:19:03 --> Loader Class Initialized
INFO - 2023-01-15 15:19:03 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:03 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:03 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:03 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:03 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:03 --> Controller Class Initialized
DEBUG - 2023-01-15 15:19:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-15 15:19:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:19:03 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:03 --> Total execution time: 0.0747
INFO - 2023-01-15 15:19:03 --> Config Class Initialized
INFO - 2023-01-15 15:19:03 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:03 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:03 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:03 --> URI Class Initialized
INFO - 2023-01-15 15:19:03 --> Router Class Initialized
INFO - 2023-01-15 15:19:03 --> Output Class Initialized
INFO - 2023-01-15 15:19:03 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:03 --> Input Class Initialized
INFO - 2023-01-15 15:19:03 --> Language Class Initialized
INFO - 2023-01-15 15:19:03 --> Language Class Initialized
INFO - 2023-01-15 15:19:03 --> Config Class Initialized
INFO - 2023-01-15 15:19:03 --> Loader Class Initialized
INFO - 2023-01-15 15:19:03 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:03 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:03 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:03 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:03 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:03 --> Controller Class Initialized
INFO - 2023-01-15 15:19:08 --> Config Class Initialized
INFO - 2023-01-15 15:19:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:08 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:08 --> URI Class Initialized
INFO - 2023-01-15 15:19:08 --> Router Class Initialized
INFO - 2023-01-15 15:19:08 --> Output Class Initialized
INFO - 2023-01-15 15:19:08 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:08 --> Input Class Initialized
INFO - 2023-01-15 15:19:08 --> Language Class Initialized
INFO - 2023-01-15 15:19:08 --> Language Class Initialized
INFO - 2023-01-15 15:19:08 --> Config Class Initialized
INFO - 2023-01-15 15:19:08 --> Loader Class Initialized
INFO - 2023-01-15 15:19:08 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:08 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:08 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:08 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:08 --> Controller Class Initialized
DEBUG - 2023-01-15 15:19:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-15 15:19:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:19:08 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:08 --> Total execution time: 0.0665
INFO - 2023-01-15 15:19:26 --> Config Class Initialized
INFO - 2023-01-15 15:19:26 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:26 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:26 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:26 --> URI Class Initialized
INFO - 2023-01-15 15:19:26 --> Router Class Initialized
INFO - 2023-01-15 15:19:26 --> Output Class Initialized
INFO - 2023-01-15 15:19:26 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:26 --> Input Class Initialized
INFO - 2023-01-15 15:19:26 --> Language Class Initialized
INFO - 2023-01-15 15:19:26 --> Language Class Initialized
INFO - 2023-01-15 15:19:26 --> Config Class Initialized
INFO - 2023-01-15 15:19:26 --> Loader Class Initialized
INFO - 2023-01-15 15:19:26 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:26 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:26 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:26 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:26 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:26 --> Controller Class Initialized
DEBUG - 2023-01-15 15:19:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-01-15 15:19:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:19:26 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:26 --> Total execution time: 0.0713
INFO - 2023-01-15 15:19:26 --> Config Class Initialized
INFO - 2023-01-15 15:19:26 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:26 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:26 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:26 --> URI Class Initialized
INFO - 2023-01-15 15:19:26 --> Router Class Initialized
INFO - 2023-01-15 15:19:26 --> Output Class Initialized
INFO - 2023-01-15 15:19:26 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:26 --> Input Class Initialized
INFO - 2023-01-15 15:19:26 --> Language Class Initialized
INFO - 2023-01-15 15:19:26 --> Language Class Initialized
INFO - 2023-01-15 15:19:26 --> Config Class Initialized
INFO - 2023-01-15 15:19:26 --> Loader Class Initialized
INFO - 2023-01-15 15:19:26 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:26 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:26 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:26 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:26 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:26 --> Controller Class Initialized
INFO - 2023-01-15 15:19:28 --> Config Class Initialized
INFO - 2023-01-15 15:19:28 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:28 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:28 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:28 --> URI Class Initialized
INFO - 2023-01-15 15:19:28 --> Router Class Initialized
INFO - 2023-01-15 15:19:28 --> Output Class Initialized
INFO - 2023-01-15 15:19:28 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:28 --> Input Class Initialized
INFO - 2023-01-15 15:19:28 --> Language Class Initialized
INFO - 2023-01-15 15:19:28 --> Language Class Initialized
INFO - 2023-01-15 15:19:28 --> Config Class Initialized
INFO - 2023-01-15 15:19:28 --> Loader Class Initialized
INFO - 2023-01-15 15:19:28 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:28 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:28 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:28 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:28 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:28 --> Controller Class Initialized
DEBUG - 2023-01-15 15:19:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-15 15:19:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:19:28 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:28 --> Total execution time: 0.0555
INFO - 2023-01-15 15:19:28 --> Config Class Initialized
INFO - 2023-01-15 15:19:28 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:28 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:28 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:28 --> URI Class Initialized
INFO - 2023-01-15 15:19:28 --> Router Class Initialized
INFO - 2023-01-15 15:19:28 --> Output Class Initialized
INFO - 2023-01-15 15:19:28 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:28 --> Input Class Initialized
INFO - 2023-01-15 15:19:28 --> Language Class Initialized
INFO - 2023-01-15 15:19:28 --> Language Class Initialized
INFO - 2023-01-15 15:19:28 --> Config Class Initialized
INFO - 2023-01-15 15:19:28 --> Loader Class Initialized
INFO - 2023-01-15 15:19:28 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:28 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:28 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:28 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:28 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:28 --> Controller Class Initialized
INFO - 2023-01-15 15:19:33 --> Config Class Initialized
INFO - 2023-01-15 15:19:33 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:33 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:33 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:33 --> URI Class Initialized
INFO - 2023-01-15 15:19:33 --> Router Class Initialized
INFO - 2023-01-15 15:19:33 --> Output Class Initialized
INFO - 2023-01-15 15:19:33 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:33 --> Input Class Initialized
INFO - 2023-01-15 15:19:33 --> Language Class Initialized
INFO - 2023-01-15 15:19:33 --> Language Class Initialized
INFO - 2023-01-15 15:19:33 --> Config Class Initialized
INFO - 2023-01-15 15:19:33 --> Loader Class Initialized
INFO - 2023-01-15 15:19:33 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:33 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:33 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:33 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:33 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:33 --> Controller Class Initialized
INFO - 2023-01-15 15:19:33 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:33 --> Total execution time: 0.0400
INFO - 2023-01-15 15:19:43 --> Config Class Initialized
INFO - 2023-01-15 15:19:43 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:43 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:43 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:43 --> URI Class Initialized
INFO - 2023-01-15 15:19:43 --> Router Class Initialized
INFO - 2023-01-15 15:19:43 --> Output Class Initialized
INFO - 2023-01-15 15:19:43 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:43 --> Input Class Initialized
INFO - 2023-01-15 15:19:43 --> Language Class Initialized
INFO - 2023-01-15 15:19:43 --> Language Class Initialized
INFO - 2023-01-15 15:19:43 --> Config Class Initialized
INFO - 2023-01-15 15:19:43 --> Loader Class Initialized
INFO - 2023-01-15 15:19:43 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:43 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:43 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:43 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:43 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:43 --> Controller Class Initialized
INFO - 2023-01-15 15:19:43 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:43 --> Total execution time: 0.0359
INFO - 2023-01-15 15:19:43 --> Config Class Initialized
INFO - 2023-01-15 15:19:43 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:43 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:43 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:43 --> URI Class Initialized
INFO - 2023-01-15 15:19:43 --> Router Class Initialized
INFO - 2023-01-15 15:19:43 --> Output Class Initialized
INFO - 2023-01-15 15:19:43 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:43 --> Input Class Initialized
INFO - 2023-01-15 15:19:43 --> Language Class Initialized
INFO - 2023-01-15 15:19:43 --> Language Class Initialized
INFO - 2023-01-15 15:19:43 --> Config Class Initialized
INFO - 2023-01-15 15:19:43 --> Loader Class Initialized
INFO - 2023-01-15 15:19:43 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:43 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:43 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:43 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:43 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:43 --> Controller Class Initialized
INFO - 2023-01-15 15:19:45 --> Config Class Initialized
INFO - 2023-01-15 15:19:45 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:45 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:45 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:45 --> URI Class Initialized
INFO - 2023-01-15 15:19:45 --> Router Class Initialized
INFO - 2023-01-15 15:19:45 --> Output Class Initialized
INFO - 2023-01-15 15:19:45 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:45 --> Input Class Initialized
INFO - 2023-01-15 15:19:45 --> Language Class Initialized
INFO - 2023-01-15 15:19:45 --> Language Class Initialized
INFO - 2023-01-15 15:19:45 --> Config Class Initialized
INFO - 2023-01-15 15:19:45 --> Loader Class Initialized
INFO - 2023-01-15 15:19:45 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:45 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:45 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:45 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:45 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:45 --> Controller Class Initialized
INFO - 2023-01-15 15:19:45 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:45 --> Total execution time: 0.0404
INFO - 2023-01-15 15:19:52 --> Config Class Initialized
INFO - 2023-01-15 15:19:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:52 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:52 --> URI Class Initialized
INFO - 2023-01-15 15:19:52 --> Router Class Initialized
INFO - 2023-01-15 15:19:52 --> Output Class Initialized
INFO - 2023-01-15 15:19:52 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:52 --> Input Class Initialized
INFO - 2023-01-15 15:19:52 --> Language Class Initialized
INFO - 2023-01-15 15:19:52 --> Language Class Initialized
INFO - 2023-01-15 15:19:52 --> Config Class Initialized
INFO - 2023-01-15 15:19:52 --> Loader Class Initialized
INFO - 2023-01-15 15:19:52 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:52 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:52 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:52 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:52 --> Controller Class Initialized
INFO - 2023-01-15 15:19:52 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:52 --> Total execution time: 0.0573
INFO - 2023-01-15 15:19:52 --> Config Class Initialized
INFO - 2023-01-15 15:19:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:52 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:52 --> URI Class Initialized
INFO - 2023-01-15 15:19:52 --> Router Class Initialized
INFO - 2023-01-15 15:19:52 --> Output Class Initialized
INFO - 2023-01-15 15:19:52 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:52 --> Input Class Initialized
INFO - 2023-01-15 15:19:52 --> Language Class Initialized
INFO - 2023-01-15 15:19:52 --> Language Class Initialized
INFO - 2023-01-15 15:19:52 --> Config Class Initialized
INFO - 2023-01-15 15:19:52 --> Loader Class Initialized
INFO - 2023-01-15 15:19:52 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:52 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:52 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:52 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:52 --> Controller Class Initialized
INFO - 2023-01-15 15:19:53 --> Config Class Initialized
INFO - 2023-01-15 15:19:53 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:53 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:53 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:53 --> URI Class Initialized
INFO - 2023-01-15 15:19:53 --> Router Class Initialized
INFO - 2023-01-15 15:19:53 --> Output Class Initialized
INFO - 2023-01-15 15:19:53 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:53 --> Input Class Initialized
INFO - 2023-01-15 15:19:53 --> Language Class Initialized
INFO - 2023-01-15 15:19:54 --> Language Class Initialized
INFO - 2023-01-15 15:19:54 --> Config Class Initialized
INFO - 2023-01-15 15:19:54 --> Loader Class Initialized
INFO - 2023-01-15 15:19:54 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:54 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:54 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:54 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:54 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:54 --> Controller Class Initialized
INFO - 2023-01-15 15:19:54 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:54 --> Total execution time: 0.0422
INFO - 2023-01-15 15:19:59 --> Config Class Initialized
INFO - 2023-01-15 15:19:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:59 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:59 --> URI Class Initialized
INFO - 2023-01-15 15:19:59 --> Router Class Initialized
INFO - 2023-01-15 15:19:59 --> Output Class Initialized
INFO - 2023-01-15 15:19:59 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:59 --> Input Class Initialized
INFO - 2023-01-15 15:19:59 --> Language Class Initialized
INFO - 2023-01-15 15:19:59 --> Language Class Initialized
INFO - 2023-01-15 15:19:59 --> Config Class Initialized
INFO - 2023-01-15 15:19:59 --> Loader Class Initialized
INFO - 2023-01-15 15:19:59 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:59 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:59 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:59 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:59 --> Controller Class Initialized
INFO - 2023-01-15 15:19:59 --> Final output sent to browser
DEBUG - 2023-01-15 15:19:59 --> Total execution time: 0.0584
INFO - 2023-01-15 15:19:59 --> Config Class Initialized
INFO - 2023-01-15 15:19:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:19:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:19:59 --> Utf8 Class Initialized
INFO - 2023-01-15 15:19:59 --> URI Class Initialized
INFO - 2023-01-15 15:19:59 --> Router Class Initialized
INFO - 2023-01-15 15:19:59 --> Output Class Initialized
INFO - 2023-01-15 15:19:59 --> Security Class Initialized
DEBUG - 2023-01-15 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:19:59 --> Input Class Initialized
INFO - 2023-01-15 15:19:59 --> Language Class Initialized
INFO - 2023-01-15 15:19:59 --> Language Class Initialized
INFO - 2023-01-15 15:19:59 --> Config Class Initialized
INFO - 2023-01-15 15:19:59 --> Loader Class Initialized
INFO - 2023-01-15 15:19:59 --> Helper loaded: url_helper
INFO - 2023-01-15 15:19:59 --> Helper loaded: file_helper
INFO - 2023-01-15 15:19:59 --> Helper loaded: form_helper
INFO - 2023-01-15 15:19:59 --> Helper loaded: my_helper
INFO - 2023-01-15 15:19:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:19:59 --> Controller Class Initialized
INFO - 2023-01-15 15:20:00 --> Config Class Initialized
INFO - 2023-01-15 15:20:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:00 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:00 --> URI Class Initialized
INFO - 2023-01-15 15:20:00 --> Router Class Initialized
INFO - 2023-01-15 15:20:00 --> Output Class Initialized
INFO - 2023-01-15 15:20:00 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:00 --> Input Class Initialized
INFO - 2023-01-15 15:20:00 --> Language Class Initialized
INFO - 2023-01-15 15:20:00 --> Language Class Initialized
INFO - 2023-01-15 15:20:00 --> Config Class Initialized
INFO - 2023-01-15 15:20:00 --> Loader Class Initialized
INFO - 2023-01-15 15:20:00 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:00 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:00 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:00 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:01 --> Controller Class Initialized
INFO - 2023-01-15 15:20:01 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:01 --> Total execution time: 0.0425
INFO - 2023-01-15 15:20:08 --> Config Class Initialized
INFO - 2023-01-15 15:20:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:08 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:08 --> URI Class Initialized
INFO - 2023-01-15 15:20:08 --> Router Class Initialized
INFO - 2023-01-15 15:20:08 --> Output Class Initialized
INFO - 2023-01-15 15:20:08 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:08 --> Input Class Initialized
INFO - 2023-01-15 15:20:08 --> Language Class Initialized
INFO - 2023-01-15 15:20:08 --> Language Class Initialized
INFO - 2023-01-15 15:20:08 --> Config Class Initialized
INFO - 2023-01-15 15:20:08 --> Loader Class Initialized
INFO - 2023-01-15 15:20:08 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:08 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:08 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:08 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:08 --> Controller Class Initialized
INFO - 2023-01-15 15:20:08 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:08 --> Total execution time: 0.0355
INFO - 2023-01-15 15:20:08 --> Config Class Initialized
INFO - 2023-01-15 15:20:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:08 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:08 --> URI Class Initialized
INFO - 2023-01-15 15:20:08 --> Router Class Initialized
INFO - 2023-01-15 15:20:08 --> Output Class Initialized
INFO - 2023-01-15 15:20:08 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:08 --> Input Class Initialized
INFO - 2023-01-15 15:20:08 --> Language Class Initialized
INFO - 2023-01-15 15:20:08 --> Language Class Initialized
INFO - 2023-01-15 15:20:08 --> Config Class Initialized
INFO - 2023-01-15 15:20:08 --> Loader Class Initialized
INFO - 2023-01-15 15:20:08 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:08 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:08 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:08 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:08 --> Controller Class Initialized
INFO - 2023-01-15 15:20:11 --> Config Class Initialized
INFO - 2023-01-15 15:20:11 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:11 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:11 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:11 --> URI Class Initialized
INFO - 2023-01-15 15:20:11 --> Router Class Initialized
INFO - 2023-01-15 15:20:11 --> Output Class Initialized
INFO - 2023-01-15 15:20:11 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:11 --> Input Class Initialized
INFO - 2023-01-15 15:20:11 --> Language Class Initialized
INFO - 2023-01-15 15:20:11 --> Language Class Initialized
INFO - 2023-01-15 15:20:11 --> Config Class Initialized
INFO - 2023-01-15 15:20:11 --> Loader Class Initialized
INFO - 2023-01-15 15:20:11 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:11 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:11 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:11 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:11 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:11 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-15 15:20:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:11 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:11 --> Total execution time: 0.0578
INFO - 2023-01-15 15:20:11 --> Config Class Initialized
INFO - 2023-01-15 15:20:11 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:11 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:11 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:11 --> URI Class Initialized
INFO - 2023-01-15 15:20:11 --> Router Class Initialized
INFO - 2023-01-15 15:20:11 --> Output Class Initialized
INFO - 2023-01-15 15:20:11 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:11 --> Input Class Initialized
INFO - 2023-01-15 15:20:11 --> Language Class Initialized
INFO - 2023-01-15 15:20:11 --> Language Class Initialized
INFO - 2023-01-15 15:20:11 --> Config Class Initialized
INFO - 2023-01-15 15:20:11 --> Loader Class Initialized
INFO - 2023-01-15 15:20:11 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:11 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:11 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:11 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:11 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:11 --> Controller Class Initialized
INFO - 2023-01-15 15:20:13 --> Config Class Initialized
INFO - 2023-01-15 15:20:13 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:13 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:13 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:13 --> URI Class Initialized
INFO - 2023-01-15 15:20:13 --> Router Class Initialized
INFO - 2023-01-15 15:20:13 --> Output Class Initialized
INFO - 2023-01-15 15:20:13 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:13 --> Input Class Initialized
INFO - 2023-01-15 15:20:13 --> Language Class Initialized
INFO - 2023-01-15 15:20:13 --> Language Class Initialized
INFO - 2023-01-15 15:20:13 --> Config Class Initialized
INFO - 2023-01-15 15:20:13 --> Loader Class Initialized
INFO - 2023-01-15 15:20:13 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:13 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:13 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:13 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:13 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:13 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-15 15:20:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:13 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:13 --> Total execution time: 0.0572
INFO - 2023-01-15 15:20:29 --> Config Class Initialized
INFO - 2023-01-15 15:20:29 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:29 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:29 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:29 --> URI Class Initialized
INFO - 2023-01-15 15:20:29 --> Router Class Initialized
INFO - 2023-01-15 15:20:29 --> Output Class Initialized
INFO - 2023-01-15 15:20:29 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:29 --> Input Class Initialized
INFO - 2023-01-15 15:20:29 --> Language Class Initialized
INFO - 2023-01-15 15:20:29 --> Language Class Initialized
INFO - 2023-01-15 15:20:29 --> Config Class Initialized
INFO - 2023-01-15 15:20:29 --> Loader Class Initialized
INFO - 2023-01-15 15:20:29 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:29 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:29 --> Controller Class Initialized
INFO - 2023-01-15 15:20:29 --> Config Class Initialized
INFO - 2023-01-15 15:20:29 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:29 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:29 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:29 --> URI Class Initialized
INFO - 2023-01-15 15:20:29 --> Router Class Initialized
INFO - 2023-01-15 15:20:29 --> Output Class Initialized
INFO - 2023-01-15 15:20:29 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:29 --> Input Class Initialized
INFO - 2023-01-15 15:20:29 --> Language Class Initialized
INFO - 2023-01-15 15:20:29 --> Language Class Initialized
INFO - 2023-01-15 15:20:29 --> Config Class Initialized
INFO - 2023-01-15 15:20:29 --> Loader Class Initialized
INFO - 2023-01-15 15:20:29 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:29 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:29 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-15 15:20:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:29 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:29 --> Total execution time: 0.0380
INFO - 2023-01-15 15:20:29 --> Config Class Initialized
INFO - 2023-01-15 15:20:29 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:29 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:29 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:29 --> URI Class Initialized
INFO - 2023-01-15 15:20:29 --> Router Class Initialized
INFO - 2023-01-15 15:20:29 --> Output Class Initialized
INFO - 2023-01-15 15:20:29 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:29 --> Input Class Initialized
INFO - 2023-01-15 15:20:29 --> Language Class Initialized
INFO - 2023-01-15 15:20:29 --> Language Class Initialized
INFO - 2023-01-15 15:20:29 --> Config Class Initialized
INFO - 2023-01-15 15:20:29 --> Loader Class Initialized
INFO - 2023-01-15 15:20:29 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:29 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:29 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:29 --> Controller Class Initialized
INFO - 2023-01-15 15:20:30 --> Config Class Initialized
INFO - 2023-01-15 15:20:30 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:30 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:30 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:30 --> URI Class Initialized
INFO - 2023-01-15 15:20:30 --> Router Class Initialized
INFO - 2023-01-15 15:20:30 --> Output Class Initialized
INFO - 2023-01-15 15:20:30 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:30 --> Input Class Initialized
INFO - 2023-01-15 15:20:30 --> Language Class Initialized
INFO - 2023-01-15 15:20:30 --> Language Class Initialized
INFO - 2023-01-15 15:20:30 --> Config Class Initialized
INFO - 2023-01-15 15:20:30 --> Loader Class Initialized
INFO - 2023-01-15 15:20:30 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:30 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:30 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:30 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:30 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:30 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-15 15:20:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:30 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:30 --> Total execution time: 0.0570
INFO - 2023-01-15 15:20:40 --> Config Class Initialized
INFO - 2023-01-15 15:20:40 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:40 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:40 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:40 --> URI Class Initialized
INFO - 2023-01-15 15:20:40 --> Router Class Initialized
INFO - 2023-01-15 15:20:40 --> Output Class Initialized
INFO - 2023-01-15 15:20:40 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:40 --> Input Class Initialized
INFO - 2023-01-15 15:20:40 --> Language Class Initialized
INFO - 2023-01-15 15:20:40 --> Language Class Initialized
INFO - 2023-01-15 15:20:40 --> Config Class Initialized
INFO - 2023-01-15 15:20:40 --> Loader Class Initialized
INFO - 2023-01-15 15:20:40 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:40 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:40 --> Controller Class Initialized
INFO - 2023-01-15 15:20:40 --> Config Class Initialized
INFO - 2023-01-15 15:20:40 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:40 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:40 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:40 --> URI Class Initialized
INFO - 2023-01-15 15:20:40 --> Router Class Initialized
INFO - 2023-01-15 15:20:40 --> Output Class Initialized
INFO - 2023-01-15 15:20:40 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:40 --> Input Class Initialized
INFO - 2023-01-15 15:20:40 --> Language Class Initialized
INFO - 2023-01-15 15:20:40 --> Language Class Initialized
INFO - 2023-01-15 15:20:40 --> Config Class Initialized
INFO - 2023-01-15 15:20:40 --> Loader Class Initialized
INFO - 2023-01-15 15:20:40 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:40 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:40 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-15 15:20:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:40 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:40 --> Total execution time: 0.0382
INFO - 2023-01-15 15:20:40 --> Config Class Initialized
INFO - 2023-01-15 15:20:40 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:40 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:40 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:40 --> URI Class Initialized
INFO - 2023-01-15 15:20:40 --> Router Class Initialized
INFO - 2023-01-15 15:20:40 --> Output Class Initialized
INFO - 2023-01-15 15:20:40 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:40 --> Input Class Initialized
INFO - 2023-01-15 15:20:40 --> Language Class Initialized
INFO - 2023-01-15 15:20:40 --> Language Class Initialized
INFO - 2023-01-15 15:20:40 --> Config Class Initialized
INFO - 2023-01-15 15:20:40 --> Loader Class Initialized
INFO - 2023-01-15 15:20:40 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:40 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:40 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:40 --> Controller Class Initialized
INFO - 2023-01-15 15:20:41 --> Config Class Initialized
INFO - 2023-01-15 15:20:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:41 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:41 --> URI Class Initialized
INFO - 2023-01-15 15:20:41 --> Router Class Initialized
INFO - 2023-01-15 15:20:41 --> Output Class Initialized
INFO - 2023-01-15 15:20:41 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:41 --> Input Class Initialized
INFO - 2023-01-15 15:20:41 --> Language Class Initialized
INFO - 2023-01-15 15:20:41 --> Language Class Initialized
INFO - 2023-01-15 15:20:41 --> Config Class Initialized
INFO - 2023-01-15 15:20:41 --> Loader Class Initialized
INFO - 2023-01-15 15:20:41 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:41 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:41 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:41 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:41 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-15 15:20:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:41 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:41 --> Total execution time: 0.0395
INFO - 2023-01-15 15:20:50 --> Config Class Initialized
INFO - 2023-01-15 15:20:50 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:50 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:50 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:50 --> URI Class Initialized
INFO - 2023-01-15 15:20:50 --> Router Class Initialized
INFO - 2023-01-15 15:20:50 --> Output Class Initialized
INFO - 2023-01-15 15:20:50 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:50 --> Input Class Initialized
INFO - 2023-01-15 15:20:50 --> Language Class Initialized
INFO - 2023-01-15 15:20:50 --> Language Class Initialized
INFO - 2023-01-15 15:20:50 --> Config Class Initialized
INFO - 2023-01-15 15:20:50 --> Loader Class Initialized
INFO - 2023-01-15 15:20:50 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:50 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:50 --> Controller Class Initialized
INFO - 2023-01-15 15:20:50 --> Config Class Initialized
INFO - 2023-01-15 15:20:50 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:50 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:50 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:50 --> URI Class Initialized
INFO - 2023-01-15 15:20:50 --> Router Class Initialized
INFO - 2023-01-15 15:20:50 --> Output Class Initialized
INFO - 2023-01-15 15:20:50 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:50 --> Input Class Initialized
INFO - 2023-01-15 15:20:50 --> Language Class Initialized
INFO - 2023-01-15 15:20:50 --> Language Class Initialized
INFO - 2023-01-15 15:20:50 --> Config Class Initialized
INFO - 2023-01-15 15:20:50 --> Loader Class Initialized
INFO - 2023-01-15 15:20:50 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:50 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:50 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-15 15:20:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:50 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:50 --> Total execution time: 0.0552
INFO - 2023-01-15 15:20:50 --> Config Class Initialized
INFO - 2023-01-15 15:20:50 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:50 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:50 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:50 --> URI Class Initialized
INFO - 2023-01-15 15:20:50 --> Router Class Initialized
INFO - 2023-01-15 15:20:50 --> Output Class Initialized
INFO - 2023-01-15 15:20:50 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:50 --> Input Class Initialized
INFO - 2023-01-15 15:20:50 --> Language Class Initialized
INFO - 2023-01-15 15:20:50 --> Language Class Initialized
INFO - 2023-01-15 15:20:50 --> Config Class Initialized
INFO - 2023-01-15 15:20:50 --> Loader Class Initialized
INFO - 2023-01-15 15:20:50 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:50 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:50 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:50 --> Controller Class Initialized
INFO - 2023-01-15 15:20:52 --> Config Class Initialized
INFO - 2023-01-15 15:20:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:20:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:20:52 --> Utf8 Class Initialized
INFO - 2023-01-15 15:20:52 --> URI Class Initialized
INFO - 2023-01-15 15:20:52 --> Router Class Initialized
INFO - 2023-01-15 15:20:52 --> Output Class Initialized
INFO - 2023-01-15 15:20:52 --> Security Class Initialized
DEBUG - 2023-01-15 15:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:20:52 --> Input Class Initialized
INFO - 2023-01-15 15:20:52 --> Language Class Initialized
INFO - 2023-01-15 15:20:52 --> Language Class Initialized
INFO - 2023-01-15 15:20:52 --> Config Class Initialized
INFO - 2023-01-15 15:20:52 --> Loader Class Initialized
INFO - 2023-01-15 15:20:52 --> Helper loaded: url_helper
INFO - 2023-01-15 15:20:52 --> Helper loaded: file_helper
INFO - 2023-01-15 15:20:52 --> Helper loaded: form_helper
INFO - 2023-01-15 15:20:52 --> Helper loaded: my_helper
INFO - 2023-01-15 15:20:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:20:52 --> Controller Class Initialized
DEBUG - 2023-01-15 15:20:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-15 15:20:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:20:52 --> Final output sent to browser
DEBUG - 2023-01-15 15:20:52 --> Total execution time: 0.0596
INFO - 2023-01-15 15:21:00 --> Config Class Initialized
INFO - 2023-01-15 15:21:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:00 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:00 --> URI Class Initialized
INFO - 2023-01-15 15:21:00 --> Router Class Initialized
INFO - 2023-01-15 15:21:00 --> Output Class Initialized
INFO - 2023-01-15 15:21:00 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:00 --> Input Class Initialized
INFO - 2023-01-15 15:21:00 --> Language Class Initialized
INFO - 2023-01-15 15:21:00 --> Language Class Initialized
INFO - 2023-01-15 15:21:00 --> Config Class Initialized
INFO - 2023-01-15 15:21:00 --> Loader Class Initialized
INFO - 2023-01-15 15:21:00 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:00 --> Controller Class Initialized
INFO - 2023-01-15 15:21:00 --> Config Class Initialized
INFO - 2023-01-15 15:21:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:00 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:00 --> URI Class Initialized
INFO - 2023-01-15 15:21:00 --> Router Class Initialized
INFO - 2023-01-15 15:21:00 --> Output Class Initialized
INFO - 2023-01-15 15:21:00 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:00 --> Input Class Initialized
INFO - 2023-01-15 15:21:00 --> Language Class Initialized
INFO - 2023-01-15 15:21:00 --> Language Class Initialized
INFO - 2023-01-15 15:21:00 --> Config Class Initialized
INFO - 2023-01-15 15:21:00 --> Loader Class Initialized
INFO - 2023-01-15 15:21:00 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:00 --> Controller Class Initialized
DEBUG - 2023-01-15 15:21:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-15 15:21:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:21:00 --> Final output sent to browser
DEBUG - 2023-01-15 15:21:00 --> Total execution time: 0.0541
INFO - 2023-01-15 15:21:00 --> Config Class Initialized
INFO - 2023-01-15 15:21:00 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:00 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:00 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:00 --> URI Class Initialized
INFO - 2023-01-15 15:21:00 --> Router Class Initialized
INFO - 2023-01-15 15:21:00 --> Output Class Initialized
INFO - 2023-01-15 15:21:00 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:00 --> Input Class Initialized
INFO - 2023-01-15 15:21:00 --> Language Class Initialized
INFO - 2023-01-15 15:21:00 --> Language Class Initialized
INFO - 2023-01-15 15:21:00 --> Config Class Initialized
INFO - 2023-01-15 15:21:00 --> Loader Class Initialized
INFO - 2023-01-15 15:21:00 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:00 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:00 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:00 --> Controller Class Initialized
INFO - 2023-01-15 15:21:08 --> Config Class Initialized
INFO - 2023-01-15 15:21:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:08 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:08 --> URI Class Initialized
INFO - 2023-01-15 15:21:08 --> Router Class Initialized
INFO - 2023-01-15 15:21:08 --> Output Class Initialized
INFO - 2023-01-15 15:21:08 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:08 --> Input Class Initialized
INFO - 2023-01-15 15:21:08 --> Language Class Initialized
INFO - 2023-01-15 15:21:08 --> Language Class Initialized
INFO - 2023-01-15 15:21:08 --> Config Class Initialized
INFO - 2023-01-15 15:21:08 --> Loader Class Initialized
INFO - 2023-01-15 15:21:08 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:08 --> Controller Class Initialized
INFO - 2023-01-15 15:21:08 --> Helper loaded: cookie_helper
INFO - 2023-01-15 15:21:08 --> Config Class Initialized
INFO - 2023-01-15 15:21:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:08 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:08 --> URI Class Initialized
INFO - 2023-01-15 15:21:08 --> Router Class Initialized
INFO - 2023-01-15 15:21:08 --> Output Class Initialized
INFO - 2023-01-15 15:21:08 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:08 --> Input Class Initialized
INFO - 2023-01-15 15:21:08 --> Language Class Initialized
INFO - 2023-01-15 15:21:08 --> Language Class Initialized
INFO - 2023-01-15 15:21:08 --> Config Class Initialized
INFO - 2023-01-15 15:21:08 --> Loader Class Initialized
INFO - 2023-01-15 15:21:08 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:08 --> Controller Class Initialized
INFO - 2023-01-15 15:21:08 --> Config Class Initialized
INFO - 2023-01-15 15:21:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:08 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:08 --> URI Class Initialized
INFO - 2023-01-15 15:21:08 --> Router Class Initialized
INFO - 2023-01-15 15:21:08 --> Output Class Initialized
INFO - 2023-01-15 15:21:08 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:08 --> Input Class Initialized
INFO - 2023-01-15 15:21:08 --> Language Class Initialized
INFO - 2023-01-15 15:21:08 --> Language Class Initialized
INFO - 2023-01-15 15:21:08 --> Config Class Initialized
INFO - 2023-01-15 15:21:08 --> Loader Class Initialized
INFO - 2023-01-15 15:21:08 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:08 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:08 --> Controller Class Initialized
DEBUG - 2023-01-15 15:21:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-15 15:21:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:21:08 --> Final output sent to browser
DEBUG - 2023-01-15 15:21:08 --> Total execution time: 0.0545
INFO - 2023-01-15 15:21:12 --> Config Class Initialized
INFO - 2023-01-15 15:21:12 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:12 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:12 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:12 --> URI Class Initialized
INFO - 2023-01-15 15:21:12 --> Router Class Initialized
INFO - 2023-01-15 15:21:12 --> Output Class Initialized
INFO - 2023-01-15 15:21:12 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:13 --> Input Class Initialized
INFO - 2023-01-15 15:21:13 --> Language Class Initialized
INFO - 2023-01-15 15:21:13 --> Language Class Initialized
INFO - 2023-01-15 15:21:13 --> Config Class Initialized
INFO - 2023-01-15 15:21:13 --> Loader Class Initialized
INFO - 2023-01-15 15:21:13 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:13 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:13 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:13 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:13 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:13 --> Controller Class Initialized
INFO - 2023-01-15 15:21:13 --> Helper loaded: cookie_helper
INFO - 2023-01-15 15:21:13 --> Final output sent to browser
DEBUG - 2023-01-15 15:21:13 --> Total execution time: 0.0564
INFO - 2023-01-15 15:21:13 --> Config Class Initialized
INFO - 2023-01-15 15:21:13 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:13 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:13 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:13 --> URI Class Initialized
INFO - 2023-01-15 15:21:13 --> Router Class Initialized
INFO - 2023-01-15 15:21:13 --> Output Class Initialized
INFO - 2023-01-15 15:21:13 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:13 --> Input Class Initialized
INFO - 2023-01-15 15:21:13 --> Language Class Initialized
INFO - 2023-01-15 15:21:13 --> Language Class Initialized
INFO - 2023-01-15 15:21:13 --> Config Class Initialized
INFO - 2023-01-15 15:21:13 --> Loader Class Initialized
INFO - 2023-01-15 15:21:13 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:13 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:13 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:13 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:13 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:13 --> Controller Class Initialized
DEBUG - 2023-01-15 15:21:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-15 15:21:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:21:13 --> Final output sent to browser
DEBUG - 2023-01-15 15:21:13 --> Total execution time: 0.0448
INFO - 2023-01-15 15:21:15 --> Config Class Initialized
INFO - 2023-01-15 15:21:15 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:21:15 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:21:15 --> Utf8 Class Initialized
INFO - 2023-01-15 15:21:15 --> URI Class Initialized
INFO - 2023-01-15 15:21:15 --> Router Class Initialized
INFO - 2023-01-15 15:21:15 --> Output Class Initialized
INFO - 2023-01-15 15:21:15 --> Security Class Initialized
DEBUG - 2023-01-15 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:21:15 --> Input Class Initialized
INFO - 2023-01-15 15:21:15 --> Language Class Initialized
INFO - 2023-01-15 15:21:15 --> Language Class Initialized
INFO - 2023-01-15 15:21:15 --> Config Class Initialized
INFO - 2023-01-15 15:21:15 --> Loader Class Initialized
INFO - 2023-01-15 15:21:15 --> Helper loaded: url_helper
INFO - 2023-01-15 15:21:15 --> Helper loaded: file_helper
INFO - 2023-01-15 15:21:15 --> Helper loaded: form_helper
INFO - 2023-01-15 15:21:15 --> Helper loaded: my_helper
INFO - 2023-01-15 15:21:15 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:21:16 --> Controller Class Initialized
DEBUG - 2023-01-15 15:21:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:21:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:21:16 --> Final output sent to browser
DEBUG - 2023-01-15 15:21:16 --> Total execution time: 0.0561
INFO - 2023-01-15 15:22:19 --> Config Class Initialized
INFO - 2023-01-15 15:22:19 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:22:19 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:22:19 --> Utf8 Class Initialized
INFO - 2023-01-15 15:22:19 --> URI Class Initialized
INFO - 2023-01-15 15:22:19 --> Router Class Initialized
INFO - 2023-01-15 15:22:19 --> Output Class Initialized
INFO - 2023-01-15 15:22:19 --> Security Class Initialized
DEBUG - 2023-01-15 15:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:22:19 --> Input Class Initialized
INFO - 2023-01-15 15:22:19 --> Language Class Initialized
INFO - 2023-01-15 15:22:19 --> Language Class Initialized
INFO - 2023-01-15 15:22:19 --> Config Class Initialized
INFO - 2023-01-15 15:22:19 --> Loader Class Initialized
INFO - 2023-01-15 15:22:19 --> Helper loaded: url_helper
INFO - 2023-01-15 15:22:19 --> Helper loaded: file_helper
INFO - 2023-01-15 15:22:19 --> Helper loaded: form_helper
INFO - 2023-01-15 15:22:19 --> Helper loaded: my_helper
INFO - 2023-01-15 15:22:19 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:22:19 --> Controller Class Initialized
DEBUG - 2023-01-15 15:22:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:22:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:22:19 --> Final output sent to browser
DEBUG - 2023-01-15 15:22:19 --> Total execution time: 0.0407
INFO - 2023-01-15 15:22:59 --> Config Class Initialized
INFO - 2023-01-15 15:22:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:22:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:22:59 --> Utf8 Class Initialized
INFO - 2023-01-15 15:22:59 --> URI Class Initialized
INFO - 2023-01-15 15:22:59 --> Router Class Initialized
INFO - 2023-01-15 15:22:59 --> Output Class Initialized
INFO - 2023-01-15 15:22:59 --> Security Class Initialized
DEBUG - 2023-01-15 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:22:59 --> Input Class Initialized
INFO - 2023-01-15 15:22:59 --> Language Class Initialized
INFO - 2023-01-15 15:22:59 --> Language Class Initialized
INFO - 2023-01-15 15:22:59 --> Config Class Initialized
INFO - 2023-01-15 15:22:59 --> Loader Class Initialized
INFO - 2023-01-15 15:22:59 --> Helper loaded: url_helper
INFO - 2023-01-15 15:22:59 --> Helper loaded: file_helper
INFO - 2023-01-15 15:22:59 --> Helper loaded: form_helper
INFO - 2023-01-15 15:22:59 --> Helper loaded: my_helper
INFO - 2023-01-15 15:22:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:22:59 --> Controller Class Initialized
DEBUG - 2023-01-15 15:22:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 15:22:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:22:59 --> Final output sent to browser
DEBUG - 2023-01-15 15:22:59 --> Total execution time: 0.0583
INFO - 2023-01-15 15:22:59 --> Config Class Initialized
INFO - 2023-01-15 15:22:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:22:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:22:59 --> Utf8 Class Initialized
INFO - 2023-01-15 15:22:59 --> URI Class Initialized
INFO - 2023-01-15 15:22:59 --> Router Class Initialized
INFO - 2023-01-15 15:22:59 --> Output Class Initialized
INFO - 2023-01-15 15:22:59 --> Security Class Initialized
DEBUG - 2023-01-15 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:22:59 --> Input Class Initialized
INFO - 2023-01-15 15:22:59 --> Language Class Initialized
INFO - 2023-01-15 15:22:59 --> Language Class Initialized
INFO - 2023-01-15 15:22:59 --> Config Class Initialized
INFO - 2023-01-15 15:22:59 --> Loader Class Initialized
INFO - 2023-01-15 15:22:59 --> Helper loaded: url_helper
INFO - 2023-01-15 15:22:59 --> Helper loaded: file_helper
INFO - 2023-01-15 15:22:59 --> Helper loaded: form_helper
INFO - 2023-01-15 15:22:59 --> Helper loaded: my_helper
INFO - 2023-01-15 15:22:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:22:59 --> Controller Class Initialized
INFO - 2023-01-15 15:23:24 --> Config Class Initialized
INFO - 2023-01-15 15:23:24 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:23:24 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:23:24 --> Utf8 Class Initialized
INFO - 2023-01-15 15:23:24 --> URI Class Initialized
INFO - 2023-01-15 15:23:24 --> Router Class Initialized
INFO - 2023-01-15 15:23:24 --> Output Class Initialized
INFO - 2023-01-15 15:23:24 --> Security Class Initialized
DEBUG - 2023-01-15 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:23:24 --> Input Class Initialized
INFO - 2023-01-15 15:23:24 --> Language Class Initialized
INFO - 2023-01-15 15:23:24 --> Language Class Initialized
INFO - 2023-01-15 15:23:24 --> Config Class Initialized
INFO - 2023-01-15 15:23:24 --> Loader Class Initialized
INFO - 2023-01-15 15:23:24 --> Helper loaded: url_helper
INFO - 2023-01-15 15:23:24 --> Helper loaded: file_helper
INFO - 2023-01-15 15:23:24 --> Helper loaded: form_helper
INFO - 2023-01-15 15:23:24 --> Helper loaded: my_helper
INFO - 2023-01-15 15:23:24 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:23:24 --> Controller Class Initialized
DEBUG - 2023-01-15 15:23:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:23:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:23:24 --> Final output sent to browser
DEBUG - 2023-01-15 15:23:24 --> Total execution time: 0.0565
INFO - 2023-01-15 15:26:07 --> Config Class Initialized
INFO - 2023-01-15 15:26:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:26:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:26:07 --> Utf8 Class Initialized
INFO - 2023-01-15 15:26:07 --> URI Class Initialized
INFO - 2023-01-15 15:26:07 --> Router Class Initialized
INFO - 2023-01-15 15:26:07 --> Output Class Initialized
INFO - 2023-01-15 15:26:07 --> Security Class Initialized
DEBUG - 2023-01-15 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:26:07 --> Input Class Initialized
INFO - 2023-01-15 15:26:07 --> Language Class Initialized
INFO - 2023-01-15 15:26:07 --> Language Class Initialized
INFO - 2023-01-15 15:26:07 --> Config Class Initialized
INFO - 2023-01-15 15:26:07 --> Loader Class Initialized
INFO - 2023-01-15 15:26:07 --> Helper loaded: url_helper
INFO - 2023-01-15 15:26:07 --> Helper loaded: file_helper
INFO - 2023-01-15 15:26:07 --> Helper loaded: form_helper
INFO - 2023-01-15 15:26:07 --> Helper loaded: my_helper
INFO - 2023-01-15 15:26:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:26:07 --> Controller Class Initialized
DEBUG - 2023-01-15 15:26:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 15:26:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:26:07 --> Final output sent to browser
DEBUG - 2023-01-15 15:26:07 --> Total execution time: 0.0596
INFO - 2023-01-15 15:26:07 --> Config Class Initialized
INFO - 2023-01-15 15:26:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:26:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:26:07 --> Utf8 Class Initialized
INFO - 2023-01-15 15:26:07 --> URI Class Initialized
INFO - 2023-01-15 15:26:07 --> Router Class Initialized
INFO - 2023-01-15 15:26:07 --> Output Class Initialized
INFO - 2023-01-15 15:26:07 --> Security Class Initialized
DEBUG - 2023-01-15 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:26:07 --> Input Class Initialized
INFO - 2023-01-15 15:26:07 --> Language Class Initialized
INFO - 2023-01-15 15:26:07 --> Language Class Initialized
INFO - 2023-01-15 15:26:07 --> Config Class Initialized
INFO - 2023-01-15 15:26:07 --> Loader Class Initialized
INFO - 2023-01-15 15:26:07 --> Helper loaded: url_helper
INFO - 2023-01-15 15:26:07 --> Helper loaded: file_helper
INFO - 2023-01-15 15:26:07 --> Helper loaded: form_helper
INFO - 2023-01-15 15:26:07 --> Helper loaded: my_helper
INFO - 2023-01-15 15:26:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:26:07 --> Controller Class Initialized
INFO - 2023-01-15 15:26:14 --> Config Class Initialized
INFO - 2023-01-15 15:26:14 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:26:14 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:26:14 --> Utf8 Class Initialized
INFO - 2023-01-15 15:26:14 --> URI Class Initialized
INFO - 2023-01-15 15:26:14 --> Router Class Initialized
INFO - 2023-01-15 15:26:14 --> Output Class Initialized
INFO - 2023-01-15 15:26:14 --> Security Class Initialized
DEBUG - 2023-01-15 15:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:26:14 --> Input Class Initialized
INFO - 2023-01-15 15:26:14 --> Language Class Initialized
INFO - 2023-01-15 15:26:14 --> Language Class Initialized
INFO - 2023-01-15 15:26:14 --> Config Class Initialized
INFO - 2023-01-15 15:26:14 --> Loader Class Initialized
INFO - 2023-01-15 15:26:14 --> Helper loaded: url_helper
INFO - 2023-01-15 15:26:14 --> Helper loaded: file_helper
INFO - 2023-01-15 15:26:14 --> Helper loaded: form_helper
INFO - 2023-01-15 15:26:14 --> Helper loaded: my_helper
INFO - 2023-01-15 15:26:14 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:26:14 --> Controller Class Initialized
DEBUG - 2023-01-15 15:26:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:26:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:26:14 --> Final output sent to browser
DEBUG - 2023-01-15 15:26:14 --> Total execution time: 0.0579
INFO - 2023-01-15 15:26:23 --> Config Class Initialized
INFO - 2023-01-15 15:26:23 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:26:23 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:26:23 --> Utf8 Class Initialized
INFO - 2023-01-15 15:26:23 --> URI Class Initialized
INFO - 2023-01-15 15:26:23 --> Router Class Initialized
INFO - 2023-01-15 15:26:23 --> Output Class Initialized
INFO - 2023-01-15 15:26:23 --> Security Class Initialized
DEBUG - 2023-01-15 15:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:26:23 --> Input Class Initialized
INFO - 2023-01-15 15:26:23 --> Language Class Initialized
INFO - 2023-01-15 15:26:23 --> Language Class Initialized
INFO - 2023-01-15 15:26:23 --> Config Class Initialized
INFO - 2023-01-15 15:26:23 --> Loader Class Initialized
INFO - 2023-01-15 15:26:23 --> Helper loaded: url_helper
INFO - 2023-01-15 15:26:23 --> Helper loaded: file_helper
INFO - 2023-01-15 15:26:23 --> Helper loaded: form_helper
INFO - 2023-01-15 15:26:23 --> Helper loaded: my_helper
INFO - 2023-01-15 15:26:23 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:26:23 --> Controller Class Initialized
DEBUG - 2023-01-15 15:26:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 15:26:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:26:23 --> Final output sent to browser
DEBUG - 2023-01-15 15:26:23 --> Total execution time: 0.0388
INFO - 2023-01-15 15:26:23 --> Config Class Initialized
INFO - 2023-01-15 15:26:23 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:26:23 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:26:23 --> Utf8 Class Initialized
INFO - 2023-01-15 15:26:23 --> URI Class Initialized
INFO - 2023-01-15 15:26:23 --> Router Class Initialized
INFO - 2023-01-15 15:26:23 --> Output Class Initialized
INFO - 2023-01-15 15:26:23 --> Security Class Initialized
DEBUG - 2023-01-15 15:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:26:23 --> Input Class Initialized
INFO - 2023-01-15 15:26:23 --> Language Class Initialized
INFO - 2023-01-15 15:26:23 --> Language Class Initialized
INFO - 2023-01-15 15:26:23 --> Config Class Initialized
INFO - 2023-01-15 15:26:23 --> Loader Class Initialized
INFO - 2023-01-15 15:26:23 --> Helper loaded: url_helper
INFO - 2023-01-15 15:26:23 --> Helper loaded: file_helper
INFO - 2023-01-15 15:26:23 --> Helper loaded: form_helper
INFO - 2023-01-15 15:26:23 --> Helper loaded: my_helper
INFO - 2023-01-15 15:26:23 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:26:23 --> Controller Class Initialized
INFO - 2023-01-15 15:29:28 --> Config Class Initialized
INFO - 2023-01-15 15:29:28 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:29:28 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:29:28 --> Utf8 Class Initialized
INFO - 2023-01-15 15:29:28 --> URI Class Initialized
INFO - 2023-01-15 15:29:28 --> Router Class Initialized
INFO - 2023-01-15 15:29:28 --> Output Class Initialized
INFO - 2023-01-15 15:29:28 --> Security Class Initialized
DEBUG - 2023-01-15 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:29:28 --> Input Class Initialized
INFO - 2023-01-15 15:29:28 --> Language Class Initialized
INFO - 2023-01-15 15:29:28 --> Language Class Initialized
INFO - 2023-01-15 15:29:28 --> Config Class Initialized
INFO - 2023-01-15 15:29:28 --> Loader Class Initialized
INFO - 2023-01-15 15:29:28 --> Helper loaded: url_helper
INFO - 2023-01-15 15:29:28 --> Helper loaded: file_helper
INFO - 2023-01-15 15:29:28 --> Helper loaded: form_helper
INFO - 2023-01-15 15:29:28 --> Helper loaded: my_helper
INFO - 2023-01-15 15:29:28 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:29:28 --> Controller Class Initialized
DEBUG - 2023-01-15 15:29:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:29:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:29:28 --> Final output sent to browser
DEBUG - 2023-01-15 15:29:28 --> Total execution time: 0.0582
INFO - 2023-01-15 15:29:30 --> Config Class Initialized
INFO - 2023-01-15 15:29:30 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:29:30 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:29:30 --> Utf8 Class Initialized
INFO - 2023-01-15 15:29:30 --> URI Class Initialized
INFO - 2023-01-15 15:29:30 --> Router Class Initialized
INFO - 2023-01-15 15:29:30 --> Output Class Initialized
INFO - 2023-01-15 15:29:30 --> Security Class Initialized
DEBUG - 2023-01-15 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:29:30 --> Input Class Initialized
INFO - 2023-01-15 15:29:30 --> Language Class Initialized
INFO - 2023-01-15 15:29:30 --> Language Class Initialized
INFO - 2023-01-15 15:29:30 --> Config Class Initialized
INFO - 2023-01-15 15:29:30 --> Loader Class Initialized
INFO - 2023-01-15 15:29:30 --> Helper loaded: url_helper
INFO - 2023-01-15 15:29:30 --> Helper loaded: file_helper
INFO - 2023-01-15 15:29:30 --> Helper loaded: form_helper
INFO - 2023-01-15 15:29:30 --> Helper loaded: my_helper
INFO - 2023-01-15 15:29:30 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:29:30 --> Controller Class Initialized
DEBUG - 2023-01-15 15:29:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:29:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:29:30 --> Final output sent to browser
DEBUG - 2023-01-15 15:29:30 --> Total execution time: 0.0419
INFO - 2023-01-15 15:29:49 --> Config Class Initialized
INFO - 2023-01-15 15:29:49 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:29:49 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:29:49 --> Utf8 Class Initialized
INFO - 2023-01-15 15:29:49 --> URI Class Initialized
INFO - 2023-01-15 15:29:49 --> Router Class Initialized
INFO - 2023-01-15 15:29:49 --> Output Class Initialized
INFO - 2023-01-15 15:29:49 --> Security Class Initialized
DEBUG - 2023-01-15 15:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:29:49 --> Input Class Initialized
INFO - 2023-01-15 15:29:49 --> Language Class Initialized
INFO - 2023-01-15 15:29:49 --> Language Class Initialized
INFO - 2023-01-15 15:29:49 --> Config Class Initialized
INFO - 2023-01-15 15:29:49 --> Loader Class Initialized
INFO - 2023-01-15 15:29:49 --> Helper loaded: url_helper
INFO - 2023-01-15 15:29:49 --> Helper loaded: file_helper
INFO - 2023-01-15 15:29:49 --> Helper loaded: form_helper
INFO - 2023-01-15 15:29:49 --> Helper loaded: my_helper
INFO - 2023-01-15 15:29:49 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:29:49 --> Controller Class Initialized
DEBUG - 2023-01-15 15:29:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:29:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:29:49 --> Final output sent to browser
DEBUG - 2023-01-15 15:29:49 --> Total execution time: 0.0569
INFO - 2023-01-15 15:30:04 --> Config Class Initialized
INFO - 2023-01-15 15:30:04 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:30:04 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:30:04 --> Utf8 Class Initialized
INFO - 2023-01-15 15:30:04 --> URI Class Initialized
INFO - 2023-01-15 15:30:04 --> Router Class Initialized
INFO - 2023-01-15 15:30:04 --> Output Class Initialized
INFO - 2023-01-15 15:30:04 --> Security Class Initialized
DEBUG - 2023-01-15 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:30:04 --> Input Class Initialized
INFO - 2023-01-15 15:30:04 --> Language Class Initialized
INFO - 2023-01-15 15:30:04 --> Language Class Initialized
INFO - 2023-01-15 15:30:04 --> Config Class Initialized
INFO - 2023-01-15 15:30:04 --> Loader Class Initialized
INFO - 2023-01-15 15:30:04 --> Helper loaded: url_helper
INFO - 2023-01-15 15:30:04 --> Helper loaded: file_helper
INFO - 2023-01-15 15:30:04 --> Helper loaded: form_helper
INFO - 2023-01-15 15:30:04 --> Helper loaded: my_helper
INFO - 2023-01-15 15:30:04 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:30:05 --> Controller Class Initialized
DEBUG - 2023-01-15 15:30:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:30:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:30:05 --> Final output sent to browser
DEBUG - 2023-01-15 15:30:05 --> Total execution time: 0.0597
INFO - 2023-01-15 15:30:40 --> Config Class Initialized
INFO - 2023-01-15 15:30:40 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:30:40 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:30:40 --> Utf8 Class Initialized
INFO - 2023-01-15 15:30:40 --> URI Class Initialized
INFO - 2023-01-15 15:30:40 --> Router Class Initialized
INFO - 2023-01-15 15:30:40 --> Output Class Initialized
INFO - 2023-01-15 15:30:40 --> Security Class Initialized
DEBUG - 2023-01-15 15:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:30:40 --> Input Class Initialized
INFO - 2023-01-15 15:30:40 --> Language Class Initialized
INFO - 2023-01-15 15:30:40 --> Language Class Initialized
INFO - 2023-01-15 15:30:40 --> Config Class Initialized
INFO - 2023-01-15 15:30:40 --> Loader Class Initialized
INFO - 2023-01-15 15:30:40 --> Helper loaded: url_helper
INFO - 2023-01-15 15:30:40 --> Helper loaded: file_helper
INFO - 2023-01-15 15:30:40 --> Helper loaded: form_helper
INFO - 2023-01-15 15:30:40 --> Helper loaded: my_helper
INFO - 2023-01-15 15:30:40 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:30:40 --> Controller Class Initialized
DEBUG - 2023-01-15 15:30:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 15:30:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:30:40 --> Final output sent to browser
DEBUG - 2023-01-15 15:30:40 --> Total execution time: 0.0574
INFO - 2023-01-15 15:32:20 --> Config Class Initialized
INFO - 2023-01-15 15:32:20 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:32:20 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:32:20 --> Utf8 Class Initialized
INFO - 2023-01-15 15:32:20 --> URI Class Initialized
INFO - 2023-01-15 15:32:20 --> Router Class Initialized
INFO - 2023-01-15 15:32:20 --> Output Class Initialized
INFO - 2023-01-15 15:32:20 --> Security Class Initialized
DEBUG - 2023-01-15 15:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:32:20 --> Input Class Initialized
INFO - 2023-01-15 15:32:20 --> Language Class Initialized
INFO - 2023-01-15 15:32:20 --> Language Class Initialized
INFO - 2023-01-15 15:32:20 --> Config Class Initialized
INFO - 2023-01-15 15:32:20 --> Loader Class Initialized
INFO - 2023-01-15 15:32:20 --> Helper loaded: url_helper
INFO - 2023-01-15 15:32:20 --> Helper loaded: file_helper
INFO - 2023-01-15 15:32:20 --> Helper loaded: form_helper
INFO - 2023-01-15 15:32:20 --> Helper loaded: my_helper
INFO - 2023-01-15 15:32:20 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:32:20 --> Controller Class Initialized
DEBUG - 2023-01-15 15:32:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 15:32:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:32:20 --> Final output sent to browser
DEBUG - 2023-01-15 15:32:20 --> Total execution time: 0.0400
INFO - 2023-01-15 15:32:20 --> Config Class Initialized
INFO - 2023-01-15 15:32:20 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:32:20 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:32:20 --> Utf8 Class Initialized
INFO - 2023-01-15 15:32:20 --> URI Class Initialized
INFO - 2023-01-15 15:32:20 --> Router Class Initialized
INFO - 2023-01-15 15:32:20 --> Output Class Initialized
INFO - 2023-01-15 15:32:20 --> Security Class Initialized
DEBUG - 2023-01-15 15:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:32:20 --> Input Class Initialized
INFO - 2023-01-15 15:32:20 --> Language Class Initialized
INFO - 2023-01-15 15:32:20 --> Language Class Initialized
INFO - 2023-01-15 15:32:20 --> Config Class Initialized
INFO - 2023-01-15 15:32:20 --> Loader Class Initialized
INFO - 2023-01-15 15:32:20 --> Helper loaded: url_helper
INFO - 2023-01-15 15:32:20 --> Helper loaded: file_helper
INFO - 2023-01-15 15:32:20 --> Helper loaded: form_helper
INFO - 2023-01-15 15:32:20 --> Helper loaded: my_helper
INFO - 2023-01-15 15:32:20 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:32:20 --> Controller Class Initialized
INFO - 2023-01-15 15:32:27 --> Config Class Initialized
INFO - 2023-01-15 15:32:27 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:32:27 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:32:27 --> Utf8 Class Initialized
INFO - 2023-01-15 15:32:27 --> URI Class Initialized
INFO - 2023-01-15 15:32:27 --> Router Class Initialized
INFO - 2023-01-15 15:32:27 --> Output Class Initialized
INFO - 2023-01-15 15:32:27 --> Security Class Initialized
DEBUG - 2023-01-15 15:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:32:27 --> Input Class Initialized
INFO - 2023-01-15 15:32:27 --> Language Class Initialized
INFO - 2023-01-15 15:32:27 --> Language Class Initialized
INFO - 2023-01-15 15:32:27 --> Config Class Initialized
INFO - 2023-01-15 15:32:27 --> Loader Class Initialized
INFO - 2023-01-15 15:32:27 --> Helper loaded: url_helper
INFO - 2023-01-15 15:32:27 --> Helper loaded: file_helper
INFO - 2023-01-15 15:32:27 --> Helper loaded: form_helper
INFO - 2023-01-15 15:32:27 --> Helper loaded: my_helper
INFO - 2023-01-15 15:32:27 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:32:27 --> Controller Class Initialized
INFO - 2023-01-15 15:33:27 --> Config Class Initialized
INFO - 2023-01-15 15:33:27 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:33:27 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:33:27 --> Utf8 Class Initialized
INFO - 2023-01-15 15:33:27 --> URI Class Initialized
INFO - 2023-01-15 15:33:27 --> Router Class Initialized
INFO - 2023-01-15 15:33:27 --> Output Class Initialized
INFO - 2023-01-15 15:33:27 --> Security Class Initialized
DEBUG - 2023-01-15 15:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:33:27 --> Input Class Initialized
INFO - 2023-01-15 15:33:27 --> Language Class Initialized
INFO - 2023-01-15 15:33:27 --> Language Class Initialized
INFO - 2023-01-15 15:33:27 --> Config Class Initialized
INFO - 2023-01-15 15:33:27 --> Loader Class Initialized
INFO - 2023-01-15 15:33:27 --> Helper loaded: url_helper
INFO - 2023-01-15 15:33:27 --> Helper loaded: file_helper
INFO - 2023-01-15 15:33:27 --> Helper loaded: form_helper
INFO - 2023-01-15 15:33:27 --> Helper loaded: my_helper
INFO - 2023-01-15 15:33:27 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:33:27 --> Controller Class Initialized
DEBUG - 2023-01-15 15:33:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 15:33:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:33:27 --> Final output sent to browser
DEBUG - 2023-01-15 15:33:27 --> Total execution time: 0.0720
INFO - 2023-01-15 15:33:30 --> Config Class Initialized
INFO - 2023-01-15 15:33:30 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:33:30 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:33:30 --> Utf8 Class Initialized
INFO - 2023-01-15 15:33:30 --> URI Class Initialized
INFO - 2023-01-15 15:33:30 --> Router Class Initialized
INFO - 2023-01-15 15:33:30 --> Output Class Initialized
INFO - 2023-01-15 15:33:30 --> Security Class Initialized
DEBUG - 2023-01-15 15:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:33:30 --> Input Class Initialized
INFO - 2023-01-15 15:33:30 --> Language Class Initialized
ERROR - 2023-01-15 15:33:30 --> 404 Page Not Found: /index
INFO - 2023-01-15 15:44:47 --> Config Class Initialized
INFO - 2023-01-15 15:44:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:44:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:44:47 --> Utf8 Class Initialized
INFO - 2023-01-15 15:44:47 --> URI Class Initialized
INFO - 2023-01-15 15:44:47 --> Router Class Initialized
INFO - 2023-01-15 15:44:47 --> Output Class Initialized
INFO - 2023-01-15 15:44:47 --> Security Class Initialized
DEBUG - 2023-01-15 15:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:44:47 --> Input Class Initialized
INFO - 2023-01-15 15:44:47 --> Language Class Initialized
INFO - 2023-01-15 15:44:47 --> Language Class Initialized
INFO - 2023-01-15 15:44:47 --> Config Class Initialized
INFO - 2023-01-15 15:44:47 --> Loader Class Initialized
INFO - 2023-01-15 15:44:47 --> Helper loaded: url_helper
INFO - 2023-01-15 15:44:47 --> Helper loaded: file_helper
INFO - 2023-01-15 15:44:47 --> Helper loaded: form_helper
INFO - 2023-01-15 15:44:47 --> Helper loaded: my_helper
INFO - 2023-01-15 15:44:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:44:47 --> Controller Class Initialized
DEBUG - 2023-01-15 15:44:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 15:44:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 15:44:47 --> Final output sent to browser
DEBUG - 2023-01-15 15:44:47 --> Total execution time: 0.0426
INFO - 2023-01-15 15:44:47 --> Config Class Initialized
INFO - 2023-01-15 15:44:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:44:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:44:47 --> Utf8 Class Initialized
INFO - 2023-01-15 15:44:47 --> URI Class Initialized
INFO - 2023-01-15 15:44:47 --> Router Class Initialized
INFO - 2023-01-15 15:44:47 --> Output Class Initialized
INFO - 2023-01-15 15:44:47 --> Security Class Initialized
DEBUG - 2023-01-15 15:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:44:47 --> Input Class Initialized
INFO - 2023-01-15 15:44:47 --> Language Class Initialized
ERROR - 2023-01-15 15:44:47 --> 404 Page Not Found: /index
INFO - 2023-01-15 15:44:47 --> Config Class Initialized
INFO - 2023-01-15 15:44:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:44:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:44:47 --> Utf8 Class Initialized
INFO - 2023-01-15 15:44:47 --> URI Class Initialized
INFO - 2023-01-15 15:44:47 --> Router Class Initialized
INFO - 2023-01-15 15:44:47 --> Output Class Initialized
INFO - 2023-01-15 15:44:47 --> Security Class Initialized
DEBUG - 2023-01-15 15:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:44:47 --> Input Class Initialized
INFO - 2023-01-15 15:44:47 --> Language Class Initialized
INFO - 2023-01-15 15:44:47 --> Language Class Initialized
INFO - 2023-01-15 15:44:47 --> Config Class Initialized
INFO - 2023-01-15 15:44:47 --> Loader Class Initialized
INFO - 2023-01-15 15:44:47 --> Helper loaded: url_helper
INFO - 2023-01-15 15:44:47 --> Helper loaded: file_helper
INFO - 2023-01-15 15:44:47 --> Helper loaded: form_helper
INFO - 2023-01-15 15:44:47 --> Helper loaded: my_helper
INFO - 2023-01-15 15:44:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:44:47 --> Controller Class Initialized
INFO - 2023-01-15 15:49:07 --> Config Class Initialized
INFO - 2023-01-15 15:49:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 15:49:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 15:49:07 --> Utf8 Class Initialized
INFO - 2023-01-15 15:49:07 --> URI Class Initialized
INFO - 2023-01-15 15:49:07 --> Router Class Initialized
INFO - 2023-01-15 15:49:07 --> Output Class Initialized
INFO - 2023-01-15 15:49:07 --> Security Class Initialized
DEBUG - 2023-01-15 15:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 15:49:07 --> Input Class Initialized
INFO - 2023-01-15 15:49:07 --> Language Class Initialized
INFO - 2023-01-15 15:49:07 --> Language Class Initialized
INFO - 2023-01-15 15:49:07 --> Config Class Initialized
INFO - 2023-01-15 15:49:07 --> Loader Class Initialized
INFO - 2023-01-15 15:49:07 --> Helper loaded: url_helper
INFO - 2023-01-15 15:49:07 --> Helper loaded: file_helper
INFO - 2023-01-15 15:49:07 --> Helper loaded: form_helper
INFO - 2023-01-15 15:49:07 --> Helper loaded: my_helper
INFO - 2023-01-15 15:49:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 15:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 15:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 15:49:07 --> Controller Class Initialized
INFO - 2023-01-15 16:01:18 --> Config Class Initialized
INFO - 2023-01-15 16:01:18 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:18 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:18 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:18 --> URI Class Initialized
INFO - 2023-01-15 16:01:19 --> Router Class Initialized
INFO - 2023-01-15 16:01:19 --> Output Class Initialized
INFO - 2023-01-15 16:01:19 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:19 --> Input Class Initialized
INFO - 2023-01-15 16:01:19 --> Language Class Initialized
INFO - 2023-01-15 16:01:19 --> Language Class Initialized
INFO - 2023-01-15 16:01:19 --> Config Class Initialized
INFO - 2023-01-15 16:01:19 --> Loader Class Initialized
INFO - 2023-01-15 16:01:19 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:19 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:19 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:19 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:19 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:19 --> Controller Class Initialized
DEBUG - 2023-01-15 16:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:01:19 --> Final output sent to browser
DEBUG - 2023-01-15 16:01:19 --> Total execution time: 0.0591
INFO - 2023-01-15 16:01:25 --> Config Class Initialized
INFO - 2023-01-15 16:01:25 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:25 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:25 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:25 --> URI Class Initialized
INFO - 2023-01-15 16:01:25 --> Router Class Initialized
INFO - 2023-01-15 16:01:25 --> Output Class Initialized
INFO - 2023-01-15 16:01:25 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:25 --> Input Class Initialized
INFO - 2023-01-15 16:01:25 --> Language Class Initialized
INFO - 2023-01-15 16:01:25 --> Language Class Initialized
INFO - 2023-01-15 16:01:25 --> Config Class Initialized
INFO - 2023-01-15 16:01:25 --> Loader Class Initialized
INFO - 2023-01-15 16:01:25 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:25 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:25 --> Controller Class Initialized
INFO - 2023-01-15 16:01:25 --> Config Class Initialized
INFO - 2023-01-15 16:01:25 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:25 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:25 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:25 --> URI Class Initialized
INFO - 2023-01-15 16:01:25 --> Router Class Initialized
INFO - 2023-01-15 16:01:25 --> Output Class Initialized
INFO - 2023-01-15 16:01:25 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:25 --> Input Class Initialized
INFO - 2023-01-15 16:01:25 --> Language Class Initialized
INFO - 2023-01-15 16:01:25 --> Language Class Initialized
INFO - 2023-01-15 16:01:25 --> Config Class Initialized
INFO - 2023-01-15 16:01:25 --> Loader Class Initialized
INFO - 2023-01-15 16:01:25 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:25 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:25 --> Controller Class Initialized
DEBUG - 2023-01-15 16:01:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-15 16:01:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:01:25 --> Final output sent to browser
DEBUG - 2023-01-15 16:01:25 --> Total execution time: 0.0978
INFO - 2023-01-15 16:01:25 --> Config Class Initialized
INFO - 2023-01-15 16:01:25 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:25 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:25 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:25 --> URI Class Initialized
INFO - 2023-01-15 16:01:25 --> Router Class Initialized
INFO - 2023-01-15 16:01:25 --> Output Class Initialized
INFO - 2023-01-15 16:01:25 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:25 --> Input Class Initialized
INFO - 2023-01-15 16:01:25 --> Language Class Initialized
INFO - 2023-01-15 16:01:25 --> Language Class Initialized
INFO - 2023-01-15 16:01:25 --> Config Class Initialized
INFO - 2023-01-15 16:01:25 --> Loader Class Initialized
INFO - 2023-01-15 16:01:25 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:25 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:25 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:25 --> Controller Class Initialized
INFO - 2023-01-15 16:01:33 --> Config Class Initialized
INFO - 2023-01-15 16:01:33 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:33 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:33 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:33 --> URI Class Initialized
INFO - 2023-01-15 16:01:33 --> Router Class Initialized
INFO - 2023-01-15 16:01:33 --> Output Class Initialized
INFO - 2023-01-15 16:01:33 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:33 --> Input Class Initialized
INFO - 2023-01-15 16:01:33 --> Language Class Initialized
INFO - 2023-01-15 16:01:33 --> Language Class Initialized
INFO - 2023-01-15 16:01:33 --> Config Class Initialized
INFO - 2023-01-15 16:01:33 --> Loader Class Initialized
INFO - 2023-01-15 16:01:33 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:33 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:33 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:33 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:33 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:33 --> Controller Class Initialized
DEBUG - 2023-01-15 16:01:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-15 16:01:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:01:33 --> Final output sent to browser
DEBUG - 2023-01-15 16:01:33 --> Total execution time: 0.0436
INFO - 2023-01-15 16:01:36 --> Config Class Initialized
INFO - 2023-01-15 16:01:36 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:36 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:36 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:36 --> URI Class Initialized
INFO - 2023-01-15 16:01:36 --> Router Class Initialized
INFO - 2023-01-15 16:01:36 --> Output Class Initialized
INFO - 2023-01-15 16:01:36 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:36 --> Input Class Initialized
INFO - 2023-01-15 16:01:36 --> Language Class Initialized
INFO - 2023-01-15 16:01:36 --> Language Class Initialized
INFO - 2023-01-15 16:01:36 --> Config Class Initialized
INFO - 2023-01-15 16:01:36 --> Loader Class Initialized
INFO - 2023-01-15 16:01:36 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:36 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:36 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:36 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:36 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:36 --> Controller Class Initialized
DEBUG - 2023-01-15 16:01:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:01:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:01:36 --> Final output sent to browser
DEBUG - 2023-01-15 16:01:36 --> Total execution time: 0.0632
INFO - 2023-01-15 16:01:36 --> Config Class Initialized
INFO - 2023-01-15 16:01:36 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:01:36 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:01:36 --> Utf8 Class Initialized
INFO - 2023-01-15 16:01:36 --> URI Class Initialized
INFO - 2023-01-15 16:01:36 --> Router Class Initialized
INFO - 2023-01-15 16:01:36 --> Output Class Initialized
INFO - 2023-01-15 16:01:36 --> Security Class Initialized
DEBUG - 2023-01-15 16:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:01:36 --> Input Class Initialized
INFO - 2023-01-15 16:01:36 --> Language Class Initialized
INFO - 2023-01-15 16:01:36 --> Language Class Initialized
INFO - 2023-01-15 16:01:36 --> Config Class Initialized
INFO - 2023-01-15 16:01:36 --> Loader Class Initialized
INFO - 2023-01-15 16:01:36 --> Helper loaded: url_helper
INFO - 2023-01-15 16:01:36 --> Helper loaded: file_helper
INFO - 2023-01-15 16:01:36 --> Helper loaded: form_helper
INFO - 2023-01-15 16:01:36 --> Helper loaded: my_helper
INFO - 2023-01-15 16:01:36 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:01:36 --> Controller Class Initialized
INFO - 2023-01-15 16:03:53 --> Config Class Initialized
INFO - 2023-01-15 16:03:53 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:03:53 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:03:53 --> Utf8 Class Initialized
INFO - 2023-01-15 16:03:53 --> URI Class Initialized
INFO - 2023-01-15 16:03:53 --> Router Class Initialized
INFO - 2023-01-15 16:03:53 --> Output Class Initialized
INFO - 2023-01-15 16:03:53 --> Security Class Initialized
DEBUG - 2023-01-15 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:03:53 --> Input Class Initialized
INFO - 2023-01-15 16:03:53 --> Language Class Initialized
INFO - 2023-01-15 16:03:53 --> Language Class Initialized
INFO - 2023-01-15 16:03:53 --> Config Class Initialized
INFO - 2023-01-15 16:03:53 --> Loader Class Initialized
INFO - 2023-01-15 16:03:53 --> Helper loaded: url_helper
INFO - 2023-01-15 16:03:53 --> Helper loaded: file_helper
INFO - 2023-01-15 16:03:53 --> Helper loaded: form_helper
INFO - 2023-01-15 16:03:53 --> Helper loaded: my_helper
INFO - 2023-01-15 16:03:53 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:03:53 --> Controller Class Initialized
INFO - 2023-01-15 16:03:53 --> Final output sent to browser
DEBUG - 2023-01-15 16:03:53 --> Total execution time: 0.0592
INFO - 2023-01-15 16:03:54 --> Config Class Initialized
INFO - 2023-01-15 16:03:54 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:03:54 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:03:54 --> Utf8 Class Initialized
INFO - 2023-01-15 16:03:54 --> URI Class Initialized
INFO - 2023-01-15 16:03:54 --> Router Class Initialized
INFO - 2023-01-15 16:03:54 --> Output Class Initialized
INFO - 2023-01-15 16:03:54 --> Security Class Initialized
DEBUG - 2023-01-15 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:03:54 --> Input Class Initialized
INFO - 2023-01-15 16:03:54 --> Language Class Initialized
INFO - 2023-01-15 16:03:54 --> Language Class Initialized
INFO - 2023-01-15 16:03:54 --> Config Class Initialized
INFO - 2023-01-15 16:03:54 --> Loader Class Initialized
INFO - 2023-01-15 16:03:54 --> Helper loaded: url_helper
INFO - 2023-01-15 16:03:54 --> Helper loaded: file_helper
INFO - 2023-01-15 16:03:54 --> Helper loaded: form_helper
INFO - 2023-01-15 16:03:54 --> Helper loaded: my_helper
INFO - 2023-01-15 16:03:54 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:03:54 --> Controller Class Initialized
INFO - 2023-01-15 16:03:54 --> Final output sent to browser
DEBUG - 2023-01-15 16:03:54 --> Total execution time: 0.0443
INFO - 2023-01-15 16:03:56 --> Config Class Initialized
INFO - 2023-01-15 16:03:56 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:03:56 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:03:56 --> Utf8 Class Initialized
INFO - 2023-01-15 16:03:56 --> URI Class Initialized
INFO - 2023-01-15 16:03:56 --> Router Class Initialized
INFO - 2023-01-15 16:03:56 --> Output Class Initialized
INFO - 2023-01-15 16:03:56 --> Security Class Initialized
DEBUG - 2023-01-15 16:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:03:56 --> Input Class Initialized
INFO - 2023-01-15 16:03:56 --> Language Class Initialized
INFO - 2023-01-15 16:03:56 --> Language Class Initialized
INFO - 2023-01-15 16:03:56 --> Config Class Initialized
INFO - 2023-01-15 16:03:56 --> Loader Class Initialized
INFO - 2023-01-15 16:03:56 --> Helper loaded: url_helper
INFO - 2023-01-15 16:03:56 --> Helper loaded: file_helper
INFO - 2023-01-15 16:03:56 --> Helper loaded: form_helper
INFO - 2023-01-15 16:03:56 --> Helper loaded: my_helper
INFO - 2023-01-15 16:03:56 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:03:56 --> Controller Class Initialized
DEBUG - 2023-01-15 16:03:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:03:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:03:56 --> Final output sent to browser
DEBUG - 2023-01-15 16:03:56 --> Total execution time: 0.0432
INFO - 2023-01-15 16:04:01 --> Config Class Initialized
INFO - 2023-01-15 16:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:01 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:01 --> URI Class Initialized
INFO - 2023-01-15 16:04:01 --> Router Class Initialized
INFO - 2023-01-15 16:04:01 --> Output Class Initialized
INFO - 2023-01-15 16:04:01 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:01 --> Input Class Initialized
INFO - 2023-01-15 16:04:01 --> Language Class Initialized
INFO - 2023-01-15 16:04:01 --> Language Class Initialized
INFO - 2023-01-15 16:04:01 --> Config Class Initialized
INFO - 2023-01-15 16:04:01 --> Loader Class Initialized
INFO - 2023-01-15 16:04:01 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:01 --> Controller Class Initialized
INFO - 2023-01-15 16:04:01 --> Config Class Initialized
INFO - 2023-01-15 16:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:01 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:01 --> URI Class Initialized
INFO - 2023-01-15 16:04:01 --> Router Class Initialized
INFO - 2023-01-15 16:04:01 --> Output Class Initialized
INFO - 2023-01-15 16:04:01 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:01 --> Input Class Initialized
INFO - 2023-01-15 16:04:01 --> Language Class Initialized
INFO - 2023-01-15 16:04:01 --> Language Class Initialized
INFO - 2023-01-15 16:04:01 --> Config Class Initialized
INFO - 2023-01-15 16:04:01 --> Loader Class Initialized
INFO - 2023-01-15 16:04:01 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:01 --> Controller Class Initialized
DEBUG - 2023-01-15 16:04:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:04:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:04:01 --> Final output sent to browser
DEBUG - 2023-01-15 16:04:01 --> Total execution time: 0.0544
INFO - 2023-01-15 16:04:01 --> Config Class Initialized
INFO - 2023-01-15 16:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:01 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:01 --> URI Class Initialized
INFO - 2023-01-15 16:04:01 --> Router Class Initialized
INFO - 2023-01-15 16:04:01 --> Output Class Initialized
INFO - 2023-01-15 16:04:01 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:01 --> Input Class Initialized
INFO - 2023-01-15 16:04:01 --> Language Class Initialized
INFO - 2023-01-15 16:04:01 --> Language Class Initialized
INFO - 2023-01-15 16:04:01 --> Config Class Initialized
INFO - 2023-01-15 16:04:01 --> Loader Class Initialized
INFO - 2023-01-15 16:04:01 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:01 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:01 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:01 --> Controller Class Initialized
INFO - 2023-01-15 16:04:03 --> Config Class Initialized
INFO - 2023-01-15 16:04:03 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:03 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:03 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:03 --> URI Class Initialized
INFO - 2023-01-15 16:04:03 --> Router Class Initialized
INFO - 2023-01-15 16:04:03 --> Output Class Initialized
INFO - 2023-01-15 16:04:03 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:03 --> Input Class Initialized
INFO - 2023-01-15 16:04:03 --> Language Class Initialized
INFO - 2023-01-15 16:04:03 --> Language Class Initialized
INFO - 2023-01-15 16:04:03 --> Config Class Initialized
INFO - 2023-01-15 16:04:03 --> Loader Class Initialized
INFO - 2023-01-15 16:04:03 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:03 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:03 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:03 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:03 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:03 --> Controller Class Initialized
INFO - 2023-01-15 16:04:03 --> Final output sent to browser
DEBUG - 2023-01-15 16:04:03 --> Total execution time: 0.0581
INFO - 2023-01-15 16:04:05 --> Config Class Initialized
INFO - 2023-01-15 16:04:05 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:05 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:05 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:05 --> URI Class Initialized
INFO - 2023-01-15 16:04:05 --> Router Class Initialized
INFO - 2023-01-15 16:04:05 --> Output Class Initialized
INFO - 2023-01-15 16:04:05 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:05 --> Input Class Initialized
INFO - 2023-01-15 16:04:05 --> Language Class Initialized
INFO - 2023-01-15 16:04:05 --> Language Class Initialized
INFO - 2023-01-15 16:04:05 --> Config Class Initialized
INFO - 2023-01-15 16:04:05 --> Loader Class Initialized
INFO - 2023-01-15 16:04:05 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:05 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:05 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:05 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:05 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:05 --> Controller Class Initialized
INFO - 2023-01-15 16:04:05 --> Final output sent to browser
DEBUG - 2023-01-15 16:04:05 --> Total execution time: 0.0459
INFO - 2023-01-15 16:04:07 --> Config Class Initialized
INFO - 2023-01-15 16:04:07 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:07 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:07 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:07 --> URI Class Initialized
INFO - 2023-01-15 16:04:07 --> Router Class Initialized
INFO - 2023-01-15 16:04:07 --> Output Class Initialized
INFO - 2023-01-15 16:04:07 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:07 --> Input Class Initialized
INFO - 2023-01-15 16:04:07 --> Language Class Initialized
INFO - 2023-01-15 16:04:07 --> Language Class Initialized
INFO - 2023-01-15 16:04:07 --> Config Class Initialized
INFO - 2023-01-15 16:04:07 --> Loader Class Initialized
INFO - 2023-01-15 16:04:07 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:07 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:07 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:07 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:07 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:07 --> Controller Class Initialized
INFO - 2023-01-15 16:04:07 --> Final output sent to browser
DEBUG - 2023-01-15 16:04:07 --> Total execution time: 0.0340
INFO - 2023-01-15 16:04:59 --> Config Class Initialized
INFO - 2023-01-15 16:04:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:04:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:04:59 --> Utf8 Class Initialized
INFO - 2023-01-15 16:04:59 --> URI Class Initialized
INFO - 2023-01-15 16:04:59 --> Router Class Initialized
INFO - 2023-01-15 16:04:59 --> Output Class Initialized
INFO - 2023-01-15 16:04:59 --> Security Class Initialized
DEBUG - 2023-01-15 16:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:04:59 --> Input Class Initialized
INFO - 2023-01-15 16:04:59 --> Language Class Initialized
INFO - 2023-01-15 16:04:59 --> Language Class Initialized
INFO - 2023-01-15 16:04:59 --> Config Class Initialized
INFO - 2023-01-15 16:04:59 --> Loader Class Initialized
INFO - 2023-01-15 16:04:59 --> Helper loaded: url_helper
INFO - 2023-01-15 16:04:59 --> Helper loaded: file_helper
INFO - 2023-01-15 16:04:59 --> Helper loaded: form_helper
INFO - 2023-01-15 16:04:59 --> Helper loaded: my_helper
INFO - 2023-01-15 16:04:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:04:59 --> Controller Class Initialized
DEBUG - 2023-01-15 16:04:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:04:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:04:59 --> Final output sent to browser
DEBUG - 2023-01-15 16:04:59 --> Total execution time: 0.0402
INFO - 2023-01-15 16:05:04 --> Config Class Initialized
INFO - 2023-01-15 16:05:04 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:04 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:04 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:04 --> URI Class Initialized
INFO - 2023-01-15 16:05:04 --> Router Class Initialized
INFO - 2023-01-15 16:05:04 --> Output Class Initialized
INFO - 2023-01-15 16:05:04 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:04 --> Input Class Initialized
INFO - 2023-01-15 16:05:04 --> Language Class Initialized
INFO - 2023-01-15 16:05:04 --> Language Class Initialized
INFO - 2023-01-15 16:05:04 --> Config Class Initialized
INFO - 2023-01-15 16:05:04 --> Loader Class Initialized
INFO - 2023-01-15 16:05:04 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:04 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:04 --> Controller Class Initialized
INFO - 2023-01-15 16:05:04 --> Config Class Initialized
INFO - 2023-01-15 16:05:04 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:04 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:04 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:04 --> URI Class Initialized
INFO - 2023-01-15 16:05:04 --> Router Class Initialized
INFO - 2023-01-15 16:05:04 --> Output Class Initialized
INFO - 2023-01-15 16:05:04 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:04 --> Input Class Initialized
INFO - 2023-01-15 16:05:04 --> Language Class Initialized
INFO - 2023-01-15 16:05:04 --> Language Class Initialized
INFO - 2023-01-15 16:05:04 --> Config Class Initialized
INFO - 2023-01-15 16:05:04 --> Loader Class Initialized
INFO - 2023-01-15 16:05:04 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:04 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:04 --> Controller Class Initialized
DEBUG - 2023-01-15 16:05:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:05:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:05:04 --> Final output sent to browser
DEBUG - 2023-01-15 16:05:04 --> Total execution time: 0.0605
INFO - 2023-01-15 16:05:04 --> Config Class Initialized
INFO - 2023-01-15 16:05:04 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:04 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:04 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:04 --> URI Class Initialized
INFO - 2023-01-15 16:05:04 --> Router Class Initialized
INFO - 2023-01-15 16:05:04 --> Output Class Initialized
INFO - 2023-01-15 16:05:04 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:04 --> Input Class Initialized
INFO - 2023-01-15 16:05:04 --> Language Class Initialized
INFO - 2023-01-15 16:05:04 --> Language Class Initialized
INFO - 2023-01-15 16:05:04 --> Config Class Initialized
INFO - 2023-01-15 16:05:04 --> Loader Class Initialized
INFO - 2023-01-15 16:05:04 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:04 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:04 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:05 --> Controller Class Initialized
INFO - 2023-01-15 16:05:17 --> Config Class Initialized
INFO - 2023-01-15 16:05:17 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:17 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:17 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:17 --> URI Class Initialized
INFO - 2023-01-15 16:05:17 --> Router Class Initialized
INFO - 2023-01-15 16:05:17 --> Output Class Initialized
INFO - 2023-01-15 16:05:17 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:17 --> Input Class Initialized
INFO - 2023-01-15 16:05:17 --> Language Class Initialized
INFO - 2023-01-15 16:05:17 --> Language Class Initialized
INFO - 2023-01-15 16:05:17 --> Config Class Initialized
INFO - 2023-01-15 16:05:17 --> Loader Class Initialized
INFO - 2023-01-15 16:05:17 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:17 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:17 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:17 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:17 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:17 --> Controller Class Initialized
INFO - 2023-01-15 16:05:19 --> Config Class Initialized
INFO - 2023-01-15 16:05:19 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:19 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:19 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:19 --> URI Class Initialized
INFO - 2023-01-15 16:05:19 --> Router Class Initialized
INFO - 2023-01-15 16:05:19 --> Output Class Initialized
INFO - 2023-01-15 16:05:19 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:19 --> Input Class Initialized
INFO - 2023-01-15 16:05:19 --> Language Class Initialized
INFO - 2023-01-15 16:05:19 --> Language Class Initialized
INFO - 2023-01-15 16:05:19 --> Config Class Initialized
INFO - 2023-01-15 16:05:19 --> Loader Class Initialized
INFO - 2023-01-15 16:05:19 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:19 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:19 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:19 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:19 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:19 --> Controller Class Initialized
DEBUG - 2023-01-15 16:05:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:05:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:05:19 --> Final output sent to browser
DEBUG - 2023-01-15 16:05:19 --> Total execution time: 0.0427
INFO - 2023-01-15 16:05:26 --> Config Class Initialized
INFO - 2023-01-15 16:05:26 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:26 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:26 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:26 --> URI Class Initialized
INFO - 2023-01-15 16:05:26 --> Router Class Initialized
INFO - 2023-01-15 16:05:26 --> Output Class Initialized
INFO - 2023-01-15 16:05:26 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:26 --> Input Class Initialized
INFO - 2023-01-15 16:05:26 --> Language Class Initialized
INFO - 2023-01-15 16:05:26 --> Language Class Initialized
INFO - 2023-01-15 16:05:26 --> Config Class Initialized
INFO - 2023-01-15 16:05:26 --> Loader Class Initialized
INFO - 2023-01-15 16:05:26 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:26 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:26 --> Controller Class Initialized
INFO - 2023-01-15 16:05:26 --> Config Class Initialized
INFO - 2023-01-15 16:05:26 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:26 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:26 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:26 --> URI Class Initialized
INFO - 2023-01-15 16:05:26 --> Router Class Initialized
INFO - 2023-01-15 16:05:26 --> Output Class Initialized
INFO - 2023-01-15 16:05:26 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:26 --> Input Class Initialized
INFO - 2023-01-15 16:05:26 --> Language Class Initialized
INFO - 2023-01-15 16:05:26 --> Language Class Initialized
INFO - 2023-01-15 16:05:26 --> Config Class Initialized
INFO - 2023-01-15 16:05:26 --> Loader Class Initialized
INFO - 2023-01-15 16:05:26 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:26 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:26 --> Controller Class Initialized
DEBUG - 2023-01-15 16:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:05:26 --> Final output sent to browser
DEBUG - 2023-01-15 16:05:26 --> Total execution time: 0.0613
INFO - 2023-01-15 16:05:26 --> Config Class Initialized
INFO - 2023-01-15 16:05:26 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:05:26 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:05:26 --> Utf8 Class Initialized
INFO - 2023-01-15 16:05:26 --> URI Class Initialized
INFO - 2023-01-15 16:05:26 --> Router Class Initialized
INFO - 2023-01-15 16:05:26 --> Output Class Initialized
INFO - 2023-01-15 16:05:26 --> Security Class Initialized
DEBUG - 2023-01-15 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:05:26 --> Input Class Initialized
INFO - 2023-01-15 16:05:26 --> Language Class Initialized
INFO - 2023-01-15 16:05:26 --> Language Class Initialized
INFO - 2023-01-15 16:05:26 --> Config Class Initialized
INFO - 2023-01-15 16:05:26 --> Loader Class Initialized
INFO - 2023-01-15 16:05:26 --> Helper loaded: url_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: file_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: form_helper
INFO - 2023-01-15 16:05:26 --> Helper loaded: my_helper
INFO - 2023-01-15 16:05:26 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:05:26 --> Controller Class Initialized
INFO - 2023-01-15 16:12:08 --> Config Class Initialized
INFO - 2023-01-15 16:12:08 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:08 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:08 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:08 --> URI Class Initialized
INFO - 2023-01-15 16:12:08 --> Router Class Initialized
INFO - 2023-01-15 16:12:08 --> Output Class Initialized
INFO - 2023-01-15 16:12:08 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:08 --> Input Class Initialized
INFO - 2023-01-15 16:12:08 --> Language Class Initialized
INFO - 2023-01-15 16:12:08 --> Language Class Initialized
INFO - 2023-01-15 16:12:08 --> Config Class Initialized
INFO - 2023-01-15 16:12:08 --> Loader Class Initialized
INFO - 2023-01-15 16:12:08 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:08 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:08 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:08 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:08 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:08 --> Controller Class Initialized
DEBUG - 2023-01-15 16:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:12:08 --> Final output sent to browser
DEBUG - 2023-01-15 16:12:08 --> Total execution time: 0.0435
INFO - 2023-01-15 16:12:12 --> Config Class Initialized
INFO - 2023-01-15 16:12:12 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:12 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:12 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:12 --> URI Class Initialized
INFO - 2023-01-15 16:12:12 --> Router Class Initialized
INFO - 2023-01-15 16:12:12 --> Output Class Initialized
INFO - 2023-01-15 16:12:12 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:12 --> Input Class Initialized
INFO - 2023-01-15 16:12:12 --> Language Class Initialized
INFO - 2023-01-15 16:12:12 --> Language Class Initialized
INFO - 2023-01-15 16:12:12 --> Config Class Initialized
INFO - 2023-01-15 16:12:12 --> Loader Class Initialized
INFO - 2023-01-15 16:12:12 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:12 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:12 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:12 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:12 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:12 --> Controller Class Initialized
INFO - 2023-01-15 16:12:12 --> Config Class Initialized
INFO - 2023-01-15 16:12:12 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:12 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:12 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:12 --> URI Class Initialized
INFO - 2023-01-15 16:12:12 --> Router Class Initialized
INFO - 2023-01-15 16:12:12 --> Output Class Initialized
INFO - 2023-01-15 16:12:12 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:12 --> Input Class Initialized
INFO - 2023-01-15 16:12:12 --> Language Class Initialized
INFO - 2023-01-15 16:12:12 --> Language Class Initialized
INFO - 2023-01-15 16:12:12 --> Config Class Initialized
INFO - 2023-01-15 16:12:12 --> Loader Class Initialized
INFO - 2023-01-15 16:12:12 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:12 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:12 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:12 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:12 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:12 --> Controller Class Initialized
DEBUG - 2023-01-15 16:12:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:12:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:12:12 --> Final output sent to browser
DEBUG - 2023-01-15 16:12:12 --> Total execution time: 0.0498
INFO - 2023-01-15 16:12:13 --> Config Class Initialized
INFO - 2023-01-15 16:12:13 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:13 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:13 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:13 --> URI Class Initialized
INFO - 2023-01-15 16:12:13 --> Router Class Initialized
INFO - 2023-01-15 16:12:13 --> Output Class Initialized
INFO - 2023-01-15 16:12:13 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:13 --> Input Class Initialized
INFO - 2023-01-15 16:12:13 --> Language Class Initialized
INFO - 2023-01-15 16:12:13 --> Language Class Initialized
INFO - 2023-01-15 16:12:13 --> Config Class Initialized
INFO - 2023-01-15 16:12:13 --> Loader Class Initialized
INFO - 2023-01-15 16:12:13 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:13 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:13 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:13 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:13 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:13 --> Controller Class Initialized
INFO - 2023-01-15 16:12:36 --> Config Class Initialized
INFO - 2023-01-15 16:12:36 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:36 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:36 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:36 --> URI Class Initialized
INFO - 2023-01-15 16:12:36 --> Router Class Initialized
INFO - 2023-01-15 16:12:36 --> Output Class Initialized
INFO - 2023-01-15 16:12:36 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:36 --> Input Class Initialized
INFO - 2023-01-15 16:12:36 --> Language Class Initialized
INFO - 2023-01-15 16:12:36 --> Language Class Initialized
INFO - 2023-01-15 16:12:36 --> Config Class Initialized
INFO - 2023-01-15 16:12:36 --> Loader Class Initialized
INFO - 2023-01-15 16:12:36 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:36 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:36 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:36 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:36 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:36 --> Controller Class Initialized
DEBUG - 2023-01-15 16:12:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:12:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:12:36 --> Final output sent to browser
DEBUG - 2023-01-15 16:12:36 --> Total execution time: 0.0428
INFO - 2023-01-15 16:12:41 --> Config Class Initialized
INFO - 2023-01-15 16:12:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:41 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:41 --> URI Class Initialized
INFO - 2023-01-15 16:12:41 --> Router Class Initialized
INFO - 2023-01-15 16:12:41 --> Output Class Initialized
INFO - 2023-01-15 16:12:41 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:41 --> Input Class Initialized
INFO - 2023-01-15 16:12:41 --> Language Class Initialized
INFO - 2023-01-15 16:12:41 --> Language Class Initialized
INFO - 2023-01-15 16:12:41 --> Config Class Initialized
INFO - 2023-01-15 16:12:41 --> Loader Class Initialized
INFO - 2023-01-15 16:12:41 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:41 --> Controller Class Initialized
INFO - 2023-01-15 16:12:41 --> Config Class Initialized
INFO - 2023-01-15 16:12:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:41 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:41 --> URI Class Initialized
INFO - 2023-01-15 16:12:41 --> Router Class Initialized
INFO - 2023-01-15 16:12:41 --> Output Class Initialized
INFO - 2023-01-15 16:12:41 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:41 --> Input Class Initialized
INFO - 2023-01-15 16:12:41 --> Language Class Initialized
INFO - 2023-01-15 16:12:41 --> Language Class Initialized
INFO - 2023-01-15 16:12:41 --> Config Class Initialized
INFO - 2023-01-15 16:12:41 --> Loader Class Initialized
INFO - 2023-01-15 16:12:41 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:41 --> Controller Class Initialized
DEBUG - 2023-01-15 16:12:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:12:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:12:41 --> Final output sent to browser
DEBUG - 2023-01-15 16:12:41 --> Total execution time: 0.0562
INFO - 2023-01-15 16:12:41 --> Config Class Initialized
INFO - 2023-01-15 16:12:41 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:12:41 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:12:41 --> Utf8 Class Initialized
INFO - 2023-01-15 16:12:41 --> URI Class Initialized
INFO - 2023-01-15 16:12:41 --> Router Class Initialized
INFO - 2023-01-15 16:12:41 --> Output Class Initialized
INFO - 2023-01-15 16:12:41 --> Security Class Initialized
DEBUG - 2023-01-15 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:12:41 --> Input Class Initialized
INFO - 2023-01-15 16:12:41 --> Language Class Initialized
INFO - 2023-01-15 16:12:41 --> Language Class Initialized
INFO - 2023-01-15 16:12:41 --> Config Class Initialized
INFO - 2023-01-15 16:12:41 --> Loader Class Initialized
INFO - 2023-01-15 16:12:41 --> Helper loaded: url_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: file_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: form_helper
INFO - 2023-01-15 16:12:41 --> Helper loaded: my_helper
INFO - 2023-01-15 16:12:41 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:12:41 --> Controller Class Initialized
INFO - 2023-01-15 16:14:54 --> Config Class Initialized
INFO - 2023-01-15 16:14:54 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:14:54 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:14:54 --> Utf8 Class Initialized
INFO - 2023-01-15 16:14:54 --> URI Class Initialized
INFO - 2023-01-15 16:14:54 --> Router Class Initialized
INFO - 2023-01-15 16:14:54 --> Output Class Initialized
INFO - 2023-01-15 16:14:54 --> Security Class Initialized
DEBUG - 2023-01-15 16:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:14:54 --> Input Class Initialized
INFO - 2023-01-15 16:14:54 --> Language Class Initialized
INFO - 2023-01-15 16:14:54 --> Language Class Initialized
INFO - 2023-01-15 16:14:54 --> Config Class Initialized
INFO - 2023-01-15 16:14:54 --> Loader Class Initialized
INFO - 2023-01-15 16:14:54 --> Helper loaded: url_helper
INFO - 2023-01-15 16:14:54 --> Helper loaded: file_helper
INFO - 2023-01-15 16:14:54 --> Helper loaded: form_helper
INFO - 2023-01-15 16:14:54 --> Helper loaded: my_helper
INFO - 2023-01-15 16:14:54 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:14:54 --> Controller Class Initialized
DEBUG - 2023-01-15 16:14:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:14:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:14:54 --> Final output sent to browser
DEBUG - 2023-01-15 16:14:54 --> Total execution time: 0.0552
INFO - 2023-01-15 16:14:59 --> Config Class Initialized
INFO - 2023-01-15 16:14:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:14:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:14:59 --> Utf8 Class Initialized
INFO - 2023-01-15 16:14:59 --> URI Class Initialized
INFO - 2023-01-15 16:14:59 --> Router Class Initialized
INFO - 2023-01-15 16:14:59 --> Output Class Initialized
INFO - 2023-01-15 16:14:59 --> Security Class Initialized
DEBUG - 2023-01-15 16:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:14:59 --> Input Class Initialized
INFO - 2023-01-15 16:14:59 --> Language Class Initialized
INFO - 2023-01-15 16:14:59 --> Language Class Initialized
INFO - 2023-01-15 16:14:59 --> Config Class Initialized
INFO - 2023-01-15 16:14:59 --> Loader Class Initialized
INFO - 2023-01-15 16:14:59 --> Helper loaded: url_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: file_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: form_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: my_helper
INFO - 2023-01-15 16:14:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:14:59 --> Controller Class Initialized
INFO - 2023-01-15 16:14:59 --> Config Class Initialized
INFO - 2023-01-15 16:14:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:14:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:14:59 --> Utf8 Class Initialized
INFO - 2023-01-15 16:14:59 --> URI Class Initialized
INFO - 2023-01-15 16:14:59 --> Router Class Initialized
INFO - 2023-01-15 16:14:59 --> Output Class Initialized
INFO - 2023-01-15 16:14:59 --> Security Class Initialized
DEBUG - 2023-01-15 16:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:14:59 --> Input Class Initialized
INFO - 2023-01-15 16:14:59 --> Language Class Initialized
INFO - 2023-01-15 16:14:59 --> Language Class Initialized
INFO - 2023-01-15 16:14:59 --> Config Class Initialized
INFO - 2023-01-15 16:14:59 --> Loader Class Initialized
INFO - 2023-01-15 16:14:59 --> Helper loaded: url_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: file_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: form_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: my_helper
INFO - 2023-01-15 16:14:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:14:59 --> Controller Class Initialized
DEBUG - 2023-01-15 16:14:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:14:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:14:59 --> Final output sent to browser
DEBUG - 2023-01-15 16:14:59 --> Total execution time: 0.0598
INFO - 2023-01-15 16:14:59 --> Config Class Initialized
INFO - 2023-01-15 16:14:59 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:14:59 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:14:59 --> Utf8 Class Initialized
INFO - 2023-01-15 16:14:59 --> URI Class Initialized
INFO - 2023-01-15 16:14:59 --> Router Class Initialized
INFO - 2023-01-15 16:14:59 --> Output Class Initialized
INFO - 2023-01-15 16:14:59 --> Security Class Initialized
DEBUG - 2023-01-15 16:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:14:59 --> Input Class Initialized
INFO - 2023-01-15 16:14:59 --> Language Class Initialized
INFO - 2023-01-15 16:14:59 --> Language Class Initialized
INFO - 2023-01-15 16:14:59 --> Config Class Initialized
INFO - 2023-01-15 16:14:59 --> Loader Class Initialized
INFO - 2023-01-15 16:14:59 --> Helper loaded: url_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: file_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: form_helper
INFO - 2023-01-15 16:14:59 --> Helper loaded: my_helper
INFO - 2023-01-15 16:14:59 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:14:59 --> Controller Class Initialized
INFO - 2023-01-15 16:19:48 --> Config Class Initialized
INFO - 2023-01-15 16:19:48 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:19:48 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:19:48 --> Utf8 Class Initialized
INFO - 2023-01-15 16:19:48 --> URI Class Initialized
INFO - 2023-01-15 16:19:48 --> Router Class Initialized
INFO - 2023-01-15 16:19:48 --> Output Class Initialized
INFO - 2023-01-15 16:19:48 --> Security Class Initialized
DEBUG - 2023-01-15 16:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:19:48 --> Input Class Initialized
INFO - 2023-01-15 16:19:48 --> Language Class Initialized
INFO - 2023-01-15 16:19:48 --> Language Class Initialized
INFO - 2023-01-15 16:19:48 --> Config Class Initialized
INFO - 2023-01-15 16:19:48 --> Loader Class Initialized
INFO - 2023-01-15 16:19:48 --> Helper loaded: url_helper
INFO - 2023-01-15 16:19:48 --> Helper loaded: file_helper
INFO - 2023-01-15 16:19:48 --> Helper loaded: form_helper
INFO - 2023-01-15 16:19:48 --> Helper loaded: my_helper
INFO - 2023-01-15 16:19:48 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:19:48 --> Controller Class Initialized
DEBUG - 2023-01-15 16:19:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:19:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:19:48 --> Final output sent to browser
DEBUG - 2023-01-15 16:19:48 --> Total execution time: 0.0446
INFO - 2023-01-15 16:19:51 --> Config Class Initialized
INFO - 2023-01-15 16:19:51 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:19:51 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:19:51 --> Utf8 Class Initialized
INFO - 2023-01-15 16:19:51 --> URI Class Initialized
INFO - 2023-01-15 16:19:51 --> Router Class Initialized
INFO - 2023-01-15 16:19:51 --> Output Class Initialized
INFO - 2023-01-15 16:19:51 --> Security Class Initialized
DEBUG - 2023-01-15 16:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:19:51 --> Input Class Initialized
INFO - 2023-01-15 16:19:51 --> Language Class Initialized
INFO - 2023-01-15 16:19:52 --> Language Class Initialized
INFO - 2023-01-15 16:19:52 --> Config Class Initialized
INFO - 2023-01-15 16:19:52 --> Loader Class Initialized
INFO - 2023-01-15 16:19:52 --> Helper loaded: url_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: file_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: form_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: my_helper
INFO - 2023-01-15 16:19:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:19:52 --> Controller Class Initialized
INFO - 2023-01-15 16:19:52 --> Config Class Initialized
INFO - 2023-01-15 16:19:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:19:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:19:52 --> Utf8 Class Initialized
INFO - 2023-01-15 16:19:52 --> URI Class Initialized
INFO - 2023-01-15 16:19:52 --> Router Class Initialized
INFO - 2023-01-15 16:19:52 --> Output Class Initialized
INFO - 2023-01-15 16:19:52 --> Security Class Initialized
DEBUG - 2023-01-15 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:19:52 --> Input Class Initialized
INFO - 2023-01-15 16:19:52 --> Language Class Initialized
INFO - 2023-01-15 16:19:52 --> Language Class Initialized
INFO - 2023-01-15 16:19:52 --> Config Class Initialized
INFO - 2023-01-15 16:19:52 --> Loader Class Initialized
INFO - 2023-01-15 16:19:52 --> Helper loaded: url_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: file_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: form_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: my_helper
INFO - 2023-01-15 16:19:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:19:52 --> Controller Class Initialized
DEBUG - 2023-01-15 16:19:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:19:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:19:52 --> Final output sent to browser
DEBUG - 2023-01-15 16:19:52 --> Total execution time: 0.0466
INFO - 2023-01-15 16:19:52 --> Config Class Initialized
INFO - 2023-01-15 16:19:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:19:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:19:52 --> Utf8 Class Initialized
INFO - 2023-01-15 16:19:52 --> URI Class Initialized
INFO - 2023-01-15 16:19:52 --> Router Class Initialized
INFO - 2023-01-15 16:19:52 --> Output Class Initialized
INFO - 2023-01-15 16:19:52 --> Security Class Initialized
DEBUG - 2023-01-15 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:19:52 --> Input Class Initialized
INFO - 2023-01-15 16:19:52 --> Language Class Initialized
INFO - 2023-01-15 16:19:52 --> Language Class Initialized
INFO - 2023-01-15 16:19:52 --> Config Class Initialized
INFO - 2023-01-15 16:19:52 --> Loader Class Initialized
INFO - 2023-01-15 16:19:52 --> Helper loaded: url_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: file_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: form_helper
INFO - 2023-01-15 16:19:52 --> Helper loaded: my_helper
INFO - 2023-01-15 16:19:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:19:52 --> Controller Class Initialized
INFO - 2023-01-15 16:21:47 --> Config Class Initialized
INFO - 2023-01-15 16:21:47 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:21:47 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:21:47 --> Utf8 Class Initialized
INFO - 2023-01-15 16:21:47 --> URI Class Initialized
INFO - 2023-01-15 16:21:47 --> Router Class Initialized
INFO - 2023-01-15 16:21:47 --> Output Class Initialized
INFO - 2023-01-15 16:21:47 --> Security Class Initialized
DEBUG - 2023-01-15 16:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:21:47 --> Input Class Initialized
INFO - 2023-01-15 16:21:47 --> Language Class Initialized
INFO - 2023-01-15 16:21:47 --> Language Class Initialized
INFO - 2023-01-15 16:21:47 --> Config Class Initialized
INFO - 2023-01-15 16:21:47 --> Loader Class Initialized
INFO - 2023-01-15 16:21:47 --> Helper loaded: url_helper
INFO - 2023-01-15 16:21:47 --> Helper loaded: file_helper
INFO - 2023-01-15 16:21:47 --> Helper loaded: form_helper
INFO - 2023-01-15 16:21:47 --> Helper loaded: my_helper
INFO - 2023-01-15 16:21:47 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:21:47 --> Controller Class Initialized
DEBUG - 2023-01-15 16:21:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:21:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:21:47 --> Final output sent to browser
DEBUG - 2023-01-15 16:21:47 --> Total execution time: 0.0430
INFO - 2023-01-15 16:21:51 --> Config Class Initialized
INFO - 2023-01-15 16:21:51 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:21:51 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:21:51 --> Utf8 Class Initialized
INFO - 2023-01-15 16:21:51 --> URI Class Initialized
INFO - 2023-01-15 16:21:51 --> Router Class Initialized
INFO - 2023-01-15 16:21:51 --> Output Class Initialized
INFO - 2023-01-15 16:21:51 --> Security Class Initialized
DEBUG - 2023-01-15 16:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:21:51 --> Input Class Initialized
INFO - 2023-01-15 16:21:51 --> Language Class Initialized
INFO - 2023-01-15 16:21:51 --> Language Class Initialized
INFO - 2023-01-15 16:21:51 --> Config Class Initialized
INFO - 2023-01-15 16:21:51 --> Loader Class Initialized
INFO - 2023-01-15 16:21:51 --> Helper loaded: url_helper
INFO - 2023-01-15 16:21:51 --> Helper loaded: file_helper
INFO - 2023-01-15 16:21:51 --> Helper loaded: form_helper
INFO - 2023-01-15 16:21:51 --> Helper loaded: my_helper
INFO - 2023-01-15 16:21:51 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:21:52 --> Controller Class Initialized
INFO - 2023-01-15 16:21:52 --> Config Class Initialized
INFO - 2023-01-15 16:21:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:21:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:21:52 --> Utf8 Class Initialized
INFO - 2023-01-15 16:21:52 --> URI Class Initialized
INFO - 2023-01-15 16:21:52 --> Router Class Initialized
INFO - 2023-01-15 16:21:52 --> Output Class Initialized
INFO - 2023-01-15 16:21:52 --> Security Class Initialized
DEBUG - 2023-01-15 16:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:21:52 --> Input Class Initialized
INFO - 2023-01-15 16:21:52 --> Language Class Initialized
INFO - 2023-01-15 16:21:52 --> Language Class Initialized
INFO - 2023-01-15 16:21:52 --> Config Class Initialized
INFO - 2023-01-15 16:21:52 --> Loader Class Initialized
INFO - 2023-01-15 16:21:52 --> Helper loaded: url_helper
INFO - 2023-01-15 16:21:52 --> Helper loaded: file_helper
INFO - 2023-01-15 16:21:52 --> Helper loaded: form_helper
INFO - 2023-01-15 16:21:52 --> Helper loaded: my_helper
INFO - 2023-01-15 16:21:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:21:52 --> Controller Class Initialized
DEBUG - 2023-01-15 16:21:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:21:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:21:52 --> Final output sent to browser
DEBUG - 2023-01-15 16:21:52 --> Total execution time: 0.0490
INFO - 2023-01-15 16:21:52 --> Config Class Initialized
INFO - 2023-01-15 16:21:52 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:21:52 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:21:52 --> Utf8 Class Initialized
INFO - 2023-01-15 16:21:52 --> URI Class Initialized
INFO - 2023-01-15 16:21:52 --> Router Class Initialized
INFO - 2023-01-15 16:21:52 --> Output Class Initialized
INFO - 2023-01-15 16:21:52 --> Security Class Initialized
DEBUG - 2023-01-15 16:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:21:52 --> Input Class Initialized
INFO - 2023-01-15 16:21:52 --> Language Class Initialized
INFO - 2023-01-15 16:21:52 --> Language Class Initialized
INFO - 2023-01-15 16:21:52 --> Config Class Initialized
INFO - 2023-01-15 16:21:52 --> Loader Class Initialized
INFO - 2023-01-15 16:21:52 --> Helper loaded: url_helper
INFO - 2023-01-15 16:21:52 --> Helper loaded: file_helper
INFO - 2023-01-15 16:21:52 --> Helper loaded: form_helper
INFO - 2023-01-15 16:21:52 --> Helper loaded: my_helper
INFO - 2023-01-15 16:21:52 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:21:52 --> Controller Class Initialized
INFO - 2023-01-15 16:23:16 --> Config Class Initialized
INFO - 2023-01-15 16:23:16 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:16 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:16 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:16 --> URI Class Initialized
INFO - 2023-01-15 16:23:16 --> Router Class Initialized
INFO - 2023-01-15 16:23:16 --> Output Class Initialized
INFO - 2023-01-15 16:23:16 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:16 --> Input Class Initialized
INFO - 2023-01-15 16:23:16 --> Language Class Initialized
INFO - 2023-01-15 16:23:16 --> Language Class Initialized
INFO - 2023-01-15 16:23:16 --> Config Class Initialized
INFO - 2023-01-15 16:23:16 --> Loader Class Initialized
INFO - 2023-01-15 16:23:16 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:16 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:16 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:16 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:16 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:16 --> Controller Class Initialized
DEBUG - 2023-01-15 16:23:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:23:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:23:16 --> Final output sent to browser
DEBUG - 2023-01-15 16:23:16 --> Total execution time: 0.0538
INFO - 2023-01-15 16:23:21 --> Config Class Initialized
INFO - 2023-01-15 16:23:21 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:21 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:21 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:21 --> URI Class Initialized
INFO - 2023-01-15 16:23:21 --> Router Class Initialized
INFO - 2023-01-15 16:23:21 --> Output Class Initialized
INFO - 2023-01-15 16:23:21 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:21 --> Input Class Initialized
INFO - 2023-01-15 16:23:21 --> Language Class Initialized
INFO - 2023-01-15 16:23:21 --> Language Class Initialized
INFO - 2023-01-15 16:23:21 --> Config Class Initialized
INFO - 2023-01-15 16:23:21 --> Loader Class Initialized
INFO - 2023-01-15 16:23:21 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:21 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:21 --> Controller Class Initialized
INFO - 2023-01-15 16:23:21 --> Config Class Initialized
INFO - 2023-01-15 16:23:21 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:21 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:21 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:21 --> URI Class Initialized
INFO - 2023-01-15 16:23:21 --> Router Class Initialized
INFO - 2023-01-15 16:23:21 --> Output Class Initialized
INFO - 2023-01-15 16:23:21 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:21 --> Input Class Initialized
INFO - 2023-01-15 16:23:21 --> Language Class Initialized
INFO - 2023-01-15 16:23:21 --> Language Class Initialized
INFO - 2023-01-15 16:23:21 --> Config Class Initialized
INFO - 2023-01-15 16:23:21 --> Loader Class Initialized
INFO - 2023-01-15 16:23:21 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:21 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:21 --> Controller Class Initialized
DEBUG - 2023-01-15 16:23:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:23:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:23:21 --> Final output sent to browser
DEBUG - 2023-01-15 16:23:21 --> Total execution time: 0.0446
INFO - 2023-01-15 16:23:21 --> Config Class Initialized
INFO - 2023-01-15 16:23:21 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:21 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:21 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:21 --> URI Class Initialized
INFO - 2023-01-15 16:23:21 --> Router Class Initialized
INFO - 2023-01-15 16:23:21 --> Output Class Initialized
INFO - 2023-01-15 16:23:21 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:21 --> Input Class Initialized
INFO - 2023-01-15 16:23:21 --> Language Class Initialized
INFO - 2023-01-15 16:23:21 --> Language Class Initialized
INFO - 2023-01-15 16:23:21 --> Config Class Initialized
INFO - 2023-01-15 16:23:21 --> Loader Class Initialized
INFO - 2023-01-15 16:23:21 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:21 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:21 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:21 --> Controller Class Initialized
INFO - 2023-01-15 16:23:44 --> Config Class Initialized
INFO - 2023-01-15 16:23:44 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:44 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:44 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:44 --> URI Class Initialized
INFO - 2023-01-15 16:23:44 --> Router Class Initialized
INFO - 2023-01-15 16:23:44 --> Output Class Initialized
INFO - 2023-01-15 16:23:44 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:44 --> Input Class Initialized
INFO - 2023-01-15 16:23:44 --> Language Class Initialized
INFO - 2023-01-15 16:23:44 --> Language Class Initialized
INFO - 2023-01-15 16:23:44 --> Config Class Initialized
INFO - 2023-01-15 16:23:44 --> Loader Class Initialized
INFO - 2023-01-15 16:23:44 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:44 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:44 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:44 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:44 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:44 --> Controller Class Initialized
DEBUG - 2023-01-15 16:23:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-01-15 16:23:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:23:44 --> Final output sent to browser
DEBUG - 2023-01-15 16:23:44 --> Total execution time: 0.0582
INFO - 2023-01-15 16:23:49 --> Config Class Initialized
INFO - 2023-01-15 16:23:49 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:49 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:49 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:49 --> URI Class Initialized
INFO - 2023-01-15 16:23:49 --> Router Class Initialized
INFO - 2023-01-15 16:23:49 --> Output Class Initialized
INFO - 2023-01-15 16:23:49 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:49 --> Input Class Initialized
INFO - 2023-01-15 16:23:49 --> Language Class Initialized
INFO - 2023-01-15 16:23:49 --> Language Class Initialized
INFO - 2023-01-15 16:23:49 --> Config Class Initialized
INFO - 2023-01-15 16:23:49 --> Loader Class Initialized
INFO - 2023-01-15 16:23:49 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:49 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:49 --> Controller Class Initialized
INFO - 2023-01-15 16:23:49 --> Config Class Initialized
INFO - 2023-01-15 16:23:49 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:49 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:49 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:49 --> URI Class Initialized
INFO - 2023-01-15 16:23:49 --> Router Class Initialized
INFO - 2023-01-15 16:23:49 --> Output Class Initialized
INFO - 2023-01-15 16:23:49 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:49 --> Input Class Initialized
INFO - 2023-01-15 16:23:49 --> Language Class Initialized
INFO - 2023-01-15 16:23:49 --> Language Class Initialized
INFO - 2023-01-15 16:23:49 --> Config Class Initialized
INFO - 2023-01-15 16:23:49 --> Loader Class Initialized
INFO - 2023-01-15 16:23:49 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:49 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:49 --> Controller Class Initialized
DEBUG - 2023-01-15 16:23:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-15 16:23:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-15 16:23:49 --> Final output sent to browser
DEBUG - 2023-01-15 16:23:49 --> Total execution time: 0.0612
INFO - 2023-01-15 16:23:49 --> Config Class Initialized
INFO - 2023-01-15 16:23:49 --> Hooks Class Initialized
DEBUG - 2023-01-15 16:23:49 --> UTF-8 Support Enabled
INFO - 2023-01-15 16:23:49 --> Utf8 Class Initialized
INFO - 2023-01-15 16:23:49 --> URI Class Initialized
INFO - 2023-01-15 16:23:49 --> Router Class Initialized
INFO - 2023-01-15 16:23:49 --> Output Class Initialized
INFO - 2023-01-15 16:23:49 --> Security Class Initialized
DEBUG - 2023-01-15 16:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-15 16:23:49 --> Input Class Initialized
INFO - 2023-01-15 16:23:49 --> Language Class Initialized
INFO - 2023-01-15 16:23:49 --> Language Class Initialized
INFO - 2023-01-15 16:23:49 --> Config Class Initialized
INFO - 2023-01-15 16:23:49 --> Loader Class Initialized
INFO - 2023-01-15 16:23:49 --> Helper loaded: url_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: file_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: form_helper
INFO - 2023-01-15 16:23:49 --> Helper loaded: my_helper
INFO - 2023-01-15 16:23:49 --> Database Driver Class Initialized
DEBUG - 2023-01-15 16:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-15 16:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-15 16:23:49 --> Controller Class Initialized
