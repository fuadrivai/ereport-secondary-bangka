<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-29 05:21:02 --> Config Class Initialized
INFO - 2024-10-29 05:21:02 --> Hooks Class Initialized
DEBUG - 2024-10-29 05:21:02 --> UTF-8 Support Enabled
INFO - 2024-10-29 05:21:02 --> Utf8 Class Initialized
INFO - 2024-10-29 05:21:02 --> URI Class Initialized
INFO - 2024-10-29 05:21:02 --> Router Class Initialized
INFO - 2024-10-29 05:21:02 --> Output Class Initialized
INFO - 2024-10-29 05:21:02 --> Security Class Initialized
DEBUG - 2024-10-29 05:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 05:21:02 --> Input Class Initialized
INFO - 2024-10-29 05:21:02 --> Language Class Initialized
INFO - 2024-10-29 05:21:02 --> Language Class Initialized
INFO - 2024-10-29 05:21:02 --> Config Class Initialized
INFO - 2024-10-29 05:21:02 --> Loader Class Initialized
INFO - 2024-10-29 05:21:02 --> Helper loaded: url_helper
INFO - 2024-10-29 05:21:02 --> Helper loaded: file_helper
INFO - 2024-10-29 05:21:02 --> Helper loaded: form_helper
INFO - 2024-10-29 05:21:02 --> Helper loaded: my_helper
INFO - 2024-10-29 05:21:02 --> Database Driver Class Initialized
INFO - 2024-10-29 05:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 05:21:02 --> Controller Class Initialized
INFO - 2024-10-29 05:21:02 --> Helper loaded: cookie_helper
INFO - 2024-10-29 05:21:02 --> Final output sent to browser
DEBUG - 2024-10-29 05:21:02 --> Total execution time: 0.0643
INFO - 2024-10-29 05:21:02 --> Config Class Initialized
INFO - 2024-10-29 05:21:02 --> Hooks Class Initialized
DEBUG - 2024-10-29 05:21:02 --> UTF-8 Support Enabled
INFO - 2024-10-29 05:21:02 --> Utf8 Class Initialized
INFO - 2024-10-29 05:21:02 --> URI Class Initialized
INFO - 2024-10-29 05:21:02 --> Router Class Initialized
INFO - 2024-10-29 05:21:02 --> Output Class Initialized
INFO - 2024-10-29 05:21:02 --> Security Class Initialized
DEBUG - 2024-10-29 05:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 05:21:02 --> Input Class Initialized
INFO - 2024-10-29 05:21:02 --> Language Class Initialized
INFO - 2024-10-29 05:21:02 --> Language Class Initialized
INFO - 2024-10-29 05:21:02 --> Config Class Initialized
INFO - 2024-10-29 05:21:02 --> Loader Class Initialized
INFO - 2024-10-29 05:21:02 --> Helper loaded: url_helper
INFO - 2024-10-29 05:21:02 --> Helper loaded: file_helper
INFO - 2024-10-29 05:21:02 --> Helper loaded: form_helper
INFO - 2024-10-29 05:21:02 --> Helper loaded: my_helper
INFO - 2024-10-29 05:21:02 --> Database Driver Class Initialized
INFO - 2024-10-29 05:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 05:21:02 --> Controller Class Initialized
INFO - 2024-10-29 05:21:02 --> Helper loaded: cookie_helper
INFO - 2024-10-29 05:21:03 --> Config Class Initialized
INFO - 2024-10-29 05:21:03 --> Hooks Class Initialized
DEBUG - 2024-10-29 05:21:03 --> UTF-8 Support Enabled
INFO - 2024-10-29 05:21:03 --> Utf8 Class Initialized
INFO - 2024-10-29 05:21:03 --> URI Class Initialized
INFO - 2024-10-29 05:21:03 --> Router Class Initialized
INFO - 2024-10-29 05:21:03 --> Output Class Initialized
INFO - 2024-10-29 05:21:03 --> Security Class Initialized
DEBUG - 2024-10-29 05:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 05:21:03 --> Input Class Initialized
INFO - 2024-10-29 05:21:03 --> Language Class Initialized
INFO - 2024-10-29 05:21:03 --> Language Class Initialized
INFO - 2024-10-29 05:21:03 --> Config Class Initialized
INFO - 2024-10-29 05:21:03 --> Loader Class Initialized
INFO - 2024-10-29 05:21:03 --> Helper loaded: url_helper
INFO - 2024-10-29 05:21:03 --> Helper loaded: file_helper
INFO - 2024-10-29 05:21:03 --> Helper loaded: form_helper
INFO - 2024-10-29 05:21:03 --> Helper loaded: my_helper
INFO - 2024-10-29 05:21:03 --> Database Driver Class Initialized
INFO - 2024-10-29 05:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 05:21:03 --> Controller Class Initialized
ERROR - 2024-10-29 05:21:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT a.id_siswa,a.id_kelas,b.tingkat,a.ta FROM t_kelas_siswa a
                                                    INNER JOIN m_kelas b ON b.id = a.id_kelas
                                                    WHERE a.id_siswa = 
INFO - 2024-10-29 05:21:03 --> Language file loaded: language/english/db_lang.php
