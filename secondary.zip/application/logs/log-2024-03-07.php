<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-07 09:37:00 --> Config Class Initialized
INFO - 2024-03-07 09:37:00 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:00 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:00 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:00 --> URI Class Initialized
INFO - 2024-03-07 09:37:00 --> Router Class Initialized
INFO - 2024-03-07 09:37:00 --> Output Class Initialized
INFO - 2024-03-07 09:37:00 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:00 --> Input Class Initialized
INFO - 2024-03-07 09:37:00 --> Language Class Initialized
INFO - 2024-03-07 09:37:00 --> Language Class Initialized
INFO - 2024-03-07 09:37:00 --> Config Class Initialized
INFO - 2024-03-07 09:37:00 --> Loader Class Initialized
INFO - 2024-03-07 09:37:00 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:00 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:00 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:00 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:00 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:00 --> Controller Class Initialized
INFO - 2024-03-07 09:37:00 --> Config Class Initialized
INFO - 2024-03-07 09:37:00 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:00 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:00 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:00 --> URI Class Initialized
INFO - 2024-03-07 09:37:00 --> Router Class Initialized
INFO - 2024-03-07 09:37:00 --> Output Class Initialized
INFO - 2024-03-07 09:37:00 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:00 --> Input Class Initialized
INFO - 2024-03-07 09:37:00 --> Language Class Initialized
INFO - 2024-03-07 09:37:00 --> Language Class Initialized
INFO - 2024-03-07 09:37:00 --> Config Class Initialized
INFO - 2024-03-07 09:37:00 --> Loader Class Initialized
INFO - 2024-03-07 09:37:00 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:00 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:00 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:00 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:00 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:00 --> Controller Class Initialized
DEBUG - 2024-03-07 09:37:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-07 09:37:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:37:00 --> Final output sent to browser
DEBUG - 2024-03-07 09:37:00 --> Total execution time: 0.0309
INFO - 2024-03-07 09:37:05 --> Config Class Initialized
INFO - 2024-03-07 09:37:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:05 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:05 --> URI Class Initialized
INFO - 2024-03-07 09:37:05 --> Router Class Initialized
INFO - 2024-03-07 09:37:05 --> Output Class Initialized
INFO - 2024-03-07 09:37:05 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:05 --> Input Class Initialized
INFO - 2024-03-07 09:37:05 --> Language Class Initialized
INFO - 2024-03-07 09:37:05 --> Language Class Initialized
INFO - 2024-03-07 09:37:05 --> Config Class Initialized
INFO - 2024-03-07 09:37:05 --> Loader Class Initialized
INFO - 2024-03-07 09:37:05 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:05 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:05 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:05 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:05 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:05 --> Controller Class Initialized
INFO - 2024-03-07 09:37:05 --> Helper loaded: cookie_helper
INFO - 2024-03-07 09:37:05 --> Final output sent to browser
DEBUG - 2024-03-07 09:37:05 --> Total execution time: 0.0436
INFO - 2024-03-07 09:37:05 --> Config Class Initialized
INFO - 2024-03-07 09:37:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:05 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:05 --> URI Class Initialized
INFO - 2024-03-07 09:37:05 --> Router Class Initialized
INFO - 2024-03-07 09:37:05 --> Output Class Initialized
INFO - 2024-03-07 09:37:05 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:05 --> Input Class Initialized
INFO - 2024-03-07 09:37:05 --> Language Class Initialized
INFO - 2024-03-07 09:37:05 --> Language Class Initialized
INFO - 2024-03-07 09:37:05 --> Config Class Initialized
INFO - 2024-03-07 09:37:05 --> Loader Class Initialized
INFO - 2024-03-07 09:37:05 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:05 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:05 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:05 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:05 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:05 --> Controller Class Initialized
DEBUG - 2024-03-07 09:37:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-07 09:37:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:37:05 --> Final output sent to browser
DEBUG - 2024-03-07 09:37:05 --> Total execution time: 0.0409
INFO - 2024-03-07 09:37:08 --> Config Class Initialized
INFO - 2024-03-07 09:37:08 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:08 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:08 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:08 --> URI Class Initialized
INFO - 2024-03-07 09:37:08 --> Router Class Initialized
INFO - 2024-03-07 09:37:08 --> Output Class Initialized
INFO - 2024-03-07 09:37:08 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:08 --> Input Class Initialized
INFO - 2024-03-07 09:37:08 --> Language Class Initialized
INFO - 2024-03-07 09:37:08 --> Language Class Initialized
INFO - 2024-03-07 09:37:08 --> Config Class Initialized
INFO - 2024-03-07 09:37:08 --> Loader Class Initialized
INFO - 2024-03-07 09:37:08 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:08 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:08 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:08 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:08 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:08 --> Controller Class Initialized
DEBUG - 2024-03-07 09:37:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-07 09:37:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:37:08 --> Final output sent to browser
DEBUG - 2024-03-07 09:37:08 --> Total execution time: 0.0298
INFO - 2024-03-07 09:37:11 --> Config Class Initialized
INFO - 2024-03-07 09:37:11 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:11 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:11 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:11 --> URI Class Initialized
INFO - 2024-03-07 09:37:11 --> Router Class Initialized
INFO - 2024-03-07 09:37:11 --> Output Class Initialized
INFO - 2024-03-07 09:37:11 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:11 --> Input Class Initialized
INFO - 2024-03-07 09:37:11 --> Language Class Initialized
INFO - 2024-03-07 09:37:11 --> Language Class Initialized
INFO - 2024-03-07 09:37:11 --> Config Class Initialized
INFO - 2024-03-07 09:37:11 --> Loader Class Initialized
INFO - 2024-03-07 09:37:11 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:11 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:11 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:11 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:11 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:11 --> Controller Class Initialized
DEBUG - 2024-03-07 09:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 09:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:37:11 --> Final output sent to browser
DEBUG - 2024-03-07 09:37:11 --> Total execution time: 0.0360
INFO - 2024-03-07 09:37:11 --> Config Class Initialized
INFO - 2024-03-07 09:37:11 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:11 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:11 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:11 --> URI Class Initialized
INFO - 2024-03-07 09:37:11 --> Router Class Initialized
INFO - 2024-03-07 09:37:11 --> Output Class Initialized
INFO - 2024-03-07 09:37:11 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:11 --> Input Class Initialized
INFO - 2024-03-07 09:37:11 --> Language Class Initialized
INFO - 2024-03-07 09:37:11 --> Language Class Initialized
INFO - 2024-03-07 09:37:11 --> Config Class Initialized
INFO - 2024-03-07 09:37:11 --> Loader Class Initialized
INFO - 2024-03-07 09:37:11 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:11 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:11 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:11 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:11 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:11 --> Controller Class Initialized
INFO - 2024-03-07 09:37:57 --> Config Class Initialized
INFO - 2024-03-07 09:37:57 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:37:57 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:37:57 --> Utf8 Class Initialized
INFO - 2024-03-07 09:37:57 --> URI Class Initialized
INFO - 2024-03-07 09:37:57 --> Router Class Initialized
INFO - 2024-03-07 09:37:57 --> Output Class Initialized
INFO - 2024-03-07 09:37:57 --> Security Class Initialized
DEBUG - 2024-03-07 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:37:57 --> Input Class Initialized
INFO - 2024-03-07 09:37:57 --> Language Class Initialized
INFO - 2024-03-07 09:37:57 --> Language Class Initialized
INFO - 2024-03-07 09:37:57 --> Config Class Initialized
INFO - 2024-03-07 09:37:57 --> Loader Class Initialized
INFO - 2024-03-07 09:37:57 --> Helper loaded: url_helper
INFO - 2024-03-07 09:37:57 --> Helper loaded: file_helper
INFO - 2024-03-07 09:37:57 --> Helper loaded: form_helper
INFO - 2024-03-07 09:37:57 --> Helper loaded: my_helper
INFO - 2024-03-07 09:37:57 --> Database Driver Class Initialized
INFO - 2024-03-07 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:37:57 --> Controller Class Initialized
INFO - 2024-03-07 09:37:57 --> Final output sent to browser
DEBUG - 2024-03-07 09:37:57 --> Total execution time: 0.0325
INFO - 2024-03-07 09:40:50 --> Config Class Initialized
INFO - 2024-03-07 09:40:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:40:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:40:50 --> Utf8 Class Initialized
INFO - 2024-03-07 09:40:50 --> URI Class Initialized
INFO - 2024-03-07 09:40:50 --> Router Class Initialized
INFO - 2024-03-07 09:40:50 --> Output Class Initialized
INFO - 2024-03-07 09:40:50 --> Security Class Initialized
DEBUG - 2024-03-07 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:40:50 --> Input Class Initialized
INFO - 2024-03-07 09:40:50 --> Language Class Initialized
INFO - 2024-03-07 09:40:50 --> Language Class Initialized
INFO - 2024-03-07 09:40:50 --> Config Class Initialized
INFO - 2024-03-07 09:40:50 --> Loader Class Initialized
INFO - 2024-03-07 09:40:50 --> Helper loaded: url_helper
INFO - 2024-03-07 09:40:50 --> Helper loaded: file_helper
INFO - 2024-03-07 09:40:50 --> Helper loaded: form_helper
INFO - 2024-03-07 09:40:50 --> Helper loaded: my_helper
INFO - 2024-03-07 09:40:50 --> Database Driver Class Initialized
INFO - 2024-03-07 09:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:40:50 --> Controller Class Initialized
INFO - 2024-03-07 09:40:51 --> Final output sent to browser
DEBUG - 2024-03-07 09:40:51 --> Total execution time: 0.1077
INFO - 2024-03-07 09:40:51 --> Config Class Initialized
INFO - 2024-03-07 09:40:51 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:40:51 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:40:51 --> Utf8 Class Initialized
INFO - 2024-03-07 09:40:51 --> URI Class Initialized
INFO - 2024-03-07 09:40:51 --> Router Class Initialized
INFO - 2024-03-07 09:40:51 --> Output Class Initialized
INFO - 2024-03-07 09:40:51 --> Security Class Initialized
DEBUG - 2024-03-07 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:40:51 --> Input Class Initialized
INFO - 2024-03-07 09:40:51 --> Language Class Initialized
INFO - 2024-03-07 09:40:51 --> Language Class Initialized
INFO - 2024-03-07 09:40:51 --> Config Class Initialized
INFO - 2024-03-07 09:40:51 --> Loader Class Initialized
INFO - 2024-03-07 09:40:51 --> Helper loaded: url_helper
INFO - 2024-03-07 09:40:51 --> Helper loaded: file_helper
INFO - 2024-03-07 09:40:51 --> Helper loaded: form_helper
INFO - 2024-03-07 09:40:51 --> Helper loaded: my_helper
INFO - 2024-03-07 09:40:51 --> Database Driver Class Initialized
INFO - 2024-03-07 09:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:40:51 --> Controller Class Initialized
INFO - 2024-03-07 09:40:53 --> Config Class Initialized
INFO - 2024-03-07 09:40:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:40:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:40:53 --> Utf8 Class Initialized
INFO - 2024-03-07 09:40:53 --> URI Class Initialized
INFO - 2024-03-07 09:40:53 --> Router Class Initialized
INFO - 2024-03-07 09:40:53 --> Output Class Initialized
INFO - 2024-03-07 09:40:53 --> Security Class Initialized
DEBUG - 2024-03-07 09:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:40:53 --> Input Class Initialized
INFO - 2024-03-07 09:40:53 --> Language Class Initialized
INFO - 2024-03-07 09:40:53 --> Language Class Initialized
INFO - 2024-03-07 09:40:53 --> Config Class Initialized
INFO - 2024-03-07 09:40:53 --> Loader Class Initialized
INFO - 2024-03-07 09:40:53 --> Helper loaded: url_helper
INFO - 2024-03-07 09:40:53 --> Helper loaded: file_helper
INFO - 2024-03-07 09:40:53 --> Helper loaded: form_helper
INFO - 2024-03-07 09:40:53 --> Helper loaded: my_helper
INFO - 2024-03-07 09:40:53 --> Database Driver Class Initialized
INFO - 2024-03-07 09:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:40:53 --> Controller Class Initialized
INFO - 2024-03-07 09:40:53 --> Final output sent to browser
DEBUG - 2024-03-07 09:40:53 --> Total execution time: 0.1206
INFO - 2024-03-07 09:40:56 --> Config Class Initialized
INFO - 2024-03-07 09:40:56 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:40:56 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:40:56 --> Utf8 Class Initialized
INFO - 2024-03-07 09:40:56 --> URI Class Initialized
INFO - 2024-03-07 09:40:56 --> Router Class Initialized
INFO - 2024-03-07 09:40:56 --> Output Class Initialized
INFO - 2024-03-07 09:40:56 --> Security Class Initialized
DEBUG - 2024-03-07 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:40:56 --> Input Class Initialized
INFO - 2024-03-07 09:40:56 --> Language Class Initialized
INFO - 2024-03-07 09:40:56 --> Language Class Initialized
INFO - 2024-03-07 09:40:56 --> Config Class Initialized
INFO - 2024-03-07 09:40:56 --> Loader Class Initialized
INFO - 2024-03-07 09:40:56 --> Helper loaded: url_helper
INFO - 2024-03-07 09:40:56 --> Helper loaded: file_helper
INFO - 2024-03-07 09:40:56 --> Helper loaded: form_helper
INFO - 2024-03-07 09:40:56 --> Helper loaded: my_helper
INFO - 2024-03-07 09:40:56 --> Database Driver Class Initialized
INFO - 2024-03-07 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:40:56 --> Controller Class Initialized
INFO - 2024-03-07 09:48:17 --> Config Class Initialized
INFO - 2024-03-07 09:48:17 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:48:17 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:48:17 --> Utf8 Class Initialized
INFO - 2024-03-07 09:48:17 --> URI Class Initialized
INFO - 2024-03-07 09:48:17 --> Router Class Initialized
INFO - 2024-03-07 09:48:17 --> Output Class Initialized
INFO - 2024-03-07 09:48:17 --> Security Class Initialized
DEBUG - 2024-03-07 09:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:48:17 --> Input Class Initialized
INFO - 2024-03-07 09:48:17 --> Language Class Initialized
INFO - 2024-03-07 09:48:17 --> Language Class Initialized
INFO - 2024-03-07 09:48:17 --> Config Class Initialized
INFO - 2024-03-07 09:48:17 --> Loader Class Initialized
INFO - 2024-03-07 09:48:17 --> Helper loaded: url_helper
INFO - 2024-03-07 09:48:17 --> Helper loaded: file_helper
INFO - 2024-03-07 09:48:17 --> Helper loaded: form_helper
INFO - 2024-03-07 09:48:17 --> Helper loaded: my_helper
INFO - 2024-03-07 09:48:17 --> Database Driver Class Initialized
INFO - 2024-03-07 09:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:48:17 --> Controller Class Initialized
INFO - 2024-03-07 09:48:17 --> Final output sent to browser
DEBUG - 2024-03-07 09:48:17 --> Total execution time: 0.0317
INFO - 2024-03-07 09:48:32 --> Config Class Initialized
INFO - 2024-03-07 09:48:32 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:48:32 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:48:32 --> Utf8 Class Initialized
INFO - 2024-03-07 09:48:32 --> URI Class Initialized
INFO - 2024-03-07 09:48:32 --> Router Class Initialized
INFO - 2024-03-07 09:48:32 --> Output Class Initialized
INFO - 2024-03-07 09:48:32 --> Security Class Initialized
DEBUG - 2024-03-07 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:48:32 --> Input Class Initialized
INFO - 2024-03-07 09:48:32 --> Language Class Initialized
INFO - 2024-03-07 09:48:32 --> Language Class Initialized
INFO - 2024-03-07 09:48:32 --> Config Class Initialized
INFO - 2024-03-07 09:48:32 --> Loader Class Initialized
INFO - 2024-03-07 09:48:32 --> Helper loaded: url_helper
INFO - 2024-03-07 09:48:32 --> Helper loaded: file_helper
INFO - 2024-03-07 09:48:32 --> Helper loaded: form_helper
INFO - 2024-03-07 09:48:32 --> Helper loaded: my_helper
INFO - 2024-03-07 09:48:32 --> Database Driver Class Initialized
INFO - 2024-03-07 09:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:48:32 --> Controller Class Initialized
INFO - 2024-03-07 09:48:32 --> Final output sent to browser
DEBUG - 2024-03-07 09:48:32 --> Total execution time: 0.0308
INFO - 2024-03-07 09:48:44 --> Config Class Initialized
INFO - 2024-03-07 09:48:44 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:48:44 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:48:44 --> Utf8 Class Initialized
INFO - 2024-03-07 09:48:44 --> URI Class Initialized
INFO - 2024-03-07 09:48:44 --> Router Class Initialized
INFO - 2024-03-07 09:48:44 --> Output Class Initialized
INFO - 2024-03-07 09:48:44 --> Security Class Initialized
DEBUG - 2024-03-07 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:48:44 --> Input Class Initialized
INFO - 2024-03-07 09:48:44 --> Language Class Initialized
INFO - 2024-03-07 09:48:44 --> Language Class Initialized
INFO - 2024-03-07 09:48:44 --> Config Class Initialized
INFO - 2024-03-07 09:48:44 --> Loader Class Initialized
INFO - 2024-03-07 09:48:44 --> Helper loaded: url_helper
INFO - 2024-03-07 09:48:44 --> Helper loaded: file_helper
INFO - 2024-03-07 09:48:44 --> Helper loaded: form_helper
INFO - 2024-03-07 09:48:44 --> Helper loaded: my_helper
INFO - 2024-03-07 09:48:44 --> Database Driver Class Initialized
INFO - 2024-03-07 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:48:44 --> Controller Class Initialized
INFO - 2024-03-07 09:48:44 --> Final output sent to browser
DEBUG - 2024-03-07 09:48:44 --> Total execution time: 0.0378
INFO - 2024-03-07 09:48:44 --> Config Class Initialized
INFO - 2024-03-07 09:48:44 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:48:44 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:48:44 --> Utf8 Class Initialized
INFO - 2024-03-07 09:48:44 --> URI Class Initialized
INFO - 2024-03-07 09:48:44 --> Router Class Initialized
INFO - 2024-03-07 09:48:44 --> Output Class Initialized
INFO - 2024-03-07 09:48:44 --> Security Class Initialized
DEBUG - 2024-03-07 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:48:44 --> Input Class Initialized
INFO - 2024-03-07 09:48:44 --> Language Class Initialized
INFO - 2024-03-07 09:48:44 --> Language Class Initialized
INFO - 2024-03-07 09:48:44 --> Config Class Initialized
INFO - 2024-03-07 09:48:44 --> Loader Class Initialized
INFO - 2024-03-07 09:48:44 --> Helper loaded: url_helper
INFO - 2024-03-07 09:48:44 --> Helper loaded: file_helper
INFO - 2024-03-07 09:48:44 --> Helper loaded: form_helper
INFO - 2024-03-07 09:48:44 --> Helper loaded: my_helper
INFO - 2024-03-07 09:48:44 --> Database Driver Class Initialized
INFO - 2024-03-07 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:48:44 --> Controller Class Initialized
INFO - 2024-03-07 09:57:28 --> Config Class Initialized
INFO - 2024-03-07 09:57:28 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:28 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:28 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:28 --> URI Class Initialized
INFO - 2024-03-07 09:57:28 --> Router Class Initialized
INFO - 2024-03-07 09:57:28 --> Output Class Initialized
INFO - 2024-03-07 09:57:28 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:28 --> Input Class Initialized
INFO - 2024-03-07 09:57:28 --> Language Class Initialized
INFO - 2024-03-07 09:57:28 --> Language Class Initialized
INFO - 2024-03-07 09:57:28 --> Config Class Initialized
INFO - 2024-03-07 09:57:28 --> Loader Class Initialized
INFO - 2024-03-07 09:57:28 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:28 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:28 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:28 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:28 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:28 --> Controller Class Initialized
DEBUG - 2024-03-07 09:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-03-07 09:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:57:28 --> Final output sent to browser
DEBUG - 2024-03-07 09:57:28 --> Total execution time: 0.0432
INFO - 2024-03-07 09:57:49 --> Config Class Initialized
INFO - 2024-03-07 09:57:49 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:49 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:49 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:49 --> URI Class Initialized
INFO - 2024-03-07 09:57:49 --> Router Class Initialized
INFO - 2024-03-07 09:57:49 --> Output Class Initialized
INFO - 2024-03-07 09:57:49 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:49 --> Input Class Initialized
INFO - 2024-03-07 09:57:49 --> Language Class Initialized
INFO - 2024-03-07 09:57:49 --> Language Class Initialized
INFO - 2024-03-07 09:57:49 --> Config Class Initialized
INFO - 2024-03-07 09:57:49 --> Loader Class Initialized
INFO - 2024-03-07 09:57:49 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:49 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:49 --> Controller Class Initialized
INFO - 2024-03-07 09:57:49 --> Config Class Initialized
INFO - 2024-03-07 09:57:49 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:49 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:49 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:49 --> URI Class Initialized
INFO - 2024-03-07 09:57:49 --> Router Class Initialized
INFO - 2024-03-07 09:57:49 --> Output Class Initialized
INFO - 2024-03-07 09:57:49 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:49 --> Input Class Initialized
INFO - 2024-03-07 09:57:49 --> Language Class Initialized
INFO - 2024-03-07 09:57:49 --> Language Class Initialized
INFO - 2024-03-07 09:57:49 --> Config Class Initialized
INFO - 2024-03-07 09:57:49 --> Loader Class Initialized
INFO - 2024-03-07 09:57:49 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:49 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:49 --> Controller Class Initialized
DEBUG - 2024-03-07 09:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 09:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:57:49 --> Final output sent to browser
DEBUG - 2024-03-07 09:57:49 --> Total execution time: 0.0790
INFO - 2024-03-07 09:57:49 --> Config Class Initialized
INFO - 2024-03-07 09:57:49 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:49 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:49 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:49 --> URI Class Initialized
INFO - 2024-03-07 09:57:49 --> Router Class Initialized
INFO - 2024-03-07 09:57:49 --> Output Class Initialized
INFO - 2024-03-07 09:57:49 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:49 --> Input Class Initialized
INFO - 2024-03-07 09:57:49 --> Language Class Initialized
INFO - 2024-03-07 09:57:49 --> Language Class Initialized
INFO - 2024-03-07 09:57:49 --> Config Class Initialized
INFO - 2024-03-07 09:57:49 --> Loader Class Initialized
INFO - 2024-03-07 09:57:49 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:49 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:49 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:49 --> Controller Class Initialized
INFO - 2024-03-07 09:57:53 --> Config Class Initialized
INFO - 2024-03-07 09:57:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:53 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:53 --> URI Class Initialized
INFO - 2024-03-07 09:57:53 --> Router Class Initialized
INFO - 2024-03-07 09:57:53 --> Output Class Initialized
INFO - 2024-03-07 09:57:53 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:53 --> Input Class Initialized
INFO - 2024-03-07 09:57:53 --> Language Class Initialized
INFO - 2024-03-07 09:57:53 --> Language Class Initialized
INFO - 2024-03-07 09:57:53 --> Config Class Initialized
INFO - 2024-03-07 09:57:53 --> Loader Class Initialized
INFO - 2024-03-07 09:57:53 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:53 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:53 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:53 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:53 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:53 --> Controller Class Initialized
INFO - 2024-03-07 09:57:53 --> Final output sent to browser
DEBUG - 2024-03-07 09:57:53 --> Total execution time: 0.0331
INFO - 2024-03-07 09:57:55 --> Config Class Initialized
INFO - 2024-03-07 09:57:55 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:55 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:55 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:55 --> URI Class Initialized
INFO - 2024-03-07 09:57:55 --> Router Class Initialized
INFO - 2024-03-07 09:57:55 --> Output Class Initialized
INFO - 2024-03-07 09:57:55 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:55 --> Input Class Initialized
INFO - 2024-03-07 09:57:55 --> Language Class Initialized
INFO - 2024-03-07 09:57:55 --> Language Class Initialized
INFO - 2024-03-07 09:57:55 --> Config Class Initialized
INFO - 2024-03-07 09:57:55 --> Loader Class Initialized
INFO - 2024-03-07 09:57:55 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:55 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:55 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:55 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:55 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:55 --> Controller Class Initialized
INFO - 2024-03-07 09:57:55 --> Final output sent to browser
DEBUG - 2024-03-07 09:57:55 --> Total execution time: 0.0905
INFO - 2024-03-07 09:57:58 --> Config Class Initialized
INFO - 2024-03-07 09:57:58 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:57:58 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:57:58 --> Utf8 Class Initialized
INFO - 2024-03-07 09:57:58 --> URI Class Initialized
INFO - 2024-03-07 09:57:58 --> Router Class Initialized
INFO - 2024-03-07 09:57:58 --> Output Class Initialized
INFO - 2024-03-07 09:57:58 --> Security Class Initialized
DEBUG - 2024-03-07 09:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:57:58 --> Input Class Initialized
INFO - 2024-03-07 09:57:58 --> Language Class Initialized
INFO - 2024-03-07 09:57:58 --> Language Class Initialized
INFO - 2024-03-07 09:57:58 --> Config Class Initialized
INFO - 2024-03-07 09:57:58 --> Loader Class Initialized
INFO - 2024-03-07 09:57:58 --> Helper loaded: url_helper
INFO - 2024-03-07 09:57:58 --> Helper loaded: file_helper
INFO - 2024-03-07 09:57:58 --> Helper loaded: form_helper
INFO - 2024-03-07 09:57:58 --> Helper loaded: my_helper
INFO - 2024-03-07 09:57:58 --> Database Driver Class Initialized
INFO - 2024-03-07 09:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:57:58 --> Controller Class Initialized
DEBUG - 2024-03-07 09:57:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-07 09:57:58 --> Final output sent to browser
DEBUG - 2024-03-07 09:57:58 --> Total execution time: 0.0535
INFO - 2024-03-07 09:58:32 --> Config Class Initialized
INFO - 2024-03-07 09:58:32 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:32 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:32 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:32 --> URI Class Initialized
INFO - 2024-03-07 09:58:32 --> Router Class Initialized
INFO - 2024-03-07 09:58:32 --> Output Class Initialized
INFO - 2024-03-07 09:58:32 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:32 --> Input Class Initialized
INFO - 2024-03-07 09:58:32 --> Language Class Initialized
INFO - 2024-03-07 09:58:32 --> Language Class Initialized
INFO - 2024-03-07 09:58:32 --> Config Class Initialized
INFO - 2024-03-07 09:58:32 --> Loader Class Initialized
INFO - 2024-03-07 09:58:32 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:32 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:32 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:32 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:32 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:32 --> Controller Class Initialized
DEBUG - 2024-03-07 09:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-07 09:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:58:32 --> Final output sent to browser
DEBUG - 2024-03-07 09:58:32 --> Total execution time: 0.0624
INFO - 2024-03-07 09:58:34 --> Config Class Initialized
INFO - 2024-03-07 09:58:34 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:34 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:34 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:34 --> URI Class Initialized
INFO - 2024-03-07 09:58:34 --> Router Class Initialized
INFO - 2024-03-07 09:58:34 --> Output Class Initialized
INFO - 2024-03-07 09:58:34 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:34 --> Input Class Initialized
INFO - 2024-03-07 09:58:34 --> Language Class Initialized
INFO - 2024-03-07 09:58:34 --> Language Class Initialized
INFO - 2024-03-07 09:58:34 --> Config Class Initialized
INFO - 2024-03-07 09:58:34 --> Loader Class Initialized
INFO - 2024-03-07 09:58:34 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:34 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:34 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:34 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:34 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:34 --> Controller Class Initialized
DEBUG - 2024-03-07 09:58:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 09:58:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:58:34 --> Final output sent to browser
DEBUG - 2024-03-07 09:58:34 --> Total execution time: 0.0430
INFO - 2024-03-07 09:58:34 --> Config Class Initialized
INFO - 2024-03-07 09:58:34 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:34 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:34 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:34 --> URI Class Initialized
INFO - 2024-03-07 09:58:34 --> Router Class Initialized
INFO - 2024-03-07 09:58:34 --> Output Class Initialized
INFO - 2024-03-07 09:58:34 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:34 --> Input Class Initialized
INFO - 2024-03-07 09:58:34 --> Language Class Initialized
INFO - 2024-03-07 09:58:34 --> Language Class Initialized
INFO - 2024-03-07 09:58:34 --> Config Class Initialized
INFO - 2024-03-07 09:58:34 --> Loader Class Initialized
INFO - 2024-03-07 09:58:34 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:34 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:34 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:34 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:34 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:34 --> Controller Class Initialized
INFO - 2024-03-07 09:58:37 --> Config Class Initialized
INFO - 2024-03-07 09:58:37 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:37 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:37 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:37 --> URI Class Initialized
INFO - 2024-03-07 09:58:37 --> Router Class Initialized
INFO - 2024-03-07 09:58:37 --> Output Class Initialized
INFO - 2024-03-07 09:58:37 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:37 --> Input Class Initialized
INFO - 2024-03-07 09:58:37 --> Language Class Initialized
INFO - 2024-03-07 09:58:37 --> Language Class Initialized
INFO - 2024-03-07 09:58:37 --> Config Class Initialized
INFO - 2024-03-07 09:58:37 --> Loader Class Initialized
INFO - 2024-03-07 09:58:37 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:37 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:37 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:37 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:37 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:37 --> Controller Class Initialized
INFO - 2024-03-07 09:58:37 --> Final output sent to browser
DEBUG - 2024-03-07 09:58:37 --> Total execution time: 0.0498
INFO - 2024-03-07 09:58:40 --> Config Class Initialized
INFO - 2024-03-07 09:58:40 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:40 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:40 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:40 --> URI Class Initialized
INFO - 2024-03-07 09:58:40 --> Router Class Initialized
INFO - 2024-03-07 09:58:40 --> Output Class Initialized
INFO - 2024-03-07 09:58:40 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:40 --> Input Class Initialized
INFO - 2024-03-07 09:58:40 --> Language Class Initialized
INFO - 2024-03-07 09:58:40 --> Language Class Initialized
INFO - 2024-03-07 09:58:40 --> Config Class Initialized
INFO - 2024-03-07 09:58:40 --> Loader Class Initialized
INFO - 2024-03-07 09:58:40 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:40 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:40 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:40 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:40 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:40 --> Controller Class Initialized
DEBUG - 2024-03-07 09:58:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-07 09:58:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:58:40 --> Final output sent to browser
DEBUG - 2024-03-07 09:58:40 --> Total execution time: 0.0309
INFO - 2024-03-07 09:58:43 --> Config Class Initialized
INFO - 2024-03-07 09:58:43 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:43 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:43 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:43 --> URI Class Initialized
INFO - 2024-03-07 09:58:43 --> Router Class Initialized
INFO - 2024-03-07 09:58:43 --> Output Class Initialized
INFO - 2024-03-07 09:58:43 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:43 --> Input Class Initialized
INFO - 2024-03-07 09:58:43 --> Language Class Initialized
INFO - 2024-03-07 09:58:43 --> Language Class Initialized
INFO - 2024-03-07 09:58:43 --> Config Class Initialized
INFO - 2024-03-07 09:58:43 --> Loader Class Initialized
INFO - 2024-03-07 09:58:43 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:43 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:43 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:43 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:43 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:43 --> Controller Class Initialized
DEBUG - 2024-03-07 09:58:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 09:58:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 09:58:43 --> Final output sent to browser
DEBUG - 2024-03-07 09:58:43 --> Total execution time: 0.0324
INFO - 2024-03-07 09:58:43 --> Config Class Initialized
INFO - 2024-03-07 09:58:43 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:43 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:43 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:43 --> URI Class Initialized
INFO - 2024-03-07 09:58:43 --> Router Class Initialized
INFO - 2024-03-07 09:58:43 --> Output Class Initialized
INFO - 2024-03-07 09:58:43 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:43 --> Input Class Initialized
INFO - 2024-03-07 09:58:43 --> Language Class Initialized
INFO - 2024-03-07 09:58:43 --> Language Class Initialized
INFO - 2024-03-07 09:58:43 --> Config Class Initialized
INFO - 2024-03-07 09:58:43 --> Loader Class Initialized
INFO - 2024-03-07 09:58:43 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:43 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:43 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:43 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:43 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:43 --> Controller Class Initialized
INFO - 2024-03-07 09:58:47 --> Config Class Initialized
INFO - 2024-03-07 09:58:47 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:58:47 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:58:47 --> Utf8 Class Initialized
INFO - 2024-03-07 09:58:47 --> URI Class Initialized
INFO - 2024-03-07 09:58:47 --> Router Class Initialized
INFO - 2024-03-07 09:58:47 --> Output Class Initialized
INFO - 2024-03-07 09:58:47 --> Security Class Initialized
DEBUG - 2024-03-07 09:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:58:47 --> Input Class Initialized
INFO - 2024-03-07 09:58:47 --> Language Class Initialized
INFO - 2024-03-07 09:58:47 --> Language Class Initialized
INFO - 2024-03-07 09:58:47 --> Config Class Initialized
INFO - 2024-03-07 09:58:47 --> Loader Class Initialized
INFO - 2024-03-07 09:58:47 --> Helper loaded: url_helper
INFO - 2024-03-07 09:58:47 --> Helper loaded: file_helper
INFO - 2024-03-07 09:58:47 --> Helper loaded: form_helper
INFO - 2024-03-07 09:58:47 --> Helper loaded: my_helper
INFO - 2024-03-07 09:58:47 --> Database Driver Class Initialized
INFO - 2024-03-07 09:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:58:47 --> Controller Class Initialized
INFO - 2024-03-07 09:58:47 --> Final output sent to browser
DEBUG - 2024-03-07 09:58:47 --> Total execution time: 0.0299
INFO - 2024-03-07 09:59:47 --> Config Class Initialized
INFO - 2024-03-07 09:59:47 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:59:47 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:59:47 --> Utf8 Class Initialized
INFO - 2024-03-07 09:59:47 --> URI Class Initialized
INFO - 2024-03-07 09:59:47 --> Router Class Initialized
INFO - 2024-03-07 09:59:47 --> Output Class Initialized
INFO - 2024-03-07 09:59:47 --> Security Class Initialized
DEBUG - 2024-03-07 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:59:47 --> Input Class Initialized
INFO - 2024-03-07 09:59:47 --> Language Class Initialized
INFO - 2024-03-07 09:59:47 --> Language Class Initialized
INFO - 2024-03-07 09:59:47 --> Config Class Initialized
INFO - 2024-03-07 09:59:47 --> Loader Class Initialized
INFO - 2024-03-07 09:59:47 --> Helper loaded: url_helper
INFO - 2024-03-07 09:59:47 --> Helper loaded: file_helper
INFO - 2024-03-07 09:59:47 --> Helper loaded: form_helper
INFO - 2024-03-07 09:59:47 --> Helper loaded: my_helper
INFO - 2024-03-07 09:59:47 --> Database Driver Class Initialized
INFO - 2024-03-07 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:59:47 --> Controller Class Initialized
INFO - 2024-03-07 09:59:47 --> Final output sent to browser
DEBUG - 2024-03-07 09:59:47 --> Total execution time: 0.0765
INFO - 2024-03-07 09:59:47 --> Config Class Initialized
INFO - 2024-03-07 09:59:47 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:59:47 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:59:47 --> Utf8 Class Initialized
INFO - 2024-03-07 09:59:47 --> URI Class Initialized
INFO - 2024-03-07 09:59:47 --> Router Class Initialized
INFO - 2024-03-07 09:59:47 --> Output Class Initialized
INFO - 2024-03-07 09:59:47 --> Security Class Initialized
DEBUG - 2024-03-07 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:59:47 --> Input Class Initialized
INFO - 2024-03-07 09:59:47 --> Language Class Initialized
INFO - 2024-03-07 09:59:47 --> Language Class Initialized
INFO - 2024-03-07 09:59:47 --> Config Class Initialized
INFO - 2024-03-07 09:59:47 --> Loader Class Initialized
INFO - 2024-03-07 09:59:47 --> Helper loaded: url_helper
INFO - 2024-03-07 09:59:47 --> Helper loaded: file_helper
INFO - 2024-03-07 09:59:47 --> Helper loaded: form_helper
INFO - 2024-03-07 09:59:47 --> Helper loaded: my_helper
INFO - 2024-03-07 09:59:47 --> Database Driver Class Initialized
INFO - 2024-03-07 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:59:47 --> Controller Class Initialized
INFO - 2024-03-07 09:59:49 --> Config Class Initialized
INFO - 2024-03-07 09:59:49 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:59:49 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:59:49 --> Utf8 Class Initialized
INFO - 2024-03-07 09:59:49 --> URI Class Initialized
INFO - 2024-03-07 09:59:49 --> Router Class Initialized
INFO - 2024-03-07 09:59:49 --> Output Class Initialized
INFO - 2024-03-07 09:59:49 --> Security Class Initialized
DEBUG - 2024-03-07 09:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:59:49 --> Input Class Initialized
INFO - 2024-03-07 09:59:49 --> Language Class Initialized
INFO - 2024-03-07 09:59:49 --> Language Class Initialized
INFO - 2024-03-07 09:59:49 --> Config Class Initialized
INFO - 2024-03-07 09:59:49 --> Loader Class Initialized
INFO - 2024-03-07 09:59:49 --> Helper loaded: url_helper
INFO - 2024-03-07 09:59:49 --> Helper loaded: file_helper
INFO - 2024-03-07 09:59:49 --> Helper loaded: form_helper
INFO - 2024-03-07 09:59:49 --> Helper loaded: my_helper
INFO - 2024-03-07 09:59:49 --> Database Driver Class Initialized
INFO - 2024-03-07 09:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:59:49 --> Controller Class Initialized
INFO - 2024-03-07 09:59:49 --> Final output sent to browser
DEBUG - 2024-03-07 09:59:49 --> Total execution time: 0.0604
INFO - 2024-03-07 09:59:52 --> Config Class Initialized
INFO - 2024-03-07 09:59:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:59:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:59:52 --> Utf8 Class Initialized
INFO - 2024-03-07 09:59:52 --> URI Class Initialized
INFO - 2024-03-07 09:59:52 --> Router Class Initialized
INFO - 2024-03-07 09:59:52 --> Output Class Initialized
INFO - 2024-03-07 09:59:52 --> Security Class Initialized
DEBUG - 2024-03-07 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:59:52 --> Input Class Initialized
INFO - 2024-03-07 09:59:52 --> Language Class Initialized
INFO - 2024-03-07 09:59:52 --> Language Class Initialized
INFO - 2024-03-07 09:59:52 --> Config Class Initialized
INFO - 2024-03-07 09:59:52 --> Loader Class Initialized
INFO - 2024-03-07 09:59:52 --> Helper loaded: url_helper
INFO - 2024-03-07 09:59:52 --> Helper loaded: file_helper
INFO - 2024-03-07 09:59:52 --> Helper loaded: form_helper
INFO - 2024-03-07 09:59:52 --> Helper loaded: my_helper
INFO - 2024-03-07 09:59:52 --> Database Driver Class Initialized
INFO - 2024-03-07 09:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:59:52 --> Controller Class Initialized
INFO - 2024-03-07 09:59:52 --> Final output sent to browser
DEBUG - 2024-03-07 09:59:52 --> Total execution time: 0.0351
INFO - 2024-03-07 09:59:52 --> Config Class Initialized
INFO - 2024-03-07 09:59:52 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:59:52 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:59:52 --> Utf8 Class Initialized
INFO - 2024-03-07 09:59:52 --> URI Class Initialized
INFO - 2024-03-07 09:59:52 --> Router Class Initialized
INFO - 2024-03-07 09:59:52 --> Output Class Initialized
INFO - 2024-03-07 09:59:52 --> Security Class Initialized
DEBUG - 2024-03-07 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:59:52 --> Input Class Initialized
INFO - 2024-03-07 09:59:52 --> Language Class Initialized
INFO - 2024-03-07 09:59:52 --> Language Class Initialized
INFO - 2024-03-07 09:59:52 --> Config Class Initialized
INFO - 2024-03-07 09:59:52 --> Loader Class Initialized
INFO - 2024-03-07 09:59:52 --> Helper loaded: url_helper
INFO - 2024-03-07 09:59:52 --> Helper loaded: file_helper
INFO - 2024-03-07 09:59:52 --> Helper loaded: form_helper
INFO - 2024-03-07 09:59:52 --> Helper loaded: my_helper
INFO - 2024-03-07 09:59:52 --> Database Driver Class Initialized
INFO - 2024-03-07 09:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:59:52 --> Controller Class Initialized
INFO - 2024-03-07 09:59:55 --> Config Class Initialized
INFO - 2024-03-07 09:59:55 --> Hooks Class Initialized
DEBUG - 2024-03-07 09:59:55 --> UTF-8 Support Enabled
INFO - 2024-03-07 09:59:55 --> Utf8 Class Initialized
INFO - 2024-03-07 09:59:55 --> URI Class Initialized
INFO - 2024-03-07 09:59:55 --> Router Class Initialized
INFO - 2024-03-07 09:59:55 --> Output Class Initialized
INFO - 2024-03-07 09:59:55 --> Security Class Initialized
DEBUG - 2024-03-07 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 09:59:55 --> Input Class Initialized
INFO - 2024-03-07 09:59:55 --> Language Class Initialized
INFO - 2024-03-07 09:59:55 --> Language Class Initialized
INFO - 2024-03-07 09:59:55 --> Config Class Initialized
INFO - 2024-03-07 09:59:55 --> Loader Class Initialized
INFO - 2024-03-07 09:59:55 --> Helper loaded: url_helper
INFO - 2024-03-07 09:59:55 --> Helper loaded: file_helper
INFO - 2024-03-07 09:59:55 --> Helper loaded: form_helper
INFO - 2024-03-07 09:59:55 --> Helper loaded: my_helper
INFO - 2024-03-07 09:59:55 --> Database Driver Class Initialized
INFO - 2024-03-07 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 09:59:55 --> Controller Class Initialized
INFO - 2024-03-07 10:01:26 --> Config Class Initialized
INFO - 2024-03-07 10:01:26 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:01:26 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:01:26 --> Utf8 Class Initialized
INFO - 2024-03-07 10:01:26 --> URI Class Initialized
INFO - 2024-03-07 10:01:26 --> Router Class Initialized
INFO - 2024-03-07 10:01:26 --> Output Class Initialized
INFO - 2024-03-07 10:01:26 --> Security Class Initialized
DEBUG - 2024-03-07 10:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:01:26 --> Input Class Initialized
INFO - 2024-03-07 10:01:26 --> Language Class Initialized
INFO - 2024-03-07 10:01:26 --> Language Class Initialized
INFO - 2024-03-07 10:01:26 --> Config Class Initialized
INFO - 2024-03-07 10:01:26 --> Loader Class Initialized
INFO - 2024-03-07 10:01:26 --> Helper loaded: url_helper
INFO - 2024-03-07 10:01:26 --> Helper loaded: file_helper
INFO - 2024-03-07 10:01:26 --> Helper loaded: form_helper
INFO - 2024-03-07 10:01:26 --> Helper loaded: my_helper
INFO - 2024-03-07 10:01:26 --> Database Driver Class Initialized
INFO - 2024-03-07 10:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:01:26 --> Controller Class Initialized
DEBUG - 2024-03-07 10:01:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-03-07 10:01:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:01:26 --> Final output sent to browser
DEBUG - 2024-03-07 10:01:26 --> Total execution time: 0.0303
INFO - 2024-03-07 10:01:53 --> Config Class Initialized
INFO - 2024-03-07 10:01:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:01:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:01:53 --> Utf8 Class Initialized
INFO - 2024-03-07 10:01:53 --> URI Class Initialized
INFO - 2024-03-07 10:01:53 --> Router Class Initialized
INFO - 2024-03-07 10:01:53 --> Output Class Initialized
INFO - 2024-03-07 10:01:53 --> Security Class Initialized
DEBUG - 2024-03-07 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:01:53 --> Input Class Initialized
INFO - 2024-03-07 10:01:53 --> Language Class Initialized
INFO - 2024-03-07 10:01:53 --> Language Class Initialized
INFO - 2024-03-07 10:01:53 --> Config Class Initialized
INFO - 2024-03-07 10:01:53 --> Loader Class Initialized
INFO - 2024-03-07 10:01:53 --> Helper loaded: url_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: file_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: form_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: my_helper
INFO - 2024-03-07 10:01:53 --> Database Driver Class Initialized
INFO - 2024-03-07 10:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:01:53 --> Controller Class Initialized
INFO - 2024-03-07 10:01:53 --> Config Class Initialized
INFO - 2024-03-07 10:01:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:01:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:01:53 --> Utf8 Class Initialized
INFO - 2024-03-07 10:01:53 --> URI Class Initialized
INFO - 2024-03-07 10:01:53 --> Router Class Initialized
INFO - 2024-03-07 10:01:53 --> Output Class Initialized
INFO - 2024-03-07 10:01:53 --> Security Class Initialized
DEBUG - 2024-03-07 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:01:53 --> Input Class Initialized
INFO - 2024-03-07 10:01:53 --> Language Class Initialized
INFO - 2024-03-07 10:01:53 --> Language Class Initialized
INFO - 2024-03-07 10:01:53 --> Config Class Initialized
INFO - 2024-03-07 10:01:53 --> Loader Class Initialized
INFO - 2024-03-07 10:01:53 --> Helper loaded: url_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: file_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: form_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: my_helper
INFO - 2024-03-07 10:01:53 --> Database Driver Class Initialized
INFO - 2024-03-07 10:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:01:53 --> Controller Class Initialized
DEBUG - 2024-03-07 10:01:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 10:01:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:01:53 --> Final output sent to browser
DEBUG - 2024-03-07 10:01:53 --> Total execution time: 0.0352
INFO - 2024-03-07 10:01:53 --> Config Class Initialized
INFO - 2024-03-07 10:01:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:01:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:01:53 --> Utf8 Class Initialized
INFO - 2024-03-07 10:01:53 --> URI Class Initialized
INFO - 2024-03-07 10:01:53 --> Router Class Initialized
INFO - 2024-03-07 10:01:53 --> Output Class Initialized
INFO - 2024-03-07 10:01:53 --> Security Class Initialized
DEBUG - 2024-03-07 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:01:53 --> Input Class Initialized
INFO - 2024-03-07 10:01:53 --> Language Class Initialized
INFO - 2024-03-07 10:01:53 --> Language Class Initialized
INFO - 2024-03-07 10:01:53 --> Config Class Initialized
INFO - 2024-03-07 10:01:53 --> Loader Class Initialized
INFO - 2024-03-07 10:01:53 --> Helper loaded: url_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: file_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: form_helper
INFO - 2024-03-07 10:01:53 --> Helper loaded: my_helper
INFO - 2024-03-07 10:01:53 --> Database Driver Class Initialized
INFO - 2024-03-07 10:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:01:53 --> Controller Class Initialized
INFO - 2024-03-07 10:01:55 --> Config Class Initialized
INFO - 2024-03-07 10:01:55 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:01:55 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:01:55 --> Utf8 Class Initialized
INFO - 2024-03-07 10:01:55 --> URI Class Initialized
INFO - 2024-03-07 10:01:55 --> Router Class Initialized
INFO - 2024-03-07 10:01:55 --> Output Class Initialized
INFO - 2024-03-07 10:01:55 --> Security Class Initialized
DEBUG - 2024-03-07 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:01:55 --> Input Class Initialized
INFO - 2024-03-07 10:01:55 --> Language Class Initialized
INFO - 2024-03-07 10:01:55 --> Language Class Initialized
INFO - 2024-03-07 10:01:55 --> Config Class Initialized
INFO - 2024-03-07 10:01:55 --> Loader Class Initialized
INFO - 2024-03-07 10:01:55 --> Helper loaded: url_helper
INFO - 2024-03-07 10:01:55 --> Helper loaded: file_helper
INFO - 2024-03-07 10:01:55 --> Helper loaded: form_helper
INFO - 2024-03-07 10:01:55 --> Helper loaded: my_helper
INFO - 2024-03-07 10:01:55 --> Database Driver Class Initialized
INFO - 2024-03-07 10:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:01:55 --> Controller Class Initialized
INFO - 2024-03-07 10:01:55 --> Final output sent to browser
DEBUG - 2024-03-07 10:01:55 --> Total execution time: 0.0309
INFO - 2024-03-07 10:01:58 --> Config Class Initialized
INFO - 2024-03-07 10:01:58 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:01:58 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:01:58 --> Utf8 Class Initialized
INFO - 2024-03-07 10:01:58 --> URI Class Initialized
INFO - 2024-03-07 10:01:58 --> Router Class Initialized
INFO - 2024-03-07 10:01:58 --> Output Class Initialized
INFO - 2024-03-07 10:01:58 --> Security Class Initialized
DEBUG - 2024-03-07 10:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:01:58 --> Input Class Initialized
INFO - 2024-03-07 10:01:58 --> Language Class Initialized
INFO - 2024-03-07 10:01:58 --> Language Class Initialized
INFO - 2024-03-07 10:01:58 --> Config Class Initialized
INFO - 2024-03-07 10:01:58 --> Loader Class Initialized
INFO - 2024-03-07 10:01:58 --> Helper loaded: url_helper
INFO - 2024-03-07 10:01:58 --> Helper loaded: file_helper
INFO - 2024-03-07 10:01:58 --> Helper loaded: form_helper
INFO - 2024-03-07 10:01:58 --> Helper loaded: my_helper
INFO - 2024-03-07 10:01:58 --> Database Driver Class Initialized
INFO - 2024-03-07 10:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:01:58 --> Controller Class Initialized
INFO - 2024-03-07 10:01:58 --> Final output sent to browser
DEBUG - 2024-03-07 10:01:58 --> Total execution time: 0.0368
INFO - 2024-03-07 10:02:01 --> Config Class Initialized
INFO - 2024-03-07 10:02:01 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:02:01 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:02:01 --> Utf8 Class Initialized
INFO - 2024-03-07 10:02:01 --> URI Class Initialized
INFO - 2024-03-07 10:02:01 --> Router Class Initialized
INFO - 2024-03-07 10:02:01 --> Output Class Initialized
INFO - 2024-03-07 10:02:01 --> Security Class Initialized
DEBUG - 2024-03-07 10:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:02:01 --> Input Class Initialized
INFO - 2024-03-07 10:02:01 --> Language Class Initialized
INFO - 2024-03-07 10:02:01 --> Language Class Initialized
INFO - 2024-03-07 10:02:01 --> Config Class Initialized
INFO - 2024-03-07 10:02:01 --> Loader Class Initialized
INFO - 2024-03-07 10:02:01 --> Helper loaded: url_helper
INFO - 2024-03-07 10:02:01 --> Helper loaded: file_helper
INFO - 2024-03-07 10:02:01 --> Helper loaded: form_helper
INFO - 2024-03-07 10:02:01 --> Helper loaded: my_helper
INFO - 2024-03-07 10:02:01 --> Database Driver Class Initialized
INFO - 2024-03-07 10:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:02:01 --> Controller Class Initialized
DEBUG - 2024-03-07 10:02:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-07 10:02:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:02:01 --> Final output sent to browser
DEBUG - 2024-03-07 10:02:01 --> Total execution time: 0.0359
INFO - 2024-03-07 10:02:29 --> Config Class Initialized
INFO - 2024-03-07 10:02:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:02:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:02:29 --> Utf8 Class Initialized
INFO - 2024-03-07 10:02:29 --> URI Class Initialized
DEBUG - 2024-03-07 10:02:29 --> No URI present. Default controller set.
INFO - 2024-03-07 10:02:29 --> Router Class Initialized
INFO - 2024-03-07 10:02:29 --> Output Class Initialized
INFO - 2024-03-07 10:02:29 --> Security Class Initialized
DEBUG - 2024-03-07 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:02:29 --> Input Class Initialized
INFO - 2024-03-07 10:02:29 --> Language Class Initialized
INFO - 2024-03-07 10:02:29 --> Language Class Initialized
INFO - 2024-03-07 10:02:29 --> Config Class Initialized
INFO - 2024-03-07 10:02:29 --> Loader Class Initialized
INFO - 2024-03-07 10:02:29 --> Helper loaded: url_helper
INFO - 2024-03-07 10:02:29 --> Helper loaded: file_helper
INFO - 2024-03-07 10:02:29 --> Helper loaded: form_helper
INFO - 2024-03-07 10:02:29 --> Helper loaded: my_helper
INFO - 2024-03-07 10:02:29 --> Database Driver Class Initialized
INFO - 2024-03-07 10:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:02:29 --> Controller Class Initialized
DEBUG - 2024-03-07 10:02:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-07 10:02:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:02:29 --> Final output sent to browser
DEBUG - 2024-03-07 10:02:29 --> Total execution time: 0.0362
INFO - 2024-03-07 10:09:42 --> Config Class Initialized
INFO - 2024-03-07 10:09:42 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:09:42 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:09:42 --> Utf8 Class Initialized
INFO - 2024-03-07 10:09:42 --> URI Class Initialized
INFO - 2024-03-07 10:09:42 --> Router Class Initialized
INFO - 2024-03-07 10:09:42 --> Output Class Initialized
INFO - 2024-03-07 10:09:42 --> Security Class Initialized
DEBUG - 2024-03-07 10:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:09:42 --> Input Class Initialized
INFO - 2024-03-07 10:09:42 --> Language Class Initialized
INFO - 2024-03-07 10:09:42 --> Language Class Initialized
INFO - 2024-03-07 10:09:42 --> Config Class Initialized
INFO - 2024-03-07 10:09:42 --> Loader Class Initialized
INFO - 2024-03-07 10:09:42 --> Helper loaded: url_helper
INFO - 2024-03-07 10:09:42 --> Helper loaded: file_helper
INFO - 2024-03-07 10:09:42 --> Helper loaded: form_helper
INFO - 2024-03-07 10:09:42 --> Helper loaded: my_helper
INFO - 2024-03-07 10:09:42 --> Database Driver Class Initialized
INFO - 2024-03-07 10:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:09:42 --> Controller Class Initialized
DEBUG - 2024-03-07 10:09:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-07 10:09:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:09:42 --> Final output sent to browser
DEBUG - 2024-03-07 10:09:42 --> Total execution time: 0.0322
INFO - 2024-03-07 10:09:48 --> Config Class Initialized
INFO - 2024-03-07 10:09:48 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:09:48 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:09:48 --> Utf8 Class Initialized
INFO - 2024-03-07 10:09:48 --> URI Class Initialized
INFO - 2024-03-07 10:09:48 --> Router Class Initialized
INFO - 2024-03-07 10:09:48 --> Output Class Initialized
INFO - 2024-03-07 10:09:48 --> Security Class Initialized
DEBUG - 2024-03-07 10:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:09:48 --> Input Class Initialized
INFO - 2024-03-07 10:09:48 --> Language Class Initialized
INFO - 2024-03-07 10:09:48 --> Language Class Initialized
INFO - 2024-03-07 10:09:48 --> Config Class Initialized
INFO - 2024-03-07 10:09:48 --> Loader Class Initialized
INFO - 2024-03-07 10:09:48 --> Helper loaded: url_helper
INFO - 2024-03-07 10:09:48 --> Helper loaded: file_helper
INFO - 2024-03-07 10:09:48 --> Helper loaded: form_helper
INFO - 2024-03-07 10:09:48 --> Helper loaded: my_helper
INFO - 2024-03-07 10:09:48 --> Database Driver Class Initialized
INFO - 2024-03-07 10:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:09:48 --> Controller Class Initialized
DEBUG - 2024-03-07 10:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-07 10:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:09:48 --> Final output sent to browser
DEBUG - 2024-03-07 10:09:48 --> Total execution time: 0.0334
INFO - 2024-03-07 10:09:50 --> Config Class Initialized
INFO - 2024-03-07 10:09:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:09:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:09:50 --> Utf8 Class Initialized
INFO - 2024-03-07 10:09:50 --> URI Class Initialized
INFO - 2024-03-07 10:09:50 --> Router Class Initialized
INFO - 2024-03-07 10:09:50 --> Output Class Initialized
INFO - 2024-03-07 10:09:50 --> Security Class Initialized
DEBUG - 2024-03-07 10:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:09:50 --> Input Class Initialized
INFO - 2024-03-07 10:09:50 --> Language Class Initialized
INFO - 2024-03-07 10:09:50 --> Language Class Initialized
INFO - 2024-03-07 10:09:50 --> Config Class Initialized
INFO - 2024-03-07 10:09:50 --> Loader Class Initialized
INFO - 2024-03-07 10:09:50 --> Helper loaded: url_helper
INFO - 2024-03-07 10:09:50 --> Helper loaded: file_helper
INFO - 2024-03-07 10:09:50 --> Helper loaded: form_helper
INFO - 2024-03-07 10:09:50 --> Helper loaded: my_helper
INFO - 2024-03-07 10:09:50 --> Database Driver Class Initialized
INFO - 2024-03-07 10:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:09:50 --> Controller Class Initialized
DEBUG - 2024-03-07 10:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 10:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 10:09:50 --> Final output sent to browser
DEBUG - 2024-03-07 10:09:50 --> Total execution time: 0.0804
INFO - 2024-03-07 10:09:50 --> Config Class Initialized
INFO - 2024-03-07 10:09:50 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:09:50 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:09:50 --> Utf8 Class Initialized
INFO - 2024-03-07 10:09:50 --> URI Class Initialized
INFO - 2024-03-07 10:09:51 --> Router Class Initialized
INFO - 2024-03-07 10:09:51 --> Output Class Initialized
INFO - 2024-03-07 10:09:51 --> Security Class Initialized
DEBUG - 2024-03-07 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:09:51 --> Input Class Initialized
INFO - 2024-03-07 10:09:51 --> Language Class Initialized
INFO - 2024-03-07 10:09:51 --> Language Class Initialized
INFO - 2024-03-07 10:09:51 --> Config Class Initialized
INFO - 2024-03-07 10:09:51 --> Loader Class Initialized
INFO - 2024-03-07 10:09:51 --> Helper loaded: url_helper
INFO - 2024-03-07 10:09:51 --> Helper loaded: file_helper
INFO - 2024-03-07 10:09:51 --> Helper loaded: form_helper
INFO - 2024-03-07 10:09:51 --> Helper loaded: my_helper
INFO - 2024-03-07 10:09:51 --> Database Driver Class Initialized
INFO - 2024-03-07 10:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:09:51 --> Controller Class Initialized
INFO - 2024-03-07 10:09:56 --> Config Class Initialized
INFO - 2024-03-07 10:09:56 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:09:56 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:09:56 --> Utf8 Class Initialized
INFO - 2024-03-07 10:09:56 --> URI Class Initialized
INFO - 2024-03-07 10:09:56 --> Router Class Initialized
INFO - 2024-03-07 10:09:56 --> Output Class Initialized
INFO - 2024-03-07 10:09:56 --> Security Class Initialized
DEBUG - 2024-03-07 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:09:56 --> Input Class Initialized
INFO - 2024-03-07 10:09:56 --> Language Class Initialized
INFO - 2024-03-07 10:09:56 --> Language Class Initialized
INFO - 2024-03-07 10:09:56 --> Config Class Initialized
INFO - 2024-03-07 10:09:56 --> Loader Class Initialized
INFO - 2024-03-07 10:09:56 --> Helper loaded: url_helper
INFO - 2024-03-07 10:09:56 --> Helper loaded: file_helper
INFO - 2024-03-07 10:09:56 --> Helper loaded: form_helper
INFO - 2024-03-07 10:09:56 --> Helper loaded: my_helper
INFO - 2024-03-07 10:09:56 --> Database Driver Class Initialized
INFO - 2024-03-07 10:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:09:56 --> Controller Class Initialized
INFO - 2024-03-07 10:09:56 --> Final output sent to browser
DEBUG - 2024-03-07 10:09:56 --> Total execution time: 0.0412
INFO - 2024-03-07 10:09:57 --> Config Class Initialized
INFO - 2024-03-07 10:09:57 --> Hooks Class Initialized
DEBUG - 2024-03-07 10:09:57 --> UTF-8 Support Enabled
INFO - 2024-03-07 10:09:57 --> Utf8 Class Initialized
INFO - 2024-03-07 10:09:57 --> URI Class Initialized
INFO - 2024-03-07 10:09:57 --> Router Class Initialized
INFO - 2024-03-07 10:09:57 --> Output Class Initialized
INFO - 2024-03-07 10:09:57 --> Security Class Initialized
DEBUG - 2024-03-07 10:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 10:09:57 --> Input Class Initialized
INFO - 2024-03-07 10:09:57 --> Language Class Initialized
INFO - 2024-03-07 10:09:57 --> Language Class Initialized
INFO - 2024-03-07 10:09:57 --> Config Class Initialized
INFO - 2024-03-07 10:09:57 --> Loader Class Initialized
INFO - 2024-03-07 10:09:57 --> Helper loaded: url_helper
INFO - 2024-03-07 10:09:57 --> Helper loaded: file_helper
INFO - 2024-03-07 10:09:57 --> Helper loaded: form_helper
INFO - 2024-03-07 10:09:57 --> Helper loaded: my_helper
INFO - 2024-03-07 10:09:57 --> Database Driver Class Initialized
INFO - 2024-03-07 10:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 10:09:57 --> Controller Class Initialized
INFO - 2024-03-07 10:09:57 --> Final output sent to browser
DEBUG - 2024-03-07 10:09:57 --> Total execution time: 0.0424
INFO - 2024-03-07 11:23:17 --> Config Class Initialized
INFO - 2024-03-07 11:23:17 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:17 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:17 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:17 --> URI Class Initialized
DEBUG - 2024-03-07 11:23:17 --> No URI present. Default controller set.
INFO - 2024-03-07 11:23:17 --> Router Class Initialized
INFO - 2024-03-07 11:23:17 --> Output Class Initialized
INFO - 2024-03-07 11:23:17 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:17 --> Input Class Initialized
INFO - 2024-03-07 11:23:17 --> Language Class Initialized
INFO - 2024-03-07 11:23:17 --> Language Class Initialized
INFO - 2024-03-07 11:23:17 --> Config Class Initialized
INFO - 2024-03-07 11:23:17 --> Loader Class Initialized
INFO - 2024-03-07 11:23:17 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:17 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:17 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:17 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:17 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:17 --> Controller Class Initialized
INFO - 2024-03-07 11:23:17 --> Config Class Initialized
INFO - 2024-03-07 11:23:17 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:17 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:17 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:17 --> URI Class Initialized
INFO - 2024-03-07 11:23:17 --> Router Class Initialized
INFO - 2024-03-07 11:23:17 --> Output Class Initialized
INFO - 2024-03-07 11:23:17 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:17 --> Input Class Initialized
INFO - 2024-03-07 11:23:17 --> Language Class Initialized
INFO - 2024-03-07 11:23:17 --> Language Class Initialized
INFO - 2024-03-07 11:23:17 --> Config Class Initialized
INFO - 2024-03-07 11:23:17 --> Loader Class Initialized
INFO - 2024-03-07 11:23:17 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:17 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:17 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:17 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:17 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:17 --> Controller Class Initialized
DEBUG - 2024-03-07 11:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-07 11:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 11:23:17 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:17 --> Total execution time: 0.0325
INFO - 2024-03-07 11:23:35 --> Config Class Initialized
INFO - 2024-03-07 11:23:35 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:35 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:35 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:35 --> URI Class Initialized
INFO - 2024-03-07 11:23:35 --> Router Class Initialized
INFO - 2024-03-07 11:23:35 --> Output Class Initialized
INFO - 2024-03-07 11:23:35 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:35 --> Input Class Initialized
INFO - 2024-03-07 11:23:35 --> Language Class Initialized
INFO - 2024-03-07 11:23:36 --> Language Class Initialized
INFO - 2024-03-07 11:23:36 --> Config Class Initialized
INFO - 2024-03-07 11:23:36 --> Loader Class Initialized
INFO - 2024-03-07 11:23:36 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:36 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:36 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:36 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:36 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:36 --> Controller Class Initialized
INFO - 2024-03-07 11:23:36 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:36 --> Total execution time: 0.0387
INFO - 2024-03-07 11:23:46 --> Config Class Initialized
INFO - 2024-03-07 11:23:46 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:46 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:46 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:46 --> URI Class Initialized
INFO - 2024-03-07 11:23:46 --> Router Class Initialized
INFO - 2024-03-07 11:23:46 --> Output Class Initialized
INFO - 2024-03-07 11:23:46 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:46 --> Input Class Initialized
INFO - 2024-03-07 11:23:46 --> Language Class Initialized
INFO - 2024-03-07 11:23:46 --> Language Class Initialized
INFO - 2024-03-07 11:23:46 --> Config Class Initialized
INFO - 2024-03-07 11:23:46 --> Loader Class Initialized
INFO - 2024-03-07 11:23:46 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:46 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:46 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:46 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:46 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:46 --> Controller Class Initialized
INFO - 2024-03-07 11:23:46 --> Helper loaded: cookie_helper
INFO - 2024-03-07 11:23:46 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:46 --> Total execution time: 0.0341
INFO - 2024-03-07 11:23:46 --> Config Class Initialized
INFO - 2024-03-07 11:23:46 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:46 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:46 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:46 --> URI Class Initialized
INFO - 2024-03-07 11:23:46 --> Router Class Initialized
INFO - 2024-03-07 11:23:46 --> Output Class Initialized
INFO - 2024-03-07 11:23:46 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:46 --> Input Class Initialized
INFO - 2024-03-07 11:23:46 --> Language Class Initialized
INFO - 2024-03-07 11:23:46 --> Language Class Initialized
INFO - 2024-03-07 11:23:46 --> Config Class Initialized
INFO - 2024-03-07 11:23:46 --> Loader Class Initialized
INFO - 2024-03-07 11:23:46 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:46 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:46 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:46 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:46 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:46 --> Controller Class Initialized
DEBUG - 2024-03-07 11:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-07 11:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 11:23:46 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:46 --> Total execution time: 0.0399
INFO - 2024-03-07 11:23:53 --> Config Class Initialized
INFO - 2024-03-07 11:23:53 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:53 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:53 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:53 --> URI Class Initialized
INFO - 2024-03-07 11:23:53 --> Router Class Initialized
INFO - 2024-03-07 11:23:53 --> Output Class Initialized
INFO - 2024-03-07 11:23:53 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:53 --> Input Class Initialized
INFO - 2024-03-07 11:23:53 --> Language Class Initialized
INFO - 2024-03-07 11:23:53 --> Language Class Initialized
INFO - 2024-03-07 11:23:53 --> Config Class Initialized
INFO - 2024-03-07 11:23:53 --> Loader Class Initialized
INFO - 2024-03-07 11:23:53 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:53 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:53 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:53 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:53 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:53 --> Controller Class Initialized
DEBUG - 2024-03-07 11:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-07 11:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 11:23:53 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:53 --> Total execution time: 0.0305
INFO - 2024-03-07 11:23:56 --> Config Class Initialized
INFO - 2024-03-07 11:23:56 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:56 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:56 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:56 --> URI Class Initialized
INFO - 2024-03-07 11:23:56 --> Router Class Initialized
INFO - 2024-03-07 11:23:56 --> Output Class Initialized
INFO - 2024-03-07 11:23:56 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:56 --> Input Class Initialized
INFO - 2024-03-07 11:23:56 --> Language Class Initialized
INFO - 2024-03-07 11:23:56 --> Language Class Initialized
INFO - 2024-03-07 11:23:56 --> Config Class Initialized
INFO - 2024-03-07 11:23:56 --> Loader Class Initialized
INFO - 2024-03-07 11:23:56 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:56 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:56 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:56 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:56 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:56 --> Controller Class Initialized
DEBUG - 2024-03-07 11:23:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-07 11:23:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 11:23:56 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:56 --> Total execution time: 0.0380
INFO - 2024-03-07 11:23:56 --> Config Class Initialized
INFO - 2024-03-07 11:23:56 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:56 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:56 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:56 --> URI Class Initialized
INFO - 2024-03-07 11:23:56 --> Router Class Initialized
INFO - 2024-03-07 11:23:56 --> Output Class Initialized
INFO - 2024-03-07 11:23:56 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:56 --> Input Class Initialized
INFO - 2024-03-07 11:23:56 --> Language Class Initialized
INFO - 2024-03-07 11:23:56 --> Language Class Initialized
INFO - 2024-03-07 11:23:56 --> Config Class Initialized
INFO - 2024-03-07 11:23:56 --> Loader Class Initialized
INFO - 2024-03-07 11:23:56 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:56 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:56 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:56 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:56 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:56 --> Controller Class Initialized
INFO - 2024-03-07 11:23:58 --> Config Class Initialized
INFO - 2024-03-07 11:23:58 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:23:58 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:23:58 --> Utf8 Class Initialized
INFO - 2024-03-07 11:23:58 --> URI Class Initialized
INFO - 2024-03-07 11:23:58 --> Router Class Initialized
INFO - 2024-03-07 11:23:58 --> Output Class Initialized
INFO - 2024-03-07 11:23:58 --> Security Class Initialized
DEBUG - 2024-03-07 11:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:23:58 --> Input Class Initialized
INFO - 2024-03-07 11:23:58 --> Language Class Initialized
INFO - 2024-03-07 11:23:58 --> Language Class Initialized
INFO - 2024-03-07 11:23:58 --> Config Class Initialized
INFO - 2024-03-07 11:23:58 --> Loader Class Initialized
INFO - 2024-03-07 11:23:58 --> Helper loaded: url_helper
INFO - 2024-03-07 11:23:58 --> Helper loaded: file_helper
INFO - 2024-03-07 11:23:58 --> Helper loaded: form_helper
INFO - 2024-03-07 11:23:58 --> Helper loaded: my_helper
INFO - 2024-03-07 11:23:58 --> Database Driver Class Initialized
INFO - 2024-03-07 11:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:23:58 --> Controller Class Initialized
INFO - 2024-03-07 11:23:58 --> Final output sent to browser
DEBUG - 2024-03-07 11:23:58 --> Total execution time: 0.0381
INFO - 2024-03-07 11:24:20 --> Config Class Initialized
INFO - 2024-03-07 11:24:20 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:24:20 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:24:20 --> Utf8 Class Initialized
INFO - 2024-03-07 11:24:20 --> URI Class Initialized
INFO - 2024-03-07 11:24:20 --> Router Class Initialized
INFO - 2024-03-07 11:24:20 --> Output Class Initialized
INFO - 2024-03-07 11:24:20 --> Security Class Initialized
DEBUG - 2024-03-07 11:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:24:20 --> Input Class Initialized
INFO - 2024-03-07 11:24:20 --> Language Class Initialized
INFO - 2024-03-07 11:24:20 --> Language Class Initialized
INFO - 2024-03-07 11:24:20 --> Config Class Initialized
INFO - 2024-03-07 11:24:20 --> Loader Class Initialized
INFO - 2024-03-07 11:24:20 --> Helper loaded: url_helper
INFO - 2024-03-07 11:24:20 --> Helper loaded: file_helper
INFO - 2024-03-07 11:24:20 --> Helper loaded: form_helper
INFO - 2024-03-07 11:24:20 --> Helper loaded: my_helper
INFO - 2024-03-07 11:24:20 --> Database Driver Class Initialized
INFO - 2024-03-07 11:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:24:20 --> Controller Class Initialized
INFO - 2024-03-07 11:24:20 --> Final output sent to browser
DEBUG - 2024-03-07 11:24:20 --> Total execution time: 0.0385
INFO - 2024-03-07 11:24:20 --> Config Class Initialized
INFO - 2024-03-07 11:24:20 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:24:20 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:24:20 --> Utf8 Class Initialized
INFO - 2024-03-07 11:24:20 --> URI Class Initialized
INFO - 2024-03-07 11:24:20 --> Router Class Initialized
INFO - 2024-03-07 11:24:20 --> Output Class Initialized
INFO - 2024-03-07 11:24:20 --> Security Class Initialized
DEBUG - 2024-03-07 11:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:24:20 --> Input Class Initialized
INFO - 2024-03-07 11:24:20 --> Language Class Initialized
INFO - 2024-03-07 11:24:20 --> Language Class Initialized
INFO - 2024-03-07 11:24:20 --> Config Class Initialized
INFO - 2024-03-07 11:24:20 --> Loader Class Initialized
INFO - 2024-03-07 11:24:20 --> Helper loaded: url_helper
INFO - 2024-03-07 11:24:20 --> Helper loaded: file_helper
INFO - 2024-03-07 11:24:20 --> Helper loaded: form_helper
INFO - 2024-03-07 11:24:20 --> Helper loaded: my_helper
INFO - 2024-03-07 11:24:20 --> Database Driver Class Initialized
INFO - 2024-03-07 11:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:24:20 --> Controller Class Initialized
INFO - 2024-03-07 11:24:26 --> Config Class Initialized
INFO - 2024-03-07 11:24:26 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:24:26 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:24:26 --> Utf8 Class Initialized
INFO - 2024-03-07 11:24:26 --> URI Class Initialized
INFO - 2024-03-07 11:24:26 --> Router Class Initialized
INFO - 2024-03-07 11:24:26 --> Output Class Initialized
INFO - 2024-03-07 11:24:26 --> Security Class Initialized
DEBUG - 2024-03-07 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:24:26 --> Input Class Initialized
INFO - 2024-03-07 11:24:26 --> Language Class Initialized
INFO - 2024-03-07 11:24:26 --> Language Class Initialized
INFO - 2024-03-07 11:24:26 --> Config Class Initialized
INFO - 2024-03-07 11:24:26 --> Loader Class Initialized
INFO - 2024-03-07 11:24:26 --> Helper loaded: url_helper
INFO - 2024-03-07 11:24:26 --> Helper loaded: file_helper
INFO - 2024-03-07 11:24:26 --> Helper loaded: form_helper
INFO - 2024-03-07 11:24:26 --> Helper loaded: my_helper
INFO - 2024-03-07 11:24:26 --> Database Driver Class Initialized
INFO - 2024-03-07 11:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:24:26 --> Controller Class Initialized
INFO - 2024-03-07 11:24:26 --> Final output sent to browser
DEBUG - 2024-03-07 11:24:26 --> Total execution time: 0.1635
INFO - 2024-03-07 11:24:31 --> Config Class Initialized
INFO - 2024-03-07 11:24:31 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:24:31 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:24:31 --> Utf8 Class Initialized
INFO - 2024-03-07 11:24:31 --> URI Class Initialized
INFO - 2024-03-07 11:24:31 --> Router Class Initialized
INFO - 2024-03-07 11:24:31 --> Output Class Initialized
INFO - 2024-03-07 11:24:31 --> Security Class Initialized
DEBUG - 2024-03-07 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:24:31 --> Input Class Initialized
INFO - 2024-03-07 11:24:31 --> Language Class Initialized
INFO - 2024-03-07 11:24:31 --> Language Class Initialized
INFO - 2024-03-07 11:24:31 --> Config Class Initialized
INFO - 2024-03-07 11:24:31 --> Loader Class Initialized
INFO - 2024-03-07 11:24:31 --> Helper loaded: url_helper
INFO - 2024-03-07 11:24:31 --> Helper loaded: file_helper
INFO - 2024-03-07 11:24:31 --> Helper loaded: form_helper
INFO - 2024-03-07 11:24:31 --> Helper loaded: my_helper
INFO - 2024-03-07 11:24:31 --> Database Driver Class Initialized
INFO - 2024-03-07 11:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:24:31 --> Controller Class Initialized
INFO - 2024-03-07 11:24:31 --> Final output sent to browser
DEBUG - 2024-03-07 11:24:31 --> Total execution time: 0.0382
INFO - 2024-03-07 11:33:05 --> Config Class Initialized
INFO - 2024-03-07 11:33:05 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:33:05 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:33:05 --> Utf8 Class Initialized
INFO - 2024-03-07 11:33:05 --> URI Class Initialized
INFO - 2024-03-07 11:33:05 --> Router Class Initialized
INFO - 2024-03-07 11:33:05 --> Output Class Initialized
INFO - 2024-03-07 11:33:05 --> Security Class Initialized
DEBUG - 2024-03-07 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:33:05 --> Input Class Initialized
INFO - 2024-03-07 11:33:05 --> Language Class Initialized
INFO - 2024-03-07 11:33:05 --> Language Class Initialized
INFO - 2024-03-07 11:33:05 --> Config Class Initialized
INFO - 2024-03-07 11:33:05 --> Loader Class Initialized
INFO - 2024-03-07 11:33:05 --> Helper loaded: url_helper
INFO - 2024-03-07 11:33:05 --> Helper loaded: file_helper
INFO - 2024-03-07 11:33:05 --> Helper loaded: form_helper
INFO - 2024-03-07 11:33:05 --> Helper loaded: my_helper
INFO - 2024-03-07 11:33:05 --> Database Driver Class Initialized
INFO - 2024-03-07 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:33:05 --> Controller Class Initialized
INFO - 2024-03-07 11:33:05 --> Final output sent to browser
DEBUG - 2024-03-07 11:33:05 --> Total execution time: 0.0648
INFO - 2024-03-07 11:33:09 --> Config Class Initialized
INFO - 2024-03-07 11:33:09 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:33:09 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:33:09 --> Utf8 Class Initialized
INFO - 2024-03-07 11:33:09 --> URI Class Initialized
INFO - 2024-03-07 11:33:09 --> Router Class Initialized
INFO - 2024-03-07 11:33:09 --> Output Class Initialized
INFO - 2024-03-07 11:33:09 --> Security Class Initialized
DEBUG - 2024-03-07 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:33:09 --> Input Class Initialized
INFO - 2024-03-07 11:33:09 --> Language Class Initialized
INFO - 2024-03-07 11:33:09 --> Language Class Initialized
INFO - 2024-03-07 11:33:09 --> Config Class Initialized
INFO - 2024-03-07 11:33:09 --> Loader Class Initialized
INFO - 2024-03-07 11:33:09 --> Helper loaded: url_helper
INFO - 2024-03-07 11:33:09 --> Helper loaded: file_helper
INFO - 2024-03-07 11:33:09 --> Helper loaded: form_helper
INFO - 2024-03-07 11:33:09 --> Helper loaded: my_helper
INFO - 2024-03-07 11:33:09 --> Database Driver Class Initialized
INFO - 2024-03-07 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:33:09 --> Controller Class Initialized
INFO - 2024-03-07 11:33:09 --> Final output sent to browser
DEBUG - 2024-03-07 11:33:09 --> Total execution time: 0.0805
INFO - 2024-03-07 11:33:28 --> Config Class Initialized
INFO - 2024-03-07 11:33:28 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:33:28 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:33:28 --> Utf8 Class Initialized
INFO - 2024-03-07 11:33:28 --> URI Class Initialized
INFO - 2024-03-07 11:33:28 --> Router Class Initialized
INFO - 2024-03-07 11:33:28 --> Output Class Initialized
INFO - 2024-03-07 11:33:28 --> Security Class Initialized
DEBUG - 2024-03-07 11:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:33:28 --> Input Class Initialized
INFO - 2024-03-07 11:33:28 --> Language Class Initialized
INFO - 2024-03-07 11:33:28 --> Language Class Initialized
INFO - 2024-03-07 11:33:28 --> Config Class Initialized
INFO - 2024-03-07 11:33:28 --> Loader Class Initialized
INFO - 2024-03-07 11:33:28 --> Helper loaded: url_helper
INFO - 2024-03-07 11:33:28 --> Helper loaded: file_helper
INFO - 2024-03-07 11:33:28 --> Helper loaded: form_helper
INFO - 2024-03-07 11:33:28 --> Helper loaded: my_helper
INFO - 2024-03-07 11:33:28 --> Database Driver Class Initialized
INFO - 2024-03-07 11:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:33:28 --> Controller Class Initialized
INFO - 2024-03-07 11:33:28 --> Final output sent to browser
DEBUG - 2024-03-07 11:33:28 --> Total execution time: 0.0312
INFO - 2024-03-07 11:33:28 --> Config Class Initialized
INFO - 2024-03-07 11:33:28 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:33:28 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:33:28 --> Utf8 Class Initialized
INFO - 2024-03-07 11:33:28 --> URI Class Initialized
INFO - 2024-03-07 11:33:28 --> Router Class Initialized
INFO - 2024-03-07 11:33:28 --> Output Class Initialized
INFO - 2024-03-07 11:33:28 --> Security Class Initialized
DEBUG - 2024-03-07 11:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:33:28 --> Input Class Initialized
INFO - 2024-03-07 11:33:28 --> Language Class Initialized
INFO - 2024-03-07 11:33:28 --> Language Class Initialized
INFO - 2024-03-07 11:33:28 --> Config Class Initialized
INFO - 2024-03-07 11:33:28 --> Loader Class Initialized
INFO - 2024-03-07 11:33:28 --> Helper loaded: url_helper
INFO - 2024-03-07 11:33:28 --> Helper loaded: file_helper
INFO - 2024-03-07 11:33:28 --> Helper loaded: form_helper
INFO - 2024-03-07 11:33:28 --> Helper loaded: my_helper
INFO - 2024-03-07 11:33:28 --> Database Driver Class Initialized
INFO - 2024-03-07 11:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:33:28 --> Controller Class Initialized
INFO - 2024-03-07 11:33:29 --> Config Class Initialized
INFO - 2024-03-07 11:33:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:33:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:33:29 --> Utf8 Class Initialized
INFO - 2024-03-07 11:33:29 --> URI Class Initialized
INFO - 2024-03-07 11:33:29 --> Router Class Initialized
INFO - 2024-03-07 11:33:29 --> Output Class Initialized
INFO - 2024-03-07 11:33:29 --> Security Class Initialized
DEBUG - 2024-03-07 11:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:33:29 --> Input Class Initialized
INFO - 2024-03-07 11:33:29 --> Language Class Initialized
INFO - 2024-03-07 11:33:29 --> Language Class Initialized
INFO - 2024-03-07 11:33:29 --> Config Class Initialized
INFO - 2024-03-07 11:33:29 --> Loader Class Initialized
INFO - 2024-03-07 11:33:29 --> Helper loaded: url_helper
INFO - 2024-03-07 11:33:29 --> Helper loaded: file_helper
INFO - 2024-03-07 11:33:29 --> Helper loaded: form_helper
INFO - 2024-03-07 11:33:29 --> Helper loaded: my_helper
INFO - 2024-03-07 11:33:29 --> Database Driver Class Initialized
INFO - 2024-03-07 11:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:33:29 --> Controller Class Initialized
INFO - 2024-03-07 11:33:29 --> Final output sent to browser
DEBUG - 2024-03-07 11:33:29 --> Total execution time: 0.0400
INFO - 2024-03-07 11:36:29 --> Config Class Initialized
INFO - 2024-03-07 11:36:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:36:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:36:29 --> Utf8 Class Initialized
INFO - 2024-03-07 11:36:29 --> URI Class Initialized
INFO - 2024-03-07 11:36:29 --> Router Class Initialized
INFO - 2024-03-07 11:36:29 --> Output Class Initialized
INFO - 2024-03-07 11:36:29 --> Security Class Initialized
DEBUG - 2024-03-07 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:36:29 --> Input Class Initialized
INFO - 2024-03-07 11:36:29 --> Language Class Initialized
INFO - 2024-03-07 11:36:29 --> Language Class Initialized
INFO - 2024-03-07 11:36:29 --> Config Class Initialized
INFO - 2024-03-07 11:36:29 --> Loader Class Initialized
INFO - 2024-03-07 11:36:29 --> Helper loaded: url_helper
INFO - 2024-03-07 11:36:29 --> Helper loaded: file_helper
INFO - 2024-03-07 11:36:29 --> Helper loaded: form_helper
INFO - 2024-03-07 11:36:29 --> Helper loaded: my_helper
INFO - 2024-03-07 11:36:29 --> Database Driver Class Initialized
INFO - 2024-03-07 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:36:29 --> Controller Class Initialized
INFO - 2024-03-07 11:36:29 --> Final output sent to browser
DEBUG - 2024-03-07 11:36:29 --> Total execution time: 0.0627
INFO - 2024-03-07 11:36:38 --> Config Class Initialized
INFO - 2024-03-07 11:36:38 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:36:38 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:36:38 --> Utf8 Class Initialized
INFO - 2024-03-07 11:36:38 --> URI Class Initialized
INFO - 2024-03-07 11:36:38 --> Router Class Initialized
INFO - 2024-03-07 11:36:38 --> Output Class Initialized
INFO - 2024-03-07 11:36:38 --> Security Class Initialized
DEBUG - 2024-03-07 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:36:38 --> Input Class Initialized
INFO - 2024-03-07 11:36:38 --> Language Class Initialized
INFO - 2024-03-07 11:36:38 --> Language Class Initialized
INFO - 2024-03-07 11:36:38 --> Config Class Initialized
INFO - 2024-03-07 11:36:38 --> Loader Class Initialized
INFO - 2024-03-07 11:36:38 --> Helper loaded: url_helper
INFO - 2024-03-07 11:36:38 --> Helper loaded: file_helper
INFO - 2024-03-07 11:36:38 --> Helper loaded: form_helper
INFO - 2024-03-07 11:36:38 --> Helper loaded: my_helper
INFO - 2024-03-07 11:36:38 --> Database Driver Class Initialized
INFO - 2024-03-07 11:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:36:38 --> Controller Class Initialized
INFO - 2024-03-07 11:36:38 --> Final output sent to browser
DEBUG - 2024-03-07 11:36:38 --> Total execution time: 0.0369
INFO - 2024-03-07 11:39:01 --> Config Class Initialized
INFO - 2024-03-07 11:39:01 --> Hooks Class Initialized
DEBUG - 2024-03-07 11:39:01 --> UTF-8 Support Enabled
INFO - 2024-03-07 11:39:01 --> Utf8 Class Initialized
INFO - 2024-03-07 11:39:01 --> URI Class Initialized
INFO - 2024-03-07 11:39:01 --> Router Class Initialized
INFO - 2024-03-07 11:39:01 --> Output Class Initialized
INFO - 2024-03-07 11:39:01 --> Security Class Initialized
DEBUG - 2024-03-07 11:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 11:39:01 --> Input Class Initialized
INFO - 2024-03-07 11:39:01 --> Language Class Initialized
INFO - 2024-03-07 11:39:01 --> Language Class Initialized
INFO - 2024-03-07 11:39:01 --> Config Class Initialized
INFO - 2024-03-07 11:39:01 --> Loader Class Initialized
INFO - 2024-03-07 11:39:01 --> Helper loaded: url_helper
INFO - 2024-03-07 11:39:01 --> Helper loaded: file_helper
INFO - 2024-03-07 11:39:02 --> Helper loaded: form_helper
INFO - 2024-03-07 11:39:02 --> Helper loaded: my_helper
INFO - 2024-03-07 11:39:02 --> Database Driver Class Initialized
INFO - 2024-03-07 11:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 11:39:02 --> Controller Class Initialized
INFO - 2024-03-07 11:39:02 --> Final output sent to browser
DEBUG - 2024-03-07 11:39:02 --> Total execution time: 0.4462
INFO - 2024-03-07 16:35:28 --> Config Class Initialized
INFO - 2024-03-07 16:35:28 --> Hooks Class Initialized
DEBUG - 2024-03-07 16:35:28 --> UTF-8 Support Enabled
INFO - 2024-03-07 16:35:28 --> Utf8 Class Initialized
INFO - 2024-03-07 16:35:28 --> URI Class Initialized
INFO - 2024-03-07 16:35:28 --> Router Class Initialized
INFO - 2024-03-07 16:35:28 --> Output Class Initialized
INFO - 2024-03-07 16:35:28 --> Security Class Initialized
DEBUG - 2024-03-07 16:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 16:35:28 --> Input Class Initialized
INFO - 2024-03-07 16:35:28 --> Language Class Initialized
INFO - 2024-03-07 16:35:28 --> Language Class Initialized
INFO - 2024-03-07 16:35:28 --> Config Class Initialized
INFO - 2024-03-07 16:35:28 --> Loader Class Initialized
INFO - 2024-03-07 16:35:28 --> Helper loaded: url_helper
INFO - 2024-03-07 16:35:28 --> Helper loaded: file_helper
INFO - 2024-03-07 16:35:28 --> Helper loaded: form_helper
INFO - 2024-03-07 16:35:28 --> Helper loaded: my_helper
INFO - 2024-03-07 16:35:28 --> Database Driver Class Initialized
INFO - 2024-03-07 16:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 16:35:28 --> Controller Class Initialized
ERROR - 2024-03-07 16:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/controllers/N_prestasi.php 19
ERROR - 2024-03-07 16:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/controllers/N_prestasi.php 20
ERROR - 2024-03-07 16:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/controllers/N_prestasi.php 21
DEBUG - 2024-03-07 16:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-03-07 16:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-07 16:35:28 --> Final output sent to browser
DEBUG - 2024-03-07 16:35:28 --> Total execution time: 0.1089
INFO - 2024-03-07 16:35:29 --> Config Class Initialized
INFO - 2024-03-07 16:35:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 16:35:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 16:35:29 --> Utf8 Class Initialized
INFO - 2024-03-07 16:35:29 --> URI Class Initialized
INFO - 2024-03-07 16:35:29 --> Router Class Initialized
INFO - 2024-03-07 16:35:29 --> Output Class Initialized
INFO - 2024-03-07 16:35:29 --> Security Class Initialized
DEBUG - 2024-03-07 16:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 16:35:29 --> Input Class Initialized
INFO - 2024-03-07 16:35:29 --> Language Class Initialized
ERROR - 2024-03-07 16:35:29 --> 404 Page Not Found: /index
INFO - 2024-03-07 16:35:29 --> Config Class Initialized
INFO - 2024-03-07 16:35:29 --> Hooks Class Initialized
DEBUG - 2024-03-07 16:35:29 --> UTF-8 Support Enabled
INFO - 2024-03-07 16:35:29 --> Utf8 Class Initialized
INFO - 2024-03-07 16:35:29 --> URI Class Initialized
INFO - 2024-03-07 16:35:29 --> Router Class Initialized
INFO - 2024-03-07 16:35:29 --> Output Class Initialized
INFO - 2024-03-07 16:35:29 --> Security Class Initialized
DEBUG - 2024-03-07 16:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-07 16:35:29 --> Input Class Initialized
INFO - 2024-03-07 16:35:29 --> Language Class Initialized
INFO - 2024-03-07 16:35:29 --> Language Class Initialized
INFO - 2024-03-07 16:35:29 --> Config Class Initialized
INFO - 2024-03-07 16:35:29 --> Loader Class Initialized
INFO - 2024-03-07 16:35:29 --> Helper loaded: url_helper
INFO - 2024-03-07 16:35:29 --> Helper loaded: file_helper
INFO - 2024-03-07 16:35:29 --> Helper loaded: form_helper
INFO - 2024-03-07 16:35:29 --> Helper loaded: my_helper
INFO - 2024-03-07 16:35:29 --> Database Driver Class Initialized
INFO - 2024-03-07 16:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-07 16:35:29 --> Controller Class Initialized
ERROR - 2024-03-07 16:35:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/controllers/N_prestasi.php 19
ERROR - 2024-03-07 16:35:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/controllers/N_prestasi.php 20
ERROR - 2024-03-07 16:35:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/controllers/N_prestasi.php 21
