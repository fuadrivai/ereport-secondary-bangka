<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-05 09:28:32 --> Config Class Initialized
INFO - 2024-12-05 09:28:32 --> Hooks Class Initialized
DEBUG - 2024-12-05 09:28:32 --> UTF-8 Support Enabled
INFO - 2024-12-05 09:28:32 --> Utf8 Class Initialized
INFO - 2024-12-05 09:28:32 --> URI Class Initialized
INFO - 2024-12-05 09:28:32 --> Router Class Initialized
INFO - 2024-12-05 09:28:32 --> Output Class Initialized
INFO - 2024-12-05 09:28:32 --> Security Class Initialized
DEBUG - 2024-12-05 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 09:28:32 --> Input Class Initialized
INFO - 2024-12-05 09:28:32 --> Language Class Initialized
INFO - 2024-12-05 09:28:32 --> Language Class Initialized
INFO - 2024-12-05 09:28:32 --> Config Class Initialized
INFO - 2024-12-05 09:28:32 --> Loader Class Initialized
INFO - 2024-12-05 09:28:32 --> Helper loaded: url_helper
INFO - 2024-12-05 09:28:32 --> Helper loaded: file_helper
INFO - 2024-12-05 09:28:32 --> Helper loaded: form_helper
INFO - 2024-12-05 09:28:32 --> Helper loaded: my_helper
INFO - 2024-12-05 09:28:32 --> Database Driver Class Initialized
INFO - 2024-12-05 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 09:28:32 --> Controller Class Initialized
DEBUG - 2024-12-05 09:28:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-05 09:28:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 09:28:32 --> Final output sent to browser
DEBUG - 2024-12-05 09:28:32 --> Total execution time: 0.0475
INFO - 2024-12-05 09:30:02 --> Config Class Initialized
INFO - 2024-12-05 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-12-05 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-12-05 09:30:02 --> Utf8 Class Initialized
INFO - 2024-12-05 09:30:02 --> URI Class Initialized
INFO - 2024-12-05 09:30:02 --> Router Class Initialized
INFO - 2024-12-05 09:30:02 --> Output Class Initialized
INFO - 2024-12-05 09:30:02 --> Security Class Initialized
DEBUG - 2024-12-05 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 09:30:02 --> Input Class Initialized
INFO - 2024-12-05 09:30:02 --> Language Class Initialized
INFO - 2024-12-05 09:30:02 --> Language Class Initialized
INFO - 2024-12-05 09:30:02 --> Config Class Initialized
INFO - 2024-12-05 09:30:02 --> Loader Class Initialized
INFO - 2024-12-05 09:30:02 --> Helper loaded: url_helper
INFO - 2024-12-05 09:30:02 --> Helper loaded: file_helper
INFO - 2024-12-05 09:30:02 --> Helper loaded: form_helper
INFO - 2024-12-05 09:30:02 --> Helper loaded: my_helper
INFO - 2024-12-05 09:30:02 --> Database Driver Class Initialized
INFO - 2024-12-05 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 09:30:02 --> Controller Class Initialized
INFO - 2024-12-05 09:30:03 --> Helper loaded: cookie_helper
INFO - 2024-12-05 09:30:03 --> Final output sent to browser
DEBUG - 2024-12-05 09:30:03 --> Total execution time: 0.8545
INFO - 2024-12-05 09:30:03 --> Config Class Initialized
INFO - 2024-12-05 09:30:03 --> Hooks Class Initialized
DEBUG - 2024-12-05 09:30:03 --> UTF-8 Support Enabled
INFO - 2024-12-05 09:30:03 --> Utf8 Class Initialized
INFO - 2024-12-05 09:30:03 --> URI Class Initialized
INFO - 2024-12-05 09:30:03 --> Router Class Initialized
INFO - 2024-12-05 09:30:03 --> Output Class Initialized
INFO - 2024-12-05 09:30:03 --> Security Class Initialized
DEBUG - 2024-12-05 09:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 09:30:03 --> Input Class Initialized
INFO - 2024-12-05 09:30:03 --> Language Class Initialized
INFO - 2024-12-05 09:30:03 --> Language Class Initialized
INFO - 2024-12-05 09:30:03 --> Config Class Initialized
INFO - 2024-12-05 09:30:03 --> Loader Class Initialized
INFO - 2024-12-05 09:30:03 --> Helper loaded: url_helper
INFO - 2024-12-05 09:30:03 --> Helper loaded: file_helper
INFO - 2024-12-05 09:30:03 --> Helper loaded: form_helper
INFO - 2024-12-05 09:30:03 --> Helper loaded: my_helper
INFO - 2024-12-05 09:30:03 --> Database Driver Class Initialized
INFO - 2024-12-05 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 09:30:03 --> Controller Class Initialized
DEBUG - 2024-12-05 09:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-05 09:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 09:30:03 --> Final output sent to browser
DEBUG - 2024-12-05 09:30:03 --> Total execution time: 0.8025
INFO - 2024-12-05 09:30:07 --> Config Class Initialized
INFO - 2024-12-05 09:30:07 --> Hooks Class Initialized
DEBUG - 2024-12-05 09:30:07 --> UTF-8 Support Enabled
INFO - 2024-12-05 09:30:07 --> Utf8 Class Initialized
INFO - 2024-12-05 09:30:07 --> URI Class Initialized
INFO - 2024-12-05 09:30:07 --> Router Class Initialized
INFO - 2024-12-05 09:30:07 --> Output Class Initialized
INFO - 2024-12-05 09:30:07 --> Security Class Initialized
DEBUG - 2024-12-05 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 09:30:07 --> Input Class Initialized
INFO - 2024-12-05 09:30:07 --> Language Class Initialized
INFO - 2024-12-05 09:30:07 --> Language Class Initialized
INFO - 2024-12-05 09:30:07 --> Config Class Initialized
INFO - 2024-12-05 09:30:07 --> Loader Class Initialized
INFO - 2024-12-05 09:30:07 --> Helper loaded: url_helper
INFO - 2024-12-05 09:30:07 --> Helper loaded: file_helper
INFO - 2024-12-05 09:30:07 --> Helper loaded: form_helper
INFO - 2024-12-05 09:30:07 --> Helper loaded: my_helper
INFO - 2024-12-05 09:30:08 --> Database Driver Class Initialized
INFO - 2024-12-05 09:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 09:30:08 --> Controller Class Initialized
DEBUG - 2024-12-05 09:30:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-12-05 09:30:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 09:30:08 --> Final output sent to browser
DEBUG - 2024-12-05 09:30:08 --> Total execution time: 0.8702
INFO - 2024-12-05 09:30:10 --> Config Class Initialized
INFO - 2024-12-05 09:30:10 --> Hooks Class Initialized
DEBUG - 2024-12-05 09:30:10 --> UTF-8 Support Enabled
INFO - 2024-12-05 09:30:10 --> Utf8 Class Initialized
INFO - 2024-12-05 09:30:10 --> URI Class Initialized
INFO - 2024-12-05 09:30:10 --> Router Class Initialized
INFO - 2024-12-05 09:30:10 --> Output Class Initialized
INFO - 2024-12-05 09:30:10 --> Security Class Initialized
DEBUG - 2024-12-05 09:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 09:30:10 --> Input Class Initialized
INFO - 2024-12-05 09:30:10 --> Language Class Initialized
INFO - 2024-12-05 09:30:10 --> Language Class Initialized
INFO - 2024-12-05 09:30:10 --> Config Class Initialized
INFO - 2024-12-05 09:30:10 --> Loader Class Initialized
INFO - 2024-12-05 09:30:10 --> Helper loaded: url_helper
INFO - 2024-12-05 09:30:10 --> Helper loaded: file_helper
INFO - 2024-12-05 09:30:10 --> Helper loaded: form_helper
INFO - 2024-12-05 09:30:10 --> Helper loaded: my_helper
INFO - 2024-12-05 09:30:10 --> Database Driver Class Initialized
INFO - 2024-12-05 09:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 09:30:10 --> Controller Class Initialized
INFO - 2024-12-05 09:30:10 --> Final output sent to browser
DEBUG - 2024-12-05 09:30:10 --> Total execution time: 0.3133
INFO - 2024-12-05 10:08:15 --> Config Class Initialized
INFO - 2024-12-05 10:08:15 --> Hooks Class Initialized
DEBUG - 2024-12-05 10:08:15 --> UTF-8 Support Enabled
INFO - 2024-12-05 10:08:15 --> Utf8 Class Initialized
INFO - 2024-12-05 10:08:15 --> URI Class Initialized
INFO - 2024-12-05 10:08:15 --> Router Class Initialized
INFO - 2024-12-05 10:08:15 --> Output Class Initialized
INFO - 2024-12-05 10:08:15 --> Security Class Initialized
DEBUG - 2024-12-05 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 10:08:15 --> Input Class Initialized
INFO - 2024-12-05 10:08:15 --> Language Class Initialized
INFO - 2024-12-05 10:08:15 --> Language Class Initialized
INFO - 2024-12-05 10:08:15 --> Config Class Initialized
INFO - 2024-12-05 10:08:15 --> Loader Class Initialized
INFO - 2024-12-05 10:08:15 --> Helper loaded: url_helper
INFO - 2024-12-05 10:08:15 --> Helper loaded: file_helper
INFO - 2024-12-05 10:08:15 --> Helper loaded: form_helper
INFO - 2024-12-05 10:08:15 --> Helper loaded: my_helper
INFO - 2024-12-05 10:08:15 --> Database Driver Class Initialized
INFO - 2024-12-05 10:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 10:08:15 --> Controller Class Initialized
INFO - 2024-12-05 10:08:15 --> Helper loaded: cookie_helper
INFO - 2024-12-05 10:08:16 --> Config Class Initialized
INFO - 2024-12-05 10:08:16 --> Hooks Class Initialized
DEBUG - 2024-12-05 10:08:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 10:08:16 --> Utf8 Class Initialized
INFO - 2024-12-05 10:08:16 --> URI Class Initialized
INFO - 2024-12-05 10:08:16 --> Router Class Initialized
INFO - 2024-12-05 10:08:16 --> Output Class Initialized
INFO - 2024-12-05 10:08:16 --> Security Class Initialized
DEBUG - 2024-12-05 10:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 10:08:16 --> Input Class Initialized
INFO - 2024-12-05 10:08:16 --> Language Class Initialized
INFO - 2024-12-05 10:08:16 --> Language Class Initialized
INFO - 2024-12-05 10:08:16 --> Config Class Initialized
INFO - 2024-12-05 10:08:16 --> Loader Class Initialized
INFO - 2024-12-05 10:08:16 --> Helper loaded: url_helper
INFO - 2024-12-05 10:08:16 --> Helper loaded: file_helper
INFO - 2024-12-05 10:08:16 --> Helper loaded: form_helper
INFO - 2024-12-05 10:08:16 --> Helper loaded: my_helper
INFO - 2024-12-05 10:08:16 --> Database Driver Class Initialized
INFO - 2024-12-05 10:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 10:08:16 --> Controller Class Initialized
INFO - 2024-12-05 10:08:16 --> Config Class Initialized
INFO - 2024-12-05 10:08:16 --> Hooks Class Initialized
DEBUG - 2024-12-05 10:08:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 10:08:16 --> Utf8 Class Initialized
INFO - 2024-12-05 10:08:16 --> URI Class Initialized
INFO - 2024-12-05 10:08:16 --> Router Class Initialized
INFO - 2024-12-05 10:08:16 --> Output Class Initialized
INFO - 2024-12-05 10:08:16 --> Security Class Initialized
DEBUG - 2024-12-05 10:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 10:08:16 --> Input Class Initialized
INFO - 2024-12-05 10:08:16 --> Language Class Initialized
INFO - 2024-12-05 10:08:16 --> Language Class Initialized
INFO - 2024-12-05 10:08:16 --> Config Class Initialized
INFO - 2024-12-05 10:08:16 --> Loader Class Initialized
INFO - 2024-12-05 10:08:16 --> Helper loaded: url_helper
INFO - 2024-12-05 10:08:16 --> Helper loaded: file_helper
INFO - 2024-12-05 10:08:16 --> Helper loaded: form_helper
INFO - 2024-12-05 10:08:16 --> Helper loaded: my_helper
INFO - 2024-12-05 10:08:16 --> Database Driver Class Initialized
INFO - 2024-12-05 10:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 10:08:16 --> Controller Class Initialized
DEBUG - 2024-12-05 10:08:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-05 10:08:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 10:08:16 --> Final output sent to browser
DEBUG - 2024-12-05 10:08:16 --> Total execution time: 0.0328
INFO - 2024-12-05 16:54:46 --> Config Class Initialized
INFO - 2024-12-05 16:54:46 --> Hooks Class Initialized
DEBUG - 2024-12-05 16:54:46 --> UTF-8 Support Enabled
INFO - 2024-12-05 16:54:46 --> Utf8 Class Initialized
INFO - 2024-12-05 16:54:46 --> URI Class Initialized
INFO - 2024-12-05 16:54:46 --> Router Class Initialized
INFO - 2024-12-05 16:54:46 --> Output Class Initialized
INFO - 2024-12-05 16:54:46 --> Security Class Initialized
DEBUG - 2024-12-05 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 16:54:46 --> Input Class Initialized
INFO - 2024-12-05 16:54:46 --> Language Class Initialized
INFO - 2024-12-05 16:54:46 --> Language Class Initialized
INFO - 2024-12-05 16:54:46 --> Config Class Initialized
INFO - 2024-12-05 16:54:46 --> Loader Class Initialized
INFO - 2024-12-05 16:54:46 --> Helper loaded: url_helper
INFO - 2024-12-05 16:54:46 --> Helper loaded: file_helper
INFO - 2024-12-05 16:54:46 --> Helper loaded: form_helper
INFO - 2024-12-05 16:54:46 --> Helper loaded: my_helper
INFO - 2024-12-05 16:54:46 --> Database Driver Class Initialized
INFO - 2024-12-05 16:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 16:54:46 --> Controller Class Initialized
DEBUG - 2024-12-05 16:54:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-05 16:54:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 16:54:46 --> Final output sent to browser
DEBUG - 2024-12-05 16:54:46 --> Total execution time: 0.1065
INFO - 2024-12-05 16:54:50 --> Config Class Initialized
INFO - 2024-12-05 16:54:50 --> Hooks Class Initialized
DEBUG - 2024-12-05 16:54:50 --> UTF-8 Support Enabled
INFO - 2024-12-05 16:54:50 --> Utf8 Class Initialized
INFO - 2024-12-05 16:54:50 --> URI Class Initialized
INFO - 2024-12-05 16:54:50 --> Router Class Initialized
INFO - 2024-12-05 16:54:50 --> Output Class Initialized
INFO - 2024-12-05 16:54:50 --> Security Class Initialized
DEBUG - 2024-12-05 16:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 16:54:50 --> Input Class Initialized
INFO - 2024-12-05 16:54:50 --> Language Class Initialized
INFO - 2024-12-05 16:54:50 --> Language Class Initialized
INFO - 2024-12-05 16:54:50 --> Config Class Initialized
INFO - 2024-12-05 16:54:50 --> Loader Class Initialized
INFO - 2024-12-05 16:54:50 --> Helper loaded: url_helper
INFO - 2024-12-05 16:54:50 --> Helper loaded: file_helper
INFO - 2024-12-05 16:54:50 --> Helper loaded: form_helper
INFO - 2024-12-05 16:54:50 --> Helper loaded: my_helper
INFO - 2024-12-05 16:54:50 --> Database Driver Class Initialized
INFO - 2024-12-05 16:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 16:54:50 --> Controller Class Initialized
DEBUG - 2024-12-05 16:54:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-05 16:54:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 16:54:50 --> Final output sent to browser
DEBUG - 2024-12-05 16:54:50 --> Total execution time: 0.0731
INFO - 2024-12-05 22:18:49 --> Config Class Initialized
INFO - 2024-12-05 22:18:49 --> Hooks Class Initialized
DEBUG - 2024-12-05 22:18:49 --> UTF-8 Support Enabled
INFO - 2024-12-05 22:18:49 --> Utf8 Class Initialized
INFO - 2024-12-05 22:18:49 --> URI Class Initialized
DEBUG - 2024-12-05 22:18:49 --> No URI present. Default controller set.
INFO - 2024-12-05 22:18:49 --> Router Class Initialized
INFO - 2024-12-05 22:18:49 --> Output Class Initialized
INFO - 2024-12-05 22:18:49 --> Security Class Initialized
DEBUG - 2024-12-05 22:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 22:18:49 --> Input Class Initialized
INFO - 2024-12-05 22:18:49 --> Language Class Initialized
INFO - 2024-12-05 22:18:49 --> Language Class Initialized
INFO - 2024-12-05 22:18:49 --> Config Class Initialized
INFO - 2024-12-05 22:18:49 --> Loader Class Initialized
INFO - 2024-12-05 22:18:49 --> Helper loaded: url_helper
INFO - 2024-12-05 22:18:49 --> Helper loaded: file_helper
INFO - 2024-12-05 22:18:49 --> Helper loaded: form_helper
INFO - 2024-12-05 22:18:49 --> Helper loaded: my_helper
INFO - 2024-12-05 22:18:49 --> Database Driver Class Initialized
INFO - 2024-12-05 22:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 22:18:49 --> Controller Class Initialized
INFO - 2024-12-05 22:18:49 --> Config Class Initialized
INFO - 2024-12-05 22:18:49 --> Hooks Class Initialized
DEBUG - 2024-12-05 22:18:49 --> UTF-8 Support Enabled
INFO - 2024-12-05 22:18:49 --> Utf8 Class Initialized
INFO - 2024-12-05 22:18:49 --> URI Class Initialized
INFO - 2024-12-05 22:18:49 --> Router Class Initialized
INFO - 2024-12-05 22:18:49 --> Output Class Initialized
INFO - 2024-12-05 22:18:49 --> Security Class Initialized
DEBUG - 2024-12-05 22:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 22:18:49 --> Input Class Initialized
INFO - 2024-12-05 22:18:49 --> Language Class Initialized
INFO - 2024-12-05 22:18:49 --> Language Class Initialized
INFO - 2024-12-05 22:18:49 --> Config Class Initialized
INFO - 2024-12-05 22:18:49 --> Loader Class Initialized
INFO - 2024-12-05 22:18:49 --> Helper loaded: url_helper
INFO - 2024-12-05 22:18:49 --> Helper loaded: file_helper
INFO - 2024-12-05 22:18:49 --> Helper loaded: form_helper
INFO - 2024-12-05 22:18:49 --> Helper loaded: my_helper
INFO - 2024-12-05 22:18:49 --> Database Driver Class Initialized
INFO - 2024-12-05 22:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 22:18:49 --> Controller Class Initialized
DEBUG - 2024-12-05 22:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-05 22:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-05 22:18:49 --> Final output sent to browser
DEBUG - 2024-12-05 22:18:49 --> Total execution time: 0.0341
