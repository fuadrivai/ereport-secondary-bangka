<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-15 10:06:13 --> Config Class Initialized
INFO - 2024-10-15 10:06:13 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:06:13 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:06:13 --> Utf8 Class Initialized
INFO - 2024-10-15 10:06:13 --> URI Class Initialized
INFO - 2024-10-15 10:06:13 --> Router Class Initialized
INFO - 2024-10-15 10:06:13 --> Output Class Initialized
INFO - 2024-10-15 10:06:13 --> Security Class Initialized
DEBUG - 2024-10-15 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:06:13 --> Input Class Initialized
INFO - 2024-10-15 10:06:13 --> Language Class Initialized
INFO - 2024-10-15 10:06:13 --> Language Class Initialized
INFO - 2024-10-15 10:06:13 --> Config Class Initialized
INFO - 2024-10-15 10:06:13 --> Loader Class Initialized
INFO - 2024-10-15 10:06:13 --> Helper loaded: url_helper
INFO - 2024-10-15 10:06:13 --> Helper loaded: file_helper
INFO - 2024-10-15 10:06:13 --> Helper loaded: form_helper
INFO - 2024-10-15 10:06:13 --> Helper loaded: my_helper
INFO - 2024-10-15 10:06:13 --> Database Driver Class Initialized
INFO - 2024-10-15 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:06:13 --> Controller Class Initialized
INFO - 2024-10-15 10:06:13 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:06:13 --> Final output sent to browser
DEBUG - 2024-10-15 10:06:13 --> Total execution time: 0.0701
INFO - 2024-10-15 10:06:14 --> Config Class Initialized
INFO - 2024-10-15 10:06:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:06:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:06:14 --> Utf8 Class Initialized
INFO - 2024-10-15 10:06:14 --> URI Class Initialized
INFO - 2024-10-15 10:06:14 --> Router Class Initialized
INFO - 2024-10-15 10:06:14 --> Output Class Initialized
INFO - 2024-10-15 10:06:14 --> Security Class Initialized
DEBUG - 2024-10-15 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:06:14 --> Input Class Initialized
INFO - 2024-10-15 10:06:14 --> Language Class Initialized
INFO - 2024-10-15 10:06:14 --> Language Class Initialized
INFO - 2024-10-15 10:06:14 --> Config Class Initialized
INFO - 2024-10-15 10:06:14 --> Loader Class Initialized
INFO - 2024-10-15 10:06:14 --> Helper loaded: url_helper
INFO - 2024-10-15 10:06:14 --> Helper loaded: file_helper
INFO - 2024-10-15 10:06:14 --> Helper loaded: form_helper
INFO - 2024-10-15 10:06:14 --> Helper loaded: my_helper
INFO - 2024-10-15 10:06:14 --> Database Driver Class Initialized
INFO - 2024-10-15 10:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:06:14 --> Controller Class Initialized
INFO - 2024-10-15 10:06:14 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:06:14 --> Config Class Initialized
INFO - 2024-10-15 10:06:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:06:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:06:14 --> Utf8 Class Initialized
INFO - 2024-10-15 10:06:14 --> URI Class Initialized
INFO - 2024-10-15 10:06:14 --> Router Class Initialized
INFO - 2024-10-15 10:06:14 --> Output Class Initialized
INFO - 2024-10-15 10:06:14 --> Security Class Initialized
DEBUG - 2024-10-15 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:06:14 --> Input Class Initialized
INFO - 2024-10-15 10:06:14 --> Language Class Initialized
INFO - 2024-10-15 10:06:14 --> Language Class Initialized
INFO - 2024-10-15 10:06:14 --> Config Class Initialized
INFO - 2024-10-15 10:06:14 --> Loader Class Initialized
INFO - 2024-10-15 10:06:14 --> Helper loaded: url_helper
INFO - 2024-10-15 10:06:14 --> Helper loaded: file_helper
INFO - 2024-10-15 10:06:14 --> Helper loaded: form_helper
INFO - 2024-10-15 10:06:14 --> Helper loaded: my_helper
INFO - 2024-10-15 10:06:14 --> Database Driver Class Initialized
INFO - 2024-10-15 10:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:06:14 --> Controller Class Initialized
DEBUG - 2024-10-15 10:06:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:06:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:06:14 --> Final output sent to browser
DEBUG - 2024-10-15 10:06:14 --> Total execution time: 0.0465
INFO - 2024-10-15 10:06:20 --> Config Class Initialized
INFO - 2024-10-15 10:06:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:06:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:06:20 --> Utf8 Class Initialized
INFO - 2024-10-15 10:06:20 --> URI Class Initialized
INFO - 2024-10-15 10:06:20 --> Router Class Initialized
INFO - 2024-10-15 10:06:20 --> Output Class Initialized
INFO - 2024-10-15 10:06:20 --> Security Class Initialized
DEBUG - 2024-10-15 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:06:20 --> Input Class Initialized
INFO - 2024-10-15 10:06:20 --> Language Class Initialized
INFO - 2024-10-15 10:06:20 --> Language Class Initialized
INFO - 2024-10-15 10:06:20 --> Config Class Initialized
INFO - 2024-10-15 10:06:20 --> Loader Class Initialized
INFO - 2024-10-15 10:06:20 --> Helper loaded: url_helper
INFO - 2024-10-15 10:06:20 --> Helper loaded: file_helper
INFO - 2024-10-15 10:06:20 --> Helper loaded: form_helper
INFO - 2024-10-15 10:06:20 --> Helper loaded: my_helper
INFO - 2024-10-15 10:06:20 --> Database Driver Class Initialized
INFO - 2024-10-15 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:06:20 --> Controller Class Initialized
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 10:06:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 10:06:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:06:23 --> Final output sent to browser
DEBUG - 2024-10-15 10:06:23 --> Total execution time: 3.0284
INFO - 2024-10-15 10:10:52 --> Config Class Initialized
INFO - 2024-10-15 10:10:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:10:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:10:52 --> Utf8 Class Initialized
INFO - 2024-10-15 10:10:52 --> URI Class Initialized
DEBUG - 2024-10-15 10:10:52 --> No URI present. Default controller set.
INFO - 2024-10-15 10:10:52 --> Router Class Initialized
INFO - 2024-10-15 10:10:52 --> Output Class Initialized
INFO - 2024-10-15 10:10:52 --> Security Class Initialized
DEBUG - 2024-10-15 10:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:10:52 --> Input Class Initialized
INFO - 2024-10-15 10:10:52 --> Language Class Initialized
INFO - 2024-10-15 10:10:52 --> Language Class Initialized
INFO - 2024-10-15 10:10:52 --> Config Class Initialized
INFO - 2024-10-15 10:10:52 --> Loader Class Initialized
INFO - 2024-10-15 10:10:52 --> Helper loaded: url_helper
INFO - 2024-10-15 10:10:52 --> Helper loaded: file_helper
INFO - 2024-10-15 10:10:52 --> Helper loaded: form_helper
INFO - 2024-10-15 10:10:52 --> Helper loaded: my_helper
INFO - 2024-10-15 10:10:52 --> Database Driver Class Initialized
INFO - 2024-10-15 10:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:10:52 --> Controller Class Initialized
INFO - 2024-10-15 10:10:52 --> Config Class Initialized
INFO - 2024-10-15 10:10:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:10:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:10:52 --> Utf8 Class Initialized
INFO - 2024-10-15 10:10:52 --> URI Class Initialized
INFO - 2024-10-15 10:10:52 --> Router Class Initialized
INFO - 2024-10-15 10:10:52 --> Output Class Initialized
INFO - 2024-10-15 10:10:52 --> Security Class Initialized
DEBUG - 2024-10-15 10:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:10:52 --> Input Class Initialized
INFO - 2024-10-15 10:10:52 --> Language Class Initialized
INFO - 2024-10-15 10:10:52 --> Language Class Initialized
INFO - 2024-10-15 10:10:52 --> Config Class Initialized
INFO - 2024-10-15 10:10:52 --> Loader Class Initialized
INFO - 2024-10-15 10:10:52 --> Helper loaded: url_helper
INFO - 2024-10-15 10:10:52 --> Helper loaded: file_helper
INFO - 2024-10-15 10:10:52 --> Helper loaded: form_helper
INFO - 2024-10-15 10:10:52 --> Helper loaded: my_helper
INFO - 2024-10-15 10:10:52 --> Database Driver Class Initialized
INFO - 2024-10-15 10:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:10:52 --> Controller Class Initialized
DEBUG - 2024-10-15 10:10:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-15 10:10:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:10:52 --> Final output sent to browser
DEBUG - 2024-10-15 10:10:52 --> Total execution time: 0.0382
INFO - 2024-10-15 10:10:56 --> Config Class Initialized
INFO - 2024-10-15 10:10:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:10:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:10:56 --> Utf8 Class Initialized
INFO - 2024-10-15 10:10:56 --> URI Class Initialized
INFO - 2024-10-15 10:10:56 --> Router Class Initialized
INFO - 2024-10-15 10:10:56 --> Output Class Initialized
INFO - 2024-10-15 10:10:56 --> Security Class Initialized
DEBUG - 2024-10-15 10:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:10:56 --> Input Class Initialized
INFO - 2024-10-15 10:10:56 --> Language Class Initialized
INFO - 2024-10-15 10:10:56 --> Language Class Initialized
INFO - 2024-10-15 10:10:56 --> Config Class Initialized
INFO - 2024-10-15 10:10:56 --> Loader Class Initialized
INFO - 2024-10-15 10:10:56 --> Helper loaded: url_helper
INFO - 2024-10-15 10:10:56 --> Helper loaded: file_helper
INFO - 2024-10-15 10:10:56 --> Helper loaded: form_helper
INFO - 2024-10-15 10:10:56 --> Helper loaded: my_helper
INFO - 2024-10-15 10:10:57 --> Database Driver Class Initialized
INFO - 2024-10-15 10:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:10:57 --> Controller Class Initialized
INFO - 2024-10-15 10:10:57 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:10:57 --> Final output sent to browser
DEBUG - 2024-10-15 10:10:57 --> Total execution time: 0.0453
INFO - 2024-10-15 10:10:57 --> Config Class Initialized
INFO - 2024-10-15 10:10:57 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:10:57 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:10:57 --> Utf8 Class Initialized
INFO - 2024-10-15 10:10:57 --> URI Class Initialized
INFO - 2024-10-15 10:10:57 --> Router Class Initialized
INFO - 2024-10-15 10:10:57 --> Output Class Initialized
INFO - 2024-10-15 10:10:57 --> Security Class Initialized
DEBUG - 2024-10-15 10:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:10:57 --> Input Class Initialized
INFO - 2024-10-15 10:10:57 --> Language Class Initialized
INFO - 2024-10-15 10:10:57 --> Language Class Initialized
INFO - 2024-10-15 10:10:57 --> Config Class Initialized
INFO - 2024-10-15 10:10:57 --> Loader Class Initialized
INFO - 2024-10-15 10:10:57 --> Helper loaded: url_helper
INFO - 2024-10-15 10:10:57 --> Helper loaded: file_helper
INFO - 2024-10-15 10:10:57 --> Helper loaded: form_helper
INFO - 2024-10-15 10:10:57 --> Helper loaded: my_helper
INFO - 2024-10-15 10:10:57 --> Database Driver Class Initialized
INFO - 2024-10-15 10:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:10:57 --> Controller Class Initialized
DEBUG - 2024-10-15 10:10:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-15 10:10:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:10:57 --> Final output sent to browser
DEBUG - 2024-10-15 10:10:57 --> Total execution time: 0.0413
INFO - 2024-10-15 10:11:00 --> Config Class Initialized
INFO - 2024-10-15 10:11:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:00 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:00 --> URI Class Initialized
INFO - 2024-10-15 10:11:00 --> Router Class Initialized
INFO - 2024-10-15 10:11:00 --> Output Class Initialized
INFO - 2024-10-15 10:11:00 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:00 --> Input Class Initialized
INFO - 2024-10-15 10:11:00 --> Language Class Initialized
INFO - 2024-10-15 10:11:00 --> Language Class Initialized
INFO - 2024-10-15 10:11:00 --> Config Class Initialized
INFO - 2024-10-15 10:11:00 --> Loader Class Initialized
INFO - 2024-10-15 10:11:00 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:00 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:00 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:00 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:00 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:00 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-15 10:11:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:11:00 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:00 --> Total execution time: 0.0330
INFO - 2024-10-15 10:11:00 --> Config Class Initialized
INFO - 2024-10-15 10:11:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:00 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:00 --> URI Class Initialized
INFO - 2024-10-15 10:11:00 --> Router Class Initialized
INFO - 2024-10-15 10:11:00 --> Output Class Initialized
INFO - 2024-10-15 10:11:00 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:00 --> Input Class Initialized
INFO - 2024-10-15 10:11:00 --> Language Class Initialized
ERROR - 2024-10-15 10:11:00 --> 404 Page Not Found: /index
INFO - 2024-10-15 10:11:00 --> Config Class Initialized
INFO - 2024-10-15 10:11:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:00 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:00 --> URI Class Initialized
INFO - 2024-10-15 10:11:00 --> Router Class Initialized
INFO - 2024-10-15 10:11:00 --> Output Class Initialized
INFO - 2024-10-15 10:11:00 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:00 --> Input Class Initialized
INFO - 2024-10-15 10:11:00 --> Language Class Initialized
INFO - 2024-10-15 10:11:00 --> Language Class Initialized
INFO - 2024-10-15 10:11:00 --> Config Class Initialized
INFO - 2024-10-15 10:11:00 --> Loader Class Initialized
INFO - 2024-10-15 10:11:00 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:00 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:00 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:00 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:00 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:00 --> Controller Class Initialized
INFO - 2024-10-15 10:11:02 --> Config Class Initialized
INFO - 2024-10-15 10:11:02 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:02 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:02 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:02 --> URI Class Initialized
INFO - 2024-10-15 10:11:02 --> Router Class Initialized
INFO - 2024-10-15 10:11:02 --> Output Class Initialized
INFO - 2024-10-15 10:11:02 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:02 --> Input Class Initialized
INFO - 2024-10-15 10:11:02 --> Language Class Initialized
INFO - 2024-10-15 10:11:02 --> Language Class Initialized
INFO - 2024-10-15 10:11:02 --> Config Class Initialized
INFO - 2024-10-15 10:11:02 --> Loader Class Initialized
INFO - 2024-10-15 10:11:02 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:02 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:02 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:02 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:02 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:02 --> Controller Class Initialized
INFO - 2024-10-15 10:11:03 --> Config Class Initialized
INFO - 2024-10-15 10:11:03 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:03 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:03 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:03 --> URI Class Initialized
INFO - 2024-10-15 10:11:03 --> Router Class Initialized
INFO - 2024-10-15 10:11:03 --> Output Class Initialized
INFO - 2024-10-15 10:11:03 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:03 --> Input Class Initialized
INFO - 2024-10-15 10:11:03 --> Language Class Initialized
INFO - 2024-10-15 10:11:03 --> Language Class Initialized
INFO - 2024-10-15 10:11:03 --> Config Class Initialized
INFO - 2024-10-15 10:11:03 --> Loader Class Initialized
INFO - 2024-10-15 10:11:03 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:03 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:03 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:03 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:03 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:03 --> Controller Class Initialized
INFO - 2024-10-15 10:11:14 --> Config Class Initialized
INFO - 2024-10-15 10:11:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:14 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:14 --> URI Class Initialized
INFO - 2024-10-15 10:11:14 --> Router Class Initialized
INFO - 2024-10-15 10:11:14 --> Output Class Initialized
INFO - 2024-10-15 10:11:14 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:14 --> Input Class Initialized
INFO - 2024-10-15 10:11:14 --> Language Class Initialized
INFO - 2024-10-15 10:11:14 --> Language Class Initialized
INFO - 2024-10-15 10:11:14 --> Config Class Initialized
INFO - 2024-10-15 10:11:14 --> Loader Class Initialized
INFO - 2024-10-15 10:11:14 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:14 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:14 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:14 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:14 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:14 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-15 10:11:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:11:14 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:14 --> Total execution time: 0.0805
INFO - 2024-10-15 10:11:20 --> Config Class Initialized
INFO - 2024-10-15 10:11:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:20 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:20 --> URI Class Initialized
INFO - 2024-10-15 10:11:20 --> Router Class Initialized
INFO - 2024-10-15 10:11:20 --> Output Class Initialized
INFO - 2024-10-15 10:11:20 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:20 --> Input Class Initialized
INFO - 2024-10-15 10:11:20 --> Language Class Initialized
INFO - 2024-10-15 10:11:20 --> Language Class Initialized
INFO - 2024-10-15 10:11:20 --> Config Class Initialized
INFO - 2024-10-15 10:11:20 --> Loader Class Initialized
INFO - 2024-10-15 10:11:20 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:20 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:20 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:20 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:20 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:20 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-15 10:11:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:11:20 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:20 --> Total execution time: 0.0361
INFO - 2024-10-15 10:11:20 --> Config Class Initialized
INFO - 2024-10-15 10:11:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:20 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:20 --> URI Class Initialized
INFO - 2024-10-15 10:11:20 --> Router Class Initialized
INFO - 2024-10-15 10:11:20 --> Output Class Initialized
INFO - 2024-10-15 10:11:20 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:20 --> Input Class Initialized
INFO - 2024-10-15 10:11:20 --> Language Class Initialized
ERROR - 2024-10-15 10:11:20 --> 404 Page Not Found: /index
INFO - 2024-10-15 10:11:20 --> Config Class Initialized
INFO - 2024-10-15 10:11:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:20 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:20 --> URI Class Initialized
INFO - 2024-10-15 10:11:20 --> Router Class Initialized
INFO - 2024-10-15 10:11:20 --> Output Class Initialized
INFO - 2024-10-15 10:11:20 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:20 --> Input Class Initialized
INFO - 2024-10-15 10:11:20 --> Language Class Initialized
INFO - 2024-10-15 10:11:20 --> Language Class Initialized
INFO - 2024-10-15 10:11:20 --> Config Class Initialized
INFO - 2024-10-15 10:11:20 --> Loader Class Initialized
INFO - 2024-10-15 10:11:20 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:20 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:20 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:20 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:20 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:20 --> Controller Class Initialized
INFO - 2024-10-15 10:11:23 --> Config Class Initialized
INFO - 2024-10-15 10:11:23 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:23 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:23 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:23 --> URI Class Initialized
INFO - 2024-10-15 10:11:23 --> Router Class Initialized
INFO - 2024-10-15 10:11:23 --> Output Class Initialized
INFO - 2024-10-15 10:11:23 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:23 --> Input Class Initialized
INFO - 2024-10-15 10:11:23 --> Language Class Initialized
INFO - 2024-10-15 10:11:23 --> Language Class Initialized
INFO - 2024-10-15 10:11:23 --> Config Class Initialized
INFO - 2024-10-15 10:11:23 --> Loader Class Initialized
INFO - 2024-10-15 10:11:23 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:23 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:23 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:23 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:23 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:23 --> Controller Class Initialized
INFO - 2024-10-15 10:11:35 --> Config Class Initialized
INFO - 2024-10-15 10:11:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:35 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:35 --> URI Class Initialized
INFO - 2024-10-15 10:11:35 --> Router Class Initialized
INFO - 2024-10-15 10:11:35 --> Output Class Initialized
INFO - 2024-10-15 10:11:35 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:35 --> Input Class Initialized
INFO - 2024-10-15 10:11:35 --> Language Class Initialized
INFO - 2024-10-15 10:11:35 --> Language Class Initialized
INFO - 2024-10-15 10:11:35 --> Config Class Initialized
INFO - 2024-10-15 10:11:35 --> Loader Class Initialized
INFO - 2024-10-15 10:11:35 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:35 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:35 --> Controller Class Initialized
INFO - 2024-10-15 10:11:35 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:11:35 --> Config Class Initialized
INFO - 2024-10-15 10:11:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:35 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:35 --> URI Class Initialized
INFO - 2024-10-15 10:11:35 --> Router Class Initialized
INFO - 2024-10-15 10:11:35 --> Output Class Initialized
INFO - 2024-10-15 10:11:35 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:35 --> Input Class Initialized
INFO - 2024-10-15 10:11:35 --> Language Class Initialized
INFO - 2024-10-15 10:11:35 --> Language Class Initialized
INFO - 2024-10-15 10:11:35 --> Config Class Initialized
INFO - 2024-10-15 10:11:35 --> Loader Class Initialized
INFO - 2024-10-15 10:11:35 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:35 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:35 --> Controller Class Initialized
INFO - 2024-10-15 10:11:35 --> Config Class Initialized
INFO - 2024-10-15 10:11:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:35 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:35 --> URI Class Initialized
INFO - 2024-10-15 10:11:35 --> Router Class Initialized
INFO - 2024-10-15 10:11:35 --> Output Class Initialized
INFO - 2024-10-15 10:11:35 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:35 --> Input Class Initialized
INFO - 2024-10-15 10:11:35 --> Language Class Initialized
INFO - 2024-10-15 10:11:35 --> Language Class Initialized
INFO - 2024-10-15 10:11:35 --> Config Class Initialized
INFO - 2024-10-15 10:11:35 --> Loader Class Initialized
INFO - 2024-10-15 10:11:35 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:35 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:35 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:35 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-15 10:11:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:11:35 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:35 --> Total execution time: 0.0397
INFO - 2024-10-15 10:11:43 --> Config Class Initialized
INFO - 2024-10-15 10:11:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:43 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:43 --> URI Class Initialized
INFO - 2024-10-15 10:11:43 --> Router Class Initialized
INFO - 2024-10-15 10:11:43 --> Output Class Initialized
INFO - 2024-10-15 10:11:43 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:43 --> Input Class Initialized
INFO - 2024-10-15 10:11:43 --> Language Class Initialized
INFO - 2024-10-15 10:11:43 --> Language Class Initialized
INFO - 2024-10-15 10:11:43 --> Config Class Initialized
INFO - 2024-10-15 10:11:43 --> Loader Class Initialized
INFO - 2024-10-15 10:11:43 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:43 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:43 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:43 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:43 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:43 --> Controller Class Initialized
INFO - 2024-10-15 10:11:43 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:11:43 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:43 --> Total execution time: 0.0336
INFO - 2024-10-15 10:11:43 --> Config Class Initialized
INFO - 2024-10-15 10:11:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:43 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:43 --> URI Class Initialized
INFO - 2024-10-15 10:11:43 --> Router Class Initialized
INFO - 2024-10-15 10:11:44 --> Output Class Initialized
INFO - 2024-10-15 10:11:44 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:44 --> Input Class Initialized
INFO - 2024-10-15 10:11:44 --> Language Class Initialized
INFO - 2024-10-15 10:11:44 --> Language Class Initialized
INFO - 2024-10-15 10:11:44 --> Config Class Initialized
INFO - 2024-10-15 10:11:44 --> Loader Class Initialized
INFO - 2024-10-15 10:11:44 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:44 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:44 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:44 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:44 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:44 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-15 10:11:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:11:44 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:44 --> Total execution time: 0.0469
INFO - 2024-10-15 10:11:45 --> Config Class Initialized
INFO - 2024-10-15 10:11:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:45 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:45 --> URI Class Initialized
INFO - 2024-10-15 10:11:45 --> Router Class Initialized
INFO - 2024-10-15 10:11:45 --> Output Class Initialized
INFO - 2024-10-15 10:11:45 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:45 --> Input Class Initialized
INFO - 2024-10-15 10:11:45 --> Language Class Initialized
INFO - 2024-10-15 10:11:45 --> Language Class Initialized
INFO - 2024-10-15 10:11:45 --> Config Class Initialized
INFO - 2024-10-15 10:11:45 --> Loader Class Initialized
INFO - 2024-10-15 10:11:45 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:45 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:45 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:45 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:45 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:45 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:11:45 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:45 --> Total execution time: 0.0394
INFO - 2024-10-15 10:11:46 --> Config Class Initialized
INFO - 2024-10-15 10:11:46 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:11:46 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:11:46 --> Utf8 Class Initialized
INFO - 2024-10-15 10:11:46 --> URI Class Initialized
INFO - 2024-10-15 10:11:46 --> Router Class Initialized
INFO - 2024-10-15 10:11:46 --> Output Class Initialized
INFO - 2024-10-15 10:11:46 --> Security Class Initialized
DEBUG - 2024-10-15 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:11:46 --> Input Class Initialized
INFO - 2024-10-15 10:11:46 --> Language Class Initialized
INFO - 2024-10-15 10:11:46 --> Language Class Initialized
INFO - 2024-10-15 10:11:46 --> Config Class Initialized
INFO - 2024-10-15 10:11:46 --> Loader Class Initialized
INFO - 2024-10-15 10:11:46 --> Helper loaded: url_helper
INFO - 2024-10-15 10:11:46 --> Helper loaded: file_helper
INFO - 2024-10-15 10:11:46 --> Helper loaded: form_helper
INFO - 2024-10-15 10:11:46 --> Helper loaded: my_helper
INFO - 2024-10-15 10:11:46 --> Database Driver Class Initialized
INFO - 2024-10-15 10:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:11:46 --> Controller Class Initialized
DEBUG - 2024-10-15 10:11:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:11:50 --> Final output sent to browser
DEBUG - 2024-10-15 10:11:50 --> Total execution time: 3.5748
INFO - 2024-10-15 10:13:57 --> Config Class Initialized
INFO - 2024-10-15 10:13:57 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:13:57 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:13:57 --> Utf8 Class Initialized
INFO - 2024-10-15 10:13:57 --> URI Class Initialized
INFO - 2024-10-15 10:13:57 --> Router Class Initialized
INFO - 2024-10-15 10:13:57 --> Output Class Initialized
INFO - 2024-10-15 10:13:57 --> Security Class Initialized
DEBUG - 2024-10-15 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:13:57 --> Input Class Initialized
INFO - 2024-10-15 10:13:57 --> Language Class Initialized
INFO - 2024-10-15 10:13:57 --> Language Class Initialized
INFO - 2024-10-15 10:13:57 --> Config Class Initialized
INFO - 2024-10-15 10:13:57 --> Loader Class Initialized
INFO - 2024-10-15 10:13:57 --> Helper loaded: url_helper
INFO - 2024-10-15 10:13:57 --> Helper loaded: file_helper
INFO - 2024-10-15 10:13:57 --> Helper loaded: form_helper
INFO - 2024-10-15 10:13:57 --> Helper loaded: my_helper
INFO - 2024-10-15 10:13:57 --> Database Driver Class Initialized
INFO - 2024-10-15 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:13:57 --> Controller Class Initialized
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-10-15 10:13:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-10-15 10:13:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-10-15 10:17:04 --> Config Class Initialized
INFO - 2024-10-15 10:17:04 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:04 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:04 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:04 --> URI Class Initialized
INFO - 2024-10-15 10:17:04 --> Router Class Initialized
INFO - 2024-10-15 10:17:04 --> Output Class Initialized
INFO - 2024-10-15 10:17:04 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:04 --> Input Class Initialized
INFO - 2024-10-15 10:17:04 --> Language Class Initialized
INFO - 2024-10-15 10:17:05 --> Language Class Initialized
INFO - 2024-10-15 10:17:05 --> Config Class Initialized
INFO - 2024-10-15 10:17:05 --> Loader Class Initialized
INFO - 2024-10-15 10:17:05 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:05 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:05 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:05 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:05 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:05 --> Controller Class Initialized
INFO - 2024-10-15 10:17:05 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:17:05 --> Final output sent to browser
DEBUG - 2024-10-15 10:17:05 --> Total execution time: 0.4664
INFO - 2024-10-15 10:17:06 --> Config Class Initialized
INFO - 2024-10-15 10:17:06 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:06 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:06 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:06 --> URI Class Initialized
INFO - 2024-10-15 10:17:06 --> Router Class Initialized
INFO - 2024-10-15 10:17:06 --> Output Class Initialized
INFO - 2024-10-15 10:17:06 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:06 --> Input Class Initialized
INFO - 2024-10-15 10:17:06 --> Language Class Initialized
INFO - 2024-10-15 10:17:06 --> Language Class Initialized
INFO - 2024-10-15 10:17:06 --> Config Class Initialized
INFO - 2024-10-15 10:17:06 --> Loader Class Initialized
INFO - 2024-10-15 10:17:06 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:06 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:06 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:06 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:06 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:06 --> Controller Class Initialized
INFO - 2024-10-15 10:17:06 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:17:06 --> Config Class Initialized
INFO - 2024-10-15 10:17:06 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:06 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:06 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:06 --> URI Class Initialized
INFO - 2024-10-15 10:17:06 --> Router Class Initialized
INFO - 2024-10-15 10:17:06 --> Output Class Initialized
INFO - 2024-10-15 10:17:06 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:06 --> Input Class Initialized
INFO - 2024-10-15 10:17:06 --> Language Class Initialized
INFO - 2024-10-15 10:17:06 --> Language Class Initialized
INFO - 2024-10-15 10:17:06 --> Config Class Initialized
INFO - 2024-10-15 10:17:06 --> Loader Class Initialized
INFO - 2024-10-15 10:17:06 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:06 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:06 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:06 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:06 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:06 --> Controller Class Initialized
DEBUG - 2024-10-15 10:17:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:17:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:17:06 --> Final output sent to browser
DEBUG - 2024-10-15 10:17:06 --> Total execution time: 0.1552
INFO - 2024-10-15 10:17:09 --> Config Class Initialized
INFO - 2024-10-15 10:17:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:09 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:09 --> URI Class Initialized
INFO - 2024-10-15 10:17:09 --> Router Class Initialized
INFO - 2024-10-15 10:17:09 --> Output Class Initialized
INFO - 2024-10-15 10:17:09 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:09 --> Input Class Initialized
INFO - 2024-10-15 10:17:09 --> Language Class Initialized
INFO - 2024-10-15 10:17:09 --> Language Class Initialized
INFO - 2024-10-15 10:17:09 --> Config Class Initialized
INFO - 2024-10-15 10:17:09 --> Loader Class Initialized
INFO - 2024-10-15 10:17:09 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:09 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:09 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:09 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:09 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:09 --> Controller Class Initialized
DEBUG - 2024-10-15 10:17:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:17:16 --> Final output sent to browser
DEBUG - 2024-10-15 10:17:16 --> Total execution time: 7.0225
INFO - 2024-10-15 10:17:58 --> Config Class Initialized
INFO - 2024-10-15 10:17:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:58 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:58 --> URI Class Initialized
INFO - 2024-10-15 10:17:58 --> Router Class Initialized
INFO - 2024-10-15 10:17:58 --> Output Class Initialized
INFO - 2024-10-15 10:17:58 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:58 --> Input Class Initialized
INFO - 2024-10-15 10:17:58 --> Language Class Initialized
INFO - 2024-10-15 10:17:58 --> Language Class Initialized
INFO - 2024-10-15 10:17:58 --> Config Class Initialized
INFO - 2024-10-15 10:17:58 --> Loader Class Initialized
INFO - 2024-10-15 10:17:58 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:58 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:58 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:58 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:58 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:58 --> Controller Class Initialized
INFO - 2024-10-15 10:17:58 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:17:58 --> Final output sent to browser
DEBUG - 2024-10-15 10:17:58 --> Total execution time: 0.3302
INFO - 2024-10-15 10:17:58 --> Config Class Initialized
INFO - 2024-10-15 10:17:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:58 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:58 --> URI Class Initialized
INFO - 2024-10-15 10:17:58 --> Router Class Initialized
INFO - 2024-10-15 10:17:58 --> Output Class Initialized
INFO - 2024-10-15 10:17:58 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:58 --> Input Class Initialized
INFO - 2024-10-15 10:17:58 --> Language Class Initialized
INFO - 2024-10-15 10:17:58 --> Language Class Initialized
INFO - 2024-10-15 10:17:58 --> Config Class Initialized
INFO - 2024-10-15 10:17:58 --> Loader Class Initialized
INFO - 2024-10-15 10:17:58 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:58 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:58 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:58 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:58 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:59 --> Controller Class Initialized
INFO - 2024-10-15 10:17:59 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:17:59 --> Config Class Initialized
INFO - 2024-10-15 10:17:59 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:17:59 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:17:59 --> Utf8 Class Initialized
INFO - 2024-10-15 10:17:59 --> URI Class Initialized
INFO - 2024-10-15 10:17:59 --> Router Class Initialized
INFO - 2024-10-15 10:17:59 --> Output Class Initialized
INFO - 2024-10-15 10:17:59 --> Security Class Initialized
DEBUG - 2024-10-15 10:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:17:59 --> Input Class Initialized
INFO - 2024-10-15 10:17:59 --> Language Class Initialized
INFO - 2024-10-15 10:17:59 --> Language Class Initialized
INFO - 2024-10-15 10:17:59 --> Config Class Initialized
INFO - 2024-10-15 10:17:59 --> Loader Class Initialized
INFO - 2024-10-15 10:17:59 --> Helper loaded: url_helper
INFO - 2024-10-15 10:17:59 --> Helper loaded: file_helper
INFO - 2024-10-15 10:17:59 --> Helper loaded: form_helper
INFO - 2024-10-15 10:17:59 --> Helper loaded: my_helper
INFO - 2024-10-15 10:17:59 --> Database Driver Class Initialized
INFO - 2024-10-15 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:17:59 --> Controller Class Initialized
DEBUG - 2024-10-15 10:17:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:17:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:17:59 --> Final output sent to browser
DEBUG - 2024-10-15 10:17:59 --> Total execution time: 0.1214
INFO - 2024-10-15 10:18:01 --> Config Class Initialized
INFO - 2024-10-15 10:18:01 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:18:01 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:18:01 --> Utf8 Class Initialized
INFO - 2024-10-15 10:18:01 --> URI Class Initialized
INFO - 2024-10-15 10:18:01 --> Router Class Initialized
INFO - 2024-10-15 10:18:01 --> Output Class Initialized
INFO - 2024-10-15 10:18:01 --> Security Class Initialized
DEBUG - 2024-10-15 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:18:01 --> Input Class Initialized
INFO - 2024-10-15 10:18:01 --> Language Class Initialized
INFO - 2024-10-15 10:18:01 --> Language Class Initialized
INFO - 2024-10-15 10:18:01 --> Config Class Initialized
INFO - 2024-10-15 10:18:01 --> Loader Class Initialized
INFO - 2024-10-15 10:18:01 --> Helper loaded: url_helper
INFO - 2024-10-15 10:18:01 --> Helper loaded: file_helper
INFO - 2024-10-15 10:18:01 --> Helper loaded: form_helper
INFO - 2024-10-15 10:18:01 --> Helper loaded: my_helper
INFO - 2024-10-15 10:18:01 --> Database Driver Class Initialized
INFO - 2024-10-15 10:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:18:01 --> Controller Class Initialized
DEBUG - 2024-10-15 10:18:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:18:12 --> Final output sent to browser
DEBUG - 2024-10-15 10:18:12 --> Total execution time: 10.9759
ERROR - 2024-10-15 10:18:19 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 262144 bytes) /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 4148
INFO - 2024-10-15 10:18:38 --> Config Class Initialized
INFO - 2024-10-15 10:18:38 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:18:38 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:18:38 --> Utf8 Class Initialized
INFO - 2024-10-15 10:18:38 --> URI Class Initialized
INFO - 2024-10-15 10:18:38 --> Router Class Initialized
INFO - 2024-10-15 10:18:38 --> Output Class Initialized
INFO - 2024-10-15 10:18:38 --> Security Class Initialized
DEBUG - 2024-10-15 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:18:38 --> Input Class Initialized
INFO - 2024-10-15 10:18:38 --> Language Class Initialized
INFO - 2024-10-15 10:18:38 --> Language Class Initialized
INFO - 2024-10-15 10:18:38 --> Config Class Initialized
INFO - 2024-10-15 10:18:38 --> Loader Class Initialized
INFO - 2024-10-15 10:18:38 --> Helper loaded: url_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: file_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: form_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: my_helper
INFO - 2024-10-15 10:18:38 --> Database Driver Class Initialized
INFO - 2024-10-15 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:18:38 --> Controller Class Initialized
INFO - 2024-10-15 10:18:38 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:18:38 --> Config Class Initialized
INFO - 2024-10-15 10:18:38 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:18:38 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:18:38 --> Utf8 Class Initialized
INFO - 2024-10-15 10:18:38 --> URI Class Initialized
INFO - 2024-10-15 10:18:38 --> Router Class Initialized
INFO - 2024-10-15 10:18:38 --> Output Class Initialized
INFO - 2024-10-15 10:18:38 --> Security Class Initialized
DEBUG - 2024-10-15 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:18:38 --> Input Class Initialized
INFO - 2024-10-15 10:18:38 --> Language Class Initialized
INFO - 2024-10-15 10:18:38 --> Language Class Initialized
INFO - 2024-10-15 10:18:38 --> Config Class Initialized
INFO - 2024-10-15 10:18:38 --> Loader Class Initialized
INFO - 2024-10-15 10:18:38 --> Helper loaded: url_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: file_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: form_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: my_helper
INFO - 2024-10-15 10:18:38 --> Database Driver Class Initialized
INFO - 2024-10-15 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:18:38 --> Controller Class Initialized
INFO - 2024-10-15 10:18:38 --> Config Class Initialized
INFO - 2024-10-15 10:18:38 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:18:38 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:18:38 --> Utf8 Class Initialized
INFO - 2024-10-15 10:18:38 --> URI Class Initialized
INFO - 2024-10-15 10:18:38 --> Router Class Initialized
INFO - 2024-10-15 10:18:38 --> Output Class Initialized
INFO - 2024-10-15 10:18:38 --> Security Class Initialized
DEBUG - 2024-10-15 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:18:38 --> Input Class Initialized
INFO - 2024-10-15 10:18:38 --> Language Class Initialized
INFO - 2024-10-15 10:18:38 --> Language Class Initialized
INFO - 2024-10-15 10:18:38 --> Config Class Initialized
INFO - 2024-10-15 10:18:38 --> Loader Class Initialized
INFO - 2024-10-15 10:18:38 --> Helper loaded: url_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: file_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: form_helper
INFO - 2024-10-15 10:18:38 --> Helper loaded: my_helper
INFO - 2024-10-15 10:18:38 --> Database Driver Class Initialized
INFO - 2024-10-15 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:18:38 --> Controller Class Initialized
DEBUG - 2024-10-15 10:18:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-15 10:18:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:18:38 --> Final output sent to browser
DEBUG - 2024-10-15 10:18:38 --> Total execution time: 0.0510
INFO - 2024-10-15 10:18:44 --> Config Class Initialized
INFO - 2024-10-15 10:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:18:44 --> Utf8 Class Initialized
INFO - 2024-10-15 10:18:44 --> URI Class Initialized
INFO - 2024-10-15 10:18:44 --> Router Class Initialized
INFO - 2024-10-15 10:18:44 --> Output Class Initialized
INFO - 2024-10-15 10:18:44 --> Security Class Initialized
DEBUG - 2024-10-15 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:18:44 --> Input Class Initialized
INFO - 2024-10-15 10:18:44 --> Language Class Initialized
INFO - 2024-10-15 10:18:44 --> Language Class Initialized
INFO - 2024-10-15 10:18:44 --> Config Class Initialized
INFO - 2024-10-15 10:18:44 --> Loader Class Initialized
INFO - 2024-10-15 10:18:44 --> Helper loaded: url_helper
INFO - 2024-10-15 10:18:44 --> Helper loaded: file_helper
INFO - 2024-10-15 10:18:44 --> Helper loaded: form_helper
INFO - 2024-10-15 10:18:44 --> Helper loaded: my_helper
INFO - 2024-10-15 10:18:44 --> Database Driver Class Initialized
INFO - 2024-10-15 10:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:18:44 --> Controller Class Initialized
INFO - 2024-10-15 10:18:44 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:18:44 --> Final output sent to browser
DEBUG - 2024-10-15 10:18:44 --> Total execution time: 0.0617
INFO - 2024-10-15 10:18:44 --> Config Class Initialized
INFO - 2024-10-15 10:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:18:44 --> Utf8 Class Initialized
INFO - 2024-10-15 10:18:44 --> URI Class Initialized
INFO - 2024-10-15 10:18:44 --> Router Class Initialized
INFO - 2024-10-15 10:18:44 --> Output Class Initialized
INFO - 2024-10-15 10:18:44 --> Security Class Initialized
DEBUG - 2024-10-15 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:18:44 --> Input Class Initialized
INFO - 2024-10-15 10:18:44 --> Language Class Initialized
INFO - 2024-10-15 10:18:44 --> Language Class Initialized
INFO - 2024-10-15 10:18:44 --> Config Class Initialized
INFO - 2024-10-15 10:18:44 --> Loader Class Initialized
INFO - 2024-10-15 10:18:44 --> Helper loaded: url_helper
INFO - 2024-10-15 10:18:44 --> Helper loaded: file_helper
INFO - 2024-10-15 10:18:44 --> Helper loaded: form_helper
INFO - 2024-10-15 10:18:44 --> Helper loaded: my_helper
INFO - 2024-10-15 10:18:44 --> Database Driver Class Initialized
INFO - 2024-10-15 10:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:18:44 --> Controller Class Initialized
DEBUG - 2024-10-15 10:18:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-15 10:18:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:18:44 --> Final output sent to browser
DEBUG - 2024-10-15 10:18:44 --> Total execution time: 0.0422
INFO - 2024-10-15 10:19:07 --> Config Class Initialized
INFO - 2024-10-15 10:19:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:19:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:19:07 --> Utf8 Class Initialized
INFO - 2024-10-15 10:19:07 --> URI Class Initialized
INFO - 2024-10-15 10:19:07 --> Router Class Initialized
INFO - 2024-10-15 10:19:07 --> Output Class Initialized
INFO - 2024-10-15 10:19:07 --> Security Class Initialized
DEBUG - 2024-10-15 10:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:19:07 --> Input Class Initialized
INFO - 2024-10-15 10:19:07 --> Language Class Initialized
INFO - 2024-10-15 10:19:07 --> Language Class Initialized
INFO - 2024-10-15 10:19:07 --> Config Class Initialized
INFO - 2024-10-15 10:19:07 --> Loader Class Initialized
INFO - 2024-10-15 10:19:07 --> Helper loaded: url_helper
INFO - 2024-10-15 10:19:07 --> Helper loaded: file_helper
INFO - 2024-10-15 10:19:07 --> Helper loaded: form_helper
INFO - 2024-10-15 10:19:07 --> Helper loaded: my_helper
INFO - 2024-10-15 10:19:07 --> Database Driver Class Initialized
INFO - 2024-10-15 10:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:19:08 --> Controller Class Initialized
DEBUG - 2024-10-15 10:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-10-15 10:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:19:08 --> Final output sent to browser
DEBUG - 2024-10-15 10:19:08 --> Total execution time: 0.0976
INFO - 2024-10-15 10:19:08 --> Config Class Initialized
INFO - 2024-10-15 10:19:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:19:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:19:08 --> Utf8 Class Initialized
INFO - 2024-10-15 10:19:08 --> URI Class Initialized
INFO - 2024-10-15 10:19:08 --> Router Class Initialized
INFO - 2024-10-15 10:19:08 --> Output Class Initialized
INFO - 2024-10-15 10:19:08 --> Security Class Initialized
DEBUG - 2024-10-15 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:19:08 --> Input Class Initialized
INFO - 2024-10-15 10:19:08 --> Language Class Initialized
ERROR - 2024-10-15 10:19:08 --> 404 Page Not Found: /index
INFO - 2024-10-15 10:19:08 --> Config Class Initialized
INFO - 2024-10-15 10:19:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:19:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:19:08 --> Utf8 Class Initialized
INFO - 2024-10-15 10:19:08 --> URI Class Initialized
INFO - 2024-10-15 10:19:08 --> Router Class Initialized
INFO - 2024-10-15 10:19:08 --> Output Class Initialized
INFO - 2024-10-15 10:19:08 --> Security Class Initialized
DEBUG - 2024-10-15 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:19:08 --> Input Class Initialized
INFO - 2024-10-15 10:19:08 --> Language Class Initialized
INFO - 2024-10-15 10:19:08 --> Language Class Initialized
INFO - 2024-10-15 10:19:08 --> Config Class Initialized
INFO - 2024-10-15 10:19:08 --> Loader Class Initialized
INFO - 2024-10-15 10:19:08 --> Helper loaded: url_helper
INFO - 2024-10-15 10:19:08 --> Helper loaded: file_helper
INFO - 2024-10-15 10:19:08 --> Helper loaded: form_helper
INFO - 2024-10-15 10:19:08 --> Helper loaded: my_helper
INFO - 2024-10-15 10:19:08 --> Database Driver Class Initialized
INFO - 2024-10-15 10:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:19:08 --> Controller Class Initialized
INFO - 2024-10-15 10:19:42 --> Config Class Initialized
INFO - 2024-10-15 10:19:42 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:19:42 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:19:42 --> Utf8 Class Initialized
INFO - 2024-10-15 10:19:42 --> URI Class Initialized
INFO - 2024-10-15 10:19:42 --> Router Class Initialized
INFO - 2024-10-15 10:19:42 --> Output Class Initialized
INFO - 2024-10-15 10:19:42 --> Security Class Initialized
DEBUG - 2024-10-15 10:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:19:42 --> Input Class Initialized
INFO - 2024-10-15 10:19:42 --> Language Class Initialized
INFO - 2024-10-15 10:19:42 --> Language Class Initialized
INFO - 2024-10-15 10:19:42 --> Config Class Initialized
INFO - 2024-10-15 10:19:42 --> Loader Class Initialized
INFO - 2024-10-15 10:19:42 --> Helper loaded: url_helper
INFO - 2024-10-15 10:19:42 --> Helper loaded: file_helper
INFO - 2024-10-15 10:19:43 --> Helper loaded: form_helper
INFO - 2024-10-15 10:19:43 --> Helper loaded: my_helper
INFO - 2024-10-15 10:19:43 --> Database Driver Class Initialized
INFO - 2024-10-15 10:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:19:43 --> Controller Class Initialized
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-10-15 10:19:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-10-15 10:19:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-10-15 10:24:02 --> Config Class Initialized
INFO - 2024-10-15 10:24:02 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:24:02 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:24:02 --> Utf8 Class Initialized
INFO - 2024-10-15 10:24:02 --> URI Class Initialized
INFO - 2024-10-15 10:24:02 --> Router Class Initialized
INFO - 2024-10-15 10:24:02 --> Output Class Initialized
INFO - 2024-10-15 10:24:02 --> Security Class Initialized
DEBUG - 2024-10-15 10:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:24:02 --> Input Class Initialized
INFO - 2024-10-15 10:24:02 --> Language Class Initialized
INFO - 2024-10-15 10:24:02 --> Language Class Initialized
INFO - 2024-10-15 10:24:02 --> Config Class Initialized
INFO - 2024-10-15 10:24:02 --> Loader Class Initialized
INFO - 2024-10-15 10:24:02 --> Helper loaded: url_helper
INFO - 2024-10-15 10:24:02 --> Helper loaded: file_helper
INFO - 2024-10-15 10:24:02 --> Helper loaded: form_helper
INFO - 2024-10-15 10:24:02 --> Helper loaded: my_helper
INFO - 2024-10-15 10:24:02 --> Database Driver Class Initialized
INFO - 2024-10-15 10:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:24:02 --> Controller Class Initialized
INFO - 2024-10-15 10:24:02 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:24:02 --> Final output sent to browser
DEBUG - 2024-10-15 10:24:02 --> Total execution time: 0.0998
INFO - 2024-10-15 10:24:03 --> Config Class Initialized
INFO - 2024-10-15 10:24:03 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:24:03 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:24:03 --> Utf8 Class Initialized
INFO - 2024-10-15 10:24:03 --> URI Class Initialized
INFO - 2024-10-15 10:24:03 --> Router Class Initialized
INFO - 2024-10-15 10:24:03 --> Output Class Initialized
INFO - 2024-10-15 10:24:03 --> Security Class Initialized
DEBUG - 2024-10-15 10:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:24:03 --> Input Class Initialized
INFO - 2024-10-15 10:24:03 --> Language Class Initialized
INFO - 2024-10-15 10:24:03 --> Language Class Initialized
INFO - 2024-10-15 10:24:03 --> Config Class Initialized
INFO - 2024-10-15 10:24:03 --> Loader Class Initialized
INFO - 2024-10-15 10:24:03 --> Helper loaded: url_helper
INFO - 2024-10-15 10:24:03 --> Helper loaded: file_helper
INFO - 2024-10-15 10:24:03 --> Helper loaded: form_helper
INFO - 2024-10-15 10:24:03 --> Helper loaded: my_helper
INFO - 2024-10-15 10:24:03 --> Database Driver Class Initialized
INFO - 2024-10-15 10:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:24:03 --> Controller Class Initialized
INFO - 2024-10-15 10:24:03 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:24:03 --> Config Class Initialized
INFO - 2024-10-15 10:24:03 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:24:03 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:24:03 --> Utf8 Class Initialized
INFO - 2024-10-15 10:24:03 --> URI Class Initialized
INFO - 2024-10-15 10:24:03 --> Router Class Initialized
INFO - 2024-10-15 10:24:03 --> Output Class Initialized
INFO - 2024-10-15 10:24:03 --> Security Class Initialized
DEBUG - 2024-10-15 10:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:24:03 --> Input Class Initialized
INFO - 2024-10-15 10:24:03 --> Language Class Initialized
INFO - 2024-10-15 10:24:03 --> Language Class Initialized
INFO - 2024-10-15 10:24:03 --> Config Class Initialized
INFO - 2024-10-15 10:24:03 --> Loader Class Initialized
INFO - 2024-10-15 10:24:03 --> Helper loaded: url_helper
INFO - 2024-10-15 10:24:03 --> Helper loaded: file_helper
INFO - 2024-10-15 10:24:03 --> Helper loaded: form_helper
INFO - 2024-10-15 10:24:03 --> Helper loaded: my_helper
INFO - 2024-10-15 10:24:03 --> Database Driver Class Initialized
INFO - 2024-10-15 10:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:24:03 --> Controller Class Initialized
DEBUG - 2024-10-15 10:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:24:03 --> Final output sent to browser
DEBUG - 2024-10-15 10:24:03 --> Total execution time: 0.0474
INFO - 2024-10-15 10:24:07 --> Config Class Initialized
INFO - 2024-10-15 10:24:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:24:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:24:07 --> Utf8 Class Initialized
INFO - 2024-10-15 10:24:07 --> URI Class Initialized
INFO - 2024-10-15 10:24:07 --> Router Class Initialized
INFO - 2024-10-15 10:24:07 --> Output Class Initialized
INFO - 2024-10-15 10:24:07 --> Security Class Initialized
DEBUG - 2024-10-15 10:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:24:07 --> Input Class Initialized
INFO - 2024-10-15 10:24:07 --> Language Class Initialized
INFO - 2024-10-15 10:24:07 --> Language Class Initialized
INFO - 2024-10-15 10:24:07 --> Config Class Initialized
INFO - 2024-10-15 10:24:07 --> Loader Class Initialized
INFO - 2024-10-15 10:24:07 --> Helper loaded: url_helper
INFO - 2024-10-15 10:24:07 --> Helper loaded: file_helper
INFO - 2024-10-15 10:24:07 --> Helper loaded: form_helper
INFO - 2024-10-15 10:24:07 --> Helper loaded: my_helper
INFO - 2024-10-15 10:24:07 --> Database Driver Class Initialized
INFO - 2024-10-15 10:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:24:07 --> Controller Class Initialized
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 10:24:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 10:24:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:24:09 --> Final output sent to browser
DEBUG - 2024-10-15 10:24:09 --> Total execution time: 2.7230
INFO - 2024-10-15 10:24:49 --> Config Class Initialized
INFO - 2024-10-15 10:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:24:49 --> Utf8 Class Initialized
INFO - 2024-10-15 10:24:49 --> URI Class Initialized
INFO - 2024-10-15 10:24:49 --> Router Class Initialized
INFO - 2024-10-15 10:24:49 --> Output Class Initialized
INFO - 2024-10-15 10:24:49 --> Security Class Initialized
DEBUG - 2024-10-15 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:24:49 --> Input Class Initialized
INFO - 2024-10-15 10:24:49 --> Language Class Initialized
INFO - 2024-10-15 10:24:49 --> Language Class Initialized
INFO - 2024-10-15 10:24:49 --> Config Class Initialized
INFO - 2024-10-15 10:24:49 --> Loader Class Initialized
INFO - 2024-10-15 10:24:49 --> Helper loaded: url_helper
INFO - 2024-10-15 10:24:49 --> Helper loaded: file_helper
INFO - 2024-10-15 10:24:49 --> Helper loaded: form_helper
INFO - 2024-10-15 10:24:49 --> Helper loaded: my_helper
INFO - 2024-10-15 10:24:49 --> Database Driver Class Initialized
INFO - 2024-10-15 10:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:24:49 --> Controller Class Initialized
DEBUG - 2024-10-15 10:24:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:24:53 --> Final output sent to browser
DEBUG - 2024-10-15 10:24:53 --> Total execution time: 3.1584
INFO - 2024-10-15 10:39:35 --> Config Class Initialized
INFO - 2024-10-15 10:39:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:39:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:39:35 --> Utf8 Class Initialized
INFO - 2024-10-15 10:39:35 --> URI Class Initialized
INFO - 2024-10-15 10:39:35 --> Router Class Initialized
INFO - 2024-10-15 10:39:35 --> Output Class Initialized
INFO - 2024-10-15 10:39:35 --> Security Class Initialized
DEBUG - 2024-10-15 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:39:35 --> Input Class Initialized
INFO - 2024-10-15 10:39:35 --> Language Class Initialized
INFO - 2024-10-15 10:39:35 --> Language Class Initialized
INFO - 2024-10-15 10:39:35 --> Config Class Initialized
INFO - 2024-10-15 10:39:35 --> Loader Class Initialized
INFO - 2024-10-15 10:39:35 --> Helper loaded: url_helper
INFO - 2024-10-15 10:39:35 --> Helper loaded: file_helper
INFO - 2024-10-15 10:39:35 --> Helper loaded: form_helper
INFO - 2024-10-15 10:39:35 --> Helper loaded: my_helper
INFO - 2024-10-15 10:39:35 --> Database Driver Class Initialized
INFO - 2024-10-15 10:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:39:35 --> Controller Class Initialized
INFO - 2024-10-15 10:39:36 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:39:36 --> Final output sent to browser
DEBUG - 2024-10-15 10:39:36 --> Total execution time: 0.8306
INFO - 2024-10-15 10:39:36 --> Config Class Initialized
INFO - 2024-10-15 10:39:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:39:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:39:36 --> Utf8 Class Initialized
INFO - 2024-10-15 10:39:36 --> URI Class Initialized
INFO - 2024-10-15 10:39:36 --> Router Class Initialized
INFO - 2024-10-15 10:39:36 --> Output Class Initialized
INFO - 2024-10-15 10:39:36 --> Security Class Initialized
DEBUG - 2024-10-15 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:39:36 --> Input Class Initialized
INFO - 2024-10-15 10:39:36 --> Language Class Initialized
INFO - 2024-10-15 10:39:36 --> Language Class Initialized
INFO - 2024-10-15 10:39:36 --> Config Class Initialized
INFO - 2024-10-15 10:39:36 --> Loader Class Initialized
INFO - 2024-10-15 10:39:36 --> Helper loaded: url_helper
INFO - 2024-10-15 10:39:36 --> Helper loaded: file_helper
INFO - 2024-10-15 10:39:36 --> Helper loaded: form_helper
INFO - 2024-10-15 10:39:36 --> Helper loaded: my_helper
INFO - 2024-10-15 10:39:36 --> Database Driver Class Initialized
INFO - 2024-10-15 10:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:39:36 --> Controller Class Initialized
INFO - 2024-10-15 10:39:36 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:39:36 --> Config Class Initialized
INFO - 2024-10-15 10:39:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:39:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:39:36 --> Utf8 Class Initialized
INFO - 2024-10-15 10:39:36 --> URI Class Initialized
INFO - 2024-10-15 10:39:36 --> Router Class Initialized
INFO - 2024-10-15 10:39:36 --> Output Class Initialized
INFO - 2024-10-15 10:39:36 --> Security Class Initialized
DEBUG - 2024-10-15 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:39:36 --> Input Class Initialized
INFO - 2024-10-15 10:39:36 --> Language Class Initialized
INFO - 2024-10-15 10:39:37 --> Language Class Initialized
INFO - 2024-10-15 10:39:37 --> Config Class Initialized
INFO - 2024-10-15 10:39:37 --> Loader Class Initialized
INFO - 2024-10-15 10:39:37 --> Helper loaded: url_helper
INFO - 2024-10-15 10:39:37 --> Helper loaded: file_helper
INFO - 2024-10-15 10:39:37 --> Helper loaded: form_helper
INFO - 2024-10-15 10:39:37 --> Helper loaded: my_helper
INFO - 2024-10-15 10:39:37 --> Database Driver Class Initialized
INFO - 2024-10-15 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:39:37 --> Controller Class Initialized
DEBUG - 2024-10-15 10:39:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:39:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:39:37 --> Final output sent to browser
DEBUG - 2024-10-15 10:39:37 --> Total execution time: 0.5213
INFO - 2024-10-15 10:41:12 --> Config Class Initialized
INFO - 2024-10-15 10:41:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:41:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:41:12 --> Utf8 Class Initialized
INFO - 2024-10-15 10:41:12 --> URI Class Initialized
INFO - 2024-10-15 10:41:12 --> Router Class Initialized
INFO - 2024-10-15 10:41:12 --> Output Class Initialized
INFO - 2024-10-15 10:41:12 --> Security Class Initialized
DEBUG - 2024-10-15 10:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:41:12 --> Input Class Initialized
INFO - 2024-10-15 10:41:12 --> Language Class Initialized
INFO - 2024-10-15 10:41:12 --> Language Class Initialized
INFO - 2024-10-15 10:41:12 --> Config Class Initialized
INFO - 2024-10-15 10:41:12 --> Loader Class Initialized
INFO - 2024-10-15 10:41:12 --> Helper loaded: url_helper
INFO - 2024-10-15 10:41:12 --> Helper loaded: file_helper
INFO - 2024-10-15 10:41:12 --> Helper loaded: form_helper
INFO - 2024-10-15 10:41:12 --> Helper loaded: my_helper
INFO - 2024-10-15 10:41:12 --> Database Driver Class Initialized
INFO - 2024-10-15 10:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:41:12 --> Controller Class Initialized
INFO - 2024-10-15 10:41:12 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:41:12 --> Final output sent to browser
DEBUG - 2024-10-15 10:41:12 --> Total execution time: 0.1791
INFO - 2024-10-15 10:41:13 --> Config Class Initialized
INFO - 2024-10-15 10:41:13 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:41:13 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:41:13 --> Utf8 Class Initialized
INFO - 2024-10-15 10:41:13 --> URI Class Initialized
INFO - 2024-10-15 10:41:13 --> Router Class Initialized
INFO - 2024-10-15 10:41:13 --> Output Class Initialized
INFO - 2024-10-15 10:41:13 --> Security Class Initialized
DEBUG - 2024-10-15 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:41:13 --> Input Class Initialized
INFO - 2024-10-15 10:41:13 --> Language Class Initialized
INFO - 2024-10-15 10:41:13 --> Language Class Initialized
INFO - 2024-10-15 10:41:13 --> Config Class Initialized
INFO - 2024-10-15 10:41:13 --> Loader Class Initialized
INFO - 2024-10-15 10:41:13 --> Helper loaded: url_helper
INFO - 2024-10-15 10:41:13 --> Helper loaded: file_helper
INFO - 2024-10-15 10:41:13 --> Helper loaded: form_helper
INFO - 2024-10-15 10:41:13 --> Helper loaded: my_helper
INFO - 2024-10-15 10:41:13 --> Database Driver Class Initialized
INFO - 2024-10-15 10:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:41:13 --> Controller Class Initialized
INFO - 2024-10-15 10:41:13 --> Helper loaded: cookie_helper
INFO - 2024-10-15 10:41:13 --> Config Class Initialized
INFO - 2024-10-15 10:41:13 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:41:13 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:41:13 --> Utf8 Class Initialized
INFO - 2024-10-15 10:41:13 --> URI Class Initialized
INFO - 2024-10-15 10:41:13 --> Router Class Initialized
INFO - 2024-10-15 10:41:13 --> Output Class Initialized
INFO - 2024-10-15 10:41:13 --> Security Class Initialized
DEBUG - 2024-10-15 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:41:13 --> Input Class Initialized
INFO - 2024-10-15 10:41:13 --> Language Class Initialized
INFO - 2024-10-15 10:41:13 --> Language Class Initialized
INFO - 2024-10-15 10:41:13 --> Config Class Initialized
INFO - 2024-10-15 10:41:13 --> Loader Class Initialized
INFO - 2024-10-15 10:41:13 --> Helper loaded: url_helper
INFO - 2024-10-15 10:41:13 --> Helper loaded: file_helper
INFO - 2024-10-15 10:41:13 --> Helper loaded: form_helper
INFO - 2024-10-15 10:41:13 --> Helper loaded: my_helper
INFO - 2024-10-15 10:41:13 --> Database Driver Class Initialized
INFO - 2024-10-15 10:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:41:13 --> Controller Class Initialized
DEBUG - 2024-10-15 10:41:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 10:41:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 10:41:13 --> Final output sent to browser
DEBUG - 2024-10-15 10:41:13 --> Total execution time: 0.1214
INFO - 2024-10-15 10:41:20 --> Config Class Initialized
INFO - 2024-10-15 10:41:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:41:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:41:20 --> Utf8 Class Initialized
INFO - 2024-10-15 10:41:20 --> URI Class Initialized
INFO - 2024-10-15 10:41:20 --> Router Class Initialized
INFO - 2024-10-15 10:41:20 --> Output Class Initialized
INFO - 2024-10-15 10:41:20 --> Security Class Initialized
DEBUG - 2024-10-15 10:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:41:20 --> Input Class Initialized
INFO - 2024-10-15 10:41:20 --> Language Class Initialized
INFO - 2024-10-15 10:41:20 --> Language Class Initialized
INFO - 2024-10-15 10:41:20 --> Config Class Initialized
INFO - 2024-10-15 10:41:20 --> Loader Class Initialized
INFO - 2024-10-15 10:41:20 --> Helper loaded: url_helper
INFO - 2024-10-15 10:41:20 --> Helper loaded: file_helper
INFO - 2024-10-15 10:41:20 --> Helper loaded: form_helper
INFO - 2024-10-15 10:41:20 --> Helper loaded: my_helper
INFO - 2024-10-15 10:41:20 --> Database Driver Class Initialized
INFO - 2024-10-15 10:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:41:20 --> Controller Class Initialized
DEBUG - 2024-10-15 10:41:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:41:26 --> Final output sent to browser
DEBUG - 2024-10-15 10:41:26 --> Total execution time: 5.5179
INFO - 2024-10-15 10:55:22 --> Config Class Initialized
INFO - 2024-10-15 10:55:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:55:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:55:22 --> Utf8 Class Initialized
INFO - 2024-10-15 10:55:22 --> URI Class Initialized
INFO - 2024-10-15 10:55:22 --> Router Class Initialized
INFO - 2024-10-15 10:55:22 --> Output Class Initialized
INFO - 2024-10-15 10:55:22 --> Security Class Initialized
DEBUG - 2024-10-15 10:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:55:22 --> Input Class Initialized
INFO - 2024-10-15 10:55:22 --> Language Class Initialized
INFO - 2024-10-15 10:55:22 --> Language Class Initialized
INFO - 2024-10-15 10:55:22 --> Config Class Initialized
INFO - 2024-10-15 10:55:22 --> Loader Class Initialized
INFO - 2024-10-15 10:55:22 --> Helper loaded: url_helper
INFO - 2024-10-15 10:55:22 --> Helper loaded: file_helper
INFO - 2024-10-15 10:55:22 --> Helper loaded: form_helper
INFO - 2024-10-15 10:55:22 --> Helper loaded: my_helper
INFO - 2024-10-15 10:55:22 --> Database Driver Class Initialized
INFO - 2024-10-15 10:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:55:22 --> Controller Class Initialized
DEBUG - 2024-10-15 10:55:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 10:55:27 --> Final output sent to browser
DEBUG - 2024-10-15 10:55:27 --> Total execution time: 5.1584
INFO - 2024-10-15 11:05:55 --> Config Class Initialized
INFO - 2024-10-15 11:05:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:05:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:05:55 --> Utf8 Class Initialized
INFO - 2024-10-15 11:05:55 --> URI Class Initialized
INFO - 2024-10-15 11:05:55 --> Router Class Initialized
INFO - 2024-10-15 11:05:55 --> Output Class Initialized
INFO - 2024-10-15 11:05:55 --> Security Class Initialized
DEBUG - 2024-10-15 11:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:05:55 --> Input Class Initialized
INFO - 2024-10-15 11:05:55 --> Language Class Initialized
INFO - 2024-10-15 11:05:55 --> Language Class Initialized
INFO - 2024-10-15 11:05:55 --> Config Class Initialized
INFO - 2024-10-15 11:05:55 --> Loader Class Initialized
INFO - 2024-10-15 11:05:55 --> Helper loaded: url_helper
INFO - 2024-10-15 11:05:55 --> Helper loaded: file_helper
INFO - 2024-10-15 11:05:55 --> Helper loaded: form_helper
INFO - 2024-10-15 11:05:55 --> Helper loaded: my_helper
INFO - 2024-10-15 11:05:55 --> Database Driver Class Initialized
INFO - 2024-10-15 11:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:05:55 --> Controller Class Initialized
INFO - 2024-10-15 11:05:55 --> Helper loaded: cookie_helper
INFO - 2024-10-15 11:05:55 --> Final output sent to browser
DEBUG - 2024-10-15 11:05:55 --> Total execution time: 0.0688
INFO - 2024-10-15 11:05:56 --> Config Class Initialized
INFO - 2024-10-15 11:05:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:05:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:05:56 --> Utf8 Class Initialized
INFO - 2024-10-15 11:05:56 --> URI Class Initialized
INFO - 2024-10-15 11:05:56 --> Router Class Initialized
INFO - 2024-10-15 11:05:56 --> Output Class Initialized
INFO - 2024-10-15 11:05:56 --> Security Class Initialized
DEBUG - 2024-10-15 11:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:05:56 --> Input Class Initialized
INFO - 2024-10-15 11:05:56 --> Language Class Initialized
INFO - 2024-10-15 11:05:56 --> Language Class Initialized
INFO - 2024-10-15 11:05:56 --> Config Class Initialized
INFO - 2024-10-15 11:05:56 --> Loader Class Initialized
INFO - 2024-10-15 11:05:56 --> Helper loaded: url_helper
INFO - 2024-10-15 11:05:56 --> Helper loaded: file_helper
INFO - 2024-10-15 11:05:56 --> Helper loaded: form_helper
INFO - 2024-10-15 11:05:56 --> Helper loaded: my_helper
INFO - 2024-10-15 11:05:56 --> Database Driver Class Initialized
INFO - 2024-10-15 11:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:05:56 --> Controller Class Initialized
INFO - 2024-10-15 11:05:56 --> Helper loaded: cookie_helper
INFO - 2024-10-15 11:05:56 --> Config Class Initialized
INFO - 2024-10-15 11:05:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:05:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:05:56 --> Utf8 Class Initialized
INFO - 2024-10-15 11:05:56 --> URI Class Initialized
INFO - 2024-10-15 11:05:56 --> Router Class Initialized
INFO - 2024-10-15 11:05:56 --> Output Class Initialized
INFO - 2024-10-15 11:05:56 --> Security Class Initialized
DEBUG - 2024-10-15 11:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:05:56 --> Input Class Initialized
INFO - 2024-10-15 11:05:56 --> Language Class Initialized
INFO - 2024-10-15 11:05:56 --> Language Class Initialized
INFO - 2024-10-15 11:05:56 --> Config Class Initialized
INFO - 2024-10-15 11:05:56 --> Loader Class Initialized
INFO - 2024-10-15 11:05:56 --> Helper loaded: url_helper
INFO - 2024-10-15 11:05:56 --> Helper loaded: file_helper
INFO - 2024-10-15 11:05:56 --> Helper loaded: form_helper
INFO - 2024-10-15 11:05:56 --> Helper loaded: my_helper
INFO - 2024-10-15 11:05:56 --> Database Driver Class Initialized
INFO - 2024-10-15 11:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:05:56 --> Controller Class Initialized
DEBUG - 2024-10-15 11:05:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 11:05:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:05:56 --> Final output sent to browser
DEBUG - 2024-10-15 11:05:56 --> Total execution time: 0.0409
INFO - 2024-10-15 11:06:24 --> Config Class Initialized
INFO - 2024-10-15 11:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:24 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:24 --> URI Class Initialized
INFO - 2024-10-15 11:06:24 --> Router Class Initialized
INFO - 2024-10-15 11:06:24 --> Output Class Initialized
INFO - 2024-10-15 11:06:24 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:24 --> Input Class Initialized
INFO - 2024-10-15 11:06:24 --> Language Class Initialized
INFO - 2024-10-15 11:06:24 --> Language Class Initialized
INFO - 2024-10-15 11:06:24 --> Config Class Initialized
INFO - 2024-10-15 11:06:24 --> Loader Class Initialized
INFO - 2024-10-15 11:06:24 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:24 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:24 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:24 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:24 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:24 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:27 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:27 --> Total execution time: 3.2805
INFO - 2024-10-15 11:06:28 --> Config Class Initialized
INFO - 2024-10-15 11:06:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:28 --> URI Class Initialized
INFO - 2024-10-15 11:06:28 --> Router Class Initialized
INFO - 2024-10-15 11:06:28 --> Output Class Initialized
INFO - 2024-10-15 11:06:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:28 --> Input Class Initialized
INFO - 2024-10-15 11:06:28 --> Language Class Initialized
INFO - 2024-10-15 11:06:28 --> Language Class Initialized
INFO - 2024-10-15 11:06:28 --> Config Class Initialized
INFO - 2024-10-15 11:06:28 --> Loader Class Initialized
INFO - 2024-10-15 11:06:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:28 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:31 --> Total execution time: 3.5907
INFO - 2024-10-15 11:06:32 --> Config Class Initialized
INFO - 2024-10-15 11:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:32 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:32 --> URI Class Initialized
INFO - 2024-10-15 11:06:32 --> Router Class Initialized
INFO - 2024-10-15 11:06:32 --> Output Class Initialized
INFO - 2024-10-15 11:06:32 --> Security Class Initialized
INFO - 2024-10-15 11:06:32 --> Config Class Initialized
INFO - 2024-10-15 11:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:32 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:32 --> URI Class Initialized
INFO - 2024-10-15 11:06:32 --> Router Class Initialized
INFO - 2024-10-15 11:06:32 --> Output Class Initialized
INFO - 2024-10-15 11:06:32 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:32 --> Input Class Initialized
INFO - 2024-10-15 11:06:32 --> Language Class Initialized
DEBUG - 2024-10-15 11:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:32 --> Input Class Initialized
INFO - 2024-10-15 11:06:32 --> Language Class Initialized
INFO - 2024-10-15 11:06:32 --> Language Class Initialized
INFO - 2024-10-15 11:06:32 --> Config Class Initialized
INFO - 2024-10-15 11:06:32 --> Loader Class Initialized
INFO - 2024-10-15 11:06:32 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:32 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:32 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:32 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:32 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:32 --> Language Class Initialized
INFO - 2024-10-15 11:06:32 --> Config Class Initialized
INFO - 2024-10-15 11:06:32 --> Loader Class Initialized
INFO - 2024-10-15 11:06:32 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:32 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:32 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:32 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:32 --> Controller Class Initialized
INFO - 2024-10-15 11:06:32 --> Database Driver Class Initialized
DEBUG - 2024-10-15 11:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:35 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:35 --> Total execution time: 3.6758
INFO - 2024-10-15 11:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:35 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:36 --> Config Class Initialized
INFO - 2024-10-15 11:06:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:36 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:36 --> URI Class Initialized
INFO - 2024-10-15 11:06:36 --> Router Class Initialized
INFO - 2024-10-15 11:06:36 --> Output Class Initialized
INFO - 2024-10-15 11:06:36 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:36 --> Input Class Initialized
INFO - 2024-10-15 11:06:36 --> Language Class Initialized
INFO - 2024-10-15 11:06:36 --> Language Class Initialized
INFO - 2024-10-15 11:06:36 --> Config Class Initialized
INFO - 2024-10-15 11:06:36 --> Loader Class Initialized
INFO - 2024-10-15 11:06:36 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:36 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:36 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:36 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:36 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:39 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:39 --> Total execution time: 6.9037
INFO - 2024-10-15 11:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:39 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:42 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:42 --> Total execution time: 5.7815
INFO - 2024-10-15 11:06:42 --> Config Class Initialized
INFO - 2024-10-15 11:06:42 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:42 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:42 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:42 --> URI Class Initialized
INFO - 2024-10-15 11:06:42 --> Router Class Initialized
INFO - 2024-10-15 11:06:42 --> Output Class Initialized
INFO - 2024-10-15 11:06:42 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:42 --> Input Class Initialized
INFO - 2024-10-15 11:06:42 --> Language Class Initialized
INFO - 2024-10-15 11:06:42 --> Language Class Initialized
INFO - 2024-10-15 11:06:42 --> Config Class Initialized
INFO - 2024-10-15 11:06:42 --> Loader Class Initialized
INFO - 2024-10-15 11:06:42 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:42 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:42 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:42 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:42 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:42 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:44 --> Config Class Initialized
INFO - 2024-10-15 11:06:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:44 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:44 --> URI Class Initialized
INFO - 2024-10-15 11:06:44 --> Router Class Initialized
INFO - 2024-10-15 11:06:44 --> Output Class Initialized
INFO - 2024-10-15 11:06:44 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:44 --> Input Class Initialized
INFO - 2024-10-15 11:06:44 --> Language Class Initialized
INFO - 2024-10-15 11:06:44 --> Language Class Initialized
INFO - 2024-10-15 11:06:44 --> Config Class Initialized
INFO - 2024-10-15 11:06:44 --> Loader Class Initialized
INFO - 2024-10-15 11:06:44 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:44 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:44 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:44 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:44 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:45 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:45 --> Total execution time: 2.9963
INFO - 2024-10-15 11:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:45 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:45 --> Config Class Initialized
INFO - 2024-10-15 11:06:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:45 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:45 --> URI Class Initialized
INFO - 2024-10-15 11:06:45 --> Router Class Initialized
INFO - 2024-10-15 11:06:45 --> Output Class Initialized
INFO - 2024-10-15 11:06:45 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:45 --> Input Class Initialized
INFO - 2024-10-15 11:06:45 --> Language Class Initialized
INFO - 2024-10-15 11:06:45 --> Language Class Initialized
INFO - 2024-10-15 11:06:45 --> Config Class Initialized
INFO - 2024-10-15 11:06:45 --> Loader Class Initialized
INFO - 2024-10-15 11:06:45 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:45 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:45 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:45 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:45 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:45 --> Config Class Initialized
INFO - 2024-10-15 11:06:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:45 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:45 --> URI Class Initialized
INFO - 2024-10-15 11:06:45 --> Router Class Initialized
INFO - 2024-10-15 11:06:45 --> Output Class Initialized
INFO - 2024-10-15 11:06:45 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:45 --> Input Class Initialized
INFO - 2024-10-15 11:06:45 --> Language Class Initialized
INFO - 2024-10-15 11:06:45 --> Language Class Initialized
INFO - 2024-10-15 11:06:45 --> Config Class Initialized
INFO - 2024-10-15 11:06:45 --> Loader Class Initialized
INFO - 2024-10-15 11:06:45 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:45 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:45 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:45 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:45 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:48 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:48 --> Total execution time: 3.6300
INFO - 2024-10-15 11:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:48 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:51 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:51 --> Total execution time: 6.3930
INFO - 2024-10-15 11:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:51 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:51 --> Config Class Initialized
INFO - 2024-10-15 11:06:51 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:51 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:51 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:51 --> URI Class Initialized
INFO - 2024-10-15 11:06:51 --> Router Class Initialized
INFO - 2024-10-15 11:06:51 --> Output Class Initialized
INFO - 2024-10-15 11:06:51 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:51 --> Input Class Initialized
INFO - 2024-10-15 11:06:51 --> Language Class Initialized
INFO - 2024-10-15 11:06:51 --> Language Class Initialized
INFO - 2024-10-15 11:06:51 --> Config Class Initialized
INFO - 2024-10-15 11:06:51 --> Loader Class Initialized
INFO - 2024-10-15 11:06:51 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:51 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:51 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:51 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:51 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:55 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:55 --> Total execution time: 9.1968
INFO - 2024-10-15 11:06:55 --> Config Class Initialized
INFO - 2024-10-15 11:06:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:55 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:55 --> URI Class Initialized
INFO - 2024-10-15 11:06:55 --> Router Class Initialized
INFO - 2024-10-15 11:06:55 --> Output Class Initialized
INFO - 2024-10-15 11:06:55 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:55 --> Input Class Initialized
INFO - 2024-10-15 11:06:55 --> Language Class Initialized
INFO - 2024-10-15 11:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:55 --> Controller Class Initialized
DEBUG - 2024-10-15 11:06:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:06:55 --> Language Class Initialized
INFO - 2024-10-15 11:06:55 --> Config Class Initialized
INFO - 2024-10-15 11:06:55 --> Loader Class Initialized
INFO - 2024-10-15 11:06:55 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:55 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:55 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:55 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:55 --> Database Driver Class Initialized
INFO - 2024-10-15 11:06:58 --> Final output sent to browser
DEBUG - 2024-10-15 11:06:58 --> Total execution time: 6.4957
INFO - 2024-10-15 11:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:06:58 --> Controller Class Initialized
INFO - 2024-10-15 11:06:58 --> Config Class Initialized
INFO - 2024-10-15 11:06:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:06:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:06:58 --> Utf8 Class Initialized
INFO - 2024-10-15 11:06:58 --> URI Class Initialized
INFO - 2024-10-15 11:06:58 --> Router Class Initialized
INFO - 2024-10-15 11:06:58 --> Output Class Initialized
INFO - 2024-10-15 11:06:58 --> Security Class Initialized
DEBUG - 2024-10-15 11:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:06:58 --> Input Class Initialized
INFO - 2024-10-15 11:06:58 --> Language Class Initialized
INFO - 2024-10-15 11:06:58 --> Language Class Initialized
INFO - 2024-10-15 11:06:58 --> Config Class Initialized
INFO - 2024-10-15 11:06:58 --> Loader Class Initialized
INFO - 2024-10-15 11:06:58 --> Helper loaded: url_helper
INFO - 2024-10-15 11:06:58 --> Helper loaded: file_helper
INFO - 2024-10-15 11:06:58 --> Helper loaded: form_helper
INFO - 2024-10-15 11:06:58 --> Helper loaded: my_helper
INFO - 2024-10-15 11:06:58 --> Database Driver Class Initialized
DEBUG - 2024-10-15 11:06:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-10-15 11:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:02 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:07:05 --> Config Class Initialized
INFO - 2024-10-15 11:07:05 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:05 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:05 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:05 --> URI Class Initialized
INFO - 2024-10-15 11:07:05 --> Router Class Initialized
INFO - 2024-10-15 11:07:05 --> Output Class Initialized
INFO - 2024-10-15 11:07:05 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:05 --> Input Class Initialized
INFO - 2024-10-15 11:07:05 --> Language Class Initialized
INFO - 2024-10-15 11:07:05 --> Language Class Initialized
INFO - 2024-10-15 11:07:05 --> Config Class Initialized
INFO - 2024-10-15 11:07:05 --> Loader Class Initialized
INFO - 2024-10-15 11:07:05 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:05 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:05 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:05 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:05 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:06 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:06 --> Total execution time: 7.6555
INFO - 2024-10-15 11:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:06 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 11:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:07:06 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:06 --> Total execution time: 0.3971
INFO - 2024-10-15 11:07:11 --> Config Class Initialized
INFO - 2024-10-15 11:07:11 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:11 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:11 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:11 --> URI Class Initialized
DEBUG - 2024-10-15 11:07:11 --> No URI present. Default controller set.
INFO - 2024-10-15 11:07:11 --> Router Class Initialized
INFO - 2024-10-15 11:07:11 --> Output Class Initialized
INFO - 2024-10-15 11:07:11 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:11 --> Input Class Initialized
INFO - 2024-10-15 11:07:11 --> Language Class Initialized
INFO - 2024-10-15 11:07:11 --> Language Class Initialized
INFO - 2024-10-15 11:07:11 --> Config Class Initialized
INFO - 2024-10-15 11:07:11 --> Loader Class Initialized
INFO - 2024-10-15 11:07:11 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:11 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:11 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:11 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:11 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:11 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-15 11:07:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:07:11 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:11 --> Total execution time: 0.0309
INFO - 2024-10-15 11:07:16 --> Config Class Initialized
INFO - 2024-10-15 11:07:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:16 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:16 --> URI Class Initialized
DEBUG - 2024-10-15 11:07:16 --> No URI present. Default controller set.
INFO - 2024-10-15 11:07:16 --> Router Class Initialized
INFO - 2024-10-15 11:07:16 --> Output Class Initialized
INFO - 2024-10-15 11:07:16 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:16 --> Input Class Initialized
INFO - 2024-10-15 11:07:16 --> Language Class Initialized
INFO - 2024-10-15 11:07:16 --> Language Class Initialized
INFO - 2024-10-15 11:07:16 --> Config Class Initialized
INFO - 2024-10-15 11:07:16 --> Loader Class Initialized
INFO - 2024-10-15 11:07:16 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:16 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:16 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:16 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:16 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:16 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-15 11:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:07:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:16 --> Total execution time: 0.0300
INFO - 2024-10-15 11:07:18 --> Config Class Initialized
INFO - 2024-10-15 11:07:18 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:18 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:18 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:18 --> URI Class Initialized
DEBUG - 2024-10-15 11:07:18 --> No URI present. Default controller set.
INFO - 2024-10-15 11:07:18 --> Router Class Initialized
INFO - 2024-10-15 11:07:18 --> Output Class Initialized
INFO - 2024-10-15 11:07:18 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:18 --> Input Class Initialized
INFO - 2024-10-15 11:07:18 --> Language Class Initialized
INFO - 2024-10-15 11:07:18 --> Language Class Initialized
INFO - 2024-10-15 11:07:18 --> Config Class Initialized
INFO - 2024-10-15 11:07:18 --> Loader Class Initialized
INFO - 2024-10-15 11:07:18 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:18 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:18 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:18 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:18 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:18 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-15 11:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:07:18 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:18 --> Total execution time: 0.0360
INFO - 2024-10-15 11:07:23 --> Config Class Initialized
INFO - 2024-10-15 11:07:23 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:23 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:23 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:23 --> URI Class Initialized
DEBUG - 2024-10-15 11:07:23 --> No URI present. Default controller set.
INFO - 2024-10-15 11:07:23 --> Router Class Initialized
INFO - 2024-10-15 11:07:23 --> Output Class Initialized
INFO - 2024-10-15 11:07:23 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:23 --> Input Class Initialized
INFO - 2024-10-15 11:07:23 --> Language Class Initialized
INFO - 2024-10-15 11:07:23 --> Language Class Initialized
INFO - 2024-10-15 11:07:23 --> Config Class Initialized
INFO - 2024-10-15 11:07:23 --> Loader Class Initialized
INFO - 2024-10-15 11:07:23 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:23 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:23 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:23 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:23 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:23 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-15 11:07:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:07:23 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:23 --> Total execution time: 0.0636
INFO - 2024-10-15 11:07:26 --> Config Class Initialized
INFO - 2024-10-15 11:07:26 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:26 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:26 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:26 --> URI Class Initialized
INFO - 2024-10-15 11:07:26 --> Router Class Initialized
INFO - 2024-10-15 11:07:26 --> Output Class Initialized
INFO - 2024-10-15 11:07:26 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:26 --> Input Class Initialized
INFO - 2024-10-15 11:07:26 --> Language Class Initialized
INFO - 2024-10-15 11:07:26 --> Language Class Initialized
INFO - 2024-10-15 11:07:26 --> Config Class Initialized
INFO - 2024-10-15 11:07:26 --> Loader Class Initialized
INFO - 2024-10-15 11:07:26 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:26 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:26 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:26 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:26 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:26 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 11:07:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:07:26 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:26 --> Total execution time: 0.0348
INFO - 2024-10-15 11:07:28 --> Config Class Initialized
INFO - 2024-10-15 11:07:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:28 --> URI Class Initialized
INFO - 2024-10-15 11:07:28 --> Router Class Initialized
INFO - 2024-10-15 11:07:28 --> Output Class Initialized
INFO - 2024-10-15 11:07:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:28 --> Input Class Initialized
INFO - 2024-10-15 11:07:28 --> Language Class Initialized
INFO - 2024-10-15 11:07:28 --> Language Class Initialized
INFO - 2024-10-15 11:07:28 --> Config Class Initialized
INFO - 2024-10-15 11:07:28 --> Loader Class Initialized
INFO - 2024-10-15 11:07:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:28 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:07:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:31 --> Total execution time: 2.9742
INFO - 2024-10-15 11:07:31 --> Config Class Initialized
INFO - 2024-10-15 11:07:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:31 --> URI Class Initialized
INFO - 2024-10-15 11:07:31 --> Router Class Initialized
INFO - 2024-10-15 11:07:31 --> Output Class Initialized
INFO - 2024-10-15 11:07:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:31 --> Input Class Initialized
INFO - 2024-10-15 11:07:31 --> Language Class Initialized
INFO - 2024-10-15 11:07:31 --> Language Class Initialized
INFO - 2024-10-15 11:07:31 --> Config Class Initialized
INFO - 2024-10-15 11:07:31 --> Loader Class Initialized
INFO - 2024-10-15 11:07:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:31 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:07:34 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:34 --> Total execution time: 3.0497
INFO - 2024-10-15 11:07:34 --> Config Class Initialized
INFO - 2024-10-15 11:07:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:34 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:34 --> URI Class Initialized
INFO - 2024-10-15 11:07:34 --> Router Class Initialized
INFO - 2024-10-15 11:07:34 --> Output Class Initialized
INFO - 2024-10-15 11:07:34 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:34 --> Input Class Initialized
INFO - 2024-10-15 11:07:34 --> Language Class Initialized
INFO - 2024-10-15 11:07:34 --> Language Class Initialized
INFO - 2024-10-15 11:07:34 --> Config Class Initialized
INFO - 2024-10-15 11:07:34 --> Loader Class Initialized
INFO - 2024-10-15 11:07:34 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:34 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:34 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:34 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:34 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:34 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:07:38 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:38 --> Total execution time: 3.4741
INFO - 2024-10-15 11:07:38 --> Config Class Initialized
INFO - 2024-10-15 11:07:38 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:38 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:38 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:38 --> URI Class Initialized
INFO - 2024-10-15 11:07:38 --> Router Class Initialized
INFO - 2024-10-15 11:07:38 --> Output Class Initialized
INFO - 2024-10-15 11:07:38 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:38 --> Input Class Initialized
INFO - 2024-10-15 11:07:38 --> Language Class Initialized
INFO - 2024-10-15 11:07:38 --> Language Class Initialized
INFO - 2024-10-15 11:07:38 --> Config Class Initialized
INFO - 2024-10-15 11:07:38 --> Loader Class Initialized
INFO - 2024-10-15 11:07:38 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:38 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:38 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:38 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:38 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:38 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:07:40 --> Config Class Initialized
INFO - 2024-10-15 11:07:40 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:40 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:40 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:40 --> URI Class Initialized
INFO - 2024-10-15 11:07:40 --> Router Class Initialized
INFO - 2024-10-15 11:07:40 --> Output Class Initialized
INFO - 2024-10-15 11:07:40 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:40 --> Input Class Initialized
INFO - 2024-10-15 11:07:40 --> Language Class Initialized
INFO - 2024-10-15 11:07:40 --> Language Class Initialized
INFO - 2024-10-15 11:07:40 --> Config Class Initialized
INFO - 2024-10-15 11:07:40 --> Loader Class Initialized
INFO - 2024-10-15 11:07:40 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:40 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:40 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:40 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:40 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:41 --> Config Class Initialized
INFO - 2024-10-15 11:07:41 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:41 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:41 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:41 --> URI Class Initialized
INFO - 2024-10-15 11:07:41 --> Router Class Initialized
INFO - 2024-10-15 11:07:41 --> Output Class Initialized
INFO - 2024-10-15 11:07:41 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:41 --> Input Class Initialized
INFO - 2024-10-15 11:07:41 --> Language Class Initialized
INFO - 2024-10-15 11:07:41 --> Language Class Initialized
INFO - 2024-10-15 11:07:41 --> Config Class Initialized
INFO - 2024-10-15 11:07:41 --> Loader Class Initialized
INFO - 2024-10-15 11:07:41 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:41 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:41 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:41 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:41 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:41 --> Config Class Initialized
INFO - 2024-10-15 11:07:41 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:07:41 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:41 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:41 --> URI Class Initialized
INFO - 2024-10-15 11:07:41 --> Router Class Initialized
INFO - 2024-10-15 11:07:41 --> Output Class Initialized
INFO - 2024-10-15 11:07:41 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:41 --> Input Class Initialized
INFO - 2024-10-15 11:07:41 --> Language Class Initialized
INFO - 2024-10-15 11:07:41 --> Language Class Initialized
INFO - 2024-10-15 11:07:41 --> Config Class Initialized
INFO - 2024-10-15 11:07:41 --> Loader Class Initialized
INFO - 2024-10-15 11:07:41 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:41 --> Helper loaded: file_helper
INFO - 2024-10-15 11:07:41 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:41 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:41 --> Database Driver Class Initialized
INFO - 2024-10-15 11:07:42 --> Final output sent to browser
DEBUG - 2024-10-15 11:07:42 --> Total execution time: 3.7736
INFO - 2024-10-15 11:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:42 --> Controller Class Initialized
DEBUG - 2024-10-15 11:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-10-15 11:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:46 --> Controller Class Initialized
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 230
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 231
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-10-15 11:07:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-10-15 11:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-10-15 11:07:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-10-15 11:07:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-10-15 11:07:52 --> Config Class Initialized
INFO - 2024-10-15 11:07:52 --> Hooks Class Initialized
INFO - 2024-10-15 11:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:07:52 --> Controller Class Initialized
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
DEBUG - 2024-10-15 11:07:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:07:52 --> Utf8 Class Initialized
INFO - 2024-10-15 11:07:52 --> URI Class Initialized
INFO - 2024-10-15 11:07:52 --> Router Class Initialized
INFO - 2024-10-15 11:07:52 --> Output Class Initialized
INFO - 2024-10-15 11:07:52 --> Security Class Initialized
DEBUG - 2024-10-15 11:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:07:52 --> Input Class Initialized
INFO - 2024-10-15 11:07:52 --> Language Class Initialized
INFO - 2024-10-15 11:07:52 --> Language Class Initialized
INFO - 2024-10-15 11:07:52 --> Config Class Initialized
INFO - 2024-10-15 11:07:52 --> Loader Class Initialized
INFO - 2024-10-15 11:07:52 --> Helper loaded: url_helper
INFO - 2024-10-15 11:07:52 --> Helper loaded: file_helper
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
INFO - 2024-10-15 11:07:52 --> Helper loaded: form_helper
INFO - 2024-10-15 11:07:52 --> Helper loaded: my_helper
INFO - 2024-10-15 11:07:52 --> Database Driver Class Initialized
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-10-15 11:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-10-15 11:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-10-15 11:11:33 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 36864 bytes) /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/include/tcpdf_static.php 2491
INFO - 2024-10-15 11:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:33 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:36 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:36 --> Total execution time: 224.0167
INFO - 2024-10-15 11:11:36 --> Config Class Initialized
INFO - 2024-10-15 11:11:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:36 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:36 --> URI Class Initialized
INFO - 2024-10-15 11:11:36 --> Router Class Initialized
INFO - 2024-10-15 11:11:36 --> Output Class Initialized
INFO - 2024-10-15 11:11:36 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:36 --> Input Class Initialized
INFO - 2024-10-15 11:11:36 --> Language Class Initialized
INFO - 2024-10-15 11:11:36 --> Language Class Initialized
INFO - 2024-10-15 11:11:36 --> Config Class Initialized
INFO - 2024-10-15 11:11:36 --> Loader Class Initialized
INFO - 2024-10-15 11:11:36 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:36 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:36 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:36 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:36 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:36 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:39 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:39 --> Total execution time: 2.7277
INFO - 2024-10-15 11:11:39 --> Config Class Initialized
INFO - 2024-10-15 11:11:39 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:39 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:39 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:39 --> URI Class Initialized
INFO - 2024-10-15 11:11:39 --> Router Class Initialized
INFO - 2024-10-15 11:11:39 --> Output Class Initialized
INFO - 2024-10-15 11:11:39 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:39 --> Input Class Initialized
INFO - 2024-10-15 11:11:39 --> Language Class Initialized
INFO - 2024-10-15 11:11:39 --> Language Class Initialized
INFO - 2024-10-15 11:11:39 --> Config Class Initialized
INFO - 2024-10-15 11:11:39 --> Loader Class Initialized
INFO - 2024-10-15 11:11:39 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:39 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:39 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:39 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:39 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:39 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:42 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:42 --> Total execution time: 2.9596
INFO - 2024-10-15 11:11:42 --> Config Class Initialized
INFO - 2024-10-15 11:11:42 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:42 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:42 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:42 --> URI Class Initialized
INFO - 2024-10-15 11:11:42 --> Router Class Initialized
INFO - 2024-10-15 11:11:42 --> Output Class Initialized
INFO - 2024-10-15 11:11:42 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:42 --> Input Class Initialized
INFO - 2024-10-15 11:11:42 --> Language Class Initialized
INFO - 2024-10-15 11:11:42 --> Language Class Initialized
INFO - 2024-10-15 11:11:42 --> Config Class Initialized
INFO - 2024-10-15 11:11:42 --> Loader Class Initialized
INFO - 2024-10-15 11:11:42 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:42 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:42 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:42 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:42 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:42 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:45 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:45 --> Total execution time: 2.8849
INFO - 2024-10-15 11:11:45 --> Config Class Initialized
INFO - 2024-10-15 11:11:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:45 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:45 --> URI Class Initialized
INFO - 2024-10-15 11:11:45 --> Router Class Initialized
INFO - 2024-10-15 11:11:45 --> Output Class Initialized
INFO - 2024-10-15 11:11:45 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:45 --> Input Class Initialized
INFO - 2024-10-15 11:11:45 --> Language Class Initialized
INFO - 2024-10-15 11:11:45 --> Language Class Initialized
INFO - 2024-10-15 11:11:45 --> Config Class Initialized
INFO - 2024-10-15 11:11:45 --> Loader Class Initialized
INFO - 2024-10-15 11:11:45 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:45 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:45 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:45 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:45 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:45 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:48 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:48 --> Total execution time: 3.2005
INFO - 2024-10-15 11:11:48 --> Config Class Initialized
INFO - 2024-10-15 11:11:48 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:48 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:48 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:48 --> URI Class Initialized
INFO - 2024-10-15 11:11:48 --> Router Class Initialized
INFO - 2024-10-15 11:11:48 --> Output Class Initialized
INFO - 2024-10-15 11:11:48 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:48 --> Input Class Initialized
INFO - 2024-10-15 11:11:48 --> Language Class Initialized
INFO - 2024-10-15 11:11:48 --> Language Class Initialized
INFO - 2024-10-15 11:11:48 --> Config Class Initialized
INFO - 2024-10-15 11:11:48 --> Loader Class Initialized
INFO - 2024-10-15 11:11:48 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:48 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:48 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:48 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:48 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:49 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:52 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:52 --> Total execution time: 3.2548
INFO - 2024-10-15 11:11:52 --> Config Class Initialized
INFO - 2024-10-15 11:11:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:52 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:52 --> URI Class Initialized
INFO - 2024-10-15 11:11:52 --> Router Class Initialized
INFO - 2024-10-15 11:11:52 --> Output Class Initialized
INFO - 2024-10-15 11:11:52 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:52 --> Input Class Initialized
INFO - 2024-10-15 11:11:52 --> Language Class Initialized
INFO - 2024-10-15 11:11:52 --> Language Class Initialized
INFO - 2024-10-15 11:11:52 --> Config Class Initialized
INFO - 2024-10-15 11:11:52 --> Loader Class Initialized
INFO - 2024-10-15 11:11:52 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:52 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:52 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:52 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:52 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:52 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:55 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:55 --> Total execution time: 2.6507
INFO - 2024-10-15 11:11:55 --> Config Class Initialized
INFO - 2024-10-15 11:11:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:55 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:55 --> URI Class Initialized
INFO - 2024-10-15 11:11:55 --> Router Class Initialized
INFO - 2024-10-15 11:11:55 --> Output Class Initialized
INFO - 2024-10-15 11:11:55 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:55 --> Input Class Initialized
INFO - 2024-10-15 11:11:55 --> Language Class Initialized
INFO - 2024-10-15 11:11:55 --> Language Class Initialized
INFO - 2024-10-15 11:11:55 --> Config Class Initialized
INFO - 2024-10-15 11:11:55 --> Loader Class Initialized
INFO - 2024-10-15 11:11:55 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:55 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:55 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:55 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:55 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:55 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:11:58 --> Final output sent to browser
DEBUG - 2024-10-15 11:11:58 --> Total execution time: 2.7313
INFO - 2024-10-15 11:11:58 --> Config Class Initialized
INFO - 2024-10-15 11:11:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:11:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:11:58 --> Utf8 Class Initialized
INFO - 2024-10-15 11:11:58 --> URI Class Initialized
INFO - 2024-10-15 11:11:58 --> Router Class Initialized
INFO - 2024-10-15 11:11:58 --> Output Class Initialized
INFO - 2024-10-15 11:11:58 --> Security Class Initialized
DEBUG - 2024-10-15 11:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:11:58 --> Input Class Initialized
INFO - 2024-10-15 11:11:58 --> Language Class Initialized
INFO - 2024-10-15 11:11:58 --> Language Class Initialized
INFO - 2024-10-15 11:11:58 --> Config Class Initialized
INFO - 2024-10-15 11:11:58 --> Loader Class Initialized
INFO - 2024-10-15 11:11:58 --> Helper loaded: url_helper
INFO - 2024-10-15 11:11:58 --> Helper loaded: file_helper
INFO - 2024-10-15 11:11:58 --> Helper loaded: form_helper
INFO - 2024-10-15 11:11:58 --> Helper loaded: my_helper
INFO - 2024-10-15 11:11:58 --> Database Driver Class Initialized
INFO - 2024-10-15 11:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:11:58 --> Controller Class Initialized
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:11:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:11:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:01 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:01 --> Total execution time: 2.7985
INFO - 2024-10-15 11:12:01 --> Config Class Initialized
INFO - 2024-10-15 11:12:01 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:01 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:01 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:01 --> URI Class Initialized
INFO - 2024-10-15 11:12:01 --> Router Class Initialized
INFO - 2024-10-15 11:12:01 --> Output Class Initialized
INFO - 2024-10-15 11:12:01 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:01 --> Input Class Initialized
INFO - 2024-10-15 11:12:01 --> Language Class Initialized
INFO - 2024-10-15 11:12:01 --> Language Class Initialized
INFO - 2024-10-15 11:12:01 --> Config Class Initialized
INFO - 2024-10-15 11:12:01 --> Loader Class Initialized
INFO - 2024-10-15 11:12:01 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:01 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:01 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:01 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:01 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:01 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:05 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:05 --> Total execution time: 3.7199
INFO - 2024-10-15 11:12:05 --> Config Class Initialized
INFO - 2024-10-15 11:12:05 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:05 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:05 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:05 --> URI Class Initialized
INFO - 2024-10-15 11:12:05 --> Router Class Initialized
INFO - 2024-10-15 11:12:05 --> Output Class Initialized
INFO - 2024-10-15 11:12:05 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:05 --> Input Class Initialized
INFO - 2024-10-15 11:12:05 --> Language Class Initialized
INFO - 2024-10-15 11:12:05 --> Language Class Initialized
INFO - 2024-10-15 11:12:05 --> Config Class Initialized
INFO - 2024-10-15 11:12:05 --> Loader Class Initialized
INFO - 2024-10-15 11:12:05 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:05 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:05 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:05 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:05 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:05 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:07 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:07 --> Total execution time: 2.8032
INFO - 2024-10-15 11:12:08 --> Config Class Initialized
INFO - 2024-10-15 11:12:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:08 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:08 --> URI Class Initialized
INFO - 2024-10-15 11:12:08 --> Router Class Initialized
INFO - 2024-10-15 11:12:08 --> Output Class Initialized
INFO - 2024-10-15 11:12:08 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:08 --> Input Class Initialized
INFO - 2024-10-15 11:12:08 --> Language Class Initialized
INFO - 2024-10-15 11:12:08 --> Language Class Initialized
INFO - 2024-10-15 11:12:08 --> Config Class Initialized
INFO - 2024-10-15 11:12:08 --> Loader Class Initialized
INFO - 2024-10-15 11:12:08 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:08 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:08 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:08 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:08 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:08 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:10 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:10 --> Total execution time: 2.7370
INFO - 2024-10-15 11:12:11 --> Config Class Initialized
INFO - 2024-10-15 11:12:11 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:11 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:11 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:11 --> URI Class Initialized
INFO - 2024-10-15 11:12:11 --> Router Class Initialized
INFO - 2024-10-15 11:12:11 --> Output Class Initialized
INFO - 2024-10-15 11:12:11 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:11 --> Input Class Initialized
INFO - 2024-10-15 11:12:11 --> Language Class Initialized
INFO - 2024-10-15 11:12:11 --> Language Class Initialized
INFO - 2024-10-15 11:12:11 --> Config Class Initialized
INFO - 2024-10-15 11:12:11 --> Loader Class Initialized
INFO - 2024-10-15 11:12:11 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:11 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:11 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:11 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:11 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:11 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:14 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:14 --> Total execution time: 2.8451
INFO - 2024-10-15 11:12:14 --> Config Class Initialized
INFO - 2024-10-15 11:12:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:14 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:14 --> URI Class Initialized
INFO - 2024-10-15 11:12:14 --> Router Class Initialized
INFO - 2024-10-15 11:12:14 --> Output Class Initialized
INFO - 2024-10-15 11:12:14 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:14 --> Input Class Initialized
INFO - 2024-10-15 11:12:14 --> Language Class Initialized
INFO - 2024-10-15 11:12:14 --> Language Class Initialized
INFO - 2024-10-15 11:12:14 --> Config Class Initialized
INFO - 2024-10-15 11:12:14 --> Loader Class Initialized
INFO - 2024-10-15 11:12:14 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:14 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:14 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:14 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:14 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:14 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:16 --> Total execution time: 2.7756
INFO - 2024-10-15 11:12:16 --> Config Class Initialized
INFO - 2024-10-15 11:12:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:17 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:17 --> URI Class Initialized
INFO - 2024-10-15 11:12:17 --> Router Class Initialized
INFO - 2024-10-15 11:12:17 --> Output Class Initialized
INFO - 2024-10-15 11:12:17 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:17 --> Input Class Initialized
INFO - 2024-10-15 11:12:17 --> Language Class Initialized
INFO - 2024-10-15 11:12:17 --> Language Class Initialized
INFO - 2024-10-15 11:12:17 --> Config Class Initialized
INFO - 2024-10-15 11:12:17 --> Loader Class Initialized
INFO - 2024-10-15 11:12:17 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:17 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:17 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:17 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:17 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:17 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:19 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:19 --> Total execution time: 2.9323
INFO - 2024-10-15 11:12:20 --> Config Class Initialized
INFO - 2024-10-15 11:12:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:20 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:20 --> URI Class Initialized
INFO - 2024-10-15 11:12:20 --> Router Class Initialized
INFO - 2024-10-15 11:12:20 --> Output Class Initialized
INFO - 2024-10-15 11:12:20 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:20 --> Input Class Initialized
INFO - 2024-10-15 11:12:20 --> Language Class Initialized
INFO - 2024-10-15 11:12:20 --> Language Class Initialized
INFO - 2024-10-15 11:12:20 --> Config Class Initialized
INFO - 2024-10-15 11:12:20 --> Loader Class Initialized
INFO - 2024-10-15 11:12:20 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:20 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:20 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:20 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:20 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:20 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:22 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:22 --> Total execution time: 2.7560
INFO - 2024-10-15 11:12:23 --> Config Class Initialized
INFO - 2024-10-15 11:12:23 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:23 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:23 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:23 --> URI Class Initialized
INFO - 2024-10-15 11:12:23 --> Router Class Initialized
INFO - 2024-10-15 11:12:23 --> Output Class Initialized
INFO - 2024-10-15 11:12:23 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:23 --> Input Class Initialized
INFO - 2024-10-15 11:12:23 --> Language Class Initialized
INFO - 2024-10-15 11:12:23 --> Language Class Initialized
INFO - 2024-10-15 11:12:23 --> Config Class Initialized
INFO - 2024-10-15 11:12:23 --> Loader Class Initialized
INFO - 2024-10-15 11:12:23 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:23 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:23 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:23 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:23 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:23 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:26 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:26 --> Total execution time: 2.9765
INFO - 2024-10-15 11:12:26 --> Config Class Initialized
INFO - 2024-10-15 11:12:26 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:26 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:26 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:26 --> URI Class Initialized
INFO - 2024-10-15 11:12:26 --> Router Class Initialized
INFO - 2024-10-15 11:12:26 --> Output Class Initialized
INFO - 2024-10-15 11:12:26 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:26 --> Input Class Initialized
INFO - 2024-10-15 11:12:26 --> Language Class Initialized
INFO - 2024-10-15 11:12:26 --> Language Class Initialized
INFO - 2024-10-15 11:12:26 --> Config Class Initialized
INFO - 2024-10-15 11:12:26 --> Loader Class Initialized
INFO - 2024-10-15 11:12:26 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:26 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:26 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:26 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:26 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:26 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:28 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:28 --> Total execution time: 2.6651
INFO - 2024-10-15 11:12:29 --> Config Class Initialized
INFO - 2024-10-15 11:12:29 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:29 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:29 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:29 --> URI Class Initialized
INFO - 2024-10-15 11:12:29 --> Router Class Initialized
INFO - 2024-10-15 11:12:29 --> Output Class Initialized
INFO - 2024-10-15 11:12:29 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:29 --> Input Class Initialized
INFO - 2024-10-15 11:12:29 --> Language Class Initialized
INFO - 2024-10-15 11:12:29 --> Language Class Initialized
INFO - 2024-10-15 11:12:29 --> Config Class Initialized
INFO - 2024-10-15 11:12:29 --> Loader Class Initialized
INFO - 2024-10-15 11:12:29 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:29 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:29 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:29 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:29 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:29 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:31 --> Total execution time: 2.8289
INFO - 2024-10-15 11:12:32 --> Config Class Initialized
INFO - 2024-10-15 11:12:32 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:32 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:32 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:32 --> URI Class Initialized
INFO - 2024-10-15 11:12:32 --> Router Class Initialized
INFO - 2024-10-15 11:12:32 --> Output Class Initialized
INFO - 2024-10-15 11:12:32 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:32 --> Input Class Initialized
INFO - 2024-10-15 11:12:32 --> Language Class Initialized
INFO - 2024-10-15 11:12:32 --> Language Class Initialized
INFO - 2024-10-15 11:12:32 --> Config Class Initialized
INFO - 2024-10-15 11:12:32 --> Loader Class Initialized
INFO - 2024-10-15 11:12:32 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:32 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:32 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:32 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:32 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:32 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:32 --> Config Class Initialized
INFO - 2024-10-15 11:12:32 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:32 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:32 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:32 --> URI Class Initialized
INFO - 2024-10-15 11:12:32 --> Router Class Initialized
INFO - 2024-10-15 11:12:32 --> Output Class Initialized
INFO - 2024-10-15 11:12:32 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:32 --> Input Class Initialized
INFO - 2024-10-15 11:12:32 --> Language Class Initialized
INFO - 2024-10-15 11:12:32 --> Language Class Initialized
INFO - 2024-10-15 11:12:32 --> Config Class Initialized
INFO - 2024-10-15 11:12:32 --> Loader Class Initialized
INFO - 2024-10-15 11:12:32 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:32 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:32 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:32 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:32 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:32 --> Controller Class Initialized
INFO - 2024-10-15 11:12:32 --> Helper loaded: cookie_helper
INFO - 2024-10-15 11:12:32 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:32 --> Total execution time: 0.1145
INFO - 2024-10-15 11:12:33 --> Config Class Initialized
INFO - 2024-10-15 11:12:33 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:33 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:33 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:33 --> URI Class Initialized
INFO - 2024-10-15 11:12:33 --> Router Class Initialized
INFO - 2024-10-15 11:12:33 --> Output Class Initialized
INFO - 2024-10-15 11:12:33 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:33 --> Input Class Initialized
INFO - 2024-10-15 11:12:33 --> Language Class Initialized
INFO - 2024-10-15 11:12:33 --> Language Class Initialized
INFO - 2024-10-15 11:12:33 --> Config Class Initialized
INFO - 2024-10-15 11:12:33 --> Loader Class Initialized
INFO - 2024-10-15 11:12:33 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:33 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:33 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:33 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:33 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:33 --> Controller Class Initialized
INFO - 2024-10-15 11:12:33 --> Helper loaded: cookie_helper
INFO - 2024-10-15 11:12:33 --> Config Class Initialized
INFO - 2024-10-15 11:12:33 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:33 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:33 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:33 --> URI Class Initialized
INFO - 2024-10-15 11:12:33 --> Router Class Initialized
INFO - 2024-10-15 11:12:33 --> Output Class Initialized
INFO - 2024-10-15 11:12:33 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:33 --> Input Class Initialized
INFO - 2024-10-15 11:12:33 --> Language Class Initialized
INFO - 2024-10-15 11:12:33 --> Language Class Initialized
INFO - 2024-10-15 11:12:33 --> Config Class Initialized
INFO - 2024-10-15 11:12:33 --> Loader Class Initialized
INFO - 2024-10-15 11:12:33 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:33 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:33 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:33 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:33 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:33 --> Controller Class Initialized
DEBUG - 2024-10-15 11:12:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 11:12:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:12:33 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:33 --> Total execution time: 0.1604
INFO - 2024-10-15 11:12:35 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:35 --> Total execution time: 3.0000
INFO - 2024-10-15 11:12:35 --> Config Class Initialized
INFO - 2024-10-15 11:12:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:35 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:35 --> URI Class Initialized
INFO - 2024-10-15 11:12:35 --> Router Class Initialized
INFO - 2024-10-15 11:12:35 --> Output Class Initialized
INFO - 2024-10-15 11:12:35 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:35 --> Input Class Initialized
INFO - 2024-10-15 11:12:35 --> Language Class Initialized
INFO - 2024-10-15 11:12:35 --> Language Class Initialized
INFO - 2024-10-15 11:12:35 --> Config Class Initialized
INFO - 2024-10-15 11:12:35 --> Loader Class Initialized
INFO - 2024-10-15 11:12:35 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:35 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:35 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:35 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:35 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:35 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:36 --> Config Class Initialized
INFO - 2024-10-15 11:12:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:36 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:36 --> URI Class Initialized
INFO - 2024-10-15 11:12:36 --> Router Class Initialized
INFO - 2024-10-15 11:12:36 --> Output Class Initialized
INFO - 2024-10-15 11:12:36 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:36 --> Input Class Initialized
INFO - 2024-10-15 11:12:36 --> Language Class Initialized
INFO - 2024-10-15 11:12:36 --> Language Class Initialized
INFO - 2024-10-15 11:12:36 --> Config Class Initialized
INFO - 2024-10-15 11:12:36 --> Loader Class Initialized
INFO - 2024-10-15 11:12:36 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:36 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:37 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:37 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:37 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:37 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:38 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:38 --> Total execution time: 3.0865
INFO - 2024-10-15 11:12:39 --> Config Class Initialized
INFO - 2024-10-15 11:12:39 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:39 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:39 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:39 --> URI Class Initialized
INFO - 2024-10-15 11:12:39 --> Router Class Initialized
INFO - 2024-10-15 11:12:39 --> Output Class Initialized
INFO - 2024-10-15 11:12:39 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:39 --> Input Class Initialized
INFO - 2024-10-15 11:12:39 --> Language Class Initialized
INFO - 2024-10-15 11:12:39 --> Language Class Initialized
INFO - 2024-10-15 11:12:39 --> Config Class Initialized
INFO - 2024-10-15 11:12:39 --> Loader Class Initialized
INFO - 2024-10-15 11:12:39 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:39 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:39 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:39 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:39 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:39 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:42 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:42 --> Total execution time: 5.9682
INFO - 2024-10-15 11:12:43 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:43 --> Total execution time: 4.5026
INFO - 2024-10-15 11:12:43 --> Config Class Initialized
INFO - 2024-10-15 11:12:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:43 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:43 --> URI Class Initialized
INFO - 2024-10-15 11:12:43 --> Router Class Initialized
INFO - 2024-10-15 11:12:43 --> Output Class Initialized
INFO - 2024-10-15 11:12:43 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:43 --> Input Class Initialized
INFO - 2024-10-15 11:12:43 --> Language Class Initialized
INFO - 2024-10-15 11:12:43 --> Language Class Initialized
INFO - 2024-10-15 11:12:43 --> Config Class Initialized
INFO - 2024-10-15 11:12:43 --> Loader Class Initialized
INFO - 2024-10-15 11:12:43 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:43 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:43 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:43 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:43 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:43 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:45 --> Config Class Initialized
INFO - 2024-10-15 11:12:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:45 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:45 --> URI Class Initialized
INFO - 2024-10-15 11:12:45 --> Router Class Initialized
INFO - 2024-10-15 11:12:45 --> Output Class Initialized
INFO - 2024-10-15 11:12:45 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:45 --> Input Class Initialized
INFO - 2024-10-15 11:12:45 --> Language Class Initialized
INFO - 2024-10-15 11:12:45 --> Language Class Initialized
INFO - 2024-10-15 11:12:45 --> Config Class Initialized
INFO - 2024-10-15 11:12:45 --> Loader Class Initialized
INFO - 2024-10-15 11:12:45 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:45 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:45 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:45 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:45 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:45 --> Controller Class Initialized
DEBUG - 2024-10-15 11:12:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:46 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:46 --> Total execution time: 2.9396
INFO - 2024-10-15 11:12:47 --> Config Class Initialized
INFO - 2024-10-15 11:12:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:47 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:47 --> URI Class Initialized
INFO - 2024-10-15 11:12:47 --> Router Class Initialized
INFO - 2024-10-15 11:12:47 --> Output Class Initialized
INFO - 2024-10-15 11:12:47 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:47 --> Input Class Initialized
INFO - 2024-10-15 11:12:47 --> Language Class Initialized
INFO - 2024-10-15 11:12:47 --> Language Class Initialized
INFO - 2024-10-15 11:12:47 --> Config Class Initialized
INFO - 2024-10-15 11:12:47 --> Loader Class Initialized
INFO - 2024-10-15 11:12:47 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:47 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:47 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:47 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:47 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:47 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:52 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:52 --> Total execution time: 5.8781
INFO - 2024-10-15 11:12:53 --> Config Class Initialized
INFO - 2024-10-15 11:12:53 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:53 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:53 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:53 --> URI Class Initialized
INFO - 2024-10-15 11:12:53 --> Router Class Initialized
INFO - 2024-10-15 11:12:53 --> Output Class Initialized
INFO - 2024-10-15 11:12:53 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:53 --> Input Class Initialized
INFO - 2024-10-15 11:12:53 --> Language Class Initialized
INFO - 2024-10-15 11:12:53 --> Language Class Initialized
INFO - 2024-10-15 11:12:53 --> Config Class Initialized
INFO - 2024-10-15 11:12:53 --> Loader Class Initialized
INFO - 2024-10-15 11:12:53 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:53 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:53 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:53 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:53 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:53 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:53 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:53 --> Total execution time: 7.7999
INFO - 2024-10-15 11:12:55 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:55 --> Total execution time: 2.8648
INFO - 2024-10-15 11:12:56 --> Config Class Initialized
INFO - 2024-10-15 11:12:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:56 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:56 --> URI Class Initialized
INFO - 2024-10-15 11:12:56 --> Router Class Initialized
INFO - 2024-10-15 11:12:56 --> Output Class Initialized
INFO - 2024-10-15 11:12:56 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:56 --> Input Class Initialized
INFO - 2024-10-15 11:12:56 --> Language Class Initialized
INFO - 2024-10-15 11:12:56 --> Language Class Initialized
INFO - 2024-10-15 11:12:56 --> Config Class Initialized
INFO - 2024-10-15 11:12:56 --> Loader Class Initialized
INFO - 2024-10-15 11:12:56 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:56 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:56 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:56 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:56 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:56 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:12:59 --> Final output sent to browser
DEBUG - 2024-10-15 11:12:59 --> Total execution time: 2.6405
INFO - 2024-10-15 11:12:59 --> Config Class Initialized
INFO - 2024-10-15 11:12:59 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:12:59 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:12:59 --> Utf8 Class Initialized
INFO - 2024-10-15 11:12:59 --> URI Class Initialized
INFO - 2024-10-15 11:12:59 --> Router Class Initialized
INFO - 2024-10-15 11:12:59 --> Output Class Initialized
INFO - 2024-10-15 11:12:59 --> Security Class Initialized
DEBUG - 2024-10-15 11:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:12:59 --> Input Class Initialized
INFO - 2024-10-15 11:12:59 --> Language Class Initialized
INFO - 2024-10-15 11:12:59 --> Language Class Initialized
INFO - 2024-10-15 11:12:59 --> Config Class Initialized
INFO - 2024-10-15 11:12:59 --> Loader Class Initialized
INFO - 2024-10-15 11:12:59 --> Helper loaded: url_helper
INFO - 2024-10-15 11:12:59 --> Helper loaded: file_helper
INFO - 2024-10-15 11:12:59 --> Helper loaded: form_helper
INFO - 2024-10-15 11:12:59 --> Helper loaded: my_helper
INFO - 2024-10-15 11:12:59 --> Database Driver Class Initialized
INFO - 2024-10-15 11:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:12:59 --> Controller Class Initialized
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:12:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:02 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:02 --> Total execution time: 3.0666
INFO - 2024-10-15 11:13:02 --> Config Class Initialized
INFO - 2024-10-15 11:13:02 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:02 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:02 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:02 --> URI Class Initialized
INFO - 2024-10-15 11:13:02 --> Router Class Initialized
INFO - 2024-10-15 11:13:02 --> Output Class Initialized
INFO - 2024-10-15 11:13:02 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:02 --> Input Class Initialized
INFO - 2024-10-15 11:13:02 --> Language Class Initialized
INFO - 2024-10-15 11:13:02 --> Language Class Initialized
INFO - 2024-10-15 11:13:02 --> Config Class Initialized
INFO - 2024-10-15 11:13:02 --> Loader Class Initialized
INFO - 2024-10-15 11:13:02 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:02 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:02 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:02 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:02 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:02 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:05 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:05 --> Total execution time: 3.2670
INFO - 2024-10-15 11:13:05 --> Config Class Initialized
INFO - 2024-10-15 11:13:05 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:05 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:05 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:05 --> URI Class Initialized
INFO - 2024-10-15 11:13:05 --> Router Class Initialized
INFO - 2024-10-15 11:13:05 --> Output Class Initialized
INFO - 2024-10-15 11:13:05 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:05 --> Input Class Initialized
INFO - 2024-10-15 11:13:05 --> Language Class Initialized
INFO - 2024-10-15 11:13:05 --> Language Class Initialized
INFO - 2024-10-15 11:13:05 --> Config Class Initialized
INFO - 2024-10-15 11:13:05 --> Loader Class Initialized
INFO - 2024-10-15 11:13:05 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:05 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:05 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:05 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:05 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:05 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:09 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:09 --> Total execution time: 3.0944
INFO - 2024-10-15 11:13:09 --> Config Class Initialized
INFO - 2024-10-15 11:13:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:09 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:09 --> URI Class Initialized
INFO - 2024-10-15 11:13:09 --> Router Class Initialized
INFO - 2024-10-15 11:13:09 --> Output Class Initialized
INFO - 2024-10-15 11:13:09 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:09 --> Input Class Initialized
INFO - 2024-10-15 11:13:09 --> Language Class Initialized
INFO - 2024-10-15 11:13:09 --> Language Class Initialized
INFO - 2024-10-15 11:13:09 --> Config Class Initialized
INFO - 2024-10-15 11:13:09 --> Loader Class Initialized
INFO - 2024-10-15 11:13:09 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:09 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:09 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:09 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:09 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:09 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:12 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:12 --> Total execution time: 2.9108
INFO - 2024-10-15 11:13:12 --> Config Class Initialized
INFO - 2024-10-15 11:13:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:12 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:12 --> URI Class Initialized
INFO - 2024-10-15 11:13:12 --> Router Class Initialized
INFO - 2024-10-15 11:13:12 --> Output Class Initialized
INFO - 2024-10-15 11:13:12 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:12 --> Input Class Initialized
INFO - 2024-10-15 11:13:12 --> Language Class Initialized
INFO - 2024-10-15 11:13:12 --> Language Class Initialized
INFO - 2024-10-15 11:13:12 --> Config Class Initialized
INFO - 2024-10-15 11:13:12 --> Loader Class Initialized
INFO - 2024-10-15 11:13:12 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:12 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:12 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:12 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:12 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:12 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:15 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:15 --> Total execution time: 2.7926
INFO - 2024-10-15 11:13:15 --> Config Class Initialized
INFO - 2024-10-15 11:13:15 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:15 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:15 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:15 --> URI Class Initialized
INFO - 2024-10-15 11:13:15 --> Router Class Initialized
INFO - 2024-10-15 11:13:15 --> Output Class Initialized
INFO - 2024-10-15 11:13:15 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:15 --> Input Class Initialized
INFO - 2024-10-15 11:13:15 --> Language Class Initialized
INFO - 2024-10-15 11:13:15 --> Language Class Initialized
INFO - 2024-10-15 11:13:15 --> Config Class Initialized
INFO - 2024-10-15 11:13:15 --> Loader Class Initialized
INFO - 2024-10-15 11:13:15 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:15 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:15 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:15 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:15 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:15 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:18 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:18 --> Total execution time: 2.5405
INFO - 2024-10-15 11:13:18 --> Config Class Initialized
INFO - 2024-10-15 11:13:18 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:18 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:18 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:18 --> URI Class Initialized
INFO - 2024-10-15 11:13:18 --> Router Class Initialized
INFO - 2024-10-15 11:13:18 --> Output Class Initialized
INFO - 2024-10-15 11:13:18 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:18 --> Input Class Initialized
INFO - 2024-10-15 11:13:18 --> Language Class Initialized
INFO - 2024-10-15 11:13:18 --> Language Class Initialized
INFO - 2024-10-15 11:13:18 --> Config Class Initialized
INFO - 2024-10-15 11:13:18 --> Loader Class Initialized
INFO - 2024-10-15 11:13:18 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:18 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:18 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:18 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:18 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:18 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:21 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:21 --> Total execution time: 3.0330
INFO - 2024-10-15 11:13:22 --> Config Class Initialized
INFO - 2024-10-15 11:13:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:22 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:22 --> URI Class Initialized
INFO - 2024-10-15 11:13:22 --> Router Class Initialized
INFO - 2024-10-15 11:13:22 --> Output Class Initialized
INFO - 2024-10-15 11:13:22 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:22 --> Input Class Initialized
INFO - 2024-10-15 11:13:22 --> Language Class Initialized
INFO - 2024-10-15 11:13:22 --> Language Class Initialized
INFO - 2024-10-15 11:13:22 --> Config Class Initialized
INFO - 2024-10-15 11:13:22 --> Loader Class Initialized
INFO - 2024-10-15 11:13:22 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:22 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:22 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:22 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:22 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:22 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:25 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:25 --> Total execution time: 3.0350
INFO - 2024-10-15 11:13:25 --> Config Class Initialized
INFO - 2024-10-15 11:13:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:25 --> URI Class Initialized
INFO - 2024-10-15 11:13:25 --> Router Class Initialized
INFO - 2024-10-15 11:13:25 --> Output Class Initialized
INFO - 2024-10-15 11:13:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:25 --> Input Class Initialized
INFO - 2024-10-15 11:13:25 --> Language Class Initialized
INFO - 2024-10-15 11:13:25 --> Language Class Initialized
INFO - 2024-10-15 11:13:25 --> Config Class Initialized
INFO - 2024-10-15 11:13:25 --> Loader Class Initialized
INFO - 2024-10-15 11:13:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:25 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:28 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:28 --> Total execution time: 2.8890
INFO - 2024-10-15 11:13:28 --> Config Class Initialized
INFO - 2024-10-15 11:13:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:28 --> URI Class Initialized
INFO - 2024-10-15 11:13:28 --> Router Class Initialized
INFO - 2024-10-15 11:13:28 --> Output Class Initialized
INFO - 2024-10-15 11:13:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:28 --> Input Class Initialized
INFO - 2024-10-15 11:13:28 --> Language Class Initialized
INFO - 2024-10-15 11:13:28 --> Language Class Initialized
INFO - 2024-10-15 11:13:28 --> Config Class Initialized
INFO - 2024-10-15 11:13:28 --> Loader Class Initialized
INFO - 2024-10-15 11:13:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:31 --> Total execution time: 2.8618
INFO - 2024-10-15 11:13:31 --> Config Class Initialized
INFO - 2024-10-15 11:13:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:31 --> URI Class Initialized
INFO - 2024-10-15 11:13:31 --> Router Class Initialized
INFO - 2024-10-15 11:13:31 --> Output Class Initialized
INFO - 2024-10-15 11:13:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:31 --> Input Class Initialized
INFO - 2024-10-15 11:13:31 --> Language Class Initialized
INFO - 2024-10-15 11:13:31 --> Language Class Initialized
INFO - 2024-10-15 11:13:31 --> Config Class Initialized
INFO - 2024-10-15 11:13:31 --> Loader Class Initialized
INFO - 2024-10-15 11:13:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:34 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:34 --> Total execution time: 2.6248
INFO - 2024-10-15 11:13:34 --> Config Class Initialized
INFO - 2024-10-15 11:13:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:34 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:34 --> URI Class Initialized
INFO - 2024-10-15 11:13:34 --> Router Class Initialized
INFO - 2024-10-15 11:13:34 --> Output Class Initialized
INFO - 2024-10-15 11:13:34 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:34 --> Input Class Initialized
INFO - 2024-10-15 11:13:34 --> Language Class Initialized
INFO - 2024-10-15 11:13:34 --> Language Class Initialized
INFO - 2024-10-15 11:13:34 --> Config Class Initialized
INFO - 2024-10-15 11:13:34 --> Loader Class Initialized
INFO - 2024-10-15 11:13:34 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:34 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:34 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:34 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:34 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:34 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:37 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:37 --> Total execution time: 2.6206
INFO - 2024-10-15 11:13:37 --> Config Class Initialized
INFO - 2024-10-15 11:13:37 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:37 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:37 --> URI Class Initialized
INFO - 2024-10-15 11:13:37 --> Router Class Initialized
INFO - 2024-10-15 11:13:37 --> Output Class Initialized
INFO - 2024-10-15 11:13:37 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:37 --> Input Class Initialized
INFO - 2024-10-15 11:13:37 --> Language Class Initialized
INFO - 2024-10-15 11:13:37 --> Language Class Initialized
INFO - 2024-10-15 11:13:37 --> Config Class Initialized
INFO - 2024-10-15 11:13:37 --> Loader Class Initialized
INFO - 2024-10-15 11:13:37 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:37 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:37 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:37 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:37 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:37 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:40 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:40 --> Total execution time: 2.9451
INFO - 2024-10-15 11:13:40 --> Config Class Initialized
INFO - 2024-10-15 11:13:40 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:40 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:40 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:40 --> URI Class Initialized
INFO - 2024-10-15 11:13:40 --> Router Class Initialized
INFO - 2024-10-15 11:13:40 --> Output Class Initialized
INFO - 2024-10-15 11:13:40 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:40 --> Input Class Initialized
INFO - 2024-10-15 11:13:40 --> Language Class Initialized
INFO - 2024-10-15 11:13:40 --> Language Class Initialized
INFO - 2024-10-15 11:13:40 --> Config Class Initialized
INFO - 2024-10-15 11:13:40 --> Loader Class Initialized
INFO - 2024-10-15 11:13:40 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:40 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:40 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:40 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:40 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:40 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:43 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:43 --> Total execution time: 2.5114
INFO - 2024-10-15 11:13:43 --> Config Class Initialized
INFO - 2024-10-15 11:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:43 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:43 --> URI Class Initialized
INFO - 2024-10-15 11:13:43 --> Router Class Initialized
INFO - 2024-10-15 11:13:43 --> Output Class Initialized
INFO - 2024-10-15 11:13:43 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:43 --> Input Class Initialized
INFO - 2024-10-15 11:13:43 --> Language Class Initialized
INFO - 2024-10-15 11:13:43 --> Language Class Initialized
INFO - 2024-10-15 11:13:43 --> Config Class Initialized
INFO - 2024-10-15 11:13:43 --> Loader Class Initialized
INFO - 2024-10-15 11:13:43 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:43 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:43 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:43 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:43 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:43 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:46 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:46 --> Total execution time: 2.7567
INFO - 2024-10-15 11:13:46 --> Config Class Initialized
INFO - 2024-10-15 11:13:46 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:46 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:46 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:46 --> URI Class Initialized
INFO - 2024-10-15 11:13:46 --> Router Class Initialized
INFO - 2024-10-15 11:13:46 --> Output Class Initialized
INFO - 2024-10-15 11:13:46 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:46 --> Input Class Initialized
INFO - 2024-10-15 11:13:46 --> Language Class Initialized
INFO - 2024-10-15 11:13:46 --> Language Class Initialized
INFO - 2024-10-15 11:13:46 --> Config Class Initialized
INFO - 2024-10-15 11:13:46 --> Loader Class Initialized
INFO - 2024-10-15 11:13:46 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:46 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:46 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:46 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:46 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:46 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:49 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:49 --> Total execution time: 2.6818
INFO - 2024-10-15 11:13:49 --> Config Class Initialized
INFO - 2024-10-15 11:13:49 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:49 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:49 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:49 --> URI Class Initialized
INFO - 2024-10-15 11:13:49 --> Router Class Initialized
INFO - 2024-10-15 11:13:49 --> Output Class Initialized
INFO - 2024-10-15 11:13:49 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:49 --> Input Class Initialized
INFO - 2024-10-15 11:13:49 --> Language Class Initialized
INFO - 2024-10-15 11:13:49 --> Language Class Initialized
INFO - 2024-10-15 11:13:49 --> Config Class Initialized
INFO - 2024-10-15 11:13:49 --> Loader Class Initialized
INFO - 2024-10-15 11:13:49 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:49 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:49 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:49 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:49 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:49 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:52 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:52 --> Total execution time: 2.7404
INFO - 2024-10-15 11:13:52 --> Config Class Initialized
INFO - 2024-10-15 11:13:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:52 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:52 --> URI Class Initialized
INFO - 2024-10-15 11:13:52 --> Router Class Initialized
INFO - 2024-10-15 11:13:52 --> Output Class Initialized
INFO - 2024-10-15 11:13:52 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:52 --> Input Class Initialized
INFO - 2024-10-15 11:13:52 --> Language Class Initialized
INFO - 2024-10-15 11:13:52 --> Language Class Initialized
INFO - 2024-10-15 11:13:52 --> Config Class Initialized
INFO - 2024-10-15 11:13:52 --> Loader Class Initialized
INFO - 2024-10-15 11:13:52 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:52 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:52 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:52 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:52 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:52 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:55 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:55 --> Total execution time: 2.7439
INFO - 2024-10-15 11:13:55 --> Config Class Initialized
INFO - 2024-10-15 11:13:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:55 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:55 --> URI Class Initialized
INFO - 2024-10-15 11:13:55 --> Router Class Initialized
INFO - 2024-10-15 11:13:55 --> Output Class Initialized
INFO - 2024-10-15 11:13:55 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:55 --> Input Class Initialized
INFO - 2024-10-15 11:13:55 --> Language Class Initialized
INFO - 2024-10-15 11:13:55 --> Language Class Initialized
INFO - 2024-10-15 11:13:55 --> Config Class Initialized
INFO - 2024-10-15 11:13:55 --> Loader Class Initialized
INFO - 2024-10-15 11:13:55 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:55 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:55 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:55 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:55 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:55 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:13:58 --> Final output sent to browser
DEBUG - 2024-10-15 11:13:58 --> Total execution time: 2.5939
INFO - 2024-10-15 11:13:58 --> Config Class Initialized
INFO - 2024-10-15 11:13:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:13:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:13:58 --> Utf8 Class Initialized
INFO - 2024-10-15 11:13:58 --> URI Class Initialized
INFO - 2024-10-15 11:13:58 --> Router Class Initialized
INFO - 2024-10-15 11:13:58 --> Output Class Initialized
INFO - 2024-10-15 11:13:58 --> Security Class Initialized
DEBUG - 2024-10-15 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:13:58 --> Input Class Initialized
INFO - 2024-10-15 11:13:58 --> Language Class Initialized
INFO - 2024-10-15 11:13:58 --> Language Class Initialized
INFO - 2024-10-15 11:13:58 --> Config Class Initialized
INFO - 2024-10-15 11:13:58 --> Loader Class Initialized
INFO - 2024-10-15 11:13:58 --> Helper loaded: url_helper
INFO - 2024-10-15 11:13:58 --> Helper loaded: file_helper
INFO - 2024-10-15 11:13:58 --> Helper loaded: form_helper
INFO - 2024-10-15 11:13:58 --> Helper loaded: my_helper
INFO - 2024-10-15 11:13:58 --> Database Driver Class Initialized
INFO - 2024-10-15 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:13:58 --> Controller Class Initialized
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:13:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:13:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:00 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:00 --> Total execution time: 2.5508
INFO - 2024-10-15 11:14:00 --> Config Class Initialized
INFO - 2024-10-15 11:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:00 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:00 --> URI Class Initialized
INFO - 2024-10-15 11:14:00 --> Router Class Initialized
INFO - 2024-10-15 11:14:00 --> Output Class Initialized
INFO - 2024-10-15 11:14:00 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:00 --> Input Class Initialized
INFO - 2024-10-15 11:14:00 --> Language Class Initialized
INFO - 2024-10-15 11:14:00 --> Language Class Initialized
INFO - 2024-10-15 11:14:00 --> Config Class Initialized
INFO - 2024-10-15 11:14:00 --> Loader Class Initialized
INFO - 2024-10-15 11:14:00 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:00 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:00 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:00 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:00 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:00 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:04 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:04 --> Total execution time: 3.2175
INFO - 2024-10-15 11:14:04 --> Config Class Initialized
INFO - 2024-10-15 11:14:04 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:04 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:04 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:04 --> URI Class Initialized
INFO - 2024-10-15 11:14:04 --> Router Class Initialized
INFO - 2024-10-15 11:14:04 --> Output Class Initialized
INFO - 2024-10-15 11:14:04 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:04 --> Input Class Initialized
INFO - 2024-10-15 11:14:04 --> Language Class Initialized
INFO - 2024-10-15 11:14:04 --> Language Class Initialized
INFO - 2024-10-15 11:14:04 --> Config Class Initialized
INFO - 2024-10-15 11:14:04 --> Loader Class Initialized
INFO - 2024-10-15 11:14:04 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:04 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:04 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:04 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:04 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:04 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:07 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:07 --> Total execution time: 2.9241
INFO - 2024-10-15 11:14:07 --> Config Class Initialized
INFO - 2024-10-15 11:14:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:07 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:07 --> URI Class Initialized
INFO - 2024-10-15 11:14:07 --> Router Class Initialized
INFO - 2024-10-15 11:14:07 --> Output Class Initialized
INFO - 2024-10-15 11:14:07 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:07 --> Input Class Initialized
INFO - 2024-10-15 11:14:07 --> Language Class Initialized
INFO - 2024-10-15 11:14:07 --> Language Class Initialized
INFO - 2024-10-15 11:14:07 --> Config Class Initialized
INFO - 2024-10-15 11:14:07 --> Loader Class Initialized
INFO - 2024-10-15 11:14:07 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:07 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:07 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:07 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:07 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:07 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:10 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:10 --> Total execution time: 3.0641
INFO - 2024-10-15 11:14:10 --> Config Class Initialized
INFO - 2024-10-15 11:14:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:10 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:10 --> URI Class Initialized
INFO - 2024-10-15 11:14:10 --> Router Class Initialized
INFO - 2024-10-15 11:14:10 --> Output Class Initialized
INFO - 2024-10-15 11:14:10 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:10 --> Input Class Initialized
INFO - 2024-10-15 11:14:10 --> Language Class Initialized
INFO - 2024-10-15 11:14:10 --> Language Class Initialized
INFO - 2024-10-15 11:14:10 --> Config Class Initialized
INFO - 2024-10-15 11:14:10 --> Loader Class Initialized
INFO - 2024-10-15 11:14:10 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:10 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:10 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:10 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:10 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:10 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:13 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:13 --> Total execution time: 2.8769
INFO - 2024-10-15 11:14:14 --> Config Class Initialized
INFO - 2024-10-15 11:14:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:14 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:14 --> URI Class Initialized
INFO - 2024-10-15 11:14:14 --> Router Class Initialized
INFO - 2024-10-15 11:14:14 --> Output Class Initialized
INFO - 2024-10-15 11:14:14 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:14 --> Input Class Initialized
INFO - 2024-10-15 11:14:14 --> Language Class Initialized
INFO - 2024-10-15 11:14:14 --> Language Class Initialized
INFO - 2024-10-15 11:14:14 --> Config Class Initialized
INFO - 2024-10-15 11:14:14 --> Loader Class Initialized
INFO - 2024-10-15 11:14:14 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:14 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:14 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:14 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:14 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:14 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:16 --> Total execution time: 2.7123
INFO - 2024-10-15 11:14:17 --> Config Class Initialized
INFO - 2024-10-15 11:14:17 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:17 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:17 --> URI Class Initialized
INFO - 2024-10-15 11:14:17 --> Router Class Initialized
INFO - 2024-10-15 11:14:17 --> Output Class Initialized
INFO - 2024-10-15 11:14:17 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:17 --> Input Class Initialized
INFO - 2024-10-15 11:14:17 --> Language Class Initialized
INFO - 2024-10-15 11:14:17 --> Language Class Initialized
INFO - 2024-10-15 11:14:17 --> Config Class Initialized
INFO - 2024-10-15 11:14:17 --> Loader Class Initialized
INFO - 2024-10-15 11:14:17 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:17 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:17 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:17 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:17 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:17 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:19 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:19 --> Total execution time: 2.6702
INFO - 2024-10-15 11:14:19 --> Config Class Initialized
INFO - 2024-10-15 11:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:19 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:19 --> URI Class Initialized
INFO - 2024-10-15 11:14:19 --> Router Class Initialized
INFO - 2024-10-15 11:14:19 --> Output Class Initialized
INFO - 2024-10-15 11:14:19 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:19 --> Input Class Initialized
INFO - 2024-10-15 11:14:19 --> Language Class Initialized
INFO - 2024-10-15 11:14:19 --> Language Class Initialized
INFO - 2024-10-15 11:14:19 --> Config Class Initialized
INFO - 2024-10-15 11:14:19 --> Loader Class Initialized
INFO - 2024-10-15 11:14:19 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:19 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:19 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:19 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:19 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:19 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:22 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:22 --> Total execution time: 2.7387
INFO - 2024-10-15 11:14:22 --> Config Class Initialized
INFO - 2024-10-15 11:14:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:22 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:22 --> URI Class Initialized
INFO - 2024-10-15 11:14:22 --> Router Class Initialized
INFO - 2024-10-15 11:14:22 --> Output Class Initialized
INFO - 2024-10-15 11:14:22 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:22 --> Input Class Initialized
INFO - 2024-10-15 11:14:22 --> Language Class Initialized
INFO - 2024-10-15 11:14:22 --> Language Class Initialized
INFO - 2024-10-15 11:14:22 --> Config Class Initialized
INFO - 2024-10-15 11:14:22 --> Loader Class Initialized
INFO - 2024-10-15 11:14:22 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:22 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:22 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:22 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:22 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:22 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:25 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:25 --> Total execution time: 2.7703
INFO - 2024-10-15 11:14:25 --> Config Class Initialized
INFO - 2024-10-15 11:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:25 --> URI Class Initialized
INFO - 2024-10-15 11:14:25 --> Router Class Initialized
INFO - 2024-10-15 11:14:25 --> Output Class Initialized
INFO - 2024-10-15 11:14:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:25 --> Input Class Initialized
INFO - 2024-10-15 11:14:25 --> Language Class Initialized
INFO - 2024-10-15 11:14:25 --> Language Class Initialized
INFO - 2024-10-15 11:14:25 --> Config Class Initialized
INFO - 2024-10-15 11:14:25 --> Loader Class Initialized
INFO - 2024-10-15 11:14:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:25 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:28 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:28 --> Total execution time: 2.7673
INFO - 2024-10-15 11:14:28 --> Config Class Initialized
INFO - 2024-10-15 11:14:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:28 --> URI Class Initialized
INFO - 2024-10-15 11:14:28 --> Router Class Initialized
INFO - 2024-10-15 11:14:28 --> Output Class Initialized
INFO - 2024-10-15 11:14:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:28 --> Input Class Initialized
INFO - 2024-10-15 11:14:28 --> Language Class Initialized
INFO - 2024-10-15 11:14:28 --> Language Class Initialized
INFO - 2024-10-15 11:14:28 --> Config Class Initialized
INFO - 2024-10-15 11:14:28 --> Loader Class Initialized
INFO - 2024-10-15 11:14:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:31 --> Total execution time: 3.0163
INFO - 2024-10-15 11:14:31 --> Config Class Initialized
INFO - 2024-10-15 11:14:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:31 --> URI Class Initialized
INFO - 2024-10-15 11:14:31 --> Router Class Initialized
INFO - 2024-10-15 11:14:31 --> Output Class Initialized
INFO - 2024-10-15 11:14:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:31 --> Input Class Initialized
INFO - 2024-10-15 11:14:31 --> Language Class Initialized
INFO - 2024-10-15 11:14:31 --> Language Class Initialized
INFO - 2024-10-15 11:14:31 --> Config Class Initialized
INFO - 2024-10-15 11:14:31 --> Loader Class Initialized
INFO - 2024-10-15 11:14:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:34 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:34 --> Total execution time: 2.7209
INFO - 2024-10-15 11:14:34 --> Config Class Initialized
INFO - 2024-10-15 11:14:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:34 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:34 --> URI Class Initialized
INFO - 2024-10-15 11:14:34 --> Router Class Initialized
INFO - 2024-10-15 11:14:34 --> Output Class Initialized
INFO - 2024-10-15 11:14:34 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:34 --> Input Class Initialized
INFO - 2024-10-15 11:14:34 --> Language Class Initialized
INFO - 2024-10-15 11:14:34 --> Language Class Initialized
INFO - 2024-10-15 11:14:34 --> Config Class Initialized
INFO - 2024-10-15 11:14:34 --> Loader Class Initialized
INFO - 2024-10-15 11:14:34 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:34 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:34 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:34 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:34 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:34 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:37 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:37 --> Total execution time: 2.6864
INFO - 2024-10-15 11:14:37 --> Config Class Initialized
INFO - 2024-10-15 11:14:37 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:37 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:37 --> URI Class Initialized
INFO - 2024-10-15 11:14:37 --> Router Class Initialized
INFO - 2024-10-15 11:14:37 --> Output Class Initialized
INFO - 2024-10-15 11:14:37 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:37 --> Input Class Initialized
INFO - 2024-10-15 11:14:37 --> Language Class Initialized
INFO - 2024-10-15 11:14:37 --> Language Class Initialized
INFO - 2024-10-15 11:14:37 --> Config Class Initialized
INFO - 2024-10-15 11:14:37 --> Loader Class Initialized
INFO - 2024-10-15 11:14:37 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:37 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:37 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:37 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:37 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:37 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:40 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:40 --> Total execution time: 2.7246
INFO - 2024-10-15 11:14:40 --> Config Class Initialized
INFO - 2024-10-15 11:14:40 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:40 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:40 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:40 --> URI Class Initialized
INFO - 2024-10-15 11:14:40 --> Router Class Initialized
INFO - 2024-10-15 11:14:40 --> Output Class Initialized
INFO - 2024-10-15 11:14:40 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:40 --> Input Class Initialized
INFO - 2024-10-15 11:14:40 --> Language Class Initialized
INFO - 2024-10-15 11:14:40 --> Language Class Initialized
INFO - 2024-10-15 11:14:40 --> Config Class Initialized
INFO - 2024-10-15 11:14:40 --> Loader Class Initialized
INFO - 2024-10-15 11:14:40 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:40 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:40 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:40 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:40 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:40 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:42 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:42 --> Total execution time: 2.6087
INFO - 2024-10-15 11:14:42 --> Config Class Initialized
INFO - 2024-10-15 11:14:42 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:42 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:42 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:42 --> URI Class Initialized
INFO - 2024-10-15 11:14:42 --> Router Class Initialized
INFO - 2024-10-15 11:14:42 --> Output Class Initialized
INFO - 2024-10-15 11:14:42 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:42 --> Input Class Initialized
INFO - 2024-10-15 11:14:42 --> Language Class Initialized
INFO - 2024-10-15 11:14:42 --> Language Class Initialized
INFO - 2024-10-15 11:14:42 --> Config Class Initialized
INFO - 2024-10-15 11:14:42 --> Loader Class Initialized
INFO - 2024-10-15 11:14:42 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:42 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:42 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:42 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:42 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:42 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:45 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:45 --> Total execution time: 2.6672
INFO - 2024-10-15 11:14:45 --> Config Class Initialized
INFO - 2024-10-15 11:14:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:45 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:45 --> URI Class Initialized
INFO - 2024-10-15 11:14:45 --> Router Class Initialized
INFO - 2024-10-15 11:14:45 --> Output Class Initialized
INFO - 2024-10-15 11:14:45 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:45 --> Input Class Initialized
INFO - 2024-10-15 11:14:45 --> Language Class Initialized
INFO - 2024-10-15 11:14:45 --> Language Class Initialized
INFO - 2024-10-15 11:14:45 --> Config Class Initialized
INFO - 2024-10-15 11:14:45 --> Loader Class Initialized
INFO - 2024-10-15 11:14:45 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:45 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:45 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:45 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:45 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:45 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:48 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:48 --> Total execution time: 2.5839
INFO - 2024-10-15 11:14:48 --> Config Class Initialized
INFO - 2024-10-15 11:14:48 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:48 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:48 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:48 --> URI Class Initialized
INFO - 2024-10-15 11:14:48 --> Router Class Initialized
INFO - 2024-10-15 11:14:48 --> Output Class Initialized
INFO - 2024-10-15 11:14:48 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:48 --> Input Class Initialized
INFO - 2024-10-15 11:14:48 --> Language Class Initialized
INFO - 2024-10-15 11:14:48 --> Language Class Initialized
INFO - 2024-10-15 11:14:48 --> Config Class Initialized
INFO - 2024-10-15 11:14:48 --> Loader Class Initialized
INFO - 2024-10-15 11:14:48 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:48 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:48 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:48 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:48 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:48 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:51 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:51 --> Total execution time: 2.6917
INFO - 2024-10-15 11:14:51 --> Config Class Initialized
INFO - 2024-10-15 11:14:51 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:51 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:51 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:51 --> URI Class Initialized
INFO - 2024-10-15 11:14:51 --> Router Class Initialized
INFO - 2024-10-15 11:14:51 --> Output Class Initialized
INFO - 2024-10-15 11:14:51 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:51 --> Input Class Initialized
INFO - 2024-10-15 11:14:51 --> Language Class Initialized
INFO - 2024-10-15 11:14:51 --> Language Class Initialized
INFO - 2024-10-15 11:14:51 --> Config Class Initialized
INFO - 2024-10-15 11:14:51 --> Loader Class Initialized
INFO - 2024-10-15 11:14:51 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:51 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:51 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:51 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:51 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:51 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:54 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:54 --> Total execution time: 2.9776
INFO - 2024-10-15 11:14:54 --> Config Class Initialized
INFO - 2024-10-15 11:14:54 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:54 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:54 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:54 --> URI Class Initialized
INFO - 2024-10-15 11:14:54 --> Router Class Initialized
INFO - 2024-10-15 11:14:54 --> Output Class Initialized
INFO - 2024-10-15 11:14:54 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:54 --> Input Class Initialized
INFO - 2024-10-15 11:14:54 --> Language Class Initialized
INFO - 2024-10-15 11:14:54 --> Language Class Initialized
INFO - 2024-10-15 11:14:54 --> Config Class Initialized
INFO - 2024-10-15 11:14:54 --> Loader Class Initialized
INFO - 2024-10-15 11:14:54 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:54 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:54 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:54 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:54 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:54 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:14:57 --> Final output sent to browser
DEBUG - 2024-10-15 11:14:57 --> Total execution time: 2.8384
INFO - 2024-10-15 11:14:57 --> Config Class Initialized
INFO - 2024-10-15 11:14:57 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:14:57 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:14:57 --> Utf8 Class Initialized
INFO - 2024-10-15 11:14:57 --> URI Class Initialized
INFO - 2024-10-15 11:14:57 --> Router Class Initialized
INFO - 2024-10-15 11:14:57 --> Output Class Initialized
INFO - 2024-10-15 11:14:57 --> Security Class Initialized
DEBUG - 2024-10-15 11:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:14:57 --> Input Class Initialized
INFO - 2024-10-15 11:14:57 --> Language Class Initialized
INFO - 2024-10-15 11:14:57 --> Language Class Initialized
INFO - 2024-10-15 11:14:57 --> Config Class Initialized
INFO - 2024-10-15 11:14:57 --> Loader Class Initialized
INFO - 2024-10-15 11:14:57 --> Helper loaded: url_helper
INFO - 2024-10-15 11:14:57 --> Helper loaded: file_helper
INFO - 2024-10-15 11:14:57 --> Helper loaded: form_helper
INFO - 2024-10-15 11:14:57 --> Helper loaded: my_helper
INFO - 2024-10-15 11:14:57 --> Database Driver Class Initialized
INFO - 2024-10-15 11:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:14:57 --> Controller Class Initialized
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:14:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:14:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:00 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:00 --> Total execution time: 3.0793
INFO - 2024-10-15 11:15:00 --> Config Class Initialized
INFO - 2024-10-15 11:15:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:00 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:00 --> URI Class Initialized
INFO - 2024-10-15 11:15:00 --> Router Class Initialized
INFO - 2024-10-15 11:15:00 --> Output Class Initialized
INFO - 2024-10-15 11:15:00 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:00 --> Input Class Initialized
INFO - 2024-10-15 11:15:00 --> Language Class Initialized
INFO - 2024-10-15 11:15:00 --> Language Class Initialized
INFO - 2024-10-15 11:15:00 --> Config Class Initialized
INFO - 2024-10-15 11:15:00 --> Loader Class Initialized
INFO - 2024-10-15 11:15:00 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:00 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:00 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:00 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:00 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:00 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:04 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:04 --> Total execution time: 3.6116
INFO - 2024-10-15 11:15:04 --> Config Class Initialized
INFO - 2024-10-15 11:15:04 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:04 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:04 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:04 --> URI Class Initialized
INFO - 2024-10-15 11:15:04 --> Router Class Initialized
INFO - 2024-10-15 11:15:04 --> Output Class Initialized
INFO - 2024-10-15 11:15:04 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:04 --> Input Class Initialized
INFO - 2024-10-15 11:15:04 --> Language Class Initialized
INFO - 2024-10-15 11:15:04 --> Language Class Initialized
INFO - 2024-10-15 11:15:04 --> Config Class Initialized
INFO - 2024-10-15 11:15:04 --> Loader Class Initialized
INFO - 2024-10-15 11:15:04 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:04 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:04 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:04 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:04 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:04 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:06 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:06 --> Total execution time: 2.8322
INFO - 2024-10-15 11:15:07 --> Config Class Initialized
INFO - 2024-10-15 11:15:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:07 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:07 --> URI Class Initialized
INFO - 2024-10-15 11:15:07 --> Router Class Initialized
INFO - 2024-10-15 11:15:07 --> Output Class Initialized
INFO - 2024-10-15 11:15:07 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:07 --> Input Class Initialized
INFO - 2024-10-15 11:15:07 --> Language Class Initialized
INFO - 2024-10-15 11:15:07 --> Language Class Initialized
INFO - 2024-10-15 11:15:07 --> Config Class Initialized
INFO - 2024-10-15 11:15:07 --> Loader Class Initialized
INFO - 2024-10-15 11:15:07 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:07 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:07 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:07 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:07 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:07 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:09 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:09 --> Total execution time: 2.7904
INFO - 2024-10-15 11:15:09 --> Config Class Initialized
INFO - 2024-10-15 11:15:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:09 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:09 --> URI Class Initialized
INFO - 2024-10-15 11:15:09 --> Router Class Initialized
INFO - 2024-10-15 11:15:09 --> Output Class Initialized
INFO - 2024-10-15 11:15:09 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:09 --> Input Class Initialized
INFO - 2024-10-15 11:15:09 --> Language Class Initialized
INFO - 2024-10-15 11:15:09 --> Language Class Initialized
INFO - 2024-10-15 11:15:09 --> Config Class Initialized
INFO - 2024-10-15 11:15:09 --> Loader Class Initialized
INFO - 2024-10-15 11:15:09 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:09 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:09 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:09 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:09 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:09 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:13 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:13 --> Total execution time: 3.6817
INFO - 2024-10-15 11:15:13 --> Config Class Initialized
INFO - 2024-10-15 11:15:13 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:13 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:13 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:13 --> URI Class Initialized
INFO - 2024-10-15 11:15:13 --> Router Class Initialized
INFO - 2024-10-15 11:15:13 --> Output Class Initialized
INFO - 2024-10-15 11:15:13 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:13 --> Input Class Initialized
INFO - 2024-10-15 11:15:13 --> Language Class Initialized
INFO - 2024-10-15 11:15:13 --> Language Class Initialized
INFO - 2024-10-15 11:15:13 --> Config Class Initialized
INFO - 2024-10-15 11:15:13 --> Loader Class Initialized
INFO - 2024-10-15 11:15:13 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:13 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:13 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:13 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:13 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:13 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:16 --> Total execution time: 2.8601
INFO - 2024-10-15 11:15:16 --> Config Class Initialized
INFO - 2024-10-15 11:15:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:16 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:16 --> URI Class Initialized
INFO - 2024-10-15 11:15:16 --> Router Class Initialized
INFO - 2024-10-15 11:15:16 --> Output Class Initialized
INFO - 2024-10-15 11:15:16 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:16 --> Input Class Initialized
INFO - 2024-10-15 11:15:16 --> Language Class Initialized
INFO - 2024-10-15 11:15:16 --> Language Class Initialized
INFO - 2024-10-15 11:15:16 --> Config Class Initialized
INFO - 2024-10-15 11:15:16 --> Loader Class Initialized
INFO - 2024-10-15 11:15:16 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:16 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:16 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:16 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:16 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:16 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:19 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:19 --> Total execution time: 2.7594
INFO - 2024-10-15 11:15:19 --> Config Class Initialized
INFO - 2024-10-15 11:15:19 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:19 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:19 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:19 --> URI Class Initialized
INFO - 2024-10-15 11:15:19 --> Router Class Initialized
INFO - 2024-10-15 11:15:19 --> Output Class Initialized
INFO - 2024-10-15 11:15:19 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:19 --> Input Class Initialized
INFO - 2024-10-15 11:15:19 --> Language Class Initialized
INFO - 2024-10-15 11:15:19 --> Language Class Initialized
INFO - 2024-10-15 11:15:19 --> Config Class Initialized
INFO - 2024-10-15 11:15:19 --> Loader Class Initialized
INFO - 2024-10-15 11:15:19 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:19 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:19 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:19 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:19 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:19 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:22 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:22 --> Total execution time: 2.8974
INFO - 2024-10-15 11:15:22 --> Config Class Initialized
INFO - 2024-10-15 11:15:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:22 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:22 --> URI Class Initialized
INFO - 2024-10-15 11:15:22 --> Router Class Initialized
INFO - 2024-10-15 11:15:22 --> Output Class Initialized
INFO - 2024-10-15 11:15:22 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:22 --> Input Class Initialized
INFO - 2024-10-15 11:15:22 --> Language Class Initialized
INFO - 2024-10-15 11:15:22 --> Language Class Initialized
INFO - 2024-10-15 11:15:22 --> Config Class Initialized
INFO - 2024-10-15 11:15:22 --> Loader Class Initialized
INFO - 2024-10-15 11:15:22 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:22 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:22 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:22 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:22 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:22 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:25 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:25 --> Total execution time: 2.8363
INFO - 2024-10-15 11:15:25 --> Config Class Initialized
INFO - 2024-10-15 11:15:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:25 --> URI Class Initialized
INFO - 2024-10-15 11:15:25 --> Router Class Initialized
INFO - 2024-10-15 11:15:25 --> Output Class Initialized
INFO - 2024-10-15 11:15:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:25 --> Input Class Initialized
INFO - 2024-10-15 11:15:25 --> Language Class Initialized
INFO - 2024-10-15 11:15:25 --> Language Class Initialized
INFO - 2024-10-15 11:15:25 --> Config Class Initialized
INFO - 2024-10-15 11:15:25 --> Loader Class Initialized
INFO - 2024-10-15 11:15:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:25 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:28 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:28 --> Total execution time: 2.7570
INFO - 2024-10-15 11:15:28 --> Config Class Initialized
INFO - 2024-10-15 11:15:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:28 --> URI Class Initialized
INFO - 2024-10-15 11:15:28 --> Router Class Initialized
INFO - 2024-10-15 11:15:28 --> Output Class Initialized
INFO - 2024-10-15 11:15:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:28 --> Input Class Initialized
INFO - 2024-10-15 11:15:28 --> Language Class Initialized
INFO - 2024-10-15 11:15:28 --> Language Class Initialized
INFO - 2024-10-15 11:15:28 --> Config Class Initialized
INFO - 2024-10-15 11:15:28 --> Loader Class Initialized
INFO - 2024-10-15 11:15:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:31 --> Total execution time: 2.8050
INFO - 2024-10-15 11:15:31 --> Config Class Initialized
INFO - 2024-10-15 11:15:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:31 --> URI Class Initialized
INFO - 2024-10-15 11:15:31 --> Router Class Initialized
INFO - 2024-10-15 11:15:31 --> Output Class Initialized
INFO - 2024-10-15 11:15:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:31 --> Input Class Initialized
INFO - 2024-10-15 11:15:31 --> Language Class Initialized
INFO - 2024-10-15 11:15:31 --> Language Class Initialized
INFO - 2024-10-15 11:15:31 --> Config Class Initialized
INFO - 2024-10-15 11:15:31 --> Loader Class Initialized
INFO - 2024-10-15 11:15:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:34 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:34 --> Total execution time: 3.0309
INFO - 2024-10-15 11:15:34 --> Config Class Initialized
INFO - 2024-10-15 11:15:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:34 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:34 --> URI Class Initialized
INFO - 2024-10-15 11:15:34 --> Router Class Initialized
INFO - 2024-10-15 11:15:34 --> Output Class Initialized
INFO - 2024-10-15 11:15:34 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:34 --> Input Class Initialized
INFO - 2024-10-15 11:15:34 --> Language Class Initialized
INFO - 2024-10-15 11:15:34 --> Language Class Initialized
INFO - 2024-10-15 11:15:34 --> Config Class Initialized
INFO - 2024-10-15 11:15:34 --> Loader Class Initialized
INFO - 2024-10-15 11:15:34 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:34 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:34 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:34 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:34 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:34 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:37 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:37 --> Total execution time: 2.8199
INFO - 2024-10-15 11:15:37 --> Config Class Initialized
INFO - 2024-10-15 11:15:37 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:37 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:37 --> URI Class Initialized
INFO - 2024-10-15 11:15:37 --> Router Class Initialized
INFO - 2024-10-15 11:15:37 --> Output Class Initialized
INFO - 2024-10-15 11:15:37 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:37 --> Input Class Initialized
INFO - 2024-10-15 11:15:37 --> Language Class Initialized
INFO - 2024-10-15 11:15:37 --> Language Class Initialized
INFO - 2024-10-15 11:15:37 --> Config Class Initialized
INFO - 2024-10-15 11:15:37 --> Loader Class Initialized
INFO - 2024-10-15 11:15:37 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:37 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:37 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:37 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:37 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:37 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:40 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:40 --> Total execution time: 2.8252
INFO - 2024-10-15 11:15:40 --> Config Class Initialized
INFO - 2024-10-15 11:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:40 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:40 --> URI Class Initialized
INFO - 2024-10-15 11:15:40 --> Router Class Initialized
INFO - 2024-10-15 11:15:40 --> Output Class Initialized
INFO - 2024-10-15 11:15:40 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:40 --> Input Class Initialized
INFO - 2024-10-15 11:15:40 --> Language Class Initialized
INFO - 2024-10-15 11:15:40 --> Language Class Initialized
INFO - 2024-10-15 11:15:40 --> Config Class Initialized
INFO - 2024-10-15 11:15:40 --> Loader Class Initialized
INFO - 2024-10-15 11:15:40 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:40 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:40 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:40 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:40 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:40 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:43 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:43 --> Total execution time: 2.6914
INFO - 2024-10-15 11:15:43 --> Config Class Initialized
INFO - 2024-10-15 11:15:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:43 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:43 --> URI Class Initialized
INFO - 2024-10-15 11:15:43 --> Router Class Initialized
INFO - 2024-10-15 11:15:43 --> Output Class Initialized
INFO - 2024-10-15 11:15:43 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:43 --> Input Class Initialized
INFO - 2024-10-15 11:15:43 --> Language Class Initialized
INFO - 2024-10-15 11:15:43 --> Language Class Initialized
INFO - 2024-10-15 11:15:43 --> Config Class Initialized
INFO - 2024-10-15 11:15:43 --> Loader Class Initialized
INFO - 2024-10-15 11:15:43 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:43 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:43 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:43 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:43 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:43 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:46 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:46 --> Total execution time: 2.8593
INFO - 2024-10-15 11:15:46 --> Config Class Initialized
INFO - 2024-10-15 11:15:46 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:46 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:46 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:46 --> URI Class Initialized
INFO - 2024-10-15 11:15:46 --> Router Class Initialized
INFO - 2024-10-15 11:15:46 --> Output Class Initialized
INFO - 2024-10-15 11:15:46 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:46 --> Input Class Initialized
INFO - 2024-10-15 11:15:46 --> Language Class Initialized
INFO - 2024-10-15 11:15:46 --> Language Class Initialized
INFO - 2024-10-15 11:15:46 --> Config Class Initialized
INFO - 2024-10-15 11:15:46 --> Loader Class Initialized
INFO - 2024-10-15 11:15:46 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:46 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:46 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:46 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:46 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:46 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:49 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:49 --> Total execution time: 2.9519
INFO - 2024-10-15 11:15:49 --> Config Class Initialized
INFO - 2024-10-15 11:15:49 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:49 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:49 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:49 --> URI Class Initialized
INFO - 2024-10-15 11:15:49 --> Router Class Initialized
INFO - 2024-10-15 11:15:49 --> Output Class Initialized
INFO - 2024-10-15 11:15:49 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:49 --> Input Class Initialized
INFO - 2024-10-15 11:15:49 --> Language Class Initialized
INFO - 2024-10-15 11:15:49 --> Language Class Initialized
INFO - 2024-10-15 11:15:49 --> Config Class Initialized
INFO - 2024-10-15 11:15:49 --> Loader Class Initialized
INFO - 2024-10-15 11:15:49 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:49 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:49 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:49 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:49 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:49 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:52 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:52 --> Total execution time: 2.7912
INFO - 2024-10-15 11:15:52 --> Config Class Initialized
INFO - 2024-10-15 11:15:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:52 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:52 --> URI Class Initialized
INFO - 2024-10-15 11:15:52 --> Router Class Initialized
INFO - 2024-10-15 11:15:52 --> Output Class Initialized
INFO - 2024-10-15 11:15:52 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:52 --> Input Class Initialized
INFO - 2024-10-15 11:15:52 --> Language Class Initialized
INFO - 2024-10-15 11:15:52 --> Language Class Initialized
INFO - 2024-10-15 11:15:52 --> Config Class Initialized
INFO - 2024-10-15 11:15:52 --> Loader Class Initialized
INFO - 2024-10-15 11:15:52 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:52 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:52 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:52 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:52 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:52 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:55 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:55 --> Total execution time: 2.7825
INFO - 2024-10-15 11:15:55 --> Config Class Initialized
INFO - 2024-10-15 11:15:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:55 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:55 --> URI Class Initialized
INFO - 2024-10-15 11:15:55 --> Router Class Initialized
INFO - 2024-10-15 11:15:55 --> Output Class Initialized
INFO - 2024-10-15 11:15:55 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:55 --> Input Class Initialized
INFO - 2024-10-15 11:15:55 --> Language Class Initialized
INFO - 2024-10-15 11:15:55 --> Language Class Initialized
INFO - 2024-10-15 11:15:55 --> Config Class Initialized
INFO - 2024-10-15 11:15:55 --> Loader Class Initialized
INFO - 2024-10-15 11:15:55 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:55 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:55 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:55 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:55 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:55 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:15:58 --> Final output sent to browser
DEBUG - 2024-10-15 11:15:58 --> Total execution time: 2.5836
INFO - 2024-10-15 11:15:58 --> Config Class Initialized
INFO - 2024-10-15 11:15:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:15:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:15:58 --> Utf8 Class Initialized
INFO - 2024-10-15 11:15:58 --> URI Class Initialized
INFO - 2024-10-15 11:15:58 --> Router Class Initialized
INFO - 2024-10-15 11:15:58 --> Output Class Initialized
INFO - 2024-10-15 11:15:58 --> Security Class Initialized
DEBUG - 2024-10-15 11:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:15:58 --> Input Class Initialized
INFO - 2024-10-15 11:15:58 --> Language Class Initialized
INFO - 2024-10-15 11:15:58 --> Language Class Initialized
INFO - 2024-10-15 11:15:58 --> Config Class Initialized
INFO - 2024-10-15 11:15:58 --> Loader Class Initialized
INFO - 2024-10-15 11:15:58 --> Helper loaded: url_helper
INFO - 2024-10-15 11:15:58 --> Helper loaded: file_helper
INFO - 2024-10-15 11:15:58 --> Helper loaded: form_helper
INFO - 2024-10-15 11:15:58 --> Helper loaded: my_helper
INFO - 2024-10-15 11:15:58 --> Database Driver Class Initialized
INFO - 2024-10-15 11:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:15:58 --> Controller Class Initialized
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:15:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:15:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:00 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:00 --> Total execution time: 2.5831
INFO - 2024-10-15 11:16:00 --> Config Class Initialized
INFO - 2024-10-15 11:16:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:00 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:00 --> URI Class Initialized
INFO - 2024-10-15 11:16:00 --> Router Class Initialized
INFO - 2024-10-15 11:16:00 --> Output Class Initialized
INFO - 2024-10-15 11:16:00 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:00 --> Input Class Initialized
INFO - 2024-10-15 11:16:00 --> Language Class Initialized
INFO - 2024-10-15 11:16:00 --> Language Class Initialized
INFO - 2024-10-15 11:16:00 --> Config Class Initialized
INFO - 2024-10-15 11:16:00 --> Loader Class Initialized
INFO - 2024-10-15 11:16:00 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:00 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:00 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:00 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:00 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:00 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:04 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:04 --> Total execution time: 3.5539
INFO - 2024-10-15 11:16:04 --> Config Class Initialized
INFO - 2024-10-15 11:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:04 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:04 --> URI Class Initialized
INFO - 2024-10-15 11:16:04 --> Router Class Initialized
INFO - 2024-10-15 11:16:04 --> Output Class Initialized
INFO - 2024-10-15 11:16:04 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:04 --> Input Class Initialized
INFO - 2024-10-15 11:16:04 --> Language Class Initialized
INFO - 2024-10-15 11:16:04 --> Language Class Initialized
INFO - 2024-10-15 11:16:04 --> Config Class Initialized
INFO - 2024-10-15 11:16:04 --> Loader Class Initialized
INFO - 2024-10-15 11:16:04 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:04 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:04 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:04 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:04 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:04 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:07 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:07 --> Total execution time: 2.9067
INFO - 2024-10-15 11:16:08 --> Config Class Initialized
INFO - 2024-10-15 11:16:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:08 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:08 --> URI Class Initialized
INFO - 2024-10-15 11:16:08 --> Router Class Initialized
INFO - 2024-10-15 11:16:08 --> Output Class Initialized
INFO - 2024-10-15 11:16:08 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:08 --> Input Class Initialized
INFO - 2024-10-15 11:16:08 --> Language Class Initialized
INFO - 2024-10-15 11:16:08 --> Language Class Initialized
INFO - 2024-10-15 11:16:08 --> Config Class Initialized
INFO - 2024-10-15 11:16:08 --> Loader Class Initialized
INFO - 2024-10-15 11:16:08 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:08 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:08 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:08 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:08 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:08 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:10 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:10 --> Total execution time: 2.9120
INFO - 2024-10-15 11:16:11 --> Config Class Initialized
INFO - 2024-10-15 11:16:11 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:11 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:11 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:11 --> URI Class Initialized
INFO - 2024-10-15 11:16:11 --> Router Class Initialized
INFO - 2024-10-15 11:16:11 --> Output Class Initialized
INFO - 2024-10-15 11:16:11 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:11 --> Input Class Initialized
INFO - 2024-10-15 11:16:11 --> Language Class Initialized
INFO - 2024-10-15 11:16:11 --> Language Class Initialized
INFO - 2024-10-15 11:16:11 --> Config Class Initialized
INFO - 2024-10-15 11:16:11 --> Loader Class Initialized
INFO - 2024-10-15 11:16:11 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:11 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:11 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:11 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:11 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:11 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:13 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:13 --> Total execution time: 2.6969
INFO - 2024-10-15 11:16:14 --> Config Class Initialized
INFO - 2024-10-15 11:16:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:14 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:14 --> URI Class Initialized
INFO - 2024-10-15 11:16:14 --> Router Class Initialized
INFO - 2024-10-15 11:16:14 --> Output Class Initialized
INFO - 2024-10-15 11:16:14 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:14 --> Input Class Initialized
INFO - 2024-10-15 11:16:14 --> Language Class Initialized
INFO - 2024-10-15 11:16:14 --> Language Class Initialized
INFO - 2024-10-15 11:16:14 --> Config Class Initialized
INFO - 2024-10-15 11:16:14 --> Loader Class Initialized
INFO - 2024-10-15 11:16:14 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:14 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:14 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:14 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:14 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:14 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:16 --> Total execution time: 2.6258
INFO - 2024-10-15 11:16:16 --> Config Class Initialized
INFO - 2024-10-15 11:16:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:16 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:16 --> URI Class Initialized
INFO - 2024-10-15 11:16:16 --> Router Class Initialized
INFO - 2024-10-15 11:16:16 --> Output Class Initialized
INFO - 2024-10-15 11:16:16 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:16 --> Input Class Initialized
INFO - 2024-10-15 11:16:16 --> Language Class Initialized
INFO - 2024-10-15 11:16:16 --> Language Class Initialized
INFO - 2024-10-15 11:16:16 --> Config Class Initialized
INFO - 2024-10-15 11:16:16 --> Loader Class Initialized
INFO - 2024-10-15 11:16:16 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:16 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:16 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:16 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:16 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:16 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:19 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:19 --> Total execution time: 2.5716
INFO - 2024-10-15 11:16:19 --> Config Class Initialized
INFO - 2024-10-15 11:16:19 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:19 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:19 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:19 --> URI Class Initialized
INFO - 2024-10-15 11:16:19 --> Router Class Initialized
INFO - 2024-10-15 11:16:19 --> Output Class Initialized
INFO - 2024-10-15 11:16:19 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:19 --> Input Class Initialized
INFO - 2024-10-15 11:16:19 --> Language Class Initialized
INFO - 2024-10-15 11:16:19 --> Language Class Initialized
INFO - 2024-10-15 11:16:19 --> Config Class Initialized
INFO - 2024-10-15 11:16:19 --> Loader Class Initialized
INFO - 2024-10-15 11:16:19 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:19 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:19 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:19 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:19 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:19 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:22 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:22 --> Total execution time: 2.6032
INFO - 2024-10-15 11:16:22 --> Config Class Initialized
INFO - 2024-10-15 11:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:22 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:22 --> URI Class Initialized
INFO - 2024-10-15 11:16:22 --> Router Class Initialized
INFO - 2024-10-15 11:16:22 --> Output Class Initialized
INFO - 2024-10-15 11:16:22 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:22 --> Input Class Initialized
INFO - 2024-10-15 11:16:22 --> Language Class Initialized
INFO - 2024-10-15 11:16:22 --> Language Class Initialized
INFO - 2024-10-15 11:16:22 --> Config Class Initialized
INFO - 2024-10-15 11:16:22 --> Loader Class Initialized
INFO - 2024-10-15 11:16:22 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:22 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:22 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:22 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:22 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:22 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:25 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:25 --> Total execution time: 2.8097
INFO - 2024-10-15 11:16:25 --> Config Class Initialized
INFO - 2024-10-15 11:16:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:25 --> URI Class Initialized
INFO - 2024-10-15 11:16:25 --> Router Class Initialized
INFO - 2024-10-15 11:16:25 --> Output Class Initialized
INFO - 2024-10-15 11:16:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:25 --> Input Class Initialized
INFO - 2024-10-15 11:16:25 --> Language Class Initialized
INFO - 2024-10-15 11:16:25 --> Language Class Initialized
INFO - 2024-10-15 11:16:25 --> Config Class Initialized
INFO - 2024-10-15 11:16:25 --> Loader Class Initialized
INFO - 2024-10-15 11:16:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:25 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:28 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:28 --> Total execution time: 2.6935
INFO - 2024-10-15 11:16:28 --> Config Class Initialized
INFO - 2024-10-15 11:16:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:28 --> URI Class Initialized
INFO - 2024-10-15 11:16:28 --> Router Class Initialized
INFO - 2024-10-15 11:16:28 --> Output Class Initialized
INFO - 2024-10-15 11:16:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:28 --> Input Class Initialized
INFO - 2024-10-15 11:16:28 --> Language Class Initialized
INFO - 2024-10-15 11:16:28 --> Language Class Initialized
INFO - 2024-10-15 11:16:28 --> Config Class Initialized
INFO - 2024-10-15 11:16:28 --> Loader Class Initialized
INFO - 2024-10-15 11:16:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:31 --> Total execution time: 2.5488
INFO - 2024-10-15 11:16:31 --> Config Class Initialized
INFO - 2024-10-15 11:16:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:31 --> URI Class Initialized
INFO - 2024-10-15 11:16:31 --> Router Class Initialized
INFO - 2024-10-15 11:16:31 --> Output Class Initialized
INFO - 2024-10-15 11:16:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:31 --> Input Class Initialized
INFO - 2024-10-15 11:16:31 --> Language Class Initialized
INFO - 2024-10-15 11:16:31 --> Language Class Initialized
INFO - 2024-10-15 11:16:31 --> Config Class Initialized
INFO - 2024-10-15 11:16:31 --> Loader Class Initialized
INFO - 2024-10-15 11:16:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:34 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:34 --> Total execution time: 2.7436
INFO - 2024-10-15 11:16:34 --> Config Class Initialized
INFO - 2024-10-15 11:16:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:34 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:34 --> URI Class Initialized
INFO - 2024-10-15 11:16:34 --> Router Class Initialized
INFO - 2024-10-15 11:16:34 --> Output Class Initialized
INFO - 2024-10-15 11:16:34 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:34 --> Input Class Initialized
INFO - 2024-10-15 11:16:34 --> Language Class Initialized
INFO - 2024-10-15 11:16:34 --> Language Class Initialized
INFO - 2024-10-15 11:16:34 --> Config Class Initialized
INFO - 2024-10-15 11:16:34 --> Loader Class Initialized
INFO - 2024-10-15 11:16:34 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:34 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:34 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:34 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:34 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:34 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:37 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:37 --> Total execution time: 2.7737
INFO - 2024-10-15 11:16:37 --> Config Class Initialized
INFO - 2024-10-15 11:16:37 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:37 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:37 --> URI Class Initialized
INFO - 2024-10-15 11:16:37 --> Router Class Initialized
INFO - 2024-10-15 11:16:37 --> Output Class Initialized
INFO - 2024-10-15 11:16:37 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:37 --> Input Class Initialized
INFO - 2024-10-15 11:16:37 --> Language Class Initialized
INFO - 2024-10-15 11:16:37 --> Language Class Initialized
INFO - 2024-10-15 11:16:37 --> Config Class Initialized
INFO - 2024-10-15 11:16:37 --> Loader Class Initialized
INFO - 2024-10-15 11:16:37 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:37 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:37 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:37 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:37 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:37 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:40 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:40 --> Total execution time: 2.6895
INFO - 2024-10-15 11:16:40 --> Config Class Initialized
INFO - 2024-10-15 11:16:40 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:40 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:40 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:40 --> URI Class Initialized
INFO - 2024-10-15 11:16:40 --> Router Class Initialized
INFO - 2024-10-15 11:16:40 --> Output Class Initialized
INFO - 2024-10-15 11:16:40 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:40 --> Input Class Initialized
INFO - 2024-10-15 11:16:40 --> Language Class Initialized
INFO - 2024-10-15 11:16:40 --> Language Class Initialized
INFO - 2024-10-15 11:16:40 --> Config Class Initialized
INFO - 2024-10-15 11:16:40 --> Loader Class Initialized
INFO - 2024-10-15 11:16:40 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:40 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:40 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:40 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:40 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:40 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:43 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:43 --> Total execution time: 2.8559
INFO - 2024-10-15 11:16:43 --> Config Class Initialized
INFO - 2024-10-15 11:16:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:43 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:43 --> URI Class Initialized
INFO - 2024-10-15 11:16:43 --> Router Class Initialized
INFO - 2024-10-15 11:16:43 --> Output Class Initialized
INFO - 2024-10-15 11:16:43 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:43 --> Input Class Initialized
INFO - 2024-10-15 11:16:43 --> Language Class Initialized
INFO - 2024-10-15 11:16:43 --> Language Class Initialized
INFO - 2024-10-15 11:16:43 --> Config Class Initialized
INFO - 2024-10-15 11:16:43 --> Loader Class Initialized
INFO - 2024-10-15 11:16:43 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:43 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:43 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:43 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:43 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:43 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:46 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:46 --> Total execution time: 2.8848
INFO - 2024-10-15 11:16:46 --> Config Class Initialized
INFO - 2024-10-15 11:16:46 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:46 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:46 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:46 --> URI Class Initialized
INFO - 2024-10-15 11:16:46 --> Router Class Initialized
INFO - 2024-10-15 11:16:46 --> Output Class Initialized
INFO - 2024-10-15 11:16:46 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:46 --> Input Class Initialized
INFO - 2024-10-15 11:16:46 --> Language Class Initialized
INFO - 2024-10-15 11:16:46 --> Language Class Initialized
INFO - 2024-10-15 11:16:46 --> Config Class Initialized
INFO - 2024-10-15 11:16:46 --> Loader Class Initialized
INFO - 2024-10-15 11:16:46 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:46 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:46 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:46 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:46 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:46 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:49 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:49 --> Total execution time: 2.6265
INFO - 2024-10-15 11:16:49 --> Config Class Initialized
INFO - 2024-10-15 11:16:49 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:49 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:49 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:49 --> URI Class Initialized
INFO - 2024-10-15 11:16:49 --> Router Class Initialized
INFO - 2024-10-15 11:16:49 --> Output Class Initialized
INFO - 2024-10-15 11:16:49 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:49 --> Input Class Initialized
INFO - 2024-10-15 11:16:49 --> Language Class Initialized
INFO - 2024-10-15 11:16:49 --> Language Class Initialized
INFO - 2024-10-15 11:16:49 --> Config Class Initialized
INFO - 2024-10-15 11:16:49 --> Loader Class Initialized
INFO - 2024-10-15 11:16:49 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:49 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:49 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:49 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:49 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:49 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:52 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:52 --> Total execution time: 3.0351
INFO - 2024-10-15 11:16:52 --> Config Class Initialized
INFO - 2024-10-15 11:16:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:52 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:52 --> URI Class Initialized
INFO - 2024-10-15 11:16:52 --> Router Class Initialized
INFO - 2024-10-15 11:16:52 --> Output Class Initialized
INFO - 2024-10-15 11:16:52 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:52 --> Input Class Initialized
INFO - 2024-10-15 11:16:52 --> Language Class Initialized
INFO - 2024-10-15 11:16:52 --> Language Class Initialized
INFO - 2024-10-15 11:16:52 --> Config Class Initialized
INFO - 2024-10-15 11:16:52 --> Loader Class Initialized
INFO - 2024-10-15 11:16:52 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:52 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:52 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:52 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:52 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:52 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:16:57 --> Final output sent to browser
DEBUG - 2024-10-15 11:16:57 --> Total execution time: 5.1319
INFO - 2024-10-15 11:16:58 --> Config Class Initialized
INFO - 2024-10-15 11:16:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:16:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:16:58 --> Utf8 Class Initialized
INFO - 2024-10-15 11:16:58 --> URI Class Initialized
INFO - 2024-10-15 11:16:58 --> Router Class Initialized
INFO - 2024-10-15 11:16:58 --> Output Class Initialized
INFO - 2024-10-15 11:16:58 --> Security Class Initialized
DEBUG - 2024-10-15 11:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:16:58 --> Input Class Initialized
INFO - 2024-10-15 11:16:58 --> Language Class Initialized
INFO - 2024-10-15 11:16:58 --> Language Class Initialized
INFO - 2024-10-15 11:16:58 --> Config Class Initialized
INFO - 2024-10-15 11:16:58 --> Loader Class Initialized
INFO - 2024-10-15 11:16:58 --> Helper loaded: url_helper
INFO - 2024-10-15 11:16:58 --> Helper loaded: file_helper
INFO - 2024-10-15 11:16:58 --> Helper loaded: form_helper
INFO - 2024-10-15 11:16:58 --> Helper loaded: my_helper
INFO - 2024-10-15 11:16:58 --> Database Driver Class Initialized
INFO - 2024-10-15 11:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:16:58 --> Controller Class Initialized
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:16:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:00 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:00 --> Total execution time: 2.6048
INFO - 2024-10-15 11:17:01 --> Config Class Initialized
INFO - 2024-10-15 11:17:01 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:01 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:01 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:01 --> URI Class Initialized
INFO - 2024-10-15 11:17:01 --> Router Class Initialized
INFO - 2024-10-15 11:17:01 --> Output Class Initialized
INFO - 2024-10-15 11:17:01 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:01 --> Input Class Initialized
INFO - 2024-10-15 11:17:01 --> Language Class Initialized
INFO - 2024-10-15 11:17:01 --> Language Class Initialized
INFO - 2024-10-15 11:17:01 --> Config Class Initialized
INFO - 2024-10-15 11:17:01 --> Loader Class Initialized
INFO - 2024-10-15 11:17:01 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:01 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:01 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:01 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:01 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:01 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:04 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:04 --> Total execution time: 3.3493
INFO - 2024-10-15 11:17:04 --> Config Class Initialized
INFO - 2024-10-15 11:17:04 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:04 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:04 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:04 --> URI Class Initialized
INFO - 2024-10-15 11:17:04 --> Router Class Initialized
INFO - 2024-10-15 11:17:04 --> Output Class Initialized
INFO - 2024-10-15 11:17:04 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:04 --> Input Class Initialized
INFO - 2024-10-15 11:17:04 --> Language Class Initialized
INFO - 2024-10-15 11:17:04 --> Language Class Initialized
INFO - 2024-10-15 11:17:04 --> Config Class Initialized
INFO - 2024-10-15 11:17:04 --> Loader Class Initialized
INFO - 2024-10-15 11:17:04 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:04 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:04 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:04 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:04 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:04 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:07 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:07 --> Total execution time: 2.7193
INFO - 2024-10-15 11:17:07 --> Config Class Initialized
INFO - 2024-10-15 11:17:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:07 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:07 --> URI Class Initialized
INFO - 2024-10-15 11:17:07 --> Router Class Initialized
INFO - 2024-10-15 11:17:07 --> Output Class Initialized
INFO - 2024-10-15 11:17:07 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:07 --> Input Class Initialized
INFO - 2024-10-15 11:17:07 --> Language Class Initialized
INFO - 2024-10-15 11:17:07 --> Language Class Initialized
INFO - 2024-10-15 11:17:07 --> Config Class Initialized
INFO - 2024-10-15 11:17:07 --> Loader Class Initialized
INFO - 2024-10-15 11:17:07 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:07 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:07 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:07 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:07 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:07 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:10 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:10 --> Total execution time: 2.8974
INFO - 2024-10-15 11:17:10 --> Config Class Initialized
INFO - 2024-10-15 11:17:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:10 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:10 --> URI Class Initialized
INFO - 2024-10-15 11:17:10 --> Router Class Initialized
INFO - 2024-10-15 11:17:10 --> Output Class Initialized
INFO - 2024-10-15 11:17:10 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:10 --> Input Class Initialized
INFO - 2024-10-15 11:17:10 --> Language Class Initialized
INFO - 2024-10-15 11:17:10 --> Language Class Initialized
INFO - 2024-10-15 11:17:10 --> Config Class Initialized
INFO - 2024-10-15 11:17:10 --> Loader Class Initialized
INFO - 2024-10-15 11:17:10 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:10 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:10 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:10 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:10 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:10 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:13 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:13 --> Total execution time: 2.8531
INFO - 2024-10-15 11:17:14 --> Config Class Initialized
INFO - 2024-10-15 11:17:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:14 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:14 --> URI Class Initialized
INFO - 2024-10-15 11:17:14 --> Router Class Initialized
INFO - 2024-10-15 11:17:14 --> Output Class Initialized
INFO - 2024-10-15 11:17:14 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:14 --> Input Class Initialized
INFO - 2024-10-15 11:17:14 --> Language Class Initialized
INFO - 2024-10-15 11:17:14 --> Language Class Initialized
INFO - 2024-10-15 11:17:14 --> Config Class Initialized
INFO - 2024-10-15 11:17:14 --> Loader Class Initialized
INFO - 2024-10-15 11:17:14 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:14 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:14 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:14 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:14 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:14 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:16 --> Total execution time: 2.7183
INFO - 2024-10-15 11:17:17 --> Config Class Initialized
INFO - 2024-10-15 11:17:17 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:17 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:17 --> URI Class Initialized
INFO - 2024-10-15 11:17:17 --> Router Class Initialized
INFO - 2024-10-15 11:17:17 --> Output Class Initialized
INFO - 2024-10-15 11:17:17 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:17 --> Input Class Initialized
INFO - 2024-10-15 11:17:17 --> Language Class Initialized
INFO - 2024-10-15 11:17:17 --> Language Class Initialized
INFO - 2024-10-15 11:17:17 --> Config Class Initialized
INFO - 2024-10-15 11:17:17 --> Loader Class Initialized
INFO - 2024-10-15 11:17:17 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:17 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:17 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:17 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:17 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:17 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:19 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:19 --> Total execution time: 2.6225
INFO - 2024-10-15 11:17:19 --> Config Class Initialized
INFO - 2024-10-15 11:17:19 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:19 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:19 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:19 --> URI Class Initialized
INFO - 2024-10-15 11:17:19 --> Router Class Initialized
INFO - 2024-10-15 11:17:19 --> Output Class Initialized
INFO - 2024-10-15 11:17:19 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:19 --> Input Class Initialized
INFO - 2024-10-15 11:17:19 --> Language Class Initialized
INFO - 2024-10-15 11:17:19 --> Language Class Initialized
INFO - 2024-10-15 11:17:19 --> Config Class Initialized
INFO - 2024-10-15 11:17:19 --> Loader Class Initialized
INFO - 2024-10-15 11:17:19 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:19 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:19 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:19 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:19 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:19 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:22 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:22 --> Total execution time: 2.6043
INFO - 2024-10-15 11:17:22 --> Config Class Initialized
INFO - 2024-10-15 11:17:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:22 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:22 --> URI Class Initialized
INFO - 2024-10-15 11:17:22 --> Router Class Initialized
INFO - 2024-10-15 11:17:22 --> Output Class Initialized
INFO - 2024-10-15 11:17:22 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:22 --> Input Class Initialized
INFO - 2024-10-15 11:17:22 --> Language Class Initialized
INFO - 2024-10-15 11:17:22 --> Language Class Initialized
INFO - 2024-10-15 11:17:22 --> Config Class Initialized
INFO - 2024-10-15 11:17:22 --> Loader Class Initialized
INFO - 2024-10-15 11:17:22 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:22 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:22 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:22 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:22 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:22 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:25 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:25 --> Total execution time: 2.7026
INFO - 2024-10-15 11:17:25 --> Config Class Initialized
INFO - 2024-10-15 11:17:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:25 --> URI Class Initialized
INFO - 2024-10-15 11:17:25 --> Router Class Initialized
INFO - 2024-10-15 11:17:25 --> Output Class Initialized
INFO - 2024-10-15 11:17:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:25 --> Input Class Initialized
INFO - 2024-10-15 11:17:25 --> Language Class Initialized
INFO - 2024-10-15 11:17:25 --> Language Class Initialized
INFO - 2024-10-15 11:17:25 --> Config Class Initialized
INFO - 2024-10-15 11:17:25 --> Loader Class Initialized
INFO - 2024-10-15 11:17:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:25 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:28 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:28 --> Total execution time: 2.5406
INFO - 2024-10-15 11:17:28 --> Config Class Initialized
INFO - 2024-10-15 11:17:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:28 --> URI Class Initialized
INFO - 2024-10-15 11:17:28 --> Router Class Initialized
INFO - 2024-10-15 11:17:28 --> Output Class Initialized
INFO - 2024-10-15 11:17:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:28 --> Input Class Initialized
INFO - 2024-10-15 11:17:28 --> Language Class Initialized
INFO - 2024-10-15 11:17:28 --> Language Class Initialized
INFO - 2024-10-15 11:17:28 --> Config Class Initialized
INFO - 2024-10-15 11:17:28 --> Loader Class Initialized
INFO - 2024-10-15 11:17:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:30 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:30 --> Total execution time: 2.6837
INFO - 2024-10-15 11:17:31 --> Config Class Initialized
INFO - 2024-10-15 11:17:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:31 --> URI Class Initialized
INFO - 2024-10-15 11:17:31 --> Router Class Initialized
INFO - 2024-10-15 11:17:31 --> Output Class Initialized
INFO - 2024-10-15 11:17:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:31 --> Input Class Initialized
INFO - 2024-10-15 11:17:31 --> Language Class Initialized
INFO - 2024-10-15 11:17:31 --> Language Class Initialized
INFO - 2024-10-15 11:17:31 --> Config Class Initialized
INFO - 2024-10-15 11:17:31 --> Loader Class Initialized
INFO - 2024-10-15 11:17:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:33 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:33 --> Total execution time: 2.6967
INFO - 2024-10-15 11:17:34 --> Config Class Initialized
INFO - 2024-10-15 11:17:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:34 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:34 --> URI Class Initialized
INFO - 2024-10-15 11:17:34 --> Router Class Initialized
INFO - 2024-10-15 11:17:34 --> Output Class Initialized
INFO - 2024-10-15 11:17:34 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:34 --> Input Class Initialized
INFO - 2024-10-15 11:17:34 --> Language Class Initialized
INFO - 2024-10-15 11:17:34 --> Language Class Initialized
INFO - 2024-10-15 11:17:34 --> Config Class Initialized
INFO - 2024-10-15 11:17:34 --> Loader Class Initialized
INFO - 2024-10-15 11:17:34 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:34 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:34 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:34 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:34 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:34 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:36 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:36 --> Total execution time: 2.7002
INFO - 2024-10-15 11:17:37 --> Config Class Initialized
INFO - 2024-10-15 11:17:37 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:37 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:37 --> URI Class Initialized
INFO - 2024-10-15 11:17:37 --> Router Class Initialized
INFO - 2024-10-15 11:17:37 --> Output Class Initialized
INFO - 2024-10-15 11:17:37 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:37 --> Input Class Initialized
INFO - 2024-10-15 11:17:37 --> Language Class Initialized
INFO - 2024-10-15 11:17:37 --> Language Class Initialized
INFO - 2024-10-15 11:17:37 --> Config Class Initialized
INFO - 2024-10-15 11:17:37 --> Loader Class Initialized
INFO - 2024-10-15 11:17:37 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:37 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:37 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:37 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:37 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:37 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:39 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:39 --> Total execution time: 2.5350
INFO - 2024-10-15 11:17:39 --> Config Class Initialized
INFO - 2024-10-15 11:17:39 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:39 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:39 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:39 --> URI Class Initialized
INFO - 2024-10-15 11:17:39 --> Router Class Initialized
INFO - 2024-10-15 11:17:39 --> Output Class Initialized
INFO - 2024-10-15 11:17:39 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:39 --> Input Class Initialized
INFO - 2024-10-15 11:17:39 --> Language Class Initialized
INFO - 2024-10-15 11:17:39 --> Language Class Initialized
INFO - 2024-10-15 11:17:39 --> Config Class Initialized
INFO - 2024-10-15 11:17:39 --> Loader Class Initialized
INFO - 2024-10-15 11:17:39 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:39 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:39 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:39 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:39 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:39 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:42 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:42 --> Total execution time: 2.4991
INFO - 2024-10-15 11:17:42 --> Config Class Initialized
INFO - 2024-10-15 11:17:42 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:42 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:42 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:42 --> URI Class Initialized
INFO - 2024-10-15 11:17:42 --> Router Class Initialized
INFO - 2024-10-15 11:17:42 --> Output Class Initialized
INFO - 2024-10-15 11:17:42 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:42 --> Input Class Initialized
INFO - 2024-10-15 11:17:42 --> Language Class Initialized
INFO - 2024-10-15 11:17:42 --> Language Class Initialized
INFO - 2024-10-15 11:17:42 --> Config Class Initialized
INFO - 2024-10-15 11:17:42 --> Loader Class Initialized
INFO - 2024-10-15 11:17:42 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:42 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:42 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:42 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:42 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:42 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:45 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:45 --> Total execution time: 2.5926
INFO - 2024-10-15 11:17:45 --> Config Class Initialized
INFO - 2024-10-15 11:17:45 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:45 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:45 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:45 --> URI Class Initialized
INFO - 2024-10-15 11:17:45 --> Router Class Initialized
INFO - 2024-10-15 11:17:45 --> Output Class Initialized
INFO - 2024-10-15 11:17:45 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:45 --> Input Class Initialized
INFO - 2024-10-15 11:17:45 --> Language Class Initialized
INFO - 2024-10-15 11:17:45 --> Language Class Initialized
INFO - 2024-10-15 11:17:45 --> Config Class Initialized
INFO - 2024-10-15 11:17:45 --> Loader Class Initialized
INFO - 2024-10-15 11:17:45 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:45 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:45 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:45 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:45 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:45 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:48 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:48 --> Total execution time: 2.6401
INFO - 2024-10-15 11:17:48 --> Config Class Initialized
INFO - 2024-10-15 11:17:48 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:48 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:48 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:48 --> URI Class Initialized
INFO - 2024-10-15 11:17:48 --> Router Class Initialized
INFO - 2024-10-15 11:17:48 --> Output Class Initialized
INFO - 2024-10-15 11:17:48 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:48 --> Input Class Initialized
INFO - 2024-10-15 11:17:48 --> Language Class Initialized
INFO - 2024-10-15 11:17:48 --> Language Class Initialized
INFO - 2024-10-15 11:17:48 --> Config Class Initialized
INFO - 2024-10-15 11:17:48 --> Loader Class Initialized
INFO - 2024-10-15 11:17:48 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:48 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:48 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:48 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:48 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:48 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:51 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:51 --> Total execution time: 2.7950
INFO - 2024-10-15 11:17:51 --> Config Class Initialized
INFO - 2024-10-15 11:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:51 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:51 --> URI Class Initialized
INFO - 2024-10-15 11:17:51 --> Router Class Initialized
INFO - 2024-10-15 11:17:51 --> Output Class Initialized
INFO - 2024-10-15 11:17:51 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:51 --> Input Class Initialized
INFO - 2024-10-15 11:17:51 --> Language Class Initialized
INFO - 2024-10-15 11:17:51 --> Language Class Initialized
INFO - 2024-10-15 11:17:51 --> Config Class Initialized
INFO - 2024-10-15 11:17:51 --> Loader Class Initialized
INFO - 2024-10-15 11:17:51 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:51 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:51 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:51 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:51 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:51 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:53 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:53 --> Total execution time: 2.6372
INFO - 2024-10-15 11:17:54 --> Config Class Initialized
INFO - 2024-10-15 11:17:54 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:54 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:54 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:54 --> URI Class Initialized
INFO - 2024-10-15 11:17:54 --> Router Class Initialized
INFO - 2024-10-15 11:17:54 --> Output Class Initialized
INFO - 2024-10-15 11:17:54 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:54 --> Input Class Initialized
INFO - 2024-10-15 11:17:54 --> Language Class Initialized
INFO - 2024-10-15 11:17:54 --> Language Class Initialized
INFO - 2024-10-15 11:17:54 --> Config Class Initialized
INFO - 2024-10-15 11:17:54 --> Loader Class Initialized
INFO - 2024-10-15 11:17:54 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:54 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:54 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:54 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:54 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:54 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:17:57 --> Final output sent to browser
DEBUG - 2024-10-15 11:17:57 --> Total execution time: 2.8795
INFO - 2024-10-15 11:17:57 --> Config Class Initialized
INFO - 2024-10-15 11:17:57 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:17:57 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:17:57 --> Utf8 Class Initialized
INFO - 2024-10-15 11:17:57 --> URI Class Initialized
INFO - 2024-10-15 11:17:57 --> Router Class Initialized
INFO - 2024-10-15 11:17:57 --> Output Class Initialized
INFO - 2024-10-15 11:17:57 --> Security Class Initialized
DEBUG - 2024-10-15 11:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:17:57 --> Input Class Initialized
INFO - 2024-10-15 11:17:57 --> Language Class Initialized
INFO - 2024-10-15 11:17:57 --> Language Class Initialized
INFO - 2024-10-15 11:17:57 --> Config Class Initialized
INFO - 2024-10-15 11:17:57 --> Loader Class Initialized
INFO - 2024-10-15 11:17:57 --> Helper loaded: url_helper
INFO - 2024-10-15 11:17:57 --> Helper loaded: file_helper
INFO - 2024-10-15 11:17:57 --> Helper loaded: form_helper
INFO - 2024-10-15 11:17:57 --> Helper loaded: my_helper
INFO - 2024-10-15 11:17:57 --> Database Driver Class Initialized
INFO - 2024-10-15 11:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:17:57 --> Controller Class Initialized
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:17:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:00 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:00 --> Total execution time: 2.6047
INFO - 2024-10-15 11:18:00 --> Config Class Initialized
INFO - 2024-10-15 11:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:00 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:00 --> URI Class Initialized
INFO - 2024-10-15 11:18:00 --> Router Class Initialized
INFO - 2024-10-15 11:18:00 --> Output Class Initialized
INFO - 2024-10-15 11:18:00 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:00 --> Input Class Initialized
INFO - 2024-10-15 11:18:00 --> Language Class Initialized
INFO - 2024-10-15 11:18:00 --> Language Class Initialized
INFO - 2024-10-15 11:18:00 --> Config Class Initialized
INFO - 2024-10-15 11:18:00 --> Loader Class Initialized
INFO - 2024-10-15 11:18:00 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:00 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:00 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:00 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:00 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:00 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:03 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:03 --> Total execution time: 3.2643
INFO - 2024-10-15 11:18:03 --> Config Class Initialized
INFO - 2024-10-15 11:18:03 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:03 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:03 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:03 --> URI Class Initialized
INFO - 2024-10-15 11:18:03 --> Router Class Initialized
INFO - 2024-10-15 11:18:03 --> Output Class Initialized
INFO - 2024-10-15 11:18:03 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:03 --> Input Class Initialized
INFO - 2024-10-15 11:18:03 --> Language Class Initialized
INFO - 2024-10-15 11:18:03 --> Language Class Initialized
INFO - 2024-10-15 11:18:03 --> Config Class Initialized
INFO - 2024-10-15 11:18:03 --> Loader Class Initialized
INFO - 2024-10-15 11:18:03 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:03 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:03 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:03 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:03 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:03 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:06 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:06 --> Total execution time: 3.0947
INFO - 2024-10-15 11:18:07 --> Config Class Initialized
INFO - 2024-10-15 11:18:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:07 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:07 --> URI Class Initialized
INFO - 2024-10-15 11:18:07 --> Router Class Initialized
INFO - 2024-10-15 11:18:07 --> Output Class Initialized
INFO - 2024-10-15 11:18:07 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:07 --> Input Class Initialized
INFO - 2024-10-15 11:18:07 --> Language Class Initialized
INFO - 2024-10-15 11:18:07 --> Language Class Initialized
INFO - 2024-10-15 11:18:07 --> Config Class Initialized
INFO - 2024-10-15 11:18:07 --> Loader Class Initialized
INFO - 2024-10-15 11:18:07 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:07 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:07 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:07 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:07 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:07 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:10 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:10 --> Total execution time: 2.8633
INFO - 2024-10-15 11:18:10 --> Config Class Initialized
INFO - 2024-10-15 11:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:10 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:10 --> URI Class Initialized
INFO - 2024-10-15 11:18:10 --> Router Class Initialized
INFO - 2024-10-15 11:18:10 --> Output Class Initialized
INFO - 2024-10-15 11:18:10 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:10 --> Input Class Initialized
INFO - 2024-10-15 11:18:10 --> Language Class Initialized
INFO - 2024-10-15 11:18:10 --> Language Class Initialized
INFO - 2024-10-15 11:18:10 --> Config Class Initialized
INFO - 2024-10-15 11:18:10 --> Loader Class Initialized
INFO - 2024-10-15 11:18:10 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:10 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:10 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:10 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:10 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:10 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:13 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:13 --> Total execution time: 2.7452
INFO - 2024-10-15 11:18:13 --> Config Class Initialized
INFO - 2024-10-15 11:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:13 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:13 --> URI Class Initialized
INFO - 2024-10-15 11:18:13 --> Router Class Initialized
INFO - 2024-10-15 11:18:13 --> Output Class Initialized
INFO - 2024-10-15 11:18:13 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:13 --> Input Class Initialized
INFO - 2024-10-15 11:18:13 --> Language Class Initialized
INFO - 2024-10-15 11:18:13 --> Language Class Initialized
INFO - 2024-10-15 11:18:13 --> Config Class Initialized
INFO - 2024-10-15 11:18:13 --> Loader Class Initialized
INFO - 2024-10-15 11:18:13 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:13 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:13 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:13 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:13 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:13 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:16 --> Total execution time: 2.8141
INFO - 2024-10-15 11:18:17 --> Config Class Initialized
INFO - 2024-10-15 11:18:17 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:17 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:17 --> URI Class Initialized
INFO - 2024-10-15 11:18:17 --> Router Class Initialized
INFO - 2024-10-15 11:18:17 --> Output Class Initialized
INFO - 2024-10-15 11:18:17 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:17 --> Input Class Initialized
INFO - 2024-10-15 11:18:17 --> Language Class Initialized
INFO - 2024-10-15 11:18:17 --> Language Class Initialized
INFO - 2024-10-15 11:18:17 --> Config Class Initialized
INFO - 2024-10-15 11:18:17 --> Loader Class Initialized
INFO - 2024-10-15 11:18:17 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:17 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:17 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:17 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:17 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:17 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:20 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:20 --> Total execution time: 2.7299
INFO - 2024-10-15 11:18:20 --> Config Class Initialized
INFO - 2024-10-15 11:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:20 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:20 --> URI Class Initialized
INFO - 2024-10-15 11:18:20 --> Router Class Initialized
INFO - 2024-10-15 11:18:20 --> Output Class Initialized
INFO - 2024-10-15 11:18:20 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:20 --> Input Class Initialized
INFO - 2024-10-15 11:18:20 --> Language Class Initialized
INFO - 2024-10-15 11:18:20 --> Language Class Initialized
INFO - 2024-10-15 11:18:20 --> Config Class Initialized
INFO - 2024-10-15 11:18:20 --> Loader Class Initialized
INFO - 2024-10-15 11:18:20 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:20 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:20 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:20 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:20 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:20 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:23 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:23 --> Total execution time: 2.8546
INFO - 2024-10-15 11:18:23 --> Config Class Initialized
INFO - 2024-10-15 11:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:23 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:23 --> URI Class Initialized
INFO - 2024-10-15 11:18:23 --> Router Class Initialized
INFO - 2024-10-15 11:18:23 --> Output Class Initialized
INFO - 2024-10-15 11:18:23 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:23 --> Input Class Initialized
INFO - 2024-10-15 11:18:23 --> Language Class Initialized
INFO - 2024-10-15 11:18:23 --> Language Class Initialized
INFO - 2024-10-15 11:18:23 --> Config Class Initialized
INFO - 2024-10-15 11:18:23 --> Loader Class Initialized
INFO - 2024-10-15 11:18:23 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:23 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:23 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:23 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:23 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:23 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:26 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:26 --> Total execution time: 2.9727
INFO - 2024-10-15 11:18:26 --> Config Class Initialized
INFO - 2024-10-15 11:18:26 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:26 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:26 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:26 --> URI Class Initialized
INFO - 2024-10-15 11:18:26 --> Router Class Initialized
INFO - 2024-10-15 11:18:26 --> Output Class Initialized
INFO - 2024-10-15 11:18:26 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:26 --> Input Class Initialized
INFO - 2024-10-15 11:18:26 --> Language Class Initialized
INFO - 2024-10-15 11:18:26 --> Language Class Initialized
INFO - 2024-10-15 11:18:26 --> Config Class Initialized
INFO - 2024-10-15 11:18:26 --> Loader Class Initialized
INFO - 2024-10-15 11:18:26 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:26 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:26 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:26 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:26 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:26 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:29 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:29 --> Total execution time: 2.8150
INFO - 2024-10-15 11:18:29 --> Config Class Initialized
INFO - 2024-10-15 11:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:29 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:29 --> URI Class Initialized
INFO - 2024-10-15 11:18:29 --> Router Class Initialized
INFO - 2024-10-15 11:18:29 --> Output Class Initialized
INFO - 2024-10-15 11:18:29 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:29 --> Input Class Initialized
INFO - 2024-10-15 11:18:29 --> Language Class Initialized
INFO - 2024-10-15 11:18:29 --> Language Class Initialized
INFO - 2024-10-15 11:18:29 --> Config Class Initialized
INFO - 2024-10-15 11:18:29 --> Loader Class Initialized
INFO - 2024-10-15 11:18:29 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:29 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:29 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:29 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:29 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:29 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:32 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:32 --> Total execution time: 2.8062
INFO - 2024-10-15 11:18:32 --> Config Class Initialized
INFO - 2024-10-15 11:18:32 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:32 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:32 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:32 --> URI Class Initialized
INFO - 2024-10-15 11:18:32 --> Router Class Initialized
INFO - 2024-10-15 11:18:32 --> Output Class Initialized
INFO - 2024-10-15 11:18:32 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:32 --> Input Class Initialized
INFO - 2024-10-15 11:18:32 --> Language Class Initialized
INFO - 2024-10-15 11:18:32 --> Language Class Initialized
INFO - 2024-10-15 11:18:32 --> Config Class Initialized
INFO - 2024-10-15 11:18:32 --> Loader Class Initialized
INFO - 2024-10-15 11:18:32 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:32 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:32 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:32 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:32 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:32 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:36 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:36 --> Total execution time: 3.8019
INFO - 2024-10-15 11:18:36 --> Config Class Initialized
INFO - 2024-10-15 11:18:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:36 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:36 --> URI Class Initialized
INFO - 2024-10-15 11:18:36 --> Router Class Initialized
INFO - 2024-10-15 11:18:36 --> Output Class Initialized
INFO - 2024-10-15 11:18:36 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:36 --> Input Class Initialized
INFO - 2024-10-15 11:18:36 --> Language Class Initialized
INFO - 2024-10-15 11:18:36 --> Language Class Initialized
INFO - 2024-10-15 11:18:36 --> Config Class Initialized
INFO - 2024-10-15 11:18:36 --> Loader Class Initialized
INFO - 2024-10-15 11:18:36 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:36 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:36 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:36 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:36 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:36 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:38 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:38 --> Total execution time: 2.6606
INFO - 2024-10-15 11:18:39 --> Config Class Initialized
INFO - 2024-10-15 11:18:39 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:39 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:39 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:39 --> URI Class Initialized
INFO - 2024-10-15 11:18:39 --> Router Class Initialized
INFO - 2024-10-15 11:18:39 --> Output Class Initialized
INFO - 2024-10-15 11:18:39 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:39 --> Input Class Initialized
INFO - 2024-10-15 11:18:39 --> Language Class Initialized
INFO - 2024-10-15 11:18:39 --> Language Class Initialized
INFO - 2024-10-15 11:18:39 --> Config Class Initialized
INFO - 2024-10-15 11:18:39 --> Loader Class Initialized
INFO - 2024-10-15 11:18:39 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:39 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:39 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:39 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:39 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:39 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:41 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:41 --> Total execution time: 2.6775
INFO - 2024-10-15 11:18:41 --> Config Class Initialized
INFO - 2024-10-15 11:18:41 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:41 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:41 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:41 --> URI Class Initialized
INFO - 2024-10-15 11:18:41 --> Router Class Initialized
INFO - 2024-10-15 11:18:41 --> Output Class Initialized
INFO - 2024-10-15 11:18:41 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:41 --> Input Class Initialized
INFO - 2024-10-15 11:18:41 --> Language Class Initialized
INFO - 2024-10-15 11:18:41 --> Language Class Initialized
INFO - 2024-10-15 11:18:41 --> Config Class Initialized
INFO - 2024-10-15 11:18:41 --> Loader Class Initialized
INFO - 2024-10-15 11:18:41 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:41 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:41 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:41 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:41 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:41 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:44 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:44 --> Total execution time: 2.7642
INFO - 2024-10-15 11:18:44 --> Config Class Initialized
INFO - 2024-10-15 11:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:44 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:44 --> URI Class Initialized
INFO - 2024-10-15 11:18:44 --> Router Class Initialized
INFO - 2024-10-15 11:18:44 --> Output Class Initialized
INFO - 2024-10-15 11:18:44 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:44 --> Input Class Initialized
INFO - 2024-10-15 11:18:44 --> Language Class Initialized
INFO - 2024-10-15 11:18:44 --> Language Class Initialized
INFO - 2024-10-15 11:18:44 --> Config Class Initialized
INFO - 2024-10-15 11:18:44 --> Loader Class Initialized
INFO - 2024-10-15 11:18:44 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:44 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:44 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:44 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:44 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:44 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:47 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:47 --> Total execution time: 2.7698
INFO - 2024-10-15 11:18:47 --> Config Class Initialized
INFO - 2024-10-15 11:18:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:47 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:47 --> URI Class Initialized
INFO - 2024-10-15 11:18:47 --> Router Class Initialized
INFO - 2024-10-15 11:18:47 --> Output Class Initialized
INFO - 2024-10-15 11:18:47 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:47 --> Input Class Initialized
INFO - 2024-10-15 11:18:47 --> Language Class Initialized
INFO - 2024-10-15 11:18:47 --> Language Class Initialized
INFO - 2024-10-15 11:18:47 --> Config Class Initialized
INFO - 2024-10-15 11:18:47 --> Loader Class Initialized
INFO - 2024-10-15 11:18:47 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:47 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:47 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:47 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:47 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:47 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:50 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:50 --> Total execution time: 2.6668
INFO - 2024-10-15 11:18:50 --> Config Class Initialized
INFO - 2024-10-15 11:18:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:50 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:50 --> URI Class Initialized
INFO - 2024-10-15 11:18:50 --> Router Class Initialized
INFO - 2024-10-15 11:18:50 --> Output Class Initialized
INFO - 2024-10-15 11:18:50 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:50 --> Input Class Initialized
INFO - 2024-10-15 11:18:50 --> Language Class Initialized
INFO - 2024-10-15 11:18:50 --> Language Class Initialized
INFO - 2024-10-15 11:18:50 --> Config Class Initialized
INFO - 2024-10-15 11:18:50 --> Loader Class Initialized
INFO - 2024-10-15 11:18:50 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:50 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:50 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:50 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:50 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:50 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:53 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:53 --> Total execution time: 2.7427
INFO - 2024-10-15 11:18:53 --> Config Class Initialized
INFO - 2024-10-15 11:18:53 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:53 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:53 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:53 --> URI Class Initialized
INFO - 2024-10-15 11:18:53 --> Router Class Initialized
INFO - 2024-10-15 11:18:53 --> Output Class Initialized
INFO - 2024-10-15 11:18:53 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:53 --> Input Class Initialized
INFO - 2024-10-15 11:18:53 --> Language Class Initialized
INFO - 2024-10-15 11:18:53 --> Language Class Initialized
INFO - 2024-10-15 11:18:53 --> Config Class Initialized
INFO - 2024-10-15 11:18:53 --> Loader Class Initialized
INFO - 2024-10-15 11:18:53 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:53 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:53 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:53 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:53 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:53 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:18:56 --> Final output sent to browser
DEBUG - 2024-10-15 11:18:56 --> Total execution time: 3.5195
INFO - 2024-10-15 11:18:57 --> Config Class Initialized
INFO - 2024-10-15 11:18:57 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:18:57 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:18:57 --> Utf8 Class Initialized
INFO - 2024-10-15 11:18:57 --> URI Class Initialized
INFO - 2024-10-15 11:18:57 --> Router Class Initialized
INFO - 2024-10-15 11:18:57 --> Output Class Initialized
INFO - 2024-10-15 11:18:57 --> Security Class Initialized
DEBUG - 2024-10-15 11:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:18:57 --> Input Class Initialized
INFO - 2024-10-15 11:18:57 --> Language Class Initialized
INFO - 2024-10-15 11:18:57 --> Language Class Initialized
INFO - 2024-10-15 11:18:57 --> Config Class Initialized
INFO - 2024-10-15 11:18:57 --> Loader Class Initialized
INFO - 2024-10-15 11:18:57 --> Helper loaded: url_helper
INFO - 2024-10-15 11:18:57 --> Helper loaded: file_helper
INFO - 2024-10-15 11:18:57 --> Helper loaded: form_helper
INFO - 2024-10-15 11:18:57 --> Helper loaded: my_helper
INFO - 2024-10-15 11:18:57 --> Database Driver Class Initialized
INFO - 2024-10-15 11:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:18:58 --> Controller Class Initialized
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:18:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:02 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:02 --> Total execution time: 4.6714
INFO - 2024-10-15 11:19:02 --> Config Class Initialized
INFO - 2024-10-15 11:19:02 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:02 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:02 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:02 --> URI Class Initialized
INFO - 2024-10-15 11:19:02 --> Router Class Initialized
INFO - 2024-10-15 11:19:02 --> Output Class Initialized
INFO - 2024-10-15 11:19:02 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:02 --> Input Class Initialized
INFO - 2024-10-15 11:19:02 --> Language Class Initialized
INFO - 2024-10-15 11:19:02 --> Language Class Initialized
INFO - 2024-10-15 11:19:02 --> Config Class Initialized
INFO - 2024-10-15 11:19:02 --> Loader Class Initialized
INFO - 2024-10-15 11:19:02 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:02 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:02 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:02 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:02 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:02 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:05 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:05 --> Total execution time: 3.3401
INFO - 2024-10-15 11:19:05 --> Config Class Initialized
INFO - 2024-10-15 11:19:05 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:05 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:05 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:05 --> URI Class Initialized
INFO - 2024-10-15 11:19:05 --> Router Class Initialized
INFO - 2024-10-15 11:19:05 --> Output Class Initialized
INFO - 2024-10-15 11:19:05 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:05 --> Input Class Initialized
INFO - 2024-10-15 11:19:05 --> Language Class Initialized
INFO - 2024-10-15 11:19:05 --> Language Class Initialized
INFO - 2024-10-15 11:19:05 --> Config Class Initialized
INFO - 2024-10-15 11:19:05 --> Loader Class Initialized
INFO - 2024-10-15 11:19:05 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:06 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:06 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:06 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:06 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:06 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:08 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:08 --> Total execution time: 2.7729
INFO - 2024-10-15 11:19:09 --> Config Class Initialized
INFO - 2024-10-15 11:19:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:09 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:09 --> URI Class Initialized
INFO - 2024-10-15 11:19:09 --> Router Class Initialized
INFO - 2024-10-15 11:19:09 --> Output Class Initialized
INFO - 2024-10-15 11:19:09 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:09 --> Input Class Initialized
INFO - 2024-10-15 11:19:09 --> Language Class Initialized
INFO - 2024-10-15 11:19:09 --> Language Class Initialized
INFO - 2024-10-15 11:19:09 --> Config Class Initialized
INFO - 2024-10-15 11:19:09 --> Loader Class Initialized
INFO - 2024-10-15 11:19:09 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:09 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:09 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:09 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:09 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:09 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:11 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:11 --> Total execution time: 2.7242
INFO - 2024-10-15 11:19:12 --> Config Class Initialized
INFO - 2024-10-15 11:19:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:12 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:12 --> URI Class Initialized
INFO - 2024-10-15 11:19:12 --> Router Class Initialized
INFO - 2024-10-15 11:19:12 --> Output Class Initialized
INFO - 2024-10-15 11:19:12 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:12 --> Input Class Initialized
INFO - 2024-10-15 11:19:12 --> Language Class Initialized
INFO - 2024-10-15 11:19:12 --> Language Class Initialized
INFO - 2024-10-15 11:19:12 --> Config Class Initialized
INFO - 2024-10-15 11:19:12 --> Loader Class Initialized
INFO - 2024-10-15 11:19:12 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:12 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:12 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:12 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:12 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:12 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:14 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:14 --> Total execution time: 2.8620
INFO - 2024-10-15 11:19:15 --> Config Class Initialized
INFO - 2024-10-15 11:19:15 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:15 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:15 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:15 --> URI Class Initialized
INFO - 2024-10-15 11:19:15 --> Router Class Initialized
INFO - 2024-10-15 11:19:15 --> Output Class Initialized
INFO - 2024-10-15 11:19:15 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:15 --> Input Class Initialized
INFO - 2024-10-15 11:19:15 --> Language Class Initialized
INFO - 2024-10-15 11:19:15 --> Language Class Initialized
INFO - 2024-10-15 11:19:15 --> Config Class Initialized
INFO - 2024-10-15 11:19:15 --> Loader Class Initialized
INFO - 2024-10-15 11:19:15 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:15 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:15 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:15 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:15 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:15 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:18 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:18 --> Total execution time: 3.2185
INFO - 2024-10-15 11:19:18 --> Config Class Initialized
INFO - 2024-10-15 11:19:18 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:18 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:18 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:18 --> URI Class Initialized
INFO - 2024-10-15 11:19:18 --> Router Class Initialized
INFO - 2024-10-15 11:19:18 --> Output Class Initialized
INFO - 2024-10-15 11:19:18 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:18 --> Input Class Initialized
INFO - 2024-10-15 11:19:18 --> Language Class Initialized
INFO - 2024-10-15 11:19:18 --> Language Class Initialized
INFO - 2024-10-15 11:19:18 --> Config Class Initialized
INFO - 2024-10-15 11:19:18 --> Loader Class Initialized
INFO - 2024-10-15 11:19:18 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:18 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:18 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:18 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:18 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:18 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:21 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:21 --> Total execution time: 2.8568
INFO - 2024-10-15 11:19:21 --> Config Class Initialized
INFO - 2024-10-15 11:19:21 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:21 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:21 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:21 --> URI Class Initialized
INFO - 2024-10-15 11:19:21 --> Router Class Initialized
INFO - 2024-10-15 11:19:21 --> Output Class Initialized
INFO - 2024-10-15 11:19:21 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:21 --> Input Class Initialized
INFO - 2024-10-15 11:19:21 --> Language Class Initialized
INFO - 2024-10-15 11:19:21 --> Language Class Initialized
INFO - 2024-10-15 11:19:21 --> Config Class Initialized
INFO - 2024-10-15 11:19:21 --> Loader Class Initialized
INFO - 2024-10-15 11:19:21 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:21 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:21 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:21 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:21 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:21 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:24 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:24 --> Total execution time: 3.0088
INFO - 2024-10-15 11:19:24 --> Config Class Initialized
INFO - 2024-10-15 11:19:24 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:24 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:24 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:24 --> URI Class Initialized
INFO - 2024-10-15 11:19:24 --> Router Class Initialized
INFO - 2024-10-15 11:19:24 --> Output Class Initialized
INFO - 2024-10-15 11:19:24 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:24 --> Input Class Initialized
INFO - 2024-10-15 11:19:24 --> Language Class Initialized
INFO - 2024-10-15 11:19:24 --> Language Class Initialized
INFO - 2024-10-15 11:19:24 --> Config Class Initialized
INFO - 2024-10-15 11:19:24 --> Loader Class Initialized
INFO - 2024-10-15 11:19:24 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:24 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:24 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:24 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:24 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:24 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:27 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:27 --> Total execution time: 2.8064
INFO - 2024-10-15 11:19:28 --> Config Class Initialized
INFO - 2024-10-15 11:19:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:28 --> URI Class Initialized
INFO - 2024-10-15 11:19:28 --> Router Class Initialized
INFO - 2024-10-15 11:19:28 --> Output Class Initialized
INFO - 2024-10-15 11:19:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:28 --> Input Class Initialized
INFO - 2024-10-15 11:19:28 --> Language Class Initialized
INFO - 2024-10-15 11:19:28 --> Language Class Initialized
INFO - 2024-10-15 11:19:28 --> Config Class Initialized
INFO - 2024-10-15 11:19:28 --> Loader Class Initialized
INFO - 2024-10-15 11:19:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:31 --> Total execution time: 3.1659
INFO - 2024-10-15 11:19:31 --> Config Class Initialized
INFO - 2024-10-15 11:19:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:31 --> URI Class Initialized
INFO - 2024-10-15 11:19:31 --> Router Class Initialized
INFO - 2024-10-15 11:19:31 --> Output Class Initialized
INFO - 2024-10-15 11:19:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:31 --> Input Class Initialized
INFO - 2024-10-15 11:19:31 --> Language Class Initialized
INFO - 2024-10-15 11:19:31 --> Language Class Initialized
INFO - 2024-10-15 11:19:31 --> Config Class Initialized
INFO - 2024-10-15 11:19:31 --> Loader Class Initialized
INFO - 2024-10-15 11:19:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:34 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:34 --> Total execution time: 2.7886
INFO - 2024-10-15 11:19:35 --> Config Class Initialized
INFO - 2024-10-15 11:19:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:35 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:35 --> URI Class Initialized
INFO - 2024-10-15 11:19:35 --> Router Class Initialized
INFO - 2024-10-15 11:19:35 --> Output Class Initialized
INFO - 2024-10-15 11:19:35 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:35 --> Input Class Initialized
INFO - 2024-10-15 11:19:35 --> Language Class Initialized
INFO - 2024-10-15 11:19:35 --> Language Class Initialized
INFO - 2024-10-15 11:19:35 --> Config Class Initialized
INFO - 2024-10-15 11:19:35 --> Loader Class Initialized
INFO - 2024-10-15 11:19:35 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:35 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:35 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:35 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:35 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:35 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:37 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:37 --> Total execution time: 2.8332
INFO - 2024-10-15 11:19:38 --> Config Class Initialized
INFO - 2024-10-15 11:19:38 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:38 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:38 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:38 --> URI Class Initialized
INFO - 2024-10-15 11:19:38 --> Router Class Initialized
INFO - 2024-10-15 11:19:38 --> Output Class Initialized
INFO - 2024-10-15 11:19:38 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:38 --> Input Class Initialized
INFO - 2024-10-15 11:19:38 --> Language Class Initialized
INFO - 2024-10-15 11:19:38 --> Language Class Initialized
INFO - 2024-10-15 11:19:38 --> Config Class Initialized
INFO - 2024-10-15 11:19:38 --> Loader Class Initialized
INFO - 2024-10-15 11:19:38 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:38 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:38 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:38 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:38 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:38 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:40 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:40 --> Total execution time: 2.6640
INFO - 2024-10-15 11:19:41 --> Config Class Initialized
INFO - 2024-10-15 11:19:41 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:41 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:41 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:41 --> URI Class Initialized
INFO - 2024-10-15 11:19:41 --> Router Class Initialized
INFO - 2024-10-15 11:19:41 --> Output Class Initialized
INFO - 2024-10-15 11:19:41 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:41 --> Input Class Initialized
INFO - 2024-10-15 11:19:41 --> Language Class Initialized
INFO - 2024-10-15 11:19:41 --> Language Class Initialized
INFO - 2024-10-15 11:19:41 --> Config Class Initialized
INFO - 2024-10-15 11:19:41 --> Loader Class Initialized
INFO - 2024-10-15 11:19:41 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:41 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:41 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:41 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:41 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:41 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:43 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:43 --> Total execution time: 2.6163
INFO - 2024-10-15 11:19:44 --> Config Class Initialized
INFO - 2024-10-15 11:19:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:44 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:44 --> URI Class Initialized
INFO - 2024-10-15 11:19:44 --> Router Class Initialized
INFO - 2024-10-15 11:19:44 --> Output Class Initialized
INFO - 2024-10-15 11:19:44 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:44 --> Input Class Initialized
INFO - 2024-10-15 11:19:44 --> Language Class Initialized
INFO - 2024-10-15 11:19:44 --> Language Class Initialized
INFO - 2024-10-15 11:19:44 --> Config Class Initialized
INFO - 2024-10-15 11:19:44 --> Loader Class Initialized
INFO - 2024-10-15 11:19:44 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:44 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:44 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:44 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:44 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:44 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:46 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:46 --> Total execution time: 2.8124
INFO - 2024-10-15 11:19:47 --> Config Class Initialized
INFO - 2024-10-15 11:19:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:47 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:47 --> URI Class Initialized
INFO - 2024-10-15 11:19:47 --> Router Class Initialized
INFO - 2024-10-15 11:19:47 --> Output Class Initialized
INFO - 2024-10-15 11:19:47 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:47 --> Input Class Initialized
INFO - 2024-10-15 11:19:47 --> Language Class Initialized
INFO - 2024-10-15 11:19:47 --> Language Class Initialized
INFO - 2024-10-15 11:19:47 --> Config Class Initialized
INFO - 2024-10-15 11:19:47 --> Loader Class Initialized
INFO - 2024-10-15 11:19:47 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:47 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:47 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:47 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:47 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:47 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:49 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:49 --> Total execution time: 2.7640
INFO - 2024-10-15 11:19:50 --> Config Class Initialized
INFO - 2024-10-15 11:19:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:50 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:50 --> URI Class Initialized
INFO - 2024-10-15 11:19:50 --> Router Class Initialized
INFO - 2024-10-15 11:19:50 --> Output Class Initialized
INFO - 2024-10-15 11:19:50 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:50 --> Input Class Initialized
INFO - 2024-10-15 11:19:50 --> Language Class Initialized
INFO - 2024-10-15 11:19:50 --> Language Class Initialized
INFO - 2024-10-15 11:19:50 --> Config Class Initialized
INFO - 2024-10-15 11:19:50 --> Loader Class Initialized
INFO - 2024-10-15 11:19:50 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:50 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:50 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:50 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:50 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:50 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:53 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:53 --> Total execution time: 2.7698
INFO - 2024-10-15 11:19:53 --> Config Class Initialized
INFO - 2024-10-15 11:19:53 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:53 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:53 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:53 --> URI Class Initialized
INFO - 2024-10-15 11:19:53 --> Router Class Initialized
INFO - 2024-10-15 11:19:53 --> Output Class Initialized
INFO - 2024-10-15 11:19:53 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:53 --> Input Class Initialized
INFO - 2024-10-15 11:19:53 --> Language Class Initialized
INFO - 2024-10-15 11:19:53 --> Language Class Initialized
INFO - 2024-10-15 11:19:53 --> Config Class Initialized
INFO - 2024-10-15 11:19:53 --> Loader Class Initialized
INFO - 2024-10-15 11:19:53 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:53 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:53 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:53 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:53 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:53 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:19:56 --> Final output sent to browser
DEBUG - 2024-10-15 11:19:56 --> Total execution time: 3.1697
INFO - 2024-10-15 11:19:57 --> Config Class Initialized
INFO - 2024-10-15 11:19:57 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:19:57 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:19:57 --> Utf8 Class Initialized
INFO - 2024-10-15 11:19:57 --> URI Class Initialized
INFO - 2024-10-15 11:19:57 --> Router Class Initialized
INFO - 2024-10-15 11:19:57 --> Output Class Initialized
INFO - 2024-10-15 11:19:57 --> Security Class Initialized
DEBUG - 2024-10-15 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:19:57 --> Input Class Initialized
INFO - 2024-10-15 11:19:57 --> Language Class Initialized
INFO - 2024-10-15 11:19:57 --> Language Class Initialized
INFO - 2024-10-15 11:19:57 --> Config Class Initialized
INFO - 2024-10-15 11:19:57 --> Loader Class Initialized
INFO - 2024-10-15 11:19:57 --> Helper loaded: url_helper
INFO - 2024-10-15 11:19:57 --> Helper loaded: file_helper
INFO - 2024-10-15 11:19:57 --> Helper loaded: form_helper
INFO - 2024-10-15 11:19:57 --> Helper loaded: my_helper
INFO - 2024-10-15 11:19:57 --> Database Driver Class Initialized
INFO - 2024-10-15 11:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:19:57 --> Controller Class Initialized
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:19:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:19:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:00 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:00 --> Total execution time: 2.8896
INFO - 2024-10-15 11:20:00 --> Config Class Initialized
INFO - 2024-10-15 11:20:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:00 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:00 --> URI Class Initialized
INFO - 2024-10-15 11:20:00 --> Router Class Initialized
INFO - 2024-10-15 11:20:00 --> Output Class Initialized
INFO - 2024-10-15 11:20:00 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:00 --> Input Class Initialized
INFO - 2024-10-15 11:20:00 --> Language Class Initialized
INFO - 2024-10-15 11:20:00 --> Language Class Initialized
INFO - 2024-10-15 11:20:00 --> Config Class Initialized
INFO - 2024-10-15 11:20:00 --> Loader Class Initialized
INFO - 2024-10-15 11:20:00 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:00 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:00 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:00 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:00 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:00 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:04 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:04 --> Total execution time: 4.5950
INFO - 2024-10-15 11:20:05 --> Config Class Initialized
INFO - 2024-10-15 11:20:05 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:05 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:05 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:05 --> URI Class Initialized
INFO - 2024-10-15 11:20:05 --> Router Class Initialized
INFO - 2024-10-15 11:20:05 --> Output Class Initialized
INFO - 2024-10-15 11:20:05 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:05 --> Input Class Initialized
INFO - 2024-10-15 11:20:05 --> Language Class Initialized
INFO - 2024-10-15 11:20:05 --> Language Class Initialized
INFO - 2024-10-15 11:20:05 --> Config Class Initialized
INFO - 2024-10-15 11:20:05 --> Loader Class Initialized
INFO - 2024-10-15 11:20:05 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:05 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:05 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:05 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:05 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:05 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:07 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:07 --> Total execution time: 2.8218
INFO - 2024-10-15 11:20:08 --> Config Class Initialized
INFO - 2024-10-15 11:20:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:08 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:08 --> URI Class Initialized
INFO - 2024-10-15 11:20:08 --> Router Class Initialized
INFO - 2024-10-15 11:20:08 --> Output Class Initialized
INFO - 2024-10-15 11:20:08 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:08 --> Input Class Initialized
INFO - 2024-10-15 11:20:08 --> Language Class Initialized
INFO - 2024-10-15 11:20:08 --> Language Class Initialized
INFO - 2024-10-15 11:20:08 --> Config Class Initialized
INFO - 2024-10-15 11:20:08 --> Loader Class Initialized
INFO - 2024-10-15 11:20:08 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:08 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:08 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:08 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:08 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:08 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:10 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:10 --> Total execution time: 2.7843
INFO - 2024-10-15 11:20:11 --> Config Class Initialized
INFO - 2024-10-15 11:20:11 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:11 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:11 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:11 --> URI Class Initialized
INFO - 2024-10-15 11:20:11 --> Router Class Initialized
INFO - 2024-10-15 11:20:11 --> Output Class Initialized
INFO - 2024-10-15 11:20:11 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:11 --> Input Class Initialized
INFO - 2024-10-15 11:20:11 --> Language Class Initialized
INFO - 2024-10-15 11:20:11 --> Language Class Initialized
INFO - 2024-10-15 11:20:11 --> Config Class Initialized
INFO - 2024-10-15 11:20:11 --> Loader Class Initialized
INFO - 2024-10-15 11:20:11 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:11 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:11 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:11 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:11 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:11 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:13 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:13 --> Total execution time: 2.7583
INFO - 2024-10-15 11:20:14 --> Config Class Initialized
INFO - 2024-10-15 11:20:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:14 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:14 --> URI Class Initialized
INFO - 2024-10-15 11:20:14 --> Router Class Initialized
INFO - 2024-10-15 11:20:14 --> Output Class Initialized
INFO - 2024-10-15 11:20:14 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:14 --> Input Class Initialized
INFO - 2024-10-15 11:20:14 --> Language Class Initialized
INFO - 2024-10-15 11:20:14 --> Language Class Initialized
INFO - 2024-10-15 11:20:14 --> Config Class Initialized
INFO - 2024-10-15 11:20:14 --> Loader Class Initialized
INFO - 2024-10-15 11:20:14 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:14 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:14 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:14 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:14 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:14 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:17 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:17 --> Total execution time: 3.3920
INFO - 2024-10-15 11:20:18 --> Config Class Initialized
INFO - 2024-10-15 11:20:18 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:18 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:18 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:18 --> URI Class Initialized
INFO - 2024-10-15 11:20:18 --> Router Class Initialized
INFO - 2024-10-15 11:20:18 --> Output Class Initialized
INFO - 2024-10-15 11:20:18 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:18 --> Input Class Initialized
INFO - 2024-10-15 11:20:18 --> Language Class Initialized
INFO - 2024-10-15 11:20:18 --> Language Class Initialized
INFO - 2024-10-15 11:20:18 --> Config Class Initialized
INFO - 2024-10-15 11:20:18 --> Loader Class Initialized
INFO - 2024-10-15 11:20:18 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:18 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:18 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:18 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:18 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:18 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:20 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:20 --> Total execution time: 2.7180
INFO - 2024-10-15 11:20:21 --> Config Class Initialized
INFO - 2024-10-15 11:20:21 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:21 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:21 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:21 --> URI Class Initialized
INFO - 2024-10-15 11:20:21 --> Router Class Initialized
INFO - 2024-10-15 11:20:21 --> Output Class Initialized
INFO - 2024-10-15 11:20:21 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:21 --> Input Class Initialized
INFO - 2024-10-15 11:20:21 --> Language Class Initialized
INFO - 2024-10-15 11:20:21 --> Language Class Initialized
INFO - 2024-10-15 11:20:21 --> Config Class Initialized
INFO - 2024-10-15 11:20:21 --> Loader Class Initialized
INFO - 2024-10-15 11:20:21 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:21 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:21 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:21 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:21 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:21 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:24 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:24 --> Total execution time: 3.3793
INFO - 2024-10-15 11:20:25 --> Config Class Initialized
INFO - 2024-10-15 11:20:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:25 --> URI Class Initialized
INFO - 2024-10-15 11:20:25 --> Router Class Initialized
INFO - 2024-10-15 11:20:25 --> Output Class Initialized
INFO - 2024-10-15 11:20:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:25 --> Input Class Initialized
INFO - 2024-10-15 11:20:25 --> Language Class Initialized
INFO - 2024-10-15 11:20:25 --> Language Class Initialized
INFO - 2024-10-15 11:20:25 --> Config Class Initialized
INFO - 2024-10-15 11:20:25 --> Loader Class Initialized
INFO - 2024-10-15 11:20:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:25 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:27 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:27 --> Total execution time: 2.9351
INFO - 2024-10-15 11:20:28 --> Config Class Initialized
INFO - 2024-10-15 11:20:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:28 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:28 --> URI Class Initialized
INFO - 2024-10-15 11:20:28 --> Router Class Initialized
INFO - 2024-10-15 11:20:28 --> Output Class Initialized
INFO - 2024-10-15 11:20:28 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:28 --> Input Class Initialized
INFO - 2024-10-15 11:20:28 --> Language Class Initialized
INFO - 2024-10-15 11:20:28 --> Language Class Initialized
INFO - 2024-10-15 11:20:28 --> Config Class Initialized
INFO - 2024-10-15 11:20:28 --> Loader Class Initialized
INFO - 2024-10-15 11:20:28 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:28 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:28 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:28 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:28 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:28 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:31 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:31 --> Total execution time: 3.2566
INFO - 2024-10-15 11:20:31 --> Config Class Initialized
INFO - 2024-10-15 11:20:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:31 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:31 --> URI Class Initialized
INFO - 2024-10-15 11:20:31 --> Router Class Initialized
INFO - 2024-10-15 11:20:31 --> Output Class Initialized
INFO - 2024-10-15 11:20:31 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:31 --> Input Class Initialized
INFO - 2024-10-15 11:20:31 --> Language Class Initialized
INFO - 2024-10-15 11:20:31 --> Language Class Initialized
INFO - 2024-10-15 11:20:31 --> Config Class Initialized
INFO - 2024-10-15 11:20:31 --> Loader Class Initialized
INFO - 2024-10-15 11:20:31 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:31 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:31 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:31 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:31 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:31 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:35 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:35 --> Total execution time: 3.3642
INFO - 2024-10-15 11:20:35 --> Config Class Initialized
INFO - 2024-10-15 11:20:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:35 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:35 --> URI Class Initialized
INFO - 2024-10-15 11:20:35 --> Router Class Initialized
INFO - 2024-10-15 11:20:35 --> Output Class Initialized
INFO - 2024-10-15 11:20:35 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:35 --> Input Class Initialized
INFO - 2024-10-15 11:20:35 --> Language Class Initialized
INFO - 2024-10-15 11:20:35 --> Language Class Initialized
INFO - 2024-10-15 11:20:35 --> Config Class Initialized
INFO - 2024-10-15 11:20:35 --> Loader Class Initialized
INFO - 2024-10-15 11:20:35 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:35 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:35 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:35 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:35 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:35 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:38 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:38 --> Total execution time: 3.3563
INFO - 2024-10-15 11:20:38 --> Config Class Initialized
INFO - 2024-10-15 11:20:38 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:38 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:38 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:38 --> URI Class Initialized
INFO - 2024-10-15 11:20:38 --> Router Class Initialized
INFO - 2024-10-15 11:20:38 --> Output Class Initialized
INFO - 2024-10-15 11:20:38 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:38 --> Input Class Initialized
INFO - 2024-10-15 11:20:38 --> Language Class Initialized
INFO - 2024-10-15 11:20:38 --> Language Class Initialized
INFO - 2024-10-15 11:20:38 --> Config Class Initialized
INFO - 2024-10-15 11:20:38 --> Loader Class Initialized
INFO - 2024-10-15 11:20:38 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:38 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:38 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:38 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:38 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:38 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:41 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:41 --> Total execution time: 2.5990
INFO - 2024-10-15 11:20:41 --> Config Class Initialized
INFO - 2024-10-15 11:20:41 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:41 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:41 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:41 --> URI Class Initialized
INFO - 2024-10-15 11:20:41 --> Router Class Initialized
INFO - 2024-10-15 11:20:41 --> Output Class Initialized
INFO - 2024-10-15 11:20:41 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:41 --> Input Class Initialized
INFO - 2024-10-15 11:20:41 --> Language Class Initialized
INFO - 2024-10-15 11:20:41 --> Language Class Initialized
INFO - 2024-10-15 11:20:41 --> Config Class Initialized
INFO - 2024-10-15 11:20:41 --> Loader Class Initialized
INFO - 2024-10-15 11:20:41 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:41 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:41 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:41 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:41 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:41 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:44 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:44 --> Total execution time: 2.5760
INFO - 2024-10-15 11:20:44 --> Config Class Initialized
INFO - 2024-10-15 11:20:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:44 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:44 --> URI Class Initialized
INFO - 2024-10-15 11:20:44 --> Router Class Initialized
INFO - 2024-10-15 11:20:44 --> Output Class Initialized
INFO - 2024-10-15 11:20:44 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:44 --> Input Class Initialized
INFO - 2024-10-15 11:20:44 --> Language Class Initialized
INFO - 2024-10-15 11:20:44 --> Language Class Initialized
INFO - 2024-10-15 11:20:44 --> Config Class Initialized
INFO - 2024-10-15 11:20:44 --> Loader Class Initialized
INFO - 2024-10-15 11:20:44 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:44 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:44 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:44 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:44 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:44 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:47 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:47 --> Total execution time: 3.0796
INFO - 2024-10-15 11:20:47 --> Config Class Initialized
INFO - 2024-10-15 11:20:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:47 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:47 --> URI Class Initialized
INFO - 2024-10-15 11:20:47 --> Router Class Initialized
INFO - 2024-10-15 11:20:47 --> Output Class Initialized
INFO - 2024-10-15 11:20:47 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:47 --> Input Class Initialized
INFO - 2024-10-15 11:20:47 --> Language Class Initialized
INFO - 2024-10-15 11:20:47 --> Language Class Initialized
INFO - 2024-10-15 11:20:47 --> Config Class Initialized
INFO - 2024-10-15 11:20:47 --> Loader Class Initialized
INFO - 2024-10-15 11:20:47 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:47 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:47 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:47 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:47 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:47 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:48 --> Config Class Initialized
INFO - 2024-10-15 11:20:48 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:48 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:48 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:48 --> URI Class Initialized
INFO - 2024-10-15 11:20:48 --> Router Class Initialized
INFO - 2024-10-15 11:20:48 --> Output Class Initialized
INFO - 2024-10-15 11:20:48 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:48 --> Input Class Initialized
INFO - 2024-10-15 11:20:48 --> Language Class Initialized
INFO - 2024-10-15 11:20:48 --> Language Class Initialized
INFO - 2024-10-15 11:20:48 --> Config Class Initialized
INFO - 2024-10-15 11:20:48 --> Loader Class Initialized
INFO - 2024-10-15 11:20:48 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:48 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:48 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:48 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:48 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:48 --> Controller Class Initialized
DEBUG - 2024-10-15 11:20:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:52 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:52 --> Total execution time: 4.7740
INFO - 2024-10-15 11:20:52 --> Config Class Initialized
INFO - 2024-10-15 11:20:52 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:52 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:52 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:52 --> URI Class Initialized
INFO - 2024-10-15 11:20:52 --> Router Class Initialized
INFO - 2024-10-15 11:20:52 --> Output Class Initialized
INFO - 2024-10-15 11:20:52 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:52 --> Input Class Initialized
INFO - 2024-10-15 11:20:52 --> Language Class Initialized
INFO - 2024-10-15 11:20:52 --> Language Class Initialized
INFO - 2024-10-15 11:20:52 --> Config Class Initialized
INFO - 2024-10-15 11:20:52 --> Loader Class Initialized
INFO - 2024-10-15 11:20:52 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:52 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:52 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:52 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:52 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:52 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:54 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:54 --> Total execution time: 5.9797
INFO - 2024-10-15 11:20:56 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:56 --> Total execution time: 3.6585
INFO - 2024-10-15 11:20:56 --> Config Class Initialized
INFO - 2024-10-15 11:20:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:56 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:56 --> URI Class Initialized
INFO - 2024-10-15 11:20:56 --> Router Class Initialized
INFO - 2024-10-15 11:20:56 --> Output Class Initialized
INFO - 2024-10-15 11:20:56 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:56 --> Input Class Initialized
INFO - 2024-10-15 11:20:56 --> Language Class Initialized
INFO - 2024-10-15 11:20:56 --> Language Class Initialized
INFO - 2024-10-15 11:20:56 --> Config Class Initialized
INFO - 2024-10-15 11:20:56 --> Loader Class Initialized
INFO - 2024-10-15 11:20:56 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:56 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:56 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:56 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:56 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:56 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:20:59 --> Final output sent to browser
DEBUG - 2024-10-15 11:20:59 --> Total execution time: 2.6573
INFO - 2024-10-15 11:20:59 --> Config Class Initialized
INFO - 2024-10-15 11:20:59 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:20:59 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:20:59 --> Utf8 Class Initialized
INFO - 2024-10-15 11:20:59 --> URI Class Initialized
INFO - 2024-10-15 11:20:59 --> Router Class Initialized
INFO - 2024-10-15 11:20:59 --> Output Class Initialized
INFO - 2024-10-15 11:20:59 --> Security Class Initialized
DEBUG - 2024-10-15 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:20:59 --> Input Class Initialized
INFO - 2024-10-15 11:20:59 --> Language Class Initialized
INFO - 2024-10-15 11:20:59 --> Language Class Initialized
INFO - 2024-10-15 11:20:59 --> Config Class Initialized
INFO - 2024-10-15 11:20:59 --> Loader Class Initialized
INFO - 2024-10-15 11:20:59 --> Helper loaded: url_helper
INFO - 2024-10-15 11:20:59 --> Helper loaded: file_helper
INFO - 2024-10-15 11:20:59 --> Helper loaded: form_helper
INFO - 2024-10-15 11:20:59 --> Helper loaded: my_helper
INFO - 2024-10-15 11:20:59 --> Database Driver Class Initialized
INFO - 2024-10-15 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:20:59 --> Controller Class Initialized
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:20:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:03 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:03 --> Total execution time: 3.5217
INFO - 2024-10-15 11:21:03 --> Config Class Initialized
INFO - 2024-10-15 11:21:03 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:03 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:03 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:03 --> URI Class Initialized
INFO - 2024-10-15 11:21:03 --> Router Class Initialized
INFO - 2024-10-15 11:21:03 --> Output Class Initialized
INFO - 2024-10-15 11:21:03 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:03 --> Input Class Initialized
INFO - 2024-10-15 11:21:03 --> Language Class Initialized
INFO - 2024-10-15 11:21:03 --> Language Class Initialized
INFO - 2024-10-15 11:21:03 --> Config Class Initialized
INFO - 2024-10-15 11:21:03 --> Loader Class Initialized
INFO - 2024-10-15 11:21:03 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:03 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:03 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:03 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:03 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:03 --> Controller Class Initialized
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:21:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:06 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:06 --> Total execution time: 3.4138
INFO - 2024-10-15 11:21:07 --> Config Class Initialized
INFO - 2024-10-15 11:21:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:07 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:07 --> URI Class Initialized
INFO - 2024-10-15 11:21:07 --> Router Class Initialized
INFO - 2024-10-15 11:21:07 --> Output Class Initialized
INFO - 2024-10-15 11:21:07 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:07 --> Input Class Initialized
INFO - 2024-10-15 11:21:07 --> Language Class Initialized
INFO - 2024-10-15 11:21:07 --> Language Class Initialized
INFO - 2024-10-15 11:21:07 --> Config Class Initialized
INFO - 2024-10-15 11:21:07 --> Loader Class Initialized
INFO - 2024-10-15 11:21:07 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:07 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:07 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:07 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:07 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:07 --> Controller Class Initialized
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:21:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:07 --> Config Class Initialized
INFO - 2024-10-15 11:21:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:07 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:07 --> URI Class Initialized
INFO - 2024-10-15 11:21:07 --> Router Class Initialized
INFO - 2024-10-15 11:21:07 --> Output Class Initialized
INFO - 2024-10-15 11:21:07 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:07 --> Input Class Initialized
INFO - 2024-10-15 11:21:07 --> Language Class Initialized
INFO - 2024-10-15 11:21:07 --> Language Class Initialized
INFO - 2024-10-15 11:21:07 --> Config Class Initialized
INFO - 2024-10-15 11:21:07 --> Loader Class Initialized
INFO - 2024-10-15 11:21:07 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:07 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:07 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:07 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:07 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:07 --> Controller Class Initialized
DEBUG - 2024-10-15 11:21:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:09 --> Config Class Initialized
INFO - 2024-10-15 11:21:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:09 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:09 --> URI Class Initialized
INFO - 2024-10-15 11:21:09 --> Router Class Initialized
INFO - 2024-10-15 11:21:09 --> Output Class Initialized
INFO - 2024-10-15 11:21:09 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:09 --> Input Class Initialized
INFO - 2024-10-15 11:21:09 --> Language Class Initialized
INFO - 2024-10-15 11:21:09 --> Language Class Initialized
INFO - 2024-10-15 11:21:09 --> Config Class Initialized
INFO - 2024-10-15 11:21:09 --> Loader Class Initialized
INFO - 2024-10-15 11:21:09 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:09 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:09 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:09 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:09 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:09 --> Controller Class Initialized
DEBUG - 2024-10-15 11:21:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:16 --> Config Class Initialized
INFO - 2024-10-15 11:21:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:16 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:16 --> URI Class Initialized
INFO - 2024-10-15 11:21:16 --> Router Class Initialized
INFO - 2024-10-15 11:21:16 --> Output Class Initialized
INFO - 2024-10-15 11:21:16 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:16 --> Input Class Initialized
INFO - 2024-10-15 11:21:16 --> Language Class Initialized
INFO - 2024-10-15 11:21:16 --> Language Class Initialized
INFO - 2024-10-15 11:21:16 --> Config Class Initialized
INFO - 2024-10-15 11:21:16 --> Loader Class Initialized
INFO - 2024-10-15 11:21:16 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:16 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:16 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:16 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:16 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:16 --> Controller Class Initialized
INFO - 2024-10-15 11:21:16 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:16 --> Total execution time: 9.2396
DEBUG - 2024-10-15 11:21:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:16 --> Config Class Initialized
INFO - 2024-10-15 11:21:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:16 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:16 --> URI Class Initialized
INFO - 2024-10-15 11:21:16 --> Router Class Initialized
INFO - 2024-10-15 11:21:16 --> Output Class Initialized
INFO - 2024-10-15 11:21:16 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:16 --> Input Class Initialized
INFO - 2024-10-15 11:21:16 --> Language Class Initialized
INFO - 2024-10-15 11:21:16 --> Language Class Initialized
INFO - 2024-10-15 11:21:16 --> Config Class Initialized
INFO - 2024-10-15 11:21:16 --> Loader Class Initialized
INFO - 2024-10-15 11:21:16 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:16 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:16 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:16 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:16 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:16 --> Controller Class Initialized
ERROR - 2024-10-15 11:21:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 11:21:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 11:21:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 11:21:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 11:21:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 11:21:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 11:21:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:19 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:19 --> Total execution time: 12.0395
INFO - 2024-10-15 11:21:22 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:22 --> Total execution time: 12.9084
INFO - 2024-10-15 11:21:25 --> Config Class Initialized
INFO - 2024-10-15 11:21:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:25 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:25 --> URI Class Initialized
INFO - 2024-10-15 11:21:25 --> Router Class Initialized
INFO - 2024-10-15 11:21:25 --> Output Class Initialized
INFO - 2024-10-15 11:21:25 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:25 --> Input Class Initialized
INFO - 2024-10-15 11:21:25 --> Language Class Initialized
INFO - 2024-10-15 11:21:25 --> Language Class Initialized
INFO - 2024-10-15 11:21:25 --> Config Class Initialized
INFO - 2024-10-15 11:21:25 --> Loader Class Initialized
INFO - 2024-10-15 11:21:25 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:25 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:25 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:25 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:25 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:25 --> Controller Class Initialized
DEBUG - 2024-10-15 11:21:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:26 --> Config Class Initialized
INFO - 2024-10-15 11:21:26 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:21:26 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:21:26 --> Utf8 Class Initialized
INFO - 2024-10-15 11:21:26 --> URI Class Initialized
INFO - 2024-10-15 11:21:26 --> Router Class Initialized
INFO - 2024-10-15 11:21:26 --> Output Class Initialized
INFO - 2024-10-15 11:21:26 --> Security Class Initialized
DEBUG - 2024-10-15 11:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:21:26 --> Input Class Initialized
INFO - 2024-10-15 11:21:26 --> Language Class Initialized
INFO - 2024-10-15 11:21:26 --> Language Class Initialized
INFO - 2024-10-15 11:21:26 --> Config Class Initialized
INFO - 2024-10-15 11:21:26 --> Loader Class Initialized
INFO - 2024-10-15 11:21:26 --> Helper loaded: url_helper
INFO - 2024-10-15 11:21:26 --> Helper loaded: file_helper
INFO - 2024-10-15 11:21:26 --> Helper loaded: form_helper
INFO - 2024-10-15 11:21:26 --> Helper loaded: my_helper
INFO - 2024-10-15 11:21:26 --> Database Driver Class Initialized
INFO - 2024-10-15 11:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:21:26 --> Controller Class Initialized
DEBUG - 2024-10-15 11:21:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 11:21:26 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:26 --> Total execution time: 10.1984
INFO - 2024-10-15 11:21:27 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:27 --> Total execution time: 11.6379
INFO - 2024-10-15 11:21:33 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:33 --> Total execution time: 7.5394
INFO - 2024-10-15 11:21:33 --> Final output sent to browser
DEBUG - 2024-10-15 11:21:33 --> Total execution time: 7.1714
INFO - 2024-10-15 11:36:41 --> Config Class Initialized
INFO - 2024-10-15 11:36:41 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:36:41 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:36:41 --> Utf8 Class Initialized
INFO - 2024-10-15 11:36:41 --> URI Class Initialized
INFO - 2024-10-15 11:36:41 --> Router Class Initialized
INFO - 2024-10-15 11:36:41 --> Output Class Initialized
INFO - 2024-10-15 11:36:41 --> Security Class Initialized
DEBUG - 2024-10-15 11:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:36:41 --> Input Class Initialized
INFO - 2024-10-15 11:36:41 --> Language Class Initialized
INFO - 2024-10-15 11:36:41 --> Language Class Initialized
INFO - 2024-10-15 11:36:41 --> Config Class Initialized
INFO - 2024-10-15 11:36:41 --> Loader Class Initialized
INFO - 2024-10-15 11:36:41 --> Helper loaded: url_helper
INFO - 2024-10-15 11:36:41 --> Helper loaded: file_helper
INFO - 2024-10-15 11:36:41 --> Helper loaded: form_helper
INFO - 2024-10-15 11:36:41 --> Helper loaded: my_helper
INFO - 2024-10-15 11:36:41 --> Database Driver Class Initialized
INFO - 2024-10-15 11:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:36:41 --> Controller Class Initialized
INFO - 2024-10-15 11:36:41 --> Helper loaded: cookie_helper
INFO - 2024-10-15 11:36:41 --> Final output sent to browser
DEBUG - 2024-10-15 11:36:41 --> Total execution time: 0.0338
INFO - 2024-10-15 11:36:43 --> Config Class Initialized
INFO - 2024-10-15 11:36:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:36:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:36:43 --> Utf8 Class Initialized
INFO - 2024-10-15 11:36:43 --> URI Class Initialized
INFO - 2024-10-15 11:36:43 --> Router Class Initialized
INFO - 2024-10-15 11:36:43 --> Output Class Initialized
INFO - 2024-10-15 11:36:43 --> Security Class Initialized
DEBUG - 2024-10-15 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:36:43 --> Input Class Initialized
INFO - 2024-10-15 11:36:43 --> Language Class Initialized
INFO - 2024-10-15 11:36:43 --> Language Class Initialized
INFO - 2024-10-15 11:36:43 --> Config Class Initialized
INFO - 2024-10-15 11:36:43 --> Loader Class Initialized
INFO - 2024-10-15 11:36:43 --> Helper loaded: url_helper
INFO - 2024-10-15 11:36:43 --> Helper loaded: file_helper
INFO - 2024-10-15 11:36:43 --> Helper loaded: form_helper
INFO - 2024-10-15 11:36:43 --> Helper loaded: my_helper
INFO - 2024-10-15 11:36:43 --> Database Driver Class Initialized
INFO - 2024-10-15 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:36:43 --> Controller Class Initialized
INFO - 2024-10-15 11:36:43 --> Helper loaded: cookie_helper
INFO - 2024-10-15 11:36:43 --> Config Class Initialized
INFO - 2024-10-15 11:36:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:36:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:36:43 --> Utf8 Class Initialized
INFO - 2024-10-15 11:36:43 --> URI Class Initialized
INFO - 2024-10-15 11:36:43 --> Router Class Initialized
INFO - 2024-10-15 11:36:43 --> Output Class Initialized
INFO - 2024-10-15 11:36:43 --> Security Class Initialized
DEBUG - 2024-10-15 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:36:43 --> Input Class Initialized
INFO - 2024-10-15 11:36:43 --> Language Class Initialized
INFO - 2024-10-15 11:36:43 --> Language Class Initialized
INFO - 2024-10-15 11:36:43 --> Config Class Initialized
INFO - 2024-10-15 11:36:43 --> Loader Class Initialized
INFO - 2024-10-15 11:36:43 --> Helper loaded: url_helper
INFO - 2024-10-15 11:36:43 --> Helper loaded: file_helper
INFO - 2024-10-15 11:36:43 --> Helper loaded: form_helper
INFO - 2024-10-15 11:36:43 --> Helper loaded: my_helper
INFO - 2024-10-15 11:36:43 --> Database Driver Class Initialized
INFO - 2024-10-15 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:36:43 --> Controller Class Initialized
DEBUG - 2024-10-15 11:36:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 11:36:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 11:36:43 --> Final output sent to browser
DEBUG - 2024-10-15 11:36:43 --> Total execution time: 0.0809
INFO - 2024-10-15 21:04:29 --> Config Class Initialized
INFO - 2024-10-15 21:04:29 --> Hooks Class Initialized
DEBUG - 2024-10-15 21:04:29 --> UTF-8 Support Enabled
INFO - 2024-10-15 21:04:29 --> Utf8 Class Initialized
INFO - 2024-10-15 21:04:29 --> URI Class Initialized
INFO - 2024-10-15 21:04:29 --> Router Class Initialized
INFO - 2024-10-15 21:04:29 --> Output Class Initialized
INFO - 2024-10-15 21:04:29 --> Security Class Initialized
DEBUG - 2024-10-15 21:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 21:04:29 --> Input Class Initialized
INFO - 2024-10-15 21:04:29 --> Language Class Initialized
INFO - 2024-10-15 21:04:29 --> Language Class Initialized
INFO - 2024-10-15 21:04:29 --> Config Class Initialized
INFO - 2024-10-15 21:04:29 --> Loader Class Initialized
INFO - 2024-10-15 21:04:29 --> Helper loaded: url_helper
INFO - 2024-10-15 21:04:29 --> Helper loaded: file_helper
INFO - 2024-10-15 21:04:29 --> Helper loaded: form_helper
INFO - 2024-10-15 21:04:29 --> Helper loaded: my_helper
INFO - 2024-10-15 21:04:29 --> Database Driver Class Initialized
INFO - 2024-10-15 21:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 21:04:29 --> Controller Class Initialized
INFO - 2024-10-15 21:04:30 --> Helper loaded: cookie_helper
INFO - 2024-10-15 21:04:30 --> Final output sent to browser
DEBUG - 2024-10-15 21:04:30 --> Total execution time: 0.1087
INFO - 2024-10-15 21:04:30 --> Config Class Initialized
INFO - 2024-10-15 21:04:30 --> Hooks Class Initialized
DEBUG - 2024-10-15 21:04:30 --> UTF-8 Support Enabled
INFO - 2024-10-15 21:04:30 --> Utf8 Class Initialized
INFO - 2024-10-15 21:04:31 --> URI Class Initialized
INFO - 2024-10-15 21:04:31 --> Router Class Initialized
INFO - 2024-10-15 21:04:31 --> Output Class Initialized
INFO - 2024-10-15 21:04:31 --> Security Class Initialized
DEBUG - 2024-10-15 21:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 21:04:31 --> Input Class Initialized
INFO - 2024-10-15 21:04:31 --> Language Class Initialized
INFO - 2024-10-15 21:04:31 --> Language Class Initialized
INFO - 2024-10-15 21:04:31 --> Config Class Initialized
INFO - 2024-10-15 21:04:31 --> Loader Class Initialized
INFO - 2024-10-15 21:04:31 --> Helper loaded: url_helper
INFO - 2024-10-15 21:04:31 --> Helper loaded: file_helper
INFO - 2024-10-15 21:04:31 --> Helper loaded: form_helper
INFO - 2024-10-15 21:04:31 --> Helper loaded: my_helper
INFO - 2024-10-15 21:04:31 --> Database Driver Class Initialized
INFO - 2024-10-15 21:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 21:04:31 --> Controller Class Initialized
INFO - 2024-10-15 21:04:31 --> Helper loaded: cookie_helper
INFO - 2024-10-15 21:04:31 --> Config Class Initialized
INFO - 2024-10-15 21:04:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 21:04:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 21:04:31 --> Utf8 Class Initialized
INFO - 2024-10-15 21:04:31 --> URI Class Initialized
INFO - 2024-10-15 21:04:31 --> Router Class Initialized
INFO - 2024-10-15 21:04:31 --> Output Class Initialized
INFO - 2024-10-15 21:04:31 --> Security Class Initialized
DEBUG - 2024-10-15 21:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 21:04:31 --> Input Class Initialized
INFO - 2024-10-15 21:04:31 --> Language Class Initialized
INFO - 2024-10-15 21:04:31 --> Language Class Initialized
INFO - 2024-10-15 21:04:31 --> Config Class Initialized
INFO - 2024-10-15 21:04:31 --> Loader Class Initialized
INFO - 2024-10-15 21:04:31 --> Helper loaded: url_helper
INFO - 2024-10-15 21:04:31 --> Helper loaded: file_helper
INFO - 2024-10-15 21:04:31 --> Helper loaded: form_helper
INFO - 2024-10-15 21:04:31 --> Helper loaded: my_helper
INFO - 2024-10-15 21:04:31 --> Database Driver Class Initialized
INFO - 2024-10-15 21:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 21:04:31 --> Controller Class Initialized
DEBUG - 2024-10-15 21:04:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-15 21:04:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-15 21:04:31 --> Final output sent to browser
DEBUG - 2024-10-15 21:04:31 --> Total execution time: 0.0519
INFO - 2024-10-15 21:04:35 --> Config Class Initialized
INFO - 2024-10-15 21:04:35 --> Hooks Class Initialized
DEBUG - 2024-10-15 21:04:35 --> UTF-8 Support Enabled
INFO - 2024-10-15 21:04:35 --> Utf8 Class Initialized
INFO - 2024-10-15 21:04:35 --> URI Class Initialized
INFO - 2024-10-15 21:04:35 --> Router Class Initialized
INFO - 2024-10-15 21:04:35 --> Output Class Initialized
INFO - 2024-10-15 21:04:35 --> Security Class Initialized
DEBUG - 2024-10-15 21:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 21:04:35 --> Input Class Initialized
INFO - 2024-10-15 21:04:35 --> Language Class Initialized
INFO - 2024-10-15 21:04:35 --> Language Class Initialized
INFO - 2024-10-15 21:04:35 --> Config Class Initialized
INFO - 2024-10-15 21:04:35 --> Loader Class Initialized
INFO - 2024-10-15 21:04:35 --> Helper loaded: url_helper
INFO - 2024-10-15 21:04:35 --> Helper loaded: file_helper
INFO - 2024-10-15 21:04:35 --> Helper loaded: form_helper
INFO - 2024-10-15 21:04:35 --> Helper loaded: my_helper
INFO - 2024-10-15 21:04:35 --> Database Driver Class Initialized
INFO - 2024-10-15 21:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 21:04:35 --> Controller Class Initialized
ERROR - 2024-10-15 21:04:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-15 21:04:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-15 21:04:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-15 21:04:43 --> Final output sent to browser
DEBUG - 2024-10-15 21:04:43 --> Total execution time: 7.9145
