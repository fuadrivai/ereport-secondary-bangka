<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-23 02:31:53 --> Config Class Initialized
INFO - 2020-03-23 02:31:53 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:31:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:31:54 --> Utf8 Class Initialized
INFO - 2020-03-23 02:31:54 --> URI Class Initialized
INFO - 2020-03-23 02:31:54 --> Router Class Initialized
INFO - 2020-03-23 02:31:54 --> Output Class Initialized
INFO - 2020-03-23 02:31:54 --> Security Class Initialized
DEBUG - 2020-03-23 02:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:31:54 --> Input Class Initialized
INFO - 2020-03-23 02:31:54 --> Language Class Initialized
INFO - 2020-03-23 02:31:55 --> Language Class Initialized
INFO - 2020-03-23 02:31:55 --> Config Class Initialized
INFO - 2020-03-23 02:31:55 --> Loader Class Initialized
INFO - 2020-03-23 02:31:55 --> Helper loaded: url_helper
INFO - 2020-03-23 02:31:55 --> Helper loaded: file_helper
INFO - 2020-03-23 02:31:55 --> Helper loaded: form_helper
INFO - 2020-03-23 02:31:55 --> Helper loaded: my_helper
INFO - 2020-03-23 02:31:55 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:31:55 --> Controller Class Initialized
DEBUG - 2020-03-23 02:31:56 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 02:31:56 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:31:56 --> Final output sent to browser
DEBUG - 2020-03-23 02:31:56 --> Total execution time: 2.8560
INFO - 2020-03-23 02:32:02 --> Config Class Initialized
INFO - 2020-03-23 02:32:02 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:32:02 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:32:02 --> Utf8 Class Initialized
INFO - 2020-03-23 02:32:02 --> URI Class Initialized
DEBUG - 2020-03-23 02:32:02 --> No URI present. Default controller set.
INFO - 2020-03-23 02:32:02 --> Router Class Initialized
INFO - 2020-03-23 02:32:02 --> Output Class Initialized
INFO - 2020-03-23 02:32:02 --> Security Class Initialized
DEBUG - 2020-03-23 02:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:32:02 --> Input Class Initialized
INFO - 2020-03-23 02:32:02 --> Language Class Initialized
INFO - 2020-03-23 02:32:03 --> Language Class Initialized
INFO - 2020-03-23 02:32:03 --> Config Class Initialized
INFO - 2020-03-23 02:32:03 --> Loader Class Initialized
INFO - 2020-03-23 02:32:03 --> Helper loaded: url_helper
INFO - 2020-03-23 02:32:03 --> Helper loaded: file_helper
INFO - 2020-03-23 02:32:03 --> Helper loaded: form_helper
INFO - 2020-03-23 02:32:03 --> Helper loaded: my_helper
INFO - 2020-03-23 02:32:03 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:32:03 --> Controller Class Initialized
INFO - 2020-03-23 02:32:03 --> Config Class Initialized
INFO - 2020-03-23 02:32:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:32:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:32:03 --> Utf8 Class Initialized
INFO - 2020-03-23 02:32:03 --> URI Class Initialized
INFO - 2020-03-23 02:32:03 --> Router Class Initialized
INFO - 2020-03-23 02:32:03 --> Output Class Initialized
INFO - 2020-03-23 02:32:03 --> Security Class Initialized
DEBUG - 2020-03-23 02:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:32:03 --> Input Class Initialized
INFO - 2020-03-23 02:32:03 --> Language Class Initialized
INFO - 2020-03-23 02:32:03 --> Language Class Initialized
INFO - 2020-03-23 02:32:03 --> Config Class Initialized
INFO - 2020-03-23 02:32:03 --> Loader Class Initialized
INFO - 2020-03-23 02:32:03 --> Helper loaded: url_helper
INFO - 2020-03-23 02:32:03 --> Helper loaded: file_helper
INFO - 2020-03-23 02:32:03 --> Helper loaded: form_helper
INFO - 2020-03-23 02:32:03 --> Helper loaded: my_helper
INFO - 2020-03-23 02:32:03 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:32:04 --> Controller Class Initialized
DEBUG - 2020-03-23 02:32:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 02:32:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:32:04 --> Final output sent to browser
DEBUG - 2020-03-23 02:32:04 --> Total execution time: 0.6896
INFO - 2020-03-23 02:32:11 --> Config Class Initialized
INFO - 2020-03-23 02:32:11 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:32:11 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:32:11 --> Utf8 Class Initialized
INFO - 2020-03-23 02:32:11 --> URI Class Initialized
INFO - 2020-03-23 02:32:11 --> Router Class Initialized
INFO - 2020-03-23 02:32:11 --> Output Class Initialized
INFO - 2020-03-23 02:32:11 --> Security Class Initialized
DEBUG - 2020-03-23 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:32:11 --> Input Class Initialized
INFO - 2020-03-23 02:32:11 --> Language Class Initialized
INFO - 2020-03-23 02:32:11 --> Language Class Initialized
INFO - 2020-03-23 02:32:11 --> Config Class Initialized
INFO - 2020-03-23 02:32:11 --> Loader Class Initialized
INFO - 2020-03-23 02:32:11 --> Helper loaded: url_helper
INFO - 2020-03-23 02:32:11 --> Helper loaded: file_helper
INFO - 2020-03-23 02:32:11 --> Helper loaded: form_helper
INFO - 2020-03-23 02:32:11 --> Helper loaded: my_helper
INFO - 2020-03-23 02:32:11 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:32:11 --> Controller Class Initialized
INFO - 2020-03-23 02:32:11 --> Final output sent to browser
DEBUG - 2020-03-23 02:32:11 --> Total execution time: 0.5667
INFO - 2020-03-23 02:32:16 --> Config Class Initialized
INFO - 2020-03-23 02:32:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:32:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:32:16 --> Utf8 Class Initialized
INFO - 2020-03-23 02:32:16 --> URI Class Initialized
INFO - 2020-03-23 02:32:16 --> Router Class Initialized
INFO - 2020-03-23 02:32:16 --> Output Class Initialized
INFO - 2020-03-23 02:32:16 --> Security Class Initialized
DEBUG - 2020-03-23 02:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:32:16 --> Input Class Initialized
INFO - 2020-03-23 02:32:16 --> Language Class Initialized
INFO - 2020-03-23 02:32:16 --> Language Class Initialized
INFO - 2020-03-23 02:32:16 --> Config Class Initialized
INFO - 2020-03-23 02:32:16 --> Loader Class Initialized
INFO - 2020-03-23 02:32:16 --> Helper loaded: url_helper
INFO - 2020-03-23 02:32:16 --> Helper loaded: file_helper
INFO - 2020-03-23 02:32:16 --> Helper loaded: form_helper
INFO - 2020-03-23 02:32:16 --> Helper loaded: my_helper
INFO - 2020-03-23 02:32:16 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:32:16 --> Controller Class Initialized
INFO - 2020-03-23 02:32:16 --> Final output sent to browser
DEBUG - 2020-03-23 02:32:16 --> Total execution time: 0.5663
INFO - 2020-03-23 02:32:23 --> Config Class Initialized
INFO - 2020-03-23 02:32:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:32:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:32:23 --> Utf8 Class Initialized
INFO - 2020-03-23 02:32:23 --> URI Class Initialized
INFO - 2020-03-23 02:32:23 --> Router Class Initialized
INFO - 2020-03-23 02:32:23 --> Output Class Initialized
INFO - 2020-03-23 02:32:23 --> Security Class Initialized
DEBUG - 2020-03-23 02:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:32:23 --> Input Class Initialized
INFO - 2020-03-23 02:32:23 --> Language Class Initialized
INFO - 2020-03-23 02:32:23 --> Language Class Initialized
INFO - 2020-03-23 02:32:23 --> Config Class Initialized
INFO - 2020-03-23 02:32:23 --> Loader Class Initialized
INFO - 2020-03-23 02:32:23 --> Helper loaded: url_helper
INFO - 2020-03-23 02:32:23 --> Helper loaded: file_helper
INFO - 2020-03-23 02:32:23 --> Helper loaded: form_helper
INFO - 2020-03-23 02:32:23 --> Helper loaded: my_helper
INFO - 2020-03-23 02:32:23 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:32:23 --> Controller Class Initialized
INFO - 2020-03-23 02:32:23 --> Helper loaded: cookie_helper
INFO - 2020-03-23 02:32:23 --> Final output sent to browser
DEBUG - 2020-03-23 02:32:23 --> Total execution time: 0.5408
INFO - 2020-03-23 02:32:23 --> Config Class Initialized
INFO - 2020-03-23 02:32:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:32:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:32:23 --> Utf8 Class Initialized
INFO - 2020-03-23 02:32:23 --> URI Class Initialized
INFO - 2020-03-23 02:32:23 --> Router Class Initialized
INFO - 2020-03-23 02:32:23 --> Output Class Initialized
INFO - 2020-03-23 02:32:23 --> Security Class Initialized
DEBUG - 2020-03-23 02:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:32:23 --> Input Class Initialized
INFO - 2020-03-23 02:32:24 --> Language Class Initialized
INFO - 2020-03-23 02:32:24 --> Language Class Initialized
INFO - 2020-03-23 02:32:24 --> Config Class Initialized
INFO - 2020-03-23 02:32:24 --> Loader Class Initialized
INFO - 2020-03-23 02:32:24 --> Helper loaded: url_helper
INFO - 2020-03-23 02:32:24 --> Helper loaded: file_helper
INFO - 2020-03-23 02:32:24 --> Helper loaded: form_helper
INFO - 2020-03-23 02:32:24 --> Helper loaded: my_helper
INFO - 2020-03-23 02:32:24 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:32:24 --> Controller Class Initialized
DEBUG - 2020-03-23 02:32:24 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 02:32:24 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:32:24 --> Final output sent to browser
DEBUG - 2020-03-23 02:32:26 --> Total execution time: 0.7824
INFO - 2020-03-23 02:33:34 --> Config Class Initialized
INFO - 2020-03-23 02:33:34 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:33:34 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:33:34 --> Utf8 Class Initialized
INFO - 2020-03-23 02:33:34 --> URI Class Initialized
INFO - 2020-03-23 02:33:34 --> Router Class Initialized
INFO - 2020-03-23 02:33:34 --> Output Class Initialized
INFO - 2020-03-23 02:33:34 --> Security Class Initialized
DEBUG - 2020-03-23 02:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:33:34 --> Input Class Initialized
INFO - 2020-03-23 02:33:34 --> Language Class Initialized
INFO - 2020-03-23 02:33:34 --> Language Class Initialized
INFO - 2020-03-23 02:33:34 --> Config Class Initialized
INFO - 2020-03-23 02:33:34 --> Loader Class Initialized
INFO - 2020-03-23 02:33:34 --> Helper loaded: url_helper
INFO - 2020-03-23 02:33:34 --> Helper loaded: file_helper
INFO - 2020-03-23 02:33:34 --> Helper loaded: form_helper
INFO - 2020-03-23 02:33:34 --> Helper loaded: my_helper
INFO - 2020-03-23 02:33:34 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:33:34 --> Controller Class Initialized
DEBUG - 2020-03-23 02:33:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-03-23 02:33:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:33:34 --> Final output sent to browser
DEBUG - 2020-03-23 02:33:34 --> Total execution time: 0.4556
INFO - 2020-03-23 02:33:35 --> Config Class Initialized
INFO - 2020-03-23 02:33:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:33:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:33:35 --> Utf8 Class Initialized
INFO - 2020-03-23 02:33:35 --> URI Class Initialized
INFO - 2020-03-23 02:33:35 --> Router Class Initialized
INFO - 2020-03-23 02:33:35 --> Output Class Initialized
INFO - 2020-03-23 02:33:35 --> Security Class Initialized
DEBUG - 2020-03-23 02:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:33:35 --> Input Class Initialized
INFO - 2020-03-23 02:33:35 --> Language Class Initialized
INFO - 2020-03-23 02:33:35 --> Language Class Initialized
INFO - 2020-03-23 02:33:35 --> Config Class Initialized
INFO - 2020-03-23 02:33:35 --> Loader Class Initialized
INFO - 2020-03-23 02:33:35 --> Helper loaded: url_helper
INFO - 2020-03-23 02:33:35 --> Helper loaded: file_helper
INFO - 2020-03-23 02:33:35 --> Helper loaded: form_helper
INFO - 2020-03-23 02:33:35 --> Helper loaded: my_helper
INFO - 2020-03-23 02:33:35 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:33:35 --> Controller Class Initialized
INFO - 2020-03-23 02:33:38 --> Config Class Initialized
INFO - 2020-03-23 02:33:38 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:33:38 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:33:38 --> Utf8 Class Initialized
INFO - 2020-03-23 02:33:38 --> URI Class Initialized
INFO - 2020-03-23 02:33:38 --> Router Class Initialized
INFO - 2020-03-23 02:33:38 --> Output Class Initialized
INFO - 2020-03-23 02:33:38 --> Security Class Initialized
DEBUG - 2020-03-23 02:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:33:38 --> Input Class Initialized
INFO - 2020-03-23 02:33:38 --> Language Class Initialized
INFO - 2020-03-23 02:33:38 --> Language Class Initialized
INFO - 2020-03-23 02:33:38 --> Config Class Initialized
INFO - 2020-03-23 02:33:38 --> Loader Class Initialized
INFO - 2020-03-23 02:33:38 --> Helper loaded: url_helper
INFO - 2020-03-23 02:33:38 --> Helper loaded: file_helper
INFO - 2020-03-23 02:33:38 --> Helper loaded: form_helper
INFO - 2020-03-23 02:33:38 --> Helper loaded: my_helper
INFO - 2020-03-23 02:33:38 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:33:38 --> Controller Class Initialized
INFO - 2020-03-23 02:33:38 --> Final output sent to browser
DEBUG - 2020-03-23 02:33:38 --> Total execution time: 0.7170
INFO - 2020-03-23 02:33:48 --> Config Class Initialized
INFO - 2020-03-23 02:33:48 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:33:48 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:33:48 --> Utf8 Class Initialized
INFO - 2020-03-23 02:33:48 --> URI Class Initialized
INFO - 2020-03-23 02:33:48 --> Router Class Initialized
INFO - 2020-03-23 02:33:48 --> Output Class Initialized
INFO - 2020-03-23 02:33:48 --> Security Class Initialized
DEBUG - 2020-03-23 02:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:33:48 --> Input Class Initialized
INFO - 2020-03-23 02:33:48 --> Language Class Initialized
INFO - 2020-03-23 02:33:48 --> Language Class Initialized
INFO - 2020-03-23 02:33:48 --> Config Class Initialized
INFO - 2020-03-23 02:33:48 --> Loader Class Initialized
INFO - 2020-03-23 02:33:48 --> Helper loaded: url_helper
INFO - 2020-03-23 02:33:48 --> Helper loaded: file_helper
INFO - 2020-03-23 02:33:48 --> Helper loaded: form_helper
INFO - 2020-03-23 02:33:48 --> Helper loaded: my_helper
INFO - 2020-03-23 02:33:48 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:33:48 --> Controller Class Initialized
INFO - 2020-03-23 02:33:48 --> Final output sent to browser
DEBUG - 2020-03-23 02:33:48 --> Total execution time: 0.7623
INFO - 2020-03-23 02:33:49 --> Config Class Initialized
INFO - 2020-03-23 02:33:49 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:33:49 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:33:49 --> Utf8 Class Initialized
INFO - 2020-03-23 02:33:49 --> URI Class Initialized
INFO - 2020-03-23 02:33:49 --> Router Class Initialized
INFO - 2020-03-23 02:33:49 --> Output Class Initialized
INFO - 2020-03-23 02:33:49 --> Security Class Initialized
DEBUG - 2020-03-23 02:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:33:49 --> Input Class Initialized
INFO - 2020-03-23 02:33:49 --> Language Class Initialized
INFO - 2020-03-23 02:33:49 --> Language Class Initialized
INFO - 2020-03-23 02:33:49 --> Config Class Initialized
INFO - 2020-03-23 02:33:49 --> Loader Class Initialized
INFO - 2020-03-23 02:33:49 --> Helper loaded: url_helper
INFO - 2020-03-23 02:33:49 --> Helper loaded: file_helper
INFO - 2020-03-23 02:33:49 --> Helper loaded: form_helper
INFO - 2020-03-23 02:33:49 --> Helper loaded: my_helper
INFO - 2020-03-23 02:33:49 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:33:49 --> Controller Class Initialized
INFO - 2020-03-23 02:33:52 --> Config Class Initialized
INFO - 2020-03-23 02:33:52 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:33:52 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:33:52 --> Utf8 Class Initialized
INFO - 2020-03-23 02:33:52 --> URI Class Initialized
DEBUG - 2020-03-23 02:33:52 --> No URI present. Default controller set.
INFO - 2020-03-23 02:33:52 --> Router Class Initialized
INFO - 2020-03-23 02:33:52 --> Output Class Initialized
INFO - 2020-03-23 02:33:52 --> Security Class Initialized
DEBUG - 2020-03-23 02:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:33:52 --> Input Class Initialized
INFO - 2020-03-23 02:33:52 --> Language Class Initialized
INFO - 2020-03-23 02:33:52 --> Language Class Initialized
INFO - 2020-03-23 02:33:52 --> Config Class Initialized
INFO - 2020-03-23 02:33:52 --> Loader Class Initialized
INFO - 2020-03-23 02:33:52 --> Helper loaded: url_helper
INFO - 2020-03-23 02:33:52 --> Helper loaded: file_helper
INFO - 2020-03-23 02:33:52 --> Helper loaded: form_helper
INFO - 2020-03-23 02:33:52 --> Helper loaded: my_helper
INFO - 2020-03-23 02:33:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:33:52 --> Controller Class Initialized
DEBUG - 2020-03-23 02:33:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 02:33:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:33:52 --> Final output sent to browser
DEBUG - 2020-03-23 02:33:52 --> Total execution time: 0.5145
INFO - 2020-03-23 02:56:17 --> Config Class Initialized
INFO - 2020-03-23 02:56:17 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:56:17 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:56:17 --> Utf8 Class Initialized
INFO - 2020-03-23 02:56:18 --> URI Class Initialized
DEBUG - 2020-03-23 02:56:18 --> No URI present. Default controller set.
INFO - 2020-03-23 02:56:18 --> Router Class Initialized
INFO - 2020-03-23 02:56:18 --> Output Class Initialized
INFO - 2020-03-23 02:56:18 --> Security Class Initialized
DEBUG - 2020-03-23 02:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:56:18 --> Input Class Initialized
INFO - 2020-03-23 02:56:18 --> Language Class Initialized
INFO - 2020-03-23 02:56:18 --> Language Class Initialized
INFO - 2020-03-23 02:56:18 --> Config Class Initialized
INFO - 2020-03-23 02:56:18 --> Loader Class Initialized
INFO - 2020-03-23 02:56:18 --> Helper loaded: url_helper
INFO - 2020-03-23 02:56:18 --> Helper loaded: file_helper
INFO - 2020-03-23 02:56:18 --> Helper loaded: form_helper
INFO - 2020-03-23 02:56:18 --> Helper loaded: my_helper
INFO - 2020-03-23 02:56:18 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:56:18 --> Controller Class Initialized
DEBUG - 2020-03-23 02:56:18 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 02:56:18 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:56:18 --> Final output sent to browser
DEBUG - 2020-03-23 02:56:18 --> Total execution time: 0.4591
INFO - 2020-03-23 02:56:20 --> Config Class Initialized
INFO - 2020-03-23 02:56:20 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:56:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:56:20 --> Utf8 Class Initialized
INFO - 2020-03-23 02:56:20 --> URI Class Initialized
DEBUG - 2020-03-23 02:56:20 --> No URI present. Default controller set.
INFO - 2020-03-23 02:56:20 --> Router Class Initialized
INFO - 2020-03-23 02:56:20 --> Output Class Initialized
INFO - 2020-03-23 02:56:20 --> Security Class Initialized
DEBUG - 2020-03-23 02:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:56:20 --> Input Class Initialized
INFO - 2020-03-23 02:56:20 --> Language Class Initialized
INFO - 2020-03-23 02:56:20 --> Language Class Initialized
INFO - 2020-03-23 02:56:20 --> Config Class Initialized
INFO - 2020-03-23 02:56:20 --> Loader Class Initialized
INFO - 2020-03-23 02:56:20 --> Helper loaded: url_helper
INFO - 2020-03-23 02:56:20 --> Helper loaded: file_helper
INFO - 2020-03-23 02:56:20 --> Helper loaded: form_helper
INFO - 2020-03-23 02:56:20 --> Helper loaded: my_helper
INFO - 2020-03-23 02:56:20 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:56:20 --> Controller Class Initialized
DEBUG - 2020-03-23 02:56:20 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 02:56:20 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:56:20 --> Final output sent to browser
DEBUG - 2020-03-23 02:56:20 --> Total execution time: 0.4289
INFO - 2020-03-23 02:56:22 --> Config Class Initialized
INFO - 2020-03-23 02:56:22 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:56:22 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:56:22 --> Utf8 Class Initialized
INFO - 2020-03-23 02:56:22 --> URI Class Initialized
INFO - 2020-03-23 02:56:22 --> Router Class Initialized
INFO - 2020-03-23 02:56:22 --> Output Class Initialized
INFO - 2020-03-23 02:56:22 --> Security Class Initialized
DEBUG - 2020-03-23 02:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:56:22 --> Input Class Initialized
INFO - 2020-03-23 02:56:22 --> Language Class Initialized
INFO - 2020-03-23 02:56:22 --> Language Class Initialized
INFO - 2020-03-23 02:56:22 --> Config Class Initialized
INFO - 2020-03-23 02:56:22 --> Loader Class Initialized
INFO - 2020-03-23 02:56:22 --> Helper loaded: url_helper
INFO - 2020-03-23 02:56:22 --> Helper loaded: file_helper
INFO - 2020-03-23 02:56:22 --> Helper loaded: form_helper
INFO - 2020-03-23 02:56:22 --> Helper loaded: my_helper
INFO - 2020-03-23 02:56:22 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:56:22 --> Controller Class Initialized
INFO - 2020-03-23 02:56:23 --> Helper loaded: cookie_helper
INFO - 2020-03-23 02:56:23 --> Config Class Initialized
INFO - 2020-03-23 02:56:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:56:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:56:23 --> Utf8 Class Initialized
INFO - 2020-03-23 02:56:23 --> URI Class Initialized
INFO - 2020-03-23 02:56:23 --> Router Class Initialized
INFO - 2020-03-23 02:56:23 --> Output Class Initialized
INFO - 2020-03-23 02:56:23 --> Security Class Initialized
DEBUG - 2020-03-23 02:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:56:23 --> Input Class Initialized
INFO - 2020-03-23 02:56:23 --> Language Class Initialized
INFO - 2020-03-23 02:56:23 --> Language Class Initialized
INFO - 2020-03-23 02:56:23 --> Config Class Initialized
INFO - 2020-03-23 02:56:23 --> Loader Class Initialized
INFO - 2020-03-23 02:56:23 --> Helper loaded: url_helper
INFO - 2020-03-23 02:56:23 --> Helper loaded: file_helper
INFO - 2020-03-23 02:56:23 --> Helper loaded: form_helper
INFO - 2020-03-23 02:56:23 --> Helper loaded: my_helper
INFO - 2020-03-23 02:56:23 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:56:23 --> Controller Class Initialized
INFO - 2020-03-23 02:56:23 --> Config Class Initialized
INFO - 2020-03-23 02:56:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:56:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:56:23 --> Utf8 Class Initialized
INFO - 2020-03-23 02:56:23 --> URI Class Initialized
INFO - 2020-03-23 02:56:23 --> Router Class Initialized
INFO - 2020-03-23 02:56:23 --> Output Class Initialized
INFO - 2020-03-23 02:56:23 --> Security Class Initialized
DEBUG - 2020-03-23 02:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:56:23 --> Input Class Initialized
INFO - 2020-03-23 02:56:23 --> Language Class Initialized
INFO - 2020-03-23 02:56:23 --> Language Class Initialized
INFO - 2020-03-23 02:56:23 --> Config Class Initialized
INFO - 2020-03-23 02:56:23 --> Loader Class Initialized
INFO - 2020-03-23 02:56:23 --> Helper loaded: url_helper
INFO - 2020-03-23 02:56:23 --> Helper loaded: file_helper
INFO - 2020-03-23 02:56:23 --> Helper loaded: form_helper
INFO - 2020-03-23 02:56:23 --> Helper loaded: my_helper
INFO - 2020-03-23 02:56:23 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:56:23 --> Controller Class Initialized
DEBUG - 2020-03-23 02:56:23 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 02:56:23 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:56:23 --> Final output sent to browser
DEBUG - 2020-03-23 02:56:23 --> Total execution time: 0.3939
INFO - 2020-03-23 02:59:50 --> Config Class Initialized
INFO - 2020-03-23 02:59:50 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:59:50 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:59:50 --> Utf8 Class Initialized
INFO - 2020-03-23 02:59:50 --> URI Class Initialized
INFO - 2020-03-23 02:59:50 --> Router Class Initialized
INFO - 2020-03-23 02:59:50 --> Output Class Initialized
INFO - 2020-03-23 02:59:50 --> Security Class Initialized
DEBUG - 2020-03-23 02:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:59:50 --> Input Class Initialized
INFO - 2020-03-23 02:59:50 --> Language Class Initialized
INFO - 2020-03-23 02:59:51 --> Language Class Initialized
INFO - 2020-03-23 02:59:51 --> Config Class Initialized
INFO - 2020-03-23 02:59:51 --> Loader Class Initialized
INFO - 2020-03-23 02:59:51 --> Helper loaded: url_helper
INFO - 2020-03-23 02:59:51 --> Helper loaded: file_helper
INFO - 2020-03-23 02:59:51 --> Helper loaded: form_helper
INFO - 2020-03-23 02:59:51 --> Helper loaded: my_helper
INFO - 2020-03-23 02:59:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:59:51 --> Controller Class Initialized
INFO - 2020-03-23 02:59:51 --> Helper loaded: cookie_helper
INFO - 2020-03-23 02:59:51 --> Final output sent to browser
DEBUG - 2020-03-23 02:59:51 --> Total execution time: 0.4578
INFO - 2020-03-23 02:59:51 --> Config Class Initialized
INFO - 2020-03-23 02:59:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 02:59:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 02:59:51 --> Utf8 Class Initialized
INFO - 2020-03-23 02:59:51 --> URI Class Initialized
INFO - 2020-03-23 02:59:51 --> Router Class Initialized
INFO - 2020-03-23 02:59:51 --> Output Class Initialized
INFO - 2020-03-23 02:59:51 --> Security Class Initialized
DEBUG - 2020-03-23 02:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 02:59:51 --> Input Class Initialized
INFO - 2020-03-23 02:59:51 --> Language Class Initialized
INFO - 2020-03-23 02:59:51 --> Language Class Initialized
INFO - 2020-03-23 02:59:51 --> Config Class Initialized
INFO - 2020-03-23 02:59:51 --> Loader Class Initialized
INFO - 2020-03-23 02:59:51 --> Helper loaded: url_helper
INFO - 2020-03-23 02:59:51 --> Helper loaded: file_helper
INFO - 2020-03-23 02:59:51 --> Helper loaded: form_helper
INFO - 2020-03-23 02:59:51 --> Helper loaded: my_helper
INFO - 2020-03-23 02:59:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 02:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 02:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 02:59:51 --> Controller Class Initialized
DEBUG - 2020-03-23 02:59:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 02:59:51 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 02:59:52 --> Final output sent to browser
DEBUG - 2020-03-23 02:59:55 --> Total execution time: 0.6537
INFO - 2020-03-23 03:00:16 --> Config Class Initialized
INFO - 2020-03-23 03:00:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:16 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:16 --> URI Class Initialized
INFO - 2020-03-23 03:00:16 --> Router Class Initialized
INFO - 2020-03-23 03:00:16 --> Output Class Initialized
INFO - 2020-03-23 03:00:16 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:16 --> Input Class Initialized
INFO - 2020-03-23 03:00:16 --> Language Class Initialized
INFO - 2020-03-23 03:00:16 --> Language Class Initialized
INFO - 2020-03-23 03:00:16 --> Config Class Initialized
INFO - 2020-03-23 03:00:17 --> Loader Class Initialized
INFO - 2020-03-23 03:00:17 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:17 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:17 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:17 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:17 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:17 --> Controller Class Initialized
DEBUG - 2020-03-23 03:00:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 03:00:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:00:17 --> Final output sent to browser
DEBUG - 2020-03-23 03:00:17 --> Total execution time: 0.5247
INFO - 2020-03-23 03:00:18 --> Config Class Initialized
INFO - 2020-03-23 03:00:18 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:18 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:18 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:18 --> URI Class Initialized
INFO - 2020-03-23 03:00:18 --> Router Class Initialized
INFO - 2020-03-23 03:00:18 --> Output Class Initialized
INFO - 2020-03-23 03:00:18 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:18 --> Input Class Initialized
INFO - 2020-03-23 03:00:18 --> Language Class Initialized
INFO - 2020-03-23 03:00:18 --> Language Class Initialized
INFO - 2020-03-23 03:00:18 --> Config Class Initialized
INFO - 2020-03-23 03:00:18 --> Loader Class Initialized
INFO - 2020-03-23 03:00:18 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:18 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:18 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:18 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:18 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:18 --> Controller Class Initialized
INFO - 2020-03-23 03:00:33 --> Config Class Initialized
INFO - 2020-03-23 03:00:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:33 --> URI Class Initialized
INFO - 2020-03-23 03:00:33 --> Router Class Initialized
INFO - 2020-03-23 03:00:33 --> Output Class Initialized
INFO - 2020-03-23 03:00:33 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:33 --> Input Class Initialized
INFO - 2020-03-23 03:00:33 --> Language Class Initialized
INFO - 2020-03-23 03:00:33 --> Language Class Initialized
INFO - 2020-03-23 03:00:33 --> Config Class Initialized
INFO - 2020-03-23 03:00:33 --> Loader Class Initialized
INFO - 2020-03-23 03:00:33 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:33 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:34 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:34 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:34 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:34 --> Controller Class Initialized
DEBUG - 2020-03-23 03:00:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-23 03:00:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:00:34 --> Final output sent to browser
DEBUG - 2020-03-23 03:00:34 --> Total execution time: 0.4977
INFO - 2020-03-23 03:00:34 --> Config Class Initialized
INFO - 2020-03-23 03:00:34 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:34 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:34 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:34 --> URI Class Initialized
INFO - 2020-03-23 03:00:34 --> Router Class Initialized
INFO - 2020-03-23 03:00:34 --> Output Class Initialized
INFO - 2020-03-23 03:00:34 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:34 --> Input Class Initialized
INFO - 2020-03-23 03:00:34 --> Language Class Initialized
INFO - 2020-03-23 03:00:35 --> Language Class Initialized
INFO - 2020-03-23 03:00:35 --> Config Class Initialized
INFO - 2020-03-23 03:00:35 --> Loader Class Initialized
INFO - 2020-03-23 03:00:35 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:35 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:35 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:35 --> Controller Class Initialized
INFO - 2020-03-23 03:00:36 --> Config Class Initialized
INFO - 2020-03-23 03:00:36 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:36 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:36 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:36 --> URI Class Initialized
INFO - 2020-03-23 03:00:36 --> Router Class Initialized
INFO - 2020-03-23 03:00:36 --> Output Class Initialized
INFO - 2020-03-23 03:00:36 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:36 --> Input Class Initialized
INFO - 2020-03-23 03:00:36 --> Language Class Initialized
INFO - 2020-03-23 03:00:36 --> Language Class Initialized
INFO - 2020-03-23 03:00:36 --> Config Class Initialized
INFO - 2020-03-23 03:00:36 --> Loader Class Initialized
INFO - 2020-03-23 03:00:36 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:36 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:36 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:37 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:37 --> Controller Class Initialized
INFO - 2020-03-23 03:00:37 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:00:37 --> Config Class Initialized
INFO - 2020-03-23 03:00:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:37 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:37 --> URI Class Initialized
INFO - 2020-03-23 03:00:37 --> Router Class Initialized
INFO - 2020-03-23 03:00:37 --> Output Class Initialized
INFO - 2020-03-23 03:00:37 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:37 --> Input Class Initialized
INFO - 2020-03-23 03:00:37 --> Language Class Initialized
INFO - 2020-03-23 03:00:37 --> Language Class Initialized
INFO - 2020-03-23 03:00:37 --> Config Class Initialized
INFO - 2020-03-23 03:00:37 --> Loader Class Initialized
INFO - 2020-03-23 03:00:37 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:37 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:37 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:37 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:37 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:37 --> Controller Class Initialized
INFO - 2020-03-23 03:00:37 --> Config Class Initialized
INFO - 2020-03-23 03:00:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:37 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:37 --> URI Class Initialized
INFO - 2020-03-23 03:00:37 --> Router Class Initialized
INFO - 2020-03-23 03:00:37 --> Output Class Initialized
INFO - 2020-03-23 03:00:37 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:37 --> Input Class Initialized
INFO - 2020-03-23 03:00:37 --> Language Class Initialized
INFO - 2020-03-23 03:00:37 --> Language Class Initialized
INFO - 2020-03-23 03:00:37 --> Config Class Initialized
INFO - 2020-03-23 03:00:37 --> Loader Class Initialized
INFO - 2020-03-23 03:00:37 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:37 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:37 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:37 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:37 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:37 --> Controller Class Initialized
DEBUG - 2020-03-23 03:00:37 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:00:37 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:00:38 --> Final output sent to browser
DEBUG - 2020-03-23 03:00:38 --> Total execution time: 0.4177
INFO - 2020-03-23 03:00:43 --> Config Class Initialized
INFO - 2020-03-23 03:00:43 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:43 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:43 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:43 --> URI Class Initialized
INFO - 2020-03-23 03:00:43 --> Router Class Initialized
INFO - 2020-03-23 03:00:43 --> Output Class Initialized
INFO - 2020-03-23 03:00:43 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:43 --> Input Class Initialized
INFO - 2020-03-23 03:00:43 --> Language Class Initialized
INFO - 2020-03-23 03:00:43 --> Language Class Initialized
INFO - 2020-03-23 03:00:43 --> Config Class Initialized
INFO - 2020-03-23 03:00:43 --> Loader Class Initialized
INFO - 2020-03-23 03:00:43 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:43 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:43 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:43 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:43 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:43 --> Controller Class Initialized
INFO - 2020-03-23 03:00:43 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:00:44 --> Final output sent to browser
DEBUG - 2020-03-23 03:00:44 --> Total execution time: 0.4891
INFO - 2020-03-23 03:00:44 --> Config Class Initialized
INFO - 2020-03-23 03:00:44 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:44 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:44 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:44 --> URI Class Initialized
INFO - 2020-03-23 03:00:44 --> Router Class Initialized
INFO - 2020-03-23 03:00:44 --> Output Class Initialized
INFO - 2020-03-23 03:00:44 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:44 --> Input Class Initialized
INFO - 2020-03-23 03:00:44 --> Language Class Initialized
INFO - 2020-03-23 03:00:44 --> Language Class Initialized
INFO - 2020-03-23 03:00:44 --> Config Class Initialized
INFO - 2020-03-23 03:00:44 --> Loader Class Initialized
INFO - 2020-03-23 03:00:44 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:44 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:44 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:44 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:44 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:44 --> Controller Class Initialized
DEBUG - 2020-03-23 03:00:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-23 03:00:44 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:00:44 --> Final output sent to browser
DEBUG - 2020-03-23 03:00:44 --> Total execution time: 0.7844
INFO - 2020-03-23 03:00:58 --> Config Class Initialized
INFO - 2020-03-23 03:00:58 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:58 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:58 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:58 --> URI Class Initialized
INFO - 2020-03-23 03:00:58 --> Router Class Initialized
INFO - 2020-03-23 03:00:58 --> Output Class Initialized
INFO - 2020-03-23 03:00:58 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:58 --> Input Class Initialized
INFO - 2020-03-23 03:00:58 --> Language Class Initialized
INFO - 2020-03-23 03:00:58 --> Language Class Initialized
INFO - 2020-03-23 03:00:58 --> Config Class Initialized
INFO - 2020-03-23 03:00:58 --> Loader Class Initialized
INFO - 2020-03-23 03:00:58 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:58 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:58 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:58 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:58 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:58 --> Controller Class Initialized
INFO - 2020-03-23 03:00:58 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:00:58 --> Config Class Initialized
INFO - 2020-03-23 03:00:58 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:58 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:58 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:58 --> URI Class Initialized
INFO - 2020-03-23 03:00:58 --> Router Class Initialized
INFO - 2020-03-23 03:00:58 --> Output Class Initialized
INFO - 2020-03-23 03:00:58 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:58 --> Input Class Initialized
INFO - 2020-03-23 03:00:58 --> Language Class Initialized
INFO - 2020-03-23 03:00:58 --> Language Class Initialized
INFO - 2020-03-23 03:00:58 --> Config Class Initialized
INFO - 2020-03-23 03:00:58 --> Loader Class Initialized
INFO - 2020-03-23 03:00:58 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:58 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:58 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:58 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:58 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:58 --> Controller Class Initialized
INFO - 2020-03-23 03:00:59 --> Config Class Initialized
INFO - 2020-03-23 03:00:59 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:00:59 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:00:59 --> Utf8 Class Initialized
INFO - 2020-03-23 03:00:59 --> URI Class Initialized
INFO - 2020-03-23 03:00:59 --> Router Class Initialized
INFO - 2020-03-23 03:00:59 --> Output Class Initialized
INFO - 2020-03-23 03:00:59 --> Security Class Initialized
DEBUG - 2020-03-23 03:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:00:59 --> Input Class Initialized
INFO - 2020-03-23 03:00:59 --> Language Class Initialized
INFO - 2020-03-23 03:00:59 --> Language Class Initialized
INFO - 2020-03-23 03:00:59 --> Config Class Initialized
INFO - 2020-03-23 03:00:59 --> Loader Class Initialized
INFO - 2020-03-23 03:00:59 --> Helper loaded: url_helper
INFO - 2020-03-23 03:00:59 --> Helper loaded: file_helper
INFO - 2020-03-23 03:00:59 --> Helper loaded: form_helper
INFO - 2020-03-23 03:00:59 --> Helper loaded: my_helper
INFO - 2020-03-23 03:00:59 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:00:59 --> Controller Class Initialized
DEBUG - 2020-03-23 03:00:59 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:00:59 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:00:59 --> Final output sent to browser
DEBUG - 2020-03-23 03:00:59 --> Total execution time: 0.4152
INFO - 2020-03-23 03:01:06 --> Config Class Initialized
INFO - 2020-03-23 03:01:06 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:06 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:06 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:06 --> URI Class Initialized
INFO - 2020-03-23 03:01:06 --> Router Class Initialized
INFO - 2020-03-23 03:01:06 --> Output Class Initialized
INFO - 2020-03-23 03:01:06 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:06 --> Input Class Initialized
INFO - 2020-03-23 03:01:06 --> Language Class Initialized
INFO - 2020-03-23 03:01:06 --> Language Class Initialized
INFO - 2020-03-23 03:01:06 --> Config Class Initialized
INFO - 2020-03-23 03:01:06 --> Loader Class Initialized
INFO - 2020-03-23 03:01:06 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:06 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:06 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:07 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:07 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:07 --> Controller Class Initialized
INFO - 2020-03-23 03:01:07 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:01:07 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:07 --> Total execution time: 0.4668
INFO - 2020-03-23 03:01:07 --> Config Class Initialized
INFO - 2020-03-23 03:01:07 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:07 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:07 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:07 --> URI Class Initialized
INFO - 2020-03-23 03:01:07 --> Router Class Initialized
INFO - 2020-03-23 03:01:07 --> Output Class Initialized
INFO - 2020-03-23 03:01:07 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:07 --> Input Class Initialized
INFO - 2020-03-23 03:01:07 --> Language Class Initialized
INFO - 2020-03-23 03:01:07 --> Language Class Initialized
INFO - 2020-03-23 03:01:07 --> Config Class Initialized
INFO - 2020-03-23 03:01:07 --> Loader Class Initialized
INFO - 2020-03-23 03:01:07 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:07 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:07 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:07 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:07 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:07 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:07 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 03:01:07 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:07 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:09 --> Total execution time: 0.6388
INFO - 2020-03-23 03:01:15 --> Config Class Initialized
INFO - 2020-03-23 03:01:15 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:15 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:15 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:15 --> URI Class Initialized
INFO - 2020-03-23 03:01:15 --> Router Class Initialized
INFO - 2020-03-23 03:01:15 --> Output Class Initialized
INFO - 2020-03-23 03:01:15 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:15 --> Input Class Initialized
INFO - 2020-03-23 03:01:15 --> Language Class Initialized
INFO - 2020-03-23 03:01:15 --> Language Class Initialized
INFO - 2020-03-23 03:01:15 --> Config Class Initialized
INFO - 2020-03-23 03:01:15 --> Loader Class Initialized
INFO - 2020-03-23 03:01:15 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:15 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:15 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:15 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:15 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:15 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:15 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 03:01:15 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:15 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:15 --> Total execution time: 0.4408
INFO - 2020-03-23 03:01:16 --> Config Class Initialized
INFO - 2020-03-23 03:01:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:16 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:16 --> URI Class Initialized
INFO - 2020-03-23 03:01:16 --> Router Class Initialized
INFO - 2020-03-23 03:01:16 --> Output Class Initialized
INFO - 2020-03-23 03:01:16 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:16 --> Input Class Initialized
INFO - 2020-03-23 03:01:16 --> Language Class Initialized
INFO - 2020-03-23 03:01:16 --> Language Class Initialized
INFO - 2020-03-23 03:01:16 --> Config Class Initialized
INFO - 2020-03-23 03:01:16 --> Loader Class Initialized
INFO - 2020-03-23 03:01:16 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:16 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:16 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:16 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:16 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:16 --> Controller Class Initialized
INFO - 2020-03-23 03:01:28 --> Config Class Initialized
INFO - 2020-03-23 03:01:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:28 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:28 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:28 --> URI Class Initialized
INFO - 2020-03-23 03:01:28 --> Router Class Initialized
INFO - 2020-03-23 03:01:28 --> Output Class Initialized
INFO - 2020-03-23 03:01:29 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:29 --> Input Class Initialized
INFO - 2020-03-23 03:01:29 --> Language Class Initialized
INFO - 2020-03-23 03:01:29 --> Language Class Initialized
INFO - 2020-03-23 03:01:29 --> Config Class Initialized
INFO - 2020-03-23 03:01:29 --> Loader Class Initialized
INFO - 2020-03-23 03:01:29 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:29 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:29 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:29 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:29 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:29 --> Controller Class Initialized
INFO - 2020-03-23 03:01:29 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:01:29 --> Config Class Initialized
INFO - 2020-03-23 03:01:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:29 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:29 --> URI Class Initialized
INFO - 2020-03-23 03:01:29 --> Router Class Initialized
INFO - 2020-03-23 03:01:29 --> Output Class Initialized
INFO - 2020-03-23 03:01:29 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:29 --> Input Class Initialized
INFO - 2020-03-23 03:01:29 --> Language Class Initialized
INFO - 2020-03-23 03:01:29 --> Language Class Initialized
INFO - 2020-03-23 03:01:29 --> Config Class Initialized
INFO - 2020-03-23 03:01:29 --> Loader Class Initialized
INFO - 2020-03-23 03:01:29 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:29 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:29 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:29 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:29 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:29 --> Controller Class Initialized
INFO - 2020-03-23 03:01:29 --> Config Class Initialized
INFO - 2020-03-23 03:01:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:29 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:29 --> URI Class Initialized
INFO - 2020-03-23 03:01:30 --> Router Class Initialized
INFO - 2020-03-23 03:01:30 --> Output Class Initialized
INFO - 2020-03-23 03:01:30 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:30 --> Input Class Initialized
INFO - 2020-03-23 03:01:30 --> Language Class Initialized
INFO - 2020-03-23 03:01:30 --> Language Class Initialized
INFO - 2020-03-23 03:01:30 --> Config Class Initialized
INFO - 2020-03-23 03:01:30 --> Loader Class Initialized
INFO - 2020-03-23 03:01:30 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:30 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:30 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:30 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:30 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:30 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:30 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:01:30 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:30 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:30 --> Total execution time: 0.4753
INFO - 2020-03-23 03:01:35 --> Config Class Initialized
INFO - 2020-03-23 03:01:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:35 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:35 --> URI Class Initialized
INFO - 2020-03-23 03:01:35 --> Router Class Initialized
INFO - 2020-03-23 03:01:35 --> Output Class Initialized
INFO - 2020-03-23 03:01:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:35 --> Input Class Initialized
INFO - 2020-03-23 03:01:35 --> Language Class Initialized
INFO - 2020-03-23 03:01:35 --> Language Class Initialized
INFO - 2020-03-23 03:01:35 --> Config Class Initialized
INFO - 2020-03-23 03:01:35 --> Loader Class Initialized
INFO - 2020-03-23 03:01:35 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:36 --> Controller Class Initialized
INFO - 2020-03-23 03:01:36 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:01:36 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:36 --> Total execution time: 0.5055
INFO - 2020-03-23 03:01:36 --> Config Class Initialized
INFO - 2020-03-23 03:01:36 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:36 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:36 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:36 --> URI Class Initialized
INFO - 2020-03-23 03:01:36 --> Router Class Initialized
INFO - 2020-03-23 03:01:36 --> Output Class Initialized
INFO - 2020-03-23 03:01:36 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:36 --> Input Class Initialized
INFO - 2020-03-23 03:01:36 --> Language Class Initialized
INFO - 2020-03-23 03:01:36 --> Language Class Initialized
INFO - 2020-03-23 03:01:36 --> Config Class Initialized
INFO - 2020-03-23 03:01:36 --> Loader Class Initialized
INFO - 2020-03-23 03:01:36 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:36 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:36 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:36 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:36 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-23 03:01:36 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:36 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:37 --> Total execution time: 0.5841
INFO - 2020-03-23 03:01:44 --> Config Class Initialized
INFO - 2020-03-23 03:01:44 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:44 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:44 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:44 --> URI Class Initialized
INFO - 2020-03-23 03:01:44 --> Router Class Initialized
INFO - 2020-03-23 03:01:44 --> Output Class Initialized
INFO - 2020-03-23 03:01:44 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:44 --> Input Class Initialized
INFO - 2020-03-23 03:01:44 --> Language Class Initialized
INFO - 2020-03-23 03:01:44 --> Language Class Initialized
INFO - 2020-03-23 03:01:44 --> Config Class Initialized
INFO - 2020-03-23 03:01:44 --> Loader Class Initialized
INFO - 2020-03-23 03:01:44 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:44 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:44 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:44 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:44 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:44 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:45 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-23 03:01:45 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:45 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:45 --> Total execution time: 0.5416
INFO - 2020-03-23 03:01:46 --> Config Class Initialized
INFO - 2020-03-23 03:01:46 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:46 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:46 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:46 --> URI Class Initialized
DEBUG - 2020-03-23 03:01:46 --> No URI present. Default controller set.
INFO - 2020-03-23 03:01:46 --> Router Class Initialized
INFO - 2020-03-23 03:01:46 --> Output Class Initialized
INFO - 2020-03-23 03:01:46 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:46 --> Input Class Initialized
INFO - 2020-03-23 03:01:46 --> Language Class Initialized
INFO - 2020-03-23 03:01:46 --> Language Class Initialized
INFO - 2020-03-23 03:01:46 --> Config Class Initialized
INFO - 2020-03-23 03:01:46 --> Loader Class Initialized
INFO - 2020-03-23 03:01:46 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:46 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:46 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:46 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:46 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:46 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:46 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-23 03:01:47 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:47 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:47 --> Total execution time: 0.4884
INFO - 2020-03-23 03:01:50 --> Config Class Initialized
INFO - 2020-03-23 03:01:50 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:50 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:50 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:50 --> URI Class Initialized
INFO - 2020-03-23 03:01:50 --> Router Class Initialized
INFO - 2020-03-23 03:01:50 --> Output Class Initialized
INFO - 2020-03-23 03:01:50 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:50 --> Input Class Initialized
INFO - 2020-03-23 03:01:50 --> Language Class Initialized
INFO - 2020-03-23 03:01:51 --> Language Class Initialized
INFO - 2020-03-23 03:01:51 --> Config Class Initialized
INFO - 2020-03-23 03:01:51 --> Loader Class Initialized
INFO - 2020-03-23 03:01:51 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:51 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:51 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:51 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:51 --> Controller Class Initialized
DEBUG - 2020-03-23 03:01:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-23 03:01:51 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:01:51 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:51 --> Total execution time: 0.6170
INFO - 2020-03-23 03:01:51 --> Config Class Initialized
INFO - 2020-03-23 03:01:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:52 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:52 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:52 --> URI Class Initialized
INFO - 2020-03-23 03:01:52 --> Router Class Initialized
INFO - 2020-03-23 03:01:52 --> Output Class Initialized
INFO - 2020-03-23 03:01:52 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:52 --> Input Class Initialized
INFO - 2020-03-23 03:01:52 --> Language Class Initialized
INFO - 2020-03-23 03:01:52 --> Language Class Initialized
INFO - 2020-03-23 03:01:52 --> Config Class Initialized
INFO - 2020-03-23 03:01:52 --> Loader Class Initialized
INFO - 2020-03-23 03:01:52 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:52 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:52 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:52 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:52 --> Controller Class Initialized
INFO - 2020-03-23 03:01:55 --> Config Class Initialized
INFO - 2020-03-23 03:01:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:01:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:01:55 --> Utf8 Class Initialized
INFO - 2020-03-23 03:01:55 --> URI Class Initialized
INFO - 2020-03-23 03:01:55 --> Router Class Initialized
INFO - 2020-03-23 03:01:55 --> Output Class Initialized
INFO - 2020-03-23 03:01:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:01:55 --> Input Class Initialized
INFO - 2020-03-23 03:01:55 --> Language Class Initialized
INFO - 2020-03-23 03:01:55 --> Language Class Initialized
INFO - 2020-03-23 03:01:55 --> Config Class Initialized
INFO - 2020-03-23 03:01:55 --> Loader Class Initialized
INFO - 2020-03-23 03:01:55 --> Helper loaded: url_helper
INFO - 2020-03-23 03:01:56 --> Helper loaded: file_helper
INFO - 2020-03-23 03:01:56 --> Helper loaded: form_helper
INFO - 2020-03-23 03:01:56 --> Helper loaded: my_helper
INFO - 2020-03-23 03:01:56 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:01:56 --> Controller Class Initialized
INFO - 2020-03-23 03:01:56 --> Final output sent to browser
DEBUG - 2020-03-23 03:01:56 --> Total execution time: 0.4294
INFO - 2020-03-23 03:02:07 --> Config Class Initialized
INFO - 2020-03-23 03:02:07 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:07 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:07 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:07 --> URI Class Initialized
INFO - 2020-03-23 03:02:07 --> Router Class Initialized
INFO - 2020-03-23 03:02:07 --> Output Class Initialized
INFO - 2020-03-23 03:02:07 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:07 --> Input Class Initialized
INFO - 2020-03-23 03:02:07 --> Language Class Initialized
INFO - 2020-03-23 03:02:07 --> Language Class Initialized
INFO - 2020-03-23 03:02:07 --> Config Class Initialized
INFO - 2020-03-23 03:02:07 --> Loader Class Initialized
INFO - 2020-03-23 03:02:07 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:07 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:07 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:07 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:07 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:07 --> Controller Class Initialized
DEBUG - 2020-03-23 03:02:07 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-03-23 03:02:07 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:02:07 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:08 --> Total execution time: 0.5383
INFO - 2020-03-23 03:02:10 --> Config Class Initialized
INFO - 2020-03-23 03:02:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:10 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:10 --> URI Class Initialized
INFO - 2020-03-23 03:02:10 --> Router Class Initialized
INFO - 2020-03-23 03:02:10 --> Output Class Initialized
INFO - 2020-03-23 03:02:10 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:10 --> Input Class Initialized
INFO - 2020-03-23 03:02:10 --> Language Class Initialized
INFO - 2020-03-23 03:02:10 --> Language Class Initialized
INFO - 2020-03-23 03:02:11 --> Config Class Initialized
INFO - 2020-03-23 03:02:11 --> Loader Class Initialized
INFO - 2020-03-23 03:02:11 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:11 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:11 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:11 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:11 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:11 --> Controller Class Initialized
DEBUG - 2020-03-23 03:02:11 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-23 03:02:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:02:11 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:11 --> Total execution time: 0.7676
INFO - 2020-03-23 03:02:11 --> Config Class Initialized
INFO - 2020-03-23 03:02:11 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:11 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:11 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:11 --> URI Class Initialized
INFO - 2020-03-23 03:02:11 --> Router Class Initialized
INFO - 2020-03-23 03:02:12 --> Output Class Initialized
INFO - 2020-03-23 03:02:12 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:12 --> Input Class Initialized
INFO - 2020-03-23 03:02:12 --> Language Class Initialized
INFO - 2020-03-23 03:02:12 --> Language Class Initialized
INFO - 2020-03-23 03:02:12 --> Config Class Initialized
INFO - 2020-03-23 03:02:12 --> Loader Class Initialized
INFO - 2020-03-23 03:02:12 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:12 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:12 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:12 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:12 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:12 --> Controller Class Initialized
INFO - 2020-03-23 03:02:15 --> Config Class Initialized
INFO - 2020-03-23 03:02:15 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:15 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:15 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:15 --> URI Class Initialized
INFO - 2020-03-23 03:02:16 --> Router Class Initialized
INFO - 2020-03-23 03:02:16 --> Output Class Initialized
INFO - 2020-03-23 03:02:16 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:16 --> Input Class Initialized
INFO - 2020-03-23 03:02:16 --> Language Class Initialized
INFO - 2020-03-23 03:02:16 --> Language Class Initialized
INFO - 2020-03-23 03:02:16 --> Config Class Initialized
INFO - 2020-03-23 03:02:16 --> Loader Class Initialized
INFO - 2020-03-23 03:02:16 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:16 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:16 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:16 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:16 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:16 --> Controller Class Initialized
INFO - 2020-03-23 03:02:16 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:16 --> Total execution time: 0.4080
INFO - 2020-03-23 03:02:17 --> Config Class Initialized
INFO - 2020-03-23 03:02:17 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:17 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:17 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:17 --> URI Class Initialized
INFO - 2020-03-23 03:02:17 --> Router Class Initialized
INFO - 2020-03-23 03:02:17 --> Output Class Initialized
INFO - 2020-03-23 03:02:17 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:17 --> Input Class Initialized
INFO - 2020-03-23 03:02:17 --> Language Class Initialized
INFO - 2020-03-23 03:02:17 --> Language Class Initialized
INFO - 2020-03-23 03:02:17 --> Config Class Initialized
INFO - 2020-03-23 03:02:17 --> Loader Class Initialized
INFO - 2020-03-23 03:02:17 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:17 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:17 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:17 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:17 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:17 --> Controller Class Initialized
INFO - 2020-03-23 03:02:17 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:17 --> Total execution time: 0.4195
INFO - 2020-03-23 03:02:18 --> Config Class Initialized
INFO - 2020-03-23 03:02:18 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:18 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:18 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:18 --> URI Class Initialized
INFO - 2020-03-23 03:02:18 --> Router Class Initialized
INFO - 2020-03-23 03:02:18 --> Output Class Initialized
INFO - 2020-03-23 03:02:18 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:18 --> Input Class Initialized
INFO - 2020-03-23 03:02:18 --> Language Class Initialized
INFO - 2020-03-23 03:02:18 --> Language Class Initialized
INFO - 2020-03-23 03:02:18 --> Config Class Initialized
INFO - 2020-03-23 03:02:18 --> Loader Class Initialized
INFO - 2020-03-23 03:02:18 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:18 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:18 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:18 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:18 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:18 --> Controller Class Initialized
INFO - 2020-03-23 03:02:18 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:18 --> Total execution time: 0.3943
INFO - 2020-03-23 03:02:20 --> Config Class Initialized
INFO - 2020-03-23 03:02:20 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:20 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:20 --> URI Class Initialized
INFO - 2020-03-23 03:02:20 --> Router Class Initialized
INFO - 2020-03-23 03:02:20 --> Output Class Initialized
INFO - 2020-03-23 03:02:20 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:20 --> Input Class Initialized
INFO - 2020-03-23 03:02:20 --> Language Class Initialized
INFO - 2020-03-23 03:02:20 --> Language Class Initialized
INFO - 2020-03-23 03:02:20 --> Config Class Initialized
INFO - 2020-03-23 03:02:20 --> Loader Class Initialized
INFO - 2020-03-23 03:02:20 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:20 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:20 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:20 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:20 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:20 --> Controller Class Initialized
INFO - 2020-03-23 03:02:20 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:20 --> Total execution time: 0.4343
INFO - 2020-03-23 03:02:48 --> Config Class Initialized
INFO - 2020-03-23 03:02:48 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:48 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:48 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:48 --> URI Class Initialized
INFO - 2020-03-23 03:02:48 --> Router Class Initialized
INFO - 2020-03-23 03:02:48 --> Output Class Initialized
INFO - 2020-03-23 03:02:48 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:48 --> Input Class Initialized
INFO - 2020-03-23 03:02:48 --> Language Class Initialized
INFO - 2020-03-23 03:02:48 --> Language Class Initialized
INFO - 2020-03-23 03:02:48 --> Config Class Initialized
INFO - 2020-03-23 03:02:48 --> Loader Class Initialized
INFO - 2020-03-23 03:02:48 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:48 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:48 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:48 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:48 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:48 --> Controller Class Initialized
INFO - 2020-03-23 03:02:48 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:48 --> Total execution time: 0.4005
INFO - 2020-03-23 03:02:51 --> Config Class Initialized
INFO - 2020-03-23 03:02:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:51 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:51 --> URI Class Initialized
INFO - 2020-03-23 03:02:51 --> Router Class Initialized
INFO - 2020-03-23 03:02:51 --> Output Class Initialized
INFO - 2020-03-23 03:02:51 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:51 --> Input Class Initialized
INFO - 2020-03-23 03:02:51 --> Language Class Initialized
INFO - 2020-03-23 03:02:51 --> Language Class Initialized
INFO - 2020-03-23 03:02:51 --> Config Class Initialized
INFO - 2020-03-23 03:02:51 --> Loader Class Initialized
INFO - 2020-03-23 03:02:51 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:51 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:51 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:51 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:52 --> Controller Class Initialized
INFO - 2020-03-23 03:02:52 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:52 --> Total execution time: 0.4023
INFO - 2020-03-23 03:02:53 --> Config Class Initialized
INFO - 2020-03-23 03:02:53 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:53 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:53 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:53 --> URI Class Initialized
INFO - 2020-03-23 03:02:53 --> Router Class Initialized
INFO - 2020-03-23 03:02:53 --> Output Class Initialized
INFO - 2020-03-23 03:02:53 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:53 --> Input Class Initialized
INFO - 2020-03-23 03:02:54 --> Language Class Initialized
INFO - 2020-03-23 03:02:54 --> Language Class Initialized
INFO - 2020-03-23 03:02:54 --> Config Class Initialized
INFO - 2020-03-23 03:02:54 --> Loader Class Initialized
INFO - 2020-03-23 03:02:54 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:54 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:54 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:54 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:54 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:54 --> Controller Class Initialized
INFO - 2020-03-23 03:02:54 --> Final output sent to browser
DEBUG - 2020-03-23 03:02:54 --> Total execution time: 0.4601
INFO - 2020-03-23 03:02:55 --> Config Class Initialized
INFO - 2020-03-23 03:02:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:02:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:02:55 --> Utf8 Class Initialized
INFO - 2020-03-23 03:02:55 --> URI Class Initialized
INFO - 2020-03-23 03:02:55 --> Router Class Initialized
INFO - 2020-03-23 03:02:55 --> Output Class Initialized
INFO - 2020-03-23 03:02:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:02:55 --> Input Class Initialized
INFO - 2020-03-23 03:02:55 --> Language Class Initialized
INFO - 2020-03-23 03:02:55 --> Language Class Initialized
INFO - 2020-03-23 03:02:55 --> Config Class Initialized
INFO - 2020-03-23 03:02:55 --> Loader Class Initialized
INFO - 2020-03-23 03:02:55 --> Helper loaded: url_helper
INFO - 2020-03-23 03:02:55 --> Helper loaded: file_helper
INFO - 2020-03-23 03:02:56 --> Helper loaded: form_helper
INFO - 2020-03-23 03:02:56 --> Helper loaded: my_helper
INFO - 2020-03-23 03:02:56 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:02:56 --> Controller Class Initialized
INFO - 2020-03-23 03:03:54 --> Config Class Initialized
INFO - 2020-03-23 03:03:54 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:03:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:03:54 --> Utf8 Class Initialized
INFO - 2020-03-23 03:03:54 --> URI Class Initialized
INFO - 2020-03-23 03:03:54 --> Router Class Initialized
INFO - 2020-03-23 03:03:54 --> Output Class Initialized
INFO - 2020-03-23 03:03:54 --> Security Class Initialized
DEBUG - 2020-03-23 03:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:03:54 --> Input Class Initialized
INFO - 2020-03-23 03:03:54 --> Language Class Initialized
INFO - 2020-03-23 03:03:54 --> Language Class Initialized
INFO - 2020-03-23 03:03:54 --> Config Class Initialized
INFO - 2020-03-23 03:03:54 --> Loader Class Initialized
INFO - 2020-03-23 03:03:54 --> Helper loaded: url_helper
INFO - 2020-03-23 03:03:54 --> Helper loaded: file_helper
INFO - 2020-03-23 03:03:54 --> Helper loaded: form_helper
INFO - 2020-03-23 03:03:54 --> Helper loaded: my_helper
INFO - 2020-03-23 03:03:54 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:03:54 --> Controller Class Initialized
INFO - 2020-03-23 03:03:54 --> Final output sent to browser
DEBUG - 2020-03-23 03:03:54 --> Total execution time: 0.4528
INFO - 2020-03-23 03:09:05 --> Config Class Initialized
INFO - 2020-03-23 03:09:05 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:05 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:05 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:05 --> URI Class Initialized
INFO - 2020-03-23 03:09:05 --> Router Class Initialized
INFO - 2020-03-23 03:09:05 --> Output Class Initialized
INFO - 2020-03-23 03:09:06 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:06 --> Input Class Initialized
INFO - 2020-03-23 03:09:06 --> Language Class Initialized
INFO - 2020-03-23 03:09:06 --> Language Class Initialized
INFO - 2020-03-23 03:09:06 --> Config Class Initialized
INFO - 2020-03-23 03:09:06 --> Loader Class Initialized
INFO - 2020-03-23 03:09:06 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:06 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:06 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:06 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:06 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:06 --> Controller Class Initialized
DEBUG - 2020-03-23 03:09:06 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-03-23 03:09:06 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:09:06 --> Final output sent to browser
DEBUG - 2020-03-23 03:09:07 --> Total execution time: 0.9126
INFO - 2020-03-23 03:09:10 --> Config Class Initialized
INFO - 2020-03-23 03:09:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:10 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:10 --> URI Class Initialized
INFO - 2020-03-23 03:09:10 --> Router Class Initialized
INFO - 2020-03-23 03:09:10 --> Output Class Initialized
INFO - 2020-03-23 03:09:10 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:10 --> Input Class Initialized
INFO - 2020-03-23 03:09:10 --> Language Class Initialized
INFO - 2020-03-23 03:09:10 --> Language Class Initialized
INFO - 2020-03-23 03:09:10 --> Config Class Initialized
INFO - 2020-03-23 03:09:11 --> Loader Class Initialized
INFO - 2020-03-23 03:09:11 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:11 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:11 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:11 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:11 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:11 --> Controller Class Initialized
DEBUG - 2020-03-23 03:09:11 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-23 03:09:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:09:11 --> Final output sent to browser
DEBUG - 2020-03-23 03:09:12 --> Total execution time: 1.1057
INFO - 2020-03-23 03:09:12 --> Config Class Initialized
INFO - 2020-03-23 03:09:12 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:13 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:13 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:13 --> URI Class Initialized
INFO - 2020-03-23 03:09:13 --> Router Class Initialized
INFO - 2020-03-23 03:09:13 --> Output Class Initialized
INFO - 2020-03-23 03:09:13 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:13 --> Input Class Initialized
INFO - 2020-03-23 03:09:13 --> Language Class Initialized
INFO - 2020-03-23 03:09:13 --> Language Class Initialized
INFO - 2020-03-23 03:09:13 --> Config Class Initialized
INFO - 2020-03-23 03:09:13 --> Loader Class Initialized
INFO - 2020-03-23 03:09:13 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:13 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:13 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:13 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:13 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:13 --> Controller Class Initialized
INFO - 2020-03-23 03:09:19 --> Config Class Initialized
INFO - 2020-03-23 03:09:19 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:20 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:20 --> URI Class Initialized
INFO - 2020-03-23 03:09:20 --> Router Class Initialized
INFO - 2020-03-23 03:09:20 --> Output Class Initialized
INFO - 2020-03-23 03:09:20 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:20 --> Input Class Initialized
INFO - 2020-03-23 03:09:20 --> Language Class Initialized
INFO - 2020-03-23 03:09:20 --> Language Class Initialized
INFO - 2020-03-23 03:09:20 --> Config Class Initialized
INFO - 2020-03-23 03:09:20 --> Loader Class Initialized
INFO - 2020-03-23 03:09:20 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:20 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:20 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:20 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:20 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:21 --> Controller Class Initialized
DEBUG - 2020-03-23 03:09:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-03-23 03:09:21 --> Final output sent to browser
DEBUG - 2020-03-23 03:09:22 --> Total execution time: 1.9832
INFO - 2020-03-23 03:09:26 --> Config Class Initialized
INFO - 2020-03-23 03:09:26 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:26 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:26 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:26 --> URI Class Initialized
INFO - 2020-03-23 03:09:26 --> Router Class Initialized
INFO - 2020-03-23 03:09:26 --> Output Class Initialized
INFO - 2020-03-23 03:09:26 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:26 --> Input Class Initialized
INFO - 2020-03-23 03:09:26 --> Language Class Initialized
INFO - 2020-03-23 03:09:26 --> Language Class Initialized
INFO - 2020-03-23 03:09:26 --> Config Class Initialized
INFO - 2020-03-23 03:09:26 --> Loader Class Initialized
INFO - 2020-03-23 03:09:26 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:27 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:27 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:27 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:27 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:27 --> Controller Class Initialized
INFO - 2020-03-23 03:09:27 --> Final output sent to browser
DEBUG - 2020-03-23 03:09:27 --> Total execution time: 0.4392
INFO - 2020-03-23 03:09:28 --> Config Class Initialized
INFO - 2020-03-23 03:09:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:29 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:29 --> URI Class Initialized
INFO - 2020-03-23 03:09:29 --> Router Class Initialized
INFO - 2020-03-23 03:09:29 --> Output Class Initialized
INFO - 2020-03-23 03:09:29 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:29 --> Input Class Initialized
INFO - 2020-03-23 03:09:29 --> Language Class Initialized
INFO - 2020-03-23 03:09:29 --> Language Class Initialized
INFO - 2020-03-23 03:09:29 --> Config Class Initialized
INFO - 2020-03-23 03:09:29 --> Loader Class Initialized
INFO - 2020-03-23 03:09:29 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:29 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:29 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:29 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:30 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:30 --> Controller Class Initialized
DEBUG - 2020-03-23 03:09:30 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-03-23 03:09:30 --> Final output sent to browser
DEBUG - 2020-03-23 03:09:31 --> Total execution time: 2.4683
INFO - 2020-03-23 03:09:33 --> Config Class Initialized
INFO - 2020-03-23 03:09:34 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:34 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:34 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:34 --> URI Class Initialized
INFO - 2020-03-23 03:09:34 --> Router Class Initialized
INFO - 2020-03-23 03:09:34 --> Output Class Initialized
INFO - 2020-03-23 03:09:34 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:34 --> Input Class Initialized
INFO - 2020-03-23 03:09:34 --> Language Class Initialized
INFO - 2020-03-23 03:09:34 --> Language Class Initialized
INFO - 2020-03-23 03:09:34 --> Config Class Initialized
INFO - 2020-03-23 03:09:34 --> Loader Class Initialized
INFO - 2020-03-23 03:09:34 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:35 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:35 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:35 --> Controller Class Initialized
INFO - 2020-03-23 03:09:45 --> Config Class Initialized
INFO - 2020-03-23 03:09:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:09:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:09:45 --> Utf8 Class Initialized
INFO - 2020-03-23 03:09:45 --> URI Class Initialized
INFO - 2020-03-23 03:09:45 --> Router Class Initialized
INFO - 2020-03-23 03:09:45 --> Output Class Initialized
INFO - 2020-03-23 03:09:45 --> Security Class Initialized
DEBUG - 2020-03-23 03:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:09:45 --> Input Class Initialized
INFO - 2020-03-23 03:09:45 --> Language Class Initialized
INFO - 2020-03-23 03:09:45 --> Language Class Initialized
INFO - 2020-03-23 03:09:45 --> Config Class Initialized
INFO - 2020-03-23 03:09:45 --> Loader Class Initialized
INFO - 2020-03-23 03:09:45 --> Helper loaded: url_helper
INFO - 2020-03-23 03:09:45 --> Helper loaded: file_helper
INFO - 2020-03-23 03:09:45 --> Helper loaded: form_helper
INFO - 2020-03-23 03:09:45 --> Helper loaded: my_helper
INFO - 2020-03-23 03:09:45 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:09:45 --> Controller Class Initialized
DEBUG - 2020-03-23 03:09:45 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-03-23 03:09:45 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:09:45 --> Final output sent to browser
DEBUG - 2020-03-23 03:09:45 --> Total execution time: 0.5261
INFO - 2020-03-23 03:10:43 --> Config Class Initialized
INFO - 2020-03-23 03:10:43 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:10:43 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:10:43 --> Utf8 Class Initialized
INFO - 2020-03-23 03:10:43 --> URI Class Initialized
INFO - 2020-03-23 03:10:43 --> Router Class Initialized
INFO - 2020-03-23 03:10:43 --> Output Class Initialized
INFO - 2020-03-23 03:10:43 --> Security Class Initialized
DEBUG - 2020-03-23 03:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:10:43 --> Input Class Initialized
INFO - 2020-03-23 03:10:43 --> Language Class Initialized
INFO - 2020-03-23 03:10:43 --> Language Class Initialized
INFO - 2020-03-23 03:10:43 --> Config Class Initialized
INFO - 2020-03-23 03:10:43 --> Loader Class Initialized
INFO - 2020-03-23 03:10:43 --> Helper loaded: url_helper
INFO - 2020-03-23 03:10:43 --> Helper loaded: file_helper
INFO - 2020-03-23 03:10:43 --> Helper loaded: form_helper
INFO - 2020-03-23 03:10:43 --> Helper loaded: my_helper
INFO - 2020-03-23 03:10:43 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:10:44 --> Controller Class Initialized
INFO - 2020-03-23 03:10:44 --> Config Class Initialized
INFO - 2020-03-23 03:10:44 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:10:44 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:10:45 --> Utf8 Class Initialized
INFO - 2020-03-23 03:10:45 --> URI Class Initialized
INFO - 2020-03-23 03:10:45 --> Router Class Initialized
INFO - 2020-03-23 03:10:45 --> Output Class Initialized
INFO - 2020-03-23 03:10:45 --> Security Class Initialized
DEBUG - 2020-03-23 03:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:10:45 --> Input Class Initialized
INFO - 2020-03-23 03:10:45 --> Language Class Initialized
INFO - 2020-03-23 03:10:45 --> Language Class Initialized
INFO - 2020-03-23 03:10:45 --> Config Class Initialized
INFO - 2020-03-23 03:10:45 --> Loader Class Initialized
INFO - 2020-03-23 03:10:45 --> Helper loaded: url_helper
INFO - 2020-03-23 03:10:45 --> Helper loaded: file_helper
INFO - 2020-03-23 03:10:45 --> Helper loaded: form_helper
INFO - 2020-03-23 03:10:45 --> Helper loaded: my_helper
INFO - 2020-03-23 03:10:45 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:10:45 --> Controller Class Initialized
DEBUG - 2020-03-23 03:10:45 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-23 03:10:45 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:10:45 --> Final output sent to browser
DEBUG - 2020-03-23 03:10:45 --> Total execution time: 0.4659
INFO - 2020-03-23 03:10:45 --> Config Class Initialized
INFO - 2020-03-23 03:10:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:10:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:10:45 --> Utf8 Class Initialized
INFO - 2020-03-23 03:10:45 --> URI Class Initialized
INFO - 2020-03-23 03:10:45 --> Router Class Initialized
INFO - 2020-03-23 03:10:45 --> Output Class Initialized
INFO - 2020-03-23 03:10:45 --> Security Class Initialized
DEBUG - 2020-03-23 03:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:10:46 --> Input Class Initialized
INFO - 2020-03-23 03:10:46 --> Language Class Initialized
INFO - 2020-03-23 03:10:46 --> Language Class Initialized
INFO - 2020-03-23 03:10:46 --> Config Class Initialized
INFO - 2020-03-23 03:10:46 --> Loader Class Initialized
INFO - 2020-03-23 03:10:46 --> Helper loaded: url_helper
INFO - 2020-03-23 03:10:46 --> Helper loaded: file_helper
INFO - 2020-03-23 03:10:46 --> Helper loaded: form_helper
INFO - 2020-03-23 03:10:46 --> Helper loaded: my_helper
INFO - 2020-03-23 03:10:46 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:10:46 --> Controller Class Initialized
INFO - 2020-03-23 03:11:01 --> Config Class Initialized
INFO - 2020-03-23 03:11:01 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:01 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:01 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:01 --> URI Class Initialized
INFO - 2020-03-23 03:11:01 --> Router Class Initialized
INFO - 2020-03-23 03:11:01 --> Output Class Initialized
INFO - 2020-03-23 03:11:01 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:01 --> Input Class Initialized
INFO - 2020-03-23 03:11:01 --> Language Class Initialized
INFO - 2020-03-23 03:11:01 --> Language Class Initialized
INFO - 2020-03-23 03:11:01 --> Config Class Initialized
INFO - 2020-03-23 03:11:01 --> Loader Class Initialized
INFO - 2020-03-23 03:11:01 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:01 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:01 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:01 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:01 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:01 --> Controller Class Initialized
INFO - 2020-03-23 03:11:01 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:01 --> Total execution time: 0.4084
INFO - 2020-03-23 03:11:13 --> Config Class Initialized
INFO - 2020-03-23 03:11:14 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:14 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:14 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:14 --> URI Class Initialized
INFO - 2020-03-23 03:11:14 --> Router Class Initialized
INFO - 2020-03-23 03:11:14 --> Output Class Initialized
INFO - 2020-03-23 03:11:14 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:14 --> Input Class Initialized
INFO - 2020-03-23 03:11:14 --> Language Class Initialized
INFO - 2020-03-23 03:11:14 --> Language Class Initialized
INFO - 2020-03-23 03:11:14 --> Config Class Initialized
INFO - 2020-03-23 03:11:14 --> Loader Class Initialized
INFO - 2020-03-23 03:11:14 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:14 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:14 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:14 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:14 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:14 --> Controller Class Initialized
INFO - 2020-03-23 03:11:14 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:14 --> Total execution time: 0.4219
INFO - 2020-03-23 03:11:29 --> Config Class Initialized
INFO - 2020-03-23 03:11:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:29 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:29 --> URI Class Initialized
INFO - 2020-03-23 03:11:29 --> Router Class Initialized
INFO - 2020-03-23 03:11:29 --> Output Class Initialized
INFO - 2020-03-23 03:11:29 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:29 --> Input Class Initialized
INFO - 2020-03-23 03:11:29 --> Language Class Initialized
INFO - 2020-03-23 03:11:29 --> Language Class Initialized
INFO - 2020-03-23 03:11:29 --> Config Class Initialized
INFO - 2020-03-23 03:11:29 --> Loader Class Initialized
INFO - 2020-03-23 03:11:29 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:29 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:29 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:29 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:29 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:29 --> Controller Class Initialized
DEBUG - 2020-03-23 03:11:29 --> File loaded: D:\xampp\htdocs\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-03-23 03:11:29 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:11:29 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:29 --> Total execution time: 0.7936
INFO - 2020-03-23 03:11:33 --> Config Class Initialized
INFO - 2020-03-23 03:11:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:33 --> URI Class Initialized
INFO - 2020-03-23 03:11:33 --> Router Class Initialized
INFO - 2020-03-23 03:11:33 --> Output Class Initialized
INFO - 2020-03-23 03:11:33 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:33 --> Input Class Initialized
INFO - 2020-03-23 03:11:33 --> Language Class Initialized
INFO - 2020-03-23 03:11:33 --> Language Class Initialized
INFO - 2020-03-23 03:11:33 --> Config Class Initialized
INFO - 2020-03-23 03:11:33 --> Loader Class Initialized
INFO - 2020-03-23 03:11:33 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:33 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:33 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:33 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:33 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:33 --> Controller Class Initialized
INFO - 2020-03-23 03:11:33 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:11:33 --> Config Class Initialized
INFO - 2020-03-23 03:11:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:33 --> URI Class Initialized
INFO - 2020-03-23 03:11:33 --> Router Class Initialized
INFO - 2020-03-23 03:11:33 --> Output Class Initialized
INFO - 2020-03-23 03:11:33 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:33 --> Input Class Initialized
INFO - 2020-03-23 03:11:34 --> Language Class Initialized
INFO - 2020-03-23 03:11:34 --> Language Class Initialized
INFO - 2020-03-23 03:11:34 --> Config Class Initialized
INFO - 2020-03-23 03:11:34 --> Loader Class Initialized
INFO - 2020-03-23 03:11:34 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:34 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:34 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:34 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:34 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:34 --> Controller Class Initialized
INFO - 2020-03-23 03:11:34 --> Config Class Initialized
INFO - 2020-03-23 03:11:34 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:34 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:34 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:34 --> URI Class Initialized
INFO - 2020-03-23 03:11:34 --> Router Class Initialized
INFO - 2020-03-23 03:11:34 --> Output Class Initialized
INFO - 2020-03-23 03:11:34 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:34 --> Input Class Initialized
INFO - 2020-03-23 03:11:34 --> Language Class Initialized
INFO - 2020-03-23 03:11:34 --> Language Class Initialized
INFO - 2020-03-23 03:11:34 --> Config Class Initialized
INFO - 2020-03-23 03:11:34 --> Loader Class Initialized
INFO - 2020-03-23 03:11:34 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:34 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:34 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:34 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:34 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:34 --> Controller Class Initialized
DEBUG - 2020-03-23 03:11:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:11:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:11:34 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:34 --> Total execution time: 0.4902
INFO - 2020-03-23 03:11:42 --> Config Class Initialized
INFO - 2020-03-23 03:11:42 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:42 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:42 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:42 --> URI Class Initialized
INFO - 2020-03-23 03:11:42 --> Router Class Initialized
INFO - 2020-03-23 03:11:42 --> Output Class Initialized
INFO - 2020-03-23 03:11:42 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:42 --> Input Class Initialized
INFO - 2020-03-23 03:11:42 --> Language Class Initialized
INFO - 2020-03-23 03:11:42 --> Language Class Initialized
INFO - 2020-03-23 03:11:42 --> Config Class Initialized
INFO - 2020-03-23 03:11:42 --> Loader Class Initialized
INFO - 2020-03-23 03:11:42 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:43 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:43 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:43 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:43 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:43 --> Controller Class Initialized
INFO - 2020-03-23 03:11:43 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:11:43 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:43 --> Total execution time: 0.5163
INFO - 2020-03-23 03:11:43 --> Config Class Initialized
INFO - 2020-03-23 03:11:43 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:43 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:43 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:43 --> URI Class Initialized
INFO - 2020-03-23 03:11:43 --> Router Class Initialized
INFO - 2020-03-23 03:11:43 --> Output Class Initialized
INFO - 2020-03-23 03:11:43 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:43 --> Input Class Initialized
INFO - 2020-03-23 03:11:43 --> Language Class Initialized
INFO - 2020-03-23 03:11:43 --> Language Class Initialized
INFO - 2020-03-23 03:11:43 --> Config Class Initialized
INFO - 2020-03-23 03:11:43 --> Loader Class Initialized
INFO - 2020-03-23 03:11:43 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:43 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:43 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:43 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:43 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:43 --> Controller Class Initialized
DEBUG - 2020-03-23 03:11:43 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 03:11:43 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:11:43 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:45 --> Total execution time: 0.6786
INFO - 2020-03-23 03:11:50 --> Config Class Initialized
INFO - 2020-03-23 03:11:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:51 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:51 --> URI Class Initialized
INFO - 2020-03-23 03:11:51 --> Router Class Initialized
INFO - 2020-03-23 03:11:51 --> Output Class Initialized
INFO - 2020-03-23 03:11:51 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:51 --> Input Class Initialized
INFO - 2020-03-23 03:11:51 --> Language Class Initialized
INFO - 2020-03-23 03:11:51 --> Language Class Initialized
INFO - 2020-03-23 03:11:51 --> Config Class Initialized
INFO - 2020-03-23 03:11:51 --> Loader Class Initialized
INFO - 2020-03-23 03:11:51 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:51 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:51 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:51 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:51 --> Controller Class Initialized
DEBUG - 2020-03-23 03:11:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-23 03:11:51 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:11:51 --> Final output sent to browser
DEBUG - 2020-03-23 03:11:51 --> Total execution time: 0.5481
INFO - 2020-03-23 03:11:52 --> Config Class Initialized
INFO - 2020-03-23 03:11:52 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:11:52 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:11:52 --> Utf8 Class Initialized
INFO - 2020-03-23 03:11:52 --> URI Class Initialized
INFO - 2020-03-23 03:11:52 --> Router Class Initialized
INFO - 2020-03-23 03:11:52 --> Output Class Initialized
INFO - 2020-03-23 03:11:52 --> Security Class Initialized
DEBUG - 2020-03-23 03:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:11:52 --> Input Class Initialized
INFO - 2020-03-23 03:11:52 --> Language Class Initialized
INFO - 2020-03-23 03:11:52 --> Language Class Initialized
INFO - 2020-03-23 03:11:52 --> Config Class Initialized
INFO - 2020-03-23 03:11:52 --> Loader Class Initialized
INFO - 2020-03-23 03:11:52 --> Helper loaded: url_helper
INFO - 2020-03-23 03:11:52 --> Helper loaded: file_helper
INFO - 2020-03-23 03:11:52 --> Helper loaded: form_helper
INFO - 2020-03-23 03:11:52 --> Helper loaded: my_helper
INFO - 2020-03-23 03:11:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:11:52 --> Controller Class Initialized
INFO - 2020-03-23 03:12:06 --> Config Class Initialized
INFO - 2020-03-23 03:12:06 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:06 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:06 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:06 --> URI Class Initialized
INFO - 2020-03-23 03:12:06 --> Router Class Initialized
INFO - 2020-03-23 03:12:06 --> Output Class Initialized
INFO - 2020-03-23 03:12:06 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:06 --> Input Class Initialized
INFO - 2020-03-23 03:12:06 --> Language Class Initialized
INFO - 2020-03-23 03:12:06 --> Language Class Initialized
INFO - 2020-03-23 03:12:06 --> Config Class Initialized
INFO - 2020-03-23 03:12:06 --> Loader Class Initialized
INFO - 2020-03-23 03:12:06 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:06 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:06 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:06 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:07 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:07 --> Controller Class Initialized
DEBUG - 2020-03-23 03:12:07 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-23 03:12:07 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:12:07 --> Final output sent to browser
DEBUG - 2020-03-23 03:12:07 --> Total execution time: 0.5669
INFO - 2020-03-23 03:12:07 --> Config Class Initialized
INFO - 2020-03-23 03:12:07 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:07 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:07 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:07 --> URI Class Initialized
INFO - 2020-03-23 03:12:07 --> Router Class Initialized
INFO - 2020-03-23 03:12:07 --> Output Class Initialized
INFO - 2020-03-23 03:12:07 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:07 --> Input Class Initialized
INFO - 2020-03-23 03:12:07 --> Language Class Initialized
INFO - 2020-03-23 03:12:07 --> Language Class Initialized
INFO - 2020-03-23 03:12:07 --> Config Class Initialized
INFO - 2020-03-23 03:12:08 --> Loader Class Initialized
INFO - 2020-03-23 03:12:08 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:08 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:08 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:08 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:08 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:08 --> Controller Class Initialized
INFO - 2020-03-23 03:12:16 --> Config Class Initialized
INFO - 2020-03-23 03:12:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:16 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:16 --> URI Class Initialized
INFO - 2020-03-23 03:12:16 --> Router Class Initialized
INFO - 2020-03-23 03:12:16 --> Output Class Initialized
INFO - 2020-03-23 03:12:16 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:16 --> Input Class Initialized
INFO - 2020-03-23 03:12:16 --> Language Class Initialized
INFO - 2020-03-23 03:12:17 --> Language Class Initialized
INFO - 2020-03-23 03:12:17 --> Config Class Initialized
INFO - 2020-03-23 03:12:17 --> Loader Class Initialized
INFO - 2020-03-23 03:12:17 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:17 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:17 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:17 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:17 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:17 --> Controller Class Initialized
DEBUG - 2020-03-23 03:12:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-23 03:12:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:12:17 --> Final output sent to browser
DEBUG - 2020-03-23 03:12:17 --> Total execution time: 0.5743
INFO - 2020-03-23 03:12:17 --> Config Class Initialized
INFO - 2020-03-23 03:12:17 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:17 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:17 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:17 --> URI Class Initialized
INFO - 2020-03-23 03:12:17 --> Router Class Initialized
INFO - 2020-03-23 03:12:17 --> Output Class Initialized
INFO - 2020-03-23 03:12:17 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:17 --> Input Class Initialized
INFO - 2020-03-23 03:12:17 --> Language Class Initialized
INFO - 2020-03-23 03:12:17 --> Language Class Initialized
INFO - 2020-03-23 03:12:17 --> Config Class Initialized
INFO - 2020-03-23 03:12:18 --> Loader Class Initialized
INFO - 2020-03-23 03:12:18 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:18 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:18 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:18 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:18 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:18 --> Controller Class Initialized
INFO - 2020-03-23 03:12:25 --> Config Class Initialized
INFO - 2020-03-23 03:12:25 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:25 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:25 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:25 --> URI Class Initialized
INFO - 2020-03-23 03:12:25 --> Router Class Initialized
INFO - 2020-03-23 03:12:25 --> Output Class Initialized
INFO - 2020-03-23 03:12:25 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:25 --> Input Class Initialized
INFO - 2020-03-23 03:12:25 --> Language Class Initialized
INFO - 2020-03-23 03:12:25 --> Language Class Initialized
INFO - 2020-03-23 03:12:25 --> Config Class Initialized
INFO - 2020-03-23 03:12:25 --> Loader Class Initialized
INFO - 2020-03-23 03:12:25 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:25 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:25 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:25 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:25 --> Controller Class Initialized
INFO - 2020-03-23 03:12:25 --> Final output sent to browser
DEBUG - 2020-03-23 03:12:25 --> Total execution time: 0.4673
INFO - 2020-03-23 03:12:36 --> Config Class Initialized
INFO - 2020-03-23 03:12:36 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:36 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:36 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:36 --> URI Class Initialized
INFO - 2020-03-23 03:12:36 --> Router Class Initialized
INFO - 2020-03-23 03:12:36 --> Output Class Initialized
INFO - 2020-03-23 03:12:36 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:36 --> Input Class Initialized
INFO - 2020-03-23 03:12:36 --> Language Class Initialized
INFO - 2020-03-23 03:12:36 --> Language Class Initialized
INFO - 2020-03-23 03:12:36 --> Config Class Initialized
INFO - 2020-03-23 03:12:36 --> Loader Class Initialized
INFO - 2020-03-23 03:12:36 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:36 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:36 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:36 --> Controller Class Initialized
INFO - 2020-03-23 03:12:36 --> Final output sent to browser
DEBUG - 2020-03-23 03:12:36 --> Total execution time: 0.4997
INFO - 2020-03-23 03:12:51 --> Config Class Initialized
INFO - 2020-03-23 03:12:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:51 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:51 --> URI Class Initialized
INFO - 2020-03-23 03:12:51 --> Router Class Initialized
INFO - 2020-03-23 03:12:51 --> Output Class Initialized
INFO - 2020-03-23 03:12:51 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:51 --> Input Class Initialized
INFO - 2020-03-23 03:12:51 --> Language Class Initialized
INFO - 2020-03-23 03:12:51 --> Language Class Initialized
INFO - 2020-03-23 03:12:51 --> Config Class Initialized
INFO - 2020-03-23 03:12:51 --> Loader Class Initialized
INFO - 2020-03-23 03:12:51 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:51 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:51 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:51 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:51 --> Controller Class Initialized
DEBUG - 2020-03-23 03:12:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-23 03:12:51 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:12:52 --> Final output sent to browser
DEBUG - 2020-03-23 03:12:52 --> Total execution time: 0.6257
INFO - 2020-03-23 03:12:52 --> Config Class Initialized
INFO - 2020-03-23 03:12:52 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:52 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:52 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:52 --> URI Class Initialized
INFO - 2020-03-23 03:12:52 --> Router Class Initialized
INFO - 2020-03-23 03:12:52 --> Output Class Initialized
INFO - 2020-03-23 03:12:52 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:52 --> Input Class Initialized
INFO - 2020-03-23 03:12:52 --> Language Class Initialized
INFO - 2020-03-23 03:12:52 --> Language Class Initialized
INFO - 2020-03-23 03:12:52 --> Config Class Initialized
INFO - 2020-03-23 03:12:52 --> Loader Class Initialized
INFO - 2020-03-23 03:12:52 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:52 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:52 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:52 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:52 --> Controller Class Initialized
INFO - 2020-03-23 03:12:56 --> Config Class Initialized
INFO - 2020-03-23 03:12:56 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:56 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:56 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:56 --> URI Class Initialized
INFO - 2020-03-23 03:12:56 --> Router Class Initialized
INFO - 2020-03-23 03:12:56 --> Output Class Initialized
INFO - 2020-03-23 03:12:56 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:56 --> Input Class Initialized
INFO - 2020-03-23 03:12:56 --> Language Class Initialized
INFO - 2020-03-23 03:12:56 --> Language Class Initialized
INFO - 2020-03-23 03:12:56 --> Config Class Initialized
INFO - 2020-03-23 03:12:56 --> Loader Class Initialized
INFO - 2020-03-23 03:12:56 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:56 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:56 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:56 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:56 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:56 --> Controller Class Initialized
DEBUG - 2020-03-23 03:12:56 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-23 03:12:56 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:12:56 --> Final output sent to browser
DEBUG - 2020-03-23 03:12:56 --> Total execution time: 0.4937
INFO - 2020-03-23 03:12:57 --> Config Class Initialized
INFO - 2020-03-23 03:12:57 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:12:57 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:12:57 --> Utf8 Class Initialized
INFO - 2020-03-23 03:12:57 --> URI Class Initialized
INFO - 2020-03-23 03:12:57 --> Router Class Initialized
INFO - 2020-03-23 03:12:57 --> Output Class Initialized
INFO - 2020-03-23 03:12:57 --> Security Class Initialized
DEBUG - 2020-03-23 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:12:57 --> Input Class Initialized
INFO - 2020-03-23 03:12:57 --> Language Class Initialized
INFO - 2020-03-23 03:12:57 --> Language Class Initialized
INFO - 2020-03-23 03:12:57 --> Config Class Initialized
INFO - 2020-03-23 03:12:57 --> Loader Class Initialized
INFO - 2020-03-23 03:12:57 --> Helper loaded: url_helper
INFO - 2020-03-23 03:12:57 --> Helper loaded: file_helper
INFO - 2020-03-23 03:12:57 --> Helper loaded: form_helper
INFO - 2020-03-23 03:12:57 --> Helper loaded: my_helper
INFO - 2020-03-23 03:12:57 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:12:57 --> Controller Class Initialized
INFO - 2020-03-23 03:13:00 --> Config Class Initialized
INFO - 2020-03-23 03:13:00 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:00 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:00 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:00 --> URI Class Initialized
INFO - 2020-03-23 03:13:00 --> Router Class Initialized
INFO - 2020-03-23 03:13:00 --> Output Class Initialized
INFO - 2020-03-23 03:13:00 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:00 --> Input Class Initialized
INFO - 2020-03-23 03:13:00 --> Language Class Initialized
INFO - 2020-03-23 03:13:00 --> Language Class Initialized
INFO - 2020-03-23 03:13:00 --> Config Class Initialized
INFO - 2020-03-23 03:13:00 --> Loader Class Initialized
INFO - 2020-03-23 03:13:00 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:00 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:00 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:00 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:00 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:00 --> Controller Class Initialized
INFO - 2020-03-23 03:13:00 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:00 --> Total execution time: 0.4913
INFO - 2020-03-23 03:13:03 --> Config Class Initialized
INFO - 2020-03-23 03:13:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:03 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:03 --> URI Class Initialized
INFO - 2020-03-23 03:13:03 --> Router Class Initialized
INFO - 2020-03-23 03:13:03 --> Output Class Initialized
INFO - 2020-03-23 03:13:03 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:03 --> Input Class Initialized
INFO - 2020-03-23 03:13:03 --> Language Class Initialized
INFO - 2020-03-23 03:13:03 --> Language Class Initialized
INFO - 2020-03-23 03:13:03 --> Config Class Initialized
INFO - 2020-03-23 03:13:03 --> Loader Class Initialized
INFO - 2020-03-23 03:13:03 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:03 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:03 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:03 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:03 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:03 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:03 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-23 03:13:03 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:03 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:03 --> Total execution time: 0.5217
INFO - 2020-03-23 03:13:04 --> Config Class Initialized
INFO - 2020-03-23 03:13:04 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:04 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:04 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:04 --> URI Class Initialized
INFO - 2020-03-23 03:13:04 --> Router Class Initialized
INFO - 2020-03-23 03:13:04 --> Output Class Initialized
INFO - 2020-03-23 03:13:04 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:04 --> Input Class Initialized
INFO - 2020-03-23 03:13:04 --> Language Class Initialized
INFO - 2020-03-23 03:13:04 --> Language Class Initialized
INFO - 2020-03-23 03:13:04 --> Config Class Initialized
INFO - 2020-03-23 03:13:04 --> Loader Class Initialized
INFO - 2020-03-23 03:13:04 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:04 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:04 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:04 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:04 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:04 --> Controller Class Initialized
INFO - 2020-03-23 03:13:08 --> Config Class Initialized
INFO - 2020-03-23 03:13:08 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:08 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:08 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:08 --> URI Class Initialized
INFO - 2020-03-23 03:13:08 --> Router Class Initialized
INFO - 2020-03-23 03:13:08 --> Output Class Initialized
INFO - 2020-03-23 03:13:08 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:08 --> Input Class Initialized
INFO - 2020-03-23 03:13:08 --> Language Class Initialized
INFO - 2020-03-23 03:13:08 --> Language Class Initialized
INFO - 2020-03-23 03:13:08 --> Config Class Initialized
INFO - 2020-03-23 03:13:08 --> Loader Class Initialized
INFO - 2020-03-23 03:13:08 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:08 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:08 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:08 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:08 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:08 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:08 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-23 03:13:09 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:09 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:09 --> Total execution time: 0.7721
INFO - 2020-03-23 03:13:09 --> Config Class Initialized
INFO - 2020-03-23 03:13:09 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:09 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:09 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:09 --> URI Class Initialized
INFO - 2020-03-23 03:13:09 --> Router Class Initialized
INFO - 2020-03-23 03:13:09 --> Output Class Initialized
INFO - 2020-03-23 03:13:09 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:09 --> Input Class Initialized
INFO - 2020-03-23 03:13:09 --> Language Class Initialized
INFO - 2020-03-23 03:13:09 --> Language Class Initialized
INFO - 2020-03-23 03:13:09 --> Config Class Initialized
INFO - 2020-03-23 03:13:09 --> Loader Class Initialized
INFO - 2020-03-23 03:13:09 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:09 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:09 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:09 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:09 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:10 --> Config Class Initialized
INFO - 2020-03-23 03:13:10 --> Hooks Class Initialized
INFO - 2020-03-23 03:13:10 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:10 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:10 --> URI Class Initialized
INFO - 2020-03-23 03:13:10 --> Router Class Initialized
INFO - 2020-03-23 03:13:10 --> Output Class Initialized
INFO - 2020-03-23 03:13:10 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:10 --> Input Class Initialized
INFO - 2020-03-23 03:13:10 --> Language Class Initialized
INFO - 2020-03-23 03:13:10 --> Language Class Initialized
INFO - 2020-03-23 03:13:10 --> Config Class Initialized
INFO - 2020-03-23 03:13:10 --> Loader Class Initialized
INFO - 2020-03-23 03:13:10 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:10 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:10 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:10 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:10 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:10 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:10 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-03-23 03:13:10 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:10 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:10 --> Total execution time: 0.7122
INFO - 2020-03-23 03:13:11 --> Config Class Initialized
INFO - 2020-03-23 03:13:11 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:11 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:11 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:11 --> URI Class Initialized
INFO - 2020-03-23 03:13:11 --> Router Class Initialized
INFO - 2020-03-23 03:13:11 --> Output Class Initialized
INFO - 2020-03-23 03:13:11 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:11 --> Input Class Initialized
INFO - 2020-03-23 03:13:11 --> Language Class Initialized
INFO - 2020-03-23 03:13:11 --> Language Class Initialized
INFO - 2020-03-23 03:13:11 --> Config Class Initialized
INFO - 2020-03-23 03:13:11 --> Loader Class Initialized
INFO - 2020-03-23 03:13:11 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:11 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:11 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:11 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:11 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:11 --> Controller Class Initialized
INFO - 2020-03-23 03:13:19 --> Config Class Initialized
INFO - 2020-03-23 03:13:19 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:19 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:19 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:19 --> URI Class Initialized
DEBUG - 2020-03-23 03:13:19 --> No URI present. Default controller set.
INFO - 2020-03-23 03:13:19 --> Router Class Initialized
INFO - 2020-03-23 03:13:19 --> Output Class Initialized
INFO - 2020-03-23 03:13:19 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:19 --> Input Class Initialized
INFO - 2020-03-23 03:13:19 --> Language Class Initialized
INFO - 2020-03-23 03:13:19 --> Language Class Initialized
INFO - 2020-03-23 03:13:19 --> Config Class Initialized
INFO - 2020-03-23 03:13:19 --> Loader Class Initialized
INFO - 2020-03-23 03:13:19 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:19 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:19 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:19 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:19 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:19 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:19 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 03:13:19 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:19 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:20 --> Total execution time: 0.5245
INFO - 2020-03-23 03:13:24 --> Config Class Initialized
INFO - 2020-03-23 03:13:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:24 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:24 --> URI Class Initialized
INFO - 2020-03-23 03:13:24 --> Router Class Initialized
INFO - 2020-03-23 03:13:24 --> Output Class Initialized
INFO - 2020-03-23 03:13:24 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:24 --> Input Class Initialized
INFO - 2020-03-23 03:13:24 --> Language Class Initialized
INFO - 2020-03-23 03:13:24 --> Language Class Initialized
INFO - 2020-03-23 03:13:24 --> Config Class Initialized
INFO - 2020-03-23 03:13:24 --> Loader Class Initialized
INFO - 2020-03-23 03:13:24 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:24 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:24 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:24 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:24 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:24 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:24 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-23 03:13:24 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:24 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:24 --> Total execution time: 0.6352
INFO - 2020-03-23 03:13:25 --> Config Class Initialized
INFO - 2020-03-23 03:13:25 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:25 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:25 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:25 --> URI Class Initialized
INFO - 2020-03-23 03:13:25 --> Router Class Initialized
INFO - 2020-03-23 03:13:25 --> Output Class Initialized
INFO - 2020-03-23 03:13:25 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:25 --> Input Class Initialized
INFO - 2020-03-23 03:13:25 --> Language Class Initialized
INFO - 2020-03-23 03:13:25 --> Language Class Initialized
INFO - 2020-03-23 03:13:25 --> Config Class Initialized
INFO - 2020-03-23 03:13:25 --> Loader Class Initialized
INFO - 2020-03-23 03:13:25 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:25 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:25 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:25 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:25 --> Controller Class Initialized
INFO - 2020-03-23 03:13:27 --> Config Class Initialized
INFO - 2020-03-23 03:13:27 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:27 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:27 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:27 --> URI Class Initialized
INFO - 2020-03-23 03:13:27 --> Router Class Initialized
INFO - 2020-03-23 03:13:27 --> Output Class Initialized
INFO - 2020-03-23 03:13:27 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:27 --> Input Class Initialized
INFO - 2020-03-23 03:13:27 --> Language Class Initialized
INFO - 2020-03-23 03:13:27 --> Language Class Initialized
INFO - 2020-03-23 03:13:27 --> Config Class Initialized
INFO - 2020-03-23 03:13:27 --> Loader Class Initialized
INFO - 2020-03-23 03:13:27 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:27 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:27 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:27 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:27 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:27 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:27 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 03:13:27 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:27 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:27 --> Total execution time: 0.4923
INFO - 2020-03-23 03:13:28 --> Config Class Initialized
INFO - 2020-03-23 03:13:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:28 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:28 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:28 --> URI Class Initialized
INFO - 2020-03-23 03:13:28 --> Router Class Initialized
INFO - 2020-03-23 03:13:28 --> Output Class Initialized
INFO - 2020-03-23 03:13:28 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:28 --> Input Class Initialized
INFO - 2020-03-23 03:13:28 --> Language Class Initialized
INFO - 2020-03-23 03:13:28 --> Language Class Initialized
INFO - 2020-03-23 03:13:28 --> Config Class Initialized
INFO - 2020-03-23 03:13:28 --> Loader Class Initialized
INFO - 2020-03-23 03:13:28 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:28 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:28 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:28 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:28 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:28 --> Controller Class Initialized
INFO - 2020-03-23 03:13:30 --> Config Class Initialized
INFO - 2020-03-23 03:13:30 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:30 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:30 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:30 --> URI Class Initialized
INFO - 2020-03-23 03:13:30 --> Router Class Initialized
INFO - 2020-03-23 03:13:31 --> Output Class Initialized
INFO - 2020-03-23 03:13:31 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:31 --> Input Class Initialized
INFO - 2020-03-23 03:13:31 --> Language Class Initialized
INFO - 2020-03-23 03:13:31 --> Language Class Initialized
INFO - 2020-03-23 03:13:31 --> Config Class Initialized
INFO - 2020-03-23 03:13:31 --> Loader Class Initialized
INFO - 2020-03-23 03:13:31 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:31 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:31 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:31 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:31 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:31 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:31 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-23 03:13:31 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:31 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:31 --> Total execution time: 0.4895
INFO - 2020-03-23 03:13:31 --> Config Class Initialized
INFO - 2020-03-23 03:13:31 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:31 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:31 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:31 --> URI Class Initialized
INFO - 2020-03-23 03:13:31 --> Router Class Initialized
INFO - 2020-03-23 03:13:31 --> Output Class Initialized
INFO - 2020-03-23 03:13:31 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:31 --> Input Class Initialized
INFO - 2020-03-23 03:13:31 --> Language Class Initialized
INFO - 2020-03-23 03:13:31 --> Language Class Initialized
INFO - 2020-03-23 03:13:31 --> Config Class Initialized
INFO - 2020-03-23 03:13:31 --> Loader Class Initialized
INFO - 2020-03-23 03:13:32 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:32 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:32 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:32 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:32 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:32 --> Controller Class Initialized
INFO - 2020-03-23 03:13:33 --> Config Class Initialized
INFO - 2020-03-23 03:13:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:33 --> URI Class Initialized
INFO - 2020-03-23 03:13:33 --> Router Class Initialized
INFO - 2020-03-23 03:13:34 --> Output Class Initialized
INFO - 2020-03-23 03:13:34 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:34 --> Input Class Initialized
INFO - 2020-03-23 03:13:34 --> Language Class Initialized
INFO - 2020-03-23 03:13:34 --> Language Class Initialized
INFO - 2020-03-23 03:13:34 --> Config Class Initialized
INFO - 2020-03-23 03:13:34 --> Loader Class Initialized
INFO - 2020-03-23 03:13:34 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:34 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:34 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:34 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:34 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:34 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-23 03:13:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:34 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:34 --> Total execution time: 0.6804
INFO - 2020-03-23 03:13:34 --> Config Class Initialized
INFO - 2020-03-23 03:13:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:35 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:35 --> URI Class Initialized
INFO - 2020-03-23 03:13:35 --> Router Class Initialized
INFO - 2020-03-23 03:13:35 --> Output Class Initialized
INFO - 2020-03-23 03:13:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:35 --> Input Class Initialized
INFO - 2020-03-23 03:13:35 --> Language Class Initialized
INFO - 2020-03-23 03:13:35 --> Language Class Initialized
INFO - 2020-03-23 03:13:35 --> Config Class Initialized
INFO - 2020-03-23 03:13:35 --> Loader Class Initialized
INFO - 2020-03-23 03:13:35 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:35 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:35 --> Database Driver Class Initialized
INFO - 2020-03-23 03:13:35 --> Config Class Initialized
INFO - 2020-03-23 03:13:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-03-23 03:13:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:35 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:35 --> Controller Class Initialized
INFO - 2020-03-23 03:13:35 --> URI Class Initialized
INFO - 2020-03-23 03:13:35 --> Router Class Initialized
INFO - 2020-03-23 03:13:35 --> Output Class Initialized
INFO - 2020-03-23 03:13:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:35 --> Input Class Initialized
INFO - 2020-03-23 03:13:35 --> Language Class Initialized
INFO - 2020-03-23 03:13:35 --> Language Class Initialized
INFO - 2020-03-23 03:13:35 --> Config Class Initialized
INFO - 2020-03-23 03:13:35 --> Loader Class Initialized
INFO - 2020-03-23 03:13:35 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:36 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:36 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-23 03:13:36 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:36 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:36 --> Total execution time: 0.5232
INFO - 2020-03-23 03:13:36 --> Config Class Initialized
INFO - 2020-03-23 03:13:36 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:36 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:36 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:36 --> URI Class Initialized
INFO - 2020-03-23 03:13:36 --> Router Class Initialized
INFO - 2020-03-23 03:13:36 --> Output Class Initialized
INFO - 2020-03-23 03:13:36 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:36 --> Input Class Initialized
INFO - 2020-03-23 03:13:36 --> Language Class Initialized
INFO - 2020-03-23 03:13:37 --> Language Class Initialized
INFO - 2020-03-23 03:13:37 --> Config Class Initialized
INFO - 2020-03-23 03:13:37 --> Loader Class Initialized
INFO - 2020-03-23 03:13:37 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:37 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:37 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:37 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:37 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:37 --> Controller Class Initialized
INFO - 2020-03-23 03:13:37 --> Config Class Initialized
INFO - 2020-03-23 03:13:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:37 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:38 --> URI Class Initialized
INFO - 2020-03-23 03:13:38 --> Router Class Initialized
INFO - 2020-03-23 03:13:38 --> Output Class Initialized
INFO - 2020-03-23 03:13:38 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:38 --> Input Class Initialized
INFO - 2020-03-23 03:13:38 --> Language Class Initialized
INFO - 2020-03-23 03:13:38 --> Language Class Initialized
INFO - 2020-03-23 03:13:38 --> Config Class Initialized
INFO - 2020-03-23 03:13:38 --> Loader Class Initialized
INFO - 2020-03-23 03:13:38 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:38 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:38 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:38 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:38 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:38 --> Controller Class Initialized
INFO - 2020-03-23 03:13:38 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:38 --> Total execution time: 0.5012
INFO - 2020-03-23 03:13:42 --> Config Class Initialized
INFO - 2020-03-23 03:13:42 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:42 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:42 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:42 --> URI Class Initialized
INFO - 2020-03-23 03:13:42 --> Router Class Initialized
INFO - 2020-03-23 03:13:42 --> Output Class Initialized
INFO - 2020-03-23 03:13:42 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:42 --> Input Class Initialized
INFO - 2020-03-23 03:13:42 --> Language Class Initialized
INFO - 2020-03-23 03:13:42 --> Language Class Initialized
INFO - 2020-03-23 03:13:42 --> Config Class Initialized
INFO - 2020-03-23 03:13:42 --> Loader Class Initialized
INFO - 2020-03-23 03:13:42 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:42 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:42 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:42 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:42 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:42 --> Controller Class Initialized
DEBUG - 2020-03-23 03:13:42 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-23 03:13:42 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:13:42 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:43 --> Total execution time: 0.6098
INFO - 2020-03-23 03:13:43 --> Config Class Initialized
INFO - 2020-03-23 03:13:43 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:43 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:43 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:43 --> URI Class Initialized
INFO - 2020-03-23 03:13:43 --> Router Class Initialized
INFO - 2020-03-23 03:13:43 --> Output Class Initialized
INFO - 2020-03-23 03:13:43 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:43 --> Input Class Initialized
INFO - 2020-03-23 03:13:43 --> Language Class Initialized
INFO - 2020-03-23 03:13:43 --> Language Class Initialized
INFO - 2020-03-23 03:13:43 --> Config Class Initialized
INFO - 2020-03-23 03:13:43 --> Loader Class Initialized
INFO - 2020-03-23 03:13:43 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:43 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:43 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:43 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:43 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:43 --> Controller Class Initialized
INFO - 2020-03-23 03:13:46 --> Config Class Initialized
INFO - 2020-03-23 03:13:46 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:13:46 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:13:46 --> Utf8 Class Initialized
INFO - 2020-03-23 03:13:46 --> URI Class Initialized
INFO - 2020-03-23 03:13:46 --> Router Class Initialized
INFO - 2020-03-23 03:13:46 --> Output Class Initialized
INFO - 2020-03-23 03:13:46 --> Security Class Initialized
DEBUG - 2020-03-23 03:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:13:46 --> Input Class Initialized
INFO - 2020-03-23 03:13:46 --> Language Class Initialized
INFO - 2020-03-23 03:13:46 --> Language Class Initialized
INFO - 2020-03-23 03:13:46 --> Config Class Initialized
INFO - 2020-03-23 03:13:46 --> Loader Class Initialized
INFO - 2020-03-23 03:13:46 --> Helper loaded: url_helper
INFO - 2020-03-23 03:13:46 --> Helper loaded: file_helper
INFO - 2020-03-23 03:13:46 --> Helper loaded: form_helper
INFO - 2020-03-23 03:13:46 --> Helper loaded: my_helper
INFO - 2020-03-23 03:13:46 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:13:46 --> Controller Class Initialized
INFO - 2020-03-23 03:13:46 --> Final output sent to browser
DEBUG - 2020-03-23 03:13:46 --> Total execution time: 0.4713
INFO - 2020-03-23 03:17:34 --> Config Class Initialized
INFO - 2020-03-23 03:17:34 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:17:34 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:17:34 --> Utf8 Class Initialized
INFO - 2020-03-23 03:17:34 --> URI Class Initialized
INFO - 2020-03-23 03:17:34 --> Router Class Initialized
INFO - 2020-03-23 03:17:34 --> Output Class Initialized
INFO - 2020-03-23 03:17:34 --> Security Class Initialized
DEBUG - 2020-03-23 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:17:35 --> Input Class Initialized
INFO - 2020-03-23 03:17:35 --> Language Class Initialized
INFO - 2020-03-23 03:17:35 --> Language Class Initialized
INFO - 2020-03-23 03:17:35 --> Config Class Initialized
INFO - 2020-03-23 03:17:35 --> Loader Class Initialized
INFO - 2020-03-23 03:17:35 --> Helper loaded: url_helper
INFO - 2020-03-23 03:17:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:17:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:17:35 --> Helper loaded: my_helper
INFO - 2020-03-23 03:17:35 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:17:35 --> Controller Class Initialized
DEBUG - 2020-03-23 03:17:35 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-23 03:17:35 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:17:35 --> Final output sent to browser
DEBUG - 2020-03-23 03:17:35 --> Total execution time: 0.4887
INFO - 2020-03-23 03:17:35 --> Config Class Initialized
INFO - 2020-03-23 03:17:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:17:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:17:35 --> Utf8 Class Initialized
INFO - 2020-03-23 03:17:35 --> URI Class Initialized
INFO - 2020-03-23 03:17:35 --> Router Class Initialized
INFO - 2020-03-23 03:17:35 --> Output Class Initialized
INFO - 2020-03-23 03:17:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:17:36 --> Input Class Initialized
INFO - 2020-03-23 03:17:36 --> Language Class Initialized
INFO - 2020-03-23 03:17:36 --> Language Class Initialized
INFO - 2020-03-23 03:17:36 --> Config Class Initialized
INFO - 2020-03-23 03:17:36 --> Loader Class Initialized
INFO - 2020-03-23 03:17:36 --> Helper loaded: url_helper
INFO - 2020-03-23 03:17:36 --> Helper loaded: file_helper
INFO - 2020-03-23 03:17:36 --> Helper loaded: form_helper
INFO - 2020-03-23 03:17:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:17:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:17:36 --> Controller Class Initialized
INFO - 2020-03-23 03:17:37 --> Config Class Initialized
INFO - 2020-03-23 03:17:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:17:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:17:37 --> Utf8 Class Initialized
INFO - 2020-03-23 03:17:37 --> URI Class Initialized
INFO - 2020-03-23 03:17:37 --> Router Class Initialized
INFO - 2020-03-23 03:17:37 --> Output Class Initialized
INFO - 2020-03-23 03:17:37 --> Security Class Initialized
DEBUG - 2020-03-23 03:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:17:37 --> Input Class Initialized
INFO - 2020-03-23 03:17:37 --> Language Class Initialized
INFO - 2020-03-23 03:17:37 --> Language Class Initialized
INFO - 2020-03-23 03:17:37 --> Config Class Initialized
INFO - 2020-03-23 03:17:37 --> Loader Class Initialized
INFO - 2020-03-23 03:17:37 --> Helper loaded: url_helper
INFO - 2020-03-23 03:17:37 --> Helper loaded: file_helper
INFO - 2020-03-23 03:17:37 --> Helper loaded: form_helper
INFO - 2020-03-23 03:17:37 --> Helper loaded: my_helper
INFO - 2020-03-23 03:17:37 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:17:37 --> Controller Class Initialized
INFO - 2020-03-23 03:17:37 --> Final output sent to browser
DEBUG - 2020-03-23 03:17:37 --> Total execution time: 0.4652
INFO - 2020-03-23 03:17:47 --> Config Class Initialized
INFO - 2020-03-23 03:17:47 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:17:47 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:17:47 --> Utf8 Class Initialized
INFO - 2020-03-23 03:17:47 --> URI Class Initialized
INFO - 2020-03-23 03:17:48 --> Router Class Initialized
INFO - 2020-03-23 03:17:48 --> Output Class Initialized
INFO - 2020-03-23 03:17:48 --> Security Class Initialized
DEBUG - 2020-03-23 03:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:17:48 --> Input Class Initialized
INFO - 2020-03-23 03:17:48 --> Language Class Initialized
INFO - 2020-03-23 03:17:48 --> Language Class Initialized
INFO - 2020-03-23 03:17:48 --> Config Class Initialized
INFO - 2020-03-23 03:17:48 --> Loader Class Initialized
INFO - 2020-03-23 03:17:48 --> Helper loaded: url_helper
INFO - 2020-03-23 03:17:48 --> Helper loaded: file_helper
INFO - 2020-03-23 03:17:48 --> Helper loaded: form_helper
INFO - 2020-03-23 03:17:48 --> Helper loaded: my_helper
INFO - 2020-03-23 03:17:48 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:17:48 --> Controller Class Initialized
INFO - 2020-03-23 03:17:48 --> Final output sent to browser
DEBUG - 2020-03-23 03:17:48 --> Total execution time: 0.4575
INFO - 2020-03-23 03:17:55 --> Config Class Initialized
INFO - 2020-03-23 03:17:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:17:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:17:55 --> Utf8 Class Initialized
INFO - 2020-03-23 03:17:55 --> URI Class Initialized
INFO - 2020-03-23 03:17:55 --> Router Class Initialized
INFO - 2020-03-23 03:17:55 --> Output Class Initialized
INFO - 2020-03-23 03:17:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:17:55 --> Input Class Initialized
INFO - 2020-03-23 03:17:55 --> Language Class Initialized
INFO - 2020-03-23 03:17:55 --> Language Class Initialized
INFO - 2020-03-23 03:17:55 --> Config Class Initialized
INFO - 2020-03-23 03:17:55 --> Loader Class Initialized
INFO - 2020-03-23 03:17:55 --> Helper loaded: url_helper
INFO - 2020-03-23 03:17:55 --> Helper loaded: file_helper
INFO - 2020-03-23 03:17:55 --> Helper loaded: form_helper
INFO - 2020-03-23 03:17:56 --> Helper loaded: my_helper
INFO - 2020-03-23 03:17:56 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:17:56 --> Controller Class Initialized
INFO - 2020-03-23 03:17:56 --> Final output sent to browser
DEBUG - 2020-03-23 03:17:56 --> Total execution time: 0.5125
INFO - 2020-03-23 03:18:19 --> Config Class Initialized
INFO - 2020-03-23 03:18:19 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:19 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:19 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:19 --> URI Class Initialized
INFO - 2020-03-23 03:18:19 --> Router Class Initialized
INFO - 2020-03-23 03:18:19 --> Output Class Initialized
INFO - 2020-03-23 03:18:19 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:19 --> Input Class Initialized
INFO - 2020-03-23 03:18:19 --> Language Class Initialized
INFO - 2020-03-23 03:18:19 --> Language Class Initialized
INFO - 2020-03-23 03:18:19 --> Config Class Initialized
INFO - 2020-03-23 03:18:19 --> Loader Class Initialized
INFO - 2020-03-23 03:18:19 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:19 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:19 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:19 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:19 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:19 --> Controller Class Initialized
INFO - 2020-03-23 03:18:19 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:19 --> Total execution time: 0.5399
INFO - 2020-03-23 03:18:19 --> Config Class Initialized
INFO - 2020-03-23 03:18:19 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:19 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:19 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:19 --> URI Class Initialized
INFO - 2020-03-23 03:18:19 --> Router Class Initialized
INFO - 2020-03-23 03:18:20 --> Output Class Initialized
INFO - 2020-03-23 03:18:20 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:20 --> Input Class Initialized
INFO - 2020-03-23 03:18:20 --> Language Class Initialized
INFO - 2020-03-23 03:18:20 --> Language Class Initialized
INFO - 2020-03-23 03:18:20 --> Config Class Initialized
INFO - 2020-03-23 03:18:20 --> Loader Class Initialized
INFO - 2020-03-23 03:18:20 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:20 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:20 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:20 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:20 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:20 --> Controller Class Initialized
INFO - 2020-03-23 03:18:24 --> Config Class Initialized
INFO - 2020-03-23 03:18:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:24 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:24 --> URI Class Initialized
INFO - 2020-03-23 03:18:24 --> Router Class Initialized
INFO - 2020-03-23 03:18:24 --> Output Class Initialized
INFO - 2020-03-23 03:18:24 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:24 --> Input Class Initialized
INFO - 2020-03-23 03:18:24 --> Language Class Initialized
INFO - 2020-03-23 03:18:24 --> Language Class Initialized
INFO - 2020-03-23 03:18:24 --> Config Class Initialized
INFO - 2020-03-23 03:18:24 --> Loader Class Initialized
INFO - 2020-03-23 03:18:24 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:24 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:24 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:24 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:24 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:25 --> Controller Class Initialized
INFO - 2020-03-23 03:18:25 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:25 --> Total execution time: 0.7386
INFO - 2020-03-23 03:18:25 --> Config Class Initialized
INFO - 2020-03-23 03:18:25 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:25 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:25 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:25 --> URI Class Initialized
INFO - 2020-03-23 03:18:25 --> Router Class Initialized
INFO - 2020-03-23 03:18:25 --> Output Class Initialized
INFO - 2020-03-23 03:18:25 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:25 --> Input Class Initialized
INFO - 2020-03-23 03:18:25 --> Language Class Initialized
INFO - 2020-03-23 03:18:25 --> Language Class Initialized
INFO - 2020-03-23 03:18:25 --> Config Class Initialized
INFO - 2020-03-23 03:18:25 --> Loader Class Initialized
INFO - 2020-03-23 03:18:25 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:25 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:25 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:25 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:25 --> Controller Class Initialized
INFO - 2020-03-23 03:18:27 --> Config Class Initialized
INFO - 2020-03-23 03:18:27 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:27 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:27 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:27 --> URI Class Initialized
DEBUG - 2020-03-23 03:18:27 --> No URI present. Default controller set.
INFO - 2020-03-23 03:18:27 --> Router Class Initialized
INFO - 2020-03-23 03:18:27 --> Output Class Initialized
INFO - 2020-03-23 03:18:27 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:27 --> Input Class Initialized
INFO - 2020-03-23 03:18:27 --> Language Class Initialized
INFO - 2020-03-23 03:18:27 --> Language Class Initialized
INFO - 2020-03-23 03:18:27 --> Config Class Initialized
INFO - 2020-03-23 03:18:27 --> Loader Class Initialized
INFO - 2020-03-23 03:18:27 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:27 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:27 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:28 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:28 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:28 --> Controller Class Initialized
DEBUG - 2020-03-23 03:18:28 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 03:18:28 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:18:28 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:28 --> Total execution time: 0.6943
INFO - 2020-03-23 03:18:31 --> Config Class Initialized
INFO - 2020-03-23 03:18:31 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:31 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:31 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:31 --> URI Class Initialized
INFO - 2020-03-23 03:18:31 --> Router Class Initialized
INFO - 2020-03-23 03:18:31 --> Output Class Initialized
INFO - 2020-03-23 03:18:31 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:31 --> Input Class Initialized
INFO - 2020-03-23 03:18:31 --> Language Class Initialized
INFO - 2020-03-23 03:18:31 --> Language Class Initialized
INFO - 2020-03-23 03:18:32 --> Config Class Initialized
INFO - 2020-03-23 03:18:32 --> Loader Class Initialized
INFO - 2020-03-23 03:18:32 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:32 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:32 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:32 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:32 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:32 --> Controller Class Initialized
DEBUG - 2020-03-23 03:18:32 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-03-23 03:18:32 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:18:32 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:32 --> Total execution time: 0.7848
INFO - 2020-03-23 03:18:33 --> Config Class Initialized
INFO - 2020-03-23 03:18:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:33 --> URI Class Initialized
INFO - 2020-03-23 03:18:33 --> Router Class Initialized
INFO - 2020-03-23 03:18:33 --> Output Class Initialized
INFO - 2020-03-23 03:18:33 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:33 --> Config Class Initialized
INFO - 2020-03-23 03:18:33 --> Hooks Class Initialized
INFO - 2020-03-23 03:18:33 --> Input Class Initialized
DEBUG - 2020-03-23 03:18:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:33 --> Language Class Initialized
INFO - 2020-03-23 03:18:33 --> URI Class Initialized
INFO - 2020-03-23 03:18:33 --> Language Class Initialized
INFO - 2020-03-23 03:18:33 --> Config Class Initialized
INFO - 2020-03-23 03:18:33 --> Router Class Initialized
INFO - 2020-03-23 03:18:33 --> Loader Class Initialized
INFO - 2020-03-23 03:18:33 --> Output Class Initialized
INFO - 2020-03-23 03:18:33 --> Security Class Initialized
INFO - 2020-03-23 03:18:33 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:33 --> Helper loaded: file_helper
DEBUG - 2020-03-23 03:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:33 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:33 --> Input Class Initialized
INFO - 2020-03-23 03:18:33 --> Language Class Initialized
INFO - 2020-03-23 03:18:33 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:33 --> Language Class Initialized
INFO - 2020-03-23 03:18:33 --> Database Driver Class Initialized
INFO - 2020-03-23 03:18:34 --> Config Class Initialized
DEBUG - 2020-03-23 03:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:34 --> Loader Class Initialized
INFO - 2020-03-23 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:34 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:34 --> Controller Class Initialized
INFO - 2020-03-23 03:18:34 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:34 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:34 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:34 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:34 --> Controller Class Initialized
DEBUG - 2020-03-23 03:18:34 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 03:18:34 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:18:34 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:34 --> Total execution time: 0.8060
INFO - 2020-03-23 03:18:35 --> Config Class Initialized
INFO - 2020-03-23 03:18:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:35 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:35 --> URI Class Initialized
INFO - 2020-03-23 03:18:35 --> Router Class Initialized
INFO - 2020-03-23 03:18:35 --> Output Class Initialized
INFO - 2020-03-23 03:18:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:35 --> Input Class Initialized
INFO - 2020-03-23 03:18:35 --> Language Class Initialized
INFO - 2020-03-23 03:18:35 --> Language Class Initialized
INFO - 2020-03-23 03:18:35 --> Config Class Initialized
INFO - 2020-03-23 03:18:35 --> Loader Class Initialized
INFO - 2020-03-23 03:18:35 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:35 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:35 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:35 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:35 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:36 --> Controller Class Initialized
INFO - 2020-03-23 03:18:51 --> Config Class Initialized
INFO - 2020-03-23 03:18:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:51 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:51 --> URI Class Initialized
INFO - 2020-03-23 03:18:51 --> Router Class Initialized
INFO - 2020-03-23 03:18:51 --> Output Class Initialized
INFO - 2020-03-23 03:18:51 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:51 --> Input Class Initialized
INFO - 2020-03-23 03:18:51 --> Language Class Initialized
INFO - 2020-03-23 03:18:51 --> Language Class Initialized
INFO - 2020-03-23 03:18:51 --> Config Class Initialized
INFO - 2020-03-23 03:18:51 --> Loader Class Initialized
INFO - 2020-03-23 03:18:51 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:51 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:51 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:51 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:51 --> Controller Class Initialized
INFO - 2020-03-23 03:18:51 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:18:51 --> Config Class Initialized
INFO - 2020-03-23 03:18:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:51 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:51 --> URI Class Initialized
INFO - 2020-03-23 03:18:52 --> Router Class Initialized
INFO - 2020-03-23 03:18:52 --> Output Class Initialized
INFO - 2020-03-23 03:18:52 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:52 --> Input Class Initialized
INFO - 2020-03-23 03:18:52 --> Language Class Initialized
INFO - 2020-03-23 03:18:52 --> Language Class Initialized
INFO - 2020-03-23 03:18:52 --> Config Class Initialized
INFO - 2020-03-23 03:18:52 --> Loader Class Initialized
INFO - 2020-03-23 03:18:52 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:52 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:52 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:52 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:52 --> Controller Class Initialized
INFO - 2020-03-23 03:18:52 --> Config Class Initialized
INFO - 2020-03-23 03:18:52 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:52 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:52 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:52 --> URI Class Initialized
INFO - 2020-03-23 03:18:52 --> Router Class Initialized
INFO - 2020-03-23 03:18:52 --> Output Class Initialized
INFO - 2020-03-23 03:18:52 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:52 --> Input Class Initialized
INFO - 2020-03-23 03:18:52 --> Language Class Initialized
INFO - 2020-03-23 03:18:52 --> Language Class Initialized
INFO - 2020-03-23 03:18:52 --> Config Class Initialized
INFO - 2020-03-23 03:18:52 --> Loader Class Initialized
INFO - 2020-03-23 03:18:52 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:52 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:52 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:52 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:52 --> Controller Class Initialized
DEBUG - 2020-03-23 03:18:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:18:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:18:52 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:52 --> Total execution time: 0.4938
INFO - 2020-03-23 03:18:59 --> Config Class Initialized
INFO - 2020-03-23 03:18:59 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:59 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:18:59 --> Utf8 Class Initialized
INFO - 2020-03-23 03:18:59 --> URI Class Initialized
INFO - 2020-03-23 03:18:59 --> Router Class Initialized
INFO - 2020-03-23 03:18:59 --> Output Class Initialized
INFO - 2020-03-23 03:18:59 --> Security Class Initialized
DEBUG - 2020-03-23 03:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:18:59 --> Input Class Initialized
INFO - 2020-03-23 03:18:59 --> Language Class Initialized
INFO - 2020-03-23 03:18:59 --> Language Class Initialized
INFO - 2020-03-23 03:18:59 --> Config Class Initialized
INFO - 2020-03-23 03:18:59 --> Loader Class Initialized
INFO - 2020-03-23 03:18:59 --> Helper loaded: url_helper
INFO - 2020-03-23 03:18:59 --> Helper loaded: file_helper
INFO - 2020-03-23 03:18:59 --> Helper loaded: form_helper
INFO - 2020-03-23 03:18:59 --> Helper loaded: my_helper
INFO - 2020-03-23 03:18:59 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:18:59 --> Controller Class Initialized
INFO - 2020-03-23 03:18:59 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:18:59 --> Final output sent to browser
DEBUG - 2020-03-23 03:18:59 --> Total execution time: 0.5414
INFO - 2020-03-23 03:18:59 --> Config Class Initialized
INFO - 2020-03-23 03:18:59 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:18:59 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:19:00 --> Utf8 Class Initialized
INFO - 2020-03-23 03:19:00 --> URI Class Initialized
INFO - 2020-03-23 03:19:00 --> Router Class Initialized
INFO - 2020-03-23 03:19:00 --> Output Class Initialized
INFO - 2020-03-23 03:19:00 --> Security Class Initialized
DEBUG - 2020-03-23 03:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:19:00 --> Input Class Initialized
INFO - 2020-03-23 03:19:00 --> Language Class Initialized
INFO - 2020-03-23 03:19:00 --> Language Class Initialized
INFO - 2020-03-23 03:19:00 --> Config Class Initialized
INFO - 2020-03-23 03:19:00 --> Loader Class Initialized
INFO - 2020-03-23 03:19:00 --> Helper loaded: url_helper
INFO - 2020-03-23 03:19:00 --> Helper loaded: file_helper
INFO - 2020-03-23 03:19:00 --> Helper loaded: form_helper
INFO - 2020-03-23 03:19:00 --> Helper loaded: my_helper
INFO - 2020-03-23 03:19:00 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:19:00 --> Controller Class Initialized
DEBUG - 2020-03-23 03:19:00 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-23 03:19:00 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:19:00 --> Final output sent to browser
DEBUG - 2020-03-23 03:19:04 --> Total execution time: 0.7607
INFO - 2020-03-23 03:19:39 --> Config Class Initialized
INFO - 2020-03-23 03:19:39 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:19:39 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:19:39 --> Utf8 Class Initialized
INFO - 2020-03-23 03:19:39 --> URI Class Initialized
INFO - 2020-03-23 03:19:39 --> Router Class Initialized
INFO - 2020-03-23 03:19:39 --> Output Class Initialized
INFO - 2020-03-23 03:19:39 --> Security Class Initialized
DEBUG - 2020-03-23 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:19:39 --> Input Class Initialized
INFO - 2020-03-23 03:19:39 --> Language Class Initialized
INFO - 2020-03-23 03:19:40 --> Language Class Initialized
INFO - 2020-03-23 03:19:40 --> Config Class Initialized
INFO - 2020-03-23 03:19:40 --> Loader Class Initialized
INFO - 2020-03-23 03:19:40 --> Helper loaded: url_helper
INFO - 2020-03-23 03:19:40 --> Helper loaded: file_helper
INFO - 2020-03-23 03:19:40 --> Helper loaded: form_helper
INFO - 2020-03-23 03:19:40 --> Helper loaded: my_helper
INFO - 2020-03-23 03:19:40 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:19:40 --> Controller Class Initialized
DEBUG - 2020-03-23 03:19:40 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-03-23 03:19:40 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:19:40 --> Final output sent to browser
DEBUG - 2020-03-23 03:19:40 --> Total execution time: 0.6620
INFO - 2020-03-23 03:19:55 --> Config Class Initialized
INFO - 2020-03-23 03:19:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:19:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:19:55 --> Utf8 Class Initialized
INFO - 2020-03-23 03:19:55 --> URI Class Initialized
INFO - 2020-03-23 03:19:55 --> Router Class Initialized
INFO - 2020-03-23 03:19:55 --> Output Class Initialized
INFO - 2020-03-23 03:19:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:19:55 --> Input Class Initialized
INFO - 2020-03-23 03:19:56 --> Language Class Initialized
INFO - 2020-03-23 03:19:56 --> Language Class Initialized
INFO - 2020-03-23 03:19:56 --> Config Class Initialized
INFO - 2020-03-23 03:19:56 --> Loader Class Initialized
INFO - 2020-03-23 03:19:56 --> Helper loaded: url_helper
INFO - 2020-03-23 03:19:56 --> Helper loaded: file_helper
INFO - 2020-03-23 03:19:56 --> Helper loaded: form_helper
INFO - 2020-03-23 03:19:56 --> Helper loaded: my_helper
INFO - 2020-03-23 03:19:56 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:19:56 --> Controller Class Initialized
DEBUG - 2020-03-23 03:19:56 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-03-23 03:19:56 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:19:56 --> Final output sent to browser
DEBUG - 2020-03-23 03:19:57 --> Total execution time: 1.3908
INFO - 2020-03-23 03:20:10 --> Config Class Initialized
INFO - 2020-03-23 03:20:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:10 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:10 --> URI Class Initialized
INFO - 2020-03-23 03:20:10 --> Router Class Initialized
INFO - 2020-03-23 03:20:10 --> Output Class Initialized
INFO - 2020-03-23 03:20:10 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:10 --> Input Class Initialized
INFO - 2020-03-23 03:20:10 --> Language Class Initialized
INFO - 2020-03-23 03:20:10 --> Language Class Initialized
INFO - 2020-03-23 03:20:11 --> Config Class Initialized
INFO - 2020-03-23 03:20:11 --> Loader Class Initialized
INFO - 2020-03-23 03:20:11 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:11 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:11 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:11 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:11 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:11 --> Controller Class Initialized
DEBUG - 2020-03-23 03:20:11 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_absensi/views/list.php
DEBUG - 2020-03-23 03:20:11 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:20:11 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:12 --> Total execution time: 1.1035
INFO - 2020-03-23 03:20:24 --> Config Class Initialized
INFO - 2020-03-23 03:20:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:24 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:24 --> URI Class Initialized
INFO - 2020-03-23 03:20:24 --> Router Class Initialized
INFO - 2020-03-23 03:20:24 --> Output Class Initialized
INFO - 2020-03-23 03:20:24 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:25 --> Input Class Initialized
INFO - 2020-03-23 03:20:25 --> Language Class Initialized
INFO - 2020-03-23 03:20:25 --> Language Class Initialized
INFO - 2020-03-23 03:20:25 --> Config Class Initialized
INFO - 2020-03-23 03:20:25 --> Loader Class Initialized
INFO - 2020-03-23 03:20:25 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:25 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:25 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:25 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:25 --> Controller Class Initialized
DEBUG - 2020-03-23 03:20:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_ekstra/views/list.php
DEBUG - 2020-03-23 03:20:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:20:25 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:25 --> Total execution time: 1.3198
INFO - 2020-03-23 03:20:29 --> Config Class Initialized
INFO - 2020-03-23 03:20:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:29 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:29 --> URI Class Initialized
INFO - 2020-03-23 03:20:29 --> Router Class Initialized
INFO - 2020-03-23 03:20:29 --> Output Class Initialized
INFO - 2020-03-23 03:20:29 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:29 --> Input Class Initialized
INFO - 2020-03-23 03:20:29 --> Language Class Initialized
INFO - 2020-03-23 03:20:29 --> Language Class Initialized
INFO - 2020-03-23 03:20:29 --> Config Class Initialized
INFO - 2020-03-23 03:20:29 --> Loader Class Initialized
INFO - 2020-03-23 03:20:29 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:29 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:29 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:29 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:29 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:29 --> Controller Class Initialized
INFO - 2020-03-23 03:20:29 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:29 --> Total execution time: 0.4621
INFO - 2020-03-23 03:20:32 --> Config Class Initialized
INFO - 2020-03-23 03:20:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:32 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:32 --> URI Class Initialized
INFO - 2020-03-23 03:20:32 --> Router Class Initialized
INFO - 2020-03-23 03:20:32 --> Output Class Initialized
INFO - 2020-03-23 03:20:32 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:32 --> Input Class Initialized
INFO - 2020-03-23 03:20:32 --> Language Class Initialized
INFO - 2020-03-23 03:20:32 --> Language Class Initialized
INFO - 2020-03-23 03:20:32 --> Config Class Initialized
INFO - 2020-03-23 03:20:32 --> Loader Class Initialized
INFO - 2020-03-23 03:20:32 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:32 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:32 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:32 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:32 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:32 --> Controller Class Initialized
INFO - 2020-03-23 03:20:32 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:32 --> Total execution time: 0.4467
INFO - 2020-03-23 03:20:35 --> Config Class Initialized
INFO - 2020-03-23 03:20:35 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:35 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:35 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:35 --> URI Class Initialized
INFO - 2020-03-23 03:20:35 --> Router Class Initialized
INFO - 2020-03-23 03:20:35 --> Output Class Initialized
INFO - 2020-03-23 03:20:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:35 --> Input Class Initialized
INFO - 2020-03-23 03:20:35 --> Language Class Initialized
INFO - 2020-03-23 03:20:36 --> Language Class Initialized
INFO - 2020-03-23 03:20:36 --> Config Class Initialized
INFO - 2020-03-23 03:20:36 --> Loader Class Initialized
INFO - 2020-03-23 03:20:36 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:36 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:36 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:36 --> Controller Class Initialized
DEBUG - 2020-03-23 03:20:36 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_prestasi/views/list.php
DEBUG - 2020-03-23 03:20:36 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:20:36 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:37 --> Total execution time: 1.3984
INFO - 2020-03-23 03:20:37 --> Config Class Initialized
INFO - 2020-03-23 03:20:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:37 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:38 --> URI Class Initialized
INFO - 2020-03-23 03:20:38 --> Router Class Initialized
INFO - 2020-03-23 03:20:38 --> Output Class Initialized
INFO - 2020-03-23 03:20:38 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:38 --> Input Class Initialized
INFO - 2020-03-23 03:20:38 --> Language Class Initialized
INFO - 2020-03-23 03:20:38 --> Language Class Initialized
INFO - 2020-03-23 03:20:38 --> Config Class Initialized
INFO - 2020-03-23 03:20:38 --> Loader Class Initialized
INFO - 2020-03-23 03:20:38 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:38 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:38 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:38 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:38 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:38 --> Controller Class Initialized
INFO - 2020-03-23 03:20:38 --> Config Class Initialized
INFO - 2020-03-23 03:20:38 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:38 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:38 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:38 --> URI Class Initialized
INFO - 2020-03-23 03:20:39 --> Router Class Initialized
INFO - 2020-03-23 03:20:39 --> Output Class Initialized
INFO - 2020-03-23 03:20:39 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:39 --> Input Class Initialized
INFO - 2020-03-23 03:20:39 --> Language Class Initialized
INFO - 2020-03-23 03:20:39 --> Language Class Initialized
INFO - 2020-03-23 03:20:39 --> Config Class Initialized
INFO - 2020-03-23 03:20:39 --> Loader Class Initialized
INFO - 2020-03-23 03:20:39 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:39 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:39 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:39 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:39 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:39 --> Controller Class Initialized
DEBUG - 2020-03-23 03:20:39 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_ekstra/views/list.php
DEBUG - 2020-03-23 03:20:39 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:20:39 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:40 --> Total execution time: 1.0923
INFO - 2020-03-23 03:20:51 --> Config Class Initialized
INFO - 2020-03-23 03:20:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:20:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:20:51 --> Utf8 Class Initialized
INFO - 2020-03-23 03:20:51 --> URI Class Initialized
INFO - 2020-03-23 03:20:52 --> Router Class Initialized
INFO - 2020-03-23 03:20:52 --> Output Class Initialized
INFO - 2020-03-23 03:20:52 --> Security Class Initialized
DEBUG - 2020-03-23 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:20:52 --> Input Class Initialized
INFO - 2020-03-23 03:20:52 --> Language Class Initialized
INFO - 2020-03-23 03:20:52 --> Language Class Initialized
INFO - 2020-03-23 03:20:52 --> Config Class Initialized
INFO - 2020-03-23 03:20:52 --> Loader Class Initialized
INFO - 2020-03-23 03:20:52 --> Helper loaded: url_helper
INFO - 2020-03-23 03:20:52 --> Helper loaded: file_helper
INFO - 2020-03-23 03:20:52 --> Helper loaded: form_helper
INFO - 2020-03-23 03:20:52 --> Helper loaded: my_helper
INFO - 2020-03-23 03:20:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:20:52 --> Controller Class Initialized
INFO - 2020-03-23 03:20:52 --> Final output sent to browser
DEBUG - 2020-03-23 03:20:52 --> Total execution time: 0.4479
INFO - 2020-03-23 03:21:03 --> Config Class Initialized
INFO - 2020-03-23 03:21:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:21:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:21:03 --> Utf8 Class Initialized
INFO - 2020-03-23 03:21:04 --> URI Class Initialized
INFO - 2020-03-23 03:21:04 --> Router Class Initialized
INFO - 2020-03-23 03:21:04 --> Output Class Initialized
INFO - 2020-03-23 03:21:04 --> Security Class Initialized
DEBUG - 2020-03-23 03:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:21:04 --> Input Class Initialized
INFO - 2020-03-23 03:21:04 --> Language Class Initialized
INFO - 2020-03-23 03:21:04 --> Language Class Initialized
INFO - 2020-03-23 03:21:04 --> Config Class Initialized
INFO - 2020-03-23 03:21:04 --> Loader Class Initialized
INFO - 2020-03-23 03:21:04 --> Helper loaded: url_helper
INFO - 2020-03-23 03:21:04 --> Helper loaded: file_helper
INFO - 2020-03-23 03:21:04 --> Helper loaded: form_helper
INFO - 2020-03-23 03:21:04 --> Helper loaded: my_helper
INFO - 2020-03-23 03:21:04 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:21:04 --> Controller Class Initialized
DEBUG - 2020-03-23 03:21:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/n_prestasi/views/list.php
DEBUG - 2020-03-23 03:21:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:21:04 --> Final output sent to browser
DEBUG - 2020-03-23 03:21:05 --> Total execution time: 1.1298
INFO - 2020-03-23 03:21:06 --> Config Class Initialized
INFO - 2020-03-23 03:21:06 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:21:06 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:21:06 --> Utf8 Class Initialized
INFO - 2020-03-23 03:21:06 --> URI Class Initialized
INFO - 2020-03-23 03:21:06 --> Router Class Initialized
INFO - 2020-03-23 03:21:06 --> Output Class Initialized
INFO - 2020-03-23 03:21:06 --> Security Class Initialized
DEBUG - 2020-03-23 03:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:21:06 --> Input Class Initialized
INFO - 2020-03-23 03:21:06 --> Language Class Initialized
INFO - 2020-03-23 03:21:06 --> Language Class Initialized
INFO - 2020-03-23 03:21:06 --> Config Class Initialized
INFO - 2020-03-23 03:21:06 --> Loader Class Initialized
INFO - 2020-03-23 03:21:06 --> Helper loaded: url_helper
INFO - 2020-03-23 03:21:06 --> Helper loaded: file_helper
INFO - 2020-03-23 03:21:06 --> Helper loaded: form_helper
INFO - 2020-03-23 03:21:06 --> Helper loaded: my_helper
INFO - 2020-03-23 03:21:06 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:21:06 --> Controller Class Initialized
INFO - 2020-03-23 03:21:20 --> Config Class Initialized
INFO - 2020-03-23 03:21:20 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:21:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:21:20 --> Utf8 Class Initialized
INFO - 2020-03-23 03:21:21 --> URI Class Initialized
INFO - 2020-03-23 03:21:21 --> Router Class Initialized
INFO - 2020-03-23 03:21:21 --> Output Class Initialized
INFO - 2020-03-23 03:21:21 --> Security Class Initialized
DEBUG - 2020-03-23 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:21:21 --> Input Class Initialized
INFO - 2020-03-23 03:21:21 --> Language Class Initialized
INFO - 2020-03-23 03:21:21 --> Language Class Initialized
INFO - 2020-03-23 03:21:21 --> Config Class Initialized
INFO - 2020-03-23 03:21:21 --> Loader Class Initialized
INFO - 2020-03-23 03:21:21 --> Helper loaded: url_helper
INFO - 2020-03-23 03:21:21 --> Helper loaded: file_helper
INFO - 2020-03-23 03:21:21 --> Helper loaded: form_helper
INFO - 2020-03-23 03:21:21 --> Helper loaded: my_helper
INFO - 2020-03-23 03:21:21 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:21:22 --> Controller Class Initialized
DEBUG - 2020-03-23 03:21:22 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-03-23 03:21:22 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:21:22 --> Final output sent to browser
DEBUG - 2020-03-23 03:21:22 --> Total execution time: 1.6456
INFO - 2020-03-23 03:21:37 --> Config Class Initialized
INFO - 2020-03-23 03:21:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:21:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:21:37 --> Utf8 Class Initialized
INFO - 2020-03-23 03:21:38 --> URI Class Initialized
INFO - 2020-03-23 03:21:38 --> Router Class Initialized
INFO - 2020-03-23 03:21:38 --> Output Class Initialized
INFO - 2020-03-23 03:21:38 --> Security Class Initialized
DEBUG - 2020-03-23 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:21:38 --> Input Class Initialized
INFO - 2020-03-23 03:21:38 --> Language Class Initialized
INFO - 2020-03-23 03:21:38 --> Language Class Initialized
INFO - 2020-03-23 03:21:38 --> Config Class Initialized
INFO - 2020-03-23 03:21:38 --> Loader Class Initialized
INFO - 2020-03-23 03:21:38 --> Helper loaded: url_helper
INFO - 2020-03-23 03:21:38 --> Helper loaded: file_helper
INFO - 2020-03-23 03:21:38 --> Helper loaded: form_helper
INFO - 2020-03-23 03:21:38 --> Helper loaded: my_helper
INFO - 2020-03-23 03:21:38 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:21:39 --> Controller Class Initialized
DEBUG - 2020-03-23 03:21:39 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-03-23 03:21:39 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:21:39 --> Final output sent to browser
DEBUG - 2020-03-23 03:21:39 --> Total execution time: 1.7818
INFO - 2020-03-23 03:22:13 --> Config Class Initialized
INFO - 2020-03-23 03:22:13 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:22:13 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:22:13 --> Utf8 Class Initialized
INFO - 2020-03-23 03:22:13 --> URI Class Initialized
INFO - 2020-03-23 03:22:13 --> Router Class Initialized
INFO - 2020-03-23 03:22:14 --> Output Class Initialized
INFO - 2020-03-23 03:22:14 --> Security Class Initialized
DEBUG - 2020-03-23 03:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:22:14 --> Input Class Initialized
INFO - 2020-03-23 03:22:14 --> Language Class Initialized
INFO - 2020-03-23 03:22:14 --> Language Class Initialized
INFO - 2020-03-23 03:22:14 --> Config Class Initialized
INFO - 2020-03-23 03:22:14 --> Loader Class Initialized
INFO - 2020-03-23 03:22:14 --> Helper loaded: url_helper
INFO - 2020-03-23 03:22:14 --> Helper loaded: file_helper
INFO - 2020-03-23 03:22:14 --> Helper loaded: form_helper
INFO - 2020-03-23 03:22:14 --> Helper loaded: my_helper
INFO - 2020-03-23 03:22:14 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:22:14 --> Controller Class Initialized
DEBUG - 2020-03-23 03:22:14 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-03-23 03:22:14 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:22:14 --> Final output sent to browser
DEBUG - 2020-03-23 03:22:14 --> Total execution time: 1.3710
INFO - 2020-03-23 03:22:23 --> Config Class Initialized
INFO - 2020-03-23 03:22:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:22:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:22:24 --> Utf8 Class Initialized
INFO - 2020-03-23 03:22:24 --> URI Class Initialized
INFO - 2020-03-23 03:22:24 --> Router Class Initialized
INFO - 2020-03-23 03:22:24 --> Output Class Initialized
INFO - 2020-03-23 03:22:24 --> Security Class Initialized
DEBUG - 2020-03-23 03:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:22:24 --> Input Class Initialized
INFO - 2020-03-23 03:22:24 --> Language Class Initialized
INFO - 2020-03-23 03:22:24 --> Language Class Initialized
INFO - 2020-03-23 03:22:25 --> Config Class Initialized
INFO - 2020-03-23 03:22:25 --> Loader Class Initialized
INFO - 2020-03-23 03:22:25 --> Helper loaded: url_helper
INFO - 2020-03-23 03:22:25 --> Helper loaded: file_helper
INFO - 2020-03-23 03:22:25 --> Helper loaded: form_helper
INFO - 2020-03-23 03:22:25 --> Helper loaded: my_helper
INFO - 2020-03-23 03:22:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:22:25 --> Controller Class Initialized
DEBUG - 2020-03-23 03:22:26 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/cetak.php
INFO - 2020-03-23 03:22:26 --> Final output sent to browser
DEBUG - 2020-03-23 03:22:27 --> Total execution time: 3.3562
INFO - 2020-03-23 03:22:33 --> Config Class Initialized
INFO - 2020-03-23 03:22:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:22:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:22:34 --> Utf8 Class Initialized
INFO - 2020-03-23 03:22:34 --> URI Class Initialized
INFO - 2020-03-23 03:22:34 --> Router Class Initialized
INFO - 2020-03-23 03:22:34 --> Output Class Initialized
INFO - 2020-03-23 03:22:35 --> Security Class Initialized
DEBUG - 2020-03-23 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:22:35 --> Input Class Initialized
INFO - 2020-03-23 03:22:35 --> Language Class Initialized
INFO - 2020-03-23 03:22:36 --> Language Class Initialized
INFO - 2020-03-23 03:22:36 --> Config Class Initialized
INFO - 2020-03-23 03:22:36 --> Loader Class Initialized
INFO - 2020-03-23 03:22:36 --> Helper loaded: url_helper
INFO - 2020-03-23 03:22:36 --> Helper loaded: file_helper
INFO - 2020-03-23 03:22:36 --> Helper loaded: form_helper
INFO - 2020-03-23 03:22:36 --> Helper loaded: my_helper
INFO - 2020-03-23 03:22:36 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:22:37 --> Controller Class Initialized
DEBUG - 2020-03-23 03:22:39 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/cetak.php
INFO - 2020-03-23 03:22:39 --> Final output sent to browser
DEBUG - 2020-03-23 03:22:40 --> Total execution time: 5.7520
INFO - 2020-03-23 03:22:53 --> Config Class Initialized
INFO - 2020-03-23 03:22:53 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:22:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:22:54 --> Utf8 Class Initialized
INFO - 2020-03-23 03:22:54 --> URI Class Initialized
INFO - 2020-03-23 03:22:54 --> Router Class Initialized
INFO - 2020-03-23 03:22:55 --> Output Class Initialized
INFO - 2020-03-23 03:22:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:22:55 --> Input Class Initialized
INFO - 2020-03-23 03:22:55 --> Language Class Initialized
INFO - 2020-03-23 03:22:55 --> Language Class Initialized
INFO - 2020-03-23 03:22:55 --> Config Class Initialized
INFO - 2020-03-23 03:22:55 --> Loader Class Initialized
INFO - 2020-03-23 03:22:55 --> Helper loaded: url_helper
INFO - 2020-03-23 03:22:55 --> Helper loaded: file_helper
INFO - 2020-03-23 03:22:55 --> Helper loaded: form_helper
INFO - 2020-03-23 03:22:55 --> Helper loaded: my_helper
INFO - 2020-03-23 03:22:55 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:22:55 --> Controller Class Initialized
DEBUG - 2020-03-23 03:22:57 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/cetak.php
INFO - 2020-03-23 03:22:57 --> Final output sent to browser
DEBUG - 2020-03-23 03:22:57 --> Total execution time: 3.4867
INFO - 2020-03-23 03:23:10 --> Config Class Initialized
INFO - 2020-03-23 03:23:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:23:11 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:23:11 --> Utf8 Class Initialized
INFO - 2020-03-23 03:23:11 --> URI Class Initialized
INFO - 2020-03-23 03:23:11 --> Router Class Initialized
INFO - 2020-03-23 03:23:11 --> Output Class Initialized
INFO - 2020-03-23 03:23:11 --> Security Class Initialized
DEBUG - 2020-03-23 03:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:23:11 --> Input Class Initialized
INFO - 2020-03-23 03:23:11 --> Language Class Initialized
INFO - 2020-03-23 03:23:11 --> Language Class Initialized
INFO - 2020-03-23 03:23:11 --> Config Class Initialized
INFO - 2020-03-23 03:23:11 --> Loader Class Initialized
INFO - 2020-03-23 03:23:11 --> Helper loaded: url_helper
INFO - 2020-03-23 03:23:12 --> Helper loaded: file_helper
INFO - 2020-03-23 03:23:12 --> Helper loaded: form_helper
INFO - 2020-03-23 03:23:12 --> Helper loaded: my_helper
INFO - 2020-03-23 03:23:12 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:23:12 --> Controller Class Initialized
DEBUG - 2020-03-23 03:23:12 --> File loaded: D:\xampp\htdocs\myraport\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-03-23 03:23:12 --> Final output sent to browser
DEBUG - 2020-03-23 03:23:13 --> Total execution time: 1.5810
INFO - 2020-03-23 03:32:32 --> Config Class Initialized
INFO - 2020-03-23 03:32:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:32:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:32:32 --> Utf8 Class Initialized
INFO - 2020-03-23 03:32:32 --> URI Class Initialized
INFO - 2020-03-23 03:32:32 --> Router Class Initialized
INFO - 2020-03-23 03:32:32 --> Output Class Initialized
INFO - 2020-03-23 03:32:32 --> Security Class Initialized
DEBUG - 2020-03-23 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:32:32 --> Input Class Initialized
INFO - 2020-03-23 03:32:32 --> Language Class Initialized
INFO - 2020-03-23 03:32:32 --> Language Class Initialized
INFO - 2020-03-23 03:32:32 --> Config Class Initialized
INFO - 2020-03-23 03:32:32 --> Loader Class Initialized
INFO - 2020-03-23 03:32:32 --> Helper loaded: url_helper
INFO - 2020-03-23 03:32:32 --> Helper loaded: file_helper
INFO - 2020-03-23 03:32:32 --> Helper loaded: form_helper
INFO - 2020-03-23 03:32:32 --> Helper loaded: my_helper
INFO - 2020-03-23 03:32:32 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:32:32 --> Controller Class Initialized
INFO - 2020-03-23 03:32:32 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:32:32 --> Config Class Initialized
INFO - 2020-03-23 03:32:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:32:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:32:32 --> Utf8 Class Initialized
INFO - 2020-03-23 03:32:33 --> URI Class Initialized
INFO - 2020-03-23 03:32:33 --> Router Class Initialized
INFO - 2020-03-23 03:32:33 --> Output Class Initialized
INFO - 2020-03-23 03:32:33 --> Security Class Initialized
DEBUG - 2020-03-23 03:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:32:33 --> Input Class Initialized
INFO - 2020-03-23 03:32:33 --> Language Class Initialized
INFO - 2020-03-23 03:32:33 --> Language Class Initialized
INFO - 2020-03-23 03:32:33 --> Config Class Initialized
INFO - 2020-03-23 03:32:33 --> Loader Class Initialized
INFO - 2020-03-23 03:32:33 --> Helper loaded: url_helper
INFO - 2020-03-23 03:32:33 --> Helper loaded: file_helper
INFO - 2020-03-23 03:32:33 --> Helper loaded: form_helper
INFO - 2020-03-23 03:32:33 --> Helper loaded: my_helper
INFO - 2020-03-23 03:32:33 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:32:33 --> Controller Class Initialized
INFO - 2020-03-23 03:32:33 --> Config Class Initialized
INFO - 2020-03-23 03:32:33 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:32:33 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:32:33 --> Utf8 Class Initialized
INFO - 2020-03-23 03:32:33 --> URI Class Initialized
INFO - 2020-03-23 03:32:33 --> Router Class Initialized
INFO - 2020-03-23 03:32:33 --> Output Class Initialized
INFO - 2020-03-23 03:32:33 --> Security Class Initialized
DEBUG - 2020-03-23 03:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:32:33 --> Input Class Initialized
INFO - 2020-03-23 03:32:33 --> Language Class Initialized
INFO - 2020-03-23 03:32:33 --> Language Class Initialized
INFO - 2020-03-23 03:32:33 --> Config Class Initialized
INFO - 2020-03-23 03:32:33 --> Loader Class Initialized
INFO - 2020-03-23 03:32:33 --> Helper loaded: url_helper
INFO - 2020-03-23 03:32:33 --> Helper loaded: file_helper
INFO - 2020-03-23 03:32:33 --> Helper loaded: form_helper
INFO - 2020-03-23 03:32:33 --> Helper loaded: my_helper
INFO - 2020-03-23 03:32:33 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:32:33 --> Controller Class Initialized
DEBUG - 2020-03-23 03:32:33 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:32:33 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:32:33 --> Final output sent to browser
DEBUG - 2020-03-23 03:32:34 --> Total execution time: 0.5460
INFO - 2020-03-23 03:33:54 --> Config Class Initialized
INFO - 2020-03-23 03:33:54 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:33:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:33:54 --> Utf8 Class Initialized
INFO - 2020-03-23 03:33:54 --> URI Class Initialized
INFO - 2020-03-23 03:33:54 --> Router Class Initialized
INFO - 2020-03-23 03:33:54 --> Output Class Initialized
INFO - 2020-03-23 03:33:54 --> Security Class Initialized
DEBUG - 2020-03-23 03:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:33:54 --> Input Class Initialized
INFO - 2020-03-23 03:33:54 --> Language Class Initialized
INFO - 2020-03-23 03:33:54 --> Language Class Initialized
INFO - 2020-03-23 03:33:54 --> Config Class Initialized
INFO - 2020-03-23 03:33:54 --> Loader Class Initialized
INFO - 2020-03-23 03:33:54 --> Helper loaded: url_helper
INFO - 2020-03-23 03:33:54 --> Helper loaded: file_helper
INFO - 2020-03-23 03:33:54 --> Helper loaded: form_helper
INFO - 2020-03-23 03:33:54 --> Helper loaded: my_helper
INFO - 2020-03-23 03:33:54 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:33:54 --> Controller Class Initialized
INFO - 2020-03-23 03:33:54 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:33:54 --> Final output sent to browser
DEBUG - 2020-03-23 03:33:54 --> Total execution time: 0.5705
INFO - 2020-03-23 03:33:54 --> Config Class Initialized
INFO - 2020-03-23 03:33:54 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:33:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:33:54 --> Utf8 Class Initialized
INFO - 2020-03-23 03:33:55 --> URI Class Initialized
INFO - 2020-03-23 03:33:55 --> Router Class Initialized
INFO - 2020-03-23 03:33:55 --> Output Class Initialized
INFO - 2020-03-23 03:33:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:33:55 --> Input Class Initialized
INFO - 2020-03-23 03:33:55 --> Language Class Initialized
INFO - 2020-03-23 03:33:55 --> Language Class Initialized
INFO - 2020-03-23 03:33:55 --> Config Class Initialized
INFO - 2020-03-23 03:33:55 --> Loader Class Initialized
INFO - 2020-03-23 03:33:55 --> Helper loaded: url_helper
INFO - 2020-03-23 03:33:55 --> Helper loaded: file_helper
INFO - 2020-03-23 03:33:55 --> Helper loaded: form_helper
INFO - 2020-03-23 03:33:55 --> Helper loaded: my_helper
INFO - 2020-03-23 03:33:55 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:33:55 --> Controller Class Initialized
DEBUG - 2020-03-23 03:33:55 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 03:33:55 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:33:55 --> Final output sent to browser
DEBUG - 2020-03-23 03:33:58 --> Total execution time: 0.7445
INFO - 2020-03-23 03:34:15 --> Config Class Initialized
INFO - 2020-03-23 03:34:15 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:34:15 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:34:15 --> Utf8 Class Initialized
INFO - 2020-03-23 03:34:15 --> URI Class Initialized
INFO - 2020-03-23 03:34:15 --> Router Class Initialized
INFO - 2020-03-23 03:34:15 --> Output Class Initialized
INFO - 2020-03-23 03:34:15 --> Security Class Initialized
DEBUG - 2020-03-23 03:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:34:15 --> Input Class Initialized
INFO - 2020-03-23 03:34:15 --> Language Class Initialized
INFO - 2020-03-23 03:34:15 --> Language Class Initialized
INFO - 2020-03-23 03:34:15 --> Config Class Initialized
INFO - 2020-03-23 03:34:15 --> Loader Class Initialized
INFO - 2020-03-23 03:34:16 --> Helper loaded: url_helper
INFO - 2020-03-23 03:34:16 --> Helper loaded: file_helper
INFO - 2020-03-23 03:34:16 --> Helper loaded: form_helper
INFO - 2020-03-23 03:34:16 --> Helper loaded: my_helper
INFO - 2020-03-23 03:34:16 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:34:16 --> Controller Class Initialized
DEBUG - 2020-03-23 03:34:16 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 03:34:16 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:34:16 --> Final output sent to browser
DEBUG - 2020-03-23 03:34:16 --> Total execution time: 0.5799
INFO - 2020-03-23 03:34:17 --> Config Class Initialized
INFO - 2020-03-23 03:34:17 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:34:17 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:34:17 --> Utf8 Class Initialized
INFO - 2020-03-23 03:34:17 --> URI Class Initialized
INFO - 2020-03-23 03:34:17 --> Router Class Initialized
INFO - 2020-03-23 03:34:17 --> Output Class Initialized
INFO - 2020-03-23 03:34:17 --> Security Class Initialized
DEBUG - 2020-03-23 03:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:34:17 --> Input Class Initialized
INFO - 2020-03-23 03:34:17 --> Language Class Initialized
INFO - 2020-03-23 03:34:17 --> Language Class Initialized
INFO - 2020-03-23 03:34:17 --> Config Class Initialized
INFO - 2020-03-23 03:34:17 --> Loader Class Initialized
INFO - 2020-03-23 03:34:17 --> Helper loaded: url_helper
INFO - 2020-03-23 03:34:17 --> Helper loaded: file_helper
INFO - 2020-03-23 03:34:17 --> Helper loaded: form_helper
INFO - 2020-03-23 03:34:17 --> Helper loaded: my_helper
INFO - 2020-03-23 03:34:17 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:34:17 --> Controller Class Initialized
INFO - 2020-03-23 03:34:21 --> Config Class Initialized
INFO - 2020-03-23 03:34:21 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:34:21 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:34:21 --> Utf8 Class Initialized
INFO - 2020-03-23 03:34:21 --> URI Class Initialized
INFO - 2020-03-23 03:34:21 --> Router Class Initialized
INFO - 2020-03-23 03:34:21 --> Output Class Initialized
INFO - 2020-03-23 03:34:21 --> Security Class Initialized
DEBUG - 2020-03-23 03:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:34:21 --> Input Class Initialized
INFO - 2020-03-23 03:34:21 --> Language Class Initialized
INFO - 2020-03-23 03:34:21 --> Language Class Initialized
INFO - 2020-03-23 03:34:21 --> Config Class Initialized
INFO - 2020-03-23 03:34:21 --> Loader Class Initialized
INFO - 2020-03-23 03:34:21 --> Helper loaded: url_helper
INFO - 2020-03-23 03:34:21 --> Helper loaded: file_helper
INFO - 2020-03-23 03:34:21 --> Helper loaded: form_helper
INFO - 2020-03-23 03:34:21 --> Helper loaded: my_helper
INFO - 2020-03-23 03:34:21 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:34:21 --> Controller Class Initialized
INFO - 2020-03-23 03:34:21 --> Final output sent to browser
DEBUG - 2020-03-23 03:34:21 --> Total execution time: 0.5169
INFO - 2020-03-23 03:34:55 --> Config Class Initialized
INFO - 2020-03-23 03:34:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:34:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:34:55 --> Utf8 Class Initialized
INFO - 2020-03-23 03:34:55 --> URI Class Initialized
INFO - 2020-03-23 03:34:55 --> Router Class Initialized
INFO - 2020-03-23 03:34:55 --> Output Class Initialized
INFO - 2020-03-23 03:34:55 --> Security Class Initialized
DEBUG - 2020-03-23 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:34:55 --> Input Class Initialized
INFO - 2020-03-23 03:34:55 --> Language Class Initialized
INFO - 2020-03-23 03:34:55 --> Language Class Initialized
INFO - 2020-03-23 03:34:55 --> Config Class Initialized
INFO - 2020-03-23 03:34:55 --> Loader Class Initialized
INFO - 2020-03-23 03:34:55 --> Helper loaded: url_helper
INFO - 2020-03-23 03:34:55 --> Helper loaded: file_helper
INFO - 2020-03-23 03:34:55 --> Helper loaded: form_helper
INFO - 2020-03-23 03:34:55 --> Helper loaded: my_helper
INFO - 2020-03-23 03:34:55 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:34:55 --> Controller Class Initialized
INFO - 2020-03-23 03:34:55 --> Final output sent to browser
DEBUG - 2020-03-23 03:34:55 --> Total execution time: 0.5424
INFO - 2020-03-23 03:35:02 --> Config Class Initialized
INFO - 2020-03-23 03:35:02 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:35:02 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:35:02 --> Utf8 Class Initialized
INFO - 2020-03-23 03:35:02 --> URI Class Initialized
INFO - 2020-03-23 03:35:02 --> Router Class Initialized
INFO - 2020-03-23 03:35:02 --> Output Class Initialized
INFO - 2020-03-23 03:35:02 --> Security Class Initialized
DEBUG - 2020-03-23 03:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:35:02 --> Input Class Initialized
INFO - 2020-03-23 03:35:02 --> Language Class Initialized
INFO - 2020-03-23 03:35:02 --> Language Class Initialized
INFO - 2020-03-23 03:35:02 --> Config Class Initialized
INFO - 2020-03-23 03:35:02 --> Loader Class Initialized
INFO - 2020-03-23 03:35:02 --> Helper loaded: url_helper
INFO - 2020-03-23 03:35:02 --> Helper loaded: file_helper
INFO - 2020-03-23 03:35:03 --> Helper loaded: form_helper
INFO - 2020-03-23 03:35:03 --> Helper loaded: my_helper
INFO - 2020-03-23 03:35:03 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:35:03 --> Controller Class Initialized
INFO - 2020-03-23 03:35:03 --> Helper loaded: cookie_helper
INFO - 2020-03-23 03:35:03 --> Config Class Initialized
INFO - 2020-03-23 03:35:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:35:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:35:03 --> Utf8 Class Initialized
INFO - 2020-03-23 03:35:03 --> URI Class Initialized
INFO - 2020-03-23 03:35:03 --> Router Class Initialized
INFO - 2020-03-23 03:35:03 --> Output Class Initialized
INFO - 2020-03-23 03:35:03 --> Security Class Initialized
DEBUG - 2020-03-23 03:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:35:03 --> Input Class Initialized
INFO - 2020-03-23 03:35:03 --> Language Class Initialized
INFO - 2020-03-23 03:35:03 --> Language Class Initialized
INFO - 2020-03-23 03:35:03 --> Config Class Initialized
INFO - 2020-03-23 03:35:03 --> Loader Class Initialized
INFO - 2020-03-23 03:35:03 --> Helper loaded: url_helper
INFO - 2020-03-23 03:35:03 --> Helper loaded: file_helper
INFO - 2020-03-23 03:35:03 --> Helper loaded: form_helper
INFO - 2020-03-23 03:35:03 --> Helper loaded: my_helper
INFO - 2020-03-23 03:35:03 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:35:03 --> Controller Class Initialized
INFO - 2020-03-23 03:35:03 --> Config Class Initialized
INFO - 2020-03-23 03:35:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 03:35:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 03:35:03 --> Utf8 Class Initialized
INFO - 2020-03-23 03:35:03 --> URI Class Initialized
INFO - 2020-03-23 03:35:03 --> Router Class Initialized
INFO - 2020-03-23 03:35:03 --> Output Class Initialized
INFO - 2020-03-23 03:35:03 --> Security Class Initialized
DEBUG - 2020-03-23 03:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 03:35:03 --> Input Class Initialized
INFO - 2020-03-23 03:35:03 --> Language Class Initialized
INFO - 2020-03-23 03:35:03 --> Language Class Initialized
INFO - 2020-03-23 03:35:03 --> Config Class Initialized
INFO - 2020-03-23 03:35:03 --> Loader Class Initialized
INFO - 2020-03-23 03:35:04 --> Helper loaded: url_helper
INFO - 2020-03-23 03:35:04 --> Helper loaded: file_helper
INFO - 2020-03-23 03:35:04 --> Helper loaded: form_helper
INFO - 2020-03-23 03:35:04 --> Helper loaded: my_helper
INFO - 2020-03-23 03:35:04 --> Database Driver Class Initialized
DEBUG - 2020-03-23 03:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 03:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 03:35:04 --> Controller Class Initialized
DEBUG - 2020-03-23 03:35:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 03:35:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 03:35:04 --> Final output sent to browser
DEBUG - 2020-03-23 03:35:04 --> Total execution time: 0.5601
INFO - 2020-03-23 05:29:09 --> Config Class Initialized
INFO - 2020-03-23 05:29:09 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:29:09 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:29:09 --> Utf8 Class Initialized
INFO - 2020-03-23 05:29:09 --> URI Class Initialized
INFO - 2020-03-23 05:29:09 --> Router Class Initialized
INFO - 2020-03-23 05:29:09 --> Output Class Initialized
INFO - 2020-03-23 05:29:09 --> Security Class Initialized
DEBUG - 2020-03-23 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:29:09 --> Input Class Initialized
INFO - 2020-03-23 05:29:09 --> Language Class Initialized
INFO - 2020-03-23 05:29:10 --> Language Class Initialized
INFO - 2020-03-23 05:29:10 --> Config Class Initialized
INFO - 2020-03-23 05:29:10 --> Loader Class Initialized
INFO - 2020-03-23 05:29:10 --> Helper loaded: url_helper
INFO - 2020-03-23 05:29:10 --> Helper loaded: file_helper
INFO - 2020-03-23 05:29:10 --> Helper loaded: form_helper
INFO - 2020-03-23 05:29:10 --> Helper loaded: my_helper
INFO - 2020-03-23 05:29:10 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:29:10 --> Controller Class Initialized
DEBUG - 2020-03-23 05:29:10 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:29:10 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:29:10 --> Final output sent to browser
DEBUG - 2020-03-23 05:29:10 --> Total execution time: 0.9435
INFO - 2020-03-23 05:29:19 --> Config Class Initialized
INFO - 2020-03-23 05:29:19 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:29:19 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:29:19 --> Utf8 Class Initialized
INFO - 2020-03-23 05:29:19 --> URI Class Initialized
INFO - 2020-03-23 05:29:19 --> Router Class Initialized
INFO - 2020-03-23 05:29:19 --> Output Class Initialized
INFO - 2020-03-23 05:29:19 --> Security Class Initialized
DEBUG - 2020-03-23 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:29:19 --> Input Class Initialized
INFO - 2020-03-23 05:29:19 --> Language Class Initialized
INFO - 2020-03-23 05:29:19 --> Language Class Initialized
INFO - 2020-03-23 05:29:19 --> Config Class Initialized
INFO - 2020-03-23 05:29:19 --> Loader Class Initialized
INFO - 2020-03-23 05:29:19 --> Helper loaded: url_helper
INFO - 2020-03-23 05:29:19 --> Helper loaded: file_helper
INFO - 2020-03-23 05:29:19 --> Helper loaded: form_helper
INFO - 2020-03-23 05:29:19 --> Helper loaded: my_helper
INFO - 2020-03-23 05:29:19 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:29:19 --> Controller Class Initialized
INFO - 2020-03-23 05:29:19 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:29:19 --> Final output sent to browser
DEBUG - 2020-03-23 05:29:19 --> Total execution time: 0.6609
INFO - 2020-03-23 05:29:19 --> Config Class Initialized
INFO - 2020-03-23 05:29:19 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:29:19 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:29:20 --> Utf8 Class Initialized
INFO - 2020-03-23 05:29:20 --> URI Class Initialized
INFO - 2020-03-23 05:29:20 --> Router Class Initialized
INFO - 2020-03-23 05:29:20 --> Output Class Initialized
INFO - 2020-03-23 05:29:20 --> Security Class Initialized
DEBUG - 2020-03-23 05:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:29:20 --> Input Class Initialized
INFO - 2020-03-23 05:29:20 --> Language Class Initialized
INFO - 2020-03-23 05:29:20 --> Language Class Initialized
INFO - 2020-03-23 05:29:20 --> Config Class Initialized
INFO - 2020-03-23 05:29:20 --> Loader Class Initialized
INFO - 2020-03-23 05:29:20 --> Helper loaded: url_helper
INFO - 2020-03-23 05:29:20 --> Helper loaded: file_helper
INFO - 2020-03-23 05:29:20 --> Helper loaded: form_helper
INFO - 2020-03-23 05:29:20 --> Helper loaded: my_helper
INFO - 2020-03-23 05:29:20 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:29:20 --> Controller Class Initialized
DEBUG - 2020-03-23 05:29:20 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 05:29:20 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:29:20 --> Final output sent to browser
DEBUG - 2020-03-23 05:29:23 --> Total execution time: 0.8755
INFO - 2020-03-23 05:37:22 --> Config Class Initialized
INFO - 2020-03-23 05:37:22 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:22 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:22 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:22 --> URI Class Initialized
INFO - 2020-03-23 05:37:23 --> Router Class Initialized
INFO - 2020-03-23 05:37:23 --> Output Class Initialized
INFO - 2020-03-23 05:37:23 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:23 --> Input Class Initialized
INFO - 2020-03-23 05:37:23 --> Language Class Initialized
INFO - 2020-03-23 05:37:23 --> Language Class Initialized
INFO - 2020-03-23 05:37:23 --> Config Class Initialized
INFO - 2020-03-23 05:37:23 --> Loader Class Initialized
INFO - 2020-03-23 05:37:23 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:23 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:23 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:23 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:23 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:23 --> Controller Class Initialized
DEBUG - 2020-03-23 05:37:23 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-23 05:37:23 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:37:23 --> Final output sent to browser
DEBUG - 2020-03-23 05:37:23 --> Total execution time: 0.7851
INFO - 2020-03-23 05:37:24 --> Config Class Initialized
INFO - 2020-03-23 05:37:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:24 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:24 --> URI Class Initialized
INFO - 2020-03-23 05:37:24 --> Router Class Initialized
INFO - 2020-03-23 05:37:24 --> Output Class Initialized
INFO - 2020-03-23 05:37:24 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:24 --> Input Class Initialized
INFO - 2020-03-23 05:37:24 --> Language Class Initialized
INFO - 2020-03-23 05:37:24 --> Language Class Initialized
INFO - 2020-03-23 05:37:24 --> Config Class Initialized
INFO - 2020-03-23 05:37:24 --> Loader Class Initialized
INFO - 2020-03-23 05:37:24 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:24 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:24 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:24 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:25 --> Controller Class Initialized
INFO - 2020-03-23 05:37:37 --> Config Class Initialized
INFO - 2020-03-23 05:37:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:37 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:37 --> URI Class Initialized
INFO - 2020-03-23 05:37:37 --> Router Class Initialized
INFO - 2020-03-23 05:37:37 --> Output Class Initialized
INFO - 2020-03-23 05:37:37 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:37 --> Input Class Initialized
INFO - 2020-03-23 05:37:37 --> Language Class Initialized
INFO - 2020-03-23 05:37:37 --> Language Class Initialized
INFO - 2020-03-23 05:37:37 --> Config Class Initialized
INFO - 2020-03-23 05:37:37 --> Loader Class Initialized
INFO - 2020-03-23 05:37:37 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:37 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:37 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:37 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:37 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:37 --> Controller Class Initialized
INFO - 2020-03-23 05:37:37 --> Final output sent to browser
DEBUG - 2020-03-23 05:37:37 --> Total execution time: 0.7344
INFO - 2020-03-23 05:37:37 --> Config Class Initialized
INFO - 2020-03-23 05:37:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:38 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:38 --> URI Class Initialized
INFO - 2020-03-23 05:37:38 --> Router Class Initialized
INFO - 2020-03-23 05:37:38 --> Output Class Initialized
INFO - 2020-03-23 05:37:38 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:38 --> Input Class Initialized
INFO - 2020-03-23 05:37:38 --> Language Class Initialized
INFO - 2020-03-23 05:37:38 --> Language Class Initialized
INFO - 2020-03-23 05:37:38 --> Config Class Initialized
INFO - 2020-03-23 05:37:38 --> Loader Class Initialized
INFO - 2020-03-23 05:37:38 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:38 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:38 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:38 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:38 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:38 --> Controller Class Initialized
INFO - 2020-03-23 05:37:44 --> Config Class Initialized
INFO - 2020-03-23 05:37:44 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:44 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:44 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:44 --> URI Class Initialized
INFO - 2020-03-23 05:37:44 --> Router Class Initialized
INFO - 2020-03-23 05:37:44 --> Output Class Initialized
INFO - 2020-03-23 05:37:44 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:44 --> Input Class Initialized
INFO - 2020-03-23 05:37:45 --> Language Class Initialized
INFO - 2020-03-23 05:37:45 --> Language Class Initialized
INFO - 2020-03-23 05:37:45 --> Config Class Initialized
INFO - 2020-03-23 05:37:45 --> Loader Class Initialized
INFO - 2020-03-23 05:37:45 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:45 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:45 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:45 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:45 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:45 --> Controller Class Initialized
INFO - 2020-03-23 05:37:45 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:37:45 --> Config Class Initialized
INFO - 2020-03-23 05:37:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:45 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:45 --> URI Class Initialized
INFO - 2020-03-23 05:37:45 --> Router Class Initialized
INFO - 2020-03-23 05:37:45 --> Output Class Initialized
INFO - 2020-03-23 05:37:45 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:45 --> Input Class Initialized
INFO - 2020-03-23 05:37:45 --> Language Class Initialized
INFO - 2020-03-23 05:37:45 --> Language Class Initialized
INFO - 2020-03-23 05:37:45 --> Config Class Initialized
INFO - 2020-03-23 05:37:45 --> Loader Class Initialized
INFO - 2020-03-23 05:37:45 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:45 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:45 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:45 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:45 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:45 --> Controller Class Initialized
INFO - 2020-03-23 05:37:45 --> Config Class Initialized
INFO - 2020-03-23 05:37:45 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:45 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:45 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:45 --> URI Class Initialized
INFO - 2020-03-23 05:37:46 --> Router Class Initialized
INFO - 2020-03-23 05:37:46 --> Output Class Initialized
INFO - 2020-03-23 05:37:46 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:46 --> Input Class Initialized
INFO - 2020-03-23 05:37:46 --> Language Class Initialized
INFO - 2020-03-23 05:37:46 --> Language Class Initialized
INFO - 2020-03-23 05:37:46 --> Config Class Initialized
INFO - 2020-03-23 05:37:46 --> Loader Class Initialized
INFO - 2020-03-23 05:37:46 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:46 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:46 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:46 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:46 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:46 --> Controller Class Initialized
DEBUG - 2020-03-23 05:37:46 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:37:46 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:37:46 --> Final output sent to browser
DEBUG - 2020-03-23 05:37:46 --> Total execution time: 0.6406
INFO - 2020-03-23 05:37:50 --> Config Class Initialized
INFO - 2020-03-23 05:37:50 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:50 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:50 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:50 --> URI Class Initialized
INFO - 2020-03-23 05:37:50 --> Router Class Initialized
INFO - 2020-03-23 05:37:50 --> Output Class Initialized
INFO - 2020-03-23 05:37:50 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:51 --> Input Class Initialized
INFO - 2020-03-23 05:37:51 --> Language Class Initialized
INFO - 2020-03-23 05:37:51 --> Language Class Initialized
INFO - 2020-03-23 05:37:51 --> Config Class Initialized
INFO - 2020-03-23 05:37:51 --> Loader Class Initialized
INFO - 2020-03-23 05:37:51 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:51 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:51 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:51 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:51 --> Controller Class Initialized
INFO - 2020-03-23 05:37:51 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:37:51 --> Final output sent to browser
DEBUG - 2020-03-23 05:37:51 --> Total execution time: 0.6534
INFO - 2020-03-23 05:37:51 --> Config Class Initialized
INFO - 2020-03-23 05:37:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:37:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:37:51 --> Utf8 Class Initialized
INFO - 2020-03-23 05:37:51 --> URI Class Initialized
INFO - 2020-03-23 05:37:51 --> Router Class Initialized
INFO - 2020-03-23 05:37:51 --> Output Class Initialized
INFO - 2020-03-23 05:37:51 --> Security Class Initialized
DEBUG - 2020-03-23 05:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:37:51 --> Input Class Initialized
INFO - 2020-03-23 05:37:51 --> Language Class Initialized
INFO - 2020-03-23 05:37:51 --> Language Class Initialized
INFO - 2020-03-23 05:37:51 --> Config Class Initialized
INFO - 2020-03-23 05:37:51 --> Loader Class Initialized
INFO - 2020-03-23 05:37:51 --> Helper loaded: url_helper
INFO - 2020-03-23 05:37:51 --> Helper loaded: file_helper
INFO - 2020-03-23 05:37:51 --> Helper loaded: form_helper
INFO - 2020-03-23 05:37:52 --> Helper loaded: my_helper
INFO - 2020-03-23 05:37:52 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:37:52 --> Controller Class Initialized
DEBUG - 2020-03-23 05:37:52 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-23 05:37:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:37:52 --> Final output sent to browser
DEBUG - 2020-03-23 05:37:52 --> Total execution time: 0.7632
INFO - 2020-03-23 05:38:07 --> Config Class Initialized
INFO - 2020-03-23 05:38:07 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:38:07 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:38:07 --> Utf8 Class Initialized
INFO - 2020-03-23 05:38:08 --> URI Class Initialized
INFO - 2020-03-23 05:38:08 --> Router Class Initialized
INFO - 2020-03-23 05:38:08 --> Output Class Initialized
INFO - 2020-03-23 05:38:08 --> Security Class Initialized
DEBUG - 2020-03-23 05:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:38:08 --> Input Class Initialized
INFO - 2020-03-23 05:38:08 --> Language Class Initialized
INFO - 2020-03-23 05:38:08 --> Language Class Initialized
INFO - 2020-03-23 05:38:08 --> Config Class Initialized
INFO - 2020-03-23 05:38:08 --> Loader Class Initialized
INFO - 2020-03-23 05:38:08 --> Helper loaded: url_helper
INFO - 2020-03-23 05:38:08 --> Helper loaded: file_helper
INFO - 2020-03-23 05:38:08 --> Helper loaded: form_helper
INFO - 2020-03-23 05:38:08 --> Helper loaded: my_helper
INFO - 2020-03-23 05:38:08 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:38:08 --> Controller Class Initialized
DEBUG - 2020-03-23 05:38:08 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-03-23 05:38:08 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:38:08 --> Final output sent to browser
DEBUG - 2020-03-23 05:38:08 --> Total execution time: 0.6108
INFO - 2020-03-23 05:38:10 --> Config Class Initialized
INFO - 2020-03-23 05:38:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:38:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:38:10 --> Utf8 Class Initialized
INFO - 2020-03-23 05:38:10 --> URI Class Initialized
INFO - 2020-03-23 05:38:10 --> Router Class Initialized
INFO - 2020-03-23 05:38:10 --> Output Class Initialized
INFO - 2020-03-23 05:38:10 --> Security Class Initialized
DEBUG - 2020-03-23 05:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:38:10 --> Input Class Initialized
INFO - 2020-03-23 05:38:10 --> Language Class Initialized
INFO - 2020-03-23 05:38:10 --> Language Class Initialized
INFO - 2020-03-23 05:38:10 --> Config Class Initialized
INFO - 2020-03-23 05:38:10 --> Loader Class Initialized
INFO - 2020-03-23 05:38:10 --> Helper loaded: url_helper
INFO - 2020-03-23 05:38:10 --> Helper loaded: file_helper
INFO - 2020-03-23 05:38:10 --> Helper loaded: form_helper
INFO - 2020-03-23 05:38:10 --> Helper loaded: my_helper
INFO - 2020-03-23 05:38:10 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:38:10 --> Controller Class Initialized
DEBUG - 2020-03-23 05:38:10 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/list.php
DEBUG - 2020-03-23 05:38:10 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:38:10 --> Final output sent to browser
DEBUG - 2020-03-23 05:38:11 --> Total execution time: 0.7057
INFO - 2020-03-23 05:38:12 --> Config Class Initialized
INFO - 2020-03-23 05:38:12 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:38:12 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:38:12 --> Utf8 Class Initialized
INFO - 2020-03-23 05:38:12 --> URI Class Initialized
DEBUG - 2020-03-23 05:38:12 --> No URI present. Default controller set.
INFO - 2020-03-23 05:38:12 --> Router Class Initialized
INFO - 2020-03-23 05:38:12 --> Output Class Initialized
INFO - 2020-03-23 05:38:12 --> Security Class Initialized
DEBUG - 2020-03-23 05:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:38:12 --> Input Class Initialized
INFO - 2020-03-23 05:38:12 --> Language Class Initialized
INFO - 2020-03-23 05:38:12 --> Language Class Initialized
INFO - 2020-03-23 05:38:12 --> Config Class Initialized
INFO - 2020-03-23 05:38:12 --> Loader Class Initialized
INFO - 2020-03-23 05:38:12 --> Helper loaded: url_helper
INFO - 2020-03-23 05:38:13 --> Helper loaded: file_helper
INFO - 2020-03-23 05:38:13 --> Helper loaded: form_helper
INFO - 2020-03-23 05:38:13 --> Helper loaded: my_helper
INFO - 2020-03-23 05:38:13 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:38:13 --> Controller Class Initialized
DEBUG - 2020-03-23 05:38:13 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-23 05:38:13 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:38:13 --> Final output sent to browser
DEBUG - 2020-03-23 05:38:13 --> Total execution time: 0.5995
INFO - 2020-03-23 05:38:27 --> Config Class Initialized
INFO - 2020-03-23 05:38:27 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:38:27 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:38:27 --> Utf8 Class Initialized
INFO - 2020-03-23 05:38:28 --> URI Class Initialized
INFO - 2020-03-23 05:38:28 --> Router Class Initialized
INFO - 2020-03-23 05:38:28 --> Output Class Initialized
INFO - 2020-03-23 05:38:28 --> Security Class Initialized
DEBUG - 2020-03-23 05:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:38:28 --> Input Class Initialized
INFO - 2020-03-23 05:38:28 --> Language Class Initialized
INFO - 2020-03-23 05:38:28 --> Language Class Initialized
INFO - 2020-03-23 05:38:28 --> Config Class Initialized
INFO - 2020-03-23 05:38:28 --> Loader Class Initialized
INFO - 2020-03-23 05:38:28 --> Helper loaded: url_helper
INFO - 2020-03-23 05:38:28 --> Helper loaded: file_helper
INFO - 2020-03-23 05:38:28 --> Helper loaded: form_helper
INFO - 2020-03-23 05:38:29 --> Helper loaded: my_helper
INFO - 2020-03-23 05:38:29 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:38:29 --> Controller Class Initialized
DEBUG - 2020-03-23 05:38:29 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/list.php
DEBUG - 2020-03-23 05:38:29 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:38:29 --> Final output sent to browser
DEBUG - 2020-03-23 05:38:30 --> Total execution time: 2.0728
INFO - 2020-03-23 05:38:42 --> Config Class Initialized
INFO - 2020-03-23 05:38:42 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:38:42 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:38:42 --> Utf8 Class Initialized
INFO - 2020-03-23 05:38:43 --> URI Class Initialized
INFO - 2020-03-23 05:38:43 --> Router Class Initialized
INFO - 2020-03-23 05:38:43 --> Output Class Initialized
INFO - 2020-03-23 05:38:43 --> Security Class Initialized
DEBUG - 2020-03-23 05:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:38:43 --> Input Class Initialized
INFO - 2020-03-23 05:38:43 --> Language Class Initialized
INFO - 2020-03-23 05:38:43 --> Language Class Initialized
INFO - 2020-03-23 05:38:43 --> Config Class Initialized
INFO - 2020-03-23 05:38:43 --> Loader Class Initialized
INFO - 2020-03-23 05:38:43 --> Helper loaded: url_helper
INFO - 2020-03-23 05:38:43 --> Helper loaded: file_helper
INFO - 2020-03-23 05:38:43 --> Helper loaded: form_helper
INFO - 2020-03-23 05:38:43 --> Helper loaded: my_helper
INFO - 2020-03-23 05:38:43 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:38:44 --> Controller Class Initialized
DEBUG - 2020-03-23 05:38:44 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/cetak_sampul1.php
INFO - 2020-03-23 05:38:44 --> Final output sent to browser
DEBUG - 2020-03-23 05:38:44 --> Total execution time: 2.0493
INFO - 2020-03-23 05:38:47 --> Config Class Initialized
INFO - 2020-03-23 05:38:47 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:38:47 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:38:48 --> Utf8 Class Initialized
INFO - 2020-03-23 05:38:48 --> URI Class Initialized
INFO - 2020-03-23 05:38:48 --> Router Class Initialized
INFO - 2020-03-23 05:38:48 --> Output Class Initialized
INFO - 2020-03-23 05:38:48 --> Security Class Initialized
DEBUG - 2020-03-23 05:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:38:48 --> Input Class Initialized
INFO - 2020-03-23 05:38:48 --> Language Class Initialized
INFO - 2020-03-23 05:38:48 --> Language Class Initialized
INFO - 2020-03-23 05:38:48 --> Config Class Initialized
INFO - 2020-03-23 05:38:48 --> Loader Class Initialized
INFO - 2020-03-23 05:38:48 --> Helper loaded: url_helper
INFO - 2020-03-23 05:38:48 --> Helper loaded: file_helper
INFO - 2020-03-23 05:38:48 --> Helper loaded: form_helper
INFO - 2020-03-23 05:38:48 --> Helper loaded: my_helper
INFO - 2020-03-23 05:38:48 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:38:48 --> Controller Class Initialized
DEBUG - 2020-03-23 05:38:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/lihat_raport/views/cetak_rapot.php
INFO - 2020-03-23 05:38:48 --> Final output sent to browser
DEBUG - 2020-03-23 05:38:49 --> Total execution time: 1.5862
INFO - 2020-03-23 05:39:01 --> Config Class Initialized
INFO - 2020-03-23 05:39:01 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:39:01 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:39:02 --> Utf8 Class Initialized
INFO - 2020-03-23 05:39:02 --> URI Class Initialized
INFO - 2020-03-23 05:39:02 --> Router Class Initialized
INFO - 2020-03-23 05:39:02 --> Output Class Initialized
INFO - 2020-03-23 05:39:02 --> Security Class Initialized
DEBUG - 2020-03-23 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:39:02 --> Input Class Initialized
INFO - 2020-03-23 05:39:02 --> Language Class Initialized
INFO - 2020-03-23 05:39:02 --> Language Class Initialized
INFO - 2020-03-23 05:39:02 --> Config Class Initialized
INFO - 2020-03-23 05:39:02 --> Loader Class Initialized
INFO - 2020-03-23 05:39:02 --> Helper loaded: url_helper
INFO - 2020-03-23 05:39:02 --> Helper loaded: file_helper
INFO - 2020-03-23 05:39:02 --> Helper loaded: form_helper
INFO - 2020-03-23 05:39:02 --> Helper loaded: my_helper
INFO - 2020-03-23 05:39:02 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:39:02 --> Controller Class Initialized
INFO - 2020-03-23 05:39:02 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:39:03 --> Config Class Initialized
INFO - 2020-03-23 05:39:03 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:39:03 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:39:03 --> Utf8 Class Initialized
INFO - 2020-03-23 05:39:03 --> URI Class Initialized
INFO - 2020-03-23 05:39:03 --> Router Class Initialized
INFO - 2020-03-23 05:39:03 --> Output Class Initialized
INFO - 2020-03-23 05:39:03 --> Security Class Initialized
DEBUG - 2020-03-23 05:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:39:03 --> Input Class Initialized
INFO - 2020-03-23 05:39:03 --> Language Class Initialized
INFO - 2020-03-23 05:39:03 --> Language Class Initialized
INFO - 2020-03-23 05:39:03 --> Config Class Initialized
INFO - 2020-03-23 05:39:03 --> Loader Class Initialized
INFO - 2020-03-23 05:39:03 --> Helper loaded: url_helper
INFO - 2020-03-23 05:39:03 --> Helper loaded: file_helper
INFO - 2020-03-23 05:39:03 --> Helper loaded: form_helper
INFO - 2020-03-23 05:39:03 --> Helper loaded: my_helper
INFO - 2020-03-23 05:39:03 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:39:04 --> Controller Class Initialized
INFO - 2020-03-23 05:39:04 --> Config Class Initialized
INFO - 2020-03-23 05:39:04 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:39:04 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:39:04 --> Utf8 Class Initialized
INFO - 2020-03-23 05:39:04 --> URI Class Initialized
INFO - 2020-03-23 05:39:04 --> Router Class Initialized
INFO - 2020-03-23 05:39:04 --> Output Class Initialized
INFO - 2020-03-23 05:39:04 --> Security Class Initialized
DEBUG - 2020-03-23 05:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:39:04 --> Input Class Initialized
INFO - 2020-03-23 05:39:04 --> Language Class Initialized
INFO - 2020-03-23 05:39:04 --> Language Class Initialized
INFO - 2020-03-23 05:39:04 --> Config Class Initialized
INFO - 2020-03-23 05:39:04 --> Loader Class Initialized
INFO - 2020-03-23 05:39:04 --> Helper loaded: url_helper
INFO - 2020-03-23 05:39:04 --> Helper loaded: file_helper
INFO - 2020-03-23 05:39:04 --> Helper loaded: form_helper
INFO - 2020-03-23 05:39:04 --> Helper loaded: my_helper
INFO - 2020-03-23 05:39:04 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:39:04 --> Controller Class Initialized
DEBUG - 2020-03-23 05:39:04 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:39:04 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:39:04 --> Final output sent to browser
DEBUG - 2020-03-23 05:39:05 --> Total execution time: 0.8190
INFO - 2020-03-23 05:47:47 --> Config Class Initialized
INFO - 2020-03-23 05:47:47 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:47:47 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:47:47 --> Utf8 Class Initialized
INFO - 2020-03-23 05:47:47 --> URI Class Initialized
INFO - 2020-03-23 05:47:47 --> Router Class Initialized
INFO - 2020-03-23 05:47:47 --> Output Class Initialized
INFO - 2020-03-23 05:47:47 --> Security Class Initialized
DEBUG - 2020-03-23 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:47:47 --> Input Class Initialized
INFO - 2020-03-23 05:47:47 --> Language Class Initialized
INFO - 2020-03-23 05:47:47 --> Language Class Initialized
INFO - 2020-03-23 05:47:47 --> Config Class Initialized
INFO - 2020-03-23 05:47:47 --> Loader Class Initialized
INFO - 2020-03-23 05:47:47 --> Helper loaded: url_helper
INFO - 2020-03-23 05:47:47 --> Helper loaded: file_helper
INFO - 2020-03-23 05:47:47 --> Helper loaded: form_helper
INFO - 2020-03-23 05:47:47 --> Helper loaded: my_helper
INFO - 2020-03-23 05:47:47 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:47:47 --> Controller Class Initialized
INFO - 2020-03-23 05:47:47 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:47:47 --> Final output sent to browser
DEBUG - 2020-03-23 05:47:47 --> Total execution time: 0.6622
INFO - 2020-03-23 05:47:48 --> Config Class Initialized
INFO - 2020-03-23 05:47:48 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:47:48 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:47:48 --> Utf8 Class Initialized
INFO - 2020-03-23 05:47:48 --> URI Class Initialized
INFO - 2020-03-23 05:47:48 --> Router Class Initialized
INFO - 2020-03-23 05:47:48 --> Output Class Initialized
INFO - 2020-03-23 05:47:48 --> Security Class Initialized
DEBUG - 2020-03-23 05:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:47:48 --> Input Class Initialized
INFO - 2020-03-23 05:47:48 --> Language Class Initialized
INFO - 2020-03-23 05:47:48 --> Language Class Initialized
INFO - 2020-03-23 05:47:48 --> Config Class Initialized
INFO - 2020-03-23 05:47:48 --> Loader Class Initialized
INFO - 2020-03-23 05:47:48 --> Helper loaded: url_helper
INFO - 2020-03-23 05:47:48 --> Helper loaded: file_helper
INFO - 2020-03-23 05:47:48 --> Helper loaded: form_helper
INFO - 2020-03-23 05:47:48 --> Helper loaded: my_helper
INFO - 2020-03-23 05:47:48 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:47:48 --> Controller Class Initialized
DEBUG - 2020-03-23 05:47:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 05:47:48 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:47:48 --> Final output sent to browser
DEBUG - 2020-03-23 05:47:51 --> Total execution time: 0.7386
INFO - 2020-03-23 05:48:08 --> Config Class Initialized
INFO - 2020-03-23 05:48:08 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:08 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:08 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:08 --> URI Class Initialized
INFO - 2020-03-23 05:48:09 --> Router Class Initialized
INFO - 2020-03-23 05:48:09 --> Output Class Initialized
INFO - 2020-03-23 05:48:09 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:09 --> Input Class Initialized
INFO - 2020-03-23 05:48:09 --> Language Class Initialized
INFO - 2020-03-23 05:48:09 --> Language Class Initialized
INFO - 2020-03-23 05:48:09 --> Config Class Initialized
INFO - 2020-03-23 05:48:09 --> Loader Class Initialized
INFO - 2020-03-23 05:48:09 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:09 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:09 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:09 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:09 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:09 --> Controller Class Initialized
DEBUG - 2020-03-23 05:48:09 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 05:48:09 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:48:09 --> Final output sent to browser
DEBUG - 2020-03-23 05:48:09 --> Total execution time: 0.8818
INFO - 2020-03-23 05:48:10 --> Config Class Initialized
INFO - 2020-03-23 05:48:10 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:10 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:10 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:10 --> URI Class Initialized
INFO - 2020-03-23 05:48:10 --> Router Class Initialized
INFO - 2020-03-23 05:48:11 --> Output Class Initialized
INFO - 2020-03-23 05:48:11 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:11 --> Input Class Initialized
INFO - 2020-03-23 05:48:11 --> Language Class Initialized
INFO - 2020-03-23 05:48:11 --> Language Class Initialized
INFO - 2020-03-23 05:48:11 --> Config Class Initialized
INFO - 2020-03-23 05:48:11 --> Loader Class Initialized
INFO - 2020-03-23 05:48:11 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:11 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:11 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:11 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:11 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:11 --> Controller Class Initialized
INFO - 2020-03-23 05:48:23 --> Config Class Initialized
INFO - 2020-03-23 05:48:23 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:23 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:23 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:23 --> URI Class Initialized
INFO - 2020-03-23 05:48:23 --> Router Class Initialized
INFO - 2020-03-23 05:48:23 --> Output Class Initialized
INFO - 2020-03-23 05:48:23 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:23 --> Input Class Initialized
INFO - 2020-03-23 05:48:23 --> Language Class Initialized
INFO - 2020-03-23 05:48:23 --> Language Class Initialized
INFO - 2020-03-23 05:48:23 --> Config Class Initialized
INFO - 2020-03-23 05:48:23 --> Loader Class Initialized
INFO - 2020-03-23 05:48:23 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:24 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:24 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:24 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:24 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:24 --> Controller Class Initialized
INFO - 2020-03-23 05:48:24 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:48:24 --> Config Class Initialized
INFO - 2020-03-23 05:48:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:24 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:24 --> URI Class Initialized
INFO - 2020-03-23 05:48:24 --> Router Class Initialized
INFO - 2020-03-23 05:48:24 --> Output Class Initialized
INFO - 2020-03-23 05:48:24 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:24 --> Input Class Initialized
INFO - 2020-03-23 05:48:24 --> Language Class Initialized
INFO - 2020-03-23 05:48:24 --> Language Class Initialized
INFO - 2020-03-23 05:48:24 --> Config Class Initialized
INFO - 2020-03-23 05:48:24 --> Loader Class Initialized
INFO - 2020-03-23 05:48:24 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:24 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:24 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:24 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:24 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:24 --> Controller Class Initialized
INFO - 2020-03-23 05:48:24 --> Config Class Initialized
INFO - 2020-03-23 05:48:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:24 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:24 --> URI Class Initialized
INFO - 2020-03-23 05:48:24 --> Router Class Initialized
INFO - 2020-03-23 05:48:24 --> Output Class Initialized
INFO - 2020-03-23 05:48:24 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:25 --> Input Class Initialized
INFO - 2020-03-23 05:48:25 --> Language Class Initialized
INFO - 2020-03-23 05:48:25 --> Language Class Initialized
INFO - 2020-03-23 05:48:25 --> Config Class Initialized
INFO - 2020-03-23 05:48:25 --> Loader Class Initialized
INFO - 2020-03-23 05:48:25 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:25 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:25 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:25 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:25 --> Controller Class Initialized
DEBUG - 2020-03-23 05:48:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:48:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:48:25 --> Final output sent to browser
DEBUG - 2020-03-23 05:48:25 --> Total execution time: 0.5835
INFO - 2020-03-23 05:48:29 --> Config Class Initialized
INFO - 2020-03-23 05:48:29 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:29 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:30 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:30 --> URI Class Initialized
INFO - 2020-03-23 05:48:30 --> Router Class Initialized
INFO - 2020-03-23 05:48:30 --> Output Class Initialized
INFO - 2020-03-23 05:48:30 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:30 --> Input Class Initialized
INFO - 2020-03-23 05:48:30 --> Language Class Initialized
INFO - 2020-03-23 05:48:30 --> Language Class Initialized
INFO - 2020-03-23 05:48:30 --> Config Class Initialized
INFO - 2020-03-23 05:48:30 --> Loader Class Initialized
INFO - 2020-03-23 05:48:30 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:30 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:30 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:30 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:30 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:30 --> Controller Class Initialized
INFO - 2020-03-23 05:48:30 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:48:30 --> Final output sent to browser
DEBUG - 2020-03-23 05:48:30 --> Total execution time: 0.6205
INFO - 2020-03-23 05:48:30 --> Config Class Initialized
INFO - 2020-03-23 05:48:30 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:48:30 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:48:30 --> Utf8 Class Initialized
INFO - 2020-03-23 05:48:30 --> URI Class Initialized
INFO - 2020-03-23 05:48:30 --> Router Class Initialized
INFO - 2020-03-23 05:48:30 --> Output Class Initialized
INFO - 2020-03-23 05:48:30 --> Security Class Initialized
DEBUG - 2020-03-23 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:48:30 --> Input Class Initialized
INFO - 2020-03-23 05:48:31 --> Language Class Initialized
INFO - 2020-03-23 05:48:31 --> Language Class Initialized
INFO - 2020-03-23 05:48:31 --> Config Class Initialized
INFO - 2020-03-23 05:48:31 --> Loader Class Initialized
INFO - 2020-03-23 05:48:31 --> Helper loaded: url_helper
INFO - 2020-03-23 05:48:31 --> Helper loaded: file_helper
INFO - 2020-03-23 05:48:31 --> Helper loaded: form_helper
INFO - 2020-03-23 05:48:31 --> Helper loaded: my_helper
INFO - 2020-03-23 05:48:31 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:48:31 --> Controller Class Initialized
DEBUG - 2020-03-23 05:48:31 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-23 05:48:31 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:48:31 --> Final output sent to browser
DEBUG - 2020-03-23 05:48:35 --> Total execution time: 0.8250
INFO - 2020-03-23 05:56:54 --> Config Class Initialized
INFO - 2020-03-23 05:56:54 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:56:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:56:54 --> Utf8 Class Initialized
INFO - 2020-03-23 05:56:54 --> URI Class Initialized
INFO - 2020-03-23 05:56:54 --> Router Class Initialized
INFO - 2020-03-23 05:56:54 --> Output Class Initialized
INFO - 2020-03-23 05:56:54 --> Security Class Initialized
DEBUG - 2020-03-23 05:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:56:54 --> Input Class Initialized
INFO - 2020-03-23 05:56:54 --> Language Class Initialized
INFO - 2020-03-23 05:56:54 --> Language Class Initialized
INFO - 2020-03-23 05:56:54 --> Config Class Initialized
INFO - 2020-03-23 05:56:54 --> Loader Class Initialized
INFO - 2020-03-23 05:56:54 --> Helper loaded: url_helper
INFO - 2020-03-23 05:56:54 --> Helper loaded: file_helper
INFO - 2020-03-23 05:56:54 --> Helper loaded: form_helper
INFO - 2020-03-23 05:56:54 --> Helper loaded: my_helper
INFO - 2020-03-23 05:56:54 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:56:54 --> Controller Class Initialized
INFO - 2020-03-23 05:56:54 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:56:54 --> Config Class Initialized
INFO - 2020-03-23 05:56:54 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:56:54 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:56:54 --> Utf8 Class Initialized
INFO - 2020-03-23 05:56:54 --> URI Class Initialized
INFO - 2020-03-23 05:56:54 --> Router Class Initialized
INFO - 2020-03-23 05:56:55 --> Output Class Initialized
INFO - 2020-03-23 05:56:55 --> Security Class Initialized
DEBUG - 2020-03-23 05:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:56:55 --> Input Class Initialized
INFO - 2020-03-23 05:56:55 --> Language Class Initialized
INFO - 2020-03-23 05:56:55 --> Language Class Initialized
INFO - 2020-03-23 05:56:55 --> Config Class Initialized
INFO - 2020-03-23 05:56:55 --> Loader Class Initialized
INFO - 2020-03-23 05:56:55 --> Helper loaded: url_helper
INFO - 2020-03-23 05:56:55 --> Helper loaded: file_helper
INFO - 2020-03-23 05:56:55 --> Helper loaded: form_helper
INFO - 2020-03-23 05:56:55 --> Helper loaded: my_helper
INFO - 2020-03-23 05:56:55 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:56:55 --> Controller Class Initialized
INFO - 2020-03-23 05:56:55 --> Config Class Initialized
INFO - 2020-03-23 05:56:55 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:56:55 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:56:55 --> Utf8 Class Initialized
INFO - 2020-03-23 05:56:55 --> URI Class Initialized
INFO - 2020-03-23 05:56:55 --> Router Class Initialized
INFO - 2020-03-23 05:56:55 --> Output Class Initialized
INFO - 2020-03-23 05:56:55 --> Security Class Initialized
DEBUG - 2020-03-23 05:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:56:55 --> Input Class Initialized
INFO - 2020-03-23 05:56:55 --> Language Class Initialized
INFO - 2020-03-23 05:56:55 --> Language Class Initialized
INFO - 2020-03-23 05:56:55 --> Config Class Initialized
INFO - 2020-03-23 05:56:55 --> Loader Class Initialized
INFO - 2020-03-23 05:56:55 --> Helper loaded: url_helper
INFO - 2020-03-23 05:56:55 --> Helper loaded: file_helper
INFO - 2020-03-23 05:56:55 --> Helper loaded: form_helper
INFO - 2020-03-23 05:56:55 --> Helper loaded: my_helper
INFO - 2020-03-23 05:56:55 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:56:55 --> Controller Class Initialized
DEBUG - 2020-03-23 05:56:56 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:56:56 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:56:56 --> Final output sent to browser
DEBUG - 2020-03-23 05:56:56 --> Total execution time: 0.6074
INFO - 2020-03-23 05:57:06 --> Config Class Initialized
INFO - 2020-03-23 05:57:06 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:06 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:06 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:06 --> URI Class Initialized
INFO - 2020-03-23 05:57:06 --> Router Class Initialized
INFO - 2020-03-23 05:57:06 --> Output Class Initialized
INFO - 2020-03-23 05:57:06 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:06 --> Input Class Initialized
INFO - 2020-03-23 05:57:07 --> Language Class Initialized
INFO - 2020-03-23 05:57:07 --> Language Class Initialized
INFO - 2020-03-23 05:57:07 --> Config Class Initialized
INFO - 2020-03-23 05:57:07 --> Loader Class Initialized
INFO - 2020-03-23 05:57:07 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:07 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:07 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:07 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:07 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:07 --> Controller Class Initialized
INFO - 2020-03-23 05:57:07 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:57:07 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:07 --> Total execution time: 0.5995
INFO - 2020-03-23 05:57:07 --> Config Class Initialized
INFO - 2020-03-23 05:57:07 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:07 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:07 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:07 --> URI Class Initialized
INFO - 2020-03-23 05:57:07 --> Router Class Initialized
INFO - 2020-03-23 05:57:07 --> Output Class Initialized
INFO - 2020-03-23 05:57:07 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:07 --> Input Class Initialized
INFO - 2020-03-23 05:57:07 --> Language Class Initialized
INFO - 2020-03-23 05:57:07 --> Language Class Initialized
INFO - 2020-03-23 05:57:07 --> Config Class Initialized
INFO - 2020-03-23 05:57:07 --> Loader Class Initialized
INFO - 2020-03-23 05:57:08 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:08 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:08 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:08 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:08 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:08 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:08 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 05:57:08 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:08 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:12 --> Total execution time: 0.8401
INFO - 2020-03-23 05:57:20 --> Config Class Initialized
INFO - 2020-03-23 05:57:20 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:20 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:20 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:20 --> URI Class Initialized
INFO - 2020-03-23 05:57:20 --> Router Class Initialized
INFO - 2020-03-23 05:57:20 --> Output Class Initialized
INFO - 2020-03-23 05:57:20 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:20 --> Input Class Initialized
INFO - 2020-03-23 05:57:20 --> Language Class Initialized
INFO - 2020-03-23 05:57:20 --> Language Class Initialized
INFO - 2020-03-23 05:57:20 --> Config Class Initialized
INFO - 2020-03-23 05:57:20 --> Loader Class Initialized
INFO - 2020-03-23 05:57:20 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:20 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:20 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:20 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:20 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:21 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:21 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-23 05:57:21 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:21 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:21 --> Total execution time: 0.6044
INFO - 2020-03-23 05:57:21 --> Config Class Initialized
INFO - 2020-03-23 05:57:21 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:21 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:21 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:21 --> URI Class Initialized
INFO - 2020-03-23 05:57:21 --> Router Class Initialized
INFO - 2020-03-23 05:57:21 --> Output Class Initialized
INFO - 2020-03-23 05:57:22 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:22 --> Input Class Initialized
INFO - 2020-03-23 05:57:22 --> Language Class Initialized
INFO - 2020-03-23 05:57:22 --> Language Class Initialized
INFO - 2020-03-23 05:57:22 --> Config Class Initialized
INFO - 2020-03-23 05:57:22 --> Loader Class Initialized
INFO - 2020-03-23 05:57:22 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:22 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:22 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:22 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:22 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:22 --> Controller Class Initialized
INFO - 2020-03-23 05:57:24 --> Config Class Initialized
INFO - 2020-03-23 05:57:24 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:24 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:24 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:24 --> URI Class Initialized
INFO - 2020-03-23 05:57:24 --> Router Class Initialized
INFO - 2020-03-23 05:57:25 --> Output Class Initialized
INFO - 2020-03-23 05:57:25 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:25 --> Input Class Initialized
INFO - 2020-03-23 05:57:25 --> Language Class Initialized
INFO - 2020-03-23 05:57:25 --> Language Class Initialized
INFO - 2020-03-23 05:57:25 --> Config Class Initialized
INFO - 2020-03-23 05:57:25 --> Loader Class Initialized
INFO - 2020-03-23 05:57:25 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:25 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:25 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:25 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:25 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:25 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:25 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-03-23 05:57:25 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:25 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:25 --> Total execution time: 0.5863
INFO - 2020-03-23 05:57:25 --> Config Class Initialized
INFO - 2020-03-23 05:57:25 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:25 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:25 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:26 --> URI Class Initialized
INFO - 2020-03-23 05:57:26 --> Router Class Initialized
INFO - 2020-03-23 05:57:26 --> Output Class Initialized
INFO - 2020-03-23 05:57:26 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:26 --> Input Class Initialized
INFO - 2020-03-23 05:57:26 --> Language Class Initialized
INFO - 2020-03-23 05:57:26 --> Language Class Initialized
INFO - 2020-03-23 05:57:26 --> Config Class Initialized
INFO - 2020-03-23 05:57:26 --> Loader Class Initialized
INFO - 2020-03-23 05:57:26 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:26 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:26 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:26 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:26 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:26 --> Controller Class Initialized
INFO - 2020-03-23 05:57:27 --> Config Class Initialized
INFO - 2020-03-23 05:57:27 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:27 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:27 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:27 --> URI Class Initialized
INFO - 2020-03-23 05:57:27 --> Router Class Initialized
INFO - 2020-03-23 05:57:27 --> Output Class Initialized
INFO - 2020-03-23 05:57:27 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:27 --> Input Class Initialized
INFO - 2020-03-23 05:57:27 --> Language Class Initialized
INFO - 2020-03-23 05:57:27 --> Language Class Initialized
INFO - 2020-03-23 05:57:27 --> Config Class Initialized
INFO - 2020-03-23 05:57:27 --> Loader Class Initialized
INFO - 2020-03-23 05:57:27 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:27 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:27 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:27 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:27 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:27 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:27 --> File loaded: D:\xampp\htdocs\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-03-23 05:57:27 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:27 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:27 --> Total execution time: 0.6093
INFO - 2020-03-23 05:57:28 --> Config Class Initialized
INFO - 2020-03-23 05:57:28 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:28 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:28 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:28 --> URI Class Initialized
INFO - 2020-03-23 05:57:28 --> Router Class Initialized
INFO - 2020-03-23 05:57:28 --> Output Class Initialized
INFO - 2020-03-23 05:57:28 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:28 --> Input Class Initialized
INFO - 2020-03-23 05:57:28 --> Language Class Initialized
INFO - 2020-03-23 05:57:28 --> Language Class Initialized
INFO - 2020-03-23 05:57:28 --> Config Class Initialized
INFO - 2020-03-23 05:57:28 --> Loader Class Initialized
INFO - 2020-03-23 05:57:28 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:28 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:28 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:28 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:28 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:28 --> Controller Class Initialized
INFO - 2020-03-23 05:57:31 --> Config Class Initialized
INFO - 2020-03-23 05:57:31 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:31 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:31 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:31 --> URI Class Initialized
INFO - 2020-03-23 05:57:31 --> Router Class Initialized
INFO - 2020-03-23 05:57:31 --> Output Class Initialized
INFO - 2020-03-23 05:57:31 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:31 --> Input Class Initialized
INFO - 2020-03-23 05:57:31 --> Language Class Initialized
INFO - 2020-03-23 05:57:31 --> Language Class Initialized
INFO - 2020-03-23 05:57:31 --> Config Class Initialized
INFO - 2020-03-23 05:57:31 --> Loader Class Initialized
INFO - 2020-03-23 05:57:31 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:31 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:31 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:31 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:31 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:32 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:32 --> File loaded: D:\xampp\htdocs\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-03-23 05:57:32 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:32 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:32 --> Total execution time: 0.5849
INFO - 2020-03-23 05:57:32 --> Config Class Initialized
INFO - 2020-03-23 05:57:32 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:32 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:32 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:32 --> URI Class Initialized
INFO - 2020-03-23 05:57:32 --> Router Class Initialized
INFO - 2020-03-23 05:57:32 --> Output Class Initialized
INFO - 2020-03-23 05:57:32 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:33 --> Input Class Initialized
INFO - 2020-03-23 05:57:33 --> Language Class Initialized
INFO - 2020-03-23 05:57:33 --> Language Class Initialized
INFO - 2020-03-23 05:57:33 --> Config Class Initialized
INFO - 2020-03-23 05:57:33 --> Loader Class Initialized
INFO - 2020-03-23 05:57:33 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:33 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:33 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:33 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:33 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:33 --> Controller Class Initialized
INFO - 2020-03-23 05:57:39 --> Config Class Initialized
INFO - 2020-03-23 05:57:39 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:39 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:39 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:39 --> URI Class Initialized
INFO - 2020-03-23 05:57:39 --> Router Class Initialized
INFO - 2020-03-23 05:57:39 --> Output Class Initialized
INFO - 2020-03-23 05:57:39 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:39 --> Input Class Initialized
INFO - 2020-03-23 05:57:39 --> Language Class Initialized
INFO - 2020-03-23 05:57:39 --> Language Class Initialized
INFO - 2020-03-23 05:57:39 --> Config Class Initialized
INFO - 2020-03-23 05:57:39 --> Loader Class Initialized
INFO - 2020-03-23 05:57:39 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:39 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:39 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:39 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:39 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:39 --> Controller Class Initialized
INFO - 2020-03-23 05:57:39 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:57:39 --> Config Class Initialized
INFO - 2020-03-23 05:57:39 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:39 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:40 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:40 --> URI Class Initialized
INFO - 2020-03-23 05:57:40 --> Router Class Initialized
INFO - 2020-03-23 05:57:40 --> Output Class Initialized
INFO - 2020-03-23 05:57:40 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:40 --> Input Class Initialized
INFO - 2020-03-23 05:57:40 --> Language Class Initialized
INFO - 2020-03-23 05:57:40 --> Language Class Initialized
INFO - 2020-03-23 05:57:40 --> Config Class Initialized
INFO - 2020-03-23 05:57:40 --> Loader Class Initialized
INFO - 2020-03-23 05:57:40 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:40 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:40 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:40 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:40 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:40 --> Controller Class Initialized
INFO - 2020-03-23 05:57:40 --> Config Class Initialized
INFO - 2020-03-23 05:57:40 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:40 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:40 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:40 --> URI Class Initialized
INFO - 2020-03-23 05:57:40 --> Router Class Initialized
INFO - 2020-03-23 05:57:40 --> Output Class Initialized
INFO - 2020-03-23 05:57:40 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:40 --> Input Class Initialized
INFO - 2020-03-23 05:57:40 --> Language Class Initialized
INFO - 2020-03-23 05:57:40 --> Language Class Initialized
INFO - 2020-03-23 05:57:40 --> Config Class Initialized
INFO - 2020-03-23 05:57:40 --> Loader Class Initialized
INFO - 2020-03-23 05:57:40 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:40 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:40 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:40 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:40 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:40 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:41 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:57:41 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:41 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:41 --> Total execution time: 0.5620
INFO - 2020-03-23 05:57:46 --> Config Class Initialized
INFO - 2020-03-23 05:57:47 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:47 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:47 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:47 --> URI Class Initialized
INFO - 2020-03-23 05:57:47 --> Router Class Initialized
INFO - 2020-03-23 05:57:47 --> Output Class Initialized
INFO - 2020-03-23 05:57:47 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:47 --> Input Class Initialized
INFO - 2020-03-23 05:57:47 --> Language Class Initialized
INFO - 2020-03-23 05:57:47 --> Language Class Initialized
INFO - 2020-03-23 05:57:47 --> Config Class Initialized
INFO - 2020-03-23 05:57:47 --> Loader Class Initialized
INFO - 2020-03-23 05:57:47 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:47 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:47 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:47 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:47 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:47 --> Controller Class Initialized
INFO - 2020-03-23 05:57:47 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:57:47 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:47 --> Total execution time: 0.6160
INFO - 2020-03-23 05:57:47 --> Config Class Initialized
INFO - 2020-03-23 05:57:47 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:57:47 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:57:47 --> Utf8 Class Initialized
INFO - 2020-03-23 05:57:47 --> URI Class Initialized
INFO - 2020-03-23 05:57:47 --> Router Class Initialized
INFO - 2020-03-23 05:57:47 --> Output Class Initialized
INFO - 2020-03-23 05:57:47 --> Security Class Initialized
DEBUG - 2020-03-23 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:57:48 --> Input Class Initialized
INFO - 2020-03-23 05:57:48 --> Language Class Initialized
INFO - 2020-03-23 05:57:48 --> Language Class Initialized
INFO - 2020-03-23 05:57:48 --> Config Class Initialized
INFO - 2020-03-23 05:57:48 --> Loader Class Initialized
INFO - 2020-03-23 05:57:48 --> Helper loaded: url_helper
INFO - 2020-03-23 05:57:48 --> Helper loaded: file_helper
INFO - 2020-03-23 05:57:48 --> Helper loaded: form_helper
INFO - 2020-03-23 05:57:48 --> Helper loaded: my_helper
INFO - 2020-03-23 05:57:48 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:57:48 --> Controller Class Initialized
DEBUG - 2020-03-23 05:57:48 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-23 05:57:48 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:57:48 --> Final output sent to browser
DEBUG - 2020-03-23 05:57:51 --> Total execution time: 0.7258
INFO - 2020-03-23 05:59:21 --> Config Class Initialized
INFO - 2020-03-23 05:59:21 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:59:21 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:59:21 --> Utf8 Class Initialized
INFO - 2020-03-23 05:59:21 --> URI Class Initialized
INFO - 2020-03-23 05:59:21 --> Router Class Initialized
INFO - 2020-03-23 05:59:21 --> Output Class Initialized
INFO - 2020-03-23 05:59:21 --> Security Class Initialized
DEBUG - 2020-03-23 05:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:59:21 --> Input Class Initialized
INFO - 2020-03-23 05:59:21 --> Language Class Initialized
INFO - 2020-03-23 05:59:21 --> Language Class Initialized
INFO - 2020-03-23 05:59:21 --> Config Class Initialized
INFO - 2020-03-23 05:59:21 --> Loader Class Initialized
INFO - 2020-03-23 05:59:21 --> Helper loaded: url_helper
INFO - 2020-03-23 05:59:21 --> Helper loaded: file_helper
INFO - 2020-03-23 05:59:21 --> Helper loaded: form_helper
INFO - 2020-03-23 05:59:22 --> Helper loaded: my_helper
INFO - 2020-03-23 05:59:22 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:59:22 --> Controller Class Initialized
INFO - 2020-03-23 05:59:22 --> Helper loaded: cookie_helper
INFO - 2020-03-23 05:59:22 --> Config Class Initialized
INFO - 2020-03-23 05:59:22 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:59:22 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:59:22 --> Utf8 Class Initialized
INFO - 2020-03-23 05:59:22 --> URI Class Initialized
INFO - 2020-03-23 05:59:22 --> Router Class Initialized
INFO - 2020-03-23 05:59:22 --> Output Class Initialized
INFO - 2020-03-23 05:59:22 --> Security Class Initialized
DEBUG - 2020-03-23 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:59:22 --> Input Class Initialized
INFO - 2020-03-23 05:59:22 --> Language Class Initialized
INFO - 2020-03-23 05:59:22 --> Language Class Initialized
INFO - 2020-03-23 05:59:22 --> Config Class Initialized
INFO - 2020-03-23 05:59:22 --> Loader Class Initialized
INFO - 2020-03-23 05:59:22 --> Helper loaded: url_helper
INFO - 2020-03-23 05:59:22 --> Helper loaded: file_helper
INFO - 2020-03-23 05:59:22 --> Helper loaded: form_helper
INFO - 2020-03-23 05:59:22 --> Helper loaded: my_helper
INFO - 2020-03-23 05:59:22 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:59:22 --> Controller Class Initialized
INFO - 2020-03-23 05:59:22 --> Config Class Initialized
INFO - 2020-03-23 05:59:22 --> Hooks Class Initialized
DEBUG - 2020-03-23 05:59:22 --> UTF-8 Support Enabled
INFO - 2020-03-23 05:59:22 --> Utf8 Class Initialized
INFO - 2020-03-23 05:59:22 --> URI Class Initialized
INFO - 2020-03-23 05:59:22 --> Router Class Initialized
INFO - 2020-03-23 05:59:23 --> Output Class Initialized
INFO - 2020-03-23 05:59:23 --> Security Class Initialized
DEBUG - 2020-03-23 05:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 05:59:23 --> Input Class Initialized
INFO - 2020-03-23 05:59:23 --> Language Class Initialized
INFO - 2020-03-23 05:59:23 --> Language Class Initialized
INFO - 2020-03-23 05:59:23 --> Config Class Initialized
INFO - 2020-03-23 05:59:23 --> Loader Class Initialized
INFO - 2020-03-23 05:59:23 --> Helper loaded: url_helper
INFO - 2020-03-23 05:59:23 --> Helper loaded: file_helper
INFO - 2020-03-23 05:59:23 --> Helper loaded: form_helper
INFO - 2020-03-23 05:59:23 --> Helper loaded: my_helper
INFO - 2020-03-23 05:59:23 --> Database Driver Class Initialized
DEBUG - 2020-03-23 05:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 05:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 05:59:23 --> Controller Class Initialized
DEBUG - 2020-03-23 05:59:23 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 05:59:23 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 05:59:23 --> Final output sent to browser
DEBUG - 2020-03-23 05:59:23 --> Total execution time: 0.5755
INFO - 2020-03-23 06:22:36 --> Config Class Initialized
INFO - 2020-03-23 06:22:37 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:22:37 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:22:37 --> Utf8 Class Initialized
INFO - 2020-03-23 06:22:37 --> URI Class Initialized
INFO - 2020-03-23 06:22:37 --> Router Class Initialized
INFO - 2020-03-23 06:22:37 --> Output Class Initialized
INFO - 2020-03-23 06:22:37 --> Security Class Initialized
DEBUG - 2020-03-23 06:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:22:37 --> Input Class Initialized
INFO - 2020-03-23 06:22:37 --> Language Class Initialized
INFO - 2020-03-23 06:22:37 --> Language Class Initialized
INFO - 2020-03-23 06:22:37 --> Config Class Initialized
INFO - 2020-03-23 06:22:37 --> Loader Class Initialized
INFO - 2020-03-23 06:22:37 --> Helper loaded: url_helper
INFO - 2020-03-23 06:22:38 --> Helper loaded: file_helper
INFO - 2020-03-23 06:22:38 --> Helper loaded: form_helper
INFO - 2020-03-23 06:22:38 --> Helper loaded: my_helper
INFO - 2020-03-23 06:22:38 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:22:38 --> Controller Class Initialized
DEBUG - 2020-03-23 06:22:38 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 06:22:38 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 06:22:38 --> Final output sent to browser
DEBUG - 2020-03-23 06:22:40 --> Total execution time: 2.0140
INFO - 2020-03-23 06:23:15 --> Config Class Initialized
INFO - 2020-03-23 06:23:16 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:23:16 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:23:16 --> Utf8 Class Initialized
INFO - 2020-03-23 06:23:16 --> URI Class Initialized
INFO - 2020-03-23 06:23:16 --> Router Class Initialized
INFO - 2020-03-23 06:23:16 --> Output Class Initialized
INFO - 2020-03-23 06:23:16 --> Security Class Initialized
DEBUG - 2020-03-23 06:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:23:16 --> Input Class Initialized
INFO - 2020-03-23 06:23:17 --> Language Class Initialized
INFO - 2020-03-23 06:23:17 --> Language Class Initialized
INFO - 2020-03-23 06:23:17 --> Config Class Initialized
INFO - 2020-03-23 06:23:17 --> Loader Class Initialized
INFO - 2020-03-23 06:23:17 --> Helper loaded: url_helper
INFO - 2020-03-23 06:23:17 --> Helper loaded: file_helper
INFO - 2020-03-23 06:23:17 --> Helper loaded: form_helper
INFO - 2020-03-23 06:23:17 --> Helper loaded: my_helper
INFO - 2020-03-23 06:23:17 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:23:17 --> Controller Class Initialized
DEBUG - 2020-03-23 06:23:17 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 06:23:17 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 06:23:17 --> Final output sent to browser
DEBUG - 2020-03-23 06:23:18 --> Total execution time: 1.6520
INFO - 2020-03-23 06:23:26 --> Config Class Initialized
INFO - 2020-03-23 06:23:26 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:23:26 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:23:26 --> Utf8 Class Initialized
INFO - 2020-03-23 06:23:26 --> URI Class Initialized
INFO - 2020-03-23 06:23:26 --> Router Class Initialized
INFO - 2020-03-23 06:23:26 --> Output Class Initialized
INFO - 2020-03-23 06:23:26 --> Security Class Initialized
DEBUG - 2020-03-23 06:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:23:26 --> Input Class Initialized
INFO - 2020-03-23 06:23:26 --> Language Class Initialized
INFO - 2020-03-23 06:23:26 --> Language Class Initialized
INFO - 2020-03-23 06:23:26 --> Config Class Initialized
INFO - 2020-03-23 06:23:26 --> Loader Class Initialized
INFO - 2020-03-23 06:23:26 --> Helper loaded: url_helper
INFO - 2020-03-23 06:23:26 --> Helper loaded: file_helper
INFO - 2020-03-23 06:23:26 --> Helper loaded: form_helper
INFO - 2020-03-23 06:23:26 --> Helper loaded: my_helper
INFO - 2020-03-23 06:23:26 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:23:26 --> Controller Class Initialized
INFO - 2020-03-23 06:23:26 --> Helper loaded: cookie_helper
INFO - 2020-03-23 06:23:26 --> Final output sent to browser
DEBUG - 2020-03-23 06:23:26 --> Total execution time: 0.6753
INFO - 2020-03-23 06:23:26 --> Config Class Initialized
INFO - 2020-03-23 06:23:27 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:23:27 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:23:27 --> Utf8 Class Initialized
INFO - 2020-03-23 06:23:27 --> URI Class Initialized
INFO - 2020-03-23 06:23:27 --> Router Class Initialized
INFO - 2020-03-23 06:23:27 --> Output Class Initialized
INFO - 2020-03-23 06:23:27 --> Security Class Initialized
DEBUG - 2020-03-23 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:23:27 --> Input Class Initialized
INFO - 2020-03-23 06:23:27 --> Language Class Initialized
INFO - 2020-03-23 06:23:27 --> Language Class Initialized
INFO - 2020-03-23 06:23:28 --> Config Class Initialized
INFO - 2020-03-23 06:23:28 --> Loader Class Initialized
INFO - 2020-03-23 06:23:28 --> Helper loaded: url_helper
INFO - 2020-03-23 06:23:28 --> Helper loaded: file_helper
INFO - 2020-03-23 06:23:28 --> Helper loaded: form_helper
INFO - 2020-03-23 06:23:28 --> Helper loaded: my_helper
INFO - 2020-03-23 06:23:28 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:23:28 --> Controller Class Initialized
DEBUG - 2020-03-23 06:23:28 --> File loaded: D:\xampp\htdocs\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-23 06:23:28 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 06:23:28 --> Final output sent to browser
DEBUG - 2020-03-23 06:23:32 --> Total execution time: 1.7838
INFO - 2020-03-23 06:23:48 --> Config Class Initialized
INFO - 2020-03-23 06:23:48 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:23:48 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:23:49 --> Utf8 Class Initialized
INFO - 2020-03-23 06:23:49 --> URI Class Initialized
INFO - 2020-03-23 06:23:49 --> Router Class Initialized
INFO - 2020-03-23 06:23:49 --> Output Class Initialized
INFO - 2020-03-23 06:23:49 --> Security Class Initialized
DEBUG - 2020-03-23 06:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:23:49 --> Input Class Initialized
INFO - 2020-03-23 06:23:49 --> Language Class Initialized
INFO - 2020-03-23 06:23:49 --> Language Class Initialized
INFO - 2020-03-23 06:23:49 --> Config Class Initialized
INFO - 2020-03-23 06:23:49 --> Loader Class Initialized
INFO - 2020-03-23 06:23:49 --> Helper loaded: url_helper
INFO - 2020-03-23 06:23:49 --> Helper loaded: file_helper
INFO - 2020-03-23 06:23:49 --> Helper loaded: form_helper
INFO - 2020-03-23 06:23:50 --> Helper loaded: my_helper
INFO - 2020-03-23 06:23:50 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:23:50 --> Controller Class Initialized
INFO - 2020-03-23 06:23:50 --> Helper loaded: cookie_helper
INFO - 2020-03-23 06:23:50 --> Config Class Initialized
INFO - 2020-03-23 06:23:50 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:23:50 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:23:50 --> Utf8 Class Initialized
INFO - 2020-03-23 06:23:50 --> URI Class Initialized
INFO - 2020-03-23 06:23:50 --> Router Class Initialized
INFO - 2020-03-23 06:23:50 --> Output Class Initialized
INFO - 2020-03-23 06:23:50 --> Security Class Initialized
DEBUG - 2020-03-23 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:23:50 --> Input Class Initialized
INFO - 2020-03-23 06:23:50 --> Language Class Initialized
INFO - 2020-03-23 06:23:50 --> Language Class Initialized
INFO - 2020-03-23 06:23:50 --> Config Class Initialized
INFO - 2020-03-23 06:23:50 --> Loader Class Initialized
INFO - 2020-03-23 06:23:50 --> Helper loaded: url_helper
INFO - 2020-03-23 06:23:50 --> Helper loaded: file_helper
INFO - 2020-03-23 06:23:50 --> Helper loaded: form_helper
INFO - 2020-03-23 06:23:50 --> Helper loaded: my_helper
INFO - 2020-03-23 06:23:50 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:23:51 --> Controller Class Initialized
INFO - 2020-03-23 06:23:51 --> Config Class Initialized
INFO - 2020-03-23 06:23:51 --> Hooks Class Initialized
DEBUG - 2020-03-23 06:23:51 --> UTF-8 Support Enabled
INFO - 2020-03-23 06:23:51 --> Utf8 Class Initialized
INFO - 2020-03-23 06:23:51 --> URI Class Initialized
INFO - 2020-03-23 06:23:51 --> Router Class Initialized
INFO - 2020-03-23 06:23:51 --> Output Class Initialized
INFO - 2020-03-23 06:23:51 --> Security Class Initialized
DEBUG - 2020-03-23 06:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-23 06:23:51 --> Input Class Initialized
INFO - 2020-03-23 06:23:51 --> Language Class Initialized
INFO - 2020-03-23 06:23:51 --> Language Class Initialized
INFO - 2020-03-23 06:23:51 --> Config Class Initialized
INFO - 2020-03-23 06:23:51 --> Loader Class Initialized
INFO - 2020-03-23 06:23:51 --> Helper loaded: url_helper
INFO - 2020-03-23 06:23:51 --> Helper loaded: file_helper
INFO - 2020-03-23 06:23:51 --> Helper loaded: form_helper
INFO - 2020-03-23 06:23:51 --> Helper loaded: my_helper
INFO - 2020-03-23 06:23:51 --> Database Driver Class Initialized
DEBUG - 2020-03-23 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-23 06:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-23 06:23:51 --> Controller Class Initialized
DEBUG - 2020-03-23 06:23:51 --> File loaded: D:\xampp\htdocs\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-23 06:23:52 --> File loaded: D:\xampp\htdocs\myraport\application\views\template_utama.php
INFO - 2020-03-23 06:23:52 --> Final output sent to browser
DEBUG - 2020-03-23 06:23:52 --> Total execution time: 0.8886
