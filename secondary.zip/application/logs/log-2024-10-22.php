<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-22 00:01:18 --> Config Class Initialized
INFO - 2024-10-22 00:01:18 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:18 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:18 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:18 --> URI Class Initialized
INFO - 2024-10-22 00:01:18 --> Router Class Initialized
INFO - 2024-10-22 00:01:18 --> Output Class Initialized
INFO - 2024-10-22 00:01:18 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:18 --> Input Class Initialized
INFO - 2024-10-22 00:01:18 --> Language Class Initialized
INFO - 2024-10-22 00:01:18 --> Language Class Initialized
INFO - 2024-10-22 00:01:18 --> Config Class Initialized
INFO - 2024-10-22 00:01:18 --> Loader Class Initialized
INFO - 2024-10-22 00:01:18 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:18 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:18 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:18 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:18 --> Database Driver Class Initialized
INFO - 2024-10-22 00:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:01:18 --> Controller Class Initialized
DEBUG - 2024-10-22 00:01:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:01:22 --> Final output sent to browser
DEBUG - 2024-10-22 00:01:22 --> Total execution time: 3.6785
INFO - 2024-10-22 00:01:46 --> Config Class Initialized
INFO - 2024-10-22 00:01:46 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:46 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:46 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:46 --> URI Class Initialized
INFO - 2024-10-22 00:01:46 --> Router Class Initialized
INFO - 2024-10-22 00:01:46 --> Output Class Initialized
INFO - 2024-10-22 00:01:46 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:46 --> Input Class Initialized
INFO - 2024-10-22 00:01:46 --> Language Class Initialized
INFO - 2024-10-22 00:01:46 --> Language Class Initialized
INFO - 2024-10-22 00:01:46 --> Config Class Initialized
INFO - 2024-10-22 00:01:46 --> Loader Class Initialized
INFO - 2024-10-22 00:01:46 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:46 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:46 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:46 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:46 --> Database Driver Class Initialized
INFO - 2024-10-22 00:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:01:46 --> Controller Class Initialized
DEBUG - 2024-10-22 00:01:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-22 00:01:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:01:46 --> Final output sent to browser
DEBUG - 2024-10-22 00:01:46 --> Total execution time: 0.0552
INFO - 2024-10-22 00:01:52 --> Config Class Initialized
INFO - 2024-10-22 00:01:52 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:52 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:52 --> URI Class Initialized
INFO - 2024-10-22 00:01:52 --> Router Class Initialized
INFO - 2024-10-22 00:01:52 --> Output Class Initialized
INFO - 2024-10-22 00:01:52 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:52 --> Input Class Initialized
INFO - 2024-10-22 00:01:52 --> Language Class Initialized
INFO - 2024-10-22 00:01:52 --> Language Class Initialized
INFO - 2024-10-22 00:01:52 --> Config Class Initialized
INFO - 2024-10-22 00:01:52 --> Loader Class Initialized
INFO - 2024-10-22 00:01:52 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:52 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:52 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:52 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:52 --> Database Driver Class Initialized
INFO - 2024-10-22 00:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:01:52 --> Controller Class Initialized
DEBUG - 2024-10-22 00:01:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-22 00:01:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:01:52 --> Final output sent to browser
DEBUG - 2024-10-22 00:01:52 --> Total execution time: 0.3612
INFO - 2024-10-22 00:01:52 --> Config Class Initialized
INFO - 2024-10-22 00:01:52 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:52 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:52 --> URI Class Initialized
INFO - 2024-10-22 00:01:52 --> Router Class Initialized
INFO - 2024-10-22 00:01:52 --> Output Class Initialized
INFO - 2024-10-22 00:01:52 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:52 --> Input Class Initialized
INFO - 2024-10-22 00:01:52 --> Language Class Initialized
ERROR - 2024-10-22 00:01:52 --> 404 Page Not Found: /index
INFO - 2024-10-22 00:01:52 --> Config Class Initialized
INFO - 2024-10-22 00:01:52 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:52 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:52 --> URI Class Initialized
INFO - 2024-10-22 00:01:52 --> Router Class Initialized
INFO - 2024-10-22 00:01:52 --> Output Class Initialized
INFO - 2024-10-22 00:01:52 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:52 --> Input Class Initialized
INFO - 2024-10-22 00:01:52 --> Language Class Initialized
INFO - 2024-10-22 00:01:52 --> Language Class Initialized
INFO - 2024-10-22 00:01:52 --> Config Class Initialized
INFO - 2024-10-22 00:01:52 --> Loader Class Initialized
INFO - 2024-10-22 00:01:52 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:52 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:52 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:52 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:52 --> Database Driver Class Initialized
INFO - 2024-10-22 00:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:01:52 --> Controller Class Initialized
INFO - 2024-10-22 00:01:54 --> Config Class Initialized
INFO - 2024-10-22 00:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:54 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:54 --> URI Class Initialized
INFO - 2024-10-22 00:01:54 --> Router Class Initialized
INFO - 2024-10-22 00:01:54 --> Output Class Initialized
INFO - 2024-10-22 00:01:54 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:54 --> Input Class Initialized
INFO - 2024-10-22 00:01:54 --> Language Class Initialized
INFO - 2024-10-22 00:01:54 --> Language Class Initialized
INFO - 2024-10-22 00:01:54 --> Config Class Initialized
INFO - 2024-10-22 00:01:54 --> Loader Class Initialized
INFO - 2024-10-22 00:01:54 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:54 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:54 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:54 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:54 --> Database Driver Class Initialized
INFO - 2024-10-22 00:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:01:54 --> Controller Class Initialized
INFO - 2024-10-22 00:01:59 --> Config Class Initialized
INFO - 2024-10-22 00:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:59 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:59 --> URI Class Initialized
INFO - 2024-10-22 00:01:59 --> Router Class Initialized
INFO - 2024-10-22 00:01:59 --> Output Class Initialized
INFO - 2024-10-22 00:01:59 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:59 --> Input Class Initialized
INFO - 2024-10-22 00:01:59 --> Language Class Initialized
INFO - 2024-10-22 00:01:59 --> Language Class Initialized
INFO - 2024-10-22 00:01:59 --> Config Class Initialized
INFO - 2024-10-22 00:01:59 --> Loader Class Initialized
INFO - 2024-10-22 00:01:59 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:59 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:59 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:59 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:59 --> Database Driver Class Initialized
INFO - 2024-10-22 00:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:01:59 --> Controller Class Initialized
INFO - 2024-10-22 00:01:59 --> Helper loaded: cookie_helper
INFO - 2024-10-22 00:01:59 --> Config Class Initialized
INFO - 2024-10-22 00:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:01:59 --> Utf8 Class Initialized
INFO - 2024-10-22 00:01:59 --> URI Class Initialized
INFO - 2024-10-22 00:01:59 --> Router Class Initialized
INFO - 2024-10-22 00:01:59 --> Output Class Initialized
INFO - 2024-10-22 00:01:59 --> Security Class Initialized
DEBUG - 2024-10-22 00:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:01:59 --> Input Class Initialized
INFO - 2024-10-22 00:01:59 --> Language Class Initialized
INFO - 2024-10-22 00:01:59 --> Language Class Initialized
INFO - 2024-10-22 00:01:59 --> Config Class Initialized
INFO - 2024-10-22 00:01:59 --> Loader Class Initialized
INFO - 2024-10-22 00:01:59 --> Helper loaded: url_helper
INFO - 2024-10-22 00:01:59 --> Helper loaded: file_helper
INFO - 2024-10-22 00:01:59 --> Helper loaded: form_helper
INFO - 2024-10-22 00:01:59 --> Helper loaded: my_helper
INFO - 2024-10-22 00:01:59 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:00 --> Controller Class Initialized
INFO - 2024-10-22 00:02:00 --> Config Class Initialized
INFO - 2024-10-22 00:02:00 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:00 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:00 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:00 --> URI Class Initialized
INFO - 2024-10-22 00:02:00 --> Router Class Initialized
INFO - 2024-10-22 00:02:00 --> Output Class Initialized
INFO - 2024-10-22 00:02:00 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:00 --> Input Class Initialized
INFO - 2024-10-22 00:02:00 --> Language Class Initialized
INFO - 2024-10-22 00:02:00 --> Language Class Initialized
INFO - 2024-10-22 00:02:00 --> Config Class Initialized
INFO - 2024-10-22 00:02:00 --> Loader Class Initialized
INFO - 2024-10-22 00:02:00 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:00 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:00 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:00 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:00 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:00 --> Controller Class Initialized
DEBUG - 2024-10-22 00:02:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-22 00:02:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:02:00 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:00 --> Total execution time: 0.0351
INFO - 2024-10-22 00:02:09 --> Config Class Initialized
INFO - 2024-10-22 00:02:09 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:09 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:09 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:09 --> URI Class Initialized
INFO - 2024-10-22 00:02:09 --> Router Class Initialized
INFO - 2024-10-22 00:02:09 --> Output Class Initialized
INFO - 2024-10-22 00:02:09 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:09 --> Input Class Initialized
INFO - 2024-10-22 00:02:09 --> Language Class Initialized
INFO - 2024-10-22 00:02:09 --> Language Class Initialized
INFO - 2024-10-22 00:02:09 --> Config Class Initialized
INFO - 2024-10-22 00:02:09 --> Loader Class Initialized
INFO - 2024-10-22 00:02:09 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:09 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:09 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:09 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:09 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:09 --> Controller Class Initialized
INFO - 2024-10-22 00:02:09 --> Helper loaded: cookie_helper
INFO - 2024-10-22 00:02:09 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:09 --> Total execution time: 0.0708
INFO - 2024-10-22 00:02:09 --> Config Class Initialized
INFO - 2024-10-22 00:02:09 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:09 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:09 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:09 --> URI Class Initialized
INFO - 2024-10-22 00:02:09 --> Router Class Initialized
INFO - 2024-10-22 00:02:09 --> Output Class Initialized
INFO - 2024-10-22 00:02:09 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:09 --> Input Class Initialized
INFO - 2024-10-22 00:02:09 --> Language Class Initialized
INFO - 2024-10-22 00:02:09 --> Language Class Initialized
INFO - 2024-10-22 00:02:09 --> Config Class Initialized
INFO - 2024-10-22 00:02:09 --> Loader Class Initialized
INFO - 2024-10-22 00:02:09 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:09 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:09 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:09 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:09 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:09 --> Controller Class Initialized
DEBUG - 2024-10-22 00:02:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-22 00:02:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:02:09 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:09 --> Total execution time: 0.0357
INFO - 2024-10-22 00:02:10 --> Config Class Initialized
INFO - 2024-10-22 00:02:10 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:10 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:10 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:10 --> URI Class Initialized
INFO - 2024-10-22 00:02:10 --> Router Class Initialized
INFO - 2024-10-22 00:02:10 --> Output Class Initialized
INFO - 2024-10-22 00:02:10 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:10 --> Input Class Initialized
INFO - 2024-10-22 00:02:10 --> Language Class Initialized
INFO - 2024-10-22 00:02:10 --> Language Class Initialized
INFO - 2024-10-22 00:02:10 --> Config Class Initialized
INFO - 2024-10-22 00:02:10 --> Loader Class Initialized
INFO - 2024-10-22 00:02:10 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:10 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:10 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:10 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:10 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:10 --> Controller Class Initialized
DEBUG - 2024-10-22 00:02:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-22 00:02:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:02:11 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:11 --> Total execution time: 0.4859
INFO - 2024-10-22 00:02:14 --> Config Class Initialized
INFO - 2024-10-22 00:02:14 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:14 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:14 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:14 --> URI Class Initialized
INFO - 2024-10-22 00:02:14 --> Router Class Initialized
INFO - 2024-10-22 00:02:14 --> Output Class Initialized
INFO - 2024-10-22 00:02:14 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:14 --> Input Class Initialized
INFO - 2024-10-22 00:02:14 --> Language Class Initialized
INFO - 2024-10-22 00:02:14 --> Language Class Initialized
INFO - 2024-10-22 00:02:14 --> Config Class Initialized
INFO - 2024-10-22 00:02:14 --> Loader Class Initialized
INFO - 2024-10-22 00:02:14 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:14 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:14 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:14 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:14 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:14 --> Controller Class Initialized
DEBUG - 2024-10-22 00:02:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:02:15 --> Config Class Initialized
INFO - 2024-10-22 00:02:15 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:15 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:15 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:15 --> URI Class Initialized
INFO - 2024-10-22 00:02:15 --> Router Class Initialized
INFO - 2024-10-22 00:02:15 --> Output Class Initialized
INFO - 2024-10-22 00:02:15 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:15 --> Input Class Initialized
INFO - 2024-10-22 00:02:15 --> Language Class Initialized
INFO - 2024-10-22 00:02:15 --> Language Class Initialized
INFO - 2024-10-22 00:02:15 --> Config Class Initialized
INFO - 2024-10-22 00:02:15 --> Loader Class Initialized
INFO - 2024-10-22 00:02:15 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:15 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:15 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:15 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:15 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:16 --> Config Class Initialized
INFO - 2024-10-22 00:02:16 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:02:16 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:02:16 --> Utf8 Class Initialized
INFO - 2024-10-22 00:02:16 --> URI Class Initialized
INFO - 2024-10-22 00:02:16 --> Router Class Initialized
INFO - 2024-10-22 00:02:16 --> Output Class Initialized
INFO - 2024-10-22 00:02:16 --> Security Class Initialized
DEBUG - 2024-10-22 00:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:02:16 --> Input Class Initialized
INFO - 2024-10-22 00:02:16 --> Language Class Initialized
INFO - 2024-10-22 00:02:16 --> Language Class Initialized
INFO - 2024-10-22 00:02:16 --> Config Class Initialized
INFO - 2024-10-22 00:02:16 --> Loader Class Initialized
INFO - 2024-10-22 00:02:16 --> Helper loaded: url_helper
INFO - 2024-10-22 00:02:16 --> Helper loaded: file_helper
INFO - 2024-10-22 00:02:16 --> Helper loaded: form_helper
INFO - 2024-10-22 00:02:16 --> Helper loaded: my_helper
INFO - 2024-10-22 00:02:16 --> Database Driver Class Initialized
INFO - 2024-10-22 00:02:18 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:18 --> Total execution time: 4.5383
INFO - 2024-10-22 00:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:18 --> Controller Class Initialized
DEBUG - 2024-10-22 00:02:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:02:23 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:23 --> Total execution time: 8.2367
INFO - 2024-10-22 00:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:02:23 --> Controller Class Initialized
DEBUG - 2024-10-22 00:02:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:02:27 --> Final output sent to browser
DEBUG - 2024-10-22 00:02:27 --> Total execution time: 11.0775
INFO - 2024-10-22 00:03:19 --> Config Class Initialized
INFO - 2024-10-22 00:03:19 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:03:19 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:03:19 --> Utf8 Class Initialized
INFO - 2024-10-22 00:03:19 --> URI Class Initialized
INFO - 2024-10-22 00:03:19 --> Router Class Initialized
INFO - 2024-10-22 00:03:19 --> Output Class Initialized
INFO - 2024-10-22 00:03:19 --> Security Class Initialized
DEBUG - 2024-10-22 00:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:03:19 --> Input Class Initialized
INFO - 2024-10-22 00:03:19 --> Language Class Initialized
INFO - 2024-10-22 00:03:19 --> Language Class Initialized
INFO - 2024-10-22 00:03:19 --> Config Class Initialized
INFO - 2024-10-22 00:03:19 --> Loader Class Initialized
INFO - 2024-10-22 00:03:19 --> Helper loaded: url_helper
INFO - 2024-10-22 00:03:19 --> Helper loaded: file_helper
INFO - 2024-10-22 00:03:19 --> Helper loaded: form_helper
INFO - 2024-10-22 00:03:19 --> Helper loaded: my_helper
INFO - 2024-10-22 00:03:19 --> Database Driver Class Initialized
INFO - 2024-10-22 00:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:03:19 --> Controller Class Initialized
DEBUG - 2024-10-22 00:03:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:03:21 --> Config Class Initialized
INFO - 2024-10-22 00:03:21 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:03:21 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:03:21 --> Utf8 Class Initialized
INFO - 2024-10-22 00:03:21 --> URI Class Initialized
INFO - 2024-10-22 00:03:21 --> Router Class Initialized
INFO - 2024-10-22 00:03:21 --> Output Class Initialized
INFO - 2024-10-22 00:03:21 --> Security Class Initialized
DEBUG - 2024-10-22 00:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:03:21 --> Input Class Initialized
INFO - 2024-10-22 00:03:21 --> Language Class Initialized
INFO - 2024-10-22 00:03:21 --> Language Class Initialized
INFO - 2024-10-22 00:03:21 --> Config Class Initialized
INFO - 2024-10-22 00:03:21 --> Loader Class Initialized
INFO - 2024-10-22 00:03:21 --> Helper loaded: url_helper
INFO - 2024-10-22 00:03:21 --> Helper loaded: file_helper
INFO - 2024-10-22 00:03:21 --> Helper loaded: form_helper
INFO - 2024-10-22 00:03:21 --> Helper loaded: my_helper
INFO - 2024-10-22 00:03:21 --> Database Driver Class Initialized
INFO - 2024-10-22 00:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:03:21 --> Controller Class Initialized
DEBUG - 2024-10-22 00:03:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:03:22 --> Config Class Initialized
INFO - 2024-10-22 00:03:22 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:03:22 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:03:22 --> Utf8 Class Initialized
INFO - 2024-10-22 00:03:22 --> URI Class Initialized
INFO - 2024-10-22 00:03:22 --> Router Class Initialized
INFO - 2024-10-22 00:03:22 --> Output Class Initialized
INFO - 2024-10-22 00:03:22 --> Security Class Initialized
DEBUG - 2024-10-22 00:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:03:22 --> Input Class Initialized
INFO - 2024-10-22 00:03:22 --> Language Class Initialized
INFO - 2024-10-22 00:03:22 --> Language Class Initialized
INFO - 2024-10-22 00:03:22 --> Config Class Initialized
INFO - 2024-10-22 00:03:22 --> Loader Class Initialized
INFO - 2024-10-22 00:03:22 --> Helper loaded: url_helper
INFO - 2024-10-22 00:03:22 --> Helper loaded: file_helper
INFO - 2024-10-22 00:03:22 --> Helper loaded: form_helper
INFO - 2024-10-22 00:03:22 --> Helper loaded: my_helper
INFO - 2024-10-22 00:03:22 --> Database Driver Class Initialized
INFO - 2024-10-22 00:03:23 --> Final output sent to browser
DEBUG - 2024-10-22 00:03:23 --> Total execution time: 4.5327
INFO - 2024-10-22 00:03:26 --> Final output sent to browser
DEBUG - 2024-10-22 00:03:26 --> Total execution time: 4.7044
INFO - 2024-10-22 00:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:03:26 --> Controller Class Initialized
DEBUG - 2024-10-22 00:03:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:03:30 --> Final output sent to browser
DEBUG - 2024-10-22 00:03:30 --> Total execution time: 7.8037
INFO - 2024-10-22 00:04:09 --> Config Class Initialized
INFO - 2024-10-22 00:04:09 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:04:09 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:04:09 --> Utf8 Class Initialized
INFO - 2024-10-22 00:04:09 --> URI Class Initialized
INFO - 2024-10-22 00:04:09 --> Router Class Initialized
INFO - 2024-10-22 00:04:09 --> Output Class Initialized
INFO - 2024-10-22 00:04:09 --> Security Class Initialized
DEBUG - 2024-10-22 00:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:04:09 --> Input Class Initialized
INFO - 2024-10-22 00:04:09 --> Language Class Initialized
INFO - 2024-10-22 00:04:09 --> Language Class Initialized
INFO - 2024-10-22 00:04:09 --> Config Class Initialized
INFO - 2024-10-22 00:04:09 --> Loader Class Initialized
INFO - 2024-10-22 00:04:09 --> Helper loaded: url_helper
INFO - 2024-10-22 00:04:09 --> Helper loaded: file_helper
INFO - 2024-10-22 00:04:09 --> Helper loaded: form_helper
INFO - 2024-10-22 00:04:09 --> Helper loaded: my_helper
INFO - 2024-10-22 00:04:09 --> Database Driver Class Initialized
INFO - 2024-10-22 00:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:04:09 --> Controller Class Initialized
DEBUG - 2024-10-22 00:04:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:04:10 --> Config Class Initialized
INFO - 2024-10-22 00:04:10 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:04:10 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:04:10 --> Utf8 Class Initialized
INFO - 2024-10-22 00:04:10 --> URI Class Initialized
INFO - 2024-10-22 00:04:10 --> Router Class Initialized
INFO - 2024-10-22 00:04:10 --> Output Class Initialized
INFO - 2024-10-22 00:04:10 --> Security Class Initialized
DEBUG - 2024-10-22 00:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:04:10 --> Input Class Initialized
INFO - 2024-10-22 00:04:10 --> Language Class Initialized
INFO - 2024-10-22 00:04:10 --> Language Class Initialized
INFO - 2024-10-22 00:04:10 --> Config Class Initialized
INFO - 2024-10-22 00:04:10 --> Loader Class Initialized
INFO - 2024-10-22 00:04:10 --> Helper loaded: url_helper
INFO - 2024-10-22 00:04:10 --> Helper loaded: file_helper
INFO - 2024-10-22 00:04:10 --> Helper loaded: form_helper
INFO - 2024-10-22 00:04:10 --> Helper loaded: my_helper
INFO - 2024-10-22 00:04:10 --> Database Driver Class Initialized
INFO - 2024-10-22 00:04:11 --> Config Class Initialized
INFO - 2024-10-22 00:04:11 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:04:11 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:04:11 --> Utf8 Class Initialized
INFO - 2024-10-22 00:04:11 --> URI Class Initialized
INFO - 2024-10-22 00:04:11 --> Router Class Initialized
INFO - 2024-10-22 00:04:11 --> Output Class Initialized
INFO - 2024-10-22 00:04:11 --> Security Class Initialized
DEBUG - 2024-10-22 00:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:04:11 --> Input Class Initialized
INFO - 2024-10-22 00:04:11 --> Language Class Initialized
INFO - 2024-10-22 00:04:11 --> Language Class Initialized
INFO - 2024-10-22 00:04:11 --> Config Class Initialized
INFO - 2024-10-22 00:04:11 --> Loader Class Initialized
INFO - 2024-10-22 00:04:11 --> Helper loaded: url_helper
INFO - 2024-10-22 00:04:11 --> Helper loaded: file_helper
INFO - 2024-10-22 00:04:11 --> Helper loaded: form_helper
INFO - 2024-10-22 00:04:11 --> Helper loaded: my_helper
INFO - 2024-10-22 00:04:11 --> Database Driver Class Initialized
INFO - 2024-10-22 00:04:13 --> Final output sent to browser
DEBUG - 2024-10-22 00:04:13 --> Total execution time: 4.1050
INFO - 2024-10-22 00:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:04:13 --> Controller Class Initialized
DEBUG - 2024-10-22 00:04:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:04:16 --> Final output sent to browser
DEBUG - 2024-10-22 00:04:16 --> Total execution time: 6.3584
INFO - 2024-10-22 00:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:04:16 --> Controller Class Initialized
DEBUG - 2024-10-22 00:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:04:20 --> Final output sent to browser
DEBUG - 2024-10-22 00:04:20 --> Total execution time: 8.9633
INFO - 2024-10-22 00:04:29 --> Config Class Initialized
INFO - 2024-10-22 00:04:29 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:04:29 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:04:29 --> Utf8 Class Initialized
INFO - 2024-10-22 00:04:29 --> URI Class Initialized
INFO - 2024-10-22 00:04:29 --> Router Class Initialized
INFO - 2024-10-22 00:04:29 --> Output Class Initialized
INFO - 2024-10-22 00:04:29 --> Security Class Initialized
DEBUG - 2024-10-22 00:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:04:29 --> Input Class Initialized
INFO - 2024-10-22 00:04:29 --> Language Class Initialized
INFO - 2024-10-22 00:04:29 --> Language Class Initialized
INFO - 2024-10-22 00:04:29 --> Config Class Initialized
INFO - 2024-10-22 00:04:29 --> Loader Class Initialized
INFO - 2024-10-22 00:04:29 --> Helper loaded: url_helper
INFO - 2024-10-22 00:04:29 --> Helper loaded: file_helper
INFO - 2024-10-22 00:04:29 --> Helper loaded: form_helper
INFO - 2024-10-22 00:04:29 --> Helper loaded: my_helper
INFO - 2024-10-22 00:04:29 --> Database Driver Class Initialized
INFO - 2024-10-22 00:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:04:29 --> Controller Class Initialized
DEBUG - 2024-10-22 00:04:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:04:32 --> Final output sent to browser
DEBUG - 2024-10-22 00:04:32 --> Total execution time: 3.1315
INFO - 2024-10-22 00:05:49 --> Config Class Initialized
INFO - 2024-10-22 00:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:05:49 --> Utf8 Class Initialized
INFO - 2024-10-22 00:05:49 --> URI Class Initialized
INFO - 2024-10-22 00:05:49 --> Router Class Initialized
INFO - 2024-10-22 00:05:49 --> Output Class Initialized
INFO - 2024-10-22 00:05:49 --> Security Class Initialized
DEBUG - 2024-10-22 00:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:05:49 --> Input Class Initialized
INFO - 2024-10-22 00:05:49 --> Language Class Initialized
INFO - 2024-10-22 00:05:49 --> Language Class Initialized
INFO - 2024-10-22 00:05:49 --> Config Class Initialized
INFO - 2024-10-22 00:05:49 --> Loader Class Initialized
INFO - 2024-10-22 00:05:49 --> Helper loaded: url_helper
INFO - 2024-10-22 00:05:49 --> Helper loaded: file_helper
INFO - 2024-10-22 00:05:49 --> Helper loaded: form_helper
INFO - 2024-10-22 00:05:49 --> Helper loaded: my_helper
INFO - 2024-10-22 00:05:49 --> Database Driver Class Initialized
INFO - 2024-10-22 00:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:05:49 --> Controller Class Initialized
DEBUG - 2024-10-22 00:05:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:05:51 --> Config Class Initialized
INFO - 2024-10-22 00:05:51 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:05:51 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:05:51 --> Utf8 Class Initialized
INFO - 2024-10-22 00:05:51 --> URI Class Initialized
INFO - 2024-10-22 00:05:51 --> Router Class Initialized
INFO - 2024-10-22 00:05:51 --> Output Class Initialized
INFO - 2024-10-22 00:05:51 --> Security Class Initialized
DEBUG - 2024-10-22 00:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:05:51 --> Input Class Initialized
INFO - 2024-10-22 00:05:51 --> Language Class Initialized
INFO - 2024-10-22 00:05:51 --> Language Class Initialized
INFO - 2024-10-22 00:05:51 --> Config Class Initialized
INFO - 2024-10-22 00:05:51 --> Loader Class Initialized
INFO - 2024-10-22 00:05:51 --> Helper loaded: url_helper
INFO - 2024-10-22 00:05:51 --> Helper loaded: file_helper
INFO - 2024-10-22 00:05:51 --> Helper loaded: form_helper
INFO - 2024-10-22 00:05:51 --> Helper loaded: my_helper
INFO - 2024-10-22 00:05:51 --> Database Driver Class Initialized
INFO - 2024-10-22 00:05:52 --> Final output sent to browser
DEBUG - 2024-10-22 00:05:52 --> Total execution time: 3.5549
INFO - 2024-10-22 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:05:52 --> Controller Class Initialized
DEBUG - 2024-10-22 00:05:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:05:53 --> Config Class Initialized
INFO - 2024-10-22 00:05:53 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:05:53 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:05:53 --> Utf8 Class Initialized
INFO - 2024-10-22 00:05:53 --> URI Class Initialized
INFO - 2024-10-22 00:05:53 --> Router Class Initialized
INFO - 2024-10-22 00:05:53 --> Output Class Initialized
INFO - 2024-10-22 00:05:53 --> Security Class Initialized
DEBUG - 2024-10-22 00:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:05:53 --> Input Class Initialized
INFO - 2024-10-22 00:05:53 --> Language Class Initialized
INFO - 2024-10-22 00:05:53 --> Language Class Initialized
INFO - 2024-10-22 00:05:53 --> Config Class Initialized
INFO - 2024-10-22 00:05:53 --> Loader Class Initialized
INFO - 2024-10-22 00:05:53 --> Helper loaded: url_helper
INFO - 2024-10-22 00:05:53 --> Helper loaded: file_helper
INFO - 2024-10-22 00:05:53 --> Helper loaded: form_helper
INFO - 2024-10-22 00:05:53 --> Helper loaded: my_helper
INFO - 2024-10-22 00:05:53 --> Database Driver Class Initialized
INFO - 2024-10-22 00:05:55 --> Final output sent to browser
DEBUG - 2024-10-22 00:05:55 --> Total execution time: 4.5319
INFO - 2024-10-22 00:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:05:55 --> Controller Class Initialized
DEBUG - 2024-10-22 00:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:05:58 --> Final output sent to browser
DEBUG - 2024-10-22 00:05:58 --> Total execution time: 5.0173
INFO - 2024-10-22 00:06:29 --> Config Class Initialized
INFO - 2024-10-22 00:06:29 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:29 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:29 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:29 --> URI Class Initialized
INFO - 2024-10-22 00:06:29 --> Router Class Initialized
INFO - 2024-10-22 00:06:29 --> Output Class Initialized
INFO - 2024-10-22 00:06:29 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:29 --> Input Class Initialized
INFO - 2024-10-22 00:06:29 --> Language Class Initialized
INFO - 2024-10-22 00:06:29 --> Language Class Initialized
INFO - 2024-10-22 00:06:29 --> Config Class Initialized
INFO - 2024-10-22 00:06:29 --> Loader Class Initialized
INFO - 2024-10-22 00:06:29 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:29 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:29 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:29 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:29 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:29 --> Controller Class Initialized
INFO - 2024-10-22 00:06:30 --> Config Class Initialized
INFO - 2024-10-22 00:06:30 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:30 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:30 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:30 --> URI Class Initialized
INFO - 2024-10-22 00:06:30 --> Router Class Initialized
INFO - 2024-10-22 00:06:30 --> Output Class Initialized
INFO - 2024-10-22 00:06:30 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:30 --> Input Class Initialized
INFO - 2024-10-22 00:06:30 --> Language Class Initialized
INFO - 2024-10-22 00:06:30 --> Language Class Initialized
INFO - 2024-10-22 00:06:30 --> Config Class Initialized
INFO - 2024-10-22 00:06:30 --> Loader Class Initialized
INFO - 2024-10-22 00:06:30 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:30 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:30 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:30 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:30 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:30 --> Controller Class Initialized
INFO - 2024-10-22 00:06:30 --> Config Class Initialized
INFO - 2024-10-22 00:06:30 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:30 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:30 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:30 --> URI Class Initialized
INFO - 2024-10-22 00:06:30 --> Router Class Initialized
INFO - 2024-10-22 00:06:30 --> Output Class Initialized
INFO - 2024-10-22 00:06:30 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:30 --> Input Class Initialized
INFO - 2024-10-22 00:06:30 --> Language Class Initialized
INFO - 2024-10-22 00:06:30 --> Language Class Initialized
INFO - 2024-10-22 00:06:30 --> Config Class Initialized
INFO - 2024-10-22 00:06:30 --> Loader Class Initialized
INFO - 2024-10-22 00:06:30 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:30 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:30 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:30 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:30 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:30 --> Controller Class Initialized
INFO - 2024-10-22 00:06:31 --> Config Class Initialized
INFO - 2024-10-22 00:06:31 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:31 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:31 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:31 --> URI Class Initialized
INFO - 2024-10-22 00:06:31 --> Router Class Initialized
INFO - 2024-10-22 00:06:31 --> Output Class Initialized
INFO - 2024-10-22 00:06:31 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:31 --> Input Class Initialized
INFO - 2024-10-22 00:06:31 --> Language Class Initialized
INFO - 2024-10-22 00:06:31 --> Language Class Initialized
INFO - 2024-10-22 00:06:31 --> Config Class Initialized
INFO - 2024-10-22 00:06:31 --> Loader Class Initialized
INFO - 2024-10-22 00:06:31 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:31 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:31 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:31 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:31 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:31 --> Controller Class Initialized
INFO - 2024-10-22 00:06:31 --> Config Class Initialized
INFO - 2024-10-22 00:06:31 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:31 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:31 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:31 --> URI Class Initialized
INFO - 2024-10-22 00:06:31 --> Router Class Initialized
INFO - 2024-10-22 00:06:31 --> Output Class Initialized
INFO - 2024-10-22 00:06:31 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:31 --> Input Class Initialized
INFO - 2024-10-22 00:06:31 --> Language Class Initialized
INFO - 2024-10-22 00:06:31 --> Language Class Initialized
INFO - 2024-10-22 00:06:31 --> Config Class Initialized
INFO - 2024-10-22 00:06:31 --> Loader Class Initialized
INFO - 2024-10-22 00:06:31 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:31 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:31 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:31 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:31 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:31 --> Controller Class Initialized
INFO - 2024-10-22 00:06:32 --> Config Class Initialized
INFO - 2024-10-22 00:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:32 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:32 --> URI Class Initialized
INFO - 2024-10-22 00:06:32 --> Router Class Initialized
INFO - 2024-10-22 00:06:32 --> Output Class Initialized
INFO - 2024-10-22 00:06:32 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:32 --> Input Class Initialized
INFO - 2024-10-22 00:06:32 --> Language Class Initialized
INFO - 2024-10-22 00:06:32 --> Language Class Initialized
INFO - 2024-10-22 00:06:32 --> Config Class Initialized
INFO - 2024-10-22 00:06:32 --> Loader Class Initialized
INFO - 2024-10-22 00:06:32 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:32 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:32 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:32 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:32 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:32 --> Controller Class Initialized
INFO - 2024-10-22 00:06:44 --> Config Class Initialized
INFO - 2024-10-22 00:06:44 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:44 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:44 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:44 --> URI Class Initialized
INFO - 2024-10-22 00:06:44 --> Router Class Initialized
INFO - 2024-10-22 00:06:44 --> Output Class Initialized
INFO - 2024-10-22 00:06:44 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:44 --> Input Class Initialized
INFO - 2024-10-22 00:06:44 --> Language Class Initialized
INFO - 2024-10-22 00:06:44 --> Language Class Initialized
INFO - 2024-10-22 00:06:44 --> Config Class Initialized
INFO - 2024-10-22 00:06:44 --> Loader Class Initialized
INFO - 2024-10-22 00:06:44 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:44 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:44 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:44 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:44 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:44 --> Controller Class Initialized
INFO - 2024-10-22 00:06:44 --> Helper loaded: cookie_helper
INFO - 2024-10-22 00:06:44 --> Config Class Initialized
INFO - 2024-10-22 00:06:44 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:44 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:44 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:44 --> URI Class Initialized
INFO - 2024-10-22 00:06:44 --> Router Class Initialized
INFO - 2024-10-22 00:06:44 --> Output Class Initialized
INFO - 2024-10-22 00:06:44 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:44 --> Input Class Initialized
INFO - 2024-10-22 00:06:44 --> Language Class Initialized
INFO - 2024-10-22 00:06:44 --> Language Class Initialized
INFO - 2024-10-22 00:06:44 --> Config Class Initialized
INFO - 2024-10-22 00:06:44 --> Loader Class Initialized
INFO - 2024-10-22 00:06:44 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:44 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:44 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:44 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:44 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:44 --> Controller Class Initialized
INFO - 2024-10-22 00:06:45 --> Config Class Initialized
INFO - 2024-10-22 00:06:45 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:45 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:45 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:45 --> URI Class Initialized
INFO - 2024-10-22 00:06:45 --> Router Class Initialized
INFO - 2024-10-22 00:06:45 --> Output Class Initialized
INFO - 2024-10-22 00:06:45 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:45 --> Input Class Initialized
INFO - 2024-10-22 00:06:45 --> Language Class Initialized
INFO - 2024-10-22 00:06:45 --> Language Class Initialized
INFO - 2024-10-22 00:06:45 --> Config Class Initialized
INFO - 2024-10-22 00:06:45 --> Loader Class Initialized
INFO - 2024-10-22 00:06:45 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:45 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:45 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:45 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:45 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:45 --> Controller Class Initialized
DEBUG - 2024-10-22 00:06:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-22 00:06:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:06:45 --> Final output sent to browser
DEBUG - 2024-10-22 00:06:45 --> Total execution time: 0.0269
INFO - 2024-10-22 00:06:49 --> Config Class Initialized
INFO - 2024-10-22 00:06:49 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:49 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:49 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:49 --> URI Class Initialized
INFO - 2024-10-22 00:06:49 --> Router Class Initialized
INFO - 2024-10-22 00:06:49 --> Output Class Initialized
INFO - 2024-10-22 00:06:49 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:49 --> Input Class Initialized
INFO - 2024-10-22 00:06:49 --> Language Class Initialized
INFO - 2024-10-22 00:06:49 --> Language Class Initialized
INFO - 2024-10-22 00:06:49 --> Config Class Initialized
INFO - 2024-10-22 00:06:49 --> Loader Class Initialized
INFO - 2024-10-22 00:06:49 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:49 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:49 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:49 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:49 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:49 --> Controller Class Initialized
INFO - 2024-10-22 00:06:49 --> Helper loaded: cookie_helper
INFO - 2024-10-22 00:06:49 --> Final output sent to browser
DEBUG - 2024-10-22 00:06:49 --> Total execution time: 0.0414
INFO - 2024-10-22 00:06:49 --> Config Class Initialized
INFO - 2024-10-22 00:06:49 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:49 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:49 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:49 --> URI Class Initialized
INFO - 2024-10-22 00:06:49 --> Router Class Initialized
INFO - 2024-10-22 00:06:49 --> Output Class Initialized
INFO - 2024-10-22 00:06:49 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:49 --> Input Class Initialized
INFO - 2024-10-22 00:06:49 --> Language Class Initialized
INFO - 2024-10-22 00:06:49 --> Language Class Initialized
INFO - 2024-10-22 00:06:49 --> Config Class Initialized
INFO - 2024-10-22 00:06:49 --> Loader Class Initialized
INFO - 2024-10-22 00:06:49 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:49 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:49 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:49 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:49 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:49 --> Controller Class Initialized
DEBUG - 2024-10-22 00:06:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-22 00:06:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:06:49 --> Final output sent to browser
DEBUG - 2024-10-22 00:06:49 --> Total execution time: 0.0347
INFO - 2024-10-22 00:06:51 --> Config Class Initialized
INFO - 2024-10-22 00:06:51 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:51 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:51 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:51 --> URI Class Initialized
INFO - 2024-10-22 00:06:51 --> Router Class Initialized
INFO - 2024-10-22 00:06:51 --> Output Class Initialized
INFO - 2024-10-22 00:06:51 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:51 --> Input Class Initialized
INFO - 2024-10-22 00:06:51 --> Language Class Initialized
INFO - 2024-10-22 00:06:51 --> Language Class Initialized
INFO - 2024-10-22 00:06:51 --> Config Class Initialized
INFO - 2024-10-22 00:06:51 --> Loader Class Initialized
INFO - 2024-10-22 00:06:51 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:51 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:51 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:51 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:51 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:51 --> Controller Class Initialized
DEBUG - 2024-10-22 00:06:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-22 00:06:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 00:06:51 --> Final output sent to browser
DEBUG - 2024-10-22 00:06:51 --> Total execution time: 0.0388
INFO - 2024-10-22 00:06:52 --> Config Class Initialized
INFO - 2024-10-22 00:06:52 --> Hooks Class Initialized
DEBUG - 2024-10-22 00:06:52 --> UTF-8 Support Enabled
INFO - 2024-10-22 00:06:52 --> Utf8 Class Initialized
INFO - 2024-10-22 00:06:52 --> URI Class Initialized
INFO - 2024-10-22 00:06:52 --> Router Class Initialized
INFO - 2024-10-22 00:06:52 --> Output Class Initialized
INFO - 2024-10-22 00:06:52 --> Security Class Initialized
DEBUG - 2024-10-22 00:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 00:06:52 --> Input Class Initialized
INFO - 2024-10-22 00:06:52 --> Language Class Initialized
INFO - 2024-10-22 00:06:52 --> Language Class Initialized
INFO - 2024-10-22 00:06:52 --> Config Class Initialized
INFO - 2024-10-22 00:06:52 --> Loader Class Initialized
INFO - 2024-10-22 00:06:52 --> Helper loaded: url_helper
INFO - 2024-10-22 00:06:52 --> Helper loaded: file_helper
INFO - 2024-10-22 00:06:52 --> Helper loaded: form_helper
INFO - 2024-10-22 00:06:52 --> Helper loaded: my_helper
INFO - 2024-10-22 00:06:52 --> Database Driver Class Initialized
INFO - 2024-10-22 00:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 00:06:52 --> Controller Class Initialized
DEBUG - 2024-10-22 00:06:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 00:06:55 --> Final output sent to browser
DEBUG - 2024-10-22 00:06:55 --> Total execution time: 2.9617
INFO - 2024-10-22 06:05:44 --> Config Class Initialized
INFO - 2024-10-22 06:05:44 --> Hooks Class Initialized
DEBUG - 2024-10-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2024-10-22 06:05:44 --> Utf8 Class Initialized
INFO - 2024-10-22 06:05:44 --> URI Class Initialized
INFO - 2024-10-22 06:05:44 --> Router Class Initialized
INFO - 2024-10-22 06:05:44 --> Output Class Initialized
INFO - 2024-10-22 06:05:44 --> Security Class Initialized
DEBUG - 2024-10-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 06:05:44 --> Input Class Initialized
INFO - 2024-10-22 06:05:44 --> Language Class Initialized
INFO - 2024-10-22 06:05:44 --> Language Class Initialized
INFO - 2024-10-22 06:05:44 --> Config Class Initialized
INFO - 2024-10-22 06:05:44 --> Loader Class Initialized
INFO - 2024-10-22 06:05:44 --> Helper loaded: url_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: file_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: form_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: my_helper
INFO - 2024-10-22 06:05:44 --> Database Driver Class Initialized
INFO - 2024-10-22 06:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 06:05:44 --> Controller Class Initialized
INFO - 2024-10-22 06:05:44 --> Helper loaded: cookie_helper
INFO - 2024-10-22 06:05:44 --> Final output sent to browser
DEBUG - 2024-10-22 06:05:44 --> Total execution time: 0.0785
INFO - 2024-10-22 06:05:44 --> Config Class Initialized
INFO - 2024-10-22 06:05:44 --> Hooks Class Initialized
DEBUG - 2024-10-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2024-10-22 06:05:44 --> Utf8 Class Initialized
INFO - 2024-10-22 06:05:44 --> URI Class Initialized
INFO - 2024-10-22 06:05:44 --> Router Class Initialized
INFO - 2024-10-22 06:05:44 --> Output Class Initialized
INFO - 2024-10-22 06:05:44 --> Security Class Initialized
DEBUG - 2024-10-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 06:05:44 --> Input Class Initialized
INFO - 2024-10-22 06:05:44 --> Language Class Initialized
INFO - 2024-10-22 06:05:44 --> Language Class Initialized
INFO - 2024-10-22 06:05:44 --> Config Class Initialized
INFO - 2024-10-22 06:05:44 --> Loader Class Initialized
INFO - 2024-10-22 06:05:44 --> Helper loaded: url_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: file_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: form_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: my_helper
INFO - 2024-10-22 06:05:44 --> Database Driver Class Initialized
INFO - 2024-10-22 06:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 06:05:44 --> Controller Class Initialized
INFO - 2024-10-22 06:05:44 --> Helper loaded: cookie_helper
INFO - 2024-10-22 06:05:44 --> Config Class Initialized
INFO - 2024-10-22 06:05:44 --> Hooks Class Initialized
DEBUG - 2024-10-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2024-10-22 06:05:44 --> Utf8 Class Initialized
INFO - 2024-10-22 06:05:44 --> URI Class Initialized
INFO - 2024-10-22 06:05:44 --> Router Class Initialized
INFO - 2024-10-22 06:05:44 --> Output Class Initialized
INFO - 2024-10-22 06:05:44 --> Security Class Initialized
DEBUG - 2024-10-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 06:05:44 --> Input Class Initialized
INFO - 2024-10-22 06:05:44 --> Language Class Initialized
INFO - 2024-10-22 06:05:44 --> Language Class Initialized
INFO - 2024-10-22 06:05:44 --> Config Class Initialized
INFO - 2024-10-22 06:05:44 --> Loader Class Initialized
INFO - 2024-10-22 06:05:44 --> Helper loaded: url_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: file_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: form_helper
INFO - 2024-10-22 06:05:44 --> Helper loaded: my_helper
INFO - 2024-10-22 06:05:44 --> Database Driver Class Initialized
INFO - 2024-10-22 06:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 06:05:44 --> Controller Class Initialized
ERROR - 2024-10-22 06:05:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT a.id_siswa,a.id_kelas,b.tingkat,a.ta FROM t_kelas_siswa a
                                                    INNER JOIN m_kelas b ON b.id = a.id_kelas
                                                    WHERE a.id_siswa = 
INFO - 2024-10-22 06:05:44 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-22 08:22:28 --> Config Class Initialized
INFO - 2024-10-22 08:22:28 --> Hooks Class Initialized
DEBUG - 2024-10-22 08:22:28 --> UTF-8 Support Enabled
INFO - 2024-10-22 08:22:28 --> Utf8 Class Initialized
INFO - 2024-10-22 08:22:28 --> URI Class Initialized
INFO - 2024-10-22 08:22:28 --> Router Class Initialized
INFO - 2024-10-22 08:22:28 --> Output Class Initialized
INFO - 2024-10-22 08:22:28 --> Security Class Initialized
DEBUG - 2024-10-22 08:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 08:22:28 --> Input Class Initialized
INFO - 2024-10-22 08:22:28 --> Language Class Initialized
INFO - 2024-10-22 08:22:28 --> Language Class Initialized
INFO - 2024-10-22 08:22:28 --> Config Class Initialized
INFO - 2024-10-22 08:22:28 --> Loader Class Initialized
INFO - 2024-10-22 08:22:28 --> Helper loaded: url_helper
INFO - 2024-10-22 08:22:28 --> Helper loaded: file_helper
INFO - 2024-10-22 08:22:28 --> Helper loaded: form_helper
INFO - 2024-10-22 08:22:28 --> Helper loaded: my_helper
INFO - 2024-10-22 08:22:28 --> Database Driver Class Initialized
INFO - 2024-10-22 08:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 08:22:28 --> Controller Class Initialized
INFO - 2024-10-22 08:22:28 --> Helper loaded: cookie_helper
INFO - 2024-10-22 08:22:28 --> Final output sent to browser
DEBUG - 2024-10-22 08:22:28 --> Total execution time: 0.0745
INFO - 2024-10-22 08:22:29 --> Config Class Initialized
INFO - 2024-10-22 08:22:29 --> Hooks Class Initialized
DEBUG - 2024-10-22 08:22:29 --> UTF-8 Support Enabled
INFO - 2024-10-22 08:22:29 --> Utf8 Class Initialized
INFO - 2024-10-22 08:22:29 --> URI Class Initialized
INFO - 2024-10-22 08:22:29 --> Router Class Initialized
INFO - 2024-10-22 08:22:29 --> Output Class Initialized
INFO - 2024-10-22 08:22:29 --> Security Class Initialized
DEBUG - 2024-10-22 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 08:22:29 --> Input Class Initialized
INFO - 2024-10-22 08:22:29 --> Language Class Initialized
INFO - 2024-10-22 08:22:29 --> Language Class Initialized
INFO - 2024-10-22 08:22:29 --> Config Class Initialized
INFO - 2024-10-22 08:22:29 --> Loader Class Initialized
INFO - 2024-10-22 08:22:29 --> Helper loaded: url_helper
INFO - 2024-10-22 08:22:29 --> Helper loaded: file_helper
INFO - 2024-10-22 08:22:29 --> Helper loaded: form_helper
INFO - 2024-10-22 08:22:29 --> Helper loaded: my_helper
INFO - 2024-10-22 08:22:29 --> Database Driver Class Initialized
INFO - 2024-10-22 08:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 08:22:29 --> Controller Class Initialized
INFO - 2024-10-22 08:22:29 --> Helper loaded: cookie_helper
INFO - 2024-10-22 08:22:29 --> Config Class Initialized
INFO - 2024-10-22 08:22:29 --> Hooks Class Initialized
DEBUG - 2024-10-22 08:22:29 --> UTF-8 Support Enabled
INFO - 2024-10-22 08:22:29 --> Utf8 Class Initialized
INFO - 2024-10-22 08:22:29 --> URI Class Initialized
INFO - 2024-10-22 08:22:29 --> Router Class Initialized
INFO - 2024-10-22 08:22:29 --> Output Class Initialized
INFO - 2024-10-22 08:22:29 --> Security Class Initialized
DEBUG - 2024-10-22 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 08:22:29 --> Input Class Initialized
INFO - 2024-10-22 08:22:29 --> Language Class Initialized
INFO - 2024-10-22 08:22:29 --> Language Class Initialized
INFO - 2024-10-22 08:22:29 --> Config Class Initialized
INFO - 2024-10-22 08:22:29 --> Loader Class Initialized
INFO - 2024-10-22 08:22:29 --> Helper loaded: url_helper
INFO - 2024-10-22 08:22:29 --> Helper loaded: file_helper
INFO - 2024-10-22 08:22:29 --> Helper loaded: form_helper
INFO - 2024-10-22 08:22:29 --> Helper loaded: my_helper
INFO - 2024-10-22 08:22:29 --> Database Driver Class Initialized
INFO - 2024-10-22 08:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 08:22:29 --> Controller Class Initialized
ERROR - 2024-10-22 08:22:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT a.id_siswa,a.id_kelas,b.tingkat,a.ta FROM t_kelas_siswa a
                                                    INNER JOIN m_kelas b ON b.id = a.id_kelas
                                                    WHERE a.id_siswa = 
INFO - 2024-10-22 08:22:29 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-22 10:54:30 --> Config Class Initialized
INFO - 2024-10-22 10:54:30 --> Hooks Class Initialized
DEBUG - 2024-10-22 10:54:30 --> UTF-8 Support Enabled
INFO - 2024-10-22 10:54:30 --> Utf8 Class Initialized
INFO - 2024-10-22 10:54:30 --> URI Class Initialized
INFO - 2024-10-22 10:54:30 --> Router Class Initialized
INFO - 2024-10-22 10:54:30 --> Output Class Initialized
INFO - 2024-10-22 10:54:30 --> Security Class Initialized
DEBUG - 2024-10-22 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 10:54:30 --> Input Class Initialized
INFO - 2024-10-22 10:54:30 --> Language Class Initialized
INFO - 2024-10-22 10:54:30 --> Language Class Initialized
INFO - 2024-10-22 10:54:30 --> Config Class Initialized
INFO - 2024-10-22 10:54:30 --> Loader Class Initialized
INFO - 2024-10-22 10:54:30 --> Helper loaded: url_helper
INFO - 2024-10-22 10:54:30 --> Helper loaded: file_helper
INFO - 2024-10-22 10:54:30 --> Helper loaded: form_helper
INFO - 2024-10-22 10:54:30 --> Helper loaded: my_helper
INFO - 2024-10-22 10:54:30 --> Database Driver Class Initialized
INFO - 2024-10-22 10:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 10:54:30 --> Controller Class Initialized
INFO - 2024-10-22 10:54:30 --> Helper loaded: cookie_helper
INFO - 2024-10-22 10:54:30 --> Final output sent to browser
DEBUG - 2024-10-22 10:54:30 --> Total execution time: 0.0518
INFO - 2024-10-22 10:54:31 --> Config Class Initialized
INFO - 2024-10-22 10:54:31 --> Hooks Class Initialized
DEBUG - 2024-10-22 10:54:31 --> UTF-8 Support Enabled
INFO - 2024-10-22 10:54:31 --> Utf8 Class Initialized
INFO - 2024-10-22 10:54:31 --> URI Class Initialized
INFO - 2024-10-22 10:54:31 --> Router Class Initialized
INFO - 2024-10-22 10:54:31 --> Output Class Initialized
INFO - 2024-10-22 10:54:31 --> Security Class Initialized
DEBUG - 2024-10-22 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 10:54:31 --> Input Class Initialized
INFO - 2024-10-22 10:54:31 --> Language Class Initialized
INFO - 2024-10-22 10:54:31 --> Language Class Initialized
INFO - 2024-10-22 10:54:31 --> Config Class Initialized
INFO - 2024-10-22 10:54:31 --> Loader Class Initialized
INFO - 2024-10-22 10:54:31 --> Helper loaded: url_helper
INFO - 2024-10-22 10:54:31 --> Helper loaded: file_helper
INFO - 2024-10-22 10:54:31 --> Helper loaded: form_helper
INFO - 2024-10-22 10:54:31 --> Helper loaded: my_helper
INFO - 2024-10-22 10:54:31 --> Database Driver Class Initialized
INFO - 2024-10-22 10:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 10:54:31 --> Controller Class Initialized
INFO - 2024-10-22 10:54:31 --> Helper loaded: cookie_helper
INFO - 2024-10-22 10:54:32 --> Config Class Initialized
INFO - 2024-10-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-22 10:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-22 10:54:32 --> Utf8 Class Initialized
INFO - 2024-10-22 10:54:32 --> URI Class Initialized
INFO - 2024-10-22 10:54:32 --> Router Class Initialized
INFO - 2024-10-22 10:54:32 --> Output Class Initialized
INFO - 2024-10-22 10:54:32 --> Security Class Initialized
DEBUG - 2024-10-22 10:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 10:54:32 --> Input Class Initialized
INFO - 2024-10-22 10:54:32 --> Language Class Initialized
INFO - 2024-10-22 10:54:32 --> Language Class Initialized
INFO - 2024-10-22 10:54:32 --> Config Class Initialized
INFO - 2024-10-22 10:54:32 --> Loader Class Initialized
INFO - 2024-10-22 10:54:32 --> Helper loaded: url_helper
INFO - 2024-10-22 10:54:32 --> Helper loaded: file_helper
INFO - 2024-10-22 10:54:32 --> Helper loaded: form_helper
INFO - 2024-10-22 10:54:32 --> Helper loaded: my_helper
INFO - 2024-10-22 10:54:32 --> Database Driver Class Initialized
INFO - 2024-10-22 10:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 10:54:32 --> Controller Class Initialized
DEBUG - 2024-10-22 10:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-22 10:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 10:54:32 --> Final output sent to browser
DEBUG - 2024-10-22 10:54:32 --> Total execution time: 0.0476
INFO - 2024-10-22 10:54:37 --> Config Class Initialized
INFO - 2024-10-22 10:54:37 --> Hooks Class Initialized
DEBUG - 2024-10-22 10:54:37 --> UTF-8 Support Enabled
INFO - 2024-10-22 10:54:37 --> Utf8 Class Initialized
INFO - 2024-10-22 10:54:37 --> URI Class Initialized
INFO - 2024-10-22 10:54:37 --> Router Class Initialized
INFO - 2024-10-22 10:54:37 --> Output Class Initialized
INFO - 2024-10-22 10:54:37 --> Security Class Initialized
DEBUG - 2024-10-22 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 10:54:37 --> Input Class Initialized
INFO - 2024-10-22 10:54:37 --> Language Class Initialized
INFO - 2024-10-22 10:54:37 --> Language Class Initialized
INFO - 2024-10-22 10:54:37 --> Config Class Initialized
INFO - 2024-10-22 10:54:37 --> Loader Class Initialized
INFO - 2024-10-22 10:54:37 --> Helper loaded: url_helper
INFO - 2024-10-22 10:54:37 --> Helper loaded: file_helper
INFO - 2024-10-22 10:54:37 --> Helper loaded: form_helper
INFO - 2024-10-22 10:54:37 --> Helper loaded: my_helper
INFO - 2024-10-22 10:54:37 --> Database Driver Class Initialized
INFO - 2024-10-22 10:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 10:54:37 --> Controller Class Initialized
DEBUG - 2024-10-22 10:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 10:54:40 --> Final output sent to browser
DEBUG - 2024-10-22 10:54:40 --> Total execution time: 3.0182
INFO - 2024-10-22 12:23:48 --> Config Class Initialized
INFO - 2024-10-22 12:23:48 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:23:48 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:23:48 --> Utf8 Class Initialized
INFO - 2024-10-22 12:23:48 --> URI Class Initialized
INFO - 2024-10-22 12:23:48 --> Router Class Initialized
INFO - 2024-10-22 12:23:48 --> Output Class Initialized
INFO - 2024-10-22 12:23:48 --> Security Class Initialized
DEBUG - 2024-10-22 12:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:23:48 --> Input Class Initialized
INFO - 2024-10-22 12:23:48 --> Language Class Initialized
INFO - 2024-10-22 12:23:48 --> Language Class Initialized
INFO - 2024-10-22 12:23:48 --> Config Class Initialized
INFO - 2024-10-22 12:23:48 --> Loader Class Initialized
INFO - 2024-10-22 12:23:48 --> Helper loaded: url_helper
INFO - 2024-10-22 12:23:48 --> Helper loaded: file_helper
INFO - 2024-10-22 12:23:48 --> Helper loaded: form_helper
INFO - 2024-10-22 12:23:48 --> Helper loaded: my_helper
INFO - 2024-10-22 12:23:48 --> Database Driver Class Initialized
INFO - 2024-10-22 12:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:23:48 --> Controller Class Initialized
DEBUG - 2024-10-22 12:23:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-22 12:23:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:23:48 --> Final output sent to browser
DEBUG - 2024-10-22 12:23:48 --> Total execution time: 0.0594
INFO - 2024-10-22 12:23:54 --> Config Class Initialized
INFO - 2024-10-22 12:23:54 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:23:54 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:23:54 --> Utf8 Class Initialized
INFO - 2024-10-22 12:23:54 --> URI Class Initialized
INFO - 2024-10-22 12:23:54 --> Router Class Initialized
INFO - 2024-10-22 12:23:54 --> Output Class Initialized
INFO - 2024-10-22 12:23:54 --> Security Class Initialized
DEBUG - 2024-10-22 12:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:23:54 --> Input Class Initialized
INFO - 2024-10-22 12:23:54 --> Language Class Initialized
INFO - 2024-10-22 12:23:54 --> Language Class Initialized
INFO - 2024-10-22 12:23:54 --> Config Class Initialized
INFO - 2024-10-22 12:23:54 --> Loader Class Initialized
INFO - 2024-10-22 12:23:54 --> Helper loaded: url_helper
INFO - 2024-10-22 12:23:54 --> Helper loaded: file_helper
INFO - 2024-10-22 12:23:54 --> Helper loaded: form_helper
INFO - 2024-10-22 12:23:54 --> Helper loaded: my_helper
INFO - 2024-10-22 12:23:54 --> Database Driver Class Initialized
INFO - 2024-10-22 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:23:54 --> Controller Class Initialized
INFO - 2024-10-22 12:23:54 --> Helper loaded: cookie_helper
INFO - 2024-10-22 12:23:54 --> Final output sent to browser
DEBUG - 2024-10-22 12:23:54 --> Total execution time: 0.0336
INFO - 2024-10-22 12:23:54 --> Config Class Initialized
INFO - 2024-10-22 12:23:54 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:23:54 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:23:54 --> Utf8 Class Initialized
INFO - 2024-10-22 12:23:54 --> URI Class Initialized
INFO - 2024-10-22 12:23:54 --> Router Class Initialized
INFO - 2024-10-22 12:23:54 --> Output Class Initialized
INFO - 2024-10-22 12:23:54 --> Security Class Initialized
DEBUG - 2024-10-22 12:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:23:54 --> Input Class Initialized
INFO - 2024-10-22 12:23:54 --> Language Class Initialized
INFO - 2024-10-22 12:23:54 --> Language Class Initialized
INFO - 2024-10-22 12:23:54 --> Config Class Initialized
INFO - 2024-10-22 12:23:54 --> Loader Class Initialized
INFO - 2024-10-22 12:23:54 --> Helper loaded: url_helper
INFO - 2024-10-22 12:23:54 --> Helper loaded: file_helper
INFO - 2024-10-22 12:23:54 --> Helper loaded: form_helper
INFO - 2024-10-22 12:23:54 --> Helper loaded: my_helper
INFO - 2024-10-22 12:23:54 --> Database Driver Class Initialized
INFO - 2024-10-22 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:23:54 --> Controller Class Initialized
DEBUG - 2024-10-22 12:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-22 12:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:23:54 --> Final output sent to browser
DEBUG - 2024-10-22 12:23:54 --> Total execution time: 0.0539
INFO - 2024-10-22 12:24:14 --> Config Class Initialized
INFO - 2024-10-22 12:24:14 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:24:14 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:24:14 --> Utf8 Class Initialized
INFO - 2024-10-22 12:24:14 --> URI Class Initialized
INFO - 2024-10-22 12:24:14 --> Router Class Initialized
INFO - 2024-10-22 12:24:14 --> Output Class Initialized
INFO - 2024-10-22 12:24:14 --> Security Class Initialized
DEBUG - 2024-10-22 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:24:14 --> Input Class Initialized
INFO - 2024-10-22 12:24:14 --> Language Class Initialized
INFO - 2024-10-22 12:24:14 --> Language Class Initialized
INFO - 2024-10-22 12:24:14 --> Config Class Initialized
INFO - 2024-10-22 12:24:14 --> Loader Class Initialized
INFO - 2024-10-22 12:24:14 --> Helper loaded: url_helper
INFO - 2024-10-22 12:24:14 --> Helper loaded: file_helper
INFO - 2024-10-22 12:24:14 --> Helper loaded: form_helper
INFO - 2024-10-22 12:24:14 --> Helper loaded: my_helper
INFO - 2024-10-22 12:24:14 --> Database Driver Class Initialized
INFO - 2024-10-22 12:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:24:14 --> Controller Class Initialized
DEBUG - 2024-10-22 12:24:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-22 12:24:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:24:14 --> Final output sent to browser
DEBUG - 2024-10-22 12:24:14 --> Total execution time: 0.0544
INFO - 2024-10-22 12:24:14 --> Config Class Initialized
INFO - 2024-10-22 12:24:14 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:24:14 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:24:14 --> Utf8 Class Initialized
INFO - 2024-10-22 12:24:14 --> URI Class Initialized
INFO - 2024-10-22 12:24:14 --> Router Class Initialized
INFO - 2024-10-22 12:24:14 --> Output Class Initialized
INFO - 2024-10-22 12:24:14 --> Security Class Initialized
DEBUG - 2024-10-22 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:24:14 --> Input Class Initialized
INFO - 2024-10-22 12:24:14 --> Language Class Initialized
ERROR - 2024-10-22 12:24:14 --> 404 Page Not Found: /index
INFO - 2024-10-22 12:24:14 --> Config Class Initialized
INFO - 2024-10-22 12:24:14 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:24:14 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:24:14 --> Utf8 Class Initialized
INFO - 2024-10-22 12:24:14 --> URI Class Initialized
INFO - 2024-10-22 12:24:14 --> Router Class Initialized
INFO - 2024-10-22 12:24:14 --> Output Class Initialized
INFO - 2024-10-22 12:24:14 --> Security Class Initialized
DEBUG - 2024-10-22 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:24:14 --> Input Class Initialized
INFO - 2024-10-22 12:24:14 --> Language Class Initialized
INFO - 2024-10-22 12:24:14 --> Language Class Initialized
INFO - 2024-10-22 12:24:14 --> Config Class Initialized
INFO - 2024-10-22 12:24:14 --> Loader Class Initialized
INFO - 2024-10-22 12:24:14 --> Helper loaded: url_helper
INFO - 2024-10-22 12:24:14 --> Helper loaded: file_helper
INFO - 2024-10-22 12:24:14 --> Helper loaded: form_helper
INFO - 2024-10-22 12:24:14 --> Helper loaded: my_helper
INFO - 2024-10-22 12:24:14 --> Database Driver Class Initialized
INFO - 2024-10-22 12:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:24:14 --> Controller Class Initialized
INFO - 2024-10-22 12:24:16 --> Config Class Initialized
INFO - 2024-10-22 12:24:16 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:24:16 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:24:16 --> Utf8 Class Initialized
INFO - 2024-10-22 12:24:16 --> URI Class Initialized
INFO - 2024-10-22 12:24:16 --> Router Class Initialized
INFO - 2024-10-22 12:24:16 --> Output Class Initialized
INFO - 2024-10-22 12:24:16 --> Security Class Initialized
DEBUG - 2024-10-22 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:24:16 --> Input Class Initialized
INFO - 2024-10-22 12:24:16 --> Language Class Initialized
INFO - 2024-10-22 12:24:16 --> Language Class Initialized
INFO - 2024-10-22 12:24:16 --> Config Class Initialized
INFO - 2024-10-22 12:24:16 --> Loader Class Initialized
INFO - 2024-10-22 12:24:16 --> Helper loaded: url_helper
INFO - 2024-10-22 12:24:16 --> Helper loaded: file_helper
INFO - 2024-10-22 12:24:16 --> Helper loaded: form_helper
INFO - 2024-10-22 12:24:16 --> Helper loaded: my_helper
INFO - 2024-10-22 12:24:16 --> Database Driver Class Initialized
INFO - 2024-10-22 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:24:16 --> Controller Class Initialized
ERROR - 2024-10-22 12:24:16 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-22 12:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-22 12:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:24:16 --> Final output sent to browser
DEBUG - 2024-10-22 12:24:16 --> Total execution time: 0.0451
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:27:48 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:27:48 --> Utf8 Class Initialized
INFO - 2024-10-22 12:27:48 --> URI Class Initialized
INFO - 2024-10-22 12:27:48 --> Router Class Initialized
INFO - 2024-10-22 12:27:48 --> Output Class Initialized
INFO - 2024-10-22 12:27:48 --> Security Class Initialized
DEBUG - 2024-10-22 12:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:27:48 --> Input Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Loader Class Initialized
INFO - 2024-10-22 12:27:48 --> Helper loaded: url_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: file_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: form_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: my_helper
INFO - 2024-10-22 12:27:48 --> Database Driver Class Initialized
INFO - 2024-10-22 12:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:27:48 --> Controller Class Initialized
INFO - 2024-10-22 12:27:48 --> Upload Class Initialized
INFO - 2024-10-22 12:27:48 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-22 12:27:48 --> The upload path does not appear to be valid.
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:27:48 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:27:48 --> Utf8 Class Initialized
INFO - 2024-10-22 12:27:48 --> URI Class Initialized
INFO - 2024-10-22 12:27:48 --> Router Class Initialized
INFO - 2024-10-22 12:27:48 --> Output Class Initialized
INFO - 2024-10-22 12:27:48 --> Security Class Initialized
DEBUG - 2024-10-22 12:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:27:48 --> Input Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Loader Class Initialized
INFO - 2024-10-22 12:27:48 --> Helper loaded: url_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: file_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: form_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: my_helper
INFO - 2024-10-22 12:27:48 --> Database Driver Class Initialized
INFO - 2024-10-22 12:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:27:48 --> Controller Class Initialized
DEBUG - 2024-10-22 12:27:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-22 12:27:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:27:48 --> Final output sent to browser
DEBUG - 2024-10-22 12:27:48 --> Total execution time: 0.0272
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:27:48 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:27:48 --> Utf8 Class Initialized
INFO - 2024-10-22 12:27:48 --> URI Class Initialized
INFO - 2024-10-22 12:27:48 --> Router Class Initialized
INFO - 2024-10-22 12:27:48 --> Output Class Initialized
INFO - 2024-10-22 12:27:48 --> Security Class Initialized
DEBUG - 2024-10-22 12:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:27:48 --> Input Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
ERROR - 2024-10-22 12:27:48 --> 404 Page Not Found: /index
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:27:48 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:27:48 --> Utf8 Class Initialized
INFO - 2024-10-22 12:27:48 --> URI Class Initialized
INFO - 2024-10-22 12:27:48 --> Router Class Initialized
INFO - 2024-10-22 12:27:48 --> Output Class Initialized
INFO - 2024-10-22 12:27:48 --> Security Class Initialized
DEBUG - 2024-10-22 12:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:27:48 --> Input Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
INFO - 2024-10-22 12:27:48 --> Language Class Initialized
INFO - 2024-10-22 12:27:48 --> Config Class Initialized
INFO - 2024-10-22 12:27:48 --> Loader Class Initialized
INFO - 2024-10-22 12:27:48 --> Helper loaded: url_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: file_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: form_helper
INFO - 2024-10-22 12:27:48 --> Helper loaded: my_helper
INFO - 2024-10-22 12:27:48 --> Database Driver Class Initialized
INFO - 2024-10-22 12:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:27:48 --> Controller Class Initialized
INFO - 2024-10-22 12:28:00 --> Config Class Initialized
INFO - 2024-10-22 12:28:00 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:00 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:00 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:00 --> URI Class Initialized
INFO - 2024-10-22 12:28:00 --> Router Class Initialized
INFO - 2024-10-22 12:28:00 --> Output Class Initialized
INFO - 2024-10-22 12:28:00 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:00 --> Input Class Initialized
INFO - 2024-10-22 12:28:00 --> Language Class Initialized
INFO - 2024-10-22 12:28:00 --> Language Class Initialized
INFO - 2024-10-22 12:28:00 --> Config Class Initialized
INFO - 2024-10-22 12:28:00 --> Loader Class Initialized
INFO - 2024-10-22 12:28:00 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:00 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:00 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:00 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:00 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:00 --> Controller Class Initialized
INFO - 2024-10-22 12:28:02 --> Config Class Initialized
INFO - 2024-10-22 12:28:02 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:02 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:02 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:02 --> URI Class Initialized
INFO - 2024-10-22 12:28:02 --> Router Class Initialized
INFO - 2024-10-22 12:28:02 --> Output Class Initialized
INFO - 2024-10-22 12:28:02 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:02 --> Input Class Initialized
INFO - 2024-10-22 12:28:02 --> Language Class Initialized
INFO - 2024-10-22 12:28:02 --> Language Class Initialized
INFO - 2024-10-22 12:28:02 --> Config Class Initialized
INFO - 2024-10-22 12:28:02 --> Loader Class Initialized
INFO - 2024-10-22 12:28:02 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:02 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:02 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:02 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:02 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:02 --> Controller Class Initialized
INFO - 2024-10-22 12:28:06 --> Config Class Initialized
INFO - 2024-10-22 12:28:06 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:06 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:06 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:06 --> URI Class Initialized
INFO - 2024-10-22 12:28:06 --> Router Class Initialized
INFO - 2024-10-22 12:28:06 --> Output Class Initialized
INFO - 2024-10-22 12:28:06 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:06 --> Input Class Initialized
INFO - 2024-10-22 12:28:06 --> Language Class Initialized
INFO - 2024-10-22 12:28:06 --> Language Class Initialized
INFO - 2024-10-22 12:28:06 --> Config Class Initialized
INFO - 2024-10-22 12:28:06 --> Loader Class Initialized
INFO - 2024-10-22 12:28:06 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:06 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:06 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:06 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:06 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:06 --> Controller Class Initialized
INFO - 2024-10-22 12:28:06 --> Config Class Initialized
INFO - 2024-10-22 12:28:06 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:06 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:06 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:06 --> URI Class Initialized
INFO - 2024-10-22 12:28:06 --> Router Class Initialized
INFO - 2024-10-22 12:28:06 --> Output Class Initialized
INFO - 2024-10-22 12:28:06 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:06 --> Input Class Initialized
INFO - 2024-10-22 12:28:06 --> Language Class Initialized
INFO - 2024-10-22 12:28:06 --> Language Class Initialized
INFO - 2024-10-22 12:28:06 --> Config Class Initialized
INFO - 2024-10-22 12:28:06 --> Loader Class Initialized
INFO - 2024-10-22 12:28:06 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:06 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:06 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:06 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:06 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:06 --> Controller Class Initialized
INFO - 2024-10-22 12:28:07 --> Config Class Initialized
INFO - 2024-10-22 12:28:07 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:07 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:07 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:07 --> URI Class Initialized
INFO - 2024-10-22 12:28:07 --> Router Class Initialized
INFO - 2024-10-22 12:28:07 --> Output Class Initialized
INFO - 2024-10-22 12:28:07 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:07 --> Input Class Initialized
INFO - 2024-10-22 12:28:07 --> Language Class Initialized
INFO - 2024-10-22 12:28:07 --> Language Class Initialized
INFO - 2024-10-22 12:28:07 --> Config Class Initialized
INFO - 2024-10-22 12:28:07 --> Loader Class Initialized
INFO - 2024-10-22 12:28:07 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:07 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:07 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:07 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:07 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:07 --> Controller Class Initialized
INFO - 2024-10-22 12:28:49 --> Config Class Initialized
INFO - 2024-10-22 12:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:49 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:49 --> URI Class Initialized
INFO - 2024-10-22 12:28:49 --> Router Class Initialized
INFO - 2024-10-22 12:28:49 --> Output Class Initialized
INFO - 2024-10-22 12:28:49 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:49 --> Input Class Initialized
INFO - 2024-10-22 12:28:49 --> Language Class Initialized
INFO - 2024-10-22 12:28:49 --> Language Class Initialized
INFO - 2024-10-22 12:28:49 --> Config Class Initialized
INFO - 2024-10-22 12:28:49 --> Loader Class Initialized
INFO - 2024-10-22 12:28:49 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:49 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:49 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:49 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:49 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:49 --> Controller Class Initialized
INFO - 2024-10-22 12:28:49 --> Final output sent to browser
DEBUG - 2024-10-22 12:28:49 --> Total execution time: 0.0372
INFO - 2024-10-22 12:28:49 --> Config Class Initialized
INFO - 2024-10-22 12:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:49 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:49 --> URI Class Initialized
INFO - 2024-10-22 12:28:49 --> Router Class Initialized
INFO - 2024-10-22 12:28:49 --> Output Class Initialized
INFO - 2024-10-22 12:28:49 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:49 --> Input Class Initialized
INFO - 2024-10-22 12:28:49 --> Language Class Initialized
ERROR - 2024-10-22 12:28:49 --> 404 Page Not Found: /index
INFO - 2024-10-22 12:28:49 --> Config Class Initialized
INFO - 2024-10-22 12:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:49 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:49 --> URI Class Initialized
INFO - 2024-10-22 12:28:49 --> Router Class Initialized
INFO - 2024-10-22 12:28:49 --> Output Class Initialized
INFO - 2024-10-22 12:28:49 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:49 --> Input Class Initialized
INFO - 2024-10-22 12:28:49 --> Language Class Initialized
INFO - 2024-10-22 12:28:49 --> Language Class Initialized
INFO - 2024-10-22 12:28:49 --> Config Class Initialized
INFO - 2024-10-22 12:28:49 --> Loader Class Initialized
INFO - 2024-10-22 12:28:49 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:49 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:49 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:49 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:49 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:49 --> Controller Class Initialized
INFO - 2024-10-22 12:28:57 --> Config Class Initialized
INFO - 2024-10-22 12:28:57 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:57 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:57 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:57 --> URI Class Initialized
INFO - 2024-10-22 12:28:57 --> Router Class Initialized
INFO - 2024-10-22 12:28:57 --> Output Class Initialized
INFO - 2024-10-22 12:28:57 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:57 --> Input Class Initialized
INFO - 2024-10-22 12:28:57 --> Language Class Initialized
INFO - 2024-10-22 12:28:57 --> Language Class Initialized
INFO - 2024-10-22 12:28:57 --> Config Class Initialized
INFO - 2024-10-22 12:28:57 --> Loader Class Initialized
INFO - 2024-10-22 12:28:58 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:58 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:58 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:58 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:58 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:58 --> Controller Class Initialized
DEBUG - 2024-10-22 12:28:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-10-22 12:28:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:28:58 --> Final output sent to browser
DEBUG - 2024-10-22 12:28:58 --> Total execution time: 0.0354
INFO - 2024-10-22 12:28:58 --> Config Class Initialized
INFO - 2024-10-22 12:28:58 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:58 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:58 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:58 --> URI Class Initialized
INFO - 2024-10-22 12:28:58 --> Router Class Initialized
INFO - 2024-10-22 12:28:58 --> Output Class Initialized
INFO - 2024-10-22 12:28:58 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:58 --> Input Class Initialized
INFO - 2024-10-22 12:28:58 --> Language Class Initialized
ERROR - 2024-10-22 12:28:58 --> 404 Page Not Found: /index
INFO - 2024-10-22 12:28:58 --> Config Class Initialized
INFO - 2024-10-22 12:28:58 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:28:58 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:28:58 --> Utf8 Class Initialized
INFO - 2024-10-22 12:28:58 --> URI Class Initialized
INFO - 2024-10-22 12:28:58 --> Router Class Initialized
INFO - 2024-10-22 12:28:58 --> Output Class Initialized
INFO - 2024-10-22 12:28:58 --> Security Class Initialized
DEBUG - 2024-10-22 12:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:28:58 --> Input Class Initialized
INFO - 2024-10-22 12:28:58 --> Language Class Initialized
INFO - 2024-10-22 12:28:58 --> Language Class Initialized
INFO - 2024-10-22 12:28:58 --> Config Class Initialized
INFO - 2024-10-22 12:28:58 --> Loader Class Initialized
INFO - 2024-10-22 12:28:58 --> Helper loaded: url_helper
INFO - 2024-10-22 12:28:58 --> Helper loaded: file_helper
INFO - 2024-10-22 12:28:58 --> Helper loaded: form_helper
INFO - 2024-10-22 12:28:58 --> Helper loaded: my_helper
INFO - 2024-10-22 12:28:58 --> Database Driver Class Initialized
INFO - 2024-10-22 12:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:28:58 --> Controller Class Initialized
INFO - 2024-10-22 12:29:09 --> Config Class Initialized
INFO - 2024-10-22 12:29:09 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:09 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:09 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:09 --> URI Class Initialized
INFO - 2024-10-22 12:29:09 --> Router Class Initialized
INFO - 2024-10-22 12:29:09 --> Output Class Initialized
INFO - 2024-10-22 12:29:09 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:09 --> Input Class Initialized
INFO - 2024-10-22 12:29:09 --> Language Class Initialized
INFO - 2024-10-22 12:29:09 --> Language Class Initialized
INFO - 2024-10-22 12:29:09 --> Config Class Initialized
INFO - 2024-10-22 12:29:09 --> Loader Class Initialized
INFO - 2024-10-22 12:29:09 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:09 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:09 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:09 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:09 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:09 --> Controller Class Initialized
DEBUG - 2024-10-22 12:29:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-10-22 12:29:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:09 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:09 --> Total execution time: 0.0284
INFO - 2024-10-22 12:29:09 --> Config Class Initialized
INFO - 2024-10-22 12:29:09 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:09 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:09 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:09 --> URI Class Initialized
INFO - 2024-10-22 12:29:09 --> Router Class Initialized
INFO - 2024-10-22 12:29:09 --> Output Class Initialized
INFO - 2024-10-22 12:29:09 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:09 --> Input Class Initialized
INFO - 2024-10-22 12:29:09 --> Language Class Initialized
ERROR - 2024-10-22 12:29:09 --> 404 Page Not Found: /index
INFO - 2024-10-22 12:29:09 --> Config Class Initialized
INFO - 2024-10-22 12:29:09 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:09 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:09 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:09 --> URI Class Initialized
INFO - 2024-10-22 12:29:09 --> Router Class Initialized
INFO - 2024-10-22 12:29:09 --> Output Class Initialized
INFO - 2024-10-22 12:29:09 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:09 --> Input Class Initialized
INFO - 2024-10-22 12:29:09 --> Language Class Initialized
INFO - 2024-10-22 12:29:09 --> Language Class Initialized
INFO - 2024-10-22 12:29:09 --> Config Class Initialized
INFO - 2024-10-22 12:29:09 --> Loader Class Initialized
INFO - 2024-10-22 12:29:09 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:09 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:09 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:09 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:09 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:09 --> Controller Class Initialized
INFO - 2024-10-22 12:29:14 --> Config Class Initialized
INFO - 2024-10-22 12:29:14 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:14 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:14 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:14 --> URI Class Initialized
INFO - 2024-10-22 12:29:14 --> Router Class Initialized
INFO - 2024-10-22 12:29:14 --> Output Class Initialized
INFO - 2024-10-22 12:29:14 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:14 --> Input Class Initialized
INFO - 2024-10-22 12:29:14 --> Language Class Initialized
INFO - 2024-10-22 12:29:14 --> Language Class Initialized
INFO - 2024-10-22 12:29:14 --> Config Class Initialized
INFO - 2024-10-22 12:29:14 --> Loader Class Initialized
INFO - 2024-10-22 12:29:14 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:14 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:14 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:14 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:14 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:14 --> Controller Class Initialized
DEBUG - 2024-10-22 12:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-10-22 12:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:14 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:14 --> Total execution time: 0.0358
INFO - 2024-10-22 12:29:21 --> Config Class Initialized
INFO - 2024-10-22 12:29:21 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:21 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:21 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:21 --> URI Class Initialized
INFO - 2024-10-22 12:29:21 --> Router Class Initialized
INFO - 2024-10-22 12:29:21 --> Output Class Initialized
INFO - 2024-10-22 12:29:21 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:21 --> Input Class Initialized
INFO - 2024-10-22 12:29:21 --> Language Class Initialized
INFO - 2024-10-22 12:29:21 --> Language Class Initialized
INFO - 2024-10-22 12:29:21 --> Config Class Initialized
INFO - 2024-10-22 12:29:21 --> Loader Class Initialized
INFO - 2024-10-22 12:29:21 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:21 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:21 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:21 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:21 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:21 --> Controller Class Initialized
DEBUG - 2024-10-22 12:29:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-10-22 12:29:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:21 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:21 --> Total execution time: 0.0257
INFO - 2024-10-22 12:29:22 --> Config Class Initialized
INFO - 2024-10-22 12:29:22 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:22 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:22 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:22 --> URI Class Initialized
INFO - 2024-10-22 12:29:22 --> Router Class Initialized
INFO - 2024-10-22 12:29:22 --> Output Class Initialized
INFO - 2024-10-22 12:29:22 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:22 --> Input Class Initialized
INFO - 2024-10-22 12:29:22 --> Language Class Initialized
ERROR - 2024-10-22 12:29:22 --> 404 Page Not Found: /index
INFO - 2024-10-22 12:29:22 --> Config Class Initialized
INFO - 2024-10-22 12:29:22 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:22 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:22 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:22 --> URI Class Initialized
INFO - 2024-10-22 12:29:22 --> Router Class Initialized
INFO - 2024-10-22 12:29:22 --> Output Class Initialized
INFO - 2024-10-22 12:29:22 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:22 --> Input Class Initialized
INFO - 2024-10-22 12:29:22 --> Language Class Initialized
INFO - 2024-10-22 12:29:22 --> Language Class Initialized
INFO - 2024-10-22 12:29:22 --> Config Class Initialized
INFO - 2024-10-22 12:29:22 --> Loader Class Initialized
INFO - 2024-10-22 12:29:22 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:22 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:22 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:22 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:22 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:22 --> Controller Class Initialized
INFO - 2024-10-22 12:29:29 --> Config Class Initialized
INFO - 2024-10-22 12:29:29 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:29 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:29 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:29 --> URI Class Initialized
INFO - 2024-10-22 12:29:29 --> Router Class Initialized
INFO - 2024-10-22 12:29:29 --> Output Class Initialized
INFO - 2024-10-22 12:29:29 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:29 --> Input Class Initialized
INFO - 2024-10-22 12:29:29 --> Language Class Initialized
INFO - 2024-10-22 12:29:29 --> Language Class Initialized
INFO - 2024-10-22 12:29:29 --> Config Class Initialized
INFO - 2024-10-22 12:29:29 --> Loader Class Initialized
INFO - 2024-10-22 12:29:29 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:29 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:29 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:29 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:29 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:29 --> Controller Class Initialized
DEBUG - 2024-10-22 12:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-22 12:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:29 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:29 --> Total execution time: 0.0331
INFO - 2024-10-22 12:29:32 --> Config Class Initialized
INFO - 2024-10-22 12:29:32 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:32 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:32 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:32 --> URI Class Initialized
INFO - 2024-10-22 12:29:32 --> Router Class Initialized
INFO - 2024-10-22 12:29:32 --> Output Class Initialized
INFO - 2024-10-22 12:29:32 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:32 --> Input Class Initialized
INFO - 2024-10-22 12:29:32 --> Language Class Initialized
INFO - 2024-10-22 12:29:32 --> Language Class Initialized
INFO - 2024-10-22 12:29:32 --> Config Class Initialized
INFO - 2024-10-22 12:29:32 --> Loader Class Initialized
INFO - 2024-10-22 12:29:32 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:32 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:32 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:32 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:32 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:32 --> Controller Class Initialized
ERROR - 2024-10-22 12:29:32 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-10-22 12:29:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-10-22 12:29:32 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-10-22 12:29:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-10-22 12:29:32 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-10-22 12:29:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-10-22 12:29:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:32 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:32 --> Total execution time: 0.0348
INFO - 2024-10-22 12:29:42 --> Config Class Initialized
INFO - 2024-10-22 12:29:42 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:42 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:42 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:42 --> URI Class Initialized
INFO - 2024-10-22 12:29:42 --> Router Class Initialized
INFO - 2024-10-22 12:29:42 --> Output Class Initialized
INFO - 2024-10-22 12:29:42 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:42 --> Input Class Initialized
INFO - 2024-10-22 12:29:42 --> Language Class Initialized
INFO - 2024-10-22 12:29:42 --> Language Class Initialized
INFO - 2024-10-22 12:29:42 --> Config Class Initialized
INFO - 2024-10-22 12:29:42 --> Loader Class Initialized
INFO - 2024-10-22 12:29:42 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:42 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:42 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:42 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:42 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:42 --> Controller Class Initialized
INFO - 2024-10-22 12:29:42 --> Config Class Initialized
INFO - 2024-10-22 12:29:42 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:42 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:42 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:42 --> URI Class Initialized
INFO - 2024-10-22 12:29:42 --> Router Class Initialized
INFO - 2024-10-22 12:29:42 --> Output Class Initialized
INFO - 2024-10-22 12:29:42 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:42 --> Input Class Initialized
INFO - 2024-10-22 12:29:42 --> Language Class Initialized
INFO - 2024-10-22 12:29:42 --> Language Class Initialized
INFO - 2024-10-22 12:29:42 --> Config Class Initialized
INFO - 2024-10-22 12:29:42 --> Loader Class Initialized
INFO - 2024-10-22 12:29:42 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:42 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:42 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:42 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:42 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:42 --> Controller Class Initialized
DEBUG - 2024-10-22 12:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-22 12:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:42 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:42 --> Total execution time: 0.0314
INFO - 2024-10-22 12:29:46 --> Config Class Initialized
INFO - 2024-10-22 12:29:46 --> Hooks Class Initialized
DEBUG - 2024-10-22 12:29:46 --> UTF-8 Support Enabled
INFO - 2024-10-22 12:29:46 --> Utf8 Class Initialized
INFO - 2024-10-22 12:29:46 --> URI Class Initialized
DEBUG - 2024-10-22 12:29:47 --> No URI present. Default controller set.
INFO - 2024-10-22 12:29:47 --> Router Class Initialized
INFO - 2024-10-22 12:29:47 --> Output Class Initialized
INFO - 2024-10-22 12:29:47 --> Security Class Initialized
DEBUG - 2024-10-22 12:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 12:29:47 --> Input Class Initialized
INFO - 2024-10-22 12:29:47 --> Language Class Initialized
INFO - 2024-10-22 12:29:47 --> Language Class Initialized
INFO - 2024-10-22 12:29:47 --> Config Class Initialized
INFO - 2024-10-22 12:29:47 --> Loader Class Initialized
INFO - 2024-10-22 12:29:47 --> Helper loaded: url_helper
INFO - 2024-10-22 12:29:47 --> Helper loaded: file_helper
INFO - 2024-10-22 12:29:47 --> Helper loaded: form_helper
INFO - 2024-10-22 12:29:47 --> Helper loaded: my_helper
INFO - 2024-10-22 12:29:47 --> Database Driver Class Initialized
INFO - 2024-10-22 12:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 12:29:47 --> Controller Class Initialized
DEBUG - 2024-10-22 12:29:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-22 12:29:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 12:29:47 --> Final output sent to browser
DEBUG - 2024-10-22 12:29:47 --> Total execution time: 0.0688
INFO - 2024-10-22 21:42:31 --> Config Class Initialized
INFO - 2024-10-22 21:42:31 --> Hooks Class Initialized
DEBUG - 2024-10-22 21:42:31 --> UTF-8 Support Enabled
INFO - 2024-10-22 21:42:31 --> Utf8 Class Initialized
INFO - 2024-10-22 21:42:31 --> URI Class Initialized
INFO - 2024-10-22 21:42:31 --> Router Class Initialized
INFO - 2024-10-22 21:42:31 --> Output Class Initialized
INFO - 2024-10-22 21:42:31 --> Security Class Initialized
DEBUG - 2024-10-22 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 21:42:31 --> Input Class Initialized
INFO - 2024-10-22 21:42:31 --> Language Class Initialized
INFO - 2024-10-22 21:42:31 --> Language Class Initialized
INFO - 2024-10-22 21:42:31 --> Config Class Initialized
INFO - 2024-10-22 21:42:31 --> Loader Class Initialized
INFO - 2024-10-22 21:42:31 --> Helper loaded: url_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: file_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: form_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: my_helper
INFO - 2024-10-22 21:42:31 --> Database Driver Class Initialized
INFO - 2024-10-22 21:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 21:42:31 --> Controller Class Initialized
INFO - 2024-10-22 21:42:31 --> Helper loaded: cookie_helper
INFO - 2024-10-22 21:42:31 --> Final output sent to browser
DEBUG - 2024-10-22 21:42:31 --> Total execution time: 0.0524
INFO - 2024-10-22 21:42:31 --> Config Class Initialized
INFO - 2024-10-22 21:42:31 --> Hooks Class Initialized
DEBUG - 2024-10-22 21:42:31 --> UTF-8 Support Enabled
INFO - 2024-10-22 21:42:31 --> Utf8 Class Initialized
INFO - 2024-10-22 21:42:31 --> URI Class Initialized
INFO - 2024-10-22 21:42:31 --> Router Class Initialized
INFO - 2024-10-22 21:42:31 --> Output Class Initialized
INFO - 2024-10-22 21:42:31 --> Security Class Initialized
DEBUG - 2024-10-22 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 21:42:31 --> Input Class Initialized
INFO - 2024-10-22 21:42:31 --> Language Class Initialized
INFO - 2024-10-22 21:42:31 --> Language Class Initialized
INFO - 2024-10-22 21:42:31 --> Config Class Initialized
INFO - 2024-10-22 21:42:31 --> Loader Class Initialized
INFO - 2024-10-22 21:42:31 --> Helper loaded: url_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: file_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: form_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: my_helper
INFO - 2024-10-22 21:42:31 --> Database Driver Class Initialized
INFO - 2024-10-22 21:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 21:42:31 --> Controller Class Initialized
INFO - 2024-10-22 21:42:31 --> Helper loaded: cookie_helper
INFO - 2024-10-22 21:42:31 --> Config Class Initialized
INFO - 2024-10-22 21:42:31 --> Hooks Class Initialized
DEBUG - 2024-10-22 21:42:31 --> UTF-8 Support Enabled
INFO - 2024-10-22 21:42:31 --> Utf8 Class Initialized
INFO - 2024-10-22 21:42:31 --> URI Class Initialized
INFO - 2024-10-22 21:42:31 --> Router Class Initialized
INFO - 2024-10-22 21:42:31 --> Output Class Initialized
INFO - 2024-10-22 21:42:31 --> Security Class Initialized
DEBUG - 2024-10-22 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 21:42:31 --> Input Class Initialized
INFO - 2024-10-22 21:42:31 --> Language Class Initialized
INFO - 2024-10-22 21:42:31 --> Language Class Initialized
INFO - 2024-10-22 21:42:31 --> Config Class Initialized
INFO - 2024-10-22 21:42:31 --> Loader Class Initialized
INFO - 2024-10-22 21:42:31 --> Helper loaded: url_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: file_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: form_helper
INFO - 2024-10-22 21:42:31 --> Helper loaded: my_helper
INFO - 2024-10-22 21:42:31 --> Database Driver Class Initialized
INFO - 2024-10-22 21:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 21:42:31 --> Controller Class Initialized
DEBUG - 2024-10-22 21:42:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-22 21:42:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-22 21:42:31 --> Final output sent to browser
DEBUG - 2024-10-22 21:42:31 --> Total execution time: 0.0413
INFO - 2024-10-22 21:42:33 --> Config Class Initialized
INFO - 2024-10-22 21:42:33 --> Hooks Class Initialized
DEBUG - 2024-10-22 21:42:33 --> UTF-8 Support Enabled
INFO - 2024-10-22 21:42:33 --> Utf8 Class Initialized
INFO - 2024-10-22 21:42:33 --> URI Class Initialized
INFO - 2024-10-22 21:42:33 --> Router Class Initialized
INFO - 2024-10-22 21:42:33 --> Output Class Initialized
INFO - 2024-10-22 21:42:33 --> Security Class Initialized
DEBUG - 2024-10-22 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 21:42:33 --> Input Class Initialized
INFO - 2024-10-22 21:42:33 --> Language Class Initialized
INFO - 2024-10-22 21:42:33 --> Language Class Initialized
INFO - 2024-10-22 21:42:33 --> Config Class Initialized
INFO - 2024-10-22 21:42:33 --> Loader Class Initialized
INFO - 2024-10-22 21:42:33 --> Helper loaded: url_helper
INFO - 2024-10-22 21:42:33 --> Helper loaded: file_helper
INFO - 2024-10-22 21:42:33 --> Helper loaded: form_helper
INFO - 2024-10-22 21:42:33 --> Helper loaded: my_helper
INFO - 2024-10-22 21:42:33 --> Database Driver Class Initialized
INFO - 2024-10-22 21:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 21:42:33 --> Controller Class Initialized
DEBUG - 2024-10-22 21:42:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-22 21:42:36 --> Final output sent to browser
DEBUG - 2024-10-22 21:42:36 --> Total execution time: 2.9819
INFO - 2024-10-22 22:48:41 --> Config Class Initialized
INFO - 2024-10-22 22:48:41 --> Hooks Class Initialized
DEBUG - 2024-10-22 22:48:41 --> UTF-8 Support Enabled
INFO - 2024-10-22 22:48:41 --> Utf8 Class Initialized
INFO - 2024-10-22 22:48:41 --> URI Class Initialized
INFO - 2024-10-22 22:48:41 --> Router Class Initialized
INFO - 2024-10-22 22:48:41 --> Output Class Initialized
INFO - 2024-10-22 22:48:41 --> Security Class Initialized
DEBUG - 2024-10-22 22:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 22:48:41 --> Input Class Initialized
INFO - 2024-10-22 22:48:41 --> Language Class Initialized
INFO - 2024-10-22 22:48:41 --> Language Class Initialized
INFO - 2024-10-22 22:48:41 --> Config Class Initialized
INFO - 2024-10-22 22:48:41 --> Loader Class Initialized
INFO - 2024-10-22 22:48:41 --> Helper loaded: url_helper
INFO - 2024-10-22 22:48:41 --> Helper loaded: file_helper
INFO - 2024-10-22 22:48:41 --> Helper loaded: form_helper
INFO - 2024-10-22 22:48:41 --> Helper loaded: my_helper
INFO - 2024-10-22 22:48:41 --> Database Driver Class Initialized
INFO - 2024-10-22 22:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 22:48:41 --> Controller Class Initialized
INFO - 2024-10-22 22:48:41 --> Helper loaded: cookie_helper
INFO - 2024-10-22 22:48:41 --> Final output sent to browser
DEBUG - 2024-10-22 22:48:41 --> Total execution time: 0.1897
INFO - 2024-10-22 22:48:41 --> Config Class Initialized
INFO - 2024-10-22 22:48:41 --> Hooks Class Initialized
DEBUG - 2024-10-22 22:48:41 --> UTF-8 Support Enabled
INFO - 2024-10-22 22:48:41 --> Utf8 Class Initialized
INFO - 2024-10-22 22:48:41 --> URI Class Initialized
INFO - 2024-10-22 22:48:41 --> Router Class Initialized
INFO - 2024-10-22 22:48:41 --> Output Class Initialized
INFO - 2024-10-22 22:48:41 --> Security Class Initialized
DEBUG - 2024-10-22 22:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 22:48:41 --> Input Class Initialized
INFO - 2024-10-22 22:48:41 --> Language Class Initialized
INFO - 2024-10-22 22:48:41 --> Language Class Initialized
INFO - 2024-10-22 22:48:41 --> Config Class Initialized
INFO - 2024-10-22 22:48:41 --> Loader Class Initialized
INFO - 2024-10-22 22:48:42 --> Helper loaded: url_helper
INFO - 2024-10-22 22:48:42 --> Helper loaded: file_helper
INFO - 2024-10-22 22:48:42 --> Helper loaded: form_helper
INFO - 2024-10-22 22:48:42 --> Helper loaded: my_helper
INFO - 2024-10-22 22:48:42 --> Database Driver Class Initialized
INFO - 2024-10-22 22:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 22:48:42 --> Controller Class Initialized
INFO - 2024-10-22 22:48:42 --> Helper loaded: cookie_helper
INFO - 2024-10-22 22:48:42 --> Config Class Initialized
INFO - 2024-10-22 22:48:42 --> Hooks Class Initialized
DEBUG - 2024-10-22 22:48:42 --> UTF-8 Support Enabled
INFO - 2024-10-22 22:48:42 --> Utf8 Class Initialized
INFO - 2024-10-22 22:48:42 --> URI Class Initialized
INFO - 2024-10-22 22:48:42 --> Router Class Initialized
INFO - 2024-10-22 22:48:42 --> Output Class Initialized
INFO - 2024-10-22 22:48:42 --> Security Class Initialized
DEBUG - 2024-10-22 22:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 22:48:42 --> Input Class Initialized
INFO - 2024-10-22 22:48:42 --> Language Class Initialized
INFO - 2024-10-22 22:48:42 --> Language Class Initialized
INFO - 2024-10-22 22:48:42 --> Config Class Initialized
INFO - 2024-10-22 22:48:42 --> Loader Class Initialized
INFO - 2024-10-22 22:48:42 --> Helper loaded: url_helper
INFO - 2024-10-22 22:48:42 --> Helper loaded: file_helper
INFO - 2024-10-22 22:48:42 --> Helper loaded: form_helper
INFO - 2024-10-22 22:48:42 --> Helper loaded: my_helper
INFO - 2024-10-22 22:48:42 --> Database Driver Class Initialized
INFO - 2024-10-22 22:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 22:48:42 --> Controller Class Initialized
ERROR - 2024-10-22 22:48:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT a.id_siswa,a.id_kelas,b.tingkat,a.ta FROM t_kelas_siswa a
                                                    INNER JOIN m_kelas b ON b.id = a.id_kelas
                                                    WHERE a.id_siswa = 
INFO - 2024-10-22 22:48:42 --> Language file loaded: language/english/db_lang.php
