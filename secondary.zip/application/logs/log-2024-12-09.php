<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-09 10:12:31 --> Config Class Initialized
INFO - 2024-12-09 10:12:31 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:12:32 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:12:32 --> Utf8 Class Initialized
INFO - 2024-12-09 10:12:32 --> URI Class Initialized
INFO - 2024-12-09 10:12:32 --> Router Class Initialized
INFO - 2024-12-09 10:12:32 --> Output Class Initialized
INFO - 2024-12-09 10:12:32 --> Security Class Initialized
DEBUG - 2024-12-09 10:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:12:32 --> Input Class Initialized
INFO - 2024-12-09 10:12:32 --> Language Class Initialized
INFO - 2024-12-09 10:12:32 --> Language Class Initialized
INFO - 2024-12-09 10:12:32 --> Config Class Initialized
INFO - 2024-12-09 10:12:32 --> Loader Class Initialized
INFO - 2024-12-09 10:12:32 --> Helper loaded: url_helper
INFO - 2024-12-09 10:12:32 --> Helper loaded: file_helper
INFO - 2024-12-09 10:12:32 --> Helper loaded: form_helper
INFO - 2024-12-09 10:12:32 --> Helper loaded: my_helper
INFO - 2024-12-09 10:12:32 --> Database Driver Class Initialized
INFO - 2024-12-09 10:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:12:32 --> Controller Class Initialized
DEBUG - 2024-12-09 10:12:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-09 10:12:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:12:32 --> Final output sent to browser
DEBUG - 2024-12-09 10:12:32 --> Total execution time: 0.0509
INFO - 2024-12-09 10:12:42 --> Config Class Initialized
INFO - 2024-12-09 10:12:42 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:12:42 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:12:42 --> Utf8 Class Initialized
INFO - 2024-12-09 10:12:42 --> URI Class Initialized
INFO - 2024-12-09 10:12:42 --> Router Class Initialized
INFO - 2024-12-09 10:12:42 --> Output Class Initialized
INFO - 2024-12-09 10:12:42 --> Security Class Initialized
DEBUG - 2024-12-09 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:12:42 --> Input Class Initialized
INFO - 2024-12-09 10:12:42 --> Language Class Initialized
INFO - 2024-12-09 10:12:42 --> Language Class Initialized
INFO - 2024-12-09 10:12:42 --> Config Class Initialized
INFO - 2024-12-09 10:12:42 --> Loader Class Initialized
INFO - 2024-12-09 10:12:42 --> Helper loaded: url_helper
INFO - 2024-12-09 10:12:42 --> Helper loaded: file_helper
INFO - 2024-12-09 10:12:42 --> Helper loaded: form_helper
INFO - 2024-12-09 10:12:42 --> Helper loaded: my_helper
INFO - 2024-12-09 10:12:42 --> Database Driver Class Initialized
INFO - 2024-12-09 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:12:42 --> Controller Class Initialized
INFO - 2024-12-09 10:12:42 --> Helper loaded: cookie_helper
INFO - 2024-12-09 10:12:42 --> Final output sent to browser
DEBUG - 2024-12-09 10:12:42 --> Total execution time: 0.1639
INFO - 2024-12-09 10:12:42 --> Config Class Initialized
INFO - 2024-12-09 10:12:42 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:12:42 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:12:42 --> Utf8 Class Initialized
INFO - 2024-12-09 10:12:42 --> URI Class Initialized
INFO - 2024-12-09 10:12:42 --> Router Class Initialized
INFO - 2024-12-09 10:12:42 --> Output Class Initialized
INFO - 2024-12-09 10:12:42 --> Security Class Initialized
DEBUG - 2024-12-09 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:12:42 --> Input Class Initialized
INFO - 2024-12-09 10:12:42 --> Language Class Initialized
INFO - 2024-12-09 10:12:42 --> Language Class Initialized
INFO - 2024-12-09 10:12:42 --> Config Class Initialized
INFO - 2024-12-09 10:12:42 --> Loader Class Initialized
INFO - 2024-12-09 10:12:42 --> Helper loaded: url_helper
INFO - 2024-12-09 10:12:42 --> Helper loaded: file_helper
INFO - 2024-12-09 10:12:42 --> Helper loaded: form_helper
INFO - 2024-12-09 10:12:42 --> Helper loaded: my_helper
INFO - 2024-12-09 10:12:42 --> Database Driver Class Initialized
INFO - 2024-12-09 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:12:42 --> Controller Class Initialized
DEBUG - 2024-12-09 10:12:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-09 10:12:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:12:43 --> Final output sent to browser
DEBUG - 2024-12-09 10:12:43 --> Total execution time: 0.2422
INFO - 2024-12-09 10:12:45 --> Config Class Initialized
INFO - 2024-12-09 10:12:45 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:12:45 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:12:45 --> Utf8 Class Initialized
INFO - 2024-12-09 10:12:45 --> URI Class Initialized
INFO - 2024-12-09 10:12:45 --> Router Class Initialized
INFO - 2024-12-09 10:12:45 --> Output Class Initialized
INFO - 2024-12-09 10:12:45 --> Security Class Initialized
DEBUG - 2024-12-09 10:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:12:45 --> Input Class Initialized
INFO - 2024-12-09 10:12:45 --> Language Class Initialized
INFO - 2024-12-09 10:12:45 --> Language Class Initialized
INFO - 2024-12-09 10:12:45 --> Config Class Initialized
INFO - 2024-12-09 10:12:45 --> Loader Class Initialized
INFO - 2024-12-09 10:12:45 --> Helper loaded: url_helper
INFO - 2024-12-09 10:12:45 --> Helper loaded: file_helper
INFO - 2024-12-09 10:12:45 --> Helper loaded: form_helper
INFO - 2024-12-09 10:12:45 --> Helper loaded: my_helper
INFO - 2024-12-09 10:12:45 --> Database Driver Class Initialized
INFO - 2024-12-09 10:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:12:45 --> Controller Class Initialized
DEBUG - 2024-12-09 10:12:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 10:12:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:12:45 --> Final output sent to browser
DEBUG - 2024-12-09 10:12:45 --> Total execution time: 0.0322
INFO - 2024-12-09 10:12:47 --> Config Class Initialized
INFO - 2024-12-09 10:12:47 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:12:47 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:12:47 --> Utf8 Class Initialized
INFO - 2024-12-09 10:12:47 --> URI Class Initialized
INFO - 2024-12-09 10:12:47 --> Router Class Initialized
INFO - 2024-12-09 10:12:47 --> Output Class Initialized
INFO - 2024-12-09 10:12:47 --> Security Class Initialized
DEBUG - 2024-12-09 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:12:47 --> Input Class Initialized
INFO - 2024-12-09 10:12:47 --> Language Class Initialized
INFO - 2024-12-09 10:12:47 --> Language Class Initialized
INFO - 2024-12-09 10:12:47 --> Config Class Initialized
INFO - 2024-12-09 10:12:47 --> Loader Class Initialized
INFO - 2024-12-09 10:12:47 --> Helper loaded: url_helper
INFO - 2024-12-09 10:12:47 --> Helper loaded: file_helper
INFO - 2024-12-09 10:12:47 --> Helper loaded: form_helper
INFO - 2024-12-09 10:12:47 --> Helper loaded: my_helper
INFO - 2024-12-09 10:12:47 --> Database Driver Class Initialized
INFO - 2024-12-09 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:12:47 --> Controller Class Initialized
DEBUG - 2024-12-09 10:12:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-09 10:12:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:12:47 --> Final output sent to browser
DEBUG - 2024-12-09 10:12:47 --> Total execution time: 0.0359
INFO - 2024-12-09 10:12:47 --> Config Class Initialized
INFO - 2024-12-09 10:12:47 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:12:47 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:12:47 --> Utf8 Class Initialized
INFO - 2024-12-09 10:12:47 --> URI Class Initialized
INFO - 2024-12-09 10:12:47 --> Router Class Initialized
INFO - 2024-12-09 10:12:47 --> Output Class Initialized
INFO - 2024-12-09 10:12:47 --> Security Class Initialized
DEBUG - 2024-12-09 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:12:47 --> Input Class Initialized
INFO - 2024-12-09 10:12:47 --> Language Class Initialized
INFO - 2024-12-09 10:12:47 --> Language Class Initialized
INFO - 2024-12-09 10:12:47 --> Config Class Initialized
INFO - 2024-12-09 10:12:47 --> Loader Class Initialized
INFO - 2024-12-09 10:12:47 --> Helper loaded: url_helper
INFO - 2024-12-09 10:12:47 --> Helper loaded: file_helper
INFO - 2024-12-09 10:12:47 --> Helper loaded: form_helper
INFO - 2024-12-09 10:12:47 --> Helper loaded: my_helper
INFO - 2024-12-09 10:12:47 --> Database Driver Class Initialized
INFO - 2024-12-09 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:12:47 --> Controller Class Initialized
INFO - 2024-12-09 10:13:00 --> Config Class Initialized
INFO - 2024-12-09 10:13:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:13:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:13:00 --> Utf8 Class Initialized
INFO - 2024-12-09 10:13:00 --> URI Class Initialized
INFO - 2024-12-09 10:13:00 --> Router Class Initialized
INFO - 2024-12-09 10:13:00 --> Output Class Initialized
INFO - 2024-12-09 10:13:00 --> Security Class Initialized
DEBUG - 2024-12-09 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:13:00 --> Input Class Initialized
INFO - 2024-12-09 10:13:00 --> Language Class Initialized
INFO - 2024-12-09 10:13:00 --> Language Class Initialized
INFO - 2024-12-09 10:13:00 --> Config Class Initialized
INFO - 2024-12-09 10:13:00 --> Loader Class Initialized
INFO - 2024-12-09 10:13:00 --> Helper loaded: url_helper
INFO - 2024-12-09 10:13:00 --> Helper loaded: file_helper
INFO - 2024-12-09 10:13:00 --> Helper loaded: form_helper
INFO - 2024-12-09 10:13:00 --> Helper loaded: my_helper
INFO - 2024-12-09 10:13:00 --> Database Driver Class Initialized
INFO - 2024-12-09 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:13:00 --> Controller Class Initialized
INFO - 2024-12-09 10:13:00 --> Final output sent to browser
DEBUG - 2024-12-09 10:13:00 --> Total execution time: 0.0374
INFO - 2024-12-09 10:13:03 --> Config Class Initialized
INFO - 2024-12-09 10:13:03 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:13:03 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:13:03 --> Utf8 Class Initialized
INFO - 2024-12-09 10:13:03 --> URI Class Initialized
INFO - 2024-12-09 10:13:03 --> Router Class Initialized
INFO - 2024-12-09 10:13:03 --> Output Class Initialized
INFO - 2024-12-09 10:13:03 --> Security Class Initialized
DEBUG - 2024-12-09 10:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:13:03 --> Input Class Initialized
INFO - 2024-12-09 10:13:03 --> Language Class Initialized
INFO - 2024-12-09 10:13:03 --> Language Class Initialized
INFO - 2024-12-09 10:13:03 --> Config Class Initialized
INFO - 2024-12-09 10:13:03 --> Loader Class Initialized
INFO - 2024-12-09 10:13:03 --> Helper loaded: url_helper
INFO - 2024-12-09 10:13:03 --> Helper loaded: file_helper
INFO - 2024-12-09 10:13:03 --> Helper loaded: form_helper
INFO - 2024-12-09 10:13:03 --> Helper loaded: my_helper
INFO - 2024-12-09 10:13:03 --> Database Driver Class Initialized
INFO - 2024-12-09 10:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:13:03 --> Controller Class Initialized
INFO - 2024-12-09 10:13:03 --> Final output sent to browser
DEBUG - 2024-12-09 10:13:03 --> Total execution time: 0.0367
INFO - 2024-12-09 10:13:05 --> Config Class Initialized
INFO - 2024-12-09 10:13:05 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:13:05 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:13:05 --> Utf8 Class Initialized
INFO - 2024-12-09 10:13:05 --> URI Class Initialized
INFO - 2024-12-09 10:13:05 --> Router Class Initialized
INFO - 2024-12-09 10:13:05 --> Output Class Initialized
INFO - 2024-12-09 10:13:05 --> Security Class Initialized
DEBUG - 2024-12-09 10:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:13:05 --> Input Class Initialized
INFO - 2024-12-09 10:13:05 --> Language Class Initialized
INFO - 2024-12-09 10:13:05 --> Language Class Initialized
INFO - 2024-12-09 10:13:05 --> Config Class Initialized
INFO - 2024-12-09 10:13:05 --> Loader Class Initialized
INFO - 2024-12-09 10:13:05 --> Helper loaded: url_helper
INFO - 2024-12-09 10:13:05 --> Helper loaded: file_helper
INFO - 2024-12-09 10:13:05 --> Helper loaded: form_helper
INFO - 2024-12-09 10:13:05 --> Helper loaded: my_helper
INFO - 2024-12-09 10:13:05 --> Database Driver Class Initialized
INFO - 2024-12-09 10:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:13:05 --> Controller Class Initialized
INFO - 2024-12-09 10:13:05 --> Final output sent to browser
DEBUG - 2024-12-09 10:13:05 --> Total execution time: 0.0432
INFO - 2024-12-09 10:16:11 --> Config Class Initialized
INFO - 2024-12-09 10:16:11 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:16:11 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:16:11 --> Utf8 Class Initialized
INFO - 2024-12-09 10:16:11 --> URI Class Initialized
INFO - 2024-12-09 10:16:11 --> Router Class Initialized
INFO - 2024-12-09 10:16:11 --> Output Class Initialized
INFO - 2024-12-09 10:16:11 --> Security Class Initialized
DEBUG - 2024-12-09 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:16:11 --> Input Class Initialized
INFO - 2024-12-09 10:16:11 --> Language Class Initialized
INFO - 2024-12-09 10:16:11 --> Language Class Initialized
INFO - 2024-12-09 10:16:11 --> Config Class Initialized
INFO - 2024-12-09 10:16:11 --> Loader Class Initialized
INFO - 2024-12-09 10:16:11 --> Helper loaded: url_helper
INFO - 2024-12-09 10:16:11 --> Helper loaded: file_helper
INFO - 2024-12-09 10:16:11 --> Helper loaded: form_helper
INFO - 2024-12-09 10:16:11 --> Helper loaded: my_helper
INFO - 2024-12-09 10:16:11 --> Database Driver Class Initialized
INFO - 2024-12-09 10:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:16:11 --> Controller Class Initialized
INFO - 2024-12-09 10:16:11 --> Final output sent to browser
DEBUG - 2024-12-09 10:16:11 --> Total execution time: 0.0612
INFO - 2024-12-09 10:17:03 --> Config Class Initialized
INFO - 2024-12-09 10:17:03 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:17:03 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:17:03 --> Utf8 Class Initialized
INFO - 2024-12-09 10:17:03 --> URI Class Initialized
INFO - 2024-12-09 10:17:03 --> Router Class Initialized
INFO - 2024-12-09 10:17:03 --> Output Class Initialized
INFO - 2024-12-09 10:17:03 --> Security Class Initialized
DEBUG - 2024-12-09 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:17:03 --> Input Class Initialized
INFO - 2024-12-09 10:17:03 --> Language Class Initialized
INFO - 2024-12-09 10:17:03 --> Language Class Initialized
INFO - 2024-12-09 10:17:03 --> Config Class Initialized
INFO - 2024-12-09 10:17:03 --> Loader Class Initialized
INFO - 2024-12-09 10:17:03 --> Helper loaded: url_helper
INFO - 2024-12-09 10:17:03 --> Helper loaded: file_helper
INFO - 2024-12-09 10:17:03 --> Helper loaded: form_helper
INFO - 2024-12-09 10:17:03 --> Helper loaded: my_helper
INFO - 2024-12-09 10:17:03 --> Database Driver Class Initialized
INFO - 2024-12-09 10:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:17:03 --> Controller Class Initialized
INFO - 2024-12-09 10:17:03 --> Final output sent to browser
DEBUG - 2024-12-09 10:17:03 --> Total execution time: 0.0413
INFO - 2024-12-09 10:24:02 --> Config Class Initialized
INFO - 2024-12-09 10:24:02 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:24:02 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:24:02 --> Utf8 Class Initialized
INFO - 2024-12-09 10:24:02 --> URI Class Initialized
INFO - 2024-12-09 10:24:02 --> Router Class Initialized
INFO - 2024-12-09 10:24:02 --> Output Class Initialized
INFO - 2024-12-09 10:24:02 --> Security Class Initialized
DEBUG - 2024-12-09 10:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:24:02 --> Input Class Initialized
INFO - 2024-12-09 10:24:02 --> Language Class Initialized
INFO - 2024-12-09 10:24:02 --> Language Class Initialized
INFO - 2024-12-09 10:24:02 --> Config Class Initialized
INFO - 2024-12-09 10:24:02 --> Loader Class Initialized
INFO - 2024-12-09 10:24:02 --> Helper loaded: url_helper
INFO - 2024-12-09 10:24:02 --> Helper loaded: file_helper
INFO - 2024-12-09 10:24:02 --> Helper loaded: form_helper
INFO - 2024-12-09 10:24:02 --> Helper loaded: my_helper
INFO - 2024-12-09 10:24:02 --> Database Driver Class Initialized
INFO - 2024-12-09 10:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:24:02 --> Controller Class Initialized
INFO - 2024-12-09 10:24:02 --> Final output sent to browser
DEBUG - 2024-12-09 10:24:02 --> Total execution time: 0.1015
INFO - 2024-12-09 10:24:49 --> Config Class Initialized
INFO - 2024-12-09 10:24:49 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:24:49 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:24:49 --> Utf8 Class Initialized
INFO - 2024-12-09 10:24:49 --> URI Class Initialized
INFO - 2024-12-09 10:24:49 --> Router Class Initialized
INFO - 2024-12-09 10:24:49 --> Output Class Initialized
INFO - 2024-12-09 10:24:49 --> Security Class Initialized
DEBUG - 2024-12-09 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:24:49 --> Input Class Initialized
INFO - 2024-12-09 10:24:49 --> Language Class Initialized
INFO - 2024-12-09 10:24:49 --> Language Class Initialized
INFO - 2024-12-09 10:24:49 --> Config Class Initialized
INFO - 2024-12-09 10:24:49 --> Loader Class Initialized
INFO - 2024-12-09 10:24:49 --> Helper loaded: url_helper
INFO - 2024-12-09 10:24:49 --> Helper loaded: file_helper
INFO - 2024-12-09 10:24:49 --> Helper loaded: form_helper
INFO - 2024-12-09 10:24:49 --> Helper loaded: my_helper
INFO - 2024-12-09 10:24:49 --> Database Driver Class Initialized
INFO - 2024-12-09 10:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:24:49 --> Controller Class Initialized
INFO - 2024-12-09 10:24:49 --> Final output sent to browser
DEBUG - 2024-12-09 10:24:49 --> Total execution time: 0.6256
INFO - 2024-12-09 10:27:18 --> Config Class Initialized
INFO - 2024-12-09 10:27:18 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:27:18 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:27:18 --> Utf8 Class Initialized
INFO - 2024-12-09 10:27:18 --> URI Class Initialized
INFO - 2024-12-09 10:27:18 --> Router Class Initialized
INFO - 2024-12-09 10:27:18 --> Output Class Initialized
INFO - 2024-12-09 10:27:18 --> Security Class Initialized
DEBUG - 2024-12-09 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:27:18 --> Input Class Initialized
INFO - 2024-12-09 10:27:18 --> Language Class Initialized
INFO - 2024-12-09 10:27:18 --> Language Class Initialized
INFO - 2024-12-09 10:27:18 --> Config Class Initialized
INFO - 2024-12-09 10:27:18 --> Loader Class Initialized
INFO - 2024-12-09 10:27:18 --> Helper loaded: url_helper
INFO - 2024-12-09 10:27:18 --> Helper loaded: file_helper
INFO - 2024-12-09 10:27:18 --> Helper loaded: form_helper
INFO - 2024-12-09 10:27:18 --> Helper loaded: my_helper
INFO - 2024-12-09 10:27:18 --> Database Driver Class Initialized
INFO - 2024-12-09 10:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:27:18 --> Controller Class Initialized
INFO - 2024-12-09 10:27:18 --> Final output sent to browser
DEBUG - 2024-12-09 10:27:18 --> Total execution time: 0.2169
INFO - 2024-12-09 10:27:58 --> Config Class Initialized
INFO - 2024-12-09 10:27:58 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:27:58 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:27:58 --> Utf8 Class Initialized
INFO - 2024-12-09 10:27:58 --> URI Class Initialized
INFO - 2024-12-09 10:27:58 --> Router Class Initialized
INFO - 2024-12-09 10:27:58 --> Output Class Initialized
INFO - 2024-12-09 10:27:58 --> Security Class Initialized
DEBUG - 2024-12-09 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:27:58 --> Input Class Initialized
INFO - 2024-12-09 10:27:58 --> Language Class Initialized
INFO - 2024-12-09 10:27:58 --> Language Class Initialized
INFO - 2024-12-09 10:27:58 --> Config Class Initialized
INFO - 2024-12-09 10:27:58 --> Loader Class Initialized
INFO - 2024-12-09 10:27:58 --> Helper loaded: url_helper
INFO - 2024-12-09 10:27:58 --> Helper loaded: file_helper
INFO - 2024-12-09 10:27:58 --> Helper loaded: form_helper
INFO - 2024-12-09 10:27:58 --> Helper loaded: my_helper
INFO - 2024-12-09 10:27:58 --> Database Driver Class Initialized
INFO - 2024-12-09 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:27:58 --> Controller Class Initialized
INFO - 2024-12-09 10:27:58 --> Final output sent to browser
DEBUG - 2024-12-09 10:27:58 --> Total execution time: 0.0825
INFO - 2024-12-09 10:28:11 --> Config Class Initialized
INFO - 2024-12-09 10:28:11 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:28:11 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:28:11 --> Utf8 Class Initialized
INFO - 2024-12-09 10:28:11 --> URI Class Initialized
INFO - 2024-12-09 10:28:11 --> Router Class Initialized
INFO - 2024-12-09 10:28:11 --> Output Class Initialized
INFO - 2024-12-09 10:28:11 --> Security Class Initialized
DEBUG - 2024-12-09 10:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:28:11 --> Input Class Initialized
INFO - 2024-12-09 10:28:11 --> Language Class Initialized
INFO - 2024-12-09 10:28:11 --> Language Class Initialized
INFO - 2024-12-09 10:28:11 --> Config Class Initialized
INFO - 2024-12-09 10:28:11 --> Loader Class Initialized
INFO - 2024-12-09 10:28:11 --> Helper loaded: url_helper
INFO - 2024-12-09 10:28:11 --> Helper loaded: file_helper
INFO - 2024-12-09 10:28:11 --> Helper loaded: form_helper
INFO - 2024-12-09 10:28:11 --> Helper loaded: my_helper
INFO - 2024-12-09 10:28:11 --> Database Driver Class Initialized
INFO - 2024-12-09 10:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:28:11 --> Controller Class Initialized
INFO - 2024-12-09 10:28:11 --> Final output sent to browser
DEBUG - 2024-12-09 10:28:11 --> Total execution time: 0.0548
INFO - 2024-12-09 10:28:14 --> Config Class Initialized
INFO - 2024-12-09 10:28:14 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:28:14 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:28:14 --> Utf8 Class Initialized
INFO - 2024-12-09 10:28:14 --> URI Class Initialized
INFO - 2024-12-09 10:28:14 --> Router Class Initialized
INFO - 2024-12-09 10:28:14 --> Output Class Initialized
INFO - 2024-12-09 10:28:14 --> Security Class Initialized
DEBUG - 2024-12-09 10:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:28:14 --> Input Class Initialized
INFO - 2024-12-09 10:28:14 --> Language Class Initialized
INFO - 2024-12-09 10:28:14 --> Language Class Initialized
INFO - 2024-12-09 10:28:14 --> Config Class Initialized
INFO - 2024-12-09 10:28:14 --> Loader Class Initialized
INFO - 2024-12-09 10:28:14 --> Helper loaded: url_helper
INFO - 2024-12-09 10:28:14 --> Helper loaded: file_helper
INFO - 2024-12-09 10:28:14 --> Helper loaded: form_helper
INFO - 2024-12-09 10:28:14 --> Helper loaded: my_helper
INFO - 2024-12-09 10:28:14 --> Database Driver Class Initialized
INFO - 2024-12-09 10:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:28:14 --> Controller Class Initialized
DEBUG - 2024-12-09 10:28:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-09 10:28:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:28:14 --> Final output sent to browser
DEBUG - 2024-12-09 10:28:14 --> Total execution time: 0.0318
INFO - 2024-12-09 10:28:14 --> Config Class Initialized
INFO - 2024-12-09 10:28:14 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:28:14 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:28:14 --> Utf8 Class Initialized
INFO - 2024-12-09 10:28:14 --> URI Class Initialized
INFO - 2024-12-09 10:28:14 --> Router Class Initialized
INFO - 2024-12-09 10:28:14 --> Output Class Initialized
INFO - 2024-12-09 10:28:14 --> Security Class Initialized
DEBUG - 2024-12-09 10:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:28:14 --> Input Class Initialized
INFO - 2024-12-09 10:28:14 --> Language Class Initialized
INFO - 2024-12-09 10:28:14 --> Language Class Initialized
INFO - 2024-12-09 10:28:14 --> Config Class Initialized
INFO - 2024-12-09 10:28:14 --> Loader Class Initialized
INFO - 2024-12-09 10:28:14 --> Helper loaded: url_helper
INFO - 2024-12-09 10:28:14 --> Helper loaded: file_helper
INFO - 2024-12-09 10:28:14 --> Helper loaded: form_helper
INFO - 2024-12-09 10:28:14 --> Helper loaded: my_helper
INFO - 2024-12-09 10:28:14 --> Database Driver Class Initialized
INFO - 2024-12-09 10:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:28:14 --> Controller Class Initialized
INFO - 2024-12-09 10:28:17 --> Config Class Initialized
INFO - 2024-12-09 10:28:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:28:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:28:17 --> Utf8 Class Initialized
INFO - 2024-12-09 10:28:17 --> URI Class Initialized
INFO - 2024-12-09 10:28:17 --> Router Class Initialized
INFO - 2024-12-09 10:28:17 --> Output Class Initialized
INFO - 2024-12-09 10:28:17 --> Security Class Initialized
DEBUG - 2024-12-09 10:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:28:17 --> Input Class Initialized
INFO - 2024-12-09 10:28:17 --> Language Class Initialized
INFO - 2024-12-09 10:28:17 --> Language Class Initialized
INFO - 2024-12-09 10:28:17 --> Config Class Initialized
INFO - 2024-12-09 10:28:17 --> Loader Class Initialized
INFO - 2024-12-09 10:28:17 --> Helper loaded: url_helper
INFO - 2024-12-09 10:28:17 --> Helper loaded: file_helper
INFO - 2024-12-09 10:28:17 --> Helper loaded: form_helper
INFO - 2024-12-09 10:28:17 --> Helper loaded: my_helper
INFO - 2024-12-09 10:28:17 --> Database Driver Class Initialized
INFO - 2024-12-09 10:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:28:17 --> Controller Class Initialized
INFO - 2024-12-09 10:28:17 --> Final output sent to browser
DEBUG - 2024-12-09 10:28:17 --> Total execution time: 0.0325
INFO - 2024-12-09 10:28:20 --> Config Class Initialized
INFO - 2024-12-09 10:28:20 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:28:20 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:28:20 --> Utf8 Class Initialized
INFO - 2024-12-09 10:28:20 --> URI Class Initialized
INFO - 2024-12-09 10:28:20 --> Router Class Initialized
INFO - 2024-12-09 10:28:20 --> Output Class Initialized
INFO - 2024-12-09 10:28:20 --> Security Class Initialized
DEBUG - 2024-12-09 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:28:20 --> Input Class Initialized
INFO - 2024-12-09 10:28:20 --> Language Class Initialized
INFO - 2024-12-09 10:28:20 --> Language Class Initialized
INFO - 2024-12-09 10:28:20 --> Config Class Initialized
INFO - 2024-12-09 10:28:20 --> Loader Class Initialized
INFO - 2024-12-09 10:28:20 --> Helper loaded: url_helper
INFO - 2024-12-09 10:28:20 --> Helper loaded: file_helper
INFO - 2024-12-09 10:28:20 --> Helper loaded: form_helper
INFO - 2024-12-09 10:28:20 --> Helper loaded: my_helper
INFO - 2024-12-09 10:28:20 --> Database Driver Class Initialized
INFO - 2024-12-09 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:28:20 --> Controller Class Initialized
INFO - 2024-12-09 10:28:20 --> Final output sent to browser
DEBUG - 2024-12-09 10:28:20 --> Total execution time: 0.0299
INFO - 2024-12-09 10:50:10 --> Config Class Initialized
INFO - 2024-12-09 10:50:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:50:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:50:10 --> Utf8 Class Initialized
INFO - 2024-12-09 10:50:10 --> URI Class Initialized
INFO - 2024-12-09 10:50:10 --> Router Class Initialized
INFO - 2024-12-09 10:50:10 --> Output Class Initialized
INFO - 2024-12-09 10:50:10 --> Security Class Initialized
DEBUG - 2024-12-09 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:50:10 --> Input Class Initialized
INFO - 2024-12-09 10:50:10 --> Language Class Initialized
INFO - 2024-12-09 10:50:10 --> Language Class Initialized
INFO - 2024-12-09 10:50:10 --> Config Class Initialized
INFO - 2024-12-09 10:50:10 --> Loader Class Initialized
INFO - 2024-12-09 10:50:10 --> Helper loaded: url_helper
INFO - 2024-12-09 10:50:10 --> Helper loaded: file_helper
INFO - 2024-12-09 10:50:10 --> Helper loaded: form_helper
INFO - 2024-12-09 10:50:10 --> Helper loaded: my_helper
INFO - 2024-12-09 10:50:10 --> Database Driver Class Initialized
INFO - 2024-12-09 10:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:50:10 --> Controller Class Initialized
DEBUG - 2024-12-09 10:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-09 10:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:50:10 --> Final output sent to browser
DEBUG - 2024-12-09 10:50:10 --> Total execution time: 0.0560
INFO - 2024-12-09 10:50:10 --> Config Class Initialized
INFO - 2024-12-09 10:50:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:50:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:50:10 --> Utf8 Class Initialized
INFO - 2024-12-09 10:50:10 --> URI Class Initialized
INFO - 2024-12-09 10:50:10 --> Router Class Initialized
INFO - 2024-12-09 10:50:10 --> Output Class Initialized
INFO - 2024-12-09 10:50:10 --> Security Class Initialized
DEBUG - 2024-12-09 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:50:10 --> Input Class Initialized
INFO - 2024-12-09 10:50:10 --> Language Class Initialized
INFO - 2024-12-09 10:50:10 --> Language Class Initialized
INFO - 2024-12-09 10:50:10 --> Config Class Initialized
INFO - 2024-12-09 10:50:10 --> Loader Class Initialized
INFO - 2024-12-09 10:50:10 --> Helper loaded: url_helper
INFO - 2024-12-09 10:50:10 --> Helper loaded: file_helper
INFO - 2024-12-09 10:50:10 --> Helper loaded: form_helper
INFO - 2024-12-09 10:50:10 --> Helper loaded: my_helper
INFO - 2024-12-09 10:50:10 --> Database Driver Class Initialized
INFO - 2024-12-09 10:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:50:10 --> Controller Class Initialized
INFO - 2024-12-09 10:50:14 --> Config Class Initialized
INFO - 2024-12-09 10:50:14 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:50:14 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:50:14 --> Utf8 Class Initialized
INFO - 2024-12-09 10:50:14 --> URI Class Initialized
INFO - 2024-12-09 10:50:14 --> Router Class Initialized
INFO - 2024-12-09 10:50:14 --> Output Class Initialized
INFO - 2024-12-09 10:50:14 --> Security Class Initialized
DEBUG - 2024-12-09 10:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:50:14 --> Input Class Initialized
INFO - 2024-12-09 10:50:14 --> Language Class Initialized
INFO - 2024-12-09 10:50:14 --> Language Class Initialized
INFO - 2024-12-09 10:50:14 --> Config Class Initialized
INFO - 2024-12-09 10:50:14 --> Loader Class Initialized
INFO - 2024-12-09 10:50:14 --> Helper loaded: url_helper
INFO - 2024-12-09 10:50:14 --> Helper loaded: file_helper
INFO - 2024-12-09 10:50:14 --> Helper loaded: form_helper
INFO - 2024-12-09 10:50:14 --> Helper loaded: my_helper
INFO - 2024-12-09 10:50:14 --> Database Driver Class Initialized
INFO - 2024-12-09 10:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:50:14 --> Controller Class Initialized
INFO - 2024-12-09 10:50:14 --> Final output sent to browser
DEBUG - 2024-12-09 10:50:14 --> Total execution time: 0.0374
INFO - 2024-12-09 10:51:43 --> Config Class Initialized
INFO - 2024-12-09 10:51:43 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:51:43 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:51:43 --> Utf8 Class Initialized
INFO - 2024-12-09 10:51:43 --> URI Class Initialized
INFO - 2024-12-09 10:51:43 --> Router Class Initialized
INFO - 2024-12-09 10:51:43 --> Output Class Initialized
INFO - 2024-12-09 10:51:43 --> Security Class Initialized
DEBUG - 2024-12-09 10:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:51:43 --> Input Class Initialized
INFO - 2024-12-09 10:51:43 --> Language Class Initialized
INFO - 2024-12-09 10:51:43 --> Language Class Initialized
INFO - 2024-12-09 10:51:43 --> Config Class Initialized
INFO - 2024-12-09 10:51:43 --> Loader Class Initialized
INFO - 2024-12-09 10:51:43 --> Helper loaded: url_helper
INFO - 2024-12-09 10:51:43 --> Helper loaded: file_helper
INFO - 2024-12-09 10:51:43 --> Helper loaded: form_helper
INFO - 2024-12-09 10:51:43 --> Helper loaded: my_helper
INFO - 2024-12-09 10:51:43 --> Database Driver Class Initialized
INFO - 2024-12-09 10:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:51:43 --> Controller Class Initialized
INFO - 2024-12-09 10:51:43 --> Final output sent to browser
DEBUG - 2024-12-09 10:51:43 --> Total execution time: 0.5102
INFO - 2024-12-09 10:52:43 --> Config Class Initialized
INFO - 2024-12-09 10:52:43 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:52:43 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:52:43 --> Utf8 Class Initialized
INFO - 2024-12-09 10:52:43 --> URI Class Initialized
INFO - 2024-12-09 10:52:43 --> Router Class Initialized
INFO - 2024-12-09 10:52:43 --> Output Class Initialized
INFO - 2024-12-09 10:52:43 --> Security Class Initialized
DEBUG - 2024-12-09 10:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:52:43 --> Input Class Initialized
INFO - 2024-12-09 10:52:43 --> Language Class Initialized
INFO - 2024-12-09 10:52:43 --> Language Class Initialized
INFO - 2024-12-09 10:52:43 --> Config Class Initialized
INFO - 2024-12-09 10:52:43 --> Loader Class Initialized
INFO - 2024-12-09 10:52:43 --> Helper loaded: url_helper
INFO - 2024-12-09 10:52:43 --> Helper loaded: file_helper
INFO - 2024-12-09 10:52:43 --> Helper loaded: form_helper
INFO - 2024-12-09 10:52:43 --> Helper loaded: my_helper
INFO - 2024-12-09 10:52:43 --> Database Driver Class Initialized
INFO - 2024-12-09 10:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:52:43 --> Controller Class Initialized
INFO - 2024-12-09 10:52:44 --> Final output sent to browser
DEBUG - 2024-12-09 10:52:44 --> Total execution time: 0.5618
INFO - 2024-12-09 10:52:47 --> Config Class Initialized
INFO - 2024-12-09 10:52:47 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:52:47 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:52:47 --> Utf8 Class Initialized
INFO - 2024-12-09 10:52:47 --> URI Class Initialized
INFO - 2024-12-09 10:52:47 --> Router Class Initialized
INFO - 2024-12-09 10:52:47 --> Output Class Initialized
INFO - 2024-12-09 10:52:47 --> Security Class Initialized
DEBUG - 2024-12-09 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:52:47 --> Input Class Initialized
INFO - 2024-12-09 10:52:47 --> Language Class Initialized
INFO - 2024-12-09 10:52:47 --> Language Class Initialized
INFO - 2024-12-09 10:52:47 --> Config Class Initialized
INFO - 2024-12-09 10:52:47 --> Loader Class Initialized
INFO - 2024-12-09 10:52:47 --> Helper loaded: url_helper
INFO - 2024-12-09 10:52:47 --> Helper loaded: file_helper
INFO - 2024-12-09 10:52:47 --> Helper loaded: form_helper
INFO - 2024-12-09 10:52:47 --> Helper loaded: my_helper
INFO - 2024-12-09 10:52:47 --> Database Driver Class Initialized
INFO - 2024-12-09 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:52:47 --> Controller Class Initialized
INFO - 2024-12-09 10:52:47 --> Final output sent to browser
DEBUG - 2024-12-09 10:52:47 --> Total execution time: 0.0326
INFO - 2024-12-09 10:53:06 --> Config Class Initialized
INFO - 2024-12-09 10:53:06 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:53:06 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:53:06 --> Utf8 Class Initialized
INFO - 2024-12-09 10:53:06 --> URI Class Initialized
INFO - 2024-12-09 10:53:06 --> Router Class Initialized
INFO - 2024-12-09 10:53:06 --> Output Class Initialized
INFO - 2024-12-09 10:53:06 --> Security Class Initialized
DEBUG - 2024-12-09 10:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:53:06 --> Input Class Initialized
INFO - 2024-12-09 10:53:06 --> Language Class Initialized
INFO - 2024-12-09 10:53:06 --> Language Class Initialized
INFO - 2024-12-09 10:53:06 --> Config Class Initialized
INFO - 2024-12-09 10:53:06 --> Loader Class Initialized
INFO - 2024-12-09 10:53:06 --> Helper loaded: url_helper
INFO - 2024-12-09 10:53:06 --> Helper loaded: file_helper
INFO - 2024-12-09 10:53:06 --> Helper loaded: form_helper
INFO - 2024-12-09 10:53:06 --> Helper loaded: my_helper
INFO - 2024-12-09 10:53:06 --> Database Driver Class Initialized
INFO - 2024-12-09 10:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:53:06 --> Controller Class Initialized
DEBUG - 2024-12-09 10:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 10:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:53:06 --> Final output sent to browser
DEBUG - 2024-12-09 10:53:06 --> Total execution time: 0.0667
INFO - 2024-12-09 10:53:08 --> Config Class Initialized
INFO - 2024-12-09 10:53:08 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:53:08 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:53:08 --> Utf8 Class Initialized
INFO - 2024-12-09 10:53:08 --> URI Class Initialized
INFO - 2024-12-09 10:53:08 --> Router Class Initialized
INFO - 2024-12-09 10:53:08 --> Output Class Initialized
INFO - 2024-12-09 10:53:08 --> Security Class Initialized
DEBUG - 2024-12-09 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:53:08 --> Input Class Initialized
INFO - 2024-12-09 10:53:08 --> Language Class Initialized
INFO - 2024-12-09 10:53:08 --> Language Class Initialized
INFO - 2024-12-09 10:53:08 --> Config Class Initialized
INFO - 2024-12-09 10:53:08 --> Loader Class Initialized
INFO - 2024-12-09 10:53:08 --> Helper loaded: url_helper
INFO - 2024-12-09 10:53:08 --> Helper loaded: file_helper
INFO - 2024-12-09 10:53:08 --> Helper loaded: form_helper
INFO - 2024-12-09 10:53:08 --> Helper loaded: my_helper
INFO - 2024-12-09 10:53:08 --> Database Driver Class Initialized
INFO - 2024-12-09 10:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:53:08 --> Controller Class Initialized
DEBUG - 2024-12-09 10:53:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-12-09 10:53:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:53:08 --> Final output sent to browser
DEBUG - 2024-12-09 10:53:08 --> Total execution time: 0.0340
INFO - 2024-12-09 10:53:43 --> Config Class Initialized
INFO - 2024-12-09 10:53:43 --> Hooks Class Initialized
DEBUG - 2024-12-09 10:53:43 --> UTF-8 Support Enabled
INFO - 2024-12-09 10:53:43 --> Utf8 Class Initialized
INFO - 2024-12-09 10:53:43 --> URI Class Initialized
INFO - 2024-12-09 10:53:43 --> Router Class Initialized
INFO - 2024-12-09 10:53:43 --> Output Class Initialized
INFO - 2024-12-09 10:53:43 --> Security Class Initialized
DEBUG - 2024-12-09 10:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 10:53:43 --> Input Class Initialized
INFO - 2024-12-09 10:53:43 --> Language Class Initialized
INFO - 2024-12-09 10:53:43 --> Language Class Initialized
INFO - 2024-12-09 10:53:43 --> Config Class Initialized
INFO - 2024-12-09 10:53:43 --> Loader Class Initialized
INFO - 2024-12-09 10:53:43 --> Helper loaded: url_helper
INFO - 2024-12-09 10:53:43 --> Helper loaded: file_helper
INFO - 2024-12-09 10:53:43 --> Helper loaded: form_helper
INFO - 2024-12-09 10:53:43 --> Helper loaded: my_helper
INFO - 2024-12-09 10:53:43 --> Database Driver Class Initialized
INFO - 2024-12-09 10:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 10:53:43 --> Controller Class Initialized
DEBUG - 2024-12-09 10:53:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 10:53:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 10:53:43 --> Final output sent to browser
DEBUG - 2024-12-09 10:53:43 --> Total execution time: 0.0335
INFO - 2024-12-09 12:06:35 --> Config Class Initialized
INFO - 2024-12-09 12:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:35 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:35 --> URI Class Initialized
DEBUG - 2024-12-09 12:06:35 --> No URI present. Default controller set.
INFO - 2024-12-09 12:06:35 --> Router Class Initialized
INFO - 2024-12-09 12:06:35 --> Output Class Initialized
INFO - 2024-12-09 12:06:35 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:35 --> Input Class Initialized
INFO - 2024-12-09 12:06:35 --> Language Class Initialized
INFO - 2024-12-09 12:06:35 --> Language Class Initialized
INFO - 2024-12-09 12:06:35 --> Config Class Initialized
INFO - 2024-12-09 12:06:35 --> Loader Class Initialized
INFO - 2024-12-09 12:06:35 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:35 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:35 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:35 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:35 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:35 --> Controller Class Initialized
INFO - 2024-12-09 12:06:35 --> Config Class Initialized
INFO - 2024-12-09 12:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:35 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:35 --> URI Class Initialized
INFO - 2024-12-09 12:06:35 --> Router Class Initialized
INFO - 2024-12-09 12:06:35 --> Output Class Initialized
INFO - 2024-12-09 12:06:35 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:35 --> Input Class Initialized
INFO - 2024-12-09 12:06:35 --> Language Class Initialized
INFO - 2024-12-09 12:06:35 --> Language Class Initialized
INFO - 2024-12-09 12:06:35 --> Config Class Initialized
INFO - 2024-12-09 12:06:35 --> Loader Class Initialized
INFO - 2024-12-09 12:06:35 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:35 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:35 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:35 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:35 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:35 --> Controller Class Initialized
DEBUG - 2024-12-09 12:06:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-09 12:06:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:06:35 --> Final output sent to browser
DEBUG - 2024-12-09 12:06:35 --> Total execution time: 0.0327
INFO - 2024-12-09 12:06:44 --> Config Class Initialized
INFO - 2024-12-09 12:06:44 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:44 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:44 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:44 --> URI Class Initialized
INFO - 2024-12-09 12:06:44 --> Router Class Initialized
INFO - 2024-12-09 12:06:44 --> Output Class Initialized
INFO - 2024-12-09 12:06:44 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:44 --> Input Class Initialized
INFO - 2024-12-09 12:06:44 --> Language Class Initialized
INFO - 2024-12-09 12:06:44 --> Language Class Initialized
INFO - 2024-12-09 12:06:44 --> Config Class Initialized
INFO - 2024-12-09 12:06:44 --> Loader Class Initialized
INFO - 2024-12-09 12:06:44 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:44 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:44 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:44 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:44 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:44 --> Controller Class Initialized
INFO - 2024-12-09 12:06:44 --> Helper loaded: cookie_helper
INFO - 2024-12-09 12:06:44 --> Final output sent to browser
DEBUG - 2024-12-09 12:06:44 --> Total execution time: 0.0371
INFO - 2024-12-09 12:06:44 --> Config Class Initialized
INFO - 2024-12-09 12:06:44 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:44 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:44 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:44 --> URI Class Initialized
INFO - 2024-12-09 12:06:44 --> Router Class Initialized
INFO - 2024-12-09 12:06:44 --> Output Class Initialized
INFO - 2024-12-09 12:06:44 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:44 --> Input Class Initialized
INFO - 2024-12-09 12:06:44 --> Language Class Initialized
INFO - 2024-12-09 12:06:44 --> Language Class Initialized
INFO - 2024-12-09 12:06:44 --> Config Class Initialized
INFO - 2024-12-09 12:06:44 --> Loader Class Initialized
INFO - 2024-12-09 12:06:44 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:44 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:44 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:44 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:44 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:44 --> Controller Class Initialized
DEBUG - 2024-12-09 12:06:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-09 12:06:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:06:45 --> Final output sent to browser
DEBUG - 2024-12-09 12:06:45 --> Total execution time: 0.0356
INFO - 2024-12-09 12:06:55 --> Config Class Initialized
INFO - 2024-12-09 12:06:55 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:55 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:55 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:55 --> URI Class Initialized
INFO - 2024-12-09 12:06:55 --> Router Class Initialized
INFO - 2024-12-09 12:06:55 --> Output Class Initialized
INFO - 2024-12-09 12:06:55 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:55 --> Input Class Initialized
INFO - 2024-12-09 12:06:55 --> Language Class Initialized
INFO - 2024-12-09 12:06:55 --> Language Class Initialized
INFO - 2024-12-09 12:06:55 --> Config Class Initialized
INFO - 2024-12-09 12:06:55 --> Loader Class Initialized
INFO - 2024-12-09 12:06:55 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:55 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:55 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:55 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:55 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:55 --> Controller Class Initialized
DEBUG - 2024-12-09 12:06:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 12:06:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:06:55 --> Final output sent to browser
DEBUG - 2024-12-09 12:06:55 --> Total execution time: 0.0312
INFO - 2024-12-09 12:06:58 --> Config Class Initialized
INFO - 2024-12-09 12:06:58 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:58 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:58 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:58 --> URI Class Initialized
INFO - 2024-12-09 12:06:58 --> Router Class Initialized
INFO - 2024-12-09 12:06:58 --> Output Class Initialized
INFO - 2024-12-09 12:06:58 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:58 --> Input Class Initialized
INFO - 2024-12-09 12:06:58 --> Language Class Initialized
INFO - 2024-12-09 12:06:58 --> Language Class Initialized
INFO - 2024-12-09 12:06:58 --> Config Class Initialized
INFO - 2024-12-09 12:06:58 --> Loader Class Initialized
INFO - 2024-12-09 12:06:58 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:58 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:58 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:58 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:58 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:58 --> Controller Class Initialized
DEBUG - 2024-12-09 12:06:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-09 12:06:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:06:58 --> Final output sent to browser
DEBUG - 2024-12-09 12:06:58 --> Total execution time: 0.0324
INFO - 2024-12-09 12:06:59 --> Config Class Initialized
INFO - 2024-12-09 12:06:59 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:06:59 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:06:59 --> Utf8 Class Initialized
INFO - 2024-12-09 12:06:59 --> URI Class Initialized
INFO - 2024-12-09 12:06:59 --> Router Class Initialized
INFO - 2024-12-09 12:06:59 --> Output Class Initialized
INFO - 2024-12-09 12:06:59 --> Security Class Initialized
DEBUG - 2024-12-09 12:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:06:59 --> Input Class Initialized
INFO - 2024-12-09 12:06:59 --> Language Class Initialized
INFO - 2024-12-09 12:06:59 --> Language Class Initialized
INFO - 2024-12-09 12:06:59 --> Config Class Initialized
INFO - 2024-12-09 12:06:59 --> Loader Class Initialized
INFO - 2024-12-09 12:06:59 --> Helper loaded: url_helper
INFO - 2024-12-09 12:06:59 --> Helper loaded: file_helper
INFO - 2024-12-09 12:06:59 --> Helper loaded: form_helper
INFO - 2024-12-09 12:06:59 --> Helper loaded: my_helper
INFO - 2024-12-09 12:06:59 --> Database Driver Class Initialized
INFO - 2024-12-09 12:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:06:59 --> Controller Class Initialized
INFO - 2024-12-09 12:07:04 --> Config Class Initialized
INFO - 2024-12-09 12:07:04 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:04 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:04 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:04 --> URI Class Initialized
INFO - 2024-12-09 12:07:04 --> Router Class Initialized
INFO - 2024-12-09 12:07:04 --> Output Class Initialized
INFO - 2024-12-09 12:07:04 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:04 --> Input Class Initialized
INFO - 2024-12-09 12:07:04 --> Language Class Initialized
INFO - 2024-12-09 12:07:04 --> Language Class Initialized
INFO - 2024-12-09 12:07:04 --> Config Class Initialized
INFO - 2024-12-09 12:07:04 --> Loader Class Initialized
INFO - 2024-12-09 12:07:04 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:04 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:04 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:04 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:04 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:04 --> Controller Class Initialized
INFO - 2024-12-09 12:07:04 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:04 --> Total execution time: 0.0348
INFO - 2024-12-09 12:07:23 --> Config Class Initialized
INFO - 2024-12-09 12:07:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:23 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:23 --> URI Class Initialized
INFO - 2024-12-09 12:07:23 --> Router Class Initialized
INFO - 2024-12-09 12:07:23 --> Output Class Initialized
INFO - 2024-12-09 12:07:23 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:23 --> Input Class Initialized
INFO - 2024-12-09 12:07:23 --> Language Class Initialized
INFO - 2024-12-09 12:07:23 --> Language Class Initialized
INFO - 2024-12-09 12:07:23 --> Config Class Initialized
INFO - 2024-12-09 12:07:23 --> Loader Class Initialized
INFO - 2024-12-09 12:07:23 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:23 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:23 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:23 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:23 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:23 --> Controller Class Initialized
INFO - 2024-12-09 12:07:23 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:23 --> Total execution time: 0.0315
INFO - 2024-12-09 12:07:23 --> Config Class Initialized
INFO - 2024-12-09 12:07:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:23 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:23 --> URI Class Initialized
INFO - 2024-12-09 12:07:23 --> Router Class Initialized
INFO - 2024-12-09 12:07:23 --> Output Class Initialized
INFO - 2024-12-09 12:07:23 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:23 --> Input Class Initialized
INFO - 2024-12-09 12:07:23 --> Language Class Initialized
INFO - 2024-12-09 12:07:23 --> Language Class Initialized
INFO - 2024-12-09 12:07:23 --> Config Class Initialized
INFO - 2024-12-09 12:07:23 --> Loader Class Initialized
INFO - 2024-12-09 12:07:23 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:23 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:23 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:23 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:23 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:23 --> Controller Class Initialized
INFO - 2024-12-09 12:07:26 --> Config Class Initialized
INFO - 2024-12-09 12:07:26 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:26 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:26 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:26 --> URI Class Initialized
INFO - 2024-12-09 12:07:26 --> Router Class Initialized
INFO - 2024-12-09 12:07:26 --> Output Class Initialized
INFO - 2024-12-09 12:07:26 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:26 --> Input Class Initialized
INFO - 2024-12-09 12:07:26 --> Language Class Initialized
INFO - 2024-12-09 12:07:26 --> Language Class Initialized
INFO - 2024-12-09 12:07:26 --> Config Class Initialized
INFO - 2024-12-09 12:07:26 --> Loader Class Initialized
INFO - 2024-12-09 12:07:26 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:26 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:26 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:26 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:26 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:26 --> Controller Class Initialized
INFO - 2024-12-09 12:07:26 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:26 --> Total execution time: 0.0302
INFO - 2024-12-09 12:07:39 --> Config Class Initialized
INFO - 2024-12-09 12:07:39 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:39 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:39 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:39 --> URI Class Initialized
INFO - 2024-12-09 12:07:39 --> Router Class Initialized
INFO - 2024-12-09 12:07:39 --> Output Class Initialized
INFO - 2024-12-09 12:07:39 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:39 --> Input Class Initialized
INFO - 2024-12-09 12:07:39 --> Language Class Initialized
INFO - 2024-12-09 12:07:39 --> Language Class Initialized
INFO - 2024-12-09 12:07:39 --> Config Class Initialized
INFO - 2024-12-09 12:07:39 --> Loader Class Initialized
INFO - 2024-12-09 12:07:39 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:39 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:39 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:39 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:39 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:39 --> Controller Class Initialized
INFO - 2024-12-09 12:07:39 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:39 --> Total execution time: 0.0314
INFO - 2024-12-09 12:07:39 --> Config Class Initialized
INFO - 2024-12-09 12:07:39 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:39 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:39 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:39 --> URI Class Initialized
INFO - 2024-12-09 12:07:39 --> Router Class Initialized
INFO - 2024-12-09 12:07:39 --> Output Class Initialized
INFO - 2024-12-09 12:07:39 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:39 --> Input Class Initialized
INFO - 2024-12-09 12:07:39 --> Language Class Initialized
INFO - 2024-12-09 12:07:39 --> Language Class Initialized
INFO - 2024-12-09 12:07:39 --> Config Class Initialized
INFO - 2024-12-09 12:07:39 --> Loader Class Initialized
INFO - 2024-12-09 12:07:39 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:39 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:39 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:39 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:39 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:39 --> Controller Class Initialized
INFO - 2024-12-09 12:07:43 --> Config Class Initialized
INFO - 2024-12-09 12:07:43 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:43 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:43 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:43 --> URI Class Initialized
INFO - 2024-12-09 12:07:43 --> Router Class Initialized
INFO - 2024-12-09 12:07:43 --> Output Class Initialized
INFO - 2024-12-09 12:07:43 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:43 --> Input Class Initialized
INFO - 2024-12-09 12:07:43 --> Language Class Initialized
INFO - 2024-12-09 12:07:43 --> Language Class Initialized
INFO - 2024-12-09 12:07:43 --> Config Class Initialized
INFO - 2024-12-09 12:07:43 --> Loader Class Initialized
INFO - 2024-12-09 12:07:43 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:43 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:43 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:43 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:43 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:43 --> Controller Class Initialized
DEBUG - 2024-12-09 12:07:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 12:07:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:07:43 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:43 --> Total execution time: 0.0290
INFO - 2024-12-09 12:07:45 --> Config Class Initialized
INFO - 2024-12-09 12:07:45 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:45 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:45 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:45 --> URI Class Initialized
INFO - 2024-12-09 12:07:45 --> Router Class Initialized
INFO - 2024-12-09 12:07:45 --> Output Class Initialized
INFO - 2024-12-09 12:07:45 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:45 --> Input Class Initialized
INFO - 2024-12-09 12:07:45 --> Language Class Initialized
INFO - 2024-12-09 12:07:45 --> Language Class Initialized
INFO - 2024-12-09 12:07:45 --> Config Class Initialized
INFO - 2024-12-09 12:07:45 --> Loader Class Initialized
INFO - 2024-12-09 12:07:45 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:45 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:45 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:45 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:45 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:45 --> Controller Class Initialized
DEBUG - 2024-12-09 12:07:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-09 12:07:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:07:45 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:45 --> Total execution time: 0.0399
INFO - 2024-12-09 12:07:46 --> Config Class Initialized
INFO - 2024-12-09 12:07:46 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:46 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:46 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:46 --> URI Class Initialized
INFO - 2024-12-09 12:07:46 --> Router Class Initialized
INFO - 2024-12-09 12:07:46 --> Output Class Initialized
INFO - 2024-12-09 12:07:46 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:46 --> Input Class Initialized
INFO - 2024-12-09 12:07:46 --> Language Class Initialized
INFO - 2024-12-09 12:07:46 --> Language Class Initialized
INFO - 2024-12-09 12:07:46 --> Config Class Initialized
INFO - 2024-12-09 12:07:46 --> Loader Class Initialized
INFO - 2024-12-09 12:07:46 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:46 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:46 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:46 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:46 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:46 --> Controller Class Initialized
INFO - 2024-12-09 12:07:57 --> Config Class Initialized
INFO - 2024-12-09 12:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:57 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:57 --> URI Class Initialized
INFO - 2024-12-09 12:07:57 --> Router Class Initialized
INFO - 2024-12-09 12:07:57 --> Output Class Initialized
INFO - 2024-12-09 12:07:57 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:57 --> Input Class Initialized
INFO - 2024-12-09 12:07:57 --> Language Class Initialized
INFO - 2024-12-09 12:07:57 --> Language Class Initialized
INFO - 2024-12-09 12:07:57 --> Config Class Initialized
INFO - 2024-12-09 12:07:57 --> Loader Class Initialized
INFO - 2024-12-09 12:07:57 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:57 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:57 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:57 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:57 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:57 --> Controller Class Initialized
DEBUG - 2024-12-09 12:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 12:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:07:57 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:57 --> Total execution time: 0.0378
INFO - 2024-12-09 12:07:59 --> Config Class Initialized
INFO - 2024-12-09 12:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:07:59 --> Utf8 Class Initialized
INFO - 2024-12-09 12:07:59 --> URI Class Initialized
INFO - 2024-12-09 12:07:59 --> Router Class Initialized
INFO - 2024-12-09 12:07:59 --> Output Class Initialized
INFO - 2024-12-09 12:07:59 --> Security Class Initialized
DEBUG - 2024-12-09 12:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:07:59 --> Input Class Initialized
INFO - 2024-12-09 12:07:59 --> Language Class Initialized
INFO - 2024-12-09 12:07:59 --> Language Class Initialized
INFO - 2024-12-09 12:07:59 --> Config Class Initialized
INFO - 2024-12-09 12:07:59 --> Loader Class Initialized
INFO - 2024-12-09 12:07:59 --> Helper loaded: url_helper
INFO - 2024-12-09 12:07:59 --> Helper loaded: file_helper
INFO - 2024-12-09 12:07:59 --> Helper loaded: form_helper
INFO - 2024-12-09 12:07:59 --> Helper loaded: my_helper
INFO - 2024-12-09 12:07:59 --> Database Driver Class Initialized
INFO - 2024-12-09 12:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:07:59 --> Controller Class Initialized
DEBUG - 2024-12-09 12:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-09 12:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:07:59 --> Final output sent to browser
DEBUG - 2024-12-09 12:07:59 --> Total execution time: 0.0315
INFO - 2024-12-09 12:08:00 --> Config Class Initialized
INFO - 2024-12-09 12:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:08:00 --> Utf8 Class Initialized
INFO - 2024-12-09 12:08:00 --> URI Class Initialized
INFO - 2024-12-09 12:08:00 --> Router Class Initialized
INFO - 2024-12-09 12:08:00 --> Output Class Initialized
INFO - 2024-12-09 12:08:00 --> Security Class Initialized
DEBUG - 2024-12-09 12:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:08:00 --> Input Class Initialized
INFO - 2024-12-09 12:08:00 --> Language Class Initialized
INFO - 2024-12-09 12:08:00 --> Language Class Initialized
INFO - 2024-12-09 12:08:00 --> Config Class Initialized
INFO - 2024-12-09 12:08:00 --> Loader Class Initialized
INFO - 2024-12-09 12:08:00 --> Helper loaded: url_helper
INFO - 2024-12-09 12:08:00 --> Helper loaded: file_helper
INFO - 2024-12-09 12:08:00 --> Helper loaded: form_helper
INFO - 2024-12-09 12:08:00 --> Helper loaded: my_helper
INFO - 2024-12-09 12:08:00 --> Database Driver Class Initialized
INFO - 2024-12-09 12:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:08:00 --> Controller Class Initialized
INFO - 2024-12-09 12:08:02 --> Config Class Initialized
INFO - 2024-12-09 12:08:02 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:08:02 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:08:02 --> Utf8 Class Initialized
INFO - 2024-12-09 12:08:02 --> URI Class Initialized
INFO - 2024-12-09 12:08:02 --> Router Class Initialized
INFO - 2024-12-09 12:08:02 --> Output Class Initialized
INFO - 2024-12-09 12:08:02 --> Security Class Initialized
DEBUG - 2024-12-09 12:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:08:02 --> Input Class Initialized
INFO - 2024-12-09 12:08:02 --> Language Class Initialized
INFO - 2024-12-09 12:08:02 --> Language Class Initialized
INFO - 2024-12-09 12:08:02 --> Config Class Initialized
INFO - 2024-12-09 12:08:02 --> Loader Class Initialized
INFO - 2024-12-09 12:08:02 --> Helper loaded: url_helper
INFO - 2024-12-09 12:08:02 --> Helper loaded: file_helper
INFO - 2024-12-09 12:08:02 --> Helper loaded: form_helper
INFO - 2024-12-09 12:08:02 --> Helper loaded: my_helper
INFO - 2024-12-09 12:08:02 --> Database Driver Class Initialized
INFO - 2024-12-09 12:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:08:02 --> Controller Class Initialized
INFO - 2024-12-09 12:08:02 --> Final output sent to browser
DEBUG - 2024-12-09 12:08:02 --> Total execution time: 0.0835
INFO - 2024-12-09 12:08:23 --> Config Class Initialized
INFO - 2024-12-09 12:08:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:08:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:08:23 --> Utf8 Class Initialized
INFO - 2024-12-09 12:08:23 --> URI Class Initialized
INFO - 2024-12-09 12:08:23 --> Router Class Initialized
INFO - 2024-12-09 12:08:23 --> Output Class Initialized
INFO - 2024-12-09 12:08:23 --> Security Class Initialized
DEBUG - 2024-12-09 12:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:08:23 --> Input Class Initialized
INFO - 2024-12-09 12:08:23 --> Language Class Initialized
INFO - 2024-12-09 12:08:23 --> Language Class Initialized
INFO - 2024-12-09 12:08:23 --> Config Class Initialized
INFO - 2024-12-09 12:08:23 --> Loader Class Initialized
INFO - 2024-12-09 12:08:23 --> Helper loaded: url_helper
INFO - 2024-12-09 12:08:23 --> Helper loaded: file_helper
INFO - 2024-12-09 12:08:23 --> Helper loaded: form_helper
INFO - 2024-12-09 12:08:23 --> Helper loaded: my_helper
INFO - 2024-12-09 12:08:23 --> Database Driver Class Initialized
INFO - 2024-12-09 12:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:08:23 --> Controller Class Initialized
INFO - 2024-12-09 12:08:23 --> Final output sent to browser
DEBUG - 2024-12-09 12:08:23 --> Total execution time: 0.0324
INFO - 2024-12-09 12:08:23 --> Config Class Initialized
INFO - 2024-12-09 12:08:23 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:08:23 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:08:23 --> Utf8 Class Initialized
INFO - 2024-12-09 12:08:23 --> URI Class Initialized
INFO - 2024-12-09 12:08:23 --> Router Class Initialized
INFO - 2024-12-09 12:08:23 --> Output Class Initialized
INFO - 2024-12-09 12:08:23 --> Security Class Initialized
DEBUG - 2024-12-09 12:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:08:23 --> Input Class Initialized
INFO - 2024-12-09 12:08:23 --> Language Class Initialized
INFO - 2024-12-09 12:08:23 --> Language Class Initialized
INFO - 2024-12-09 12:08:23 --> Config Class Initialized
INFO - 2024-12-09 12:08:23 --> Loader Class Initialized
INFO - 2024-12-09 12:08:23 --> Helper loaded: url_helper
INFO - 2024-12-09 12:08:23 --> Helper loaded: file_helper
INFO - 2024-12-09 12:08:23 --> Helper loaded: form_helper
INFO - 2024-12-09 12:08:23 --> Helper loaded: my_helper
INFO - 2024-12-09 12:08:23 --> Database Driver Class Initialized
INFO - 2024-12-09 12:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:08:23 --> Controller Class Initialized
INFO - 2024-12-09 12:08:25 --> Config Class Initialized
INFO - 2024-12-09 12:08:25 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:08:25 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:08:25 --> Utf8 Class Initialized
INFO - 2024-12-09 12:08:25 --> URI Class Initialized
INFO - 2024-12-09 12:08:25 --> Router Class Initialized
INFO - 2024-12-09 12:08:25 --> Output Class Initialized
INFO - 2024-12-09 12:08:25 --> Security Class Initialized
DEBUG - 2024-12-09 12:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:08:25 --> Input Class Initialized
INFO - 2024-12-09 12:08:25 --> Language Class Initialized
INFO - 2024-12-09 12:08:25 --> Language Class Initialized
INFO - 2024-12-09 12:08:25 --> Config Class Initialized
INFO - 2024-12-09 12:08:25 --> Loader Class Initialized
INFO - 2024-12-09 12:08:25 --> Helper loaded: url_helper
INFO - 2024-12-09 12:08:25 --> Helper loaded: file_helper
INFO - 2024-12-09 12:08:25 --> Helper loaded: form_helper
INFO - 2024-12-09 12:08:25 --> Helper loaded: my_helper
INFO - 2024-12-09 12:08:25 --> Database Driver Class Initialized
INFO - 2024-12-09 12:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:08:25 --> Controller Class Initialized
INFO - 2024-12-09 12:08:25 --> Final output sent to browser
DEBUG - 2024-12-09 12:08:25 --> Total execution time: 0.0288
INFO - 2024-12-09 12:10:01 --> Config Class Initialized
INFO - 2024-12-09 12:10:01 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:01 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:01 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:01 --> URI Class Initialized
INFO - 2024-12-09 12:10:01 --> Router Class Initialized
INFO - 2024-12-09 12:10:01 --> Output Class Initialized
INFO - 2024-12-09 12:10:01 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:01 --> Input Class Initialized
INFO - 2024-12-09 12:10:01 --> Language Class Initialized
INFO - 2024-12-09 12:10:01 --> Language Class Initialized
INFO - 2024-12-09 12:10:01 --> Config Class Initialized
INFO - 2024-12-09 12:10:01 --> Loader Class Initialized
INFO - 2024-12-09 12:10:01 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:01 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:01 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:01 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:01 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:01 --> Controller Class Initialized
INFO - 2024-12-09 12:10:01 --> Final output sent to browser
DEBUG - 2024-12-09 12:10:01 --> Total execution time: 0.1359
INFO - 2024-12-09 12:10:01 --> Config Class Initialized
INFO - 2024-12-09 12:10:01 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:01 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:01 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:01 --> URI Class Initialized
INFO - 2024-12-09 12:10:01 --> Router Class Initialized
INFO - 2024-12-09 12:10:01 --> Output Class Initialized
INFO - 2024-12-09 12:10:01 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:01 --> Input Class Initialized
INFO - 2024-12-09 12:10:01 --> Language Class Initialized
INFO - 2024-12-09 12:10:01 --> Language Class Initialized
INFO - 2024-12-09 12:10:01 --> Config Class Initialized
INFO - 2024-12-09 12:10:01 --> Loader Class Initialized
INFO - 2024-12-09 12:10:01 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:01 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:02 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:02 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:02 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:02 --> Controller Class Initialized
INFO - 2024-12-09 12:10:05 --> Config Class Initialized
INFO - 2024-12-09 12:10:05 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:05 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:05 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:05 --> URI Class Initialized
INFO - 2024-12-09 12:10:05 --> Router Class Initialized
INFO - 2024-12-09 12:10:05 --> Output Class Initialized
INFO - 2024-12-09 12:10:05 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:05 --> Input Class Initialized
INFO - 2024-12-09 12:10:05 --> Language Class Initialized
INFO - 2024-12-09 12:10:05 --> Language Class Initialized
INFO - 2024-12-09 12:10:05 --> Config Class Initialized
INFO - 2024-12-09 12:10:05 --> Loader Class Initialized
INFO - 2024-12-09 12:10:05 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:05 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:05 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:05 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:05 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:06 --> Controller Class Initialized
INFO - 2024-12-09 12:10:06 --> Final output sent to browser
DEBUG - 2024-12-09 12:10:06 --> Total execution time: 0.0672
INFO - 2024-12-09 12:10:12 --> Config Class Initialized
INFO - 2024-12-09 12:10:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:12 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:12 --> URI Class Initialized
INFO - 2024-12-09 12:10:12 --> Router Class Initialized
INFO - 2024-12-09 12:10:12 --> Output Class Initialized
INFO - 2024-12-09 12:10:12 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:12 --> Input Class Initialized
INFO - 2024-12-09 12:10:12 --> Language Class Initialized
INFO - 2024-12-09 12:10:12 --> Language Class Initialized
INFO - 2024-12-09 12:10:12 --> Config Class Initialized
INFO - 2024-12-09 12:10:12 --> Loader Class Initialized
INFO - 2024-12-09 12:10:12 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:12 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:12 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:12 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:12 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:12 --> Controller Class Initialized
INFO - 2024-12-09 12:10:12 --> Final output sent to browser
DEBUG - 2024-12-09 12:10:12 --> Total execution time: 0.0274
INFO - 2024-12-09 12:10:12 --> Config Class Initialized
INFO - 2024-12-09 12:10:12 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:12 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:12 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:12 --> URI Class Initialized
INFO - 2024-12-09 12:10:12 --> Router Class Initialized
INFO - 2024-12-09 12:10:12 --> Output Class Initialized
INFO - 2024-12-09 12:10:12 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:12 --> Input Class Initialized
INFO - 2024-12-09 12:10:12 --> Language Class Initialized
INFO - 2024-12-09 12:10:12 --> Language Class Initialized
INFO - 2024-12-09 12:10:12 --> Config Class Initialized
INFO - 2024-12-09 12:10:12 --> Loader Class Initialized
INFO - 2024-12-09 12:10:12 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:12 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:12 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:12 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:12 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:12 --> Controller Class Initialized
INFO - 2024-12-09 12:10:14 --> Config Class Initialized
INFO - 2024-12-09 12:10:14 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:14 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:14 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:14 --> URI Class Initialized
DEBUG - 2024-12-09 12:10:14 --> No URI present. Default controller set.
INFO - 2024-12-09 12:10:14 --> Router Class Initialized
INFO - 2024-12-09 12:10:14 --> Output Class Initialized
INFO - 2024-12-09 12:10:14 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:14 --> Input Class Initialized
INFO - 2024-12-09 12:10:14 --> Language Class Initialized
INFO - 2024-12-09 12:10:14 --> Language Class Initialized
INFO - 2024-12-09 12:10:14 --> Config Class Initialized
INFO - 2024-12-09 12:10:14 --> Loader Class Initialized
INFO - 2024-12-09 12:10:14 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:14 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:14 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:14 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:14 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:14 --> Controller Class Initialized
DEBUG - 2024-12-09 12:10:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-09 12:10:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:10:14 --> Final output sent to browser
DEBUG - 2024-12-09 12:10:14 --> Total execution time: 0.0719
INFO - 2024-12-09 12:10:17 --> Config Class Initialized
INFO - 2024-12-09 12:10:17 --> Hooks Class Initialized
DEBUG - 2024-12-09 12:10:17 --> UTF-8 Support Enabled
INFO - 2024-12-09 12:10:17 --> Utf8 Class Initialized
INFO - 2024-12-09 12:10:17 --> URI Class Initialized
INFO - 2024-12-09 12:10:17 --> Router Class Initialized
INFO - 2024-12-09 12:10:17 --> Output Class Initialized
INFO - 2024-12-09 12:10:17 --> Security Class Initialized
DEBUG - 2024-12-09 12:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 12:10:17 --> Input Class Initialized
INFO - 2024-12-09 12:10:17 --> Language Class Initialized
INFO - 2024-12-09 12:10:17 --> Language Class Initialized
INFO - 2024-12-09 12:10:17 --> Config Class Initialized
INFO - 2024-12-09 12:10:17 --> Loader Class Initialized
INFO - 2024-12-09 12:10:17 --> Helper loaded: url_helper
INFO - 2024-12-09 12:10:17 --> Helper loaded: file_helper
INFO - 2024-12-09 12:10:17 --> Helper loaded: form_helper
INFO - 2024-12-09 12:10:17 --> Helper loaded: my_helper
INFO - 2024-12-09 12:10:17 --> Database Driver Class Initialized
INFO - 2024-12-09 12:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 12:10:17 --> Controller Class Initialized
DEBUG - 2024-12-09 12:10:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 12:10:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 12:10:17 --> Final output sent to browser
DEBUG - 2024-12-09 12:10:17 --> Total execution time: 0.0521
INFO - 2024-12-09 14:07:09 --> Config Class Initialized
INFO - 2024-12-09 14:07:09 --> Hooks Class Initialized
DEBUG - 2024-12-09 14:07:09 --> UTF-8 Support Enabled
INFO - 2024-12-09 14:07:09 --> Utf8 Class Initialized
INFO - 2024-12-09 14:07:09 --> URI Class Initialized
INFO - 2024-12-09 14:07:09 --> Router Class Initialized
INFO - 2024-12-09 14:07:09 --> Output Class Initialized
INFO - 2024-12-09 14:07:09 --> Security Class Initialized
DEBUG - 2024-12-09 14:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 14:07:09 --> Input Class Initialized
INFO - 2024-12-09 14:07:09 --> Language Class Initialized
INFO - 2024-12-09 14:07:09 --> Language Class Initialized
INFO - 2024-12-09 14:07:09 --> Config Class Initialized
INFO - 2024-12-09 14:07:09 --> Loader Class Initialized
INFO - 2024-12-09 14:07:09 --> Helper loaded: url_helper
INFO - 2024-12-09 14:07:09 --> Helper loaded: file_helper
INFO - 2024-12-09 14:07:09 --> Helper loaded: form_helper
INFO - 2024-12-09 14:07:09 --> Helper loaded: my_helper
INFO - 2024-12-09 14:07:09 --> Database Driver Class Initialized
INFO - 2024-12-09 14:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 14:07:09 --> Controller Class Initialized
DEBUG - 2024-12-09 14:07:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 14:07:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 14:07:09 --> Final output sent to browser
DEBUG - 2024-12-09 14:07:09 --> Total execution time: 0.0628
INFO - 2024-12-09 14:08:45 --> Config Class Initialized
INFO - 2024-12-09 14:08:45 --> Hooks Class Initialized
DEBUG - 2024-12-09 14:08:45 --> UTF-8 Support Enabled
INFO - 2024-12-09 14:08:45 --> Utf8 Class Initialized
INFO - 2024-12-09 14:08:45 --> URI Class Initialized
INFO - 2024-12-09 14:08:45 --> Router Class Initialized
INFO - 2024-12-09 14:08:45 --> Output Class Initialized
INFO - 2024-12-09 14:08:45 --> Security Class Initialized
DEBUG - 2024-12-09 14:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 14:08:45 --> Input Class Initialized
INFO - 2024-12-09 14:08:45 --> Language Class Initialized
INFO - 2024-12-09 14:08:45 --> Language Class Initialized
INFO - 2024-12-09 14:08:45 --> Config Class Initialized
INFO - 2024-12-09 14:08:45 --> Loader Class Initialized
INFO - 2024-12-09 14:08:45 --> Helper loaded: url_helper
INFO - 2024-12-09 14:08:45 --> Helper loaded: file_helper
INFO - 2024-12-09 14:08:45 --> Helper loaded: form_helper
INFO - 2024-12-09 14:08:45 --> Helper loaded: my_helper
INFO - 2024-12-09 14:08:45 --> Database Driver Class Initialized
INFO - 2024-12-09 14:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 14:08:45 --> Controller Class Initialized
DEBUG - 2024-12-09 14:08:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-09 14:08:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 14:08:45 --> Final output sent to browser
DEBUG - 2024-12-09 14:08:45 --> Total execution time: 0.0342
INFO - 2024-12-09 14:08:51 --> Config Class Initialized
INFO - 2024-12-09 14:08:51 --> Hooks Class Initialized
DEBUG - 2024-12-09 14:08:51 --> UTF-8 Support Enabled
INFO - 2024-12-09 14:08:51 --> Utf8 Class Initialized
INFO - 2024-12-09 14:08:51 --> URI Class Initialized
DEBUG - 2024-12-09 14:08:51 --> No URI present. Default controller set.
INFO - 2024-12-09 14:08:51 --> Router Class Initialized
INFO - 2024-12-09 14:08:51 --> Output Class Initialized
INFO - 2024-12-09 14:08:51 --> Security Class Initialized
DEBUG - 2024-12-09 14:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 14:08:51 --> Input Class Initialized
INFO - 2024-12-09 14:08:51 --> Language Class Initialized
INFO - 2024-12-09 14:08:51 --> Language Class Initialized
INFO - 2024-12-09 14:08:51 --> Config Class Initialized
INFO - 2024-12-09 14:08:51 --> Loader Class Initialized
INFO - 2024-12-09 14:08:51 --> Helper loaded: url_helper
INFO - 2024-12-09 14:08:51 --> Helper loaded: file_helper
INFO - 2024-12-09 14:08:51 --> Helper loaded: form_helper
INFO - 2024-12-09 14:08:51 --> Helper loaded: my_helper
INFO - 2024-12-09 14:08:51 --> Database Driver Class Initialized
INFO - 2024-12-09 14:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 14:08:51 --> Controller Class Initialized
DEBUG - 2024-12-09 14:08:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-09 14:08:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-09 14:08:51 --> Final output sent to browser
DEBUG - 2024-12-09 14:08:51 --> Total execution time: 0.0327
INFO - 2024-12-09 18:55:09 --> Config Class Initialized
INFO - 2024-12-09 18:55:09 --> Hooks Class Initialized
DEBUG - 2024-12-09 18:55:09 --> UTF-8 Support Enabled
INFO - 2024-12-09 18:55:09 --> Utf8 Class Initialized
INFO - 2024-12-09 18:55:09 --> URI Class Initialized
INFO - 2024-12-09 18:55:09 --> Router Class Initialized
INFO - 2024-12-09 18:55:10 --> Output Class Initialized
INFO - 2024-12-09 18:55:10 --> Security Class Initialized
DEBUG - 2024-12-09 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 18:55:10 --> Input Class Initialized
INFO - 2024-12-09 18:55:10 --> Language Class Initialized
INFO - 2024-12-09 18:55:10 --> Language Class Initialized
INFO - 2024-12-09 18:55:10 --> Config Class Initialized
INFO - 2024-12-09 18:55:10 --> Loader Class Initialized
INFO - 2024-12-09 18:55:10 --> Helper loaded: url_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: file_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: form_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: my_helper
INFO - 2024-12-09 18:55:10 --> Database Driver Class Initialized
INFO - 2024-12-09 18:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 18:55:10 --> Controller Class Initialized
INFO - 2024-12-09 18:55:10 --> Helper loaded: cookie_helper
INFO - 2024-12-09 18:55:10 --> Final output sent to browser
DEBUG - 2024-12-09 18:55:10 --> Total execution time: 0.0742
INFO - 2024-12-09 18:55:10 --> Config Class Initialized
INFO - 2024-12-09 18:55:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 18:55:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 18:55:10 --> Utf8 Class Initialized
INFO - 2024-12-09 18:55:10 --> URI Class Initialized
INFO - 2024-12-09 18:55:10 --> Router Class Initialized
INFO - 2024-12-09 18:55:10 --> Output Class Initialized
INFO - 2024-12-09 18:55:10 --> Security Class Initialized
DEBUG - 2024-12-09 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 18:55:10 --> Input Class Initialized
INFO - 2024-12-09 18:55:10 --> Language Class Initialized
INFO - 2024-12-09 18:55:10 --> Language Class Initialized
INFO - 2024-12-09 18:55:10 --> Config Class Initialized
INFO - 2024-12-09 18:55:10 --> Loader Class Initialized
INFO - 2024-12-09 18:55:10 --> Helper loaded: url_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: file_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: form_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: my_helper
INFO - 2024-12-09 18:55:10 --> Database Driver Class Initialized
INFO - 2024-12-09 18:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 18:55:10 --> Controller Class Initialized
INFO - 2024-12-09 18:55:10 --> Helper loaded: cookie_helper
INFO - 2024-12-09 18:55:10 --> Config Class Initialized
INFO - 2024-12-09 18:55:10 --> Hooks Class Initialized
DEBUG - 2024-12-09 18:55:10 --> UTF-8 Support Enabled
INFO - 2024-12-09 18:55:10 --> Utf8 Class Initialized
INFO - 2024-12-09 18:55:10 --> URI Class Initialized
INFO - 2024-12-09 18:55:10 --> Router Class Initialized
INFO - 2024-12-09 18:55:10 --> Output Class Initialized
INFO - 2024-12-09 18:55:10 --> Security Class Initialized
DEBUG - 2024-12-09 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 18:55:10 --> Input Class Initialized
INFO - 2024-12-09 18:55:10 --> Language Class Initialized
INFO - 2024-12-09 18:55:10 --> Language Class Initialized
INFO - 2024-12-09 18:55:10 --> Config Class Initialized
INFO - 2024-12-09 18:55:10 --> Loader Class Initialized
INFO - 2024-12-09 18:55:10 --> Helper loaded: url_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: file_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: form_helper
INFO - 2024-12-09 18:55:10 --> Helper loaded: my_helper
INFO - 2024-12-09 18:55:10 --> Database Driver Class Initialized
INFO - 2024-12-09 18:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 18:55:10 --> Controller Class Initialized
ERROR - 2024-12-09 18:55:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT a.id_siswa,a.id_kelas,b.tingkat,a.ta FROM t_kelas_siswa a
                                                    INNER JOIN m_kelas b ON b.id = a.id_kelas
                                                    WHERE a.id_siswa = 
INFO - 2024-12-09 18:55:10 --> Language file loaded: language/english/db_lang.php
