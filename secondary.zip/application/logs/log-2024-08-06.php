<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-06 08:44:42 --> Config Class Initialized
INFO - 2024-08-06 08:44:42 --> Hooks Class Initialized
DEBUG - 2024-08-06 08:44:42 --> UTF-8 Support Enabled
INFO - 2024-08-06 08:44:42 --> Utf8 Class Initialized
INFO - 2024-08-06 08:44:42 --> URI Class Initialized
INFO - 2024-08-06 08:44:42 --> Router Class Initialized
INFO - 2024-08-06 08:44:42 --> Output Class Initialized
INFO - 2024-08-06 08:44:42 --> Security Class Initialized
DEBUG - 2024-08-06 08:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 08:44:42 --> Input Class Initialized
INFO - 2024-08-06 08:44:42 --> Language Class Initialized
INFO - 2024-08-06 08:44:42 --> Language Class Initialized
INFO - 2024-08-06 08:44:42 --> Config Class Initialized
INFO - 2024-08-06 08:44:42 --> Loader Class Initialized
INFO - 2024-08-06 08:44:42 --> Helper loaded: url_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: file_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: form_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: my_helper
INFO - 2024-08-06 08:44:42 --> Database Driver Class Initialized
INFO - 2024-08-06 08:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 08:44:42 --> Controller Class Initialized
INFO - 2024-08-06 08:44:42 --> Helper loaded: cookie_helper
INFO - 2024-08-06 08:44:42 --> Final output sent to browser
DEBUG - 2024-08-06 08:44:42 --> Total execution time: 0.0504
INFO - 2024-08-06 08:44:42 --> Config Class Initialized
INFO - 2024-08-06 08:44:42 --> Hooks Class Initialized
DEBUG - 2024-08-06 08:44:42 --> UTF-8 Support Enabled
INFO - 2024-08-06 08:44:42 --> Utf8 Class Initialized
INFO - 2024-08-06 08:44:42 --> URI Class Initialized
INFO - 2024-08-06 08:44:42 --> Router Class Initialized
INFO - 2024-08-06 08:44:42 --> Output Class Initialized
INFO - 2024-08-06 08:44:42 --> Security Class Initialized
DEBUG - 2024-08-06 08:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 08:44:42 --> Input Class Initialized
INFO - 2024-08-06 08:44:42 --> Language Class Initialized
INFO - 2024-08-06 08:44:42 --> Language Class Initialized
INFO - 2024-08-06 08:44:42 --> Config Class Initialized
INFO - 2024-08-06 08:44:42 --> Loader Class Initialized
INFO - 2024-08-06 08:44:42 --> Helper loaded: url_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: file_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: form_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: my_helper
INFO - 2024-08-06 08:44:42 --> Database Driver Class Initialized
INFO - 2024-08-06 08:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 08:44:42 --> Controller Class Initialized
INFO - 2024-08-06 08:44:42 --> Helper loaded: cookie_helper
INFO - 2024-08-06 08:44:42 --> Config Class Initialized
INFO - 2024-08-06 08:44:42 --> Hooks Class Initialized
DEBUG - 2024-08-06 08:44:42 --> UTF-8 Support Enabled
INFO - 2024-08-06 08:44:42 --> Utf8 Class Initialized
INFO - 2024-08-06 08:44:42 --> URI Class Initialized
INFO - 2024-08-06 08:44:42 --> Router Class Initialized
INFO - 2024-08-06 08:44:42 --> Output Class Initialized
INFO - 2024-08-06 08:44:42 --> Security Class Initialized
DEBUG - 2024-08-06 08:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 08:44:42 --> Input Class Initialized
INFO - 2024-08-06 08:44:42 --> Language Class Initialized
INFO - 2024-08-06 08:44:42 --> Language Class Initialized
INFO - 2024-08-06 08:44:42 --> Config Class Initialized
INFO - 2024-08-06 08:44:42 --> Loader Class Initialized
INFO - 2024-08-06 08:44:42 --> Helper loaded: url_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: file_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: form_helper
INFO - 2024-08-06 08:44:42 --> Helper loaded: my_helper
INFO - 2024-08-06 08:44:42 --> Database Driver Class Initialized
INFO - 2024-08-06 08:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 08:44:42 --> Controller Class Initialized
DEBUG - 2024-08-06 08:44:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-06 08:44:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 08:44:42 --> Final output sent to browser
DEBUG - 2024-08-06 08:44:42 --> Total execution time: 0.0329
INFO - 2024-08-06 13:58:14 --> Config Class Initialized
INFO - 2024-08-06 13:58:14 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:14 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:14 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:14 --> URI Class Initialized
INFO - 2024-08-06 13:58:14 --> Router Class Initialized
INFO - 2024-08-06 13:58:14 --> Output Class Initialized
INFO - 2024-08-06 13:58:14 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:14 --> Input Class Initialized
INFO - 2024-08-06 13:58:14 --> Language Class Initialized
INFO - 2024-08-06 13:58:14 --> Language Class Initialized
INFO - 2024-08-06 13:58:14 --> Config Class Initialized
INFO - 2024-08-06 13:58:14 --> Loader Class Initialized
INFO - 2024-08-06 13:58:14 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:14 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:14 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:14 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:14 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:14 --> Controller Class Initialized
INFO - 2024-08-06 13:58:14 --> Helper loaded: cookie_helper
INFO - 2024-08-06 13:58:14 --> Final output sent to browser
DEBUG - 2024-08-06 13:58:14 --> Total execution time: 0.1178
INFO - 2024-08-06 13:58:15 --> Config Class Initialized
INFO - 2024-08-06 13:58:15 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:15 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:15 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:15 --> URI Class Initialized
INFO - 2024-08-06 13:58:15 --> Router Class Initialized
INFO - 2024-08-06 13:58:15 --> Output Class Initialized
INFO - 2024-08-06 13:58:15 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:15 --> Input Class Initialized
INFO - 2024-08-06 13:58:15 --> Language Class Initialized
INFO - 2024-08-06 13:58:15 --> Language Class Initialized
INFO - 2024-08-06 13:58:15 --> Config Class Initialized
INFO - 2024-08-06 13:58:15 --> Loader Class Initialized
INFO - 2024-08-06 13:58:15 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:15 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:15 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:15 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:15 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:15 --> Controller Class Initialized
INFO - 2024-08-06 13:58:15 --> Helper loaded: cookie_helper
INFO - 2024-08-06 13:58:15 --> Config Class Initialized
INFO - 2024-08-06 13:58:15 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:15 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:15 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:15 --> URI Class Initialized
INFO - 2024-08-06 13:58:15 --> Router Class Initialized
INFO - 2024-08-06 13:58:15 --> Output Class Initialized
INFO - 2024-08-06 13:58:15 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:15 --> Input Class Initialized
INFO - 2024-08-06 13:58:15 --> Language Class Initialized
INFO - 2024-08-06 13:58:15 --> Language Class Initialized
INFO - 2024-08-06 13:58:15 --> Config Class Initialized
INFO - 2024-08-06 13:58:15 --> Loader Class Initialized
INFO - 2024-08-06 13:58:15 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:15 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:15 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:15 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:15 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:15 --> Controller Class Initialized
DEBUG - 2024-08-06 13:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-06 13:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 13:58:15 --> Final output sent to browser
DEBUG - 2024-08-06 13:58:15 --> Total execution time: 0.0648
INFO - 2024-08-06 13:58:41 --> Config Class Initialized
INFO - 2024-08-06 13:58:41 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:41 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:41 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:41 --> URI Class Initialized
INFO - 2024-08-06 13:58:41 --> Router Class Initialized
INFO - 2024-08-06 13:58:41 --> Output Class Initialized
INFO - 2024-08-06 13:58:41 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:41 --> Input Class Initialized
INFO - 2024-08-06 13:58:41 --> Language Class Initialized
INFO - 2024-08-06 13:58:41 --> Language Class Initialized
INFO - 2024-08-06 13:58:41 --> Config Class Initialized
INFO - 2024-08-06 13:58:41 --> Loader Class Initialized
INFO - 2024-08-06 13:58:41 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:41 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:41 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:41 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:41 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:41 --> Controller Class Initialized
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-06 13:58:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-06 13:58:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-06 13:58:44 --> Final output sent to browser
DEBUG - 2024-08-06 13:58:44 --> Total execution time: 2.8658
INFO - 2024-08-06 13:58:45 --> Config Class Initialized
INFO - 2024-08-06 13:58:45 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:45 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:45 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:45 --> URI Class Initialized
INFO - 2024-08-06 13:58:45 --> Router Class Initialized
INFO - 2024-08-06 13:58:45 --> Output Class Initialized
INFO - 2024-08-06 13:58:45 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:45 --> Input Class Initialized
INFO - 2024-08-06 13:58:45 --> Language Class Initialized
INFO - 2024-08-06 13:58:45 --> Language Class Initialized
INFO - 2024-08-06 13:58:45 --> Config Class Initialized
INFO - 2024-08-06 13:58:45 --> Loader Class Initialized
INFO - 2024-08-06 13:58:45 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:45 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:45 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:45 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:45 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:45 --> Controller Class Initialized
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-06 13:58:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-06 13:58:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-06 13:58:47 --> Config Class Initialized
INFO - 2024-08-06 13:58:47 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:47 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:47 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:47 --> URI Class Initialized
INFO - 2024-08-06 13:58:47 --> Router Class Initialized
INFO - 2024-08-06 13:58:47 --> Output Class Initialized
INFO - 2024-08-06 13:58:47 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:47 --> Input Class Initialized
INFO - 2024-08-06 13:58:47 --> Language Class Initialized
INFO - 2024-08-06 13:58:47 --> Language Class Initialized
INFO - 2024-08-06 13:58:47 --> Config Class Initialized
INFO - 2024-08-06 13:58:47 --> Loader Class Initialized
INFO - 2024-08-06 13:58:47 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:47 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:47 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:47 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:47 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:48 --> Final output sent to browser
DEBUG - 2024-08-06 13:58:48 --> Total execution time: 2.3920
INFO - 2024-08-06 13:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:48 --> Controller Class Initialized
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-06 13:58:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-06 13:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-06 13:58:49 --> Config Class Initialized
INFO - 2024-08-06 13:58:49 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:49 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:49 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:49 --> URI Class Initialized
INFO - 2024-08-06 13:58:49 --> Router Class Initialized
INFO - 2024-08-06 13:58:49 --> Output Class Initialized
INFO - 2024-08-06 13:58:49 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:49 --> Input Class Initialized
INFO - 2024-08-06 13:58:49 --> Language Class Initialized
INFO - 2024-08-06 13:58:49 --> Language Class Initialized
INFO - 2024-08-06 13:58:49 --> Config Class Initialized
INFO - 2024-08-06 13:58:49 --> Loader Class Initialized
INFO - 2024-08-06 13:58:49 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:49 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:49 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:49 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:49 --> Database Driver Class Initialized
INFO - 2024-08-06 13:58:50 --> Final output sent to browser
DEBUG - 2024-08-06 13:58:50 --> Total execution time: 3.2492
INFO - 2024-08-06 13:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:50 --> Controller Class Initialized
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-06 13:58:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-06 13:58:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-06 13:58:51 --> Config Class Initialized
INFO - 2024-08-06 13:58:51 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:51 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:51 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:51 --> URI Class Initialized
INFO - 2024-08-06 13:58:51 --> Router Class Initialized
INFO - 2024-08-06 13:58:51 --> Output Class Initialized
INFO - 2024-08-06 13:58:51 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:51 --> Input Class Initialized
INFO - 2024-08-06 13:58:51 --> Language Class Initialized
INFO - 2024-08-06 13:58:51 --> Language Class Initialized
INFO - 2024-08-06 13:58:51 --> Config Class Initialized
INFO - 2024-08-06 13:58:51 --> Loader Class Initialized
INFO - 2024-08-06 13:58:51 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:51 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:51 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:51 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:51 --> Database Driver Class Initialized
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-06 13:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 13:58:54 --> Controller Class Initialized
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-06 13:58:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-06 13:58:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-06 13:58:55 --> Config Class Initialized
INFO - 2024-08-06 13:58:55 --> Hooks Class Initialized
DEBUG - 2024-08-06 13:58:55 --> UTF-8 Support Enabled
INFO - 2024-08-06 13:58:55 --> Utf8 Class Initialized
INFO - 2024-08-06 13:58:55 --> URI Class Initialized
DEBUG - 2024-08-06 13:58:55 --> No URI present. Default controller set.
INFO - 2024-08-06 13:58:55 --> Router Class Initialized
INFO - 2024-08-06 13:58:55 --> Output Class Initialized
INFO - 2024-08-06 13:58:55 --> Security Class Initialized
DEBUG - 2024-08-06 13:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 13:58:55 --> Input Class Initialized
INFO - 2024-08-06 13:58:55 --> Language Class Initialized
INFO - 2024-08-06 13:58:55 --> Language Class Initialized
INFO - 2024-08-06 13:58:55 --> Config Class Initialized
INFO - 2024-08-06 13:58:55 --> Loader Class Initialized
INFO - 2024-08-06 13:58:55 --> Helper loaded: url_helper
INFO - 2024-08-06 13:58:55 --> Helper loaded: file_helper
INFO - 2024-08-06 13:58:55 --> Helper loaded: form_helper
INFO - 2024-08-06 13:58:55 --> Helper loaded: my_helper
INFO - 2024-08-06 13:58:55 --> Database Driver Class Initialized
INFO - 2024-08-06 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:02:21 --> Controller Class Initialized
DEBUG - 2024-08-06 14:02:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-06 14:02:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 14:02:21 --> Final output sent to browser
DEBUG - 2024-08-06 14:02:21 --> Total execution time: 205.8220
INFO - 2024-08-06 14:03:59 --> Config Class Initialized
INFO - 2024-08-06 14:03:59 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:03:59 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:03:59 --> Utf8 Class Initialized
INFO - 2024-08-06 14:03:59 --> URI Class Initialized
DEBUG - 2024-08-06 14:03:59 --> No URI present. Default controller set.
INFO - 2024-08-06 14:03:59 --> Router Class Initialized
INFO - 2024-08-06 14:03:59 --> Output Class Initialized
INFO - 2024-08-06 14:03:59 --> Security Class Initialized
DEBUG - 2024-08-06 14:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:03:59 --> Input Class Initialized
INFO - 2024-08-06 14:03:59 --> Language Class Initialized
INFO - 2024-08-06 14:03:59 --> Language Class Initialized
INFO - 2024-08-06 14:03:59 --> Config Class Initialized
INFO - 2024-08-06 14:03:59 --> Loader Class Initialized
INFO - 2024-08-06 14:03:59 --> Helper loaded: url_helper
INFO - 2024-08-06 14:03:59 --> Helper loaded: file_helper
INFO - 2024-08-06 14:03:59 --> Helper loaded: form_helper
INFO - 2024-08-06 14:03:59 --> Helper loaded: my_helper
INFO - 2024-08-06 14:03:59 --> Database Driver Class Initialized
INFO - 2024-08-06 14:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:03:59 --> Controller Class Initialized
INFO - 2024-08-06 14:03:59 --> Config Class Initialized
INFO - 2024-08-06 14:03:59 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:03:59 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:03:59 --> Utf8 Class Initialized
INFO - 2024-08-06 14:03:59 --> URI Class Initialized
INFO - 2024-08-06 14:03:59 --> Router Class Initialized
INFO - 2024-08-06 14:03:59 --> Output Class Initialized
INFO - 2024-08-06 14:03:59 --> Security Class Initialized
DEBUG - 2024-08-06 14:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:03:59 --> Input Class Initialized
INFO - 2024-08-06 14:03:59 --> Language Class Initialized
INFO - 2024-08-06 14:03:59 --> Language Class Initialized
INFO - 2024-08-06 14:03:59 --> Config Class Initialized
INFO - 2024-08-06 14:03:59 --> Loader Class Initialized
INFO - 2024-08-06 14:03:59 --> Helper loaded: url_helper
INFO - 2024-08-06 14:03:59 --> Helper loaded: file_helper
INFO - 2024-08-06 14:03:59 --> Helper loaded: form_helper
INFO - 2024-08-06 14:03:59 --> Helper loaded: my_helper
INFO - 2024-08-06 14:03:59 --> Database Driver Class Initialized
INFO - 2024-08-06 14:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:03:59 --> Controller Class Initialized
DEBUG - 2024-08-06 14:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-06 14:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 14:03:59 --> Final output sent to browser
DEBUG - 2024-08-06 14:03:59 --> Total execution time: 0.0297
INFO - 2024-08-06 14:04:04 --> Config Class Initialized
INFO - 2024-08-06 14:04:04 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:04:04 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:04:04 --> Utf8 Class Initialized
INFO - 2024-08-06 14:04:04 --> URI Class Initialized
INFO - 2024-08-06 14:04:04 --> Router Class Initialized
INFO - 2024-08-06 14:04:04 --> Output Class Initialized
INFO - 2024-08-06 14:04:04 --> Security Class Initialized
DEBUG - 2024-08-06 14:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:04:04 --> Input Class Initialized
INFO - 2024-08-06 14:04:04 --> Language Class Initialized
INFO - 2024-08-06 14:04:04 --> Language Class Initialized
INFO - 2024-08-06 14:04:04 --> Config Class Initialized
INFO - 2024-08-06 14:04:04 --> Loader Class Initialized
INFO - 2024-08-06 14:04:04 --> Helper loaded: url_helper
INFO - 2024-08-06 14:04:04 --> Helper loaded: file_helper
INFO - 2024-08-06 14:04:04 --> Helper loaded: form_helper
INFO - 2024-08-06 14:04:04 --> Helper loaded: my_helper
INFO - 2024-08-06 14:04:04 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:04:04 --> Controller Class Initialized
INFO - 2024-08-06 14:04:04 --> Final output sent to browser
DEBUG - 2024-08-06 14:04:04 --> Total execution time: 0.0414
INFO - 2024-08-06 14:04:12 --> Config Class Initialized
INFO - 2024-08-06 14:04:12 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:04:12 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:04:12 --> Utf8 Class Initialized
INFO - 2024-08-06 14:04:12 --> URI Class Initialized
INFO - 2024-08-06 14:04:12 --> Router Class Initialized
INFO - 2024-08-06 14:04:12 --> Output Class Initialized
INFO - 2024-08-06 14:04:12 --> Security Class Initialized
DEBUG - 2024-08-06 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:04:12 --> Input Class Initialized
INFO - 2024-08-06 14:04:12 --> Language Class Initialized
INFO - 2024-08-06 14:04:12 --> Language Class Initialized
INFO - 2024-08-06 14:04:12 --> Config Class Initialized
INFO - 2024-08-06 14:04:12 --> Loader Class Initialized
INFO - 2024-08-06 14:04:12 --> Helper loaded: url_helper
INFO - 2024-08-06 14:04:12 --> Helper loaded: file_helper
INFO - 2024-08-06 14:04:12 --> Helper loaded: form_helper
INFO - 2024-08-06 14:04:12 --> Helper loaded: my_helper
INFO - 2024-08-06 14:04:12 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:04:12 --> Controller Class Initialized
INFO - 2024-08-06 14:04:12 --> Helper loaded: cookie_helper
INFO - 2024-08-06 14:04:12 --> Final output sent to browser
DEBUG - 2024-08-06 14:04:12 --> Total execution time: 0.0544
INFO - 2024-08-06 14:04:12 --> Config Class Initialized
INFO - 2024-08-06 14:04:12 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:04:12 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:04:12 --> Utf8 Class Initialized
INFO - 2024-08-06 14:04:12 --> URI Class Initialized
INFO - 2024-08-06 14:04:12 --> Router Class Initialized
INFO - 2024-08-06 14:04:12 --> Output Class Initialized
INFO - 2024-08-06 14:04:12 --> Security Class Initialized
DEBUG - 2024-08-06 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:04:12 --> Input Class Initialized
INFO - 2024-08-06 14:04:12 --> Language Class Initialized
INFO - 2024-08-06 14:04:12 --> Language Class Initialized
INFO - 2024-08-06 14:04:12 --> Config Class Initialized
INFO - 2024-08-06 14:04:12 --> Loader Class Initialized
INFO - 2024-08-06 14:04:12 --> Helper loaded: url_helper
INFO - 2024-08-06 14:04:12 --> Helper loaded: file_helper
INFO - 2024-08-06 14:04:12 --> Helper loaded: form_helper
INFO - 2024-08-06 14:04:12 --> Helper loaded: my_helper
INFO - 2024-08-06 14:04:12 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:04:12 --> Controller Class Initialized
DEBUG - 2024-08-06 14:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-06 14:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 14:04:12 --> Final output sent to browser
DEBUG - 2024-08-06 14:04:12 --> Total execution time: 0.0317
INFO - 2024-08-06 14:04:17 --> Config Class Initialized
INFO - 2024-08-06 14:04:17 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:04:17 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:04:17 --> Utf8 Class Initialized
INFO - 2024-08-06 14:04:17 --> URI Class Initialized
INFO - 2024-08-06 14:04:17 --> Router Class Initialized
INFO - 2024-08-06 14:04:17 --> Output Class Initialized
INFO - 2024-08-06 14:04:17 --> Security Class Initialized
DEBUG - 2024-08-06 14:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:04:17 --> Input Class Initialized
INFO - 2024-08-06 14:04:17 --> Language Class Initialized
INFO - 2024-08-06 14:04:17 --> Language Class Initialized
INFO - 2024-08-06 14:04:17 --> Config Class Initialized
INFO - 2024-08-06 14:04:17 --> Loader Class Initialized
INFO - 2024-08-06 14:04:17 --> Helper loaded: url_helper
INFO - 2024-08-06 14:04:17 --> Helper loaded: file_helper
INFO - 2024-08-06 14:04:17 --> Helper loaded: form_helper
INFO - 2024-08-06 14:04:17 --> Helper loaded: my_helper
INFO - 2024-08-06 14:04:17 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:04:17 --> Controller Class Initialized
DEBUG - 2024-08-06 14:04:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-08-06 14:04:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 14:04:17 --> Final output sent to browser
DEBUG - 2024-08-06 14:04:17 --> Total execution time: 0.0333
INFO - 2024-08-06 14:04:18 --> Config Class Initialized
INFO - 2024-08-06 14:04:18 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:04:18 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:04:18 --> Utf8 Class Initialized
INFO - 2024-08-06 14:04:18 --> URI Class Initialized
INFO - 2024-08-06 14:04:18 --> Router Class Initialized
INFO - 2024-08-06 14:04:18 --> Output Class Initialized
INFO - 2024-08-06 14:04:18 --> Security Class Initialized
DEBUG - 2024-08-06 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:04:18 --> Input Class Initialized
INFO - 2024-08-06 14:04:18 --> Language Class Initialized
INFO - 2024-08-06 14:04:18 --> Language Class Initialized
INFO - 2024-08-06 14:04:18 --> Config Class Initialized
INFO - 2024-08-06 14:04:18 --> Loader Class Initialized
INFO - 2024-08-06 14:04:18 --> Helper loaded: url_helper
INFO - 2024-08-06 14:04:18 --> Helper loaded: file_helper
INFO - 2024-08-06 14:04:18 --> Helper loaded: form_helper
INFO - 2024-08-06 14:04:18 --> Helper loaded: my_helper
INFO - 2024-08-06 14:04:18 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:04:18 --> Controller Class Initialized
INFO - 2024-08-06 14:04:18 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:19 --> Config Class Initialized
INFO - 2024-08-06 14:04:19 --> Hooks Class Initialized
DEBUG - 2024-08-06 14:04:19 --> UTF-8 Support Enabled
INFO - 2024-08-06 14:04:19 --> Utf8 Class Initialized
INFO - 2024-08-06 14:04:19 --> URI Class Initialized
INFO - 2024-08-06 14:04:19 --> Router Class Initialized
INFO - 2024-08-06 14:04:19 --> Output Class Initialized
INFO - 2024-08-06 14:04:19 --> Security Class Initialized
DEBUG - 2024-08-06 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 14:04:19 --> Input Class Initialized
INFO - 2024-08-06 14:04:19 --> Language Class Initialized
INFO - 2024-08-06 14:04:19 --> Language Class Initialized
INFO - 2024-08-06 14:04:19 --> Config Class Initialized
INFO - 2024-08-06 14:04:19 --> Loader Class Initialized
INFO - 2024-08-06 14:04:19 --> Helper loaded: url_helper
INFO - 2024-08-06 14:04:19 --> Helper loaded: file_helper
INFO - 2024-08-06 14:04:19 --> Helper loaded: form_helper
INFO - 2024-08-06 14:04:19 --> Helper loaded: my_helper
INFO - 2024-08-06 14:04:19 --> Database Driver Class Initialized
INFO - 2024-08-06 14:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 14:04:19 --> Controller Class Initialized
DEBUG - 2024-08-06 14:04:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-08-06 14:04:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 14:04:19 --> Final output sent to browser
DEBUG - 2024-08-06 14:04:19 --> Total execution time: 0.0401
INFO - 2024-08-06 22:26:20 --> Config Class Initialized
INFO - 2024-08-06 22:26:20 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:20 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:20 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:20 --> URI Class Initialized
INFO - 2024-08-06 22:26:20 --> Router Class Initialized
INFO - 2024-08-06 22:26:20 --> Output Class Initialized
INFO - 2024-08-06 22:26:20 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:20 --> Input Class Initialized
INFO - 2024-08-06 22:26:20 --> Language Class Initialized
INFO - 2024-08-06 22:26:20 --> Language Class Initialized
INFO - 2024-08-06 22:26:20 --> Config Class Initialized
INFO - 2024-08-06 22:26:20 --> Loader Class Initialized
INFO - 2024-08-06 22:26:20 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:20 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:20 --> Controller Class Initialized
INFO - 2024-08-06 22:26:20 --> Helper loaded: cookie_helper
INFO - 2024-08-06 22:26:20 --> Final output sent to browser
DEBUG - 2024-08-06 22:26:20 --> Total execution time: 0.0623
INFO - 2024-08-06 22:26:20 --> Config Class Initialized
INFO - 2024-08-06 22:26:20 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:20 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:20 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:20 --> URI Class Initialized
INFO - 2024-08-06 22:26:20 --> Router Class Initialized
INFO - 2024-08-06 22:26:20 --> Output Class Initialized
INFO - 2024-08-06 22:26:20 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:20 --> Input Class Initialized
INFO - 2024-08-06 22:26:20 --> Language Class Initialized
INFO - 2024-08-06 22:26:20 --> Language Class Initialized
INFO - 2024-08-06 22:26:20 --> Config Class Initialized
INFO - 2024-08-06 22:26:20 --> Loader Class Initialized
INFO - 2024-08-06 22:26:20 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:20 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:20 --> Controller Class Initialized
INFO - 2024-08-06 22:26:20 --> Helper loaded: cookie_helper
INFO - 2024-08-06 22:26:20 --> Config Class Initialized
INFO - 2024-08-06 22:26:20 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:20 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:20 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:20 --> URI Class Initialized
INFO - 2024-08-06 22:26:20 --> Router Class Initialized
INFO - 2024-08-06 22:26:20 --> Output Class Initialized
INFO - 2024-08-06 22:26:20 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:20 --> Input Class Initialized
INFO - 2024-08-06 22:26:20 --> Language Class Initialized
INFO - 2024-08-06 22:26:20 --> Language Class Initialized
INFO - 2024-08-06 22:26:20 --> Config Class Initialized
INFO - 2024-08-06 22:26:20 --> Loader Class Initialized
INFO - 2024-08-06 22:26:20 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:20 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:20 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:20 --> Controller Class Initialized
DEBUG - 2024-08-06 22:26:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-06 22:26:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 22:26:20 --> Final output sent to browser
DEBUG - 2024-08-06 22:26:20 --> Total execution time: 0.0486
INFO - 2024-08-06 22:26:32 --> Config Class Initialized
INFO - 2024-08-06 22:26:32 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:32 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:32 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:32 --> URI Class Initialized
INFO - 2024-08-06 22:26:32 --> Router Class Initialized
INFO - 2024-08-06 22:26:32 --> Output Class Initialized
INFO - 2024-08-06 22:26:32 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:32 --> Input Class Initialized
INFO - 2024-08-06 22:26:32 --> Language Class Initialized
INFO - 2024-08-06 22:26:32 --> Language Class Initialized
INFO - 2024-08-06 22:26:32 --> Config Class Initialized
INFO - 2024-08-06 22:26:32 --> Loader Class Initialized
INFO - 2024-08-06 22:26:32 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:32 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:32 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:32 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:32 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:32 --> Controller Class Initialized
DEBUG - 2024-08-06 22:26:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-06 22:26:37 --> Final output sent to browser
DEBUG - 2024-08-06 22:26:37 --> Total execution time: 4.7074
INFO - 2024-08-06 22:26:37 --> Config Class Initialized
INFO - 2024-08-06 22:26:37 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:37 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:37 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:37 --> URI Class Initialized
INFO - 2024-08-06 22:26:37 --> Router Class Initialized
INFO - 2024-08-06 22:26:37 --> Output Class Initialized
INFO - 2024-08-06 22:26:37 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:37 --> Input Class Initialized
INFO - 2024-08-06 22:26:37 --> Language Class Initialized
INFO - 2024-08-06 22:26:37 --> Language Class Initialized
INFO - 2024-08-06 22:26:37 --> Config Class Initialized
INFO - 2024-08-06 22:26:37 --> Loader Class Initialized
INFO - 2024-08-06 22:26:37 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:37 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:37 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:37 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:37 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:37 --> Controller Class Initialized
DEBUG - 2024-08-06 22:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-06 22:26:42 --> Final output sent to browser
DEBUG - 2024-08-06 22:26:42 --> Total execution time: 4.4479
INFO - 2024-08-06 22:26:42 --> Config Class Initialized
INFO - 2024-08-06 22:26:42 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:42 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:42 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:42 --> URI Class Initialized
INFO - 2024-08-06 22:26:42 --> Router Class Initialized
INFO - 2024-08-06 22:26:42 --> Output Class Initialized
INFO - 2024-08-06 22:26:42 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:42 --> Input Class Initialized
INFO - 2024-08-06 22:26:42 --> Language Class Initialized
INFO - 2024-08-06 22:26:42 --> Language Class Initialized
INFO - 2024-08-06 22:26:42 --> Config Class Initialized
INFO - 2024-08-06 22:26:42 --> Loader Class Initialized
INFO - 2024-08-06 22:26:42 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:42 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:42 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:42 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:42 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:42 --> Controller Class Initialized
DEBUG - 2024-08-06 22:26:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-06 22:26:42 --> Config Class Initialized
INFO - 2024-08-06 22:26:42 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:42 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:42 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:42 --> URI Class Initialized
INFO - 2024-08-06 22:26:42 --> Router Class Initialized
INFO - 2024-08-06 22:26:42 --> Output Class Initialized
INFO - 2024-08-06 22:26:42 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:42 --> Input Class Initialized
INFO - 2024-08-06 22:26:42 --> Language Class Initialized
INFO - 2024-08-06 22:26:42 --> Language Class Initialized
INFO - 2024-08-06 22:26:42 --> Config Class Initialized
INFO - 2024-08-06 22:26:42 --> Loader Class Initialized
INFO - 2024-08-06 22:26:42 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:42 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:42 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:42 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:42 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:45 --> Controller Class Initialized
DEBUG - 2024-08-06 22:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-06 22:26:48 --> Config Class Initialized
INFO - 2024-08-06 22:26:48 --> Hooks Class Initialized
DEBUG - 2024-08-06 22:26:48 --> UTF-8 Support Enabled
INFO - 2024-08-06 22:26:48 --> Utf8 Class Initialized
INFO - 2024-08-06 22:26:48 --> URI Class Initialized
DEBUG - 2024-08-06 22:26:48 --> No URI present. Default controller set.
INFO - 2024-08-06 22:26:48 --> Router Class Initialized
INFO - 2024-08-06 22:26:48 --> Output Class Initialized
INFO - 2024-08-06 22:26:48 --> Security Class Initialized
DEBUG - 2024-08-06 22:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-06 22:26:48 --> Input Class Initialized
INFO - 2024-08-06 22:26:48 --> Language Class Initialized
INFO - 2024-08-06 22:26:48 --> Language Class Initialized
INFO - 2024-08-06 22:26:48 --> Config Class Initialized
INFO - 2024-08-06 22:26:48 --> Loader Class Initialized
INFO - 2024-08-06 22:26:48 --> Helper loaded: url_helper
INFO - 2024-08-06 22:26:48 --> Helper loaded: file_helper
INFO - 2024-08-06 22:26:48 --> Helper loaded: form_helper
INFO - 2024-08-06 22:26:48 --> Helper loaded: my_helper
INFO - 2024-08-06 22:26:48 --> Database Driver Class Initialized
INFO - 2024-08-06 22:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-06 22:26:48 --> Controller Class Initialized
DEBUG - 2024-08-06 22:26:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-06 22:26:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-06 22:26:48 --> Final output sent to browser
DEBUG - 2024-08-06 22:26:48 --> Total execution time: 0.4973
