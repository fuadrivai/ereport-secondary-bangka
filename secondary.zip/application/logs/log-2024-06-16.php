<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-16 06:05:38 --> Config Class Initialized
INFO - 2024-06-16 06:05:38 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:38 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:38 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:38 --> URI Class Initialized
INFO - 2024-06-16 06:05:38 --> Router Class Initialized
INFO - 2024-06-16 06:05:38 --> Output Class Initialized
INFO - 2024-06-16 06:05:38 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:38 --> Input Class Initialized
INFO - 2024-06-16 06:05:38 --> Language Class Initialized
INFO - 2024-06-16 06:05:38 --> Language Class Initialized
INFO - 2024-06-16 06:05:38 --> Config Class Initialized
INFO - 2024-06-16 06:05:38 --> Loader Class Initialized
INFO - 2024-06-16 06:05:38 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:38 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:38 --> Controller Class Initialized
INFO - 2024-06-16 06:05:38 --> Helper loaded: cookie_helper
INFO - 2024-06-16 06:05:38 --> Config Class Initialized
INFO - 2024-06-16 06:05:38 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:38 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:38 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:38 --> URI Class Initialized
INFO - 2024-06-16 06:05:38 --> Router Class Initialized
INFO - 2024-06-16 06:05:38 --> Output Class Initialized
INFO - 2024-06-16 06:05:38 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:38 --> Input Class Initialized
INFO - 2024-06-16 06:05:38 --> Language Class Initialized
INFO - 2024-06-16 06:05:38 --> Language Class Initialized
INFO - 2024-06-16 06:05:38 --> Config Class Initialized
INFO - 2024-06-16 06:05:38 --> Loader Class Initialized
INFO - 2024-06-16 06:05:38 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:38 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:38 --> Controller Class Initialized
INFO - 2024-06-16 06:05:38 --> Config Class Initialized
INFO - 2024-06-16 06:05:38 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:38 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:38 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:38 --> URI Class Initialized
INFO - 2024-06-16 06:05:38 --> Router Class Initialized
INFO - 2024-06-16 06:05:38 --> Output Class Initialized
INFO - 2024-06-16 06:05:38 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:38 --> Input Class Initialized
INFO - 2024-06-16 06:05:38 --> Language Class Initialized
INFO - 2024-06-16 06:05:38 --> Language Class Initialized
INFO - 2024-06-16 06:05:38 --> Config Class Initialized
INFO - 2024-06-16 06:05:38 --> Loader Class Initialized
INFO - 2024-06-16 06:05:38 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:38 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:38 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:38 --> Controller Class Initialized
DEBUG - 2024-06-16 06:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-16 06:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:05:38 --> Final output sent to browser
DEBUG - 2024-06-16 06:05:38 --> Total execution time: 0.0427
INFO - 2024-06-16 06:05:45 --> Config Class Initialized
INFO - 2024-06-16 06:05:45 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:45 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:45 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:45 --> URI Class Initialized
INFO - 2024-06-16 06:05:45 --> Router Class Initialized
INFO - 2024-06-16 06:05:45 --> Output Class Initialized
INFO - 2024-06-16 06:05:45 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:45 --> Input Class Initialized
INFO - 2024-06-16 06:05:45 --> Language Class Initialized
INFO - 2024-06-16 06:05:45 --> Language Class Initialized
INFO - 2024-06-16 06:05:45 --> Config Class Initialized
INFO - 2024-06-16 06:05:45 --> Loader Class Initialized
INFO - 2024-06-16 06:05:45 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:45 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:45 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:45 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:45 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:45 --> Controller Class Initialized
INFO - 2024-06-16 06:05:45 --> Helper loaded: cookie_helper
INFO - 2024-06-16 06:05:45 --> Final output sent to browser
DEBUG - 2024-06-16 06:05:45 --> Total execution time: 0.1554
INFO - 2024-06-16 06:05:45 --> Config Class Initialized
INFO - 2024-06-16 06:05:45 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:45 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:45 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:45 --> URI Class Initialized
INFO - 2024-06-16 06:05:45 --> Router Class Initialized
INFO - 2024-06-16 06:05:45 --> Output Class Initialized
INFO - 2024-06-16 06:05:45 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:45 --> Input Class Initialized
INFO - 2024-06-16 06:05:45 --> Language Class Initialized
INFO - 2024-06-16 06:05:45 --> Language Class Initialized
INFO - 2024-06-16 06:05:45 --> Config Class Initialized
INFO - 2024-06-16 06:05:45 --> Loader Class Initialized
INFO - 2024-06-16 06:05:45 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:45 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:45 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:45 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:45 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:45 --> Controller Class Initialized
DEBUG - 2024-06-16 06:05:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-16 06:05:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:05:45 --> Final output sent to browser
DEBUG - 2024-06-16 06:05:45 --> Total execution time: 0.0451
INFO - 2024-06-16 06:05:48 --> Config Class Initialized
INFO - 2024-06-16 06:05:48 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:48 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:48 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:48 --> URI Class Initialized
INFO - 2024-06-16 06:05:48 --> Router Class Initialized
INFO - 2024-06-16 06:05:48 --> Output Class Initialized
INFO - 2024-06-16 06:05:48 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:48 --> Input Class Initialized
INFO - 2024-06-16 06:05:48 --> Language Class Initialized
INFO - 2024-06-16 06:05:48 --> Language Class Initialized
INFO - 2024-06-16 06:05:48 --> Config Class Initialized
INFO - 2024-06-16 06:05:48 --> Loader Class Initialized
INFO - 2024-06-16 06:05:48 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:48 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:48 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:48 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:48 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:48 --> Controller Class Initialized
DEBUG - 2024-06-16 06:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-16 06:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:05:48 --> Final output sent to browser
DEBUG - 2024-06-16 06:05:48 --> Total execution time: 0.0409
INFO - 2024-06-16 06:05:51 --> Config Class Initialized
INFO - 2024-06-16 06:05:51 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:51 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:51 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:51 --> URI Class Initialized
INFO - 2024-06-16 06:05:51 --> Router Class Initialized
INFO - 2024-06-16 06:05:51 --> Output Class Initialized
INFO - 2024-06-16 06:05:51 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:51 --> Input Class Initialized
INFO - 2024-06-16 06:05:51 --> Language Class Initialized
INFO - 2024-06-16 06:05:51 --> Language Class Initialized
INFO - 2024-06-16 06:05:51 --> Config Class Initialized
INFO - 2024-06-16 06:05:51 --> Loader Class Initialized
INFO - 2024-06-16 06:05:51 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:51 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:51 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:51 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:51 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:51 --> Controller Class Initialized
DEBUG - 2024-06-16 06:05:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-16 06:05:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:05:51 --> Final output sent to browser
DEBUG - 2024-06-16 06:05:51 --> Total execution time: 0.0486
INFO - 2024-06-16 06:05:51 --> Config Class Initialized
INFO - 2024-06-16 06:05:51 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:05:51 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:05:51 --> Utf8 Class Initialized
INFO - 2024-06-16 06:05:51 --> URI Class Initialized
INFO - 2024-06-16 06:05:51 --> Router Class Initialized
INFO - 2024-06-16 06:05:51 --> Output Class Initialized
INFO - 2024-06-16 06:05:51 --> Security Class Initialized
DEBUG - 2024-06-16 06:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:05:51 --> Input Class Initialized
INFO - 2024-06-16 06:05:51 --> Language Class Initialized
INFO - 2024-06-16 06:05:51 --> Language Class Initialized
INFO - 2024-06-16 06:05:51 --> Config Class Initialized
INFO - 2024-06-16 06:05:51 --> Loader Class Initialized
INFO - 2024-06-16 06:05:51 --> Helper loaded: url_helper
INFO - 2024-06-16 06:05:51 --> Helper loaded: file_helper
INFO - 2024-06-16 06:05:51 --> Helper loaded: form_helper
INFO - 2024-06-16 06:05:51 --> Helper loaded: my_helper
INFO - 2024-06-16 06:05:51 --> Database Driver Class Initialized
INFO - 2024-06-16 06:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:05:51 --> Controller Class Initialized
INFO - 2024-06-16 06:10:20 --> Config Class Initialized
INFO - 2024-06-16 06:10:20 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:10:20 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:10:20 --> Utf8 Class Initialized
INFO - 2024-06-16 06:10:20 --> URI Class Initialized
INFO - 2024-06-16 06:10:20 --> Router Class Initialized
INFO - 2024-06-16 06:10:20 --> Output Class Initialized
INFO - 2024-06-16 06:10:20 --> Security Class Initialized
DEBUG - 2024-06-16 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:10:20 --> Input Class Initialized
INFO - 2024-06-16 06:10:20 --> Language Class Initialized
INFO - 2024-06-16 06:10:20 --> Language Class Initialized
INFO - 2024-06-16 06:10:20 --> Config Class Initialized
INFO - 2024-06-16 06:10:20 --> Loader Class Initialized
INFO - 2024-06-16 06:10:20 --> Helper loaded: url_helper
INFO - 2024-06-16 06:10:20 --> Helper loaded: file_helper
INFO - 2024-06-16 06:10:20 --> Helper loaded: form_helper
INFO - 2024-06-16 06:10:20 --> Helper loaded: my_helper
INFO - 2024-06-16 06:10:20 --> Database Driver Class Initialized
INFO - 2024-06-16 06:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:10:20 --> Controller Class Initialized
INFO - 2024-06-16 06:10:20 --> Final output sent to browser
DEBUG - 2024-06-16 06:10:20 --> Total execution time: 0.0652
INFO - 2024-06-16 06:10:47 --> Config Class Initialized
INFO - 2024-06-16 06:10:47 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:10:47 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:10:47 --> Utf8 Class Initialized
INFO - 2024-06-16 06:10:47 --> URI Class Initialized
INFO - 2024-06-16 06:10:47 --> Router Class Initialized
INFO - 2024-06-16 06:10:47 --> Output Class Initialized
INFO - 2024-06-16 06:10:47 --> Security Class Initialized
DEBUG - 2024-06-16 06:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:10:47 --> Input Class Initialized
INFO - 2024-06-16 06:10:47 --> Language Class Initialized
INFO - 2024-06-16 06:10:47 --> Language Class Initialized
INFO - 2024-06-16 06:10:47 --> Config Class Initialized
INFO - 2024-06-16 06:10:47 --> Loader Class Initialized
INFO - 2024-06-16 06:10:47 --> Helper loaded: url_helper
INFO - 2024-06-16 06:10:47 --> Helper loaded: file_helper
INFO - 2024-06-16 06:10:47 --> Helper loaded: form_helper
INFO - 2024-06-16 06:10:47 --> Helper loaded: my_helper
INFO - 2024-06-16 06:10:47 --> Database Driver Class Initialized
INFO - 2024-06-16 06:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:10:47 --> Controller Class Initialized
INFO - 2024-06-16 06:10:47 --> Final output sent to browser
DEBUG - 2024-06-16 06:10:47 --> Total execution time: 0.0753
INFO - 2024-06-16 06:10:47 --> Config Class Initialized
INFO - 2024-06-16 06:10:47 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:10:47 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:10:47 --> Utf8 Class Initialized
INFO - 2024-06-16 06:10:47 --> URI Class Initialized
INFO - 2024-06-16 06:10:47 --> Router Class Initialized
INFO - 2024-06-16 06:10:47 --> Output Class Initialized
INFO - 2024-06-16 06:10:47 --> Security Class Initialized
DEBUG - 2024-06-16 06:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:10:47 --> Input Class Initialized
INFO - 2024-06-16 06:10:47 --> Language Class Initialized
INFO - 2024-06-16 06:10:47 --> Language Class Initialized
INFO - 2024-06-16 06:10:47 --> Config Class Initialized
INFO - 2024-06-16 06:10:47 --> Loader Class Initialized
INFO - 2024-06-16 06:10:47 --> Helper loaded: url_helper
INFO - 2024-06-16 06:10:47 --> Helper loaded: file_helper
INFO - 2024-06-16 06:10:47 --> Helper loaded: form_helper
INFO - 2024-06-16 06:10:47 --> Helper loaded: my_helper
INFO - 2024-06-16 06:10:47 --> Database Driver Class Initialized
INFO - 2024-06-16 06:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:10:47 --> Controller Class Initialized
INFO - 2024-06-16 06:10:49 --> Config Class Initialized
INFO - 2024-06-16 06:10:49 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:10:49 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:10:49 --> Utf8 Class Initialized
INFO - 2024-06-16 06:10:49 --> URI Class Initialized
INFO - 2024-06-16 06:10:49 --> Router Class Initialized
INFO - 2024-06-16 06:10:49 --> Output Class Initialized
INFO - 2024-06-16 06:10:49 --> Security Class Initialized
DEBUG - 2024-06-16 06:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:10:49 --> Input Class Initialized
INFO - 2024-06-16 06:10:49 --> Language Class Initialized
INFO - 2024-06-16 06:10:49 --> Language Class Initialized
INFO - 2024-06-16 06:10:49 --> Config Class Initialized
INFO - 2024-06-16 06:10:49 --> Loader Class Initialized
INFO - 2024-06-16 06:10:49 --> Helper loaded: url_helper
INFO - 2024-06-16 06:10:49 --> Helper loaded: file_helper
INFO - 2024-06-16 06:10:49 --> Helper loaded: form_helper
INFO - 2024-06-16 06:10:49 --> Helper loaded: my_helper
INFO - 2024-06-16 06:10:49 --> Database Driver Class Initialized
INFO - 2024-06-16 06:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:10:49 --> Controller Class Initialized
INFO - 2024-06-16 06:10:49 --> Final output sent to browser
DEBUG - 2024-06-16 06:10:49 --> Total execution time: 0.0727
INFO - 2024-06-16 06:13:53 --> Config Class Initialized
INFO - 2024-06-16 06:13:53 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:13:53 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:13:53 --> Utf8 Class Initialized
INFO - 2024-06-16 06:13:53 --> URI Class Initialized
INFO - 2024-06-16 06:13:53 --> Router Class Initialized
INFO - 2024-06-16 06:13:53 --> Output Class Initialized
INFO - 2024-06-16 06:13:53 --> Security Class Initialized
DEBUG - 2024-06-16 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:13:53 --> Input Class Initialized
INFO - 2024-06-16 06:13:53 --> Language Class Initialized
INFO - 2024-06-16 06:13:53 --> Language Class Initialized
INFO - 2024-06-16 06:13:53 --> Config Class Initialized
INFO - 2024-06-16 06:13:53 --> Loader Class Initialized
INFO - 2024-06-16 06:13:53 --> Helper loaded: url_helper
INFO - 2024-06-16 06:13:53 --> Helper loaded: file_helper
INFO - 2024-06-16 06:13:53 --> Helper loaded: form_helper
INFO - 2024-06-16 06:13:53 --> Helper loaded: my_helper
INFO - 2024-06-16 06:13:53 --> Database Driver Class Initialized
INFO - 2024-06-16 06:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:13:53 --> Controller Class Initialized
INFO - 2024-06-16 06:13:53 --> Final output sent to browser
DEBUG - 2024-06-16 06:13:53 --> Total execution time: 0.0878
INFO - 2024-06-16 06:14:22 --> Config Class Initialized
INFO - 2024-06-16 06:14:22 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:14:22 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:14:22 --> Utf8 Class Initialized
INFO - 2024-06-16 06:14:22 --> URI Class Initialized
INFO - 2024-06-16 06:14:22 --> Router Class Initialized
INFO - 2024-06-16 06:14:22 --> Output Class Initialized
INFO - 2024-06-16 06:14:22 --> Security Class Initialized
DEBUG - 2024-06-16 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:14:22 --> Input Class Initialized
INFO - 2024-06-16 06:14:22 --> Language Class Initialized
INFO - 2024-06-16 06:14:22 --> Language Class Initialized
INFO - 2024-06-16 06:14:22 --> Config Class Initialized
INFO - 2024-06-16 06:14:22 --> Loader Class Initialized
INFO - 2024-06-16 06:14:22 --> Helper loaded: url_helper
INFO - 2024-06-16 06:14:22 --> Helper loaded: file_helper
INFO - 2024-06-16 06:14:22 --> Helper loaded: form_helper
INFO - 2024-06-16 06:14:22 --> Helper loaded: my_helper
INFO - 2024-06-16 06:14:22 --> Database Driver Class Initialized
INFO - 2024-06-16 06:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:14:22 --> Controller Class Initialized
DEBUG - 2024-06-16 06:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-16 06:14:22 --> Final output sent to browser
DEBUG - 2024-06-16 06:14:22 --> Total execution time: 0.1487
INFO - 2024-06-16 06:14:31 --> Config Class Initialized
INFO - 2024-06-16 06:14:31 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:14:31 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:14:31 --> Utf8 Class Initialized
INFO - 2024-06-16 06:14:31 --> URI Class Initialized
INFO - 2024-06-16 06:14:31 --> Router Class Initialized
INFO - 2024-06-16 06:14:31 --> Output Class Initialized
INFO - 2024-06-16 06:14:31 --> Security Class Initialized
DEBUG - 2024-06-16 06:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:14:31 --> Input Class Initialized
INFO - 2024-06-16 06:14:31 --> Language Class Initialized
INFO - 2024-06-16 06:14:31 --> Language Class Initialized
INFO - 2024-06-16 06:14:31 --> Config Class Initialized
INFO - 2024-06-16 06:14:31 --> Loader Class Initialized
INFO - 2024-06-16 06:14:31 --> Helper loaded: url_helper
INFO - 2024-06-16 06:14:31 --> Helper loaded: file_helper
INFO - 2024-06-16 06:14:31 --> Helper loaded: form_helper
INFO - 2024-06-16 06:14:31 --> Helper loaded: my_helper
INFO - 2024-06-16 06:14:31 --> Database Driver Class Initialized
INFO - 2024-06-16 06:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:14:31 --> Controller Class Initialized
INFO - 2024-06-16 06:14:31 --> Final output sent to browser
DEBUG - 2024-06-16 06:14:31 --> Total execution time: 0.0775
INFO - 2024-06-16 06:14:37 --> Config Class Initialized
INFO - 2024-06-16 06:14:37 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:14:37 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:14:37 --> Utf8 Class Initialized
INFO - 2024-06-16 06:14:37 --> URI Class Initialized
INFO - 2024-06-16 06:14:37 --> Router Class Initialized
INFO - 2024-06-16 06:14:37 --> Output Class Initialized
INFO - 2024-06-16 06:14:37 --> Security Class Initialized
DEBUG - 2024-06-16 06:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:14:37 --> Input Class Initialized
INFO - 2024-06-16 06:14:37 --> Language Class Initialized
INFO - 2024-06-16 06:14:37 --> Language Class Initialized
INFO - 2024-06-16 06:14:37 --> Config Class Initialized
INFO - 2024-06-16 06:14:37 --> Loader Class Initialized
INFO - 2024-06-16 06:14:37 --> Helper loaded: url_helper
INFO - 2024-06-16 06:14:37 --> Helper loaded: file_helper
INFO - 2024-06-16 06:14:37 --> Helper loaded: form_helper
INFO - 2024-06-16 06:14:37 --> Helper loaded: my_helper
INFO - 2024-06-16 06:14:37 --> Database Driver Class Initialized
INFO - 2024-06-16 06:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:14:37 --> Controller Class Initialized
INFO - 2024-06-16 06:17:53 --> Config Class Initialized
INFO - 2024-06-16 06:17:53 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:17:53 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:17:53 --> Utf8 Class Initialized
INFO - 2024-06-16 06:17:53 --> URI Class Initialized
INFO - 2024-06-16 06:17:53 --> Router Class Initialized
INFO - 2024-06-16 06:17:53 --> Output Class Initialized
INFO - 2024-06-16 06:17:53 --> Security Class Initialized
DEBUG - 2024-06-16 06:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:17:53 --> Input Class Initialized
INFO - 2024-06-16 06:17:53 --> Language Class Initialized
INFO - 2024-06-16 06:17:53 --> Language Class Initialized
INFO - 2024-06-16 06:17:53 --> Config Class Initialized
INFO - 2024-06-16 06:17:53 --> Loader Class Initialized
INFO - 2024-06-16 06:17:53 --> Helper loaded: url_helper
INFO - 2024-06-16 06:17:53 --> Helper loaded: file_helper
INFO - 2024-06-16 06:17:53 --> Helper loaded: form_helper
INFO - 2024-06-16 06:17:53 --> Helper loaded: my_helper
INFO - 2024-06-16 06:17:53 --> Database Driver Class Initialized
INFO - 2024-06-16 06:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:17:53 --> Controller Class Initialized
DEBUG - 2024-06-16 06:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-16 06:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:17:53 --> Final output sent to browser
DEBUG - 2024-06-16 06:17:53 --> Total execution time: 0.1877
INFO - 2024-06-16 06:18:02 --> Config Class Initialized
INFO - 2024-06-16 06:18:02 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:02 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:02 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:02 --> URI Class Initialized
INFO - 2024-06-16 06:18:02 --> Router Class Initialized
INFO - 2024-06-16 06:18:02 --> Output Class Initialized
INFO - 2024-06-16 06:18:02 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:02 --> Input Class Initialized
INFO - 2024-06-16 06:18:02 --> Language Class Initialized
INFO - 2024-06-16 06:18:02 --> Language Class Initialized
INFO - 2024-06-16 06:18:02 --> Config Class Initialized
INFO - 2024-06-16 06:18:02 --> Loader Class Initialized
INFO - 2024-06-16 06:18:02 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:02 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:02 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:02 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:02 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:02 --> Controller Class Initialized
INFO - 2024-06-16 06:18:02 --> Config Class Initialized
INFO - 2024-06-16 06:18:02 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:02 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:02 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:02 --> URI Class Initialized
INFO - 2024-06-16 06:18:02 --> Router Class Initialized
INFO - 2024-06-16 06:18:02 --> Output Class Initialized
INFO - 2024-06-16 06:18:02 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:02 --> Input Class Initialized
INFO - 2024-06-16 06:18:02 --> Language Class Initialized
INFO - 2024-06-16 06:18:02 --> Language Class Initialized
INFO - 2024-06-16 06:18:02 --> Config Class Initialized
INFO - 2024-06-16 06:18:02 --> Loader Class Initialized
INFO - 2024-06-16 06:18:02 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:02 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:02 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:02 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:02 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:02 --> Controller Class Initialized
DEBUG - 2024-06-16 06:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-16 06:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:18:02 --> Final output sent to browser
DEBUG - 2024-06-16 06:18:02 --> Total execution time: 0.0717
INFO - 2024-06-16 06:18:03 --> Config Class Initialized
INFO - 2024-06-16 06:18:03 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:03 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:03 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:03 --> URI Class Initialized
INFO - 2024-06-16 06:18:03 --> Router Class Initialized
INFO - 2024-06-16 06:18:03 --> Output Class Initialized
INFO - 2024-06-16 06:18:03 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:03 --> Input Class Initialized
INFO - 2024-06-16 06:18:03 --> Language Class Initialized
INFO - 2024-06-16 06:18:03 --> Language Class Initialized
INFO - 2024-06-16 06:18:03 --> Config Class Initialized
INFO - 2024-06-16 06:18:03 --> Loader Class Initialized
INFO - 2024-06-16 06:18:03 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:03 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:03 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:03 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:03 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:03 --> Controller Class Initialized
INFO - 2024-06-16 06:18:06 --> Config Class Initialized
INFO - 2024-06-16 06:18:06 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:06 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:06 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:06 --> URI Class Initialized
INFO - 2024-06-16 06:18:06 --> Router Class Initialized
INFO - 2024-06-16 06:18:06 --> Output Class Initialized
INFO - 2024-06-16 06:18:06 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:06 --> Input Class Initialized
INFO - 2024-06-16 06:18:06 --> Language Class Initialized
INFO - 2024-06-16 06:18:06 --> Language Class Initialized
INFO - 2024-06-16 06:18:06 --> Config Class Initialized
INFO - 2024-06-16 06:18:06 --> Loader Class Initialized
INFO - 2024-06-16 06:18:06 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:06 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:06 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:06 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:06 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:06 --> Controller Class Initialized
INFO - 2024-06-16 06:18:07 --> Final output sent to browser
DEBUG - 2024-06-16 06:18:07 --> Total execution time: 0.1022
INFO - 2024-06-16 06:18:10 --> Config Class Initialized
INFO - 2024-06-16 06:18:10 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:10 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:10 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:10 --> URI Class Initialized
INFO - 2024-06-16 06:18:10 --> Router Class Initialized
INFO - 2024-06-16 06:18:10 --> Output Class Initialized
INFO - 2024-06-16 06:18:10 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:10 --> Input Class Initialized
INFO - 2024-06-16 06:18:10 --> Language Class Initialized
INFO - 2024-06-16 06:18:10 --> Language Class Initialized
INFO - 2024-06-16 06:18:10 --> Config Class Initialized
INFO - 2024-06-16 06:18:10 --> Loader Class Initialized
INFO - 2024-06-16 06:18:10 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:10 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:10 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:10 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:10 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:10 --> Controller Class Initialized
INFO - 2024-06-16 06:18:10 --> Final output sent to browser
DEBUG - 2024-06-16 06:18:10 --> Total execution time: 0.0442
INFO - 2024-06-16 06:18:57 --> Config Class Initialized
INFO - 2024-06-16 06:18:57 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:57 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:57 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:57 --> URI Class Initialized
INFO - 2024-06-16 06:18:57 --> Router Class Initialized
INFO - 2024-06-16 06:18:57 --> Output Class Initialized
INFO - 2024-06-16 06:18:57 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:57 --> Input Class Initialized
INFO - 2024-06-16 06:18:57 --> Language Class Initialized
INFO - 2024-06-16 06:18:57 --> Language Class Initialized
INFO - 2024-06-16 06:18:57 --> Config Class Initialized
INFO - 2024-06-16 06:18:57 --> Loader Class Initialized
INFO - 2024-06-16 06:18:57 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:57 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:57 --> Controller Class Initialized
INFO - 2024-06-16 06:18:57 --> Helper loaded: cookie_helper
INFO - 2024-06-16 06:18:57 --> Config Class Initialized
INFO - 2024-06-16 06:18:57 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:57 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:57 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:57 --> URI Class Initialized
INFO - 2024-06-16 06:18:57 --> Router Class Initialized
INFO - 2024-06-16 06:18:57 --> Output Class Initialized
INFO - 2024-06-16 06:18:57 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:57 --> Input Class Initialized
INFO - 2024-06-16 06:18:57 --> Language Class Initialized
INFO - 2024-06-16 06:18:57 --> Language Class Initialized
INFO - 2024-06-16 06:18:57 --> Config Class Initialized
INFO - 2024-06-16 06:18:57 --> Loader Class Initialized
INFO - 2024-06-16 06:18:57 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:57 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:57 --> Controller Class Initialized
INFO - 2024-06-16 06:18:57 --> Config Class Initialized
INFO - 2024-06-16 06:18:57 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:18:57 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:18:57 --> Utf8 Class Initialized
INFO - 2024-06-16 06:18:57 --> URI Class Initialized
INFO - 2024-06-16 06:18:57 --> Router Class Initialized
INFO - 2024-06-16 06:18:57 --> Output Class Initialized
INFO - 2024-06-16 06:18:57 --> Security Class Initialized
DEBUG - 2024-06-16 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:18:57 --> Input Class Initialized
INFO - 2024-06-16 06:18:57 --> Language Class Initialized
INFO - 2024-06-16 06:18:57 --> Language Class Initialized
INFO - 2024-06-16 06:18:57 --> Config Class Initialized
INFO - 2024-06-16 06:18:57 --> Loader Class Initialized
INFO - 2024-06-16 06:18:57 --> Helper loaded: url_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: file_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: form_helper
INFO - 2024-06-16 06:18:57 --> Helper loaded: my_helper
INFO - 2024-06-16 06:18:57 --> Database Driver Class Initialized
INFO - 2024-06-16 06:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:18:57 --> Controller Class Initialized
DEBUG - 2024-06-16 06:18:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-16 06:18:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:18:57 --> Final output sent to browser
DEBUG - 2024-06-16 06:18:57 --> Total execution time: 0.0332
INFO - 2024-06-16 06:19:08 --> Config Class Initialized
INFO - 2024-06-16 06:19:08 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:19:08 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:19:08 --> Utf8 Class Initialized
INFO - 2024-06-16 06:19:08 --> URI Class Initialized
INFO - 2024-06-16 06:19:08 --> Router Class Initialized
INFO - 2024-06-16 06:19:08 --> Output Class Initialized
INFO - 2024-06-16 06:19:08 --> Security Class Initialized
DEBUG - 2024-06-16 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:19:08 --> Input Class Initialized
INFO - 2024-06-16 06:19:08 --> Language Class Initialized
INFO - 2024-06-16 06:19:08 --> Language Class Initialized
INFO - 2024-06-16 06:19:08 --> Config Class Initialized
INFO - 2024-06-16 06:19:08 --> Loader Class Initialized
INFO - 2024-06-16 06:19:08 --> Helper loaded: url_helper
INFO - 2024-06-16 06:19:08 --> Helper loaded: file_helper
INFO - 2024-06-16 06:19:08 --> Helper loaded: form_helper
INFO - 2024-06-16 06:19:08 --> Helper loaded: my_helper
INFO - 2024-06-16 06:19:08 --> Database Driver Class Initialized
INFO - 2024-06-16 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:19:08 --> Controller Class Initialized
INFO - 2024-06-16 06:19:08 --> Helper loaded: cookie_helper
INFO - 2024-06-16 06:19:08 --> Final output sent to browser
DEBUG - 2024-06-16 06:19:08 --> Total execution time: 0.2175
INFO - 2024-06-16 06:19:08 --> Config Class Initialized
INFO - 2024-06-16 06:19:08 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:19:08 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:19:08 --> Utf8 Class Initialized
INFO - 2024-06-16 06:19:08 --> URI Class Initialized
INFO - 2024-06-16 06:19:08 --> Router Class Initialized
INFO - 2024-06-16 06:19:08 --> Output Class Initialized
INFO - 2024-06-16 06:19:08 --> Security Class Initialized
DEBUG - 2024-06-16 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:19:08 --> Input Class Initialized
INFO - 2024-06-16 06:19:08 --> Language Class Initialized
INFO - 2024-06-16 06:19:08 --> Language Class Initialized
INFO - 2024-06-16 06:19:08 --> Config Class Initialized
INFO - 2024-06-16 06:19:08 --> Loader Class Initialized
INFO - 2024-06-16 06:19:08 --> Helper loaded: url_helper
INFO - 2024-06-16 06:19:08 --> Helper loaded: file_helper
INFO - 2024-06-16 06:19:08 --> Helper loaded: form_helper
INFO - 2024-06-16 06:19:08 --> Helper loaded: my_helper
INFO - 2024-06-16 06:19:08 --> Database Driver Class Initialized
INFO - 2024-06-16 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:19:08 --> Controller Class Initialized
DEBUG - 2024-06-16 06:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-16 06:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:19:08 --> Final output sent to browser
DEBUG - 2024-06-16 06:19:08 --> Total execution time: 0.0820
INFO - 2024-06-16 06:19:14 --> Config Class Initialized
INFO - 2024-06-16 06:19:14 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:19:14 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:19:14 --> Utf8 Class Initialized
INFO - 2024-06-16 06:19:14 --> URI Class Initialized
INFO - 2024-06-16 06:19:14 --> Router Class Initialized
INFO - 2024-06-16 06:19:14 --> Output Class Initialized
INFO - 2024-06-16 06:19:14 --> Security Class Initialized
DEBUG - 2024-06-16 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:19:14 --> Input Class Initialized
INFO - 2024-06-16 06:19:14 --> Language Class Initialized
INFO - 2024-06-16 06:19:14 --> Language Class Initialized
INFO - 2024-06-16 06:19:14 --> Config Class Initialized
INFO - 2024-06-16 06:19:14 --> Loader Class Initialized
INFO - 2024-06-16 06:19:14 --> Helper loaded: url_helper
INFO - 2024-06-16 06:19:14 --> Helper loaded: file_helper
INFO - 2024-06-16 06:19:14 --> Helper loaded: form_helper
INFO - 2024-06-16 06:19:14 --> Helper loaded: my_helper
INFO - 2024-06-16 06:19:14 --> Database Driver Class Initialized
INFO - 2024-06-16 06:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:19:14 --> Controller Class Initialized
DEBUG - 2024-06-16 06:19:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-06-16 06:19:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:19:14 --> Final output sent to browser
DEBUG - 2024-06-16 06:19:14 --> Total execution time: 0.0284
INFO - 2024-06-16 06:19:14 --> Config Class Initialized
INFO - 2024-06-16 06:19:14 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:19:14 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:19:14 --> Utf8 Class Initialized
INFO - 2024-06-16 06:19:14 --> URI Class Initialized
INFO - 2024-06-16 06:19:14 --> Router Class Initialized
INFO - 2024-06-16 06:19:14 --> Output Class Initialized
INFO - 2024-06-16 06:19:14 --> Security Class Initialized
DEBUG - 2024-06-16 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:19:14 --> Input Class Initialized
INFO - 2024-06-16 06:19:14 --> Language Class Initialized
ERROR - 2024-06-16 06:19:14 --> 404 Page Not Found: /index
INFO - 2024-06-16 06:19:14 --> Config Class Initialized
INFO - 2024-06-16 06:19:14 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:19:14 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:19:14 --> Utf8 Class Initialized
INFO - 2024-06-16 06:19:14 --> URI Class Initialized
INFO - 2024-06-16 06:19:14 --> Router Class Initialized
INFO - 2024-06-16 06:19:14 --> Output Class Initialized
INFO - 2024-06-16 06:19:14 --> Security Class Initialized
DEBUG - 2024-06-16 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:19:14 --> Input Class Initialized
INFO - 2024-06-16 06:19:14 --> Language Class Initialized
INFO - 2024-06-16 06:19:14 --> Language Class Initialized
INFO - 2024-06-16 06:19:14 --> Config Class Initialized
INFO - 2024-06-16 06:19:14 --> Loader Class Initialized
INFO - 2024-06-16 06:19:14 --> Helper loaded: url_helper
INFO - 2024-06-16 06:19:14 --> Helper loaded: file_helper
INFO - 2024-06-16 06:19:14 --> Helper loaded: form_helper
INFO - 2024-06-16 06:19:14 --> Helper loaded: my_helper
INFO - 2024-06-16 06:19:14 --> Database Driver Class Initialized
INFO - 2024-06-16 06:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:19:14 --> Controller Class Initialized
INFO - 2024-06-16 06:19:44 --> Config Class Initialized
INFO - 2024-06-16 06:19:44 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:19:44 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:19:44 --> Utf8 Class Initialized
INFO - 2024-06-16 06:19:44 --> URI Class Initialized
INFO - 2024-06-16 06:19:44 --> Router Class Initialized
INFO - 2024-06-16 06:19:44 --> Output Class Initialized
INFO - 2024-06-16 06:19:44 --> Security Class Initialized
DEBUG - 2024-06-16 06:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:19:44 --> Input Class Initialized
INFO - 2024-06-16 06:19:44 --> Language Class Initialized
INFO - 2024-06-16 06:19:44 --> Language Class Initialized
INFO - 2024-06-16 06:19:44 --> Config Class Initialized
INFO - 2024-06-16 06:19:44 --> Loader Class Initialized
INFO - 2024-06-16 06:19:44 --> Helper loaded: url_helper
INFO - 2024-06-16 06:19:44 --> Helper loaded: file_helper
INFO - 2024-06-16 06:19:44 --> Helper loaded: form_helper
INFO - 2024-06-16 06:19:44 --> Helper loaded: my_helper
INFO - 2024-06-16 06:19:44 --> Database Driver Class Initialized
INFO - 2024-06-16 06:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:19:44 --> Controller Class Initialized
INFO - 2024-06-16 06:19:44 --> Final output sent to browser
DEBUG - 2024-06-16 06:19:44 --> Total execution time: 0.1134
INFO - 2024-06-16 06:20:11 --> Config Class Initialized
INFO - 2024-06-16 06:20:11 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:11 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:11 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:11 --> URI Class Initialized
INFO - 2024-06-16 06:20:11 --> Router Class Initialized
INFO - 2024-06-16 06:20:11 --> Output Class Initialized
INFO - 2024-06-16 06:20:11 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:11 --> Input Class Initialized
INFO - 2024-06-16 06:20:11 --> Language Class Initialized
INFO - 2024-06-16 06:20:11 --> Language Class Initialized
INFO - 2024-06-16 06:20:11 --> Config Class Initialized
INFO - 2024-06-16 06:20:11 --> Loader Class Initialized
INFO - 2024-06-16 06:20:11 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:11 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:11 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:11 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:11 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:11 --> Controller Class Initialized
INFO - 2024-06-16 06:20:11 --> Final output sent to browser
DEBUG - 2024-06-16 06:20:11 --> Total execution time: 0.1424
INFO - 2024-06-16 06:20:11 --> Config Class Initialized
INFO - 2024-06-16 06:20:11 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:11 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:11 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:11 --> URI Class Initialized
INFO - 2024-06-16 06:20:11 --> Router Class Initialized
INFO - 2024-06-16 06:20:11 --> Output Class Initialized
INFO - 2024-06-16 06:20:11 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:11 --> Input Class Initialized
INFO - 2024-06-16 06:20:11 --> Language Class Initialized
ERROR - 2024-06-16 06:20:11 --> 404 Page Not Found: /index
INFO - 2024-06-16 06:20:11 --> Config Class Initialized
INFO - 2024-06-16 06:20:11 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:11 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:11 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:11 --> URI Class Initialized
INFO - 2024-06-16 06:20:11 --> Router Class Initialized
INFO - 2024-06-16 06:20:11 --> Output Class Initialized
INFO - 2024-06-16 06:20:11 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:11 --> Input Class Initialized
INFO - 2024-06-16 06:20:11 --> Language Class Initialized
INFO - 2024-06-16 06:20:11 --> Language Class Initialized
INFO - 2024-06-16 06:20:11 --> Config Class Initialized
INFO - 2024-06-16 06:20:11 --> Loader Class Initialized
INFO - 2024-06-16 06:20:11 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:11 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:11 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:11 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:11 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:11 --> Controller Class Initialized
INFO - 2024-06-16 06:20:20 --> Config Class Initialized
INFO - 2024-06-16 06:20:20 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:20 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:20 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:20 --> URI Class Initialized
INFO - 2024-06-16 06:20:20 --> Router Class Initialized
INFO - 2024-06-16 06:20:20 --> Output Class Initialized
INFO - 2024-06-16 06:20:20 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:20 --> Input Class Initialized
INFO - 2024-06-16 06:20:20 --> Language Class Initialized
INFO - 2024-06-16 06:20:20 --> Language Class Initialized
INFO - 2024-06-16 06:20:20 --> Config Class Initialized
INFO - 2024-06-16 06:20:20 --> Loader Class Initialized
INFO - 2024-06-16 06:20:20 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:20 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:20 --> Controller Class Initialized
INFO - 2024-06-16 06:20:20 --> Helper loaded: cookie_helper
INFO - 2024-06-16 06:20:20 --> Config Class Initialized
INFO - 2024-06-16 06:20:20 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:20 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:20 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:20 --> URI Class Initialized
INFO - 2024-06-16 06:20:20 --> Router Class Initialized
INFO - 2024-06-16 06:20:20 --> Output Class Initialized
INFO - 2024-06-16 06:20:20 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:20 --> Input Class Initialized
INFO - 2024-06-16 06:20:20 --> Language Class Initialized
INFO - 2024-06-16 06:20:20 --> Language Class Initialized
INFO - 2024-06-16 06:20:20 --> Config Class Initialized
INFO - 2024-06-16 06:20:20 --> Loader Class Initialized
INFO - 2024-06-16 06:20:20 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:20 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:20 --> Controller Class Initialized
INFO - 2024-06-16 06:20:20 --> Config Class Initialized
INFO - 2024-06-16 06:20:20 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:20 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:20 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:20 --> URI Class Initialized
INFO - 2024-06-16 06:20:20 --> Router Class Initialized
INFO - 2024-06-16 06:20:20 --> Output Class Initialized
INFO - 2024-06-16 06:20:20 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:20 --> Input Class Initialized
INFO - 2024-06-16 06:20:20 --> Language Class Initialized
INFO - 2024-06-16 06:20:20 --> Language Class Initialized
INFO - 2024-06-16 06:20:20 --> Config Class Initialized
INFO - 2024-06-16 06:20:20 --> Loader Class Initialized
INFO - 2024-06-16 06:20:20 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:20 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:20 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:20 --> Controller Class Initialized
DEBUG - 2024-06-16 06:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-16 06:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:20:20 --> Final output sent to browser
DEBUG - 2024-06-16 06:20:20 --> Total execution time: 0.0299
INFO - 2024-06-16 06:20:26 --> Config Class Initialized
INFO - 2024-06-16 06:20:26 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:26 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:26 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:26 --> URI Class Initialized
INFO - 2024-06-16 06:20:26 --> Router Class Initialized
INFO - 2024-06-16 06:20:26 --> Output Class Initialized
INFO - 2024-06-16 06:20:26 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:26 --> Input Class Initialized
INFO - 2024-06-16 06:20:26 --> Language Class Initialized
INFO - 2024-06-16 06:20:26 --> Language Class Initialized
INFO - 2024-06-16 06:20:26 --> Config Class Initialized
INFO - 2024-06-16 06:20:26 --> Loader Class Initialized
INFO - 2024-06-16 06:20:26 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:26 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:26 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:26 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:26 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:26 --> Controller Class Initialized
INFO - 2024-06-16 06:20:26 --> Helper loaded: cookie_helper
INFO - 2024-06-16 06:20:26 --> Final output sent to browser
DEBUG - 2024-06-16 06:20:26 --> Total execution time: 0.1377
INFO - 2024-06-16 06:20:26 --> Config Class Initialized
INFO - 2024-06-16 06:20:26 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:26 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:26 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:26 --> URI Class Initialized
INFO - 2024-06-16 06:20:26 --> Router Class Initialized
INFO - 2024-06-16 06:20:26 --> Output Class Initialized
INFO - 2024-06-16 06:20:26 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:26 --> Input Class Initialized
INFO - 2024-06-16 06:20:26 --> Language Class Initialized
INFO - 2024-06-16 06:20:26 --> Language Class Initialized
INFO - 2024-06-16 06:20:26 --> Config Class Initialized
INFO - 2024-06-16 06:20:26 --> Loader Class Initialized
INFO - 2024-06-16 06:20:26 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:26 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:26 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:26 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:26 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:26 --> Controller Class Initialized
DEBUG - 2024-06-16 06:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-16 06:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:20:26 --> Final output sent to browser
DEBUG - 2024-06-16 06:20:26 --> Total execution time: 0.0803
INFO - 2024-06-16 06:20:30 --> Config Class Initialized
INFO - 2024-06-16 06:20:30 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:30 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:30 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:30 --> URI Class Initialized
INFO - 2024-06-16 06:20:30 --> Router Class Initialized
INFO - 2024-06-16 06:20:30 --> Output Class Initialized
INFO - 2024-06-16 06:20:30 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:30 --> Input Class Initialized
INFO - 2024-06-16 06:20:30 --> Language Class Initialized
INFO - 2024-06-16 06:20:30 --> Language Class Initialized
INFO - 2024-06-16 06:20:30 --> Config Class Initialized
INFO - 2024-06-16 06:20:30 --> Loader Class Initialized
INFO - 2024-06-16 06:20:30 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:30 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:30 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:30 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:30 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:30 --> Controller Class Initialized
DEBUG - 2024-06-16 06:20:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-16 06:20:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 06:20:30 --> Final output sent to browser
DEBUG - 2024-06-16 06:20:30 --> Total execution time: 0.0673
INFO - 2024-06-16 06:20:33 --> Config Class Initialized
INFO - 2024-06-16 06:20:33 --> Hooks Class Initialized
DEBUG - 2024-06-16 06:20:33 --> UTF-8 Support Enabled
INFO - 2024-06-16 06:20:33 --> Utf8 Class Initialized
INFO - 2024-06-16 06:20:33 --> URI Class Initialized
INFO - 2024-06-16 06:20:33 --> Router Class Initialized
INFO - 2024-06-16 06:20:33 --> Output Class Initialized
INFO - 2024-06-16 06:20:33 --> Security Class Initialized
DEBUG - 2024-06-16 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 06:20:33 --> Input Class Initialized
INFO - 2024-06-16 06:20:33 --> Language Class Initialized
INFO - 2024-06-16 06:20:33 --> Language Class Initialized
INFO - 2024-06-16 06:20:33 --> Config Class Initialized
INFO - 2024-06-16 06:20:33 --> Loader Class Initialized
INFO - 2024-06-16 06:20:33 --> Helper loaded: url_helper
INFO - 2024-06-16 06:20:33 --> Helper loaded: file_helper
INFO - 2024-06-16 06:20:33 --> Helper loaded: form_helper
INFO - 2024-06-16 06:20:33 --> Helper loaded: my_helper
INFO - 2024-06-16 06:20:33 --> Database Driver Class Initialized
INFO - 2024-06-16 06:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 06:20:33 --> Controller Class Initialized
DEBUG - 2024-06-16 06:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-16 06:20:35 --> Final output sent to browser
DEBUG - 2024-06-16 06:20:35 --> Total execution time: 2.3594
INFO - 2024-06-16 08:26:32 --> Config Class Initialized
INFO - 2024-06-16 08:26:32 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:32 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:32 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:32 --> URI Class Initialized
DEBUG - 2024-06-16 08:26:32 --> No URI present. Default controller set.
INFO - 2024-06-16 08:26:32 --> Router Class Initialized
INFO - 2024-06-16 08:26:32 --> Output Class Initialized
INFO - 2024-06-16 08:26:32 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:32 --> Input Class Initialized
INFO - 2024-06-16 08:26:32 --> Language Class Initialized
INFO - 2024-06-16 08:26:32 --> Language Class Initialized
INFO - 2024-06-16 08:26:32 --> Config Class Initialized
INFO - 2024-06-16 08:26:32 --> Loader Class Initialized
INFO - 2024-06-16 08:26:32 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:32 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:32 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:32 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:32 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:32 --> Controller Class Initialized
INFO - 2024-06-16 08:26:32 --> Config Class Initialized
INFO - 2024-06-16 08:26:32 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:32 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:32 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:32 --> URI Class Initialized
INFO - 2024-06-16 08:26:32 --> Router Class Initialized
INFO - 2024-06-16 08:26:32 --> Output Class Initialized
INFO - 2024-06-16 08:26:32 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:32 --> Input Class Initialized
INFO - 2024-06-16 08:26:32 --> Language Class Initialized
INFO - 2024-06-16 08:26:32 --> Language Class Initialized
INFO - 2024-06-16 08:26:32 --> Config Class Initialized
INFO - 2024-06-16 08:26:32 --> Loader Class Initialized
INFO - 2024-06-16 08:26:32 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:32 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:33 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:33 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:33 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:33 --> Controller Class Initialized
DEBUG - 2024-06-16 08:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-16 08:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:26:33 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:33 --> Total execution time: 0.3207
INFO - 2024-06-16 08:26:34 --> Config Class Initialized
INFO - 2024-06-16 08:26:34 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:34 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:34 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:34 --> URI Class Initialized
DEBUG - 2024-06-16 08:26:34 --> No URI present. Default controller set.
INFO - 2024-06-16 08:26:34 --> Router Class Initialized
INFO - 2024-06-16 08:26:34 --> Output Class Initialized
INFO - 2024-06-16 08:26:34 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:34 --> Input Class Initialized
INFO - 2024-06-16 08:26:34 --> Language Class Initialized
INFO - 2024-06-16 08:26:34 --> Language Class Initialized
INFO - 2024-06-16 08:26:34 --> Config Class Initialized
INFO - 2024-06-16 08:26:34 --> Loader Class Initialized
INFO - 2024-06-16 08:26:34 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:34 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:34 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:34 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:34 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:34 --> Controller Class Initialized
INFO - 2024-06-16 08:26:35 --> Config Class Initialized
INFO - 2024-06-16 08:26:35 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:35 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:35 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:35 --> URI Class Initialized
INFO - 2024-06-16 08:26:35 --> Router Class Initialized
INFO - 2024-06-16 08:26:35 --> Output Class Initialized
INFO - 2024-06-16 08:26:35 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:35 --> Input Class Initialized
INFO - 2024-06-16 08:26:35 --> Language Class Initialized
INFO - 2024-06-16 08:26:35 --> Language Class Initialized
INFO - 2024-06-16 08:26:35 --> Config Class Initialized
INFO - 2024-06-16 08:26:35 --> Loader Class Initialized
INFO - 2024-06-16 08:26:35 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:35 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:35 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:35 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:35 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:35 --> Controller Class Initialized
INFO - 2024-06-16 08:26:35 --> Helper loaded: cookie_helper
INFO - 2024-06-16 08:26:35 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:35 --> Total execution time: 0.1232
INFO - 2024-06-16 08:26:35 --> Config Class Initialized
INFO - 2024-06-16 08:26:35 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:35 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:35 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:35 --> URI Class Initialized
INFO - 2024-06-16 08:26:35 --> Router Class Initialized
INFO - 2024-06-16 08:26:35 --> Output Class Initialized
INFO - 2024-06-16 08:26:35 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:35 --> Input Class Initialized
INFO - 2024-06-16 08:26:35 --> Language Class Initialized
INFO - 2024-06-16 08:26:35 --> Language Class Initialized
INFO - 2024-06-16 08:26:35 --> Config Class Initialized
INFO - 2024-06-16 08:26:35 --> Loader Class Initialized
INFO - 2024-06-16 08:26:35 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:35 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:35 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:35 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:35 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:35 --> Controller Class Initialized
DEBUG - 2024-06-16 08:26:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-16 08:26:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:26:35 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:35 --> Total execution time: 0.0571
INFO - 2024-06-16 08:26:36 --> Config Class Initialized
INFO - 2024-06-16 08:26:36 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:36 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:36 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:36 --> URI Class Initialized
INFO - 2024-06-16 08:26:36 --> Router Class Initialized
INFO - 2024-06-16 08:26:36 --> Output Class Initialized
INFO - 2024-06-16 08:26:36 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:36 --> Input Class Initialized
INFO - 2024-06-16 08:26:36 --> Language Class Initialized
INFO - 2024-06-16 08:26:36 --> Language Class Initialized
INFO - 2024-06-16 08:26:36 --> Config Class Initialized
INFO - 2024-06-16 08:26:36 --> Loader Class Initialized
INFO - 2024-06-16 08:26:36 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:36 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:36 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:36 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:36 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:36 --> Controller Class Initialized
DEBUG - 2024-06-16 08:26:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-16 08:26:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:26:36 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:36 --> Total execution time: 0.0911
INFO - 2024-06-16 08:26:38 --> Config Class Initialized
INFO - 2024-06-16 08:26:38 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:38 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:38 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:38 --> URI Class Initialized
INFO - 2024-06-16 08:26:38 --> Router Class Initialized
INFO - 2024-06-16 08:26:38 --> Output Class Initialized
INFO - 2024-06-16 08:26:38 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:38 --> Input Class Initialized
INFO - 2024-06-16 08:26:38 --> Language Class Initialized
INFO - 2024-06-16 08:26:38 --> Language Class Initialized
INFO - 2024-06-16 08:26:38 --> Config Class Initialized
INFO - 2024-06-16 08:26:38 --> Loader Class Initialized
INFO - 2024-06-16 08:26:38 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:38 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:38 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:38 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:38 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:38 --> Controller Class Initialized
DEBUG - 2024-06-16 08:26:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-16 08:26:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:26:38 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:38 --> Total execution time: 0.0526
INFO - 2024-06-16 08:26:40 --> Config Class Initialized
INFO - 2024-06-16 08:26:40 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:40 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:40 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:40 --> URI Class Initialized
INFO - 2024-06-16 08:26:40 --> Router Class Initialized
INFO - 2024-06-16 08:26:40 --> Output Class Initialized
INFO - 2024-06-16 08:26:40 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:40 --> Input Class Initialized
INFO - 2024-06-16 08:26:40 --> Language Class Initialized
INFO - 2024-06-16 08:26:40 --> Language Class Initialized
INFO - 2024-06-16 08:26:40 --> Config Class Initialized
INFO - 2024-06-16 08:26:40 --> Loader Class Initialized
INFO - 2024-06-16 08:26:40 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:40 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:40 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:40 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:40 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:40 --> Controller Class Initialized
DEBUG - 2024-06-16 08:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-16 08:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:26:40 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:40 --> Total execution time: 0.0511
INFO - 2024-06-16 08:26:40 --> Config Class Initialized
INFO - 2024-06-16 08:26:40 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:40 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:40 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:40 --> URI Class Initialized
INFO - 2024-06-16 08:26:40 --> Router Class Initialized
INFO - 2024-06-16 08:26:40 --> Output Class Initialized
INFO - 2024-06-16 08:26:40 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:40 --> Input Class Initialized
INFO - 2024-06-16 08:26:40 --> Language Class Initialized
INFO - 2024-06-16 08:26:40 --> Language Class Initialized
INFO - 2024-06-16 08:26:40 --> Config Class Initialized
INFO - 2024-06-16 08:26:40 --> Loader Class Initialized
INFO - 2024-06-16 08:26:40 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:40 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:40 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:40 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:40 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:40 --> Controller Class Initialized
INFO - 2024-06-16 08:26:43 --> Config Class Initialized
INFO - 2024-06-16 08:26:43 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:43 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:43 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:43 --> URI Class Initialized
INFO - 2024-06-16 08:26:43 --> Router Class Initialized
INFO - 2024-06-16 08:26:43 --> Output Class Initialized
INFO - 2024-06-16 08:26:43 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:43 --> Input Class Initialized
INFO - 2024-06-16 08:26:43 --> Language Class Initialized
INFO - 2024-06-16 08:26:43 --> Language Class Initialized
INFO - 2024-06-16 08:26:43 --> Config Class Initialized
INFO - 2024-06-16 08:26:43 --> Loader Class Initialized
INFO - 2024-06-16 08:26:43 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:43 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:43 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:43 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:43 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:43 --> Controller Class Initialized
INFO - 2024-06-16 08:26:43 --> Final output sent to browser
DEBUG - 2024-06-16 08:26:43 --> Total execution time: 0.0550
INFO - 2024-06-16 08:26:45 --> Config Class Initialized
INFO - 2024-06-16 08:26:45 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:26:45 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:26:45 --> Utf8 Class Initialized
INFO - 2024-06-16 08:26:45 --> URI Class Initialized
INFO - 2024-06-16 08:26:45 --> Router Class Initialized
INFO - 2024-06-16 08:26:45 --> Output Class Initialized
INFO - 2024-06-16 08:26:45 --> Security Class Initialized
DEBUG - 2024-06-16 08:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:26:45 --> Input Class Initialized
INFO - 2024-06-16 08:26:45 --> Language Class Initialized
INFO - 2024-06-16 08:26:45 --> Language Class Initialized
INFO - 2024-06-16 08:26:45 --> Config Class Initialized
INFO - 2024-06-16 08:26:45 --> Loader Class Initialized
INFO - 2024-06-16 08:26:45 --> Helper loaded: url_helper
INFO - 2024-06-16 08:26:45 --> Helper loaded: file_helper
INFO - 2024-06-16 08:26:45 --> Helper loaded: form_helper
INFO - 2024-06-16 08:26:45 --> Helper loaded: my_helper
INFO - 2024-06-16 08:26:45 --> Database Driver Class Initialized
INFO - 2024-06-16 08:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:26:45 --> Controller Class Initialized
INFO - 2024-06-16 08:27:22 --> Config Class Initialized
INFO - 2024-06-16 08:27:22 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:27:22 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:27:22 --> Utf8 Class Initialized
INFO - 2024-06-16 08:27:22 --> URI Class Initialized
INFO - 2024-06-16 08:27:22 --> Router Class Initialized
INFO - 2024-06-16 08:27:22 --> Output Class Initialized
INFO - 2024-06-16 08:27:22 --> Security Class Initialized
DEBUG - 2024-06-16 08:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:27:22 --> Input Class Initialized
INFO - 2024-06-16 08:27:22 --> Language Class Initialized
INFO - 2024-06-16 08:27:22 --> Language Class Initialized
INFO - 2024-06-16 08:27:22 --> Config Class Initialized
INFO - 2024-06-16 08:27:22 --> Loader Class Initialized
INFO - 2024-06-16 08:27:22 --> Helper loaded: url_helper
INFO - 2024-06-16 08:27:22 --> Helper loaded: file_helper
INFO - 2024-06-16 08:27:22 --> Helper loaded: form_helper
INFO - 2024-06-16 08:27:22 --> Helper loaded: my_helper
INFO - 2024-06-16 08:27:22 --> Database Driver Class Initialized
INFO - 2024-06-16 08:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:27:22 --> Controller Class Initialized
INFO - 2024-06-16 08:27:22 --> Final output sent to browser
DEBUG - 2024-06-16 08:27:22 --> Total execution time: 0.0562
INFO - 2024-06-16 08:27:22 --> Config Class Initialized
INFO - 2024-06-16 08:27:22 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:27:22 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:27:22 --> Utf8 Class Initialized
INFO - 2024-06-16 08:27:22 --> URI Class Initialized
INFO - 2024-06-16 08:27:22 --> Router Class Initialized
INFO - 2024-06-16 08:27:22 --> Output Class Initialized
INFO - 2024-06-16 08:27:22 --> Security Class Initialized
DEBUG - 2024-06-16 08:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:27:22 --> Input Class Initialized
INFO - 2024-06-16 08:27:22 --> Language Class Initialized
INFO - 2024-06-16 08:27:22 --> Language Class Initialized
INFO - 2024-06-16 08:27:22 --> Config Class Initialized
INFO - 2024-06-16 08:27:22 --> Loader Class Initialized
INFO - 2024-06-16 08:27:22 --> Helper loaded: url_helper
INFO - 2024-06-16 08:27:22 --> Helper loaded: file_helper
INFO - 2024-06-16 08:27:22 --> Helper loaded: form_helper
INFO - 2024-06-16 08:27:22 --> Helper loaded: my_helper
INFO - 2024-06-16 08:27:22 --> Database Driver Class Initialized
INFO - 2024-06-16 08:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:27:22 --> Controller Class Initialized
INFO - 2024-06-16 08:27:22 --> Final output sent to browser
DEBUG - 2024-06-16 08:27:22 --> Total execution time: 0.0474
INFO - 2024-06-16 08:27:39 --> Config Class Initialized
INFO - 2024-06-16 08:27:39 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:27:39 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:27:39 --> Utf8 Class Initialized
INFO - 2024-06-16 08:27:39 --> URI Class Initialized
INFO - 2024-06-16 08:27:39 --> Router Class Initialized
INFO - 2024-06-16 08:27:39 --> Output Class Initialized
INFO - 2024-06-16 08:27:39 --> Security Class Initialized
DEBUG - 2024-06-16 08:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:27:39 --> Input Class Initialized
INFO - 2024-06-16 08:27:39 --> Language Class Initialized
INFO - 2024-06-16 08:27:39 --> Language Class Initialized
INFO - 2024-06-16 08:27:39 --> Config Class Initialized
INFO - 2024-06-16 08:27:39 --> Loader Class Initialized
INFO - 2024-06-16 08:27:39 --> Helper loaded: url_helper
INFO - 2024-06-16 08:27:39 --> Helper loaded: file_helper
INFO - 2024-06-16 08:27:39 --> Helper loaded: form_helper
INFO - 2024-06-16 08:27:39 --> Helper loaded: my_helper
INFO - 2024-06-16 08:27:39 --> Database Driver Class Initialized
INFO - 2024-06-16 08:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:27:39 --> Controller Class Initialized
INFO - 2024-06-16 08:27:39 --> Final output sent to browser
DEBUG - 2024-06-16 08:27:39 --> Total execution time: 0.4496
INFO - 2024-06-16 08:27:42 --> Config Class Initialized
INFO - 2024-06-16 08:27:42 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:27:42 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:27:42 --> Utf8 Class Initialized
INFO - 2024-06-16 08:27:42 --> URI Class Initialized
INFO - 2024-06-16 08:27:42 --> Router Class Initialized
INFO - 2024-06-16 08:27:42 --> Output Class Initialized
INFO - 2024-06-16 08:27:42 --> Security Class Initialized
DEBUG - 2024-06-16 08:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:27:42 --> Input Class Initialized
INFO - 2024-06-16 08:27:42 --> Language Class Initialized
INFO - 2024-06-16 08:27:42 --> Language Class Initialized
INFO - 2024-06-16 08:27:42 --> Config Class Initialized
INFO - 2024-06-16 08:27:42 --> Loader Class Initialized
INFO - 2024-06-16 08:27:42 --> Helper loaded: url_helper
INFO - 2024-06-16 08:27:42 --> Helper loaded: file_helper
INFO - 2024-06-16 08:27:42 --> Helper loaded: form_helper
INFO - 2024-06-16 08:27:42 --> Helper loaded: my_helper
INFO - 2024-06-16 08:27:42 --> Database Driver Class Initialized
INFO - 2024-06-16 08:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:27:42 --> Controller Class Initialized
INFO - 2024-06-16 08:27:42 --> Final output sent to browser
DEBUG - 2024-06-16 08:27:42 --> Total execution time: 0.1235
INFO - 2024-06-16 08:28:05 --> Config Class Initialized
INFO - 2024-06-16 08:28:05 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:05 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:05 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:05 --> URI Class Initialized
INFO - 2024-06-16 08:28:05 --> Router Class Initialized
INFO - 2024-06-16 08:28:05 --> Output Class Initialized
INFO - 2024-06-16 08:28:05 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:05 --> Input Class Initialized
INFO - 2024-06-16 08:28:05 --> Language Class Initialized
INFO - 2024-06-16 08:28:05 --> Language Class Initialized
INFO - 2024-06-16 08:28:05 --> Config Class Initialized
INFO - 2024-06-16 08:28:05 --> Loader Class Initialized
INFO - 2024-06-16 08:28:05 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:05 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:05 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:05 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:05 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:05 --> Controller Class Initialized
INFO - 2024-06-16 08:28:05 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:05 --> Total execution time: 0.1850
INFO - 2024-06-16 08:28:08 --> Config Class Initialized
INFO - 2024-06-16 08:28:08 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:08 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:08 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:08 --> URI Class Initialized
INFO - 2024-06-16 08:28:08 --> Router Class Initialized
INFO - 2024-06-16 08:28:08 --> Output Class Initialized
INFO - 2024-06-16 08:28:08 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:08 --> Input Class Initialized
INFO - 2024-06-16 08:28:08 --> Language Class Initialized
INFO - 2024-06-16 08:28:08 --> Language Class Initialized
INFO - 2024-06-16 08:28:08 --> Config Class Initialized
INFO - 2024-06-16 08:28:08 --> Loader Class Initialized
INFO - 2024-06-16 08:28:08 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:08 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:08 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:08 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:08 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:08 --> Controller Class Initialized
INFO - 2024-06-16 08:28:08 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:08 --> Total execution time: 0.0695
INFO - 2024-06-16 08:28:26 --> Config Class Initialized
INFO - 2024-06-16 08:28:26 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:26 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:26 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:26 --> URI Class Initialized
INFO - 2024-06-16 08:28:26 --> Router Class Initialized
INFO - 2024-06-16 08:28:26 --> Output Class Initialized
INFO - 2024-06-16 08:28:26 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:26 --> Input Class Initialized
INFO - 2024-06-16 08:28:26 --> Language Class Initialized
INFO - 2024-06-16 08:28:26 --> Language Class Initialized
INFO - 2024-06-16 08:28:26 --> Config Class Initialized
INFO - 2024-06-16 08:28:26 --> Loader Class Initialized
INFO - 2024-06-16 08:28:26 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:26 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:26 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:26 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:26 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:26 --> Controller Class Initialized
INFO - 2024-06-16 08:28:26 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:26 --> Total execution time: 0.2982
INFO - 2024-06-16 08:28:31 --> Config Class Initialized
INFO - 2024-06-16 08:28:31 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:31 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:31 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:31 --> URI Class Initialized
INFO - 2024-06-16 08:28:31 --> Router Class Initialized
INFO - 2024-06-16 08:28:31 --> Output Class Initialized
INFO - 2024-06-16 08:28:31 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:31 --> Input Class Initialized
INFO - 2024-06-16 08:28:31 --> Language Class Initialized
INFO - 2024-06-16 08:28:32 --> Language Class Initialized
INFO - 2024-06-16 08:28:32 --> Config Class Initialized
INFO - 2024-06-16 08:28:32 --> Loader Class Initialized
INFO - 2024-06-16 08:28:32 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:32 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:32 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:32 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:32 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:32 --> Controller Class Initialized
INFO - 2024-06-16 08:28:32 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:32 --> Total execution time: 0.1051
INFO - 2024-06-16 08:28:35 --> Config Class Initialized
INFO - 2024-06-16 08:28:35 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:35 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:35 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:35 --> URI Class Initialized
INFO - 2024-06-16 08:28:35 --> Router Class Initialized
INFO - 2024-06-16 08:28:35 --> Output Class Initialized
INFO - 2024-06-16 08:28:35 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:35 --> Input Class Initialized
INFO - 2024-06-16 08:28:35 --> Language Class Initialized
INFO - 2024-06-16 08:28:35 --> Language Class Initialized
INFO - 2024-06-16 08:28:35 --> Config Class Initialized
INFO - 2024-06-16 08:28:35 --> Loader Class Initialized
INFO - 2024-06-16 08:28:35 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:35 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:35 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:35 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:35 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:35 --> Controller Class Initialized
INFO - 2024-06-16 08:28:35 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:35 --> Total execution time: 0.0778
INFO - 2024-06-16 08:28:42 --> Config Class Initialized
INFO - 2024-06-16 08:28:42 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:42 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:42 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:42 --> URI Class Initialized
INFO - 2024-06-16 08:28:42 --> Router Class Initialized
INFO - 2024-06-16 08:28:42 --> Output Class Initialized
INFO - 2024-06-16 08:28:42 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:42 --> Input Class Initialized
INFO - 2024-06-16 08:28:42 --> Language Class Initialized
INFO - 2024-06-16 08:28:42 --> Language Class Initialized
INFO - 2024-06-16 08:28:42 --> Config Class Initialized
INFO - 2024-06-16 08:28:42 --> Loader Class Initialized
INFO - 2024-06-16 08:28:42 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:42 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:42 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:42 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:42 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:42 --> Controller Class Initialized
INFO - 2024-06-16 08:28:42 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:42 --> Total execution time: 0.1216
INFO - 2024-06-16 08:28:46 --> Config Class Initialized
INFO - 2024-06-16 08:28:46 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:46 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:46 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:46 --> URI Class Initialized
INFO - 2024-06-16 08:28:46 --> Router Class Initialized
INFO - 2024-06-16 08:28:46 --> Output Class Initialized
INFO - 2024-06-16 08:28:46 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:46 --> Input Class Initialized
INFO - 2024-06-16 08:28:46 --> Language Class Initialized
INFO - 2024-06-16 08:28:46 --> Language Class Initialized
INFO - 2024-06-16 08:28:46 --> Config Class Initialized
INFO - 2024-06-16 08:28:46 --> Loader Class Initialized
INFO - 2024-06-16 08:28:46 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:46 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:46 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:46 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:46 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:46 --> Controller Class Initialized
INFO - 2024-06-16 08:28:47 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:47 --> Total execution time: 0.1019
INFO - 2024-06-16 08:28:52 --> Config Class Initialized
INFO - 2024-06-16 08:28:52 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:52 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:52 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:52 --> URI Class Initialized
INFO - 2024-06-16 08:28:52 --> Router Class Initialized
INFO - 2024-06-16 08:28:52 --> Output Class Initialized
INFO - 2024-06-16 08:28:52 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:52 --> Input Class Initialized
INFO - 2024-06-16 08:28:52 --> Language Class Initialized
INFO - 2024-06-16 08:28:52 --> Language Class Initialized
INFO - 2024-06-16 08:28:52 --> Config Class Initialized
INFO - 2024-06-16 08:28:52 --> Loader Class Initialized
INFO - 2024-06-16 08:28:52 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:52 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:52 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:52 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:52 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:52 --> Controller Class Initialized
INFO - 2024-06-16 08:28:52 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:52 --> Total execution time: 0.2165
INFO - 2024-06-16 08:28:55 --> Config Class Initialized
INFO - 2024-06-16 08:28:55 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:55 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:55 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:55 --> URI Class Initialized
INFO - 2024-06-16 08:28:55 --> Router Class Initialized
INFO - 2024-06-16 08:28:55 --> Output Class Initialized
INFO - 2024-06-16 08:28:55 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:55 --> Input Class Initialized
INFO - 2024-06-16 08:28:55 --> Language Class Initialized
INFO - 2024-06-16 08:28:55 --> Language Class Initialized
INFO - 2024-06-16 08:28:55 --> Config Class Initialized
INFO - 2024-06-16 08:28:55 --> Loader Class Initialized
INFO - 2024-06-16 08:28:55 --> Helper loaded: url_helper
INFO - 2024-06-16 08:28:55 --> Helper loaded: file_helper
INFO - 2024-06-16 08:28:55 --> Helper loaded: form_helper
INFO - 2024-06-16 08:28:55 --> Helper loaded: my_helper
INFO - 2024-06-16 08:28:55 --> Database Driver Class Initialized
INFO - 2024-06-16 08:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:28:55 --> Controller Class Initialized
INFO - 2024-06-16 08:28:55 --> Final output sent to browser
DEBUG - 2024-06-16 08:28:55 --> Total execution time: 0.1445
INFO - 2024-06-16 08:28:59 --> Config Class Initialized
INFO - 2024-06-16 08:28:59 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:28:59 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:28:59 --> Utf8 Class Initialized
INFO - 2024-06-16 08:28:59 --> URI Class Initialized
INFO - 2024-06-16 08:28:59 --> Router Class Initialized
INFO - 2024-06-16 08:28:59 --> Output Class Initialized
INFO - 2024-06-16 08:28:59 --> Security Class Initialized
DEBUG - 2024-06-16 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:28:59 --> Input Class Initialized
INFO - 2024-06-16 08:28:59 --> Language Class Initialized
INFO - 2024-06-16 08:29:00 --> Language Class Initialized
INFO - 2024-06-16 08:29:00 --> Config Class Initialized
INFO - 2024-06-16 08:29:00 --> Loader Class Initialized
INFO - 2024-06-16 08:29:00 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:00 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:00 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:00 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:00 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:00 --> Controller Class Initialized
INFO - 2024-06-16 08:29:00 --> Final output sent to browser
DEBUG - 2024-06-16 08:29:00 --> Total execution time: 0.0772
INFO - 2024-06-16 08:29:03 --> Config Class Initialized
INFO - 2024-06-16 08:29:03 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:29:03 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:29:03 --> Utf8 Class Initialized
INFO - 2024-06-16 08:29:03 --> URI Class Initialized
INFO - 2024-06-16 08:29:03 --> Router Class Initialized
INFO - 2024-06-16 08:29:03 --> Output Class Initialized
INFO - 2024-06-16 08:29:03 --> Security Class Initialized
DEBUG - 2024-06-16 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:29:03 --> Input Class Initialized
INFO - 2024-06-16 08:29:03 --> Language Class Initialized
INFO - 2024-06-16 08:29:03 --> Language Class Initialized
INFO - 2024-06-16 08:29:03 --> Config Class Initialized
INFO - 2024-06-16 08:29:03 --> Loader Class Initialized
INFO - 2024-06-16 08:29:03 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:03 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:03 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:03 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:03 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:03 --> Controller Class Initialized
INFO - 2024-06-16 08:29:03 --> Final output sent to browser
DEBUG - 2024-06-16 08:29:03 --> Total execution time: 0.1507
INFO - 2024-06-16 08:29:11 --> Config Class Initialized
INFO - 2024-06-16 08:29:11 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:29:11 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:29:11 --> Utf8 Class Initialized
INFO - 2024-06-16 08:29:11 --> URI Class Initialized
INFO - 2024-06-16 08:29:11 --> Router Class Initialized
INFO - 2024-06-16 08:29:11 --> Output Class Initialized
INFO - 2024-06-16 08:29:11 --> Security Class Initialized
DEBUG - 2024-06-16 08:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:29:11 --> Input Class Initialized
INFO - 2024-06-16 08:29:11 --> Language Class Initialized
INFO - 2024-06-16 08:29:11 --> Language Class Initialized
INFO - 2024-06-16 08:29:11 --> Config Class Initialized
INFO - 2024-06-16 08:29:11 --> Loader Class Initialized
INFO - 2024-06-16 08:29:11 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:11 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:11 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:11 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:11 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:11 --> Controller Class Initialized
DEBUG - 2024-06-16 08:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-16 08:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:29:11 --> Final output sent to browser
DEBUG - 2024-06-16 08:29:11 --> Total execution time: 0.1088
INFO - 2024-06-16 08:29:11 --> Config Class Initialized
INFO - 2024-06-16 08:29:11 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:29:11 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:29:11 --> Utf8 Class Initialized
INFO - 2024-06-16 08:29:11 --> URI Class Initialized
INFO - 2024-06-16 08:29:11 --> Router Class Initialized
INFO - 2024-06-16 08:29:11 --> Output Class Initialized
INFO - 2024-06-16 08:29:11 --> Security Class Initialized
DEBUG - 2024-06-16 08:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:29:11 --> Input Class Initialized
INFO - 2024-06-16 08:29:11 --> Language Class Initialized
INFO - 2024-06-16 08:29:11 --> Language Class Initialized
INFO - 2024-06-16 08:29:11 --> Config Class Initialized
INFO - 2024-06-16 08:29:11 --> Loader Class Initialized
INFO - 2024-06-16 08:29:11 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:11 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:11 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:11 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:11 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:11 --> Controller Class Initialized
INFO - 2024-06-16 08:29:13 --> Config Class Initialized
INFO - 2024-06-16 08:29:13 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:29:13 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:29:13 --> Utf8 Class Initialized
INFO - 2024-06-16 08:29:13 --> URI Class Initialized
INFO - 2024-06-16 08:29:13 --> Router Class Initialized
INFO - 2024-06-16 08:29:13 --> Output Class Initialized
INFO - 2024-06-16 08:29:13 --> Security Class Initialized
DEBUG - 2024-06-16 08:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:29:13 --> Input Class Initialized
INFO - 2024-06-16 08:29:13 --> Language Class Initialized
INFO - 2024-06-16 08:29:13 --> Language Class Initialized
INFO - 2024-06-16 08:29:13 --> Config Class Initialized
INFO - 2024-06-16 08:29:13 --> Loader Class Initialized
INFO - 2024-06-16 08:29:13 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:13 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:13 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:13 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:13 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:13 --> Controller Class Initialized
INFO - 2024-06-16 08:29:37 --> Config Class Initialized
INFO - 2024-06-16 08:29:37 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:29:37 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:29:37 --> Utf8 Class Initialized
INFO - 2024-06-16 08:29:37 --> URI Class Initialized
INFO - 2024-06-16 08:29:37 --> Router Class Initialized
INFO - 2024-06-16 08:29:37 --> Output Class Initialized
INFO - 2024-06-16 08:29:37 --> Security Class Initialized
DEBUG - 2024-06-16 08:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:29:37 --> Input Class Initialized
INFO - 2024-06-16 08:29:37 --> Language Class Initialized
INFO - 2024-06-16 08:29:37 --> Language Class Initialized
INFO - 2024-06-16 08:29:37 --> Config Class Initialized
INFO - 2024-06-16 08:29:37 --> Loader Class Initialized
INFO - 2024-06-16 08:29:37 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:37 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:37 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:37 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:37 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:37 --> Controller Class Initialized
DEBUG - 2024-06-16 08:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-16 08:29:37 --> Final output sent to browser
DEBUG - 2024-06-16 08:29:37 --> Total execution time: 0.1042
INFO - 2024-06-16 08:29:51 --> Config Class Initialized
INFO - 2024-06-16 08:29:51 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:29:51 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:29:51 --> Utf8 Class Initialized
INFO - 2024-06-16 08:29:51 --> URI Class Initialized
INFO - 2024-06-16 08:29:51 --> Router Class Initialized
INFO - 2024-06-16 08:29:51 --> Output Class Initialized
INFO - 2024-06-16 08:29:51 --> Security Class Initialized
DEBUG - 2024-06-16 08:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:29:51 --> Input Class Initialized
INFO - 2024-06-16 08:29:51 --> Language Class Initialized
INFO - 2024-06-16 08:29:51 --> Language Class Initialized
INFO - 2024-06-16 08:29:51 --> Config Class Initialized
INFO - 2024-06-16 08:29:51 --> Loader Class Initialized
INFO - 2024-06-16 08:29:51 --> Helper loaded: url_helper
INFO - 2024-06-16 08:29:51 --> Helper loaded: file_helper
INFO - 2024-06-16 08:29:51 --> Helper loaded: form_helper
INFO - 2024-06-16 08:29:51 --> Helper loaded: my_helper
INFO - 2024-06-16 08:29:51 --> Database Driver Class Initialized
INFO - 2024-06-16 08:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:29:51 --> Controller Class Initialized
INFO - 2024-06-16 08:29:51 --> Final output sent to browser
DEBUG - 2024-06-16 08:29:51 --> Total execution time: 0.3194
INFO - 2024-06-16 08:30:02 --> Config Class Initialized
INFO - 2024-06-16 08:30:02 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:02 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:02 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:02 --> URI Class Initialized
INFO - 2024-06-16 08:30:02 --> Router Class Initialized
INFO - 2024-06-16 08:30:02 --> Output Class Initialized
INFO - 2024-06-16 08:30:02 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:02 --> Input Class Initialized
INFO - 2024-06-16 08:30:02 --> Language Class Initialized
INFO - 2024-06-16 08:30:02 --> Language Class Initialized
INFO - 2024-06-16 08:30:02 --> Config Class Initialized
INFO - 2024-06-16 08:30:02 --> Loader Class Initialized
INFO - 2024-06-16 08:30:02 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:02 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:02 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:02 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:02 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:03 --> Controller Class Initialized
INFO - 2024-06-16 08:30:03 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:03 --> Total execution time: 0.6594
INFO - 2024-06-16 08:30:06 --> Config Class Initialized
INFO - 2024-06-16 08:30:06 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:06 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:06 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:06 --> URI Class Initialized
INFO - 2024-06-16 08:30:06 --> Router Class Initialized
INFO - 2024-06-16 08:30:06 --> Output Class Initialized
INFO - 2024-06-16 08:30:06 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:06 --> Input Class Initialized
INFO - 2024-06-16 08:30:06 --> Language Class Initialized
INFO - 2024-06-16 08:30:06 --> Language Class Initialized
INFO - 2024-06-16 08:30:06 --> Config Class Initialized
INFO - 2024-06-16 08:30:06 --> Loader Class Initialized
INFO - 2024-06-16 08:30:06 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:06 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:06 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:06 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:06 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:06 --> Controller Class Initialized
DEBUG - 2024-06-16 08:30:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-16 08:30:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:30:06 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:06 --> Total execution time: 0.0436
INFO - 2024-06-16 08:30:06 --> Config Class Initialized
INFO - 2024-06-16 08:30:06 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:06 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:06 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:06 --> URI Class Initialized
INFO - 2024-06-16 08:30:06 --> Router Class Initialized
INFO - 2024-06-16 08:30:06 --> Output Class Initialized
INFO - 2024-06-16 08:30:06 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:06 --> Input Class Initialized
INFO - 2024-06-16 08:30:06 --> Language Class Initialized
INFO - 2024-06-16 08:30:06 --> Language Class Initialized
INFO - 2024-06-16 08:30:06 --> Config Class Initialized
INFO - 2024-06-16 08:30:06 --> Loader Class Initialized
INFO - 2024-06-16 08:30:06 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:06 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:06 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:06 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:06 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:06 --> Controller Class Initialized
INFO - 2024-06-16 08:30:09 --> Config Class Initialized
INFO - 2024-06-16 08:30:09 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:09 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:09 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:09 --> URI Class Initialized
INFO - 2024-06-16 08:30:09 --> Router Class Initialized
INFO - 2024-06-16 08:30:09 --> Output Class Initialized
INFO - 2024-06-16 08:30:09 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:09 --> Input Class Initialized
INFO - 2024-06-16 08:30:09 --> Language Class Initialized
INFO - 2024-06-16 08:30:09 --> Language Class Initialized
INFO - 2024-06-16 08:30:09 --> Config Class Initialized
INFO - 2024-06-16 08:30:09 --> Loader Class Initialized
INFO - 2024-06-16 08:30:09 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:09 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:09 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:09 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:09 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:09 --> Controller Class Initialized
DEBUG - 2024-06-16 08:30:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-16 08:30:09 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:09 --> Total execution time: 0.1096
INFO - 2024-06-16 08:30:42 --> Config Class Initialized
INFO - 2024-06-16 08:30:42 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:42 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:42 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:42 --> URI Class Initialized
INFO - 2024-06-16 08:30:42 --> Router Class Initialized
INFO - 2024-06-16 08:30:42 --> Output Class Initialized
INFO - 2024-06-16 08:30:42 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:42 --> Input Class Initialized
INFO - 2024-06-16 08:30:42 --> Language Class Initialized
INFO - 2024-06-16 08:30:42 --> Language Class Initialized
INFO - 2024-06-16 08:30:42 --> Config Class Initialized
INFO - 2024-06-16 08:30:42 --> Loader Class Initialized
INFO - 2024-06-16 08:30:42 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:42 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:42 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:42 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:42 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:42 --> Controller Class Initialized
INFO - 2024-06-16 08:30:42 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:42 --> Total execution time: 0.1610
INFO - 2024-06-16 08:30:51 --> Config Class Initialized
INFO - 2024-06-16 08:30:51 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:51 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:51 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:51 --> URI Class Initialized
INFO - 2024-06-16 08:30:51 --> Router Class Initialized
INFO - 2024-06-16 08:30:51 --> Output Class Initialized
INFO - 2024-06-16 08:30:51 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:51 --> Input Class Initialized
INFO - 2024-06-16 08:30:51 --> Language Class Initialized
INFO - 2024-06-16 08:30:51 --> Language Class Initialized
INFO - 2024-06-16 08:30:51 --> Config Class Initialized
INFO - 2024-06-16 08:30:51 --> Loader Class Initialized
INFO - 2024-06-16 08:30:51 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:51 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:51 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:51 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:51 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:51 --> Controller Class Initialized
INFO - 2024-06-16 08:30:51 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:51 --> Total execution time: 0.1182
INFO - 2024-06-16 08:30:55 --> Config Class Initialized
INFO - 2024-06-16 08:30:55 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:55 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:55 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:55 --> URI Class Initialized
INFO - 2024-06-16 08:30:55 --> Router Class Initialized
INFO - 2024-06-16 08:30:55 --> Output Class Initialized
INFO - 2024-06-16 08:30:55 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:55 --> Input Class Initialized
INFO - 2024-06-16 08:30:55 --> Language Class Initialized
INFO - 2024-06-16 08:30:55 --> Language Class Initialized
INFO - 2024-06-16 08:30:55 --> Config Class Initialized
INFO - 2024-06-16 08:30:55 --> Loader Class Initialized
INFO - 2024-06-16 08:30:55 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:55 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:55 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:55 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:55 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:55 --> Controller Class Initialized
DEBUG - 2024-06-16 08:30:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-16 08:30:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-16 08:30:55 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:55 --> Total execution time: 0.0373
INFO - 2024-06-16 08:30:55 --> Config Class Initialized
INFO - 2024-06-16 08:30:55 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:55 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:55 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:55 --> URI Class Initialized
INFO - 2024-06-16 08:30:55 --> Router Class Initialized
INFO - 2024-06-16 08:30:55 --> Output Class Initialized
INFO - 2024-06-16 08:30:55 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:55 --> Input Class Initialized
INFO - 2024-06-16 08:30:55 --> Language Class Initialized
INFO - 2024-06-16 08:30:55 --> Language Class Initialized
INFO - 2024-06-16 08:30:55 --> Config Class Initialized
INFO - 2024-06-16 08:30:55 --> Loader Class Initialized
INFO - 2024-06-16 08:30:55 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:55 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:55 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:55 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:55 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:55 --> Controller Class Initialized
INFO - 2024-06-16 08:30:57 --> Config Class Initialized
INFO - 2024-06-16 08:30:57 --> Hooks Class Initialized
DEBUG - 2024-06-16 08:30:57 --> UTF-8 Support Enabled
INFO - 2024-06-16 08:30:57 --> Utf8 Class Initialized
INFO - 2024-06-16 08:30:57 --> URI Class Initialized
INFO - 2024-06-16 08:30:57 --> Router Class Initialized
INFO - 2024-06-16 08:30:57 --> Output Class Initialized
INFO - 2024-06-16 08:30:57 --> Security Class Initialized
DEBUG - 2024-06-16 08:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-16 08:30:57 --> Input Class Initialized
INFO - 2024-06-16 08:30:57 --> Language Class Initialized
INFO - 2024-06-16 08:30:57 --> Language Class Initialized
INFO - 2024-06-16 08:30:57 --> Config Class Initialized
INFO - 2024-06-16 08:30:57 --> Loader Class Initialized
INFO - 2024-06-16 08:30:57 --> Helper loaded: url_helper
INFO - 2024-06-16 08:30:57 --> Helper loaded: file_helper
INFO - 2024-06-16 08:30:57 --> Helper loaded: form_helper
INFO - 2024-06-16 08:30:57 --> Helper loaded: my_helper
INFO - 2024-06-16 08:30:57 --> Database Driver Class Initialized
INFO - 2024-06-16 08:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-16 08:30:57 --> Controller Class Initialized
DEBUG - 2024-06-16 08:30:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-16 08:30:57 --> Final output sent to browser
DEBUG - 2024-06-16 08:30:57 --> Total execution time: 0.1011
