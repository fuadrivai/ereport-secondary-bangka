<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-20 14:47:01 --> Config Class Initialized
INFO - 2023-11-20 14:47:01 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:01 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:01 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:01 --> URI Class Initialized
DEBUG - 2023-11-20 14:47:01 --> No URI present. Default controller set.
INFO - 2023-11-20 14:47:01 --> Router Class Initialized
INFO - 2023-11-20 14:47:01 --> Output Class Initialized
INFO - 2023-11-20 14:47:01 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:01 --> Input Class Initialized
INFO - 2023-11-20 14:47:01 --> Language Class Initialized
INFO - 2023-11-20 14:47:01 --> Language Class Initialized
INFO - 2023-11-20 14:47:01 --> Config Class Initialized
INFO - 2023-11-20 14:47:01 --> Loader Class Initialized
INFO - 2023-11-20 14:47:01 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:01 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:02 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:02 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:02 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:02 --> Controller Class Initialized
INFO - 2023-11-20 14:47:02 --> Config Class Initialized
INFO - 2023-11-20 14:47:02 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:02 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:02 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:02 --> URI Class Initialized
INFO - 2023-11-20 14:47:02 --> Router Class Initialized
INFO - 2023-11-20 14:47:02 --> Output Class Initialized
INFO - 2023-11-20 14:47:02 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:02 --> Input Class Initialized
INFO - 2023-11-20 14:47:02 --> Language Class Initialized
INFO - 2023-11-20 14:47:02 --> Language Class Initialized
INFO - 2023-11-20 14:47:02 --> Config Class Initialized
INFO - 2023-11-20 14:47:02 --> Loader Class Initialized
INFO - 2023-11-20 14:47:02 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:02 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:02 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:02 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:02 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:02 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 14:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:47:02 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:02 --> Total execution time: 0.1078
INFO - 2023-11-20 14:47:10 --> Config Class Initialized
INFO - 2023-11-20 14:47:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:10 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:10 --> URI Class Initialized
INFO - 2023-11-20 14:47:10 --> Router Class Initialized
INFO - 2023-11-20 14:47:10 --> Output Class Initialized
INFO - 2023-11-20 14:47:10 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:10 --> Input Class Initialized
INFO - 2023-11-20 14:47:10 --> Language Class Initialized
INFO - 2023-11-20 14:47:10 --> Language Class Initialized
INFO - 2023-11-20 14:47:10 --> Config Class Initialized
INFO - 2023-11-20 14:47:10 --> Loader Class Initialized
INFO - 2023-11-20 14:47:10 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:10 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:10 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:10 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:10 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:10 --> Controller Class Initialized
INFO - 2023-11-20 14:47:10 --> Helper loaded: cookie_helper
INFO - 2023-11-20 14:47:10 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:10 --> Total execution time: 0.0393
INFO - 2023-11-20 14:47:10 --> Config Class Initialized
INFO - 2023-11-20 14:47:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:10 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:10 --> URI Class Initialized
INFO - 2023-11-20 14:47:10 --> Router Class Initialized
INFO - 2023-11-20 14:47:10 --> Output Class Initialized
INFO - 2023-11-20 14:47:10 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:10 --> Input Class Initialized
INFO - 2023-11-20 14:47:10 --> Language Class Initialized
INFO - 2023-11-20 14:47:10 --> Language Class Initialized
INFO - 2023-11-20 14:47:10 --> Config Class Initialized
INFO - 2023-11-20 14:47:10 --> Loader Class Initialized
INFO - 2023-11-20 14:47:10 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:10 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:10 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:10 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:10 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:10 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-20 14:47:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:47:10 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:10 --> Total execution time: 0.0524
INFO - 2023-11-20 14:47:14 --> Config Class Initialized
INFO - 2023-11-20 14:47:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:14 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:14 --> URI Class Initialized
INFO - 2023-11-20 14:47:14 --> Router Class Initialized
INFO - 2023-11-20 14:47:14 --> Output Class Initialized
INFO - 2023-11-20 14:47:14 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:14 --> Input Class Initialized
INFO - 2023-11-20 14:47:14 --> Language Class Initialized
INFO - 2023-11-20 14:47:14 --> Language Class Initialized
INFO - 2023-11-20 14:47:14 --> Config Class Initialized
INFO - 2023-11-20 14:47:14 --> Loader Class Initialized
INFO - 2023-11-20 14:47:14 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:14 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:14 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:14 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:14 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:14 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-11-20 14:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:47:14 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:14 --> Total execution time: 0.0418
INFO - 2023-11-20 14:47:14 --> Config Class Initialized
INFO - 2023-11-20 14:47:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:14 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:14 --> URI Class Initialized
INFO - 2023-11-20 14:47:14 --> Router Class Initialized
INFO - 2023-11-20 14:47:14 --> Output Class Initialized
INFO - 2023-11-20 14:47:14 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:14 --> Input Class Initialized
INFO - 2023-11-20 14:47:14 --> Language Class Initialized
ERROR - 2023-11-20 14:47:14 --> 404 Page Not Found: /index
INFO - 2023-11-20 14:47:14 --> Config Class Initialized
INFO - 2023-11-20 14:47:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:14 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:14 --> URI Class Initialized
INFO - 2023-11-20 14:47:14 --> Router Class Initialized
INFO - 2023-11-20 14:47:14 --> Output Class Initialized
INFO - 2023-11-20 14:47:14 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:14 --> Input Class Initialized
INFO - 2023-11-20 14:47:14 --> Language Class Initialized
INFO - 2023-11-20 14:47:14 --> Language Class Initialized
INFO - 2023-11-20 14:47:14 --> Config Class Initialized
INFO - 2023-11-20 14:47:14 --> Loader Class Initialized
INFO - 2023-11-20 14:47:14 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:14 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:14 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:14 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:14 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:15 --> Controller Class Initialized
INFO - 2023-11-20 14:47:22 --> Config Class Initialized
INFO - 2023-11-20 14:47:22 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:22 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:22 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:22 --> URI Class Initialized
INFO - 2023-11-20 14:47:22 --> Router Class Initialized
INFO - 2023-11-20 14:47:22 --> Output Class Initialized
INFO - 2023-11-20 14:47:22 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:22 --> Input Class Initialized
INFO - 2023-11-20 14:47:22 --> Language Class Initialized
INFO - 2023-11-20 14:47:22 --> Language Class Initialized
INFO - 2023-11-20 14:47:22 --> Config Class Initialized
INFO - 2023-11-20 14:47:22 --> Loader Class Initialized
INFO - 2023-11-20 14:47:22 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:22 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:22 --> Controller Class Initialized
INFO - 2023-11-20 14:47:22 --> Helper loaded: cookie_helper
INFO - 2023-11-20 14:47:22 --> Config Class Initialized
INFO - 2023-11-20 14:47:22 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:22 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:22 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:22 --> URI Class Initialized
INFO - 2023-11-20 14:47:22 --> Router Class Initialized
INFO - 2023-11-20 14:47:22 --> Output Class Initialized
INFO - 2023-11-20 14:47:22 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:22 --> Input Class Initialized
INFO - 2023-11-20 14:47:22 --> Language Class Initialized
INFO - 2023-11-20 14:47:22 --> Language Class Initialized
INFO - 2023-11-20 14:47:22 --> Config Class Initialized
INFO - 2023-11-20 14:47:22 --> Loader Class Initialized
INFO - 2023-11-20 14:47:22 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:22 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:22 --> Controller Class Initialized
INFO - 2023-11-20 14:47:22 --> Config Class Initialized
INFO - 2023-11-20 14:47:22 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:22 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:22 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:22 --> URI Class Initialized
INFO - 2023-11-20 14:47:22 --> Router Class Initialized
INFO - 2023-11-20 14:47:22 --> Output Class Initialized
INFO - 2023-11-20 14:47:22 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:22 --> Input Class Initialized
INFO - 2023-11-20 14:47:22 --> Language Class Initialized
INFO - 2023-11-20 14:47:22 --> Language Class Initialized
INFO - 2023-11-20 14:47:22 --> Config Class Initialized
INFO - 2023-11-20 14:47:22 --> Loader Class Initialized
INFO - 2023-11-20 14:47:22 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:22 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:22 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:22 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 14:47:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:47:22 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:22 --> Total execution time: 0.0735
INFO - 2023-11-20 14:47:27 --> Config Class Initialized
INFO - 2023-11-20 14:47:27 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:27 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:27 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:27 --> URI Class Initialized
INFO - 2023-11-20 14:47:27 --> Router Class Initialized
INFO - 2023-11-20 14:47:27 --> Output Class Initialized
INFO - 2023-11-20 14:47:27 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:27 --> Input Class Initialized
INFO - 2023-11-20 14:47:27 --> Language Class Initialized
INFO - 2023-11-20 14:47:27 --> Language Class Initialized
INFO - 2023-11-20 14:47:27 --> Config Class Initialized
INFO - 2023-11-20 14:47:27 --> Loader Class Initialized
INFO - 2023-11-20 14:47:27 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:27 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:27 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:27 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:27 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:27 --> Controller Class Initialized
INFO - 2023-11-20 14:47:27 --> Helper loaded: cookie_helper
INFO - 2023-11-20 14:47:27 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:27 --> Total execution time: 0.1786
INFO - 2023-11-20 14:47:27 --> Config Class Initialized
INFO - 2023-11-20 14:47:27 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:27 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:27 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:27 --> URI Class Initialized
INFO - 2023-11-20 14:47:27 --> Router Class Initialized
INFO - 2023-11-20 14:47:27 --> Output Class Initialized
INFO - 2023-11-20 14:47:27 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:27 --> Input Class Initialized
INFO - 2023-11-20 14:47:27 --> Language Class Initialized
INFO - 2023-11-20 14:47:27 --> Language Class Initialized
INFO - 2023-11-20 14:47:27 --> Config Class Initialized
INFO - 2023-11-20 14:47:27 --> Loader Class Initialized
INFO - 2023-11-20 14:47:27 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:27 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:27 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:27 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:27 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:27 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-20 14:47:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:47:27 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:27 --> Total execution time: 0.0797
INFO - 2023-11-20 14:47:31 --> Config Class Initialized
INFO - 2023-11-20 14:47:31 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:31 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:31 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:31 --> URI Class Initialized
INFO - 2023-11-20 14:47:31 --> Router Class Initialized
INFO - 2023-11-20 14:47:31 --> Output Class Initialized
INFO - 2023-11-20 14:47:31 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:31 --> Input Class Initialized
INFO - 2023-11-20 14:47:31 --> Language Class Initialized
INFO - 2023-11-20 14:47:31 --> Language Class Initialized
INFO - 2023-11-20 14:47:31 --> Config Class Initialized
INFO - 2023-11-20 14:47:31 --> Loader Class Initialized
INFO - 2023-11-20 14:47:31 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:31 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:31 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:31 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:31 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:31 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-20 14:47:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:47:31 --> Final output sent to browser
DEBUG - 2023-11-20 14:47:31 --> Total execution time: 0.0521
INFO - 2023-11-20 14:47:34 --> Config Class Initialized
INFO - 2023-11-20 14:47:34 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:34 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:34 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:34 --> URI Class Initialized
INFO - 2023-11-20 14:47:34 --> Router Class Initialized
INFO - 2023-11-20 14:47:34 --> Output Class Initialized
INFO - 2023-11-20 14:47:34 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:34 --> Input Class Initialized
INFO - 2023-11-20 14:47:34 --> Language Class Initialized
INFO - 2023-11-20 14:47:34 --> Language Class Initialized
INFO - 2023-11-20 14:47:34 --> Config Class Initialized
INFO - 2023-11-20 14:47:34 --> Loader Class Initialized
INFO - 2023-11-20 14:47:34 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:34 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:34 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:34 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:34 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:34 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-11-20 14:47:34 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\logo mh primary black.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-11-20 14:47:39 --> Config Class Initialized
INFO - 2023-11-20 14:47:39 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:47:39 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:47:39 --> Utf8 Class Initialized
INFO - 2023-11-20 14:47:39 --> URI Class Initialized
INFO - 2023-11-20 14:47:39 --> Router Class Initialized
INFO - 2023-11-20 14:47:39 --> Output Class Initialized
INFO - 2023-11-20 14:47:39 --> Security Class Initialized
DEBUG - 2023-11-20 14:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:47:39 --> Input Class Initialized
INFO - 2023-11-20 14:47:39 --> Language Class Initialized
INFO - 2023-11-20 14:47:39 --> Language Class Initialized
INFO - 2023-11-20 14:47:39 --> Config Class Initialized
INFO - 2023-11-20 14:47:39 --> Loader Class Initialized
INFO - 2023-11-20 14:47:39 --> Helper loaded: url_helper
INFO - 2023-11-20 14:47:39 --> Helper loaded: file_helper
INFO - 2023-11-20 14:47:39 --> Helper loaded: form_helper
INFO - 2023-11-20 14:47:39 --> Helper loaded: my_helper
INFO - 2023-11-20 14:47:39 --> Database Driver Class Initialized
INFO - 2023-11-20 14:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:47:39 --> Controller Class Initialized
DEBUG - 2023-11-20 14:47:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2023-11-20 14:47:39 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-11-20 14:49:19 --> Config Class Initialized
INFO - 2023-11-20 14:49:19 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:49:19 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:49:19 --> Utf8 Class Initialized
INFO - 2023-11-20 14:49:19 --> URI Class Initialized
INFO - 2023-11-20 14:49:19 --> Router Class Initialized
INFO - 2023-11-20 14:49:19 --> Output Class Initialized
INFO - 2023-11-20 14:49:19 --> Security Class Initialized
DEBUG - 2023-11-20 14:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:49:19 --> Input Class Initialized
INFO - 2023-11-20 14:49:19 --> Language Class Initialized
INFO - 2023-11-20 14:49:19 --> Language Class Initialized
INFO - 2023-11-20 14:49:19 --> Config Class Initialized
INFO - 2023-11-20 14:49:19 --> Loader Class Initialized
INFO - 2023-11-20 14:49:19 --> Helper loaded: url_helper
INFO - 2023-11-20 14:49:19 --> Helper loaded: file_helper
INFO - 2023-11-20 14:49:19 --> Helper loaded: form_helper
INFO - 2023-11-20 14:49:19 --> Helper loaded: my_helper
INFO - 2023-11-20 14:49:20 --> Database Driver Class Initialized
INFO - 2023-11-20 14:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:49:20 --> Controller Class Initialized
DEBUG - 2023-11-20 14:49:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-20 14:49:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:49:20 --> Final output sent to browser
DEBUG - 2023-11-20 14:49:20 --> Total execution time: 0.0620
INFO - 2023-11-20 14:49:22 --> Config Class Initialized
INFO - 2023-11-20 14:49:22 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:49:22 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:49:22 --> Utf8 Class Initialized
INFO - 2023-11-20 14:49:22 --> URI Class Initialized
INFO - 2023-11-20 14:49:22 --> Router Class Initialized
INFO - 2023-11-20 14:49:22 --> Output Class Initialized
INFO - 2023-11-20 14:49:22 --> Security Class Initialized
DEBUG - 2023-11-20 14:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:49:22 --> Input Class Initialized
INFO - 2023-11-20 14:49:22 --> Language Class Initialized
INFO - 2023-11-20 14:49:22 --> Language Class Initialized
INFO - 2023-11-20 14:49:22 --> Config Class Initialized
INFO - 2023-11-20 14:49:22 --> Loader Class Initialized
INFO - 2023-11-20 14:49:22 --> Helper loaded: url_helper
INFO - 2023-11-20 14:49:22 --> Helper loaded: file_helper
INFO - 2023-11-20 14:49:22 --> Helper loaded: form_helper
INFO - 2023-11-20 14:49:22 --> Helper loaded: my_helper
INFO - 2023-11-20 14:49:22 --> Database Driver Class Initialized
INFO - 2023-11-20 14:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:49:22 --> Controller Class Initialized
DEBUG - 2023-11-20 14:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 14:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 14:49:27 --> Final output sent to browser
DEBUG - 2023-11-20 14:49:27 --> Total execution time: 4.8960
INFO - 2023-11-20 14:49:42 --> Config Class Initialized
INFO - 2023-11-20 14:49:42 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:49:42 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:49:42 --> Utf8 Class Initialized
INFO - 2023-11-20 14:49:42 --> URI Class Initialized
INFO - 2023-11-20 14:49:42 --> Router Class Initialized
INFO - 2023-11-20 14:49:42 --> Output Class Initialized
INFO - 2023-11-20 14:49:42 --> Security Class Initialized
DEBUG - 2023-11-20 14:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:49:42 --> Input Class Initialized
INFO - 2023-11-20 14:49:42 --> Language Class Initialized
INFO - 2023-11-20 14:49:42 --> Language Class Initialized
INFO - 2023-11-20 14:49:42 --> Config Class Initialized
INFO - 2023-11-20 14:49:42 --> Loader Class Initialized
INFO - 2023-11-20 14:49:42 --> Helper loaded: url_helper
INFO - 2023-11-20 14:49:42 --> Helper loaded: file_helper
INFO - 2023-11-20 14:49:42 --> Helper loaded: form_helper
INFO - 2023-11-20 14:49:42 --> Helper loaded: my_helper
INFO - 2023-11-20 14:49:42 --> Database Driver Class Initialized
INFO - 2023-11-20 14:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:49:42 --> Controller Class Initialized
DEBUG - 2023-11-20 14:49:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-20 14:49:48 --> Final output sent to browser
DEBUG - 2023-11-20 14:49:48 --> Total execution time: 5.8610
INFO - 2023-11-20 14:54:42 --> Config Class Initialized
INFO - 2023-11-20 14:54:42 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:54:42 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:54:42 --> Utf8 Class Initialized
INFO - 2023-11-20 14:54:42 --> URI Class Initialized
INFO - 2023-11-20 14:54:42 --> Router Class Initialized
INFO - 2023-11-20 14:54:42 --> Output Class Initialized
INFO - 2023-11-20 14:54:42 --> Security Class Initialized
DEBUG - 2023-11-20 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:54:42 --> Input Class Initialized
INFO - 2023-11-20 14:54:42 --> Language Class Initialized
INFO - 2023-11-20 14:54:42 --> Language Class Initialized
INFO - 2023-11-20 14:54:42 --> Config Class Initialized
INFO - 2023-11-20 14:54:42 --> Loader Class Initialized
INFO - 2023-11-20 14:54:42 --> Helper loaded: url_helper
INFO - 2023-11-20 14:54:42 --> Helper loaded: file_helper
INFO - 2023-11-20 14:54:42 --> Helper loaded: form_helper
INFO - 2023-11-20 14:54:42 --> Helper loaded: my_helper
INFO - 2023-11-20 14:54:43 --> Database Driver Class Initialized
INFO - 2023-11-20 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:54:43 --> Controller Class Initialized
DEBUG - 2023-11-20 14:54:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-11-20 14:54:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:54:43 --> Final output sent to browser
DEBUG - 2023-11-20 14:54:43 --> Total execution time: 0.4611
INFO - 2023-11-20 14:54:57 --> Config Class Initialized
INFO - 2023-11-20 14:54:57 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:54:57 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:54:57 --> Utf8 Class Initialized
INFO - 2023-11-20 14:54:57 --> URI Class Initialized
INFO - 2023-11-20 14:54:57 --> Router Class Initialized
INFO - 2023-11-20 14:54:57 --> Output Class Initialized
INFO - 2023-11-20 14:54:57 --> Security Class Initialized
DEBUG - 2023-11-20 14:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:54:57 --> Input Class Initialized
INFO - 2023-11-20 14:54:57 --> Language Class Initialized
INFO - 2023-11-20 14:54:57 --> Language Class Initialized
INFO - 2023-11-20 14:54:57 --> Config Class Initialized
INFO - 2023-11-20 14:54:57 --> Loader Class Initialized
INFO - 2023-11-20 14:54:57 --> Helper loaded: url_helper
INFO - 2023-11-20 14:54:57 --> Helper loaded: file_helper
INFO - 2023-11-20 14:54:57 --> Helper loaded: form_helper
INFO - 2023-11-20 14:54:57 --> Helper loaded: my_helper
INFO - 2023-11-20 14:54:57 --> Database Driver Class Initialized
INFO - 2023-11-20 14:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:54:57 --> Controller Class Initialized
DEBUG - 2023-11-20 14:54:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-20 14:54:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:54:57 --> Final output sent to browser
DEBUG - 2023-11-20 14:54:57 --> Total execution time: 0.3297
INFO - 2023-11-20 14:55:18 --> Config Class Initialized
INFO - 2023-11-20 14:55:18 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:55:18 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:55:18 --> Utf8 Class Initialized
INFO - 2023-11-20 14:55:18 --> URI Class Initialized
INFO - 2023-11-20 14:55:18 --> Router Class Initialized
INFO - 2023-11-20 14:55:18 --> Output Class Initialized
INFO - 2023-11-20 14:55:18 --> Security Class Initialized
DEBUG - 2023-11-20 14:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:55:18 --> Input Class Initialized
INFO - 2023-11-20 14:55:18 --> Language Class Initialized
INFO - 2023-11-20 14:55:18 --> Language Class Initialized
INFO - 2023-11-20 14:55:18 --> Config Class Initialized
INFO - 2023-11-20 14:55:18 --> Loader Class Initialized
INFO - 2023-11-20 14:55:18 --> Helper loaded: url_helper
INFO - 2023-11-20 14:55:18 --> Helper loaded: file_helper
INFO - 2023-11-20 14:55:18 --> Helper loaded: form_helper
INFO - 2023-11-20 14:55:18 --> Helper loaded: my_helper
INFO - 2023-11-20 14:55:18 --> Database Driver Class Initialized
INFO - 2023-11-20 14:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:55:18 --> Controller Class Initialized
INFO - 2023-11-20 14:55:18 --> Final output sent to browser
DEBUG - 2023-11-20 14:55:18 --> Total execution time: 0.0624
INFO - 2023-11-20 14:55:21 --> Config Class Initialized
INFO - 2023-11-20 14:55:21 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:55:21 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:55:21 --> Utf8 Class Initialized
INFO - 2023-11-20 14:55:21 --> URI Class Initialized
INFO - 2023-11-20 14:55:21 --> Router Class Initialized
INFO - 2023-11-20 14:55:21 --> Output Class Initialized
INFO - 2023-11-20 14:55:21 --> Security Class Initialized
DEBUG - 2023-11-20 14:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:55:21 --> Input Class Initialized
INFO - 2023-11-20 14:55:21 --> Language Class Initialized
INFO - 2023-11-20 14:55:21 --> Language Class Initialized
INFO - 2023-11-20 14:55:21 --> Config Class Initialized
INFO - 2023-11-20 14:55:21 --> Loader Class Initialized
INFO - 2023-11-20 14:55:21 --> Helper loaded: url_helper
INFO - 2023-11-20 14:55:21 --> Helper loaded: file_helper
INFO - 2023-11-20 14:55:21 --> Helper loaded: form_helper
INFO - 2023-11-20 14:55:21 --> Helper loaded: my_helper
INFO - 2023-11-20 14:55:21 --> Database Driver Class Initialized
INFO - 2023-11-20 14:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:55:21 --> Controller Class Initialized
DEBUG - 2023-11-20 14:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 14:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 14:55:25 --> Final output sent to browser
DEBUG - 2023-11-20 14:55:25 --> Total execution time: 4.1472
INFO - 2023-11-20 14:56:57 --> Config Class Initialized
INFO - 2023-11-20 14:56:57 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:56:57 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:56:57 --> Utf8 Class Initialized
INFO - 2023-11-20 14:56:57 --> URI Class Initialized
INFO - 2023-11-20 14:56:57 --> Router Class Initialized
INFO - 2023-11-20 14:56:57 --> Output Class Initialized
INFO - 2023-11-20 14:56:57 --> Security Class Initialized
DEBUG - 2023-11-20 14:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:56:57 --> Input Class Initialized
INFO - 2023-11-20 14:56:57 --> Language Class Initialized
INFO - 2023-11-20 14:56:57 --> Language Class Initialized
INFO - 2023-11-20 14:56:57 --> Config Class Initialized
INFO - 2023-11-20 14:56:57 --> Loader Class Initialized
INFO - 2023-11-20 14:56:57 --> Helper loaded: url_helper
INFO - 2023-11-20 14:56:57 --> Helper loaded: file_helper
INFO - 2023-11-20 14:56:57 --> Helper loaded: form_helper
INFO - 2023-11-20 14:56:57 --> Helper loaded: my_helper
INFO - 2023-11-20 14:56:57 --> Database Driver Class Initialized
INFO - 2023-11-20 14:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:56:57 --> Controller Class Initialized
INFO - 2023-11-20 14:56:57 --> Final output sent to browser
DEBUG - 2023-11-20 14:56:57 --> Total execution time: 0.0532
INFO - 2023-11-20 14:56:58 --> Config Class Initialized
INFO - 2023-11-20 14:56:58 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:56:58 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:56:58 --> Utf8 Class Initialized
INFO - 2023-11-20 14:56:58 --> URI Class Initialized
INFO - 2023-11-20 14:56:58 --> Router Class Initialized
INFO - 2023-11-20 14:56:58 --> Output Class Initialized
INFO - 2023-11-20 14:56:58 --> Security Class Initialized
DEBUG - 2023-11-20 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:56:58 --> Input Class Initialized
INFO - 2023-11-20 14:56:58 --> Language Class Initialized
INFO - 2023-11-20 14:56:58 --> Language Class Initialized
INFO - 2023-11-20 14:56:58 --> Config Class Initialized
INFO - 2023-11-20 14:56:58 --> Loader Class Initialized
INFO - 2023-11-20 14:56:58 --> Helper loaded: url_helper
INFO - 2023-11-20 14:56:58 --> Helper loaded: file_helper
INFO - 2023-11-20 14:56:58 --> Helper loaded: form_helper
INFO - 2023-11-20 14:56:58 --> Helper loaded: my_helper
INFO - 2023-11-20 14:56:58 --> Database Driver Class Initialized
INFO - 2023-11-20 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:56:58 --> Controller Class Initialized
DEBUG - 2023-11-20 14:56:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-20 14:56:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 14:56:58 --> Final output sent to browser
DEBUG - 2023-11-20 14:56:58 --> Total execution time: 0.0550
INFO - 2023-11-20 14:57:02 --> Config Class Initialized
INFO - 2023-11-20 14:57:02 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:57:02 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:57:02 --> Utf8 Class Initialized
INFO - 2023-11-20 14:57:02 --> URI Class Initialized
INFO - 2023-11-20 14:57:02 --> Router Class Initialized
INFO - 2023-11-20 14:57:02 --> Output Class Initialized
INFO - 2023-11-20 14:57:02 --> Security Class Initialized
DEBUG - 2023-11-20 14:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:57:02 --> Input Class Initialized
INFO - 2023-11-20 14:57:02 --> Language Class Initialized
INFO - 2023-11-20 14:57:02 --> Language Class Initialized
INFO - 2023-11-20 14:57:02 --> Config Class Initialized
INFO - 2023-11-20 14:57:02 --> Loader Class Initialized
INFO - 2023-11-20 14:57:02 --> Helper loaded: url_helper
INFO - 2023-11-20 14:57:02 --> Helper loaded: file_helper
INFO - 2023-11-20 14:57:02 --> Helper loaded: form_helper
INFO - 2023-11-20 14:57:02 --> Helper loaded: my_helper
INFO - 2023-11-20 14:57:02 --> Database Driver Class Initialized
INFO - 2023-11-20 14:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:57:02 --> Controller Class Initialized
DEBUG - 2023-11-20 14:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 14:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 14:57:06 --> Final output sent to browser
DEBUG - 2023-11-20 14:57:06 --> Total execution time: 4.1553
INFO - 2023-11-20 14:58:20 --> Config Class Initialized
INFO - 2023-11-20 14:58:20 --> Hooks Class Initialized
DEBUG - 2023-11-20 14:58:20 --> UTF-8 Support Enabled
INFO - 2023-11-20 14:58:20 --> Utf8 Class Initialized
INFO - 2023-11-20 14:58:20 --> URI Class Initialized
INFO - 2023-11-20 14:58:20 --> Router Class Initialized
INFO - 2023-11-20 14:58:20 --> Output Class Initialized
INFO - 2023-11-20 14:58:20 --> Security Class Initialized
DEBUG - 2023-11-20 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 14:58:20 --> Input Class Initialized
INFO - 2023-11-20 14:58:20 --> Language Class Initialized
INFO - 2023-11-20 14:58:20 --> Language Class Initialized
INFO - 2023-11-20 14:58:20 --> Config Class Initialized
INFO - 2023-11-20 14:58:20 --> Loader Class Initialized
INFO - 2023-11-20 14:58:20 --> Helper loaded: url_helper
INFO - 2023-11-20 14:58:20 --> Helper loaded: file_helper
INFO - 2023-11-20 14:58:20 --> Helper loaded: form_helper
INFO - 2023-11-20 14:58:20 --> Helper loaded: my_helper
INFO - 2023-11-20 14:58:20 --> Database Driver Class Initialized
INFO - 2023-11-20 14:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 14:58:20 --> Controller Class Initialized
INFO - 2023-11-20 14:58:20 --> Final output sent to browser
DEBUG - 2023-11-20 14:58:20 --> Total execution time: 0.1806
INFO - 2023-11-20 15:00:23 --> Config Class Initialized
INFO - 2023-11-20 15:00:23 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:00:23 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:00:23 --> Utf8 Class Initialized
INFO - 2023-11-20 15:00:23 --> URI Class Initialized
INFO - 2023-11-20 15:00:23 --> Router Class Initialized
INFO - 2023-11-20 15:00:23 --> Output Class Initialized
INFO - 2023-11-20 15:00:23 --> Security Class Initialized
DEBUG - 2023-11-20 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:00:23 --> Input Class Initialized
INFO - 2023-11-20 15:00:23 --> Language Class Initialized
INFO - 2023-11-20 15:00:23 --> Language Class Initialized
INFO - 2023-11-20 15:00:23 --> Config Class Initialized
INFO - 2023-11-20 15:00:23 --> Loader Class Initialized
INFO - 2023-11-20 15:00:23 --> Helper loaded: url_helper
INFO - 2023-11-20 15:00:23 --> Helper loaded: file_helper
INFO - 2023-11-20 15:00:23 --> Helper loaded: form_helper
INFO - 2023-11-20 15:00:23 --> Helper loaded: my_helper
INFO - 2023-11-20 15:00:23 --> Database Driver Class Initialized
INFO - 2023-11-20 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:00:23 --> Controller Class Initialized
DEBUG - 2023-11-20 15:00:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 15:00:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 15:00:28 --> Final output sent to browser
DEBUG - 2023-11-20 15:00:28 --> Total execution time: 4.9791
INFO - 2023-11-20 15:00:41 --> Config Class Initialized
INFO - 2023-11-20 15:00:41 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:00:41 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:00:41 --> Utf8 Class Initialized
INFO - 2023-11-20 15:00:41 --> URI Class Initialized
INFO - 2023-11-20 15:00:41 --> Router Class Initialized
INFO - 2023-11-20 15:00:41 --> Output Class Initialized
INFO - 2023-11-20 15:00:41 --> Security Class Initialized
DEBUG - 2023-11-20 15:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:00:41 --> Input Class Initialized
INFO - 2023-11-20 15:00:41 --> Language Class Initialized
INFO - 2023-11-20 15:00:41 --> Language Class Initialized
INFO - 2023-11-20 15:00:41 --> Config Class Initialized
INFO - 2023-11-20 15:00:41 --> Loader Class Initialized
INFO - 2023-11-20 15:00:41 --> Helper loaded: url_helper
INFO - 2023-11-20 15:00:41 --> Helper loaded: file_helper
INFO - 2023-11-20 15:00:41 --> Helper loaded: form_helper
INFO - 2023-11-20 15:00:41 --> Helper loaded: my_helper
INFO - 2023-11-20 15:00:41 --> Database Driver Class Initialized
INFO - 2023-11-20 15:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:00:41 --> Controller Class Initialized
DEBUG - 2023-11-20 15:00:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 15:00:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 15:00:45 --> Final output sent to browser
DEBUG - 2023-11-20 15:00:45 --> Total execution time: 4.2525
INFO - 2023-11-20 15:00:57 --> Config Class Initialized
INFO - 2023-11-20 15:00:57 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:00:57 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:00:57 --> Utf8 Class Initialized
INFO - 2023-11-20 15:00:57 --> URI Class Initialized
INFO - 2023-11-20 15:00:57 --> Router Class Initialized
INFO - 2023-11-20 15:00:57 --> Output Class Initialized
INFO - 2023-11-20 15:00:57 --> Security Class Initialized
DEBUG - 2023-11-20 15:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:00:57 --> Input Class Initialized
INFO - 2023-11-20 15:00:57 --> Language Class Initialized
INFO - 2023-11-20 15:00:57 --> Language Class Initialized
INFO - 2023-11-20 15:00:57 --> Config Class Initialized
INFO - 2023-11-20 15:00:57 --> Loader Class Initialized
INFO - 2023-11-20 15:00:57 --> Helper loaded: url_helper
INFO - 2023-11-20 15:00:57 --> Helper loaded: file_helper
INFO - 2023-11-20 15:00:57 --> Helper loaded: form_helper
INFO - 2023-11-20 15:00:57 --> Helper loaded: my_helper
INFO - 2023-11-20 15:00:57 --> Database Driver Class Initialized
INFO - 2023-11-20 15:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:00:57 --> Controller Class Initialized
DEBUG - 2023-11-20 15:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 15:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 15:01:04 --> Final output sent to browser
DEBUG - 2023-11-20 15:01:04 --> Total execution time: 7.2955
INFO - 2023-11-20 15:01:28 --> Config Class Initialized
INFO - 2023-11-20 15:01:28 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:01:28 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:01:28 --> Utf8 Class Initialized
INFO - 2023-11-20 15:01:28 --> URI Class Initialized
INFO - 2023-11-20 15:01:28 --> Router Class Initialized
INFO - 2023-11-20 15:01:28 --> Output Class Initialized
INFO - 2023-11-20 15:01:28 --> Security Class Initialized
DEBUG - 2023-11-20 15:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:01:28 --> Input Class Initialized
INFO - 2023-11-20 15:01:28 --> Language Class Initialized
INFO - 2023-11-20 15:01:28 --> Language Class Initialized
INFO - 2023-11-20 15:01:28 --> Config Class Initialized
INFO - 2023-11-20 15:01:28 --> Loader Class Initialized
INFO - 2023-11-20 15:01:28 --> Helper loaded: url_helper
INFO - 2023-11-20 15:01:28 --> Helper loaded: file_helper
INFO - 2023-11-20 15:01:28 --> Helper loaded: form_helper
INFO - 2023-11-20 15:01:28 --> Helper loaded: my_helper
INFO - 2023-11-20 15:01:28 --> Database Driver Class Initialized
INFO - 2023-11-20 15:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:01:28 --> Controller Class Initialized
DEBUG - 2023-11-20 15:01:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-11-20 15:01:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:01:28 --> Final output sent to browser
DEBUG - 2023-11-20 15:01:28 --> Total execution time: 0.0545
INFO - 2023-11-20 15:01:31 --> Config Class Initialized
INFO - 2023-11-20 15:01:31 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:01:31 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:01:31 --> Utf8 Class Initialized
INFO - 2023-11-20 15:01:31 --> URI Class Initialized
INFO - 2023-11-20 15:01:31 --> Router Class Initialized
INFO - 2023-11-20 15:01:31 --> Output Class Initialized
INFO - 2023-11-20 15:01:31 --> Security Class Initialized
DEBUG - 2023-11-20 15:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:01:31 --> Input Class Initialized
INFO - 2023-11-20 15:01:31 --> Language Class Initialized
INFO - 2023-11-20 15:01:31 --> Language Class Initialized
INFO - 2023-11-20 15:01:31 --> Config Class Initialized
INFO - 2023-11-20 15:01:31 --> Loader Class Initialized
INFO - 2023-11-20 15:01:31 --> Helper loaded: url_helper
INFO - 2023-11-20 15:01:31 --> Helper loaded: file_helper
INFO - 2023-11-20 15:01:31 --> Helper loaded: form_helper
INFO - 2023-11-20 15:01:31 --> Helper loaded: my_helper
INFO - 2023-11-20 15:01:31 --> Database Driver Class Initialized
INFO - 2023-11-20 15:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:01:31 --> Controller Class Initialized
INFO - 2023-11-20 15:01:31 --> Final output sent to browser
DEBUG - 2023-11-20 15:01:31 --> Total execution time: 0.0642
INFO - 2023-11-20 15:01:32 --> Config Class Initialized
INFO - 2023-11-20 15:01:32 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:01:32 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:01:32 --> Utf8 Class Initialized
INFO - 2023-11-20 15:01:32 --> URI Class Initialized
INFO - 2023-11-20 15:01:32 --> Router Class Initialized
INFO - 2023-11-20 15:01:32 --> Output Class Initialized
INFO - 2023-11-20 15:01:32 --> Security Class Initialized
DEBUG - 2023-11-20 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:01:32 --> Input Class Initialized
INFO - 2023-11-20 15:01:32 --> Language Class Initialized
INFO - 2023-11-20 15:01:32 --> Language Class Initialized
INFO - 2023-11-20 15:01:32 --> Config Class Initialized
INFO - 2023-11-20 15:01:32 --> Loader Class Initialized
INFO - 2023-11-20 15:01:32 --> Helper loaded: url_helper
INFO - 2023-11-20 15:01:32 --> Helper loaded: file_helper
INFO - 2023-11-20 15:01:32 --> Helper loaded: form_helper
INFO - 2023-11-20 15:01:32 --> Helper loaded: my_helper
INFO - 2023-11-20 15:01:32 --> Database Driver Class Initialized
INFO - 2023-11-20 15:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:01:32 --> Controller Class Initialized
DEBUG - 2023-11-20 15:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-11-20 15:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:01:32 --> Final output sent to browser
DEBUG - 2023-11-20 15:01:32 --> Total execution time: 0.0491
INFO - 2023-11-20 15:01:40 --> Config Class Initialized
INFO - 2023-11-20 15:01:40 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:01:40 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:01:40 --> Utf8 Class Initialized
INFO - 2023-11-20 15:01:40 --> URI Class Initialized
INFO - 2023-11-20 15:01:40 --> Router Class Initialized
INFO - 2023-11-20 15:01:40 --> Output Class Initialized
INFO - 2023-11-20 15:01:40 --> Security Class Initialized
DEBUG - 2023-11-20 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:01:40 --> Input Class Initialized
INFO - 2023-11-20 15:01:40 --> Language Class Initialized
INFO - 2023-11-20 15:01:40 --> Language Class Initialized
INFO - 2023-11-20 15:01:40 --> Config Class Initialized
INFO - 2023-11-20 15:01:40 --> Loader Class Initialized
INFO - 2023-11-20 15:01:40 --> Helper loaded: url_helper
INFO - 2023-11-20 15:01:40 --> Helper loaded: file_helper
INFO - 2023-11-20 15:01:40 --> Helper loaded: form_helper
INFO - 2023-11-20 15:01:40 --> Helper loaded: my_helper
INFO - 2023-11-20 15:01:40 --> Database Driver Class Initialized
INFO - 2023-11-20 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:01:40 --> Controller Class Initialized
DEBUG - 2023-11-20 15:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 15:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 15:01:44 --> Final output sent to browser
DEBUG - 2023-11-20 15:01:44 --> Total execution time: 4.2938
INFO - 2023-11-20 15:03:57 --> Config Class Initialized
INFO - 2023-11-20 15:03:57 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:03:57 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:03:57 --> Utf8 Class Initialized
INFO - 2023-11-20 15:03:57 --> URI Class Initialized
INFO - 2023-11-20 15:03:57 --> Router Class Initialized
INFO - 2023-11-20 15:03:57 --> Output Class Initialized
INFO - 2023-11-20 15:03:57 --> Security Class Initialized
DEBUG - 2023-11-20 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:03:57 --> Input Class Initialized
INFO - 2023-11-20 15:03:57 --> Language Class Initialized
INFO - 2023-11-20 15:03:57 --> Language Class Initialized
INFO - 2023-11-20 15:03:57 --> Config Class Initialized
INFO - 2023-11-20 15:03:57 --> Loader Class Initialized
INFO - 2023-11-20 15:03:57 --> Helper loaded: url_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: file_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: form_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: my_helper
INFO - 2023-11-20 15:03:57 --> Database Driver Class Initialized
INFO - 2023-11-20 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:03:57 --> Controller Class Initialized
INFO - 2023-11-20 15:03:57 --> Helper loaded: cookie_helper
INFO - 2023-11-20 15:03:57 --> Config Class Initialized
INFO - 2023-11-20 15:03:57 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:03:57 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:03:57 --> Utf8 Class Initialized
INFO - 2023-11-20 15:03:57 --> URI Class Initialized
INFO - 2023-11-20 15:03:57 --> Router Class Initialized
INFO - 2023-11-20 15:03:57 --> Output Class Initialized
INFO - 2023-11-20 15:03:57 --> Security Class Initialized
DEBUG - 2023-11-20 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:03:57 --> Input Class Initialized
INFO - 2023-11-20 15:03:57 --> Language Class Initialized
INFO - 2023-11-20 15:03:57 --> Language Class Initialized
INFO - 2023-11-20 15:03:57 --> Config Class Initialized
INFO - 2023-11-20 15:03:57 --> Loader Class Initialized
INFO - 2023-11-20 15:03:57 --> Helper loaded: url_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: file_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: form_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: my_helper
INFO - 2023-11-20 15:03:57 --> Database Driver Class Initialized
INFO - 2023-11-20 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:03:57 --> Controller Class Initialized
INFO - 2023-11-20 15:03:57 --> Config Class Initialized
INFO - 2023-11-20 15:03:57 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:03:57 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:03:57 --> Utf8 Class Initialized
INFO - 2023-11-20 15:03:57 --> URI Class Initialized
INFO - 2023-11-20 15:03:57 --> Router Class Initialized
INFO - 2023-11-20 15:03:57 --> Output Class Initialized
INFO - 2023-11-20 15:03:57 --> Security Class Initialized
DEBUG - 2023-11-20 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:03:57 --> Input Class Initialized
INFO - 2023-11-20 15:03:57 --> Language Class Initialized
INFO - 2023-11-20 15:03:57 --> Language Class Initialized
INFO - 2023-11-20 15:03:57 --> Config Class Initialized
INFO - 2023-11-20 15:03:57 --> Loader Class Initialized
INFO - 2023-11-20 15:03:57 --> Helper loaded: url_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: file_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: form_helper
INFO - 2023-11-20 15:03:57 --> Helper loaded: my_helper
INFO - 2023-11-20 15:03:57 --> Database Driver Class Initialized
INFO - 2023-11-20 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:03:57 --> Controller Class Initialized
DEBUG - 2023-11-20 15:03:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 15:03:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:03:57 --> Final output sent to browser
DEBUG - 2023-11-20 15:03:57 --> Total execution time: 0.0713
INFO - 2023-11-20 15:04:06 --> Config Class Initialized
INFO - 2023-11-20 15:04:06 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:04:06 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:04:06 --> Utf8 Class Initialized
INFO - 2023-11-20 15:04:06 --> URI Class Initialized
INFO - 2023-11-20 15:04:06 --> Router Class Initialized
INFO - 2023-11-20 15:04:06 --> Output Class Initialized
INFO - 2023-11-20 15:04:06 --> Security Class Initialized
DEBUG - 2023-11-20 15:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:04:06 --> Input Class Initialized
INFO - 2023-11-20 15:04:06 --> Language Class Initialized
INFO - 2023-11-20 15:04:06 --> Language Class Initialized
INFO - 2023-11-20 15:04:06 --> Config Class Initialized
INFO - 2023-11-20 15:04:06 --> Loader Class Initialized
INFO - 2023-11-20 15:04:06 --> Helper loaded: url_helper
INFO - 2023-11-20 15:04:06 --> Helper loaded: file_helper
INFO - 2023-11-20 15:04:06 --> Helper loaded: form_helper
INFO - 2023-11-20 15:04:06 --> Helper loaded: my_helper
INFO - 2023-11-20 15:04:06 --> Database Driver Class Initialized
INFO - 2023-11-20 15:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:04:06 --> Controller Class Initialized
INFO - 2023-11-20 15:04:06 --> Helper loaded: cookie_helper
INFO - 2023-11-20 15:04:06 --> Final output sent to browser
DEBUG - 2023-11-20 15:04:06 --> Total execution time: 0.0360
INFO - 2023-11-20 15:04:06 --> Config Class Initialized
INFO - 2023-11-20 15:04:06 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:04:06 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:04:06 --> Utf8 Class Initialized
INFO - 2023-11-20 15:04:06 --> URI Class Initialized
INFO - 2023-11-20 15:04:06 --> Router Class Initialized
INFO - 2023-11-20 15:04:06 --> Output Class Initialized
INFO - 2023-11-20 15:04:06 --> Security Class Initialized
DEBUG - 2023-11-20 15:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:04:06 --> Input Class Initialized
INFO - 2023-11-20 15:04:06 --> Language Class Initialized
INFO - 2023-11-20 15:04:06 --> Language Class Initialized
INFO - 2023-11-20 15:04:06 --> Config Class Initialized
INFO - 2023-11-20 15:04:06 --> Loader Class Initialized
INFO - 2023-11-20 15:04:06 --> Helper loaded: url_helper
INFO - 2023-11-20 15:04:06 --> Helper loaded: file_helper
INFO - 2023-11-20 15:04:06 --> Helper loaded: form_helper
INFO - 2023-11-20 15:04:06 --> Helper loaded: my_helper
INFO - 2023-11-20 15:04:06 --> Database Driver Class Initialized
INFO - 2023-11-20 15:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:04:06 --> Controller Class Initialized
DEBUG - 2023-11-20 15:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-20 15:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:04:06 --> Final output sent to browser
DEBUG - 2023-11-20 15:04:06 --> Total execution time: 0.0372
INFO - 2023-11-20 15:04:10 --> Config Class Initialized
INFO - 2023-11-20 15:04:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:04:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:04:10 --> Utf8 Class Initialized
INFO - 2023-11-20 15:04:10 --> URI Class Initialized
INFO - 2023-11-20 15:04:10 --> Router Class Initialized
INFO - 2023-11-20 15:04:10 --> Output Class Initialized
INFO - 2023-11-20 15:04:10 --> Security Class Initialized
DEBUG - 2023-11-20 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:04:10 --> Input Class Initialized
INFO - 2023-11-20 15:04:10 --> Language Class Initialized
INFO - 2023-11-20 15:04:10 --> Language Class Initialized
INFO - 2023-11-20 15:04:10 --> Config Class Initialized
INFO - 2023-11-20 15:04:10 --> Loader Class Initialized
INFO - 2023-11-20 15:04:10 --> Helper loaded: url_helper
INFO - 2023-11-20 15:04:10 --> Helper loaded: file_helper
INFO - 2023-11-20 15:04:10 --> Helper loaded: form_helper
INFO - 2023-11-20 15:04:10 --> Helper loaded: my_helper
INFO - 2023-11-20 15:04:10 --> Database Driver Class Initialized
INFO - 2023-11-20 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:04:10 --> Controller Class Initialized
DEBUG - 2023-11-20 15:04:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-11-20 15:04:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:04:10 --> Final output sent to browser
DEBUG - 2023-11-20 15:04:10 --> Total execution time: 0.1020
INFO - 2023-11-20 15:04:10 --> Config Class Initialized
INFO - 2023-11-20 15:04:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:04:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:04:10 --> Utf8 Class Initialized
INFO - 2023-11-20 15:04:10 --> URI Class Initialized
INFO - 2023-11-20 15:04:10 --> Router Class Initialized
INFO - 2023-11-20 15:04:10 --> Output Class Initialized
INFO - 2023-11-20 15:04:10 --> Security Class Initialized
DEBUG - 2023-11-20 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:04:10 --> Input Class Initialized
INFO - 2023-11-20 15:04:10 --> Language Class Initialized
ERROR - 2023-11-20 15:04:10 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:04:10 --> Config Class Initialized
INFO - 2023-11-20 15:04:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:04:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:04:10 --> Utf8 Class Initialized
INFO - 2023-11-20 15:04:10 --> URI Class Initialized
INFO - 2023-11-20 15:04:10 --> Router Class Initialized
INFO - 2023-11-20 15:04:10 --> Output Class Initialized
INFO - 2023-11-20 15:04:10 --> Security Class Initialized
DEBUG - 2023-11-20 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:04:10 --> Input Class Initialized
INFO - 2023-11-20 15:04:10 --> Language Class Initialized
INFO - 2023-11-20 15:04:10 --> Language Class Initialized
INFO - 2023-11-20 15:04:10 --> Config Class Initialized
INFO - 2023-11-20 15:04:10 --> Loader Class Initialized
INFO - 2023-11-20 15:04:10 --> Helper loaded: url_helper
INFO - 2023-11-20 15:04:10 --> Helper loaded: file_helper
INFO - 2023-11-20 15:04:10 --> Helper loaded: form_helper
INFO - 2023-11-20 15:04:10 --> Helper loaded: my_helper
INFO - 2023-11-20 15:04:10 --> Database Driver Class Initialized
INFO - 2023-11-20 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:04:10 --> Controller Class Initialized
INFO - 2023-11-20 15:05:03 --> Config Class Initialized
INFO - 2023-11-20 15:05:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:03 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:03 --> URI Class Initialized
INFO - 2023-11-20 15:05:03 --> Router Class Initialized
INFO - 2023-11-20 15:05:03 --> Output Class Initialized
INFO - 2023-11-20 15:05:03 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:03 --> Input Class Initialized
INFO - 2023-11-20 15:05:03 --> Language Class Initialized
INFO - 2023-11-20 15:05:03 --> Language Class Initialized
INFO - 2023-11-20 15:05:03 --> Config Class Initialized
INFO - 2023-11-20 15:05:03 --> Loader Class Initialized
INFO - 2023-11-20 15:05:03 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:03 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:03 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:03 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:03 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:03 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-11-20 15:05:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:05:03 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:03 --> Total execution time: 0.0796
INFO - 2023-11-20 15:05:03 --> Config Class Initialized
INFO - 2023-11-20 15:05:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:03 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:03 --> URI Class Initialized
INFO - 2023-11-20 15:05:03 --> Router Class Initialized
INFO - 2023-11-20 15:05:03 --> Output Class Initialized
INFO - 2023-11-20 15:05:03 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:03 --> Input Class Initialized
INFO - 2023-11-20 15:05:03 --> Language Class Initialized
ERROR - 2023-11-20 15:05:03 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:05:03 --> Config Class Initialized
INFO - 2023-11-20 15:05:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:03 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:03 --> URI Class Initialized
INFO - 2023-11-20 15:05:03 --> Router Class Initialized
INFO - 2023-11-20 15:05:03 --> Output Class Initialized
INFO - 2023-11-20 15:05:03 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:03 --> Input Class Initialized
INFO - 2023-11-20 15:05:03 --> Language Class Initialized
INFO - 2023-11-20 15:05:03 --> Language Class Initialized
INFO - 2023-11-20 15:05:03 --> Config Class Initialized
INFO - 2023-11-20 15:05:03 --> Loader Class Initialized
INFO - 2023-11-20 15:05:03 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:03 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:03 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:03 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:03 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:03 --> Controller Class Initialized
INFO - 2023-11-20 15:05:05 --> Config Class Initialized
INFO - 2023-11-20 15:05:05 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:05 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:05 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:05 --> URI Class Initialized
INFO - 2023-11-20 15:05:05 --> Router Class Initialized
INFO - 2023-11-20 15:05:05 --> Output Class Initialized
INFO - 2023-11-20 15:05:05 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:05 --> Input Class Initialized
INFO - 2023-11-20 15:05:05 --> Language Class Initialized
INFO - 2023-11-20 15:05:05 --> Language Class Initialized
INFO - 2023-11-20 15:05:05 --> Config Class Initialized
INFO - 2023-11-20 15:05:05 --> Loader Class Initialized
INFO - 2023-11-20 15:05:05 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:05 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:05 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:05 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:05 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:05 --> Controller Class Initialized
INFO - 2023-11-20 15:05:05 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:05 --> Total execution time: 0.0513
INFO - 2023-11-20 15:05:10 --> Config Class Initialized
INFO - 2023-11-20 15:05:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:10 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:10 --> URI Class Initialized
INFO - 2023-11-20 15:05:10 --> Router Class Initialized
INFO - 2023-11-20 15:05:10 --> Output Class Initialized
INFO - 2023-11-20 15:05:10 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:10 --> Input Class Initialized
INFO - 2023-11-20 15:05:10 --> Language Class Initialized
INFO - 2023-11-20 15:05:10 --> Language Class Initialized
INFO - 2023-11-20 15:05:10 --> Config Class Initialized
INFO - 2023-11-20 15:05:10 --> Loader Class Initialized
INFO - 2023-11-20 15:05:10 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:10 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:10 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:10 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:10 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:10 --> Controller Class Initialized
INFO - 2023-11-20 15:05:10 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:10 --> Total execution time: 0.0513
INFO - 2023-11-20 15:05:10 --> Config Class Initialized
INFO - 2023-11-20 15:05:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:10 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:10 --> URI Class Initialized
INFO - 2023-11-20 15:05:10 --> Router Class Initialized
INFO - 2023-11-20 15:05:10 --> Output Class Initialized
INFO - 2023-11-20 15:05:10 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:10 --> Input Class Initialized
INFO - 2023-11-20 15:05:10 --> Language Class Initialized
ERROR - 2023-11-20 15:05:10 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:05:11 --> Config Class Initialized
INFO - 2023-11-20 15:05:11 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:11 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:11 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:11 --> URI Class Initialized
INFO - 2023-11-20 15:05:11 --> Router Class Initialized
INFO - 2023-11-20 15:05:11 --> Output Class Initialized
INFO - 2023-11-20 15:05:11 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:11 --> Input Class Initialized
INFO - 2023-11-20 15:05:11 --> Language Class Initialized
INFO - 2023-11-20 15:05:11 --> Language Class Initialized
INFO - 2023-11-20 15:05:11 --> Config Class Initialized
INFO - 2023-11-20 15:05:11 --> Loader Class Initialized
INFO - 2023-11-20 15:05:11 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:11 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:11 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:11 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:11 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:11 --> Controller Class Initialized
INFO - 2023-11-20 15:05:13 --> Config Class Initialized
INFO - 2023-11-20 15:05:13 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:13 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:13 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:13 --> URI Class Initialized
INFO - 2023-11-20 15:05:13 --> Router Class Initialized
INFO - 2023-11-20 15:05:13 --> Output Class Initialized
INFO - 2023-11-20 15:05:13 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:13 --> Input Class Initialized
INFO - 2023-11-20 15:05:13 --> Language Class Initialized
INFO - 2023-11-20 15:05:13 --> Language Class Initialized
INFO - 2023-11-20 15:05:13 --> Config Class Initialized
INFO - 2023-11-20 15:05:13 --> Loader Class Initialized
INFO - 2023-11-20 15:05:13 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:13 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:13 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:13 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:13 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:13 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-20 15:05:14 --> Config Class Initialized
INFO - 2023-11-20 15:05:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:14 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:14 --> URI Class Initialized
INFO - 2023-11-20 15:05:14 --> Router Class Initialized
INFO - 2023-11-20 15:05:14 --> Output Class Initialized
INFO - 2023-11-20 15:05:14 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:14 --> Input Class Initialized
INFO - 2023-11-20 15:05:14 --> Language Class Initialized
INFO - 2023-11-20 15:05:14 --> Language Class Initialized
INFO - 2023-11-20 15:05:14 --> Config Class Initialized
INFO - 2023-11-20 15:05:14 --> Loader Class Initialized
INFO - 2023-11-20 15:05:14 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:14 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:14 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:14 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:14 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:19 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:19 --> Total execution time: 6.5221
INFO - 2023-11-20 15:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:20 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 15:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 15:05:24 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:24 --> Total execution time: 9.8511
INFO - 2023-11-20 15:05:31 --> Config Class Initialized
INFO - 2023-11-20 15:05:31 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:31 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:31 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:31 --> URI Class Initialized
INFO - 2023-11-20 15:05:31 --> Router Class Initialized
INFO - 2023-11-20 15:05:31 --> Output Class Initialized
INFO - 2023-11-20 15:05:31 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:31 --> Input Class Initialized
INFO - 2023-11-20 15:05:31 --> Language Class Initialized
INFO - 2023-11-20 15:05:31 --> Language Class Initialized
INFO - 2023-11-20 15:05:31 --> Config Class Initialized
INFO - 2023-11-20 15:05:31 --> Loader Class Initialized
INFO - 2023-11-20 15:05:31 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:31 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:31 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:31 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:32 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:32 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-11-20 15:05:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:05:32 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:32 --> Total execution time: 0.0777
INFO - 2023-11-20 15:05:32 --> Config Class Initialized
INFO - 2023-11-20 15:05:32 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:32 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:32 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:32 --> URI Class Initialized
INFO - 2023-11-20 15:05:32 --> Router Class Initialized
INFO - 2023-11-20 15:05:32 --> Output Class Initialized
INFO - 2023-11-20 15:05:32 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:32 --> Input Class Initialized
INFO - 2023-11-20 15:05:32 --> Language Class Initialized
ERROR - 2023-11-20 15:05:32 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:05:32 --> Config Class Initialized
INFO - 2023-11-20 15:05:32 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:32 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:32 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:32 --> URI Class Initialized
INFO - 2023-11-20 15:05:32 --> Router Class Initialized
INFO - 2023-11-20 15:05:32 --> Output Class Initialized
INFO - 2023-11-20 15:05:32 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:32 --> Input Class Initialized
INFO - 2023-11-20 15:05:32 --> Language Class Initialized
INFO - 2023-11-20 15:05:32 --> Language Class Initialized
INFO - 2023-11-20 15:05:32 --> Config Class Initialized
INFO - 2023-11-20 15:05:32 --> Loader Class Initialized
INFO - 2023-11-20 15:05:32 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:32 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:32 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:32 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:32 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:32 --> Controller Class Initialized
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:33 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:33 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:33 --> URI Class Initialized
INFO - 2023-11-20 15:05:33 --> Router Class Initialized
INFO - 2023-11-20 15:05:33 --> Output Class Initialized
INFO - 2023-11-20 15:05:33 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:33 --> Input Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Loader Class Initialized
INFO - 2023-11-20 15:05:33 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:33 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:33 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-11-20 15:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:05:33 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:33 --> Total execution time: 0.0574
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:33 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:33 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:33 --> URI Class Initialized
INFO - 2023-11-20 15:05:33 --> Router Class Initialized
INFO - 2023-11-20 15:05:33 --> Output Class Initialized
INFO - 2023-11-20 15:05:33 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:33 --> Input Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
ERROR - 2023-11-20 15:05:33 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:33 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:33 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:33 --> URI Class Initialized
INFO - 2023-11-20 15:05:33 --> Router Class Initialized
INFO - 2023-11-20 15:05:33 --> Output Class Initialized
INFO - 2023-11-20 15:05:33 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:33 --> Input Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Loader Class Initialized
INFO - 2023-11-20 15:05:33 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:33 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:33 --> Controller Class Initialized
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:33 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:33 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:33 --> URI Class Initialized
INFO - 2023-11-20 15:05:33 --> Router Class Initialized
INFO - 2023-11-20 15:05:33 --> Output Class Initialized
INFO - 2023-11-20 15:05:33 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:33 --> Input Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
INFO - 2023-11-20 15:05:33 --> Language Class Initialized
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Loader Class Initialized
INFO - 2023-11-20 15:05:33 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:33 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:33 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:33 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-11-20 15:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:05:33 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:33 --> Total execution time: 0.0391
INFO - 2023-11-20 15:05:33 --> Config Class Initialized
INFO - 2023-11-20 15:05:33 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:33 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:33 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:33 --> URI Class Initialized
INFO - 2023-11-20 15:05:33 --> Router Class Initialized
INFO - 2023-11-20 15:05:33 --> Output Class Initialized
INFO - 2023-11-20 15:05:33 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:34 --> Input Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
ERROR - 2023-11-20 15:05:34 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:34 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:34 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:34 --> URI Class Initialized
INFO - 2023-11-20 15:05:34 --> Router Class Initialized
INFO - 2023-11-20 15:05:34 --> Output Class Initialized
INFO - 2023-11-20 15:05:34 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:34 --> Input Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Loader Class Initialized
INFO - 2023-11-20 15:05:34 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:34 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:34 --> Controller Class Initialized
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:34 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:34 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:34 --> URI Class Initialized
INFO - 2023-11-20 15:05:34 --> Router Class Initialized
INFO - 2023-11-20 15:05:34 --> Output Class Initialized
INFO - 2023-11-20 15:05:34 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:34 --> Input Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Loader Class Initialized
INFO - 2023-11-20 15:05:34 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:34 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:34 --> Controller Class Initialized
DEBUG - 2023-11-20 15:05:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-20 15:05:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:05:34 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:34 --> Total execution time: 0.0406
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:34 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:34 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:34 --> URI Class Initialized
INFO - 2023-11-20 15:05:34 --> Router Class Initialized
INFO - 2023-11-20 15:05:34 --> Output Class Initialized
INFO - 2023-11-20 15:05:34 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:34 --> Input Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
ERROR - 2023-11-20 15:05:34 --> 404 Page Not Found: /index
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:34 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:34 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:34 --> URI Class Initialized
INFO - 2023-11-20 15:05:34 --> Router Class Initialized
INFO - 2023-11-20 15:05:34 --> Output Class Initialized
INFO - 2023-11-20 15:05:34 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:34 --> Input Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
INFO - 2023-11-20 15:05:34 --> Language Class Initialized
INFO - 2023-11-20 15:05:34 --> Config Class Initialized
INFO - 2023-11-20 15:05:34 --> Loader Class Initialized
INFO - 2023-11-20 15:05:34 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:34 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:34 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:34 --> Controller Class Initialized
INFO - 2023-11-20 15:05:39 --> Config Class Initialized
INFO - 2023-11-20 15:05:39 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:05:39 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:05:39 --> Utf8 Class Initialized
INFO - 2023-11-20 15:05:39 --> URI Class Initialized
INFO - 2023-11-20 15:05:39 --> Router Class Initialized
INFO - 2023-11-20 15:05:39 --> Output Class Initialized
INFO - 2023-11-20 15:05:39 --> Security Class Initialized
DEBUG - 2023-11-20 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:05:39 --> Input Class Initialized
INFO - 2023-11-20 15:05:39 --> Language Class Initialized
INFO - 2023-11-20 15:05:39 --> Language Class Initialized
INFO - 2023-11-20 15:05:39 --> Config Class Initialized
INFO - 2023-11-20 15:05:39 --> Loader Class Initialized
INFO - 2023-11-20 15:05:39 --> Helper loaded: url_helper
INFO - 2023-11-20 15:05:39 --> Helper loaded: file_helper
INFO - 2023-11-20 15:05:39 --> Helper loaded: form_helper
INFO - 2023-11-20 15:05:39 --> Helper loaded: my_helper
INFO - 2023-11-20 15:05:39 --> Database Driver Class Initialized
INFO - 2023-11-20 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:05:39 --> Controller Class Initialized
INFO - 2023-11-20 15:05:39 --> Final output sent to browser
DEBUG - 2023-11-20 15:05:39 --> Total execution time: 0.0636
INFO - 2023-11-20 15:29:30 --> Config Class Initialized
INFO - 2023-11-20 15:29:30 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:29:30 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:29:30 --> Utf8 Class Initialized
INFO - 2023-11-20 15:29:30 --> URI Class Initialized
INFO - 2023-11-20 15:29:30 --> Router Class Initialized
INFO - 2023-11-20 15:29:30 --> Output Class Initialized
INFO - 2023-11-20 15:29:30 --> Security Class Initialized
DEBUG - 2023-11-20 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:29:30 --> Input Class Initialized
INFO - 2023-11-20 15:29:30 --> Language Class Initialized
INFO - 2023-11-20 15:29:30 --> Language Class Initialized
INFO - 2023-11-20 15:29:30 --> Config Class Initialized
INFO - 2023-11-20 15:29:30 --> Loader Class Initialized
INFO - 2023-11-20 15:29:30 --> Helper loaded: url_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: file_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: form_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: my_helper
INFO - 2023-11-20 15:29:30 --> Database Driver Class Initialized
INFO - 2023-11-20 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:29:30 --> Controller Class Initialized
INFO - 2023-11-20 15:29:30 --> Helper loaded: cookie_helper
INFO - 2023-11-20 15:29:30 --> Config Class Initialized
INFO - 2023-11-20 15:29:30 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:29:30 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:29:30 --> Utf8 Class Initialized
INFO - 2023-11-20 15:29:30 --> URI Class Initialized
INFO - 2023-11-20 15:29:30 --> Router Class Initialized
INFO - 2023-11-20 15:29:30 --> Output Class Initialized
INFO - 2023-11-20 15:29:30 --> Security Class Initialized
DEBUG - 2023-11-20 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:29:30 --> Input Class Initialized
INFO - 2023-11-20 15:29:30 --> Language Class Initialized
INFO - 2023-11-20 15:29:30 --> Language Class Initialized
INFO - 2023-11-20 15:29:30 --> Config Class Initialized
INFO - 2023-11-20 15:29:30 --> Loader Class Initialized
INFO - 2023-11-20 15:29:30 --> Helper loaded: url_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: file_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: form_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: my_helper
INFO - 2023-11-20 15:29:30 --> Database Driver Class Initialized
INFO - 2023-11-20 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:29:30 --> Controller Class Initialized
INFO - 2023-11-20 15:29:30 --> Config Class Initialized
INFO - 2023-11-20 15:29:30 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:29:30 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:29:30 --> Utf8 Class Initialized
INFO - 2023-11-20 15:29:30 --> URI Class Initialized
INFO - 2023-11-20 15:29:30 --> Router Class Initialized
INFO - 2023-11-20 15:29:30 --> Output Class Initialized
INFO - 2023-11-20 15:29:30 --> Security Class Initialized
DEBUG - 2023-11-20 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:29:30 --> Input Class Initialized
INFO - 2023-11-20 15:29:30 --> Language Class Initialized
INFO - 2023-11-20 15:29:30 --> Language Class Initialized
INFO - 2023-11-20 15:29:30 --> Config Class Initialized
INFO - 2023-11-20 15:29:30 --> Loader Class Initialized
INFO - 2023-11-20 15:29:30 --> Helper loaded: url_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: file_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: form_helper
INFO - 2023-11-20 15:29:30 --> Helper loaded: my_helper
INFO - 2023-11-20 15:29:30 --> Database Driver Class Initialized
INFO - 2023-11-20 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:29:30 --> Controller Class Initialized
DEBUG - 2023-11-20 15:29:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 15:29:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 15:29:30 --> Final output sent to browser
DEBUG - 2023-11-20 15:29:30 --> Total execution time: 0.0654
INFO - 2023-11-20 16:13:36 --> Config Class Initialized
INFO - 2023-11-20 16:13:36 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:13:36 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:13:36 --> Utf8 Class Initialized
INFO - 2023-11-20 16:13:36 --> URI Class Initialized
INFO - 2023-11-20 16:13:36 --> Router Class Initialized
INFO - 2023-11-20 16:13:36 --> Output Class Initialized
INFO - 2023-11-20 16:13:36 --> Security Class Initialized
DEBUG - 2023-11-20 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:13:36 --> Input Class Initialized
INFO - 2023-11-20 16:13:36 --> Language Class Initialized
INFO - 2023-11-20 16:13:36 --> Language Class Initialized
INFO - 2023-11-20 16:13:36 --> Config Class Initialized
INFO - 2023-11-20 16:13:36 --> Loader Class Initialized
INFO - 2023-11-20 16:13:36 --> Helper loaded: url_helper
INFO - 2023-11-20 16:13:36 --> Helper loaded: file_helper
INFO - 2023-11-20 16:13:36 --> Helper loaded: form_helper
INFO - 2023-11-20 16:13:36 --> Helper loaded: my_helper
INFO - 2023-11-20 16:13:36 --> Database Driver Class Initialized
INFO - 2023-11-20 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:13:36 --> Controller Class Initialized
DEBUG - 2023-11-20 16:13:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-20 16:13:44 --> Final output sent to browser
DEBUG - 2023-11-20 16:13:44 --> Total execution time: 7.6230
INFO - 2023-11-20 16:15:46 --> Config Class Initialized
INFO - 2023-11-20 16:15:46 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:15:46 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:15:46 --> Utf8 Class Initialized
INFO - 2023-11-20 16:15:46 --> URI Class Initialized
INFO - 2023-11-20 16:15:46 --> Router Class Initialized
INFO - 2023-11-20 16:15:46 --> Output Class Initialized
INFO - 2023-11-20 16:15:46 --> Security Class Initialized
DEBUG - 2023-11-20 16:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:15:46 --> Input Class Initialized
INFO - 2023-11-20 16:15:46 --> Language Class Initialized
INFO - 2023-11-20 16:15:46 --> Language Class Initialized
INFO - 2023-11-20 16:15:46 --> Config Class Initialized
INFO - 2023-11-20 16:15:46 --> Loader Class Initialized
INFO - 2023-11-20 16:15:46 --> Helper loaded: url_helper
INFO - 2023-11-20 16:15:46 --> Helper loaded: file_helper
INFO - 2023-11-20 16:15:46 --> Helper loaded: form_helper
INFO - 2023-11-20 16:15:46 --> Helper loaded: my_helper
INFO - 2023-11-20 16:15:46 --> Database Driver Class Initialized
INFO - 2023-11-20 16:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:15:46 --> Controller Class Initialized
DEBUG - 2023-11-20 16:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
DEBUG - 2023-11-20 16:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-11-20 16:15:50 --> Final output sent to browser
DEBUG - 2023-11-20 16:15:50 --> Total execution time: 4.2355
INFO - 2023-11-20 16:17:02 --> Config Class Initialized
INFO - 2023-11-20 16:17:02 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:17:02 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:17:02 --> Utf8 Class Initialized
INFO - 2023-11-20 16:17:02 --> URI Class Initialized
INFO - 2023-11-20 16:17:02 --> Router Class Initialized
INFO - 2023-11-20 16:17:02 --> Output Class Initialized
INFO - 2023-11-20 16:17:02 --> Security Class Initialized
DEBUG - 2023-11-20 16:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:17:02 --> Input Class Initialized
INFO - 2023-11-20 16:17:02 --> Language Class Initialized
INFO - 2023-11-20 16:17:02 --> Language Class Initialized
INFO - 2023-11-20 16:17:02 --> Config Class Initialized
INFO - 2023-11-20 16:17:02 --> Loader Class Initialized
INFO - 2023-11-20 16:17:02 --> Helper loaded: url_helper
INFO - 2023-11-20 16:17:02 --> Helper loaded: file_helper
INFO - 2023-11-20 16:17:02 --> Helper loaded: form_helper
INFO - 2023-11-20 16:17:02 --> Helper loaded: my_helper
INFO - 2023-11-20 16:17:02 --> Database Driver Class Initialized
INFO - 2023-11-20 16:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:17:02 --> Controller Class Initialized
DEBUG - 2023-11-20 16:17:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-20 16:17:05 --> Final output sent to browser
DEBUG - 2023-11-20 16:17:05 --> Total execution time: 3.0234
INFO - 2023-11-20 16:18:32 --> Config Class Initialized
INFO - 2023-11-20 16:18:32 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:32 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:32 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:32 --> URI Class Initialized
INFO - 2023-11-20 16:18:32 --> Router Class Initialized
INFO - 2023-11-20 16:18:32 --> Output Class Initialized
INFO - 2023-11-20 16:18:32 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:32 --> Input Class Initialized
INFO - 2023-11-20 16:18:32 --> Language Class Initialized
INFO - 2023-11-20 16:18:32 --> Language Class Initialized
INFO - 2023-11-20 16:18:32 --> Config Class Initialized
INFO - 2023-11-20 16:18:32 --> Loader Class Initialized
INFO - 2023-11-20 16:18:32 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:32 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:32 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:32 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:32 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:32 --> Controller Class Initialized
DEBUG - 2023-11-20 16:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-20 16:18:37 --> Final output sent to browser
DEBUG - 2023-11-20 16:18:37 --> Total execution time: 5.2559
INFO - 2023-11-20 16:18:47 --> Config Class Initialized
INFO - 2023-11-20 16:18:47 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:47 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:47 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:47 --> URI Class Initialized
DEBUG - 2023-11-20 16:18:47 --> No URI present. Default controller set.
INFO - 2023-11-20 16:18:47 --> Router Class Initialized
INFO - 2023-11-20 16:18:47 --> Output Class Initialized
INFO - 2023-11-20 16:18:47 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:47 --> Input Class Initialized
INFO - 2023-11-20 16:18:47 --> Language Class Initialized
INFO - 2023-11-20 16:18:47 --> Language Class Initialized
INFO - 2023-11-20 16:18:47 --> Config Class Initialized
INFO - 2023-11-20 16:18:47 --> Loader Class Initialized
INFO - 2023-11-20 16:18:47 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:47 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:47 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:47 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:47 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:47 --> Controller Class Initialized
DEBUG - 2023-11-20 16:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-20 16:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:18:47 --> Final output sent to browser
DEBUG - 2023-11-20 16:18:47 --> Total execution time: 0.0554
INFO - 2023-11-20 16:18:49 --> Config Class Initialized
INFO - 2023-11-20 16:18:49 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:49 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:49 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:49 --> URI Class Initialized
INFO - 2023-11-20 16:18:49 --> Router Class Initialized
INFO - 2023-11-20 16:18:49 --> Output Class Initialized
INFO - 2023-11-20 16:18:49 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:49 --> Input Class Initialized
INFO - 2023-11-20 16:18:49 --> Language Class Initialized
INFO - 2023-11-20 16:18:49 --> Language Class Initialized
INFO - 2023-11-20 16:18:49 --> Config Class Initialized
INFO - 2023-11-20 16:18:49 --> Loader Class Initialized
INFO - 2023-11-20 16:18:49 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:49 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:49 --> Controller Class Initialized
INFO - 2023-11-20 16:18:49 --> Helper loaded: cookie_helper
INFO - 2023-11-20 16:18:49 --> Config Class Initialized
INFO - 2023-11-20 16:18:49 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:49 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:49 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:49 --> URI Class Initialized
INFO - 2023-11-20 16:18:49 --> Router Class Initialized
INFO - 2023-11-20 16:18:49 --> Output Class Initialized
INFO - 2023-11-20 16:18:49 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:49 --> Input Class Initialized
INFO - 2023-11-20 16:18:49 --> Language Class Initialized
INFO - 2023-11-20 16:18:49 --> Language Class Initialized
INFO - 2023-11-20 16:18:49 --> Config Class Initialized
INFO - 2023-11-20 16:18:49 --> Loader Class Initialized
INFO - 2023-11-20 16:18:49 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:49 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:49 --> Controller Class Initialized
INFO - 2023-11-20 16:18:49 --> Config Class Initialized
INFO - 2023-11-20 16:18:49 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:49 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:49 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:49 --> URI Class Initialized
INFO - 2023-11-20 16:18:49 --> Router Class Initialized
INFO - 2023-11-20 16:18:49 --> Output Class Initialized
INFO - 2023-11-20 16:18:49 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:49 --> Input Class Initialized
INFO - 2023-11-20 16:18:49 --> Language Class Initialized
INFO - 2023-11-20 16:18:49 --> Language Class Initialized
INFO - 2023-11-20 16:18:49 --> Config Class Initialized
INFO - 2023-11-20 16:18:49 --> Loader Class Initialized
INFO - 2023-11-20 16:18:49 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:49 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:49 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:49 --> Controller Class Initialized
DEBUG - 2023-11-20 16:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 16:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:18:49 --> Final output sent to browser
DEBUG - 2023-11-20 16:18:49 --> Total execution time: 0.0326
INFO - 2023-11-20 16:18:56 --> Config Class Initialized
INFO - 2023-11-20 16:18:56 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:56 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:56 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:56 --> URI Class Initialized
INFO - 2023-11-20 16:18:56 --> Router Class Initialized
INFO - 2023-11-20 16:18:56 --> Output Class Initialized
INFO - 2023-11-20 16:18:56 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:56 --> Input Class Initialized
INFO - 2023-11-20 16:18:56 --> Language Class Initialized
INFO - 2023-11-20 16:18:56 --> Language Class Initialized
INFO - 2023-11-20 16:18:56 --> Config Class Initialized
INFO - 2023-11-20 16:18:56 --> Loader Class Initialized
INFO - 2023-11-20 16:18:56 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:56 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:56 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:56 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:56 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:56 --> Controller Class Initialized
INFO - 2023-11-20 16:18:56 --> Helper loaded: cookie_helper
INFO - 2023-11-20 16:18:56 --> Final output sent to browser
DEBUG - 2023-11-20 16:18:56 --> Total execution time: 0.0416
INFO - 2023-11-20 16:18:56 --> Config Class Initialized
INFO - 2023-11-20 16:18:56 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:56 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:56 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:56 --> URI Class Initialized
INFO - 2023-11-20 16:18:56 --> Router Class Initialized
INFO - 2023-11-20 16:18:56 --> Output Class Initialized
INFO - 2023-11-20 16:18:56 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:56 --> Input Class Initialized
INFO - 2023-11-20 16:18:56 --> Language Class Initialized
INFO - 2023-11-20 16:18:56 --> Language Class Initialized
INFO - 2023-11-20 16:18:56 --> Config Class Initialized
INFO - 2023-11-20 16:18:56 --> Loader Class Initialized
INFO - 2023-11-20 16:18:56 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:56 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:56 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:56 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:56 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:56 --> Controller Class Initialized
DEBUG - 2023-11-20 16:18:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-20 16:18:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:18:56 --> Final output sent to browser
DEBUG - 2023-11-20 16:18:56 --> Total execution time: 0.0439
INFO - 2023-11-20 16:18:59 --> Config Class Initialized
INFO - 2023-11-20 16:18:59 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:59 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:59 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:59 --> URI Class Initialized
INFO - 2023-11-20 16:18:59 --> Router Class Initialized
INFO - 2023-11-20 16:18:59 --> Output Class Initialized
INFO - 2023-11-20 16:18:59 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:59 --> Input Class Initialized
INFO - 2023-11-20 16:18:59 --> Language Class Initialized
INFO - 2023-11-20 16:18:59 --> Language Class Initialized
INFO - 2023-11-20 16:18:59 --> Config Class Initialized
INFO - 2023-11-20 16:18:59 --> Loader Class Initialized
INFO - 2023-11-20 16:18:59 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:59 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:59 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:59 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:59 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:59 --> Controller Class Initialized
DEBUG - 2023-11-20 16:18:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-11-20 16:18:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:18:59 --> Final output sent to browser
DEBUG - 2023-11-20 16:18:59 --> Total execution time: 0.0369
INFO - 2023-11-20 16:18:59 --> Config Class Initialized
INFO - 2023-11-20 16:18:59 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:59 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:59 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:59 --> URI Class Initialized
INFO - 2023-11-20 16:18:59 --> Router Class Initialized
INFO - 2023-11-20 16:18:59 --> Output Class Initialized
INFO - 2023-11-20 16:18:59 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:59 --> Input Class Initialized
INFO - 2023-11-20 16:18:59 --> Language Class Initialized
ERROR - 2023-11-20 16:18:59 --> 404 Page Not Found: /index
INFO - 2023-11-20 16:18:59 --> Config Class Initialized
INFO - 2023-11-20 16:18:59 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:18:59 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:18:59 --> Utf8 Class Initialized
INFO - 2023-11-20 16:18:59 --> URI Class Initialized
INFO - 2023-11-20 16:18:59 --> Router Class Initialized
INFO - 2023-11-20 16:18:59 --> Output Class Initialized
INFO - 2023-11-20 16:18:59 --> Security Class Initialized
DEBUG - 2023-11-20 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:18:59 --> Input Class Initialized
INFO - 2023-11-20 16:18:59 --> Language Class Initialized
INFO - 2023-11-20 16:18:59 --> Language Class Initialized
INFO - 2023-11-20 16:18:59 --> Config Class Initialized
INFO - 2023-11-20 16:18:59 --> Loader Class Initialized
INFO - 2023-11-20 16:18:59 --> Helper loaded: url_helper
INFO - 2023-11-20 16:18:59 --> Helper loaded: file_helper
INFO - 2023-11-20 16:18:59 --> Helper loaded: form_helper
INFO - 2023-11-20 16:18:59 --> Helper loaded: my_helper
INFO - 2023-11-20 16:18:59 --> Database Driver Class Initialized
INFO - 2023-11-20 16:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:18:59 --> Controller Class Initialized
INFO - 2023-11-20 16:19:02 --> Config Class Initialized
INFO - 2023-11-20 16:19:02 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:19:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:19:03 --> Utf8 Class Initialized
INFO - 2023-11-20 16:19:03 --> URI Class Initialized
INFO - 2023-11-20 16:19:03 --> Router Class Initialized
INFO - 2023-11-20 16:19:03 --> Output Class Initialized
INFO - 2023-11-20 16:19:03 --> Security Class Initialized
DEBUG - 2023-11-20 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:19:03 --> Input Class Initialized
INFO - 2023-11-20 16:19:03 --> Language Class Initialized
INFO - 2023-11-20 16:19:03 --> Language Class Initialized
INFO - 2023-11-20 16:19:03 --> Config Class Initialized
INFO - 2023-11-20 16:19:03 --> Loader Class Initialized
INFO - 2023-11-20 16:19:03 --> Helper loaded: url_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: file_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: form_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: my_helper
INFO - 2023-11-20 16:19:03 --> Database Driver Class Initialized
INFO - 2023-11-20 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:19:03 --> Controller Class Initialized
INFO - 2023-11-20 16:19:03 --> Helper loaded: cookie_helper
INFO - 2023-11-20 16:19:03 --> Config Class Initialized
INFO - 2023-11-20 16:19:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:19:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:19:03 --> Utf8 Class Initialized
INFO - 2023-11-20 16:19:03 --> URI Class Initialized
INFO - 2023-11-20 16:19:03 --> Router Class Initialized
INFO - 2023-11-20 16:19:03 --> Output Class Initialized
INFO - 2023-11-20 16:19:03 --> Security Class Initialized
DEBUG - 2023-11-20 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:19:03 --> Input Class Initialized
INFO - 2023-11-20 16:19:03 --> Language Class Initialized
INFO - 2023-11-20 16:19:03 --> Language Class Initialized
INFO - 2023-11-20 16:19:03 --> Config Class Initialized
INFO - 2023-11-20 16:19:03 --> Loader Class Initialized
INFO - 2023-11-20 16:19:03 --> Helper loaded: url_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: file_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: form_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: my_helper
INFO - 2023-11-20 16:19:03 --> Database Driver Class Initialized
INFO - 2023-11-20 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:19:03 --> Controller Class Initialized
INFO - 2023-11-20 16:19:03 --> Config Class Initialized
INFO - 2023-11-20 16:19:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:19:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:19:03 --> Utf8 Class Initialized
INFO - 2023-11-20 16:19:03 --> URI Class Initialized
INFO - 2023-11-20 16:19:03 --> Router Class Initialized
INFO - 2023-11-20 16:19:03 --> Output Class Initialized
INFO - 2023-11-20 16:19:03 --> Security Class Initialized
DEBUG - 2023-11-20 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:19:03 --> Input Class Initialized
INFO - 2023-11-20 16:19:03 --> Language Class Initialized
INFO - 2023-11-20 16:19:03 --> Language Class Initialized
INFO - 2023-11-20 16:19:03 --> Config Class Initialized
INFO - 2023-11-20 16:19:03 --> Loader Class Initialized
INFO - 2023-11-20 16:19:03 --> Helper loaded: url_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: file_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: form_helper
INFO - 2023-11-20 16:19:03 --> Helper loaded: my_helper
INFO - 2023-11-20 16:19:03 --> Database Driver Class Initialized
INFO - 2023-11-20 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:19:03 --> Controller Class Initialized
DEBUG - 2023-11-20 16:19:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 16:19:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:19:03 --> Final output sent to browser
DEBUG - 2023-11-20 16:19:03 --> Total execution time: 0.0948
INFO - 2023-11-20 16:19:08 --> Config Class Initialized
INFO - 2023-11-20 16:19:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:19:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:19:08 --> Utf8 Class Initialized
INFO - 2023-11-20 16:19:08 --> URI Class Initialized
INFO - 2023-11-20 16:19:08 --> Router Class Initialized
INFO - 2023-11-20 16:19:08 --> Output Class Initialized
INFO - 2023-11-20 16:19:08 --> Security Class Initialized
DEBUG - 2023-11-20 16:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:19:08 --> Input Class Initialized
INFO - 2023-11-20 16:19:08 --> Language Class Initialized
INFO - 2023-11-20 16:19:08 --> Language Class Initialized
INFO - 2023-11-20 16:19:08 --> Config Class Initialized
INFO - 2023-11-20 16:19:08 --> Loader Class Initialized
INFO - 2023-11-20 16:19:08 --> Helper loaded: url_helper
INFO - 2023-11-20 16:19:08 --> Helper loaded: file_helper
INFO - 2023-11-20 16:19:08 --> Helper loaded: form_helper
INFO - 2023-11-20 16:19:08 --> Helper loaded: my_helper
INFO - 2023-11-20 16:19:08 --> Database Driver Class Initialized
INFO - 2023-11-20 16:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:19:08 --> Controller Class Initialized
INFO - 2023-11-20 16:19:08 --> Helper loaded: cookie_helper
INFO - 2023-11-20 16:19:08 --> Final output sent to browser
DEBUG - 2023-11-20 16:19:08 --> Total execution time: 0.0443
INFO - 2023-11-20 16:19:08 --> Config Class Initialized
INFO - 2023-11-20 16:19:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:19:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:19:08 --> Utf8 Class Initialized
INFO - 2023-11-20 16:19:08 --> URI Class Initialized
INFO - 2023-11-20 16:19:08 --> Router Class Initialized
INFO - 2023-11-20 16:19:08 --> Output Class Initialized
INFO - 2023-11-20 16:19:08 --> Security Class Initialized
DEBUG - 2023-11-20 16:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:19:08 --> Input Class Initialized
INFO - 2023-11-20 16:19:08 --> Language Class Initialized
INFO - 2023-11-20 16:19:08 --> Language Class Initialized
INFO - 2023-11-20 16:19:08 --> Config Class Initialized
INFO - 2023-11-20 16:19:08 --> Loader Class Initialized
INFO - 2023-11-20 16:19:08 --> Helper loaded: url_helper
INFO - 2023-11-20 16:19:08 --> Helper loaded: file_helper
INFO - 2023-11-20 16:19:08 --> Helper loaded: form_helper
INFO - 2023-11-20 16:19:08 --> Helper loaded: my_helper
INFO - 2023-11-20 16:19:08 --> Database Driver Class Initialized
INFO - 2023-11-20 16:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:19:08 --> Controller Class Initialized
DEBUG - 2023-11-20 16:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-20 16:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:19:08 --> Final output sent to browser
DEBUG - 2023-11-20 16:19:08 --> Total execution time: 0.0357
INFO - 2023-11-20 16:19:17 --> Config Class Initialized
INFO - 2023-11-20 16:19:17 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:19:17 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:19:17 --> Utf8 Class Initialized
INFO - 2023-11-20 16:19:17 --> URI Class Initialized
INFO - 2023-11-20 16:19:17 --> Router Class Initialized
INFO - 2023-11-20 16:19:17 --> Output Class Initialized
INFO - 2023-11-20 16:19:17 --> Security Class Initialized
DEBUG - 2023-11-20 16:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:19:17 --> Input Class Initialized
INFO - 2023-11-20 16:19:17 --> Language Class Initialized
INFO - 2023-11-20 16:19:17 --> Language Class Initialized
INFO - 2023-11-20 16:19:17 --> Config Class Initialized
INFO - 2023-11-20 16:19:17 --> Loader Class Initialized
INFO - 2023-11-20 16:19:17 --> Helper loaded: url_helper
INFO - 2023-11-20 16:19:17 --> Helper loaded: file_helper
INFO - 2023-11-20 16:19:17 --> Helper loaded: form_helper
INFO - 2023-11-20 16:19:17 --> Helper loaded: my_helper
INFO - 2023-11-20 16:19:17 --> Database Driver Class Initialized
INFO - 2023-11-20 16:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:19:17 --> Controller Class Initialized
DEBUG - 2023-11-20 16:19:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-20 16:19:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:19:17 --> Final output sent to browser
DEBUG - 2023-11-20 16:19:17 --> Total execution time: 0.1136
INFO - 2023-11-20 16:20:14 --> Config Class Initialized
INFO - 2023-11-20 16:20:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:20:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:20:14 --> Utf8 Class Initialized
INFO - 2023-11-20 16:20:14 --> URI Class Initialized
INFO - 2023-11-20 16:20:14 --> Router Class Initialized
INFO - 2023-11-20 16:20:14 --> Output Class Initialized
INFO - 2023-11-20 16:20:14 --> Security Class Initialized
DEBUG - 2023-11-20 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:20:14 --> Input Class Initialized
INFO - 2023-11-20 16:20:14 --> Language Class Initialized
INFO - 2023-11-20 16:20:14 --> Language Class Initialized
INFO - 2023-11-20 16:20:14 --> Config Class Initialized
INFO - 2023-11-20 16:20:14 --> Loader Class Initialized
INFO - 2023-11-20 16:20:14 --> Helper loaded: url_helper
INFO - 2023-11-20 16:20:14 --> Helper loaded: file_helper
INFO - 2023-11-20 16:20:14 --> Helper loaded: form_helper
INFO - 2023-11-20 16:20:14 --> Helper loaded: my_helper
INFO - 2023-11-20 16:20:14 --> Database Driver Class Initialized
INFO - 2023-11-20 16:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:20:14 --> Controller Class Initialized
DEBUG - 2023-11-20 16:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-20 16:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:20:14 --> Final output sent to browser
DEBUG - 2023-11-20 16:20:14 --> Total execution time: 0.0545
INFO - 2023-11-20 16:20:24 --> Config Class Initialized
INFO - 2023-11-20 16:20:24 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:20:24 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:20:24 --> Utf8 Class Initialized
INFO - 2023-11-20 16:20:24 --> URI Class Initialized
INFO - 2023-11-20 16:20:24 --> Router Class Initialized
INFO - 2023-11-20 16:20:24 --> Output Class Initialized
INFO - 2023-11-20 16:20:24 --> Security Class Initialized
DEBUG - 2023-11-20 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:20:24 --> Input Class Initialized
INFO - 2023-11-20 16:20:24 --> Language Class Initialized
INFO - 2023-11-20 16:20:24 --> Language Class Initialized
INFO - 2023-11-20 16:20:24 --> Config Class Initialized
INFO - 2023-11-20 16:20:24 --> Loader Class Initialized
INFO - 2023-11-20 16:20:24 --> Helper loaded: url_helper
INFO - 2023-11-20 16:20:24 --> Helper loaded: file_helper
INFO - 2023-11-20 16:20:24 --> Helper loaded: form_helper
INFO - 2023-11-20 16:20:24 --> Helper loaded: my_helper
INFO - 2023-11-20 16:20:24 --> Database Driver Class Initialized
INFO - 2023-11-20 16:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:20:24 --> Controller Class Initialized
DEBUG - 2023-11-20 16:20:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-20 16:20:30 --> Final output sent to browser
DEBUG - 2023-11-20 16:20:30 --> Total execution time: 5.4521
INFO - 2023-11-20 16:22:03 --> Config Class Initialized
INFO - 2023-11-20 16:22:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:03 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:03 --> URI Class Initialized
INFO - 2023-11-20 16:22:03 --> Router Class Initialized
INFO - 2023-11-20 16:22:03 --> Output Class Initialized
INFO - 2023-11-20 16:22:03 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:03 --> Input Class Initialized
INFO - 2023-11-20 16:22:03 --> Language Class Initialized
INFO - 2023-11-20 16:22:03 --> Language Class Initialized
INFO - 2023-11-20 16:22:03 --> Config Class Initialized
INFO - 2023-11-20 16:22:03 --> Loader Class Initialized
INFO - 2023-11-20 16:22:03 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:03 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:03 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:03 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:03 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:03 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-20 16:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:03 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:03 --> Total execution time: 0.0753
INFO - 2023-11-20 16:22:08 --> Config Class Initialized
INFO - 2023-11-20 16:22:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:08 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:08 --> URI Class Initialized
INFO - 2023-11-20 16:22:08 --> Router Class Initialized
INFO - 2023-11-20 16:22:08 --> Output Class Initialized
INFO - 2023-11-20 16:22:08 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:08 --> Input Class Initialized
INFO - 2023-11-20 16:22:08 --> Language Class Initialized
INFO - 2023-11-20 16:22:08 --> Language Class Initialized
INFO - 2023-11-20 16:22:08 --> Config Class Initialized
INFO - 2023-11-20 16:22:08 --> Loader Class Initialized
INFO - 2023-11-20 16:22:08 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:08 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:08 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:09 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:09 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:09 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-11-20 16:22:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:09 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:09 --> Total execution time: 0.2575
INFO - 2023-11-20 16:22:09 --> Config Class Initialized
INFO - 2023-11-20 16:22:09 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:09 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:09 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:09 --> URI Class Initialized
INFO - 2023-11-20 16:22:09 --> Router Class Initialized
INFO - 2023-11-20 16:22:09 --> Output Class Initialized
INFO - 2023-11-20 16:22:09 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:09 --> Input Class Initialized
INFO - 2023-11-20 16:22:09 --> Language Class Initialized
INFO - 2023-11-20 16:22:09 --> Language Class Initialized
INFO - 2023-11-20 16:22:09 --> Config Class Initialized
INFO - 2023-11-20 16:22:09 --> Loader Class Initialized
INFO - 2023-11-20 16:22:09 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:09 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:09 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:09 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:09 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:09 --> Controller Class Initialized
INFO - 2023-11-20 16:22:11 --> Config Class Initialized
INFO - 2023-11-20 16:22:11 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:11 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:11 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:11 --> URI Class Initialized
INFO - 2023-11-20 16:22:11 --> Router Class Initialized
INFO - 2023-11-20 16:22:11 --> Output Class Initialized
INFO - 2023-11-20 16:22:11 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:11 --> Input Class Initialized
INFO - 2023-11-20 16:22:11 --> Language Class Initialized
INFO - 2023-11-20 16:22:11 --> Language Class Initialized
INFO - 2023-11-20 16:22:11 --> Config Class Initialized
INFO - 2023-11-20 16:22:11 --> Loader Class Initialized
INFO - 2023-11-20 16:22:11 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:11 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:11 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:11 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:11 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:11 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-20 16:22:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:11 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:11 --> Total execution time: 0.0390
INFO - 2023-11-20 16:22:12 --> Config Class Initialized
INFO - 2023-11-20 16:22:12 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:12 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:12 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:12 --> URI Class Initialized
INFO - 2023-11-20 16:22:12 --> Router Class Initialized
INFO - 2023-11-20 16:22:12 --> Output Class Initialized
INFO - 2023-11-20 16:22:12 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:12 --> Input Class Initialized
INFO - 2023-11-20 16:22:12 --> Language Class Initialized
INFO - 2023-11-20 16:22:12 --> Language Class Initialized
INFO - 2023-11-20 16:22:12 --> Config Class Initialized
INFO - 2023-11-20 16:22:12 --> Loader Class Initialized
INFO - 2023-11-20 16:22:12 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:12 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:12 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:12 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:12 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:12 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-20 16:22:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:12 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:12 --> Total execution time: 0.0498
INFO - 2023-11-20 16:22:13 --> Config Class Initialized
INFO - 2023-11-20 16:22:13 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:13 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:13 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:13 --> URI Class Initialized
INFO - 2023-11-20 16:22:13 --> Router Class Initialized
INFO - 2023-11-20 16:22:13 --> Output Class Initialized
INFO - 2023-11-20 16:22:13 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:13 --> Input Class Initialized
INFO - 2023-11-20 16:22:13 --> Language Class Initialized
INFO - 2023-11-20 16:22:13 --> Language Class Initialized
INFO - 2023-11-20 16:22:13 --> Config Class Initialized
INFO - 2023-11-20 16:22:13 --> Loader Class Initialized
INFO - 2023-11-20 16:22:13 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:13 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:13 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:13 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:13 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:13 --> Controller Class Initialized
INFO - 2023-11-20 16:22:16 --> Config Class Initialized
INFO - 2023-11-20 16:22:16 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:16 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:16 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:16 --> URI Class Initialized
INFO - 2023-11-20 16:22:16 --> Router Class Initialized
INFO - 2023-11-20 16:22:16 --> Output Class Initialized
INFO - 2023-11-20 16:22:16 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:16 --> Input Class Initialized
INFO - 2023-11-20 16:22:16 --> Language Class Initialized
INFO - 2023-11-20 16:22:16 --> Language Class Initialized
INFO - 2023-11-20 16:22:16 --> Config Class Initialized
INFO - 2023-11-20 16:22:16 --> Loader Class Initialized
INFO - 2023-11-20 16:22:16 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:16 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:16 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:16 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:16 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:16 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-20 16:22:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:16 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:16 --> Total execution time: 0.0423
INFO - 2023-11-20 16:22:17 --> Config Class Initialized
INFO - 2023-11-20 16:22:17 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:17 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:17 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:17 --> URI Class Initialized
INFO - 2023-11-20 16:22:17 --> Router Class Initialized
INFO - 2023-11-20 16:22:17 --> Output Class Initialized
INFO - 2023-11-20 16:22:17 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:17 --> Input Class Initialized
INFO - 2023-11-20 16:22:17 --> Language Class Initialized
INFO - 2023-11-20 16:22:17 --> Language Class Initialized
INFO - 2023-11-20 16:22:17 --> Config Class Initialized
INFO - 2023-11-20 16:22:17 --> Loader Class Initialized
INFO - 2023-11-20 16:22:17 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:17 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:17 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:17 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:17 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:17 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-20 16:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:17 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:17 --> Total execution time: 0.0328
INFO - 2023-11-20 16:22:17 --> Config Class Initialized
INFO - 2023-11-20 16:22:17 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:17 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:17 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:17 --> URI Class Initialized
INFO - 2023-11-20 16:22:17 --> Router Class Initialized
INFO - 2023-11-20 16:22:17 --> Output Class Initialized
INFO - 2023-11-20 16:22:17 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:17 --> Input Class Initialized
INFO - 2023-11-20 16:22:17 --> Language Class Initialized
INFO - 2023-11-20 16:22:17 --> Language Class Initialized
INFO - 2023-11-20 16:22:17 --> Config Class Initialized
INFO - 2023-11-20 16:22:17 --> Loader Class Initialized
INFO - 2023-11-20 16:22:17 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:17 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:17 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:17 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:17 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:17 --> Controller Class Initialized
INFO - 2023-11-20 16:22:19 --> Config Class Initialized
INFO - 2023-11-20 16:22:19 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:19 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:19 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:19 --> URI Class Initialized
INFO - 2023-11-20 16:22:19 --> Router Class Initialized
INFO - 2023-11-20 16:22:19 --> Output Class Initialized
INFO - 2023-11-20 16:22:19 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:19 --> Input Class Initialized
INFO - 2023-11-20 16:22:19 --> Language Class Initialized
INFO - 2023-11-20 16:22:19 --> Language Class Initialized
INFO - 2023-11-20 16:22:19 --> Config Class Initialized
INFO - 2023-11-20 16:22:19 --> Loader Class Initialized
INFO - 2023-11-20 16:22:19 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:19 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:19 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:19 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:19 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:19 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-20 16:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:19 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:19 --> Total execution time: 0.0381
INFO - 2023-11-20 16:22:20 --> Config Class Initialized
INFO - 2023-11-20 16:22:20 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:20 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:20 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:20 --> URI Class Initialized
INFO - 2023-11-20 16:22:20 --> Router Class Initialized
INFO - 2023-11-20 16:22:20 --> Output Class Initialized
INFO - 2023-11-20 16:22:20 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:20 --> Input Class Initialized
INFO - 2023-11-20 16:22:20 --> Language Class Initialized
INFO - 2023-11-20 16:22:20 --> Language Class Initialized
INFO - 2023-11-20 16:22:20 --> Config Class Initialized
INFO - 2023-11-20 16:22:20 --> Loader Class Initialized
INFO - 2023-11-20 16:22:20 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:20 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:20 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:20 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:20 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:20 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-20 16:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:20 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:20 --> Total execution time: 0.0448
INFO - 2023-11-20 16:22:20 --> Config Class Initialized
INFO - 2023-11-20 16:22:20 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:20 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:20 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:20 --> URI Class Initialized
INFO - 2023-11-20 16:22:20 --> Router Class Initialized
INFO - 2023-11-20 16:22:20 --> Output Class Initialized
INFO - 2023-11-20 16:22:20 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:20 --> Input Class Initialized
INFO - 2023-11-20 16:22:20 --> Language Class Initialized
INFO - 2023-11-20 16:22:20 --> Language Class Initialized
INFO - 2023-11-20 16:22:20 --> Config Class Initialized
INFO - 2023-11-20 16:22:20 --> Loader Class Initialized
INFO - 2023-11-20 16:22:20 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:20 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:20 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:20 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:20 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:20 --> Controller Class Initialized
INFO - 2023-11-20 16:22:21 --> Config Class Initialized
INFO - 2023-11-20 16:22:21 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:21 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:21 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:21 --> URI Class Initialized
INFO - 2023-11-20 16:22:21 --> Router Class Initialized
INFO - 2023-11-20 16:22:21 --> Output Class Initialized
INFO - 2023-11-20 16:22:21 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:21 --> Input Class Initialized
INFO - 2023-11-20 16:22:21 --> Language Class Initialized
INFO - 2023-11-20 16:22:21 --> Language Class Initialized
INFO - 2023-11-20 16:22:21 --> Config Class Initialized
INFO - 2023-11-20 16:22:21 --> Loader Class Initialized
INFO - 2023-11-20 16:22:21 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:21 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:21 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:21 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:21 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:21 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-20 16:22:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:21 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:21 --> Total execution time: 0.0617
INFO - 2023-11-20 16:22:27 --> Config Class Initialized
INFO - 2023-11-20 16:22:27 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:27 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:27 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:27 --> URI Class Initialized
INFO - 2023-11-20 16:22:27 --> Router Class Initialized
INFO - 2023-11-20 16:22:27 --> Output Class Initialized
INFO - 2023-11-20 16:22:27 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:27 --> Input Class Initialized
INFO - 2023-11-20 16:22:27 --> Language Class Initialized
INFO - 2023-11-20 16:22:27 --> Language Class Initialized
INFO - 2023-11-20 16:22:27 --> Config Class Initialized
INFO - 2023-11-20 16:22:27 --> Loader Class Initialized
INFO - 2023-11-20 16:22:27 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:27 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:27 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:27 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:27 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:27 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-20 16:22:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:27 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:27 --> Total execution time: 0.0401
INFO - 2023-11-20 16:22:27 --> Config Class Initialized
INFO - 2023-11-20 16:22:27 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:27 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:27 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:27 --> URI Class Initialized
INFO - 2023-11-20 16:22:27 --> Router Class Initialized
INFO - 2023-11-20 16:22:27 --> Output Class Initialized
INFO - 2023-11-20 16:22:27 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:27 --> Input Class Initialized
INFO - 2023-11-20 16:22:27 --> Language Class Initialized
INFO - 2023-11-20 16:22:27 --> Language Class Initialized
INFO - 2023-11-20 16:22:27 --> Config Class Initialized
INFO - 2023-11-20 16:22:27 --> Loader Class Initialized
INFO - 2023-11-20 16:22:27 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:27 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:27 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:27 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:27 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:27 --> Controller Class Initialized
INFO - 2023-11-20 16:22:36 --> Config Class Initialized
INFO - 2023-11-20 16:22:36 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:36 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:36 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:36 --> URI Class Initialized
INFO - 2023-11-20 16:22:36 --> Router Class Initialized
INFO - 2023-11-20 16:22:36 --> Output Class Initialized
INFO - 2023-11-20 16:22:36 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:36 --> Input Class Initialized
INFO - 2023-11-20 16:22:36 --> Language Class Initialized
INFO - 2023-11-20 16:22:36 --> Language Class Initialized
INFO - 2023-11-20 16:22:36 --> Config Class Initialized
INFO - 2023-11-20 16:22:36 --> Loader Class Initialized
INFO - 2023-11-20 16:22:36 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:36 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:36 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:36 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:36 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:36 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-20 16:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:36 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:36 --> Total execution time: 0.0425
INFO - 2023-11-20 16:22:49 --> Config Class Initialized
INFO - 2023-11-20 16:22:49 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:49 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:49 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:49 --> URI Class Initialized
INFO - 2023-11-20 16:22:49 --> Router Class Initialized
INFO - 2023-11-20 16:22:49 --> Output Class Initialized
INFO - 2023-11-20 16:22:49 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:49 --> Input Class Initialized
INFO - 2023-11-20 16:22:49 --> Language Class Initialized
INFO - 2023-11-20 16:22:49 --> Language Class Initialized
INFO - 2023-11-20 16:22:49 --> Config Class Initialized
INFO - 2023-11-20 16:22:49 --> Loader Class Initialized
INFO - 2023-11-20 16:22:49 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:49 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:49 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:49 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:49 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:49 --> Controller Class Initialized
DEBUG - 2023-11-20 16:22:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-20 16:22:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:22:49 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:49 --> Total execution time: 0.0915
INFO - 2023-11-20 16:22:49 --> Config Class Initialized
INFO - 2023-11-20 16:22:49 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:49 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:49 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:49 --> URI Class Initialized
INFO - 2023-11-20 16:22:49 --> Router Class Initialized
INFO - 2023-11-20 16:22:49 --> Output Class Initialized
INFO - 2023-11-20 16:22:49 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:49 --> Input Class Initialized
INFO - 2023-11-20 16:22:49 --> Language Class Initialized
INFO - 2023-11-20 16:22:49 --> Language Class Initialized
INFO - 2023-11-20 16:22:49 --> Config Class Initialized
INFO - 2023-11-20 16:22:49 --> Loader Class Initialized
INFO - 2023-11-20 16:22:49 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:49 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:49 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:49 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:49 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:49 --> Controller Class Initialized
INFO - 2023-11-20 16:22:51 --> Config Class Initialized
INFO - 2023-11-20 16:22:51 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:22:51 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:22:51 --> Utf8 Class Initialized
INFO - 2023-11-20 16:22:51 --> URI Class Initialized
INFO - 2023-11-20 16:22:51 --> Router Class Initialized
INFO - 2023-11-20 16:22:51 --> Output Class Initialized
INFO - 2023-11-20 16:22:51 --> Security Class Initialized
DEBUG - 2023-11-20 16:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:22:51 --> Input Class Initialized
INFO - 2023-11-20 16:22:51 --> Language Class Initialized
INFO - 2023-11-20 16:22:51 --> Language Class Initialized
INFO - 2023-11-20 16:22:51 --> Config Class Initialized
INFO - 2023-11-20 16:22:51 --> Loader Class Initialized
INFO - 2023-11-20 16:22:51 --> Helper loaded: url_helper
INFO - 2023-11-20 16:22:51 --> Helper loaded: file_helper
INFO - 2023-11-20 16:22:51 --> Helper loaded: form_helper
INFO - 2023-11-20 16:22:51 --> Helper loaded: my_helper
INFO - 2023-11-20 16:22:51 --> Database Driver Class Initialized
INFO - 2023-11-20 16:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:22:51 --> Controller Class Initialized
INFO - 2023-11-20 16:22:51 --> Final output sent to browser
DEBUG - 2023-11-20 16:22:51 --> Total execution time: 0.0391
INFO - 2023-11-20 16:24:51 --> Config Class Initialized
INFO - 2023-11-20 16:24:51 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:24:51 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:24:51 --> Utf8 Class Initialized
INFO - 2023-11-20 16:24:51 --> URI Class Initialized
INFO - 2023-11-20 16:24:51 --> Router Class Initialized
INFO - 2023-11-20 16:24:51 --> Output Class Initialized
INFO - 2023-11-20 16:24:51 --> Security Class Initialized
DEBUG - 2023-11-20 16:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:24:51 --> Input Class Initialized
INFO - 2023-11-20 16:24:51 --> Language Class Initialized
INFO - 2023-11-20 16:24:51 --> Language Class Initialized
INFO - 2023-11-20 16:24:51 --> Config Class Initialized
INFO - 2023-11-20 16:24:51 --> Loader Class Initialized
INFO - 2023-11-20 16:24:51 --> Helper loaded: url_helper
INFO - 2023-11-20 16:24:51 --> Helper loaded: file_helper
INFO - 2023-11-20 16:24:51 --> Helper loaded: form_helper
INFO - 2023-11-20 16:24:51 --> Helper loaded: my_helper
INFO - 2023-11-20 16:24:51 --> Database Driver Class Initialized
INFO - 2023-11-20 16:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:24:51 --> Controller Class Initialized
DEBUG - 2023-11-20 16:24:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-20 16:24:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:24:51 --> Final output sent to browser
DEBUG - 2023-11-20 16:24:51 --> Total execution time: 0.0555
INFO - 2023-11-20 16:24:51 --> Config Class Initialized
INFO - 2023-11-20 16:24:51 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:24:51 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:24:51 --> Utf8 Class Initialized
INFO - 2023-11-20 16:24:51 --> URI Class Initialized
INFO - 2023-11-20 16:24:51 --> Router Class Initialized
INFO - 2023-11-20 16:24:51 --> Output Class Initialized
INFO - 2023-11-20 16:24:51 --> Security Class Initialized
DEBUG - 2023-11-20 16:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:24:51 --> Input Class Initialized
INFO - 2023-11-20 16:24:51 --> Language Class Initialized
INFO - 2023-11-20 16:24:51 --> Language Class Initialized
INFO - 2023-11-20 16:24:51 --> Config Class Initialized
INFO - 2023-11-20 16:24:51 --> Loader Class Initialized
INFO - 2023-11-20 16:24:51 --> Helper loaded: url_helper
INFO - 2023-11-20 16:24:51 --> Helper loaded: file_helper
INFO - 2023-11-20 16:24:51 --> Helper loaded: form_helper
INFO - 2023-11-20 16:24:52 --> Helper loaded: my_helper
INFO - 2023-11-20 16:24:52 --> Database Driver Class Initialized
INFO - 2023-11-20 16:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:24:52 --> Controller Class Initialized
INFO - 2023-11-20 16:24:53 --> Config Class Initialized
INFO - 2023-11-20 16:24:53 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:24:53 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:24:53 --> Utf8 Class Initialized
INFO - 2023-11-20 16:24:53 --> URI Class Initialized
INFO - 2023-11-20 16:24:53 --> Router Class Initialized
INFO - 2023-11-20 16:24:53 --> Output Class Initialized
INFO - 2023-11-20 16:24:53 --> Security Class Initialized
DEBUG - 2023-11-20 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:24:53 --> Input Class Initialized
INFO - 2023-11-20 16:24:53 --> Language Class Initialized
INFO - 2023-11-20 16:24:53 --> Language Class Initialized
INFO - 2023-11-20 16:24:53 --> Config Class Initialized
INFO - 2023-11-20 16:24:53 --> Loader Class Initialized
INFO - 2023-11-20 16:24:53 --> Helper loaded: url_helper
INFO - 2023-11-20 16:24:53 --> Helper loaded: file_helper
INFO - 2023-11-20 16:24:53 --> Helper loaded: form_helper
INFO - 2023-11-20 16:24:53 --> Helper loaded: my_helper
INFO - 2023-11-20 16:24:53 --> Database Driver Class Initialized
INFO - 2023-11-20 16:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:24:53 --> Controller Class Initialized
INFO - 2023-11-20 16:24:53 --> Final output sent to browser
DEBUG - 2023-11-20 16:24:53 --> Total execution time: 0.0326
INFO - 2023-11-20 16:24:56 --> Config Class Initialized
INFO - 2023-11-20 16:24:56 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:24:56 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:24:56 --> Utf8 Class Initialized
INFO - 2023-11-20 16:24:56 --> URI Class Initialized
INFO - 2023-11-20 16:24:56 --> Router Class Initialized
INFO - 2023-11-20 16:24:56 --> Output Class Initialized
INFO - 2023-11-20 16:24:56 --> Security Class Initialized
DEBUG - 2023-11-20 16:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:24:56 --> Input Class Initialized
INFO - 2023-11-20 16:24:56 --> Language Class Initialized
INFO - 2023-11-20 16:24:56 --> Language Class Initialized
INFO - 2023-11-20 16:24:56 --> Config Class Initialized
INFO - 2023-11-20 16:24:56 --> Loader Class Initialized
INFO - 2023-11-20 16:24:56 --> Helper loaded: url_helper
INFO - 2023-11-20 16:24:56 --> Helper loaded: file_helper
INFO - 2023-11-20 16:24:56 --> Helper loaded: form_helper
INFO - 2023-11-20 16:24:56 --> Helper loaded: my_helper
INFO - 2023-11-20 16:24:56 --> Database Driver Class Initialized
INFO - 2023-11-20 16:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:24:56 --> Controller Class Initialized
INFO - 2023-11-20 16:24:56 --> Final output sent to browser
DEBUG - 2023-11-20 16:24:56 --> Total execution time: 0.0360
INFO - 2023-11-20 16:25:00 --> Config Class Initialized
INFO - 2023-11-20 16:25:00 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:25:00 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:25:00 --> Utf8 Class Initialized
INFO - 2023-11-20 16:25:00 --> URI Class Initialized
INFO - 2023-11-20 16:25:00 --> Router Class Initialized
INFO - 2023-11-20 16:25:00 --> Output Class Initialized
INFO - 2023-11-20 16:25:00 --> Security Class Initialized
DEBUG - 2023-11-20 16:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:25:00 --> Input Class Initialized
INFO - 2023-11-20 16:25:00 --> Language Class Initialized
INFO - 2023-11-20 16:25:00 --> Language Class Initialized
INFO - 2023-11-20 16:25:00 --> Config Class Initialized
INFO - 2023-11-20 16:25:00 --> Loader Class Initialized
INFO - 2023-11-20 16:25:00 --> Helper loaded: url_helper
INFO - 2023-11-20 16:25:00 --> Helper loaded: file_helper
INFO - 2023-11-20 16:25:00 --> Helper loaded: form_helper
INFO - 2023-11-20 16:25:00 --> Helper loaded: my_helper
INFO - 2023-11-20 16:25:00 --> Database Driver Class Initialized
INFO - 2023-11-20 16:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:25:00 --> Controller Class Initialized
INFO - 2023-11-20 16:25:00 --> Final output sent to browser
DEBUG - 2023-11-20 16:25:00 --> Total execution time: 0.0476
INFO - 2023-11-20 16:25:24 --> Config Class Initialized
INFO - 2023-11-20 16:25:24 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:25:24 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:25:24 --> Utf8 Class Initialized
INFO - 2023-11-20 16:25:24 --> URI Class Initialized
INFO - 2023-11-20 16:25:24 --> Router Class Initialized
INFO - 2023-11-20 16:25:24 --> Output Class Initialized
INFO - 2023-11-20 16:25:24 --> Security Class Initialized
DEBUG - 2023-11-20 16:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:25:24 --> Input Class Initialized
INFO - 2023-11-20 16:25:24 --> Language Class Initialized
INFO - 2023-11-20 16:25:25 --> Language Class Initialized
INFO - 2023-11-20 16:25:25 --> Config Class Initialized
INFO - 2023-11-20 16:25:25 --> Loader Class Initialized
INFO - 2023-11-20 16:25:25 --> Helper loaded: url_helper
INFO - 2023-11-20 16:25:25 --> Helper loaded: file_helper
INFO - 2023-11-20 16:25:25 --> Helper loaded: form_helper
INFO - 2023-11-20 16:25:25 --> Helper loaded: my_helper
INFO - 2023-11-20 16:25:25 --> Database Driver Class Initialized
INFO - 2023-11-20 16:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:25:25 --> Controller Class Initialized
INFO - 2023-11-20 16:25:25 --> Final output sent to browser
DEBUG - 2023-11-20 16:25:25 --> Total execution time: 0.0341
INFO - 2023-11-20 16:27:42 --> Config Class Initialized
INFO - 2023-11-20 16:27:42 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:27:42 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:27:42 --> Utf8 Class Initialized
INFO - 2023-11-20 16:27:42 --> URI Class Initialized
INFO - 2023-11-20 16:27:42 --> Router Class Initialized
INFO - 2023-11-20 16:27:42 --> Output Class Initialized
INFO - 2023-11-20 16:27:42 --> Security Class Initialized
DEBUG - 2023-11-20 16:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:27:42 --> Input Class Initialized
INFO - 2023-11-20 16:27:42 --> Language Class Initialized
INFO - 2023-11-20 16:27:42 --> Language Class Initialized
INFO - 2023-11-20 16:27:42 --> Config Class Initialized
INFO - 2023-11-20 16:27:42 --> Loader Class Initialized
INFO - 2023-11-20 16:27:42 --> Helper loaded: url_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: file_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: form_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: my_helper
INFO - 2023-11-20 16:27:42 --> Database Driver Class Initialized
INFO - 2023-11-20 16:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:27:42 --> Controller Class Initialized
INFO - 2023-11-20 16:27:42 --> Helper loaded: cookie_helper
INFO - 2023-11-20 16:27:42 --> Config Class Initialized
INFO - 2023-11-20 16:27:42 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:27:42 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:27:42 --> Utf8 Class Initialized
INFO - 2023-11-20 16:27:42 --> URI Class Initialized
INFO - 2023-11-20 16:27:42 --> Router Class Initialized
INFO - 2023-11-20 16:27:42 --> Output Class Initialized
INFO - 2023-11-20 16:27:42 --> Security Class Initialized
DEBUG - 2023-11-20 16:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:27:42 --> Input Class Initialized
INFO - 2023-11-20 16:27:42 --> Language Class Initialized
INFO - 2023-11-20 16:27:42 --> Language Class Initialized
INFO - 2023-11-20 16:27:42 --> Config Class Initialized
INFO - 2023-11-20 16:27:42 --> Loader Class Initialized
INFO - 2023-11-20 16:27:42 --> Helper loaded: url_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: file_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: form_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: my_helper
INFO - 2023-11-20 16:27:42 --> Database Driver Class Initialized
INFO - 2023-11-20 16:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:27:42 --> Controller Class Initialized
INFO - 2023-11-20 16:27:42 --> Config Class Initialized
INFO - 2023-11-20 16:27:42 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:27:42 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:27:42 --> Utf8 Class Initialized
INFO - 2023-11-20 16:27:42 --> URI Class Initialized
INFO - 2023-11-20 16:27:42 --> Router Class Initialized
INFO - 2023-11-20 16:27:42 --> Output Class Initialized
INFO - 2023-11-20 16:27:42 --> Security Class Initialized
DEBUG - 2023-11-20 16:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:27:42 --> Input Class Initialized
INFO - 2023-11-20 16:27:42 --> Language Class Initialized
INFO - 2023-11-20 16:27:42 --> Language Class Initialized
INFO - 2023-11-20 16:27:42 --> Config Class Initialized
INFO - 2023-11-20 16:27:42 --> Loader Class Initialized
INFO - 2023-11-20 16:27:42 --> Helper loaded: url_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: file_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: form_helper
INFO - 2023-11-20 16:27:42 --> Helper loaded: my_helper
INFO - 2023-11-20 16:27:42 --> Database Driver Class Initialized
INFO - 2023-11-20 16:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:27:42 --> Controller Class Initialized
DEBUG - 2023-11-20 16:27:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-20 16:27:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-20 16:27:42 --> Final output sent to browser
DEBUG - 2023-11-20 16:27:42 --> Total execution time: 0.0373
