<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-03 14:42:42 --> Config Class Initialized
INFO - 2024-08-03 14:42:42 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:42 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:42 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:42 --> URI Class Initialized
INFO - 2024-08-03 14:42:43 --> Router Class Initialized
INFO - 2024-08-03 14:42:43 --> Output Class Initialized
INFO - 2024-08-03 14:42:43 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:43 --> Input Class Initialized
INFO - 2024-08-03 14:42:43 --> Language Class Initialized
INFO - 2024-08-03 14:42:43 --> Language Class Initialized
INFO - 2024-08-03 14:42:43 --> Config Class Initialized
INFO - 2024-08-03 14:42:43 --> Loader Class Initialized
INFO - 2024-08-03 14:42:43 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:43 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:43 --> Controller Class Initialized
INFO - 2024-08-03 14:42:43 --> Helper loaded: cookie_helper
INFO - 2024-08-03 14:42:43 --> Final output sent to browser
DEBUG - 2024-08-03 14:42:43 --> Total execution time: 0.1054
INFO - 2024-08-03 14:42:43 --> Config Class Initialized
INFO - 2024-08-03 14:42:43 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:43 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:43 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:43 --> URI Class Initialized
INFO - 2024-08-03 14:42:43 --> Router Class Initialized
INFO - 2024-08-03 14:42:43 --> Output Class Initialized
INFO - 2024-08-03 14:42:43 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:43 --> Input Class Initialized
INFO - 2024-08-03 14:42:43 --> Language Class Initialized
INFO - 2024-08-03 14:42:43 --> Language Class Initialized
INFO - 2024-08-03 14:42:43 --> Config Class Initialized
INFO - 2024-08-03 14:42:43 --> Loader Class Initialized
INFO - 2024-08-03 14:42:43 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:43 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:43 --> Controller Class Initialized
INFO - 2024-08-03 14:42:43 --> Helper loaded: cookie_helper
INFO - 2024-08-03 14:42:43 --> Config Class Initialized
INFO - 2024-08-03 14:42:43 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:43 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:43 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:43 --> URI Class Initialized
INFO - 2024-08-03 14:42:43 --> Router Class Initialized
INFO - 2024-08-03 14:42:43 --> Output Class Initialized
INFO - 2024-08-03 14:42:43 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:43 --> Input Class Initialized
INFO - 2024-08-03 14:42:43 --> Language Class Initialized
INFO - 2024-08-03 14:42:43 --> Language Class Initialized
INFO - 2024-08-03 14:42:43 --> Config Class Initialized
INFO - 2024-08-03 14:42:43 --> Loader Class Initialized
INFO - 2024-08-03 14:42:43 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:43 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:43 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:43 --> Controller Class Initialized
DEBUG - 2024-08-03 14:42:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-03 14:42:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-03 14:42:43 --> Final output sent to browser
DEBUG - 2024-08-03 14:42:43 --> Total execution time: 0.0359
INFO - 2024-08-03 14:42:48 --> Config Class Initialized
INFO - 2024-08-03 14:42:48 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:48 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:48 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:48 --> URI Class Initialized
INFO - 2024-08-03 14:42:48 --> Router Class Initialized
INFO - 2024-08-03 14:42:48 --> Output Class Initialized
INFO - 2024-08-03 14:42:48 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:48 --> Input Class Initialized
INFO - 2024-08-03 14:42:48 --> Language Class Initialized
INFO - 2024-08-03 14:42:48 --> Language Class Initialized
INFO - 2024-08-03 14:42:48 --> Config Class Initialized
INFO - 2024-08-03 14:42:48 --> Loader Class Initialized
INFO - 2024-08-03 14:42:48 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:48 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:48 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:48 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:48 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:48 --> Controller Class Initialized
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-03 14:42:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-03 14:42:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-03 14:42:48 --> Config Class Initialized
INFO - 2024-08-03 14:42:48 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:48 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:48 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:48 --> URI Class Initialized
INFO - 2024-08-03 14:42:48 --> Router Class Initialized
INFO - 2024-08-03 14:42:48 --> Output Class Initialized
INFO - 2024-08-03 14:42:48 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:48 --> Input Class Initialized
INFO - 2024-08-03 14:42:48 --> Language Class Initialized
INFO - 2024-08-03 14:42:48 --> Language Class Initialized
INFO - 2024-08-03 14:42:48 --> Config Class Initialized
INFO - 2024-08-03 14:42:48 --> Loader Class Initialized
INFO - 2024-08-03 14:42:48 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:48 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:48 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:48 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:48 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:50 --> Config Class Initialized
INFO - 2024-08-03 14:42:50 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:50 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:50 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:50 --> URI Class Initialized
INFO - 2024-08-03 14:42:50 --> Router Class Initialized
INFO - 2024-08-03 14:42:50 --> Output Class Initialized
INFO - 2024-08-03 14:42:50 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:50 --> Input Class Initialized
INFO - 2024-08-03 14:42:50 --> Language Class Initialized
INFO - 2024-08-03 14:42:50 --> Language Class Initialized
INFO - 2024-08-03 14:42:50 --> Config Class Initialized
INFO - 2024-08-03 14:42:50 --> Loader Class Initialized
INFO - 2024-08-03 14:42:50 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:50 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:50 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:50 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:50 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:50 --> Config Class Initialized
INFO - 2024-08-03 14:42:50 --> Hooks Class Initialized
DEBUG - 2024-08-03 14:42:50 --> UTF-8 Support Enabled
INFO - 2024-08-03 14:42:50 --> Utf8 Class Initialized
INFO - 2024-08-03 14:42:50 --> URI Class Initialized
INFO - 2024-08-03 14:42:50 --> Router Class Initialized
INFO - 2024-08-03 14:42:50 --> Output Class Initialized
INFO - 2024-08-03 14:42:50 --> Security Class Initialized
DEBUG - 2024-08-03 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-03 14:42:50 --> Input Class Initialized
INFO - 2024-08-03 14:42:50 --> Language Class Initialized
INFO - 2024-08-03 14:42:50 --> Language Class Initialized
INFO - 2024-08-03 14:42:50 --> Config Class Initialized
INFO - 2024-08-03 14:42:50 --> Loader Class Initialized
INFO - 2024-08-03 14:42:50 --> Helper loaded: url_helper
INFO - 2024-08-03 14:42:50 --> Helper loaded: file_helper
INFO - 2024-08-03 14:42:50 --> Helper loaded: form_helper
INFO - 2024-08-03 14:42:50 --> Helper loaded: my_helper
INFO - 2024-08-03 14:42:50 --> Database Driver Class Initialized
INFO - 2024-08-03 14:42:51 --> Final output sent to browser
DEBUG - 2024-08-03 14:42:51 --> Total execution time: 3.2501
INFO - 2024-08-03 14:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:51 --> Controller Class Initialized
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-03 14:42:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-03 14:42:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-03 14:42:53 --> Final output sent to browser
DEBUG - 2024-08-03 14:42:53 --> Total execution time: 4.8998
INFO - 2024-08-03 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:53 --> Controller Class Initialized
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-03 14:42:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-03 14:42:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-03 14:42:56 --> Final output sent to browser
DEBUG - 2024-08-03 14:42:56 --> Total execution time: 6.1959
INFO - 2024-08-03 14:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-03 14:42:56 --> Controller Class Initialized
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-03 14:42:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-03 14:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-03 14:42:58 --> Final output sent to browser
DEBUG - 2024-08-03 14:42:58 --> Total execution time: 7.7784
