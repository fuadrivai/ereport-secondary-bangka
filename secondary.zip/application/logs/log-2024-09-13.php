<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-13 12:02:57 --> Config Class Initialized
INFO - 2024-09-13 12:02:57 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:02:57 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:02:57 --> Utf8 Class Initialized
INFO - 2024-09-13 12:02:57 --> URI Class Initialized
INFO - 2024-09-13 12:02:57 --> Router Class Initialized
INFO - 2024-09-13 12:02:57 --> Output Class Initialized
INFO - 2024-09-13 12:02:57 --> Security Class Initialized
DEBUG - 2024-09-13 12:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:02:57 --> Input Class Initialized
INFO - 2024-09-13 12:02:57 --> Language Class Initialized
INFO - 2024-09-13 12:02:57 --> Language Class Initialized
INFO - 2024-09-13 12:02:57 --> Config Class Initialized
INFO - 2024-09-13 12:02:57 --> Loader Class Initialized
INFO - 2024-09-13 12:02:57 --> Helper loaded: url_helper
INFO - 2024-09-13 12:02:57 --> Helper loaded: file_helper
INFO - 2024-09-13 12:02:57 --> Helper loaded: form_helper
INFO - 2024-09-13 12:02:57 --> Helper loaded: my_helper
INFO - 2024-09-13 12:02:57 --> Database Driver Class Initialized
INFO - 2024-09-13 12:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:02:57 --> Controller Class Initialized
INFO - 2024-09-13 12:02:58 --> Helper loaded: cookie_helper
INFO - 2024-09-13 12:02:58 --> Final output sent to browser
DEBUG - 2024-09-13 12:02:58 --> Total execution time: 0.0722
INFO - 2024-09-13 12:03:00 --> Config Class Initialized
INFO - 2024-09-13 12:03:00 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:03:00 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:03:00 --> Utf8 Class Initialized
INFO - 2024-09-13 12:03:00 --> URI Class Initialized
INFO - 2024-09-13 12:03:00 --> Router Class Initialized
INFO - 2024-09-13 12:03:00 --> Output Class Initialized
INFO - 2024-09-13 12:03:00 --> Security Class Initialized
DEBUG - 2024-09-13 12:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:03:00 --> Input Class Initialized
INFO - 2024-09-13 12:03:00 --> Language Class Initialized
INFO - 2024-09-13 12:03:00 --> Language Class Initialized
INFO - 2024-09-13 12:03:00 --> Config Class Initialized
INFO - 2024-09-13 12:03:00 --> Loader Class Initialized
INFO - 2024-09-13 12:03:00 --> Helper loaded: url_helper
INFO - 2024-09-13 12:03:00 --> Helper loaded: file_helper
INFO - 2024-09-13 12:03:00 --> Helper loaded: form_helper
INFO - 2024-09-13 12:03:00 --> Helper loaded: my_helper
INFO - 2024-09-13 12:03:00 --> Database Driver Class Initialized
INFO - 2024-09-13 12:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:03:00 --> Controller Class Initialized
INFO - 2024-09-13 12:03:00 --> Helper loaded: cookie_helper
INFO - 2024-09-13 12:03:00 --> Config Class Initialized
INFO - 2024-09-13 12:03:00 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:03:00 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:03:00 --> Utf8 Class Initialized
INFO - 2024-09-13 12:03:00 --> URI Class Initialized
INFO - 2024-09-13 12:03:00 --> Router Class Initialized
INFO - 2024-09-13 12:03:00 --> Output Class Initialized
INFO - 2024-09-13 12:03:00 --> Security Class Initialized
DEBUG - 2024-09-13 12:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:03:00 --> Input Class Initialized
INFO - 2024-09-13 12:03:00 --> Language Class Initialized
INFO - 2024-09-13 12:03:00 --> Language Class Initialized
INFO - 2024-09-13 12:03:00 --> Config Class Initialized
INFO - 2024-09-13 12:03:00 --> Loader Class Initialized
INFO - 2024-09-13 12:03:00 --> Helper loaded: url_helper
INFO - 2024-09-13 12:03:00 --> Helper loaded: file_helper
INFO - 2024-09-13 12:03:00 --> Helper loaded: form_helper
INFO - 2024-09-13 12:03:00 --> Helper loaded: my_helper
INFO - 2024-09-13 12:03:00 --> Database Driver Class Initialized
INFO - 2024-09-13 12:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:03:00 --> Controller Class Initialized
DEBUG - 2024-09-13 12:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-13 12:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-13 12:03:00 --> Final output sent to browser
DEBUG - 2024-09-13 12:03:00 --> Total execution time: 0.0422
INFO - 2024-09-13 12:03:09 --> Config Class Initialized
INFO - 2024-09-13 12:03:09 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:03:09 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:03:09 --> Utf8 Class Initialized
INFO - 2024-09-13 12:03:09 --> URI Class Initialized
INFO - 2024-09-13 12:03:09 --> Router Class Initialized
INFO - 2024-09-13 12:03:09 --> Output Class Initialized
INFO - 2024-09-13 12:03:09 --> Security Class Initialized
DEBUG - 2024-09-13 12:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:03:09 --> Input Class Initialized
INFO - 2024-09-13 12:03:09 --> Language Class Initialized
INFO - 2024-09-13 12:03:09 --> Language Class Initialized
INFO - 2024-09-13 12:03:09 --> Config Class Initialized
INFO - 2024-09-13 12:03:09 --> Loader Class Initialized
INFO - 2024-09-13 12:03:09 --> Helper loaded: url_helper
INFO - 2024-09-13 12:03:09 --> Helper loaded: file_helper
INFO - 2024-09-13 12:03:09 --> Helper loaded: form_helper
INFO - 2024-09-13 12:03:09 --> Helper loaded: my_helper
INFO - 2024-09-13 12:03:09 --> Database Driver Class Initialized
INFO - 2024-09-13 12:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:03:09 --> Controller Class Initialized
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-13 12:03:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-13 12:03:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-13 12:03:14 --> Final output sent to browser
DEBUG - 2024-09-13 12:03:14 --> Total execution time: 4.8044
INFO - 2024-09-13 12:03:14 --> Config Class Initialized
INFO - 2024-09-13 12:03:14 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:03:14 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:03:14 --> Utf8 Class Initialized
INFO - 2024-09-13 12:03:14 --> URI Class Initialized
INFO - 2024-09-13 12:03:14 --> Router Class Initialized
INFO - 2024-09-13 12:03:14 --> Output Class Initialized
INFO - 2024-09-13 12:03:14 --> Security Class Initialized
DEBUG - 2024-09-13 12:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:03:14 --> Input Class Initialized
INFO - 2024-09-13 12:03:14 --> Language Class Initialized
INFO - 2024-09-13 12:03:14 --> Language Class Initialized
INFO - 2024-09-13 12:03:14 --> Config Class Initialized
INFO - 2024-09-13 12:03:14 --> Loader Class Initialized
INFO - 2024-09-13 12:03:14 --> Helper loaded: url_helper
INFO - 2024-09-13 12:03:14 --> Helper loaded: file_helper
INFO - 2024-09-13 12:03:14 --> Helper loaded: form_helper
INFO - 2024-09-13 12:03:14 --> Helper loaded: my_helper
INFO - 2024-09-13 12:03:14 --> Database Driver Class Initialized
INFO - 2024-09-13 12:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:03:14 --> Controller Class Initialized
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-13 12:03:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-13 12:03:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-13 12:03:18 --> Final output sent to browser
DEBUG - 2024-09-13 12:03:18 --> Total execution time: 3.9883
INFO - 2024-09-13 12:03:18 --> Config Class Initialized
INFO - 2024-09-13 12:03:18 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:03:18 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:03:18 --> Utf8 Class Initialized
INFO - 2024-09-13 12:03:18 --> URI Class Initialized
INFO - 2024-09-13 12:03:18 --> Router Class Initialized
INFO - 2024-09-13 12:03:18 --> Output Class Initialized
INFO - 2024-09-13 12:03:18 --> Security Class Initialized
DEBUG - 2024-09-13 12:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:03:18 --> Input Class Initialized
INFO - 2024-09-13 12:03:18 --> Language Class Initialized
INFO - 2024-09-13 12:03:18 --> Language Class Initialized
INFO - 2024-09-13 12:03:18 --> Config Class Initialized
INFO - 2024-09-13 12:03:18 --> Loader Class Initialized
INFO - 2024-09-13 12:03:18 --> Helper loaded: url_helper
INFO - 2024-09-13 12:03:18 --> Helper loaded: file_helper
INFO - 2024-09-13 12:03:18 --> Helper loaded: form_helper
INFO - 2024-09-13 12:03:18 --> Helper loaded: my_helper
INFO - 2024-09-13 12:03:18 --> Database Driver Class Initialized
INFO - 2024-09-13 12:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:03:18 --> Controller Class Initialized
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-13 12:03:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-13 12:03:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-13 12:03:23 --> Final output sent to browser
DEBUG - 2024-09-13 12:03:23 --> Total execution time: 4.6450
INFO - 2024-09-13 15:38:58 --> Config Class Initialized
INFO - 2024-09-13 15:38:58 --> Hooks Class Initialized
DEBUG - 2024-09-13 15:38:58 --> UTF-8 Support Enabled
INFO - 2024-09-13 15:38:58 --> Utf8 Class Initialized
INFO - 2024-09-13 15:38:58 --> URI Class Initialized
INFO - 2024-09-13 15:38:58 --> Router Class Initialized
INFO - 2024-09-13 15:38:58 --> Output Class Initialized
INFO - 2024-09-13 15:38:58 --> Security Class Initialized
DEBUG - 2024-09-13 15:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 15:38:58 --> Input Class Initialized
INFO - 2024-09-13 15:38:58 --> Language Class Initialized
INFO - 2024-09-13 15:38:58 --> Language Class Initialized
INFO - 2024-09-13 15:38:58 --> Config Class Initialized
INFO - 2024-09-13 15:38:58 --> Loader Class Initialized
INFO - 2024-09-13 15:38:58 --> Helper loaded: url_helper
INFO - 2024-09-13 15:38:58 --> Helper loaded: file_helper
INFO - 2024-09-13 15:38:58 --> Helper loaded: form_helper
INFO - 2024-09-13 15:38:58 --> Helper loaded: my_helper
INFO - 2024-09-13 15:38:58 --> Database Driver Class Initialized
INFO - 2024-09-13 15:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 15:38:58 --> Controller Class Initialized
INFO - 2024-09-13 15:38:58 --> Helper loaded: cookie_helper
INFO - 2024-09-13 15:38:58 --> Final output sent to browser
DEBUG - 2024-09-13 15:38:58 --> Total execution time: 0.0733
INFO - 2024-09-13 15:38:59 --> Config Class Initialized
INFO - 2024-09-13 15:38:59 --> Hooks Class Initialized
DEBUG - 2024-09-13 15:38:59 --> UTF-8 Support Enabled
INFO - 2024-09-13 15:38:59 --> Utf8 Class Initialized
INFO - 2024-09-13 15:38:59 --> URI Class Initialized
INFO - 2024-09-13 15:38:59 --> Router Class Initialized
INFO - 2024-09-13 15:38:59 --> Output Class Initialized
INFO - 2024-09-13 15:38:59 --> Security Class Initialized
DEBUG - 2024-09-13 15:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 15:38:59 --> Input Class Initialized
INFO - 2024-09-13 15:38:59 --> Language Class Initialized
INFO - 2024-09-13 15:38:59 --> Language Class Initialized
INFO - 2024-09-13 15:38:59 --> Config Class Initialized
INFO - 2024-09-13 15:38:59 --> Loader Class Initialized
INFO - 2024-09-13 15:38:59 --> Helper loaded: url_helper
INFO - 2024-09-13 15:38:59 --> Helper loaded: file_helper
INFO - 2024-09-13 15:38:59 --> Helper loaded: form_helper
INFO - 2024-09-13 15:38:59 --> Helper loaded: my_helper
INFO - 2024-09-13 15:38:59 --> Database Driver Class Initialized
INFO - 2024-09-13 15:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 15:38:59 --> Controller Class Initialized
INFO - 2024-09-13 15:38:59 --> Helper loaded: cookie_helper
INFO - 2024-09-13 15:38:59 --> Config Class Initialized
INFO - 2024-09-13 15:38:59 --> Hooks Class Initialized
DEBUG - 2024-09-13 15:38:59 --> UTF-8 Support Enabled
INFO - 2024-09-13 15:38:59 --> Utf8 Class Initialized
INFO - 2024-09-13 15:38:59 --> URI Class Initialized
INFO - 2024-09-13 15:38:59 --> Router Class Initialized
INFO - 2024-09-13 15:38:59 --> Output Class Initialized
INFO - 2024-09-13 15:38:59 --> Security Class Initialized
DEBUG - 2024-09-13 15:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 15:38:59 --> Input Class Initialized
INFO - 2024-09-13 15:38:59 --> Language Class Initialized
INFO - 2024-09-13 15:38:59 --> Language Class Initialized
INFO - 2024-09-13 15:38:59 --> Config Class Initialized
INFO - 2024-09-13 15:38:59 --> Loader Class Initialized
INFO - 2024-09-13 15:38:59 --> Helper loaded: url_helper
INFO - 2024-09-13 15:38:59 --> Helper loaded: file_helper
INFO - 2024-09-13 15:38:59 --> Helper loaded: form_helper
INFO - 2024-09-13 15:38:59 --> Helper loaded: my_helper
INFO - 2024-09-13 15:38:59 --> Database Driver Class Initialized
INFO - 2024-09-13 15:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 15:38:59 --> Controller Class Initialized
DEBUG - 2024-09-13 15:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-13 15:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-13 15:38:59 --> Final output sent to browser
DEBUG - 2024-09-13 15:38:59 --> Total execution time: 0.0383
INFO - 2024-09-13 15:39:11 --> Config Class Initialized
INFO - 2024-09-13 15:39:11 --> Hooks Class Initialized
DEBUG - 2024-09-13 15:39:11 --> UTF-8 Support Enabled
INFO - 2024-09-13 15:39:11 --> Utf8 Class Initialized
INFO - 2024-09-13 15:39:11 --> URI Class Initialized
INFO - 2024-09-13 15:39:11 --> Router Class Initialized
INFO - 2024-09-13 15:39:11 --> Output Class Initialized
INFO - 2024-09-13 15:39:11 --> Security Class Initialized
DEBUG - 2024-09-13 15:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 15:39:11 --> Input Class Initialized
INFO - 2024-09-13 15:39:11 --> Language Class Initialized
INFO - 2024-09-13 15:39:11 --> Language Class Initialized
INFO - 2024-09-13 15:39:11 --> Config Class Initialized
INFO - 2024-09-13 15:39:11 --> Loader Class Initialized
INFO - 2024-09-13 15:39:11 --> Helper loaded: url_helper
INFO - 2024-09-13 15:39:11 --> Helper loaded: file_helper
INFO - 2024-09-13 15:39:11 --> Helper loaded: form_helper
INFO - 2024-09-13 15:39:11 --> Helper loaded: my_helper
INFO - 2024-09-13 15:39:11 --> Database Driver Class Initialized
INFO - 2024-09-13 15:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 15:39:11 --> Controller Class Initialized
DEBUG - 2024-09-13 15:39:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-13 15:39:14 --> Final output sent to browser
DEBUG - 2024-09-13 15:39:14 --> Total execution time: 3.5211
INFO - 2024-09-13 15:59:43 --> Config Class Initialized
INFO - 2024-09-13 15:59:43 --> Hooks Class Initialized
DEBUG - 2024-09-13 15:59:43 --> UTF-8 Support Enabled
INFO - 2024-09-13 15:59:43 --> Utf8 Class Initialized
INFO - 2024-09-13 15:59:43 --> URI Class Initialized
INFO - 2024-09-13 15:59:43 --> Router Class Initialized
INFO - 2024-09-13 15:59:43 --> Output Class Initialized
INFO - 2024-09-13 15:59:43 --> Security Class Initialized
DEBUG - 2024-09-13 15:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 15:59:43 --> Input Class Initialized
INFO - 2024-09-13 15:59:43 --> Language Class Initialized
INFO - 2024-09-13 15:59:43 --> Language Class Initialized
INFO - 2024-09-13 15:59:43 --> Config Class Initialized
INFO - 2024-09-13 15:59:43 --> Loader Class Initialized
INFO - 2024-09-13 15:59:43 --> Helper loaded: url_helper
INFO - 2024-09-13 15:59:43 --> Helper loaded: file_helper
INFO - 2024-09-13 15:59:43 --> Helper loaded: form_helper
INFO - 2024-09-13 15:59:43 --> Helper loaded: my_helper
INFO - 2024-09-13 15:59:43 --> Database Driver Class Initialized
INFO - 2024-09-13 15:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 15:59:43 --> Controller Class Initialized
DEBUG - 2024-09-13 15:59:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-13 15:59:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-13 15:59:43 --> Final output sent to browser
DEBUG - 2024-09-13 15:59:43 --> Total execution time: 0.0568
