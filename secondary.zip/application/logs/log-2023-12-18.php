<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-18 08:00:57 --> Config Class Initialized
INFO - 2023-12-18 08:00:57 --> Hooks Class Initialized
DEBUG - 2023-12-18 08:00:57 --> UTF-8 Support Enabled
INFO - 2023-12-18 08:00:57 --> Utf8 Class Initialized
INFO - 2023-12-18 08:00:57 --> URI Class Initialized
INFO - 2023-12-18 08:00:57 --> Router Class Initialized
INFO - 2023-12-18 08:00:57 --> Output Class Initialized
INFO - 2023-12-18 08:00:57 --> Security Class Initialized
DEBUG - 2023-12-18 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 08:00:57 --> Input Class Initialized
INFO - 2023-12-18 08:00:57 --> Language Class Initialized
INFO - 2023-12-18 08:00:57 --> Language Class Initialized
INFO - 2023-12-18 08:00:57 --> Config Class Initialized
INFO - 2023-12-18 08:00:57 --> Loader Class Initialized
INFO - 2023-12-18 08:00:57 --> Helper loaded: url_helper
INFO - 2023-12-18 08:00:57 --> Helper loaded: file_helper
INFO - 2023-12-18 08:00:57 --> Helper loaded: form_helper
INFO - 2023-12-18 08:00:57 --> Helper loaded: my_helper
INFO - 2023-12-18 08:00:57 --> Database Driver Class Initialized
INFO - 2023-12-18 08:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 08:00:57 --> Controller Class Initialized
DEBUG - 2023-12-18 08:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-18 08:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-18 08:00:57 --> Final output sent to browser
DEBUG - 2023-12-18 08:00:57 --> Total execution time: 0.0754
INFO - 2023-12-18 19:20:52 --> Config Class Initialized
INFO - 2023-12-18 19:20:52 --> Hooks Class Initialized
INFO - 2023-12-18 19:20:52 --> Config Class Initialized
INFO - 2023-12-18 19:20:52 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:20:52 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:20:52 --> Utf8 Class Initialized
DEBUG - 2023-12-18 19:20:52 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:20:52 --> Utf8 Class Initialized
INFO - 2023-12-18 19:20:52 --> URI Class Initialized
INFO - 2023-12-18 19:20:52 --> URI Class Initialized
INFO - 2023-12-18 19:20:52 --> Router Class Initialized
INFO - 2023-12-18 19:20:52 --> Router Class Initialized
INFO - 2023-12-18 19:20:52 --> Output Class Initialized
INFO - 2023-12-18 19:20:52 --> Output Class Initialized
INFO - 2023-12-18 19:20:52 --> Security Class Initialized
INFO - 2023-12-18 19:20:52 --> Security Class Initialized
DEBUG - 2023-12-18 19:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:20:52 --> Input Class Initialized
DEBUG - 2023-12-18 19:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:20:52 --> Input Class Initialized
INFO - 2023-12-18 19:20:52 --> Language Class Initialized
INFO - 2023-12-18 19:20:52 --> Language Class Initialized
INFO - 2023-12-18 19:20:52 --> Language Class Initialized
INFO - 2023-12-18 19:20:52 --> Config Class Initialized
INFO - 2023-12-18 19:20:52 --> Loader Class Initialized
INFO - 2023-12-18 19:20:52 --> Language Class Initialized
INFO - 2023-12-18 19:20:52 --> Config Class Initialized
INFO - 2023-12-18 19:20:52 --> Loader Class Initialized
INFO - 2023-12-18 19:20:52 --> Helper loaded: url_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: url_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: file_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: file_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: form_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: form_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: my_helper
INFO - 2023-12-18 19:20:52 --> Helper loaded: my_helper
INFO - 2023-12-18 19:20:52 --> Database Driver Class Initialized
INFO - 2023-12-18 19:20:52 --> Database Driver Class Initialized
INFO - 2023-12-18 19:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:20:52 --> Controller Class Initialized
INFO - 2023-12-18 19:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:20:52 --> Controller Class Initialized
INFO - 2023-12-18 19:20:53 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:20:53 --> Final output sent to browser
DEBUG - 2023-12-18 19:20:53 --> Total execution time: 0.8082
INFO - 2023-12-18 19:20:53 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:20:53 --> Final output sent to browser
DEBUG - 2023-12-18 19:20:53 --> Total execution time: 0.8104
INFO - 2023-12-18 19:20:53 --> Config Class Initialized
INFO - 2023-12-18 19:20:53 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:20:53 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:20:53 --> Utf8 Class Initialized
INFO - 2023-12-18 19:20:53 --> URI Class Initialized
INFO - 2023-12-18 19:20:53 --> Router Class Initialized
INFO - 2023-12-18 19:20:53 --> Output Class Initialized
INFO - 2023-12-18 19:20:53 --> Security Class Initialized
DEBUG - 2023-12-18 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:20:53 --> Input Class Initialized
INFO - 2023-12-18 19:20:53 --> Language Class Initialized
INFO - 2023-12-18 19:20:53 --> Language Class Initialized
INFO - 2023-12-18 19:20:53 --> Config Class Initialized
INFO - 2023-12-18 19:20:53 --> Loader Class Initialized
INFO - 2023-12-18 19:20:53 --> Helper loaded: url_helper
INFO - 2023-12-18 19:20:53 --> Helper loaded: file_helper
INFO - 2023-12-18 19:20:53 --> Helper loaded: form_helper
INFO - 2023-12-18 19:20:53 --> Helper loaded: my_helper
INFO - 2023-12-18 19:20:53 --> Database Driver Class Initialized
INFO - 2023-12-18 19:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:20:53 --> Controller Class Initialized
INFO - 2023-12-18 19:20:53 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:20:54 --> Config Class Initialized
INFO - 2023-12-18 19:20:54 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:20:54 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:20:54 --> Utf8 Class Initialized
INFO - 2023-12-18 19:20:54 --> URI Class Initialized
INFO - 2023-12-18 19:20:54 --> Config Class Initialized
INFO - 2023-12-18 19:20:54 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:20:54 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:20:54 --> Utf8 Class Initialized
INFO - 2023-12-18 19:20:54 --> URI Class Initialized
INFO - 2023-12-18 19:20:54 --> Router Class Initialized
INFO - 2023-12-18 19:20:54 --> Output Class Initialized
INFO - 2023-12-18 19:20:54 --> Security Class Initialized
DEBUG - 2023-12-18 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:20:54 --> Input Class Initialized
INFO - 2023-12-18 19:20:54 --> Language Class Initialized
INFO - 2023-12-18 19:20:54 --> Router Class Initialized
INFO - 2023-12-18 19:20:54 --> Output Class Initialized
INFO - 2023-12-18 19:20:54 --> Security Class Initialized
DEBUG - 2023-12-18 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:20:54 --> Input Class Initialized
INFO - 2023-12-18 19:20:54 --> Language Class Initialized
INFO - 2023-12-18 19:20:54 --> Language Class Initialized
INFO - 2023-12-18 19:20:54 --> Config Class Initialized
INFO - 2023-12-18 19:20:54 --> Loader Class Initialized
INFO - 2023-12-18 19:20:54 --> Helper loaded: url_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: file_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: form_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: my_helper
INFO - 2023-12-18 19:20:54 --> Language Class Initialized
INFO - 2023-12-18 19:20:54 --> Config Class Initialized
INFO - 2023-12-18 19:20:54 --> Loader Class Initialized
INFO - 2023-12-18 19:20:54 --> Database Driver Class Initialized
INFO - 2023-12-18 19:20:54 --> Helper loaded: url_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: file_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: form_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: my_helper
INFO - 2023-12-18 19:20:54 --> Database Driver Class Initialized
INFO - 2023-12-18 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:20:54 --> Controller Class Initialized
INFO - 2023-12-18 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:20:54 --> Controller Class Initialized
INFO - 2023-12-18 19:20:54 --> Helper loaded: cookie_helper
DEBUG - 2023-12-18 19:20:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-18 19:20:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-18 19:20:54 --> Final output sent to browser
DEBUG - 2023-12-18 19:20:54 --> Total execution time: 0.1496
INFO - 2023-12-18 19:20:54 --> Config Class Initialized
INFO - 2023-12-18 19:20:54 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:20:54 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:20:54 --> Utf8 Class Initialized
INFO - 2023-12-18 19:20:54 --> URI Class Initialized
INFO - 2023-12-18 19:20:54 --> Router Class Initialized
INFO - 2023-12-18 19:20:54 --> Output Class Initialized
INFO - 2023-12-18 19:20:54 --> Security Class Initialized
DEBUG - 2023-12-18 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:20:54 --> Input Class Initialized
INFO - 2023-12-18 19:20:54 --> Language Class Initialized
INFO - 2023-12-18 19:20:54 --> Language Class Initialized
INFO - 2023-12-18 19:20:54 --> Config Class Initialized
INFO - 2023-12-18 19:20:54 --> Loader Class Initialized
INFO - 2023-12-18 19:20:54 --> Helper loaded: url_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: file_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: form_helper
INFO - 2023-12-18 19:20:54 --> Helper loaded: my_helper
INFO - 2023-12-18 19:20:54 --> Database Driver Class Initialized
INFO - 2023-12-18 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:20:54 --> Controller Class Initialized
DEBUG - 2023-12-18 19:20:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-18 19:20:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-18 19:20:54 --> Final output sent to browser
DEBUG - 2023-12-18 19:20:54 --> Total execution time: 0.1830
INFO - 2023-12-18 19:21:11 --> Config Class Initialized
INFO - 2023-12-18 19:21:11 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:11 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:11 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:11 --> URI Class Initialized
INFO - 2023-12-18 19:21:11 --> Router Class Initialized
INFO - 2023-12-18 19:21:11 --> Output Class Initialized
INFO - 2023-12-18 19:21:11 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:11 --> Input Class Initialized
INFO - 2023-12-18 19:21:11 --> Language Class Initialized
INFO - 2023-12-18 19:21:11 --> Language Class Initialized
INFO - 2023-12-18 19:21:11 --> Config Class Initialized
INFO - 2023-12-18 19:21:11 --> Loader Class Initialized
INFO - 2023-12-18 19:21:11 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:11 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:11 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:11 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:11 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:11 --> Controller Class Initialized
INFO - 2023-12-18 19:21:11 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:21:11 --> Final output sent to browser
DEBUG - 2023-12-18 19:21:11 --> Total execution time: 0.0606
INFO - 2023-12-18 19:21:12 --> Config Class Initialized
INFO - 2023-12-18 19:21:12 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:12 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:12 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:12 --> URI Class Initialized
INFO - 2023-12-18 19:21:12 --> Router Class Initialized
INFO - 2023-12-18 19:21:12 --> Output Class Initialized
INFO - 2023-12-18 19:21:12 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:12 --> Input Class Initialized
INFO - 2023-12-18 19:21:12 --> Language Class Initialized
INFO - 2023-12-18 19:21:12 --> Language Class Initialized
INFO - 2023-12-18 19:21:12 --> Config Class Initialized
INFO - 2023-12-18 19:21:12 --> Loader Class Initialized
INFO - 2023-12-18 19:21:12 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:12 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:12 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:12 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:12 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:12 --> Controller Class Initialized
INFO - 2023-12-18 19:21:12 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:21:12 --> Config Class Initialized
INFO - 2023-12-18 19:21:12 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:12 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:12 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:12 --> URI Class Initialized
INFO - 2023-12-18 19:21:12 --> Router Class Initialized
INFO - 2023-12-18 19:21:12 --> Output Class Initialized
INFO - 2023-12-18 19:21:12 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:12 --> Input Class Initialized
INFO - 2023-12-18 19:21:12 --> Language Class Initialized
INFO - 2023-12-18 19:21:12 --> Language Class Initialized
INFO - 2023-12-18 19:21:12 --> Config Class Initialized
INFO - 2023-12-18 19:21:12 --> Loader Class Initialized
INFO - 2023-12-18 19:21:12 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:12 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:12 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:12 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:12 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:12 --> Controller Class Initialized
DEBUG - 2023-12-18 19:21:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-18 19:21:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-18 19:21:12 --> Final output sent to browser
DEBUG - 2023-12-18 19:21:12 --> Total execution time: 0.0730
INFO - 2023-12-18 19:21:20 --> Config Class Initialized
INFO - 2023-12-18 19:21:20 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:20 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:20 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:20 --> URI Class Initialized
INFO - 2023-12-18 19:21:20 --> Router Class Initialized
INFO - 2023-12-18 19:21:20 --> Output Class Initialized
INFO - 2023-12-18 19:21:20 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:20 --> Input Class Initialized
INFO - 2023-12-18 19:21:20 --> Language Class Initialized
INFO - 2023-12-18 19:21:20 --> Language Class Initialized
INFO - 2023-12-18 19:21:20 --> Config Class Initialized
INFO - 2023-12-18 19:21:20 --> Loader Class Initialized
INFO - 2023-12-18 19:21:20 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:20 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:20 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:20 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:20 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:20 --> Controller Class Initialized
DEBUG - 2023-12-18 19:21:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:21:25 --> Final output sent to browser
DEBUG - 2023-12-18 19:21:25 --> Total execution time: 4.5527
INFO - 2023-12-18 19:21:25 --> Config Class Initialized
INFO - 2023-12-18 19:21:25 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:25 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:25 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:25 --> URI Class Initialized
INFO - 2023-12-18 19:21:25 --> Router Class Initialized
INFO - 2023-12-18 19:21:25 --> Output Class Initialized
INFO - 2023-12-18 19:21:25 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:25 --> Input Class Initialized
INFO - 2023-12-18 19:21:25 --> Language Class Initialized
INFO - 2023-12-18 19:21:25 --> Language Class Initialized
INFO - 2023-12-18 19:21:25 --> Config Class Initialized
INFO - 2023-12-18 19:21:25 --> Loader Class Initialized
INFO - 2023-12-18 19:21:25 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:25 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:25 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:25 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:25 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:25 --> Controller Class Initialized
DEBUG - 2023-12-18 19:21:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:21:27 --> Config Class Initialized
INFO - 2023-12-18 19:21:27 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:27 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:27 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:27 --> URI Class Initialized
INFO - 2023-12-18 19:21:27 --> Router Class Initialized
INFO - 2023-12-18 19:21:27 --> Output Class Initialized
INFO - 2023-12-18 19:21:27 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:27 --> Input Class Initialized
INFO - 2023-12-18 19:21:27 --> Language Class Initialized
INFO - 2023-12-18 19:21:27 --> Language Class Initialized
INFO - 2023-12-18 19:21:27 --> Config Class Initialized
INFO - 2023-12-18 19:21:27 --> Loader Class Initialized
INFO - 2023-12-18 19:21:27 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:27 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:27 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:27 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:27 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:27 --> Controller Class Initialized
DEBUG - 2023-12-18 19:21:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:21:34 --> Final output sent to browser
DEBUG - 2023-12-18 19:21:34 --> Total execution time: 9.1234
INFO - 2023-12-18 19:21:36 --> Final output sent to browser
DEBUG - 2023-12-18 19:21:36 --> Total execution time: 9.1335
INFO - 2023-12-18 19:21:36 --> Config Class Initialized
INFO - 2023-12-18 19:21:36 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:36 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:36 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:36 --> URI Class Initialized
INFO - 2023-12-18 19:21:36 --> Router Class Initialized
INFO - 2023-12-18 19:21:36 --> Output Class Initialized
INFO - 2023-12-18 19:21:36 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:36 --> Input Class Initialized
INFO - 2023-12-18 19:21:36 --> Language Class Initialized
INFO - 2023-12-18 19:21:36 --> Language Class Initialized
INFO - 2023-12-18 19:21:36 --> Config Class Initialized
INFO - 2023-12-18 19:21:36 --> Loader Class Initialized
INFO - 2023-12-18 19:21:37 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:37 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:37 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:37 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:37 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:37 --> Controller Class Initialized
DEBUG - 2023-12-18 19:21:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:21:42 --> Final output sent to browser
DEBUG - 2023-12-18 19:21:42 --> Total execution time: 5.5765
INFO - 2023-12-18 19:21:53 --> Config Class Initialized
INFO - 2023-12-18 19:21:53 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:53 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:53 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:53 --> URI Class Initialized
INFO - 2023-12-18 19:21:53 --> Config Class Initialized
INFO - 2023-12-18 19:21:53 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:21:53 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:21:53 --> Utf8 Class Initialized
INFO - 2023-12-18 19:21:53 --> Router Class Initialized
INFO - 2023-12-18 19:21:53 --> Output Class Initialized
INFO - 2023-12-18 19:21:53 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:53 --> Input Class Initialized
INFO - 2023-12-18 19:21:53 --> Language Class Initialized
INFO - 2023-12-18 19:21:53 --> URI Class Initialized
INFO - 2023-12-18 19:21:53 --> Language Class Initialized
INFO - 2023-12-18 19:21:53 --> Config Class Initialized
INFO - 2023-12-18 19:21:53 --> Loader Class Initialized
INFO - 2023-12-18 19:21:53 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:53 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:53 --> Router Class Initialized
INFO - 2023-12-18 19:21:53 --> Output Class Initialized
INFO - 2023-12-18 19:21:53 --> Security Class Initialized
DEBUG - 2023-12-18 19:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:21:53 --> Input Class Initialized
INFO - 2023-12-18 19:21:53 --> Language Class Initialized
INFO - 2023-12-18 19:21:53 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:53 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:53 --> Language Class Initialized
INFO - 2023-12-18 19:21:53 --> Config Class Initialized
INFO - 2023-12-18 19:21:53 --> Loader Class Initialized
INFO - 2023-12-18 19:21:53 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:53 --> Helper loaded: url_helper
INFO - 2023-12-18 19:21:53 --> Helper loaded: file_helper
INFO - 2023-12-18 19:21:53 --> Helper loaded: form_helper
INFO - 2023-12-18 19:21:53 --> Helper loaded: my_helper
INFO - 2023-12-18 19:21:53 --> Database Driver Class Initialized
INFO - 2023-12-18 19:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:21:53 --> Controller Class Initialized
DEBUG - 2023-12-18 19:21:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:22:04 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:04 --> Total execution time: 11.1053
INFO - 2023-12-18 19:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:04 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:22:05 --> Config Class Initialized
INFO - 2023-12-18 19:22:05 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:05 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:05 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:05 --> URI Class Initialized
INFO - 2023-12-18 19:22:05 --> Router Class Initialized
INFO - 2023-12-18 19:22:05 --> Output Class Initialized
INFO - 2023-12-18 19:22:05 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:05 --> Input Class Initialized
INFO - 2023-12-18 19:22:05 --> Language Class Initialized
INFO - 2023-12-18 19:22:05 --> Language Class Initialized
INFO - 2023-12-18 19:22:05 --> Config Class Initialized
INFO - 2023-12-18 19:22:05 --> Loader Class Initialized
INFO - 2023-12-18 19:22:05 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:05 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:05 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:05 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:05 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:05 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:22:06 --> Config Class Initialized
INFO - 2023-12-18 19:22:06 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:06 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:06 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:06 --> URI Class Initialized
INFO - 2023-12-18 19:22:06 --> Router Class Initialized
INFO - 2023-12-18 19:22:06 --> Output Class Initialized
INFO - 2023-12-18 19:22:06 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:06 --> Input Class Initialized
INFO - 2023-12-18 19:22:06 --> Language Class Initialized
INFO - 2023-12-18 19:22:06 --> Language Class Initialized
INFO - 2023-12-18 19:22:06 --> Config Class Initialized
INFO - 2023-12-18 19:22:06 --> Loader Class Initialized
INFO - 2023-12-18 19:22:06 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:06 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:07 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:07 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:07 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:19 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:19 --> Total execution time: 14.2689
INFO - 2023-12-18 19:22:21 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:21 --> Total execution time: 28.0415
INFO - 2023-12-18 19:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:21 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:22:21 --> Config Class Initialized
INFO - 2023-12-18 19:22:21 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:21 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:21 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:21 --> URI Class Initialized
INFO - 2023-12-18 19:22:21 --> Router Class Initialized
INFO - 2023-12-18 19:22:22 --> Output Class Initialized
INFO - 2023-12-18 19:22:22 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:22 --> Input Class Initialized
INFO - 2023-12-18 19:22:22 --> Language Class Initialized
INFO - 2023-12-18 19:22:22 --> Language Class Initialized
INFO - 2023-12-18 19:22:22 --> Config Class Initialized
INFO - 2023-12-18 19:22:22 --> Loader Class Initialized
INFO - 2023-12-18 19:22:22 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:22 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:22 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:22 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:22 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:22 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:22:23 --> Config Class Initialized
INFO - 2023-12-18 19:22:23 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:23 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:23 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:23 --> URI Class Initialized
INFO - 2023-12-18 19:22:23 --> Router Class Initialized
INFO - 2023-12-18 19:22:23 --> Output Class Initialized
INFO - 2023-12-18 19:22:23 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:23 --> Input Class Initialized
INFO - 2023-12-18 19:22:23 --> Language Class Initialized
INFO - 2023-12-18 19:22:23 --> Language Class Initialized
INFO - 2023-12-18 19:22:23 --> Config Class Initialized
INFO - 2023-12-18 19:22:23 --> Loader Class Initialized
INFO - 2023-12-18 19:22:23 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:23 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:23 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:23 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:23 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:33 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:33 --> Total execution time: 27.3630
INFO - 2023-12-18 19:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:33 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:22:34 --> Config Class Initialized
INFO - 2023-12-18 19:22:34 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:34 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:34 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:34 --> URI Class Initialized
INFO - 2023-12-18 19:22:34 --> Router Class Initialized
INFO - 2023-12-18 19:22:34 --> Output Class Initialized
INFO - 2023-12-18 19:22:34 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:34 --> Input Class Initialized
INFO - 2023-12-18 19:22:34 --> Language Class Initialized
INFO - 2023-12-18 19:22:34 --> Language Class Initialized
INFO - 2023-12-18 19:22:34 --> Config Class Initialized
INFO - 2023-12-18 19:22:34 --> Loader Class Initialized
INFO - 2023-12-18 19:22:34 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:34 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:34 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:34 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:34 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:39 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:39 --> Total execution time: 18.0654
INFO - 2023-12-18 19:22:45 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:45 --> Total execution time: 22.2212
INFO - 2023-12-18 19:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:45 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-18 19:22:46 --> Config Class Initialized
INFO - 2023-12-18 19:22:46 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:46 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:46 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:46 --> URI Class Initialized
INFO - 2023-12-18 19:22:46 --> Router Class Initialized
INFO - 2023-12-18 19:22:46 --> Output Class Initialized
INFO - 2023-12-18 19:22:46 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:46 --> Input Class Initialized
INFO - 2023-12-18 19:22:46 --> Language Class Initialized
INFO - 2023-12-18 19:22:46 --> Language Class Initialized
INFO - 2023-12-18 19:22:46 --> Config Class Initialized
INFO - 2023-12-18 19:22:46 --> Loader Class Initialized
INFO - 2023-12-18 19:22:46 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:46 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:46 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:46 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:46 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:51 --> Config Class Initialized
INFO - 2023-12-18 19:22:51 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:22:51 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:22:51 --> Utf8 Class Initialized
INFO - 2023-12-18 19:22:51 --> URI Class Initialized
INFO - 2023-12-18 19:22:51 --> Router Class Initialized
INFO - 2023-12-18 19:22:51 --> Output Class Initialized
INFO - 2023-12-18 19:22:51 --> Security Class Initialized
DEBUG - 2023-12-18 19:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:22:51 --> Input Class Initialized
INFO - 2023-12-18 19:22:51 --> Language Class Initialized
INFO - 2023-12-18 19:22:51 --> Language Class Initialized
INFO - 2023-12-18 19:22:51 --> Config Class Initialized
INFO - 2023-12-18 19:22:51 --> Loader Class Initialized
INFO - 2023-12-18 19:22:51 --> Helper loaded: url_helper
INFO - 2023-12-18 19:22:51 --> Helper loaded: file_helper
INFO - 2023-12-18 19:22:51 --> Helper loaded: form_helper
INFO - 2023-12-18 19:22:51 --> Helper loaded: my_helper
INFO - 2023-12-18 19:22:51 --> Database Driver Class Initialized
INFO - 2023-12-18 19:22:57 --> Final output sent to browser
DEBUG - 2023-12-18 19:22:57 --> Total execution time: 22.9729
INFO - 2023-12-18 19:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:22:57 --> Controller Class Initialized
DEBUG - 2023-12-18 19:22:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:23:07 --> Config Class Initialized
INFO - 2023-12-18 19:23:07 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:07 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:07 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:07 --> URI Class Initialized
INFO - 2023-12-18 19:23:07 --> Router Class Initialized
INFO - 2023-12-18 19:23:07 --> Output Class Initialized
INFO - 2023-12-18 19:23:07 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:07 --> Input Class Initialized
INFO - 2023-12-18 19:23:07 --> Language Class Initialized
INFO - 2023-12-18 19:23:08 --> Language Class Initialized
INFO - 2023-12-18 19:23:08 --> Config Class Initialized
INFO - 2023-12-18 19:23:08 --> Loader Class Initialized
INFO - 2023-12-18 19:23:08 --> Final output sent to browser
DEBUG - 2023-12-18 19:23:08 --> Total execution time: 21.7746
INFO - 2023-12-18 19:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:08 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:08 --> Controller Class Initialized
INFO - 2023-12-18 19:23:08 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:08 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:08 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:08 --> Database Driver Class Initialized
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:23:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:23:10 --> Config Class Initialized
INFO - 2023-12-18 19:23:10 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:10 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:10 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:10 --> URI Class Initialized
INFO - 2023-12-18 19:23:10 --> Router Class Initialized
INFO - 2023-12-18 19:23:10 --> Output Class Initialized
INFO - 2023-12-18 19:23:10 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:10 --> Input Class Initialized
INFO - 2023-12-18 19:23:10 --> Language Class Initialized
INFO - 2023-12-18 19:23:10 --> Language Class Initialized
INFO - 2023-12-18 19:23:10 --> Config Class Initialized
INFO - 2023-12-18 19:23:10 --> Loader Class Initialized
INFO - 2023-12-18 19:23:10 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:10 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:10 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:10 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:10 --> Database Driver Class Initialized
INFO - 2023-12-18 19:23:14 --> Config Class Initialized
INFO - 2023-12-18 19:23:14 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:14 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:14 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:14 --> URI Class Initialized
INFO - 2023-12-18 19:23:14 --> Router Class Initialized
INFO - 2023-12-18 19:23:14 --> Output Class Initialized
INFO - 2023-12-18 19:23:14 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:14 --> Input Class Initialized
INFO - 2023-12-18 19:23:14 --> Language Class Initialized
INFO - 2023-12-18 19:23:14 --> Language Class Initialized
INFO - 2023-12-18 19:23:14 --> Config Class Initialized
INFO - 2023-12-18 19:23:14 --> Loader Class Initialized
INFO - 2023-12-18 19:23:14 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:14 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:14 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:14 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:14 --> Database Driver Class Initialized
INFO - 2023-12-18 19:23:18 --> Final output sent to browser
DEBUG - 2023-12-18 19:23:18 --> Total execution time: 27.0513
INFO - 2023-12-18 19:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:18 --> Controller Class Initialized
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:23:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:29 --> Controller Class Initialized
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:29 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:23:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:23:34 --> Config Class Initialized
INFO - 2023-12-18 19:23:34 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:34 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:34 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:34 --> URI Class Initialized
INFO - 2023-12-18 19:23:34 --> Router Class Initialized
INFO - 2023-12-18 19:23:35 --> Output Class Initialized
INFO - 2023-12-18 19:23:35 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:35 --> Input Class Initialized
INFO - 2023-12-18 19:23:35 --> Language Class Initialized
INFO - 2023-12-18 19:23:35 --> Language Class Initialized
INFO - 2023-12-18 19:23:35 --> Config Class Initialized
INFO - 2023-12-18 19:23:35 --> Loader Class Initialized
INFO - 2023-12-18 19:23:35 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:35 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:35 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:35 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:35 --> Database Driver Class Initialized
INFO - 2023-12-18 19:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:38 --> Controller Class Initialized
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:23:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:23:43 --> Config Class Initialized
INFO - 2023-12-18 19:23:43 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:43 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:43 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:43 --> URI Class Initialized
INFO - 2023-12-18 19:23:43 --> Router Class Initialized
INFO - 2023-12-18 19:23:43 --> Output Class Initialized
INFO - 2023-12-18 19:23:43 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:43 --> Input Class Initialized
INFO - 2023-12-18 19:23:43 --> Language Class Initialized
INFO - 2023-12-18 19:23:43 --> Language Class Initialized
INFO - 2023-12-18 19:23:43 --> Config Class Initialized
INFO - 2023-12-18 19:23:43 --> Loader Class Initialized
INFO - 2023-12-18 19:23:43 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:43 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:43 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:43 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:43 --> Database Driver Class Initialized
INFO - 2023-12-18 19:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:44 --> Controller Class Initialized
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:44 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:23:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:23:45 --> Config Class Initialized
INFO - 2023-12-18 19:23:45 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:45 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:45 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:45 --> URI Class Initialized
INFO - 2023-12-18 19:23:45 --> Router Class Initialized
INFO - 2023-12-18 19:23:45 --> Output Class Initialized
INFO - 2023-12-18 19:23:45 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:45 --> Input Class Initialized
INFO - 2023-12-18 19:23:45 --> Language Class Initialized
INFO - 2023-12-18 19:23:45 --> Language Class Initialized
INFO - 2023-12-18 19:23:45 --> Config Class Initialized
INFO - 2023-12-18 19:23:45 --> Loader Class Initialized
INFO - 2023-12-18 19:23:45 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:45 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:45 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:45 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:45 --> Database Driver Class Initialized
INFO - 2023-12-18 19:23:46 --> Config Class Initialized
INFO - 2023-12-18 19:23:46 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:46 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:46 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:46 --> URI Class Initialized
INFO - 2023-12-18 19:23:46 --> Router Class Initialized
INFO - 2023-12-18 19:23:46 --> Output Class Initialized
INFO - 2023-12-18 19:23:46 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:46 --> Input Class Initialized
INFO - 2023-12-18 19:23:46 --> Language Class Initialized
INFO - 2023-12-18 19:23:46 --> Language Class Initialized
INFO - 2023-12-18 19:23:46 --> Config Class Initialized
INFO - 2023-12-18 19:23:46 --> Loader Class Initialized
INFO - 2023-12-18 19:23:46 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:46 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:46 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:46 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:46 --> Database Driver Class Initialized
INFO - 2023-12-18 19:23:50 --> Final output sent to browser
DEBUG - 2023-12-18 19:23:50 --> Total execution time: 16.0744
INFO - 2023-12-18 19:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:50 --> Controller Class Initialized
DEBUG - 2023-12-18 19:23:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:23:57 --> Final output sent to browser
DEBUG - 2023-12-18 19:23:57 --> Total execution time: 14.0969
INFO - 2023-12-18 19:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:23:57 --> Controller Class Initialized
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:23:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:23:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:23:58 --> Config Class Initialized
INFO - 2023-12-18 19:23:58 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:23:58 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:23:58 --> Utf8 Class Initialized
INFO - 2023-12-18 19:23:58 --> URI Class Initialized
INFO - 2023-12-18 19:23:58 --> Router Class Initialized
INFO - 2023-12-18 19:23:58 --> Output Class Initialized
INFO - 2023-12-18 19:23:58 --> Security Class Initialized
DEBUG - 2023-12-18 19:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:23:58 --> Input Class Initialized
INFO - 2023-12-18 19:23:58 --> Language Class Initialized
INFO - 2023-12-18 19:23:58 --> Language Class Initialized
INFO - 2023-12-18 19:23:58 --> Config Class Initialized
INFO - 2023-12-18 19:23:58 --> Loader Class Initialized
INFO - 2023-12-18 19:23:58 --> Helper loaded: url_helper
INFO - 2023-12-18 19:23:58 --> Helper loaded: file_helper
INFO - 2023-12-18 19:23:58 --> Helper loaded: form_helper
INFO - 2023-12-18 19:23:58 --> Helper loaded: my_helper
INFO - 2023-12-18 19:23:58 --> Database Driver Class Initialized
INFO - 2023-12-18 19:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:24:09 --> Controller Class Initialized
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:09 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:24:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:24:11 --> Config Class Initialized
INFO - 2023-12-18 19:24:11 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:24:11 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:24:11 --> Utf8 Class Initialized
INFO - 2023-12-18 19:24:11 --> URI Class Initialized
INFO - 2023-12-18 19:24:11 --> Router Class Initialized
INFO - 2023-12-18 19:24:11 --> Output Class Initialized
INFO - 2023-12-18 19:24:11 --> Security Class Initialized
DEBUG - 2023-12-18 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:24:11 --> Input Class Initialized
INFO - 2023-12-18 19:24:11 --> Language Class Initialized
INFO - 2023-12-18 19:24:11 --> Language Class Initialized
INFO - 2023-12-18 19:24:11 --> Config Class Initialized
INFO - 2023-12-18 19:24:11 --> Loader Class Initialized
INFO - 2023-12-18 19:24:11 --> Helper loaded: url_helper
INFO - 2023-12-18 19:24:11 --> Helper loaded: file_helper
INFO - 2023-12-18 19:24:11 --> Helper loaded: form_helper
INFO - 2023-12-18 19:24:11 --> Helper loaded: my_helper
INFO - 2023-12-18 19:24:11 --> Database Driver Class Initialized
INFO - 2023-12-18 19:24:21 --> Final output sent to browser
DEBUG - 2023-12-18 19:24:21 --> Total execution time: 35.1885
INFO - 2023-12-18 19:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:24:21 --> Controller Class Initialized
DEBUG - 2023-12-18 19:24:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:24:21 --> Config Class Initialized
INFO - 2023-12-18 19:24:21 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:24:21 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:24:21 --> Utf8 Class Initialized
INFO - 2023-12-18 19:24:21 --> URI Class Initialized
INFO - 2023-12-18 19:24:21 --> Router Class Initialized
INFO - 2023-12-18 19:24:21 --> Output Class Initialized
INFO - 2023-12-18 19:24:21 --> Security Class Initialized
DEBUG - 2023-12-18 19:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:24:22 --> Input Class Initialized
INFO - 2023-12-18 19:24:22 --> Language Class Initialized
INFO - 2023-12-18 19:24:22 --> Language Class Initialized
INFO - 2023-12-18 19:24:22 --> Config Class Initialized
INFO - 2023-12-18 19:24:22 --> Loader Class Initialized
INFO - 2023-12-18 19:24:22 --> Helper loaded: url_helper
INFO - 2023-12-18 19:24:22 --> Helper loaded: file_helper
INFO - 2023-12-18 19:24:22 --> Helper loaded: form_helper
INFO - 2023-12-18 19:24:22 --> Helper loaded: my_helper
INFO - 2023-12-18 19:24:22 --> Database Driver Class Initialized
INFO - 2023-12-18 19:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:24:22 --> Controller Class Initialized
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:24:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:24:23 --> Config Class Initialized
INFO - 2023-12-18 19:24:23 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:24:23 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:24:23 --> Utf8 Class Initialized
INFO - 2023-12-18 19:24:23 --> URI Class Initialized
INFO - 2023-12-18 19:24:23 --> Router Class Initialized
INFO - 2023-12-18 19:24:23 --> Output Class Initialized
INFO - 2023-12-18 19:24:24 --> Security Class Initialized
DEBUG - 2023-12-18 19:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:24:24 --> Input Class Initialized
INFO - 2023-12-18 19:24:24 --> Language Class Initialized
INFO - 2023-12-18 19:24:24 --> Language Class Initialized
INFO - 2023-12-18 19:24:24 --> Config Class Initialized
INFO - 2023-12-18 19:24:24 --> Loader Class Initialized
INFO - 2023-12-18 19:24:24 --> Helper loaded: url_helper
INFO - 2023-12-18 19:24:24 --> Helper loaded: file_helper
INFO - 2023-12-18 19:24:24 --> Helper loaded: form_helper
INFO - 2023-12-18 19:24:24 --> Helper loaded: my_helper
INFO - 2023-12-18 19:24:24 --> Database Driver Class Initialized
INFO - 2023-12-18 19:24:40 --> Final output sent to browser
DEBUG - 2023-12-18 19:24:40 --> Total execution time: 41.8370
INFO - 2023-12-18 19:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:24:40 --> Controller Class Initialized
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:40 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:24:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:24:50 --> Controller Class Initialized
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:24:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:24:50 --> Config Class Initialized
INFO - 2023-12-18 19:24:50 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:24:50 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:24:50 --> Utf8 Class Initialized
INFO - 2023-12-18 19:24:50 --> URI Class Initialized
INFO - 2023-12-18 19:24:51 --> Router Class Initialized
INFO - 2023-12-18 19:24:51 --> Output Class Initialized
INFO - 2023-12-18 19:24:51 --> Security Class Initialized
DEBUG - 2023-12-18 19:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:24:51 --> Input Class Initialized
INFO - 2023-12-18 19:24:51 --> Language Class Initialized
INFO - 2023-12-18 19:24:51 --> Language Class Initialized
INFO - 2023-12-18 19:24:51 --> Config Class Initialized
INFO - 2023-12-18 19:24:51 --> Loader Class Initialized
INFO - 2023-12-18 19:24:51 --> Helper loaded: url_helper
INFO - 2023-12-18 19:24:51 --> Helper loaded: file_helper
INFO - 2023-12-18 19:24:51 --> Helper loaded: form_helper
INFO - 2023-12-18 19:24:51 --> Helper loaded: my_helper
INFO - 2023-12-18 19:24:51 --> Database Driver Class Initialized
INFO - 2023-12-18 19:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:24:51 --> Controller Class Initialized
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:24:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:24:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:24:54 --> Config Class Initialized
INFO - 2023-12-18 19:24:54 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:24:54 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:24:54 --> Utf8 Class Initialized
INFO - 2023-12-18 19:24:54 --> URI Class Initialized
INFO - 2023-12-18 19:24:54 --> Router Class Initialized
INFO - 2023-12-18 19:24:54 --> Output Class Initialized
INFO - 2023-12-18 19:24:54 --> Security Class Initialized
DEBUG - 2023-12-18 19:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:24:54 --> Input Class Initialized
INFO - 2023-12-18 19:24:54 --> Language Class Initialized
INFO - 2023-12-18 19:24:54 --> Language Class Initialized
INFO - 2023-12-18 19:24:54 --> Config Class Initialized
INFO - 2023-12-18 19:24:54 --> Loader Class Initialized
INFO - 2023-12-18 19:24:54 --> Helper loaded: url_helper
INFO - 2023-12-18 19:24:54 --> Helper loaded: file_helper
INFO - 2023-12-18 19:24:54 --> Helper loaded: form_helper
INFO - 2023-12-18 19:24:54 --> Helper loaded: my_helper
INFO - 2023-12-18 19:24:54 --> Database Driver Class Initialized
INFO - 2023-12-18 19:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:25:12 --> Controller Class Initialized
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:25:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:25:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:29:13 --> Config Class Initialized
INFO - 2023-12-18 19:29:13 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:14 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:14 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:14 --> URI Class Initialized
INFO - 2023-12-18 19:29:14 --> Router Class Initialized
INFO - 2023-12-18 19:29:14 --> Output Class Initialized
INFO - 2023-12-18 19:29:14 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:14 --> Input Class Initialized
INFO - 2023-12-18 19:29:14 --> Language Class Initialized
INFO - 2023-12-18 19:29:14 --> Language Class Initialized
INFO - 2023-12-18 19:29:14 --> Config Class Initialized
INFO - 2023-12-18 19:29:14 --> Loader Class Initialized
INFO - 2023-12-18 19:29:14 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:14 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:14 --> Controller Class Initialized
INFO - 2023-12-18 19:29:14 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:29:14 --> Final output sent to browser
DEBUG - 2023-12-18 19:29:14 --> Total execution time: 0.3639
INFO - 2023-12-18 19:29:14 --> Config Class Initialized
INFO - 2023-12-18 19:29:14 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:14 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:14 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:14 --> URI Class Initialized
INFO - 2023-12-18 19:29:14 --> Router Class Initialized
INFO - 2023-12-18 19:29:14 --> Output Class Initialized
INFO - 2023-12-18 19:29:14 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:14 --> Input Class Initialized
INFO - 2023-12-18 19:29:14 --> Language Class Initialized
INFO - 2023-12-18 19:29:14 --> Language Class Initialized
INFO - 2023-12-18 19:29:14 --> Config Class Initialized
INFO - 2023-12-18 19:29:14 --> Loader Class Initialized
INFO - 2023-12-18 19:29:14 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:14 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:14 --> Controller Class Initialized
INFO - 2023-12-18 19:29:14 --> Helper loaded: cookie_helper
INFO - 2023-12-18 19:29:14 --> Config Class Initialized
INFO - 2023-12-18 19:29:14 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:14 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:14 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:14 --> URI Class Initialized
INFO - 2023-12-18 19:29:14 --> Router Class Initialized
INFO - 2023-12-18 19:29:14 --> Output Class Initialized
INFO - 2023-12-18 19:29:14 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:14 --> Input Class Initialized
INFO - 2023-12-18 19:29:14 --> Language Class Initialized
INFO - 2023-12-18 19:29:14 --> Language Class Initialized
INFO - 2023-12-18 19:29:14 --> Config Class Initialized
INFO - 2023-12-18 19:29:14 --> Loader Class Initialized
INFO - 2023-12-18 19:29:14 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:14 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:14 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:14 --> Controller Class Initialized
DEBUG - 2023-12-18 19:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-18 19:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-18 19:29:14 --> Final output sent to browser
DEBUG - 2023-12-18 19:29:14 --> Total execution time: 0.0894
INFO - 2023-12-18 19:29:18 --> Config Class Initialized
INFO - 2023-12-18 19:29:18 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:18 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:18 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:18 --> URI Class Initialized
INFO - 2023-12-18 19:29:18 --> Router Class Initialized
INFO - 2023-12-18 19:29:18 --> Output Class Initialized
INFO - 2023-12-18 19:29:18 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:18 --> Input Class Initialized
INFO - 2023-12-18 19:29:18 --> Language Class Initialized
INFO - 2023-12-18 19:29:18 --> Config Class Initialized
INFO - 2023-12-18 19:29:18 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:18 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:18 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:18 --> URI Class Initialized
INFO - 2023-12-18 19:29:18 --> Router Class Initialized
INFO - 2023-12-18 19:29:18 --> Output Class Initialized
INFO - 2023-12-18 19:29:18 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:18 --> Input Class Initialized
INFO - 2023-12-18 19:29:18 --> Language Class Initialized
INFO - 2023-12-18 19:29:18 --> Language Class Initialized
INFO - 2023-12-18 19:29:18 --> Config Class Initialized
INFO - 2023-12-18 19:29:18 --> Loader Class Initialized
INFO - 2023-12-18 19:29:18 --> Language Class Initialized
INFO - 2023-12-18 19:29:18 --> Config Class Initialized
INFO - 2023-12-18 19:29:18 --> Loader Class Initialized
INFO - 2023-12-18 19:29:18 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:18 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:18 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:18 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:18 --> Controller Class Initialized
INFO - 2023-12-18 19:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:18 --> Controller Class Initialized
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:29:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
DEBUG - 2023-12-18 19:29:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:29:32 --> Final output sent to browser
DEBUG - 2023-12-18 19:29:32 --> Total execution time: 13.4534
INFO - 2023-12-18 19:29:33 --> Config Class Initialized
INFO - 2023-12-18 19:29:33 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:33 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:33 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:33 --> URI Class Initialized
INFO - 2023-12-18 19:29:33 --> Router Class Initialized
INFO - 2023-12-18 19:29:33 --> Output Class Initialized
INFO - 2023-12-18 19:29:33 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:33 --> Input Class Initialized
INFO - 2023-12-18 19:29:33 --> Language Class Initialized
INFO - 2023-12-18 19:29:33 --> Language Class Initialized
INFO - 2023-12-18 19:29:33 --> Config Class Initialized
INFO - 2023-12-18 19:29:33 --> Loader Class Initialized
INFO - 2023-12-18 19:29:33 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:33 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:33 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:33 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:33 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:33 --> Controller Class Initialized
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:29:33 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:29:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:29:35 --> Final output sent to browser
DEBUG - 2023-12-18 19:29:35 --> Total execution time: 16.4525
INFO - 2023-12-18 19:29:35 --> Config Class Initialized
INFO - 2023-12-18 19:29:35 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:35 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:35 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:36 --> URI Class Initialized
INFO - 2023-12-18 19:29:36 --> Router Class Initialized
INFO - 2023-12-18 19:29:36 --> Output Class Initialized
INFO - 2023-12-18 19:29:36 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:36 --> Input Class Initialized
INFO - 2023-12-18 19:29:36 --> Language Class Initialized
INFO - 2023-12-18 19:29:37 --> Language Class Initialized
INFO - 2023-12-18 19:29:37 --> Config Class Initialized
INFO - 2023-12-18 19:29:37 --> Loader Class Initialized
INFO - 2023-12-18 19:29:37 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:37 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:37 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:37 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:37 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:37 --> Controller Class Initialized
DEBUG - 2023-12-18 19:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:29:54 --> Config Class Initialized
INFO - 2023-12-18 19:29:54 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:29:54 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:29:54 --> Utf8 Class Initialized
INFO - 2023-12-18 19:29:54 --> URI Class Initialized
INFO - 2023-12-18 19:29:54 --> Router Class Initialized
INFO - 2023-12-18 19:29:54 --> Output Class Initialized
INFO - 2023-12-18 19:29:54 --> Security Class Initialized
DEBUG - 2023-12-18 19:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:29:54 --> Input Class Initialized
INFO - 2023-12-18 19:29:54 --> Language Class Initialized
INFO - 2023-12-18 19:29:54 --> Language Class Initialized
INFO - 2023-12-18 19:29:54 --> Config Class Initialized
INFO - 2023-12-18 19:29:54 --> Loader Class Initialized
INFO - 2023-12-18 19:29:54 --> Helper loaded: url_helper
INFO - 2023-12-18 19:29:54 --> Helper loaded: file_helper
INFO - 2023-12-18 19:29:54 --> Helper loaded: form_helper
INFO - 2023-12-18 19:29:54 --> Helper loaded: my_helper
INFO - 2023-12-18 19:29:55 --> Database Driver Class Initialized
INFO - 2023-12-18 19:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:29:55 --> Controller Class Initialized
DEBUG - 2023-12-18 19:29:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:29:57 --> Final output sent to browser
DEBUG - 2023-12-18 19:29:57 --> Total execution time: 22.0988
INFO - 2023-12-18 19:30:03 --> Config Class Initialized
INFO - 2023-12-18 19:30:03 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:30:03 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:30:03 --> Utf8 Class Initialized
INFO - 2023-12-18 19:30:03 --> URI Class Initialized
INFO - 2023-12-18 19:30:03 --> Router Class Initialized
INFO - 2023-12-18 19:30:03 --> Output Class Initialized
INFO - 2023-12-18 19:30:03 --> Security Class Initialized
DEBUG - 2023-12-18 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:30:03 --> Input Class Initialized
INFO - 2023-12-18 19:30:03 --> Language Class Initialized
INFO - 2023-12-18 19:30:03 --> Language Class Initialized
INFO - 2023-12-18 19:30:03 --> Config Class Initialized
INFO - 2023-12-18 19:30:03 --> Loader Class Initialized
INFO - 2023-12-18 19:30:03 --> Helper loaded: url_helper
INFO - 2023-12-18 19:30:03 --> Helper loaded: file_helper
INFO - 2023-12-18 19:30:03 --> Helper loaded: form_helper
INFO - 2023-12-18 19:30:03 --> Helper loaded: my_helper
INFO - 2023-12-18 19:30:03 --> Database Driver Class Initialized
INFO - 2023-12-18 19:30:07 --> Final output sent to browser
DEBUG - 2023-12-18 19:30:07 --> Total execution time: 12.5924
INFO - 2023-12-18 19:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:30:07 --> Controller Class Initialized
INFO - 2023-12-18 19:30:07 --> Config Class Initialized
INFO - 2023-12-18 19:30:07 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:30:07 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:30:07 --> Utf8 Class Initialized
INFO - 2023-12-18 19:30:07 --> URI Class Initialized
INFO - 2023-12-18 19:30:07 --> Router Class Initialized
INFO - 2023-12-18 19:30:07 --> Output Class Initialized
INFO - 2023-12-18 19:30:07 --> Security Class Initialized
DEBUG - 2023-12-18 19:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:30:07 --> Input Class Initialized
INFO - 2023-12-18 19:30:07 --> Language Class Initialized
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
INFO - 2023-12-18 19:30:07 --> Language Class Initialized
INFO - 2023-12-18 19:30:07 --> Config Class Initialized
INFO - 2023-12-18 19:30:07 --> Loader Class Initialized
INFO - 2023-12-18 19:30:07 --> Helper loaded: url_helper
INFO - 2023-12-18 19:30:07 --> Helper loaded: file_helper
INFO - 2023-12-18 19:30:07 --> Helper loaded: form_helper
INFO - 2023-12-18 19:30:07 --> Helper loaded: my_helper
INFO - 2023-12-18 19:30:07 --> Database Driver Class Initialized
DEBUG - 2023-12-18 19:30:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:30:08 --> Config Class Initialized
INFO - 2023-12-18 19:30:08 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:30:08 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:30:08 --> Utf8 Class Initialized
INFO - 2023-12-18 19:30:08 --> URI Class Initialized
INFO - 2023-12-18 19:30:08 --> Router Class Initialized
INFO - 2023-12-18 19:30:08 --> Output Class Initialized
INFO - 2023-12-18 19:30:08 --> Security Class Initialized
DEBUG - 2023-12-18 19:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:30:08 --> Input Class Initialized
INFO - 2023-12-18 19:30:08 --> Language Class Initialized
INFO - 2023-12-18 19:30:08 --> Language Class Initialized
INFO - 2023-12-18 19:30:08 --> Config Class Initialized
INFO - 2023-12-18 19:30:08 --> Loader Class Initialized
INFO - 2023-12-18 19:30:08 --> Helper loaded: url_helper
INFO - 2023-12-18 19:30:08 --> Helper loaded: file_helper
INFO - 2023-12-18 19:30:08 --> Helper loaded: form_helper
INFO - 2023-12-18 19:30:08 --> Helper loaded: my_helper
INFO - 2023-12-18 19:30:08 --> Database Driver Class Initialized
INFO - 2023-12-18 19:30:21 --> Final output sent to browser
DEBUG - 2023-12-18 19:30:21 --> Total execution time: 18.7829
INFO - 2023-12-18 19:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:30:21 --> Controller Class Initialized
DEBUG - 2023-12-18 19:30:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 19:30:36 --> Final output sent to browser
DEBUG - 2023-12-18 19:30:36 --> Total execution time: 28.8795
INFO - 2023-12-18 19:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:30:36 --> Controller Class Initialized
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:30:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:30:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:31:18 --> Config Class Initialized
INFO - 2023-12-18 19:31:18 --> Hooks Class Initialized
DEBUG - 2023-12-18 19:31:18 --> UTF-8 Support Enabled
INFO - 2023-12-18 19:31:18 --> Utf8 Class Initialized
INFO - 2023-12-18 19:31:18 --> URI Class Initialized
INFO - 2023-12-18 19:31:18 --> Router Class Initialized
INFO - 2023-12-18 19:31:18 --> Output Class Initialized
INFO - 2023-12-18 19:31:18 --> Security Class Initialized
DEBUG - 2023-12-18 19:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 19:31:18 --> Input Class Initialized
INFO - 2023-12-18 19:31:18 --> Language Class Initialized
INFO - 2023-12-18 19:31:18 --> Language Class Initialized
INFO - 2023-12-18 19:31:18 --> Config Class Initialized
INFO - 2023-12-18 19:31:18 --> Loader Class Initialized
INFO - 2023-12-18 19:31:18 --> Helper loaded: url_helper
INFO - 2023-12-18 19:31:18 --> Helper loaded: file_helper
INFO - 2023-12-18 19:31:18 --> Helper loaded: form_helper
INFO - 2023-12-18 19:31:18 --> Helper loaded: my_helper
INFO - 2023-12-18 19:31:18 --> Database Driver Class Initialized
INFO - 2023-12-18 19:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 19:31:18 --> Controller Class Initialized
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 19:31:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 19:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 19:31:24 --> Final output sent to browser
DEBUG - 2023-12-18 19:31:24 --> Total execution time: 6.4452
INFO - 2023-12-18 22:44:25 --> Config Class Initialized
INFO - 2023-12-18 22:44:25 --> Hooks Class Initialized
INFO - 2023-12-18 22:44:25 --> Config Class Initialized
INFO - 2023-12-18 22:44:25 --> Hooks Class Initialized
DEBUG - 2023-12-18 22:44:25 --> UTF-8 Support Enabled
INFO - 2023-12-18 22:44:25 --> Utf8 Class Initialized
DEBUG - 2023-12-18 22:44:25 --> UTF-8 Support Enabled
INFO - 2023-12-18 22:44:25 --> Utf8 Class Initialized
INFO - 2023-12-18 22:44:25 --> URI Class Initialized
INFO - 2023-12-18 22:44:25 --> URI Class Initialized
INFO - 2023-12-18 22:44:25 --> Router Class Initialized
INFO - 2023-12-18 22:44:25 --> Router Class Initialized
INFO - 2023-12-18 22:44:25 --> Output Class Initialized
INFO - 2023-12-18 22:44:25 --> Output Class Initialized
INFO - 2023-12-18 22:44:25 --> Security Class Initialized
INFO - 2023-12-18 22:44:25 --> Security Class Initialized
DEBUG - 2023-12-18 22:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 22:44:25 --> Input Class Initialized
DEBUG - 2023-12-18 22:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 22:44:25 --> Input Class Initialized
INFO - 2023-12-18 22:44:25 --> Language Class Initialized
INFO - 2023-12-18 22:44:25 --> Language Class Initialized
INFO - 2023-12-18 22:44:25 --> Language Class Initialized
INFO - 2023-12-18 22:44:25 --> Config Class Initialized
INFO - 2023-12-18 22:44:25 --> Loader Class Initialized
INFO - 2023-12-18 22:44:25 --> Language Class Initialized
INFO - 2023-12-18 22:44:25 --> Config Class Initialized
INFO - 2023-12-18 22:44:25 --> Loader Class Initialized
INFO - 2023-12-18 22:44:25 --> Helper loaded: url_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: url_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: file_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: file_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: form_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: form_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: my_helper
INFO - 2023-12-18 22:44:25 --> Helper loaded: my_helper
INFO - 2023-12-18 22:44:25 --> Database Driver Class Initialized
INFO - 2023-12-18 22:44:25 --> Database Driver Class Initialized
INFO - 2023-12-18 22:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 22:44:25 --> Controller Class Initialized
INFO - 2023-12-18 22:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 22:44:25 --> Controller Class Initialized
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:25 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 22:44:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
DEBUG - 2023-12-18 22:44:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 22:44:39 --> Final output sent to browser
DEBUG - 2023-12-18 22:44:39 --> Total execution time: 14.1720
INFO - 2023-12-18 22:44:40 --> Config Class Initialized
INFO - 2023-12-18 22:44:40 --> Hooks Class Initialized
DEBUG - 2023-12-18 22:44:40 --> UTF-8 Support Enabled
INFO - 2023-12-18 22:44:40 --> Utf8 Class Initialized
INFO - 2023-12-18 22:44:40 --> URI Class Initialized
INFO - 2023-12-18 22:44:40 --> Router Class Initialized
INFO - 2023-12-18 22:44:40 --> Output Class Initialized
INFO - 2023-12-18 22:44:40 --> Security Class Initialized
DEBUG - 2023-12-18 22:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 22:44:40 --> Input Class Initialized
INFO - 2023-12-18 22:44:40 --> Language Class Initialized
INFO - 2023-12-18 22:44:40 --> Language Class Initialized
INFO - 2023-12-18 22:44:40 --> Config Class Initialized
INFO - 2023-12-18 22:44:40 --> Loader Class Initialized
INFO - 2023-12-18 22:44:40 --> Helper loaded: url_helper
INFO - 2023-12-18 22:44:40 --> Helper loaded: file_helper
INFO - 2023-12-18 22:44:40 --> Helper loaded: form_helper
INFO - 2023-12-18 22:44:40 --> Helper loaded: my_helper
INFO - 2023-12-18 22:44:40 --> Database Driver Class Initialized
INFO - 2023-12-18 22:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 22:44:40 --> Controller Class Initialized
DEBUG - 2023-12-18 22:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-18 22:44:40 --> Final output sent to browser
DEBUG - 2023-12-18 22:44:40 --> Total execution time: 15.4975
INFO - 2023-12-18 22:44:41 --> Config Class Initialized
INFO - 2023-12-18 22:44:41 --> Hooks Class Initialized
DEBUG - 2023-12-18 22:44:41 --> UTF-8 Support Enabled
INFO - 2023-12-18 22:44:41 --> Utf8 Class Initialized
INFO - 2023-12-18 22:44:41 --> URI Class Initialized
INFO - 2023-12-18 22:44:41 --> Router Class Initialized
INFO - 2023-12-18 22:44:41 --> Output Class Initialized
INFO - 2023-12-18 22:44:41 --> Security Class Initialized
DEBUG - 2023-12-18 22:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-18 22:44:41 --> Input Class Initialized
INFO - 2023-12-18 22:44:41 --> Language Class Initialized
INFO - 2023-12-18 22:44:41 --> Language Class Initialized
INFO - 2023-12-18 22:44:41 --> Config Class Initialized
INFO - 2023-12-18 22:44:41 --> Loader Class Initialized
INFO - 2023-12-18 22:44:41 --> Helper loaded: url_helper
INFO - 2023-12-18 22:44:41 --> Helper loaded: file_helper
INFO - 2023-12-18 22:44:41 --> Helper loaded: form_helper
INFO - 2023-12-18 22:44:41 --> Helper loaded: my_helper
INFO - 2023-12-18 22:44:41 --> Database Driver Class Initialized
INFO - 2023-12-18 22:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-18 22:44:41 --> Controller Class Initialized
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-18 22:44:41 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-18 22:44:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-18 22:44:54 --> Final output sent to browser
DEBUG - 2023-12-18 22:44:54 --> Total execution time: 13.9671
