<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-05 07:54:19 --> Config Class Initialized
INFO - 2024-01-05 07:54:19 --> Hooks Class Initialized
DEBUG - 2024-01-05 07:54:19 --> UTF-8 Support Enabled
INFO - 2024-01-05 07:54:19 --> Utf8 Class Initialized
INFO - 2024-01-05 07:54:19 --> URI Class Initialized
INFO - 2024-01-05 07:54:19 --> Router Class Initialized
INFO - 2024-01-05 07:54:19 --> Output Class Initialized
INFO - 2024-01-05 07:54:19 --> Security Class Initialized
DEBUG - 2024-01-05 07:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 07:54:19 --> Input Class Initialized
INFO - 2024-01-05 07:54:19 --> Language Class Initialized
INFO - 2024-01-05 07:54:19 --> Language Class Initialized
INFO - 2024-01-05 07:54:19 --> Config Class Initialized
INFO - 2024-01-05 07:54:19 --> Loader Class Initialized
INFO - 2024-01-05 07:54:19 --> Helper loaded: url_helper
INFO - 2024-01-05 07:54:19 --> Helper loaded: file_helper
INFO - 2024-01-05 07:54:19 --> Helper loaded: form_helper
INFO - 2024-01-05 07:54:19 --> Helper loaded: my_helper
INFO - 2024-01-05 07:54:19 --> Database Driver Class Initialized
INFO - 2024-01-05 07:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 07:54:19 --> Controller Class Initialized
DEBUG - 2024-01-05 07:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-05 07:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 07:54:19 --> Final output sent to browser
DEBUG - 2024-01-05 07:54:19 --> Total execution time: 0.2554
INFO - 2024-01-05 07:54:26 --> Config Class Initialized
INFO - 2024-01-05 07:54:26 --> Hooks Class Initialized
DEBUG - 2024-01-05 07:54:26 --> UTF-8 Support Enabled
INFO - 2024-01-05 07:54:26 --> Utf8 Class Initialized
INFO - 2024-01-05 07:54:26 --> URI Class Initialized
INFO - 2024-01-05 07:54:26 --> Router Class Initialized
INFO - 2024-01-05 07:54:26 --> Output Class Initialized
INFO - 2024-01-05 07:54:26 --> Security Class Initialized
DEBUG - 2024-01-05 07:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 07:54:26 --> Input Class Initialized
INFO - 2024-01-05 07:54:26 --> Language Class Initialized
INFO - 2024-01-05 07:54:26 --> Language Class Initialized
INFO - 2024-01-05 07:54:26 --> Config Class Initialized
INFO - 2024-01-05 07:54:26 --> Loader Class Initialized
INFO - 2024-01-05 07:54:26 --> Helper loaded: url_helper
INFO - 2024-01-05 07:54:26 --> Helper loaded: file_helper
INFO - 2024-01-05 07:54:26 --> Helper loaded: form_helper
INFO - 2024-01-05 07:54:26 --> Helper loaded: my_helper
INFO - 2024-01-05 07:54:26 --> Database Driver Class Initialized
INFO - 2024-01-05 07:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 07:54:26 --> Controller Class Initialized
INFO - 2024-01-05 07:54:26 --> Helper loaded: cookie_helper
INFO - 2024-01-05 07:54:26 --> Final output sent to browser
DEBUG - 2024-01-05 07:54:26 --> Total execution time: 0.0647
INFO - 2024-01-05 07:54:26 --> Config Class Initialized
INFO - 2024-01-05 07:54:26 --> Hooks Class Initialized
DEBUG - 2024-01-05 07:54:26 --> UTF-8 Support Enabled
INFO - 2024-01-05 07:54:26 --> Utf8 Class Initialized
INFO - 2024-01-05 07:54:26 --> URI Class Initialized
INFO - 2024-01-05 07:54:26 --> Router Class Initialized
INFO - 2024-01-05 07:54:26 --> Output Class Initialized
INFO - 2024-01-05 07:54:26 --> Security Class Initialized
DEBUG - 2024-01-05 07:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 07:54:26 --> Input Class Initialized
INFO - 2024-01-05 07:54:26 --> Language Class Initialized
INFO - 2024-01-05 07:54:27 --> Language Class Initialized
INFO - 2024-01-05 07:54:27 --> Config Class Initialized
INFO - 2024-01-05 07:54:27 --> Loader Class Initialized
INFO - 2024-01-05 07:54:27 --> Helper loaded: url_helper
INFO - 2024-01-05 07:54:27 --> Helper loaded: file_helper
INFO - 2024-01-05 07:54:27 --> Helper loaded: form_helper
INFO - 2024-01-05 07:54:27 --> Helper loaded: my_helper
INFO - 2024-01-05 07:54:27 --> Database Driver Class Initialized
INFO - 2024-01-05 07:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 07:54:27 --> Controller Class Initialized
DEBUG - 2024-01-05 07:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-05 07:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 07:54:27 --> Final output sent to browser
DEBUG - 2024-01-05 07:54:27 --> Total execution time: 0.0539
INFO - 2024-01-05 07:54:33 --> Config Class Initialized
INFO - 2024-01-05 07:54:33 --> Hooks Class Initialized
DEBUG - 2024-01-05 07:54:33 --> UTF-8 Support Enabled
INFO - 2024-01-05 07:54:33 --> Utf8 Class Initialized
INFO - 2024-01-05 07:54:33 --> URI Class Initialized
INFO - 2024-01-05 07:54:33 --> Router Class Initialized
INFO - 2024-01-05 07:54:33 --> Output Class Initialized
INFO - 2024-01-05 07:54:33 --> Security Class Initialized
DEBUG - 2024-01-05 07:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 07:54:33 --> Input Class Initialized
INFO - 2024-01-05 07:54:33 --> Language Class Initialized
INFO - 2024-01-05 07:54:33 --> Language Class Initialized
INFO - 2024-01-05 07:54:33 --> Config Class Initialized
INFO - 2024-01-05 07:54:33 --> Loader Class Initialized
INFO - 2024-01-05 07:54:33 --> Helper loaded: url_helper
INFO - 2024-01-05 07:54:33 --> Helper loaded: file_helper
INFO - 2024-01-05 07:54:33 --> Helper loaded: form_helper
INFO - 2024-01-05 07:54:33 --> Helper loaded: my_helper
INFO - 2024-01-05 07:54:33 --> Database Driver Class Initialized
INFO - 2024-01-05 07:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 07:54:33 --> Controller Class Initialized
DEBUG - 2024-01-05 07:54:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/landing.php
DEBUG - 2024-01-05 07:54:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 07:54:33 --> Final output sent to browser
DEBUG - 2024-01-05 07:54:33 --> Total execution time: 0.0516
INFO - 2024-01-05 07:54:35 --> Config Class Initialized
INFO - 2024-01-05 07:54:35 --> Hooks Class Initialized
DEBUG - 2024-01-05 07:54:35 --> UTF-8 Support Enabled
INFO - 2024-01-05 07:54:35 --> Utf8 Class Initialized
INFO - 2024-01-05 07:54:35 --> URI Class Initialized
INFO - 2024-01-05 07:54:35 --> Router Class Initialized
INFO - 2024-01-05 07:54:35 --> Output Class Initialized
INFO - 2024-01-05 07:54:35 --> Security Class Initialized
DEBUG - 2024-01-05 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 07:54:35 --> Input Class Initialized
INFO - 2024-01-05 07:54:35 --> Language Class Initialized
INFO - 2024-01-05 07:54:35 --> Language Class Initialized
INFO - 2024-01-05 07:54:35 --> Config Class Initialized
INFO - 2024-01-05 07:54:35 --> Loader Class Initialized
INFO - 2024-01-05 07:54:35 --> Helper loaded: url_helper
INFO - 2024-01-05 07:54:35 --> Helper loaded: file_helper
INFO - 2024-01-05 07:54:35 --> Helper loaded: form_helper
INFO - 2024-01-05 07:54:35 --> Helper loaded: my_helper
INFO - 2024-01-05 07:54:35 --> Database Driver Class Initialized
INFO - 2024-01-05 07:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 07:54:35 --> Controller Class Initialized
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:35 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 07:54:36 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
DEBUG - 2024-01-05 07:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak.php
INFO - 2024-01-05 07:54:36 --> Final output sent to browser
DEBUG - 2024-01-05 07:54:36 --> Total execution time: 0.4313
INFO - 2024-01-05 07:57:45 --> Config Class Initialized
INFO - 2024-01-05 07:57:45 --> Hooks Class Initialized
DEBUG - 2024-01-05 07:57:45 --> UTF-8 Support Enabled
INFO - 2024-01-05 07:57:45 --> Utf8 Class Initialized
INFO - 2024-01-05 07:57:45 --> URI Class Initialized
INFO - 2024-01-05 07:57:45 --> Router Class Initialized
INFO - 2024-01-05 07:57:45 --> Output Class Initialized
INFO - 2024-01-05 07:57:45 --> Security Class Initialized
DEBUG - 2024-01-05 07:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 07:57:45 --> Input Class Initialized
INFO - 2024-01-05 07:57:45 --> Language Class Initialized
INFO - 2024-01-05 07:57:45 --> Language Class Initialized
INFO - 2024-01-05 07:57:45 --> Config Class Initialized
INFO - 2024-01-05 07:57:45 --> Loader Class Initialized
INFO - 2024-01-05 07:57:45 --> Helper loaded: url_helper
INFO - 2024-01-05 07:57:45 --> Helper loaded: file_helper
INFO - 2024-01-05 07:57:45 --> Helper loaded: form_helper
INFO - 2024-01-05 07:57:45 --> Helper loaded: my_helper
INFO - 2024-01-05 07:57:45 --> Database Driver Class Initialized
INFO - 2024-01-05 07:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 07:57:45 --> Controller Class Initialized
DEBUG - 2024-01-05 07:57:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak_ekstra.php
INFO - 2024-01-05 07:57:45 --> Final output sent to browser
DEBUG - 2024-01-05 07:57:45 --> Total execution time: 0.0402
INFO - 2024-01-05 08:16:33 --> Config Class Initialized
INFO - 2024-01-05 08:16:33 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:16:33 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:16:33 --> Utf8 Class Initialized
INFO - 2024-01-05 08:16:33 --> URI Class Initialized
INFO - 2024-01-05 08:16:33 --> Router Class Initialized
INFO - 2024-01-05 08:16:33 --> Output Class Initialized
INFO - 2024-01-05 08:16:33 --> Security Class Initialized
DEBUG - 2024-01-05 08:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:16:33 --> Input Class Initialized
INFO - 2024-01-05 08:16:33 --> Language Class Initialized
INFO - 2024-01-05 08:16:33 --> Language Class Initialized
INFO - 2024-01-05 08:16:33 --> Config Class Initialized
INFO - 2024-01-05 08:16:33 --> Loader Class Initialized
INFO - 2024-01-05 08:16:33 --> Helper loaded: url_helper
INFO - 2024-01-05 08:16:33 --> Helper loaded: file_helper
INFO - 2024-01-05 08:16:33 --> Helper loaded: form_helper
INFO - 2024-01-05 08:16:33 --> Helper loaded: my_helper
INFO - 2024-01-05 08:16:33 --> Database Driver Class Initialized
INFO - 2024-01-05 08:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:16:33 --> Controller Class Initialized
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2024-01-05 08:16:33 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
DEBUG - 2024-01-05 08:16:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak.php
INFO - 2024-01-05 08:16:33 --> Final output sent to browser
DEBUG - 2024-01-05 08:16:33 --> Total execution time: 0.3284
INFO - 2024-01-05 08:16:40 --> Config Class Initialized
INFO - 2024-01-05 08:16:40 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:16:40 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:16:40 --> Utf8 Class Initialized
INFO - 2024-01-05 08:16:40 --> URI Class Initialized
INFO - 2024-01-05 08:16:40 --> Router Class Initialized
INFO - 2024-01-05 08:16:40 --> Output Class Initialized
INFO - 2024-01-05 08:16:40 --> Security Class Initialized
DEBUG - 2024-01-05 08:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:16:40 --> Input Class Initialized
INFO - 2024-01-05 08:16:40 --> Language Class Initialized
INFO - 2024-01-05 08:16:40 --> Language Class Initialized
INFO - 2024-01-05 08:16:40 --> Config Class Initialized
INFO - 2024-01-05 08:16:40 --> Loader Class Initialized
INFO - 2024-01-05 08:16:40 --> Helper loaded: url_helper
INFO - 2024-01-05 08:16:40 --> Helper loaded: file_helper
INFO - 2024-01-05 08:16:40 --> Helper loaded: form_helper
INFO - 2024-01-05 08:16:40 --> Helper loaded: my_helper
INFO - 2024-01-05 08:16:40 --> Database Driver Class Initialized
INFO - 2024-01-05 08:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:16:40 --> Controller Class Initialized
DEBUG - 2024-01-05 08:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak_ekstra.php
INFO - 2024-01-05 08:16:40 --> Final output sent to browser
DEBUG - 2024-01-05 08:16:40 --> Total execution time: 0.0388
INFO - 2024-01-05 08:46:45 --> Config Class Initialized
INFO - 2024-01-05 08:46:45 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:46:45 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:46:45 --> Utf8 Class Initialized
INFO - 2024-01-05 08:46:45 --> URI Class Initialized
INFO - 2024-01-05 08:46:45 --> Router Class Initialized
INFO - 2024-01-05 08:46:45 --> Output Class Initialized
INFO - 2024-01-05 08:46:45 --> Security Class Initialized
DEBUG - 2024-01-05 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:46:45 --> Input Class Initialized
INFO - 2024-01-05 08:46:45 --> Language Class Initialized
INFO - 2024-01-05 08:46:45 --> Language Class Initialized
INFO - 2024-01-05 08:46:45 --> Config Class Initialized
INFO - 2024-01-05 08:46:45 --> Loader Class Initialized
INFO - 2024-01-05 08:46:45 --> Helper loaded: url_helper
INFO - 2024-01-05 08:46:45 --> Helper loaded: file_helper
INFO - 2024-01-05 08:46:45 --> Helper loaded: form_helper
INFO - 2024-01-05 08:46:45 --> Helper loaded: my_helper
INFO - 2024-01-05 08:46:45 --> Database Driver Class Initialized
INFO - 2024-01-05 08:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:46:45 --> Controller Class Initialized
DEBUG - 2024-01-05 08:46:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-01-05 08:46:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:46:45 --> Final output sent to browser
DEBUG - 2024-01-05 08:46:45 --> Total execution time: 0.0501
INFO - 2024-01-05 08:48:29 --> Config Class Initialized
INFO - 2024-01-05 08:48:29 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:29 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:29 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:29 --> URI Class Initialized
INFO - 2024-01-05 08:48:29 --> Router Class Initialized
INFO - 2024-01-05 08:48:29 --> Output Class Initialized
INFO - 2024-01-05 08:48:29 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:29 --> Input Class Initialized
INFO - 2024-01-05 08:48:29 --> Language Class Initialized
INFO - 2024-01-05 08:48:29 --> Language Class Initialized
INFO - 2024-01-05 08:48:29 --> Config Class Initialized
INFO - 2024-01-05 08:48:29 --> Loader Class Initialized
INFO - 2024-01-05 08:48:29 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:29 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:29 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:29 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:29 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:29 --> Controller Class Initialized
INFO - 2024-01-05 08:48:29 --> Config Class Initialized
INFO - 2024-01-05 08:48:29 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:29 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:29 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:29 --> URI Class Initialized
INFO - 2024-01-05 08:48:29 --> Router Class Initialized
INFO - 2024-01-05 08:48:29 --> Output Class Initialized
INFO - 2024-01-05 08:48:29 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:29 --> Input Class Initialized
INFO - 2024-01-05 08:48:29 --> Language Class Initialized
INFO - 2024-01-05 08:48:29 --> Language Class Initialized
INFO - 2024-01-05 08:48:29 --> Config Class Initialized
INFO - 2024-01-05 08:48:29 --> Loader Class Initialized
INFO - 2024-01-05 08:48:29 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:29 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:29 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:29 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:29 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:29 --> Controller Class Initialized
DEBUG - 2024-01-05 08:48:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-05 08:48:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:48:29 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:29 --> Total execution time: 0.0376
INFO - 2024-01-05 08:48:39 --> Config Class Initialized
INFO - 2024-01-05 08:48:39 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:39 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:39 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:39 --> URI Class Initialized
INFO - 2024-01-05 08:48:39 --> Router Class Initialized
INFO - 2024-01-05 08:48:39 --> Output Class Initialized
INFO - 2024-01-05 08:48:39 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:39 --> Input Class Initialized
INFO - 2024-01-05 08:48:39 --> Language Class Initialized
INFO - 2024-01-05 08:48:39 --> Language Class Initialized
INFO - 2024-01-05 08:48:39 --> Config Class Initialized
INFO - 2024-01-05 08:48:39 --> Loader Class Initialized
INFO - 2024-01-05 08:48:39 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:39 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:39 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:39 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:39 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:39 --> Controller Class Initialized
INFO - 2024-01-05 08:48:39 --> Helper loaded: cookie_helper
INFO - 2024-01-05 08:48:39 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:39 --> Total execution time: 0.0423
INFO - 2024-01-05 08:48:39 --> Config Class Initialized
INFO - 2024-01-05 08:48:39 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:39 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:39 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:39 --> URI Class Initialized
INFO - 2024-01-05 08:48:39 --> Router Class Initialized
INFO - 2024-01-05 08:48:39 --> Output Class Initialized
INFO - 2024-01-05 08:48:39 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:39 --> Input Class Initialized
INFO - 2024-01-05 08:48:39 --> Language Class Initialized
INFO - 2024-01-05 08:48:39 --> Language Class Initialized
INFO - 2024-01-05 08:48:39 --> Config Class Initialized
INFO - 2024-01-05 08:48:39 --> Loader Class Initialized
INFO - 2024-01-05 08:48:39 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:39 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:39 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:39 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:39 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:39 --> Controller Class Initialized
DEBUG - 2024-01-05 08:48:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-05 08:48:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:48:39 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:39 --> Total execution time: 0.0317
INFO - 2024-01-05 08:48:42 --> Config Class Initialized
INFO - 2024-01-05 08:48:42 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:42 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:42 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:42 --> URI Class Initialized
INFO - 2024-01-05 08:48:42 --> Router Class Initialized
INFO - 2024-01-05 08:48:42 --> Output Class Initialized
INFO - 2024-01-05 08:48:42 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:42 --> Input Class Initialized
INFO - 2024-01-05 08:48:42 --> Language Class Initialized
INFO - 2024-01-05 08:48:42 --> Language Class Initialized
INFO - 2024-01-05 08:48:42 --> Config Class Initialized
INFO - 2024-01-05 08:48:42 --> Loader Class Initialized
INFO - 2024-01-05 08:48:42 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:42 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:42 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:42 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:42 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:42 --> Controller Class Initialized
DEBUG - 2024-01-05 08:48:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-05 08:48:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:48:42 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:42 --> Total execution time: 0.0402
INFO - 2024-01-05 08:48:44 --> Config Class Initialized
INFO - 2024-01-05 08:48:44 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:44 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:44 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:44 --> URI Class Initialized
INFO - 2024-01-05 08:48:44 --> Router Class Initialized
INFO - 2024-01-05 08:48:44 --> Output Class Initialized
INFO - 2024-01-05 08:48:44 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:44 --> Input Class Initialized
INFO - 2024-01-05 08:48:44 --> Language Class Initialized
INFO - 2024-01-05 08:48:44 --> Language Class Initialized
INFO - 2024-01-05 08:48:44 --> Config Class Initialized
INFO - 2024-01-05 08:48:44 --> Loader Class Initialized
INFO - 2024-01-05 08:48:44 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:44 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:44 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:44 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:44 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:44 --> Controller Class Initialized
DEBUG - 2024-01-05 08:48:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 08:48:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:48:44 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:44 --> Total execution time: 0.0446
INFO - 2024-01-05 08:48:44 --> Config Class Initialized
INFO - 2024-01-05 08:48:44 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:44 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:44 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:44 --> URI Class Initialized
INFO - 2024-01-05 08:48:44 --> Router Class Initialized
INFO - 2024-01-05 08:48:44 --> Output Class Initialized
INFO - 2024-01-05 08:48:44 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:44 --> Input Class Initialized
INFO - 2024-01-05 08:48:44 --> Language Class Initialized
INFO - 2024-01-05 08:48:44 --> Language Class Initialized
INFO - 2024-01-05 08:48:44 --> Config Class Initialized
INFO - 2024-01-05 08:48:44 --> Loader Class Initialized
INFO - 2024-01-05 08:48:44 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:44 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:44 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:44 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:44 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:44 --> Controller Class Initialized
INFO - 2024-01-05 08:48:47 --> Config Class Initialized
INFO - 2024-01-05 08:48:47 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:47 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:47 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:47 --> URI Class Initialized
INFO - 2024-01-05 08:48:47 --> Router Class Initialized
INFO - 2024-01-05 08:48:47 --> Output Class Initialized
INFO - 2024-01-05 08:48:47 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:47 --> Input Class Initialized
INFO - 2024-01-05 08:48:47 --> Language Class Initialized
INFO - 2024-01-05 08:48:47 --> Language Class Initialized
INFO - 2024-01-05 08:48:47 --> Config Class Initialized
INFO - 2024-01-05 08:48:47 --> Loader Class Initialized
INFO - 2024-01-05 08:48:47 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:47 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:47 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:47 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:47 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:47 --> Controller Class Initialized
INFO - 2024-01-05 08:48:50 --> Config Class Initialized
INFO - 2024-01-05 08:48:50 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:50 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:50 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:50 --> URI Class Initialized
INFO - 2024-01-05 08:48:50 --> Router Class Initialized
INFO - 2024-01-05 08:48:50 --> Output Class Initialized
INFO - 2024-01-05 08:48:50 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:50 --> Input Class Initialized
INFO - 2024-01-05 08:48:50 --> Language Class Initialized
INFO - 2024-01-05 08:48:50 --> Language Class Initialized
INFO - 2024-01-05 08:48:50 --> Config Class Initialized
INFO - 2024-01-05 08:48:50 --> Loader Class Initialized
INFO - 2024-01-05 08:48:50 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:50 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:50 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:50 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:50 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:50 --> Controller Class Initialized
DEBUG - 2024-01-05 08:48:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-05 08:48:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:48:50 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:50 --> Total execution time: 0.0478
INFO - 2024-01-05 08:48:53 --> Config Class Initialized
INFO - 2024-01-05 08:48:53 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:53 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:53 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:53 --> URI Class Initialized
INFO - 2024-01-05 08:48:53 --> Router Class Initialized
INFO - 2024-01-05 08:48:53 --> Output Class Initialized
INFO - 2024-01-05 08:48:53 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:53 --> Input Class Initialized
INFO - 2024-01-05 08:48:53 --> Language Class Initialized
INFO - 2024-01-05 08:48:53 --> Language Class Initialized
INFO - 2024-01-05 08:48:53 --> Config Class Initialized
INFO - 2024-01-05 08:48:53 --> Loader Class Initialized
INFO - 2024-01-05 08:48:53 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:53 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:53 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:53 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:53 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:53 --> Controller Class Initialized
DEBUG - 2024-01-05 08:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 08:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:48:53 --> Final output sent to browser
DEBUG - 2024-01-05 08:48:53 --> Total execution time: 0.0372
INFO - 2024-01-05 08:48:53 --> Config Class Initialized
INFO - 2024-01-05 08:48:53 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:53 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:53 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:53 --> URI Class Initialized
INFO - 2024-01-05 08:48:53 --> Router Class Initialized
INFO - 2024-01-05 08:48:53 --> Output Class Initialized
INFO - 2024-01-05 08:48:53 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:53 --> Input Class Initialized
INFO - 2024-01-05 08:48:53 --> Language Class Initialized
INFO - 2024-01-05 08:48:53 --> Language Class Initialized
INFO - 2024-01-05 08:48:53 --> Config Class Initialized
INFO - 2024-01-05 08:48:53 --> Loader Class Initialized
INFO - 2024-01-05 08:48:53 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:53 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:53 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:53 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:53 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:53 --> Controller Class Initialized
INFO - 2024-01-05 08:48:54 --> Config Class Initialized
INFO - 2024-01-05 08:48:54 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:48:54 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:48:54 --> Utf8 Class Initialized
INFO - 2024-01-05 08:48:54 --> URI Class Initialized
INFO - 2024-01-05 08:48:54 --> Router Class Initialized
INFO - 2024-01-05 08:48:54 --> Output Class Initialized
INFO - 2024-01-05 08:48:54 --> Security Class Initialized
DEBUG - 2024-01-05 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:48:54 --> Input Class Initialized
INFO - 2024-01-05 08:48:54 --> Language Class Initialized
INFO - 2024-01-05 08:48:54 --> Language Class Initialized
INFO - 2024-01-05 08:48:54 --> Config Class Initialized
INFO - 2024-01-05 08:48:54 --> Loader Class Initialized
INFO - 2024-01-05 08:48:54 --> Helper loaded: url_helper
INFO - 2024-01-05 08:48:54 --> Helper loaded: file_helper
INFO - 2024-01-05 08:48:54 --> Helper loaded: form_helper
INFO - 2024-01-05 08:48:54 --> Helper loaded: my_helper
INFO - 2024-01-05 08:48:54 --> Database Driver Class Initialized
INFO - 2024-01-05 08:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:48:54 --> Controller Class Initialized
INFO - 2024-01-05 08:52:21 --> Config Class Initialized
INFO - 2024-01-05 08:52:21 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:21 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:21 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:21 --> URI Class Initialized
INFO - 2024-01-05 08:52:21 --> Router Class Initialized
INFO - 2024-01-05 08:52:21 --> Output Class Initialized
INFO - 2024-01-05 08:52:21 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:21 --> Input Class Initialized
INFO - 2024-01-05 08:52:21 --> Language Class Initialized
INFO - 2024-01-05 08:52:21 --> Language Class Initialized
INFO - 2024-01-05 08:52:21 --> Config Class Initialized
INFO - 2024-01-05 08:52:21 --> Loader Class Initialized
INFO - 2024-01-05 08:52:21 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:21 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:21 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:21 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:21 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:21 --> Controller Class Initialized
DEBUG - 2024-01-05 08:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 08:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:52:21 --> Final output sent to browser
DEBUG - 2024-01-05 08:52:21 --> Total execution time: 0.0533
INFO - 2024-01-05 08:52:21 --> Config Class Initialized
INFO - 2024-01-05 08:52:21 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:21 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:21 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:21 --> URI Class Initialized
INFO - 2024-01-05 08:52:21 --> Router Class Initialized
INFO - 2024-01-05 08:52:21 --> Output Class Initialized
INFO - 2024-01-05 08:52:21 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:21 --> Input Class Initialized
INFO - 2024-01-05 08:52:21 --> Language Class Initialized
INFO - 2024-01-05 08:52:21 --> Language Class Initialized
INFO - 2024-01-05 08:52:21 --> Config Class Initialized
INFO - 2024-01-05 08:52:21 --> Loader Class Initialized
INFO - 2024-01-05 08:52:21 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:21 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:21 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:21 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:21 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:21 --> Controller Class Initialized
INFO - 2024-01-05 08:52:28 --> Config Class Initialized
INFO - 2024-01-05 08:52:28 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:28 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:28 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:28 --> URI Class Initialized
INFO - 2024-01-05 08:52:28 --> Router Class Initialized
INFO - 2024-01-05 08:52:28 --> Output Class Initialized
INFO - 2024-01-05 08:52:28 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:28 --> Input Class Initialized
INFO - 2024-01-05 08:52:28 --> Language Class Initialized
INFO - 2024-01-05 08:52:28 --> Language Class Initialized
INFO - 2024-01-05 08:52:28 --> Config Class Initialized
INFO - 2024-01-05 08:52:28 --> Loader Class Initialized
INFO - 2024-01-05 08:52:28 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:28 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:28 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:28 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:28 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:28 --> Controller Class Initialized
INFO - 2024-01-05 08:52:33 --> Config Class Initialized
INFO - 2024-01-05 08:52:33 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:33 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:33 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:33 --> URI Class Initialized
INFO - 2024-01-05 08:52:33 --> Router Class Initialized
INFO - 2024-01-05 08:52:33 --> Output Class Initialized
INFO - 2024-01-05 08:52:33 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:33 --> Input Class Initialized
INFO - 2024-01-05 08:52:33 --> Language Class Initialized
INFO - 2024-01-05 08:52:33 --> Language Class Initialized
INFO - 2024-01-05 08:52:33 --> Config Class Initialized
INFO - 2024-01-05 08:52:33 --> Loader Class Initialized
INFO - 2024-01-05 08:52:33 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:33 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:33 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:33 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:33 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:33 --> Controller Class Initialized
DEBUG - 2024-01-05 08:52:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 08:52:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:52:33 --> Final output sent to browser
DEBUG - 2024-01-05 08:52:33 --> Total execution time: 0.0334
INFO - 2024-01-05 08:52:34 --> Config Class Initialized
INFO - 2024-01-05 08:52:34 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:34 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:34 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:34 --> URI Class Initialized
INFO - 2024-01-05 08:52:34 --> Router Class Initialized
INFO - 2024-01-05 08:52:34 --> Output Class Initialized
INFO - 2024-01-05 08:52:34 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:34 --> Input Class Initialized
INFO - 2024-01-05 08:52:34 --> Language Class Initialized
INFO - 2024-01-05 08:52:34 --> Language Class Initialized
INFO - 2024-01-05 08:52:34 --> Config Class Initialized
INFO - 2024-01-05 08:52:34 --> Loader Class Initialized
INFO - 2024-01-05 08:52:34 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:34 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:34 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:34 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:34 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:34 --> Controller Class Initialized
INFO - 2024-01-05 08:52:47 --> Config Class Initialized
INFO - 2024-01-05 08:52:47 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:47 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:47 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:47 --> URI Class Initialized
INFO - 2024-01-05 08:52:47 --> Router Class Initialized
INFO - 2024-01-05 08:52:47 --> Output Class Initialized
INFO - 2024-01-05 08:52:47 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:47 --> Input Class Initialized
INFO - 2024-01-05 08:52:47 --> Language Class Initialized
INFO - 2024-01-05 08:52:47 --> Language Class Initialized
INFO - 2024-01-05 08:52:47 --> Config Class Initialized
INFO - 2024-01-05 08:52:47 --> Loader Class Initialized
INFO - 2024-01-05 08:52:47 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:47 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:47 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:47 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:47 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:47 --> Controller Class Initialized
INFO - 2024-01-05 08:52:47 --> Final output sent to browser
DEBUG - 2024-01-05 08:52:47 --> Total execution time: 0.0414
INFO - 2024-01-05 08:52:56 --> Config Class Initialized
INFO - 2024-01-05 08:52:56 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:52:56 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:52:56 --> Utf8 Class Initialized
INFO - 2024-01-05 08:52:56 --> URI Class Initialized
INFO - 2024-01-05 08:52:56 --> Router Class Initialized
INFO - 2024-01-05 08:52:56 --> Output Class Initialized
INFO - 2024-01-05 08:52:56 --> Security Class Initialized
DEBUG - 2024-01-05 08:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:52:56 --> Input Class Initialized
INFO - 2024-01-05 08:52:56 --> Language Class Initialized
INFO - 2024-01-05 08:52:56 --> Language Class Initialized
INFO - 2024-01-05 08:52:56 --> Config Class Initialized
INFO - 2024-01-05 08:52:56 --> Loader Class Initialized
INFO - 2024-01-05 08:52:56 --> Helper loaded: url_helper
INFO - 2024-01-05 08:52:56 --> Helper loaded: file_helper
INFO - 2024-01-05 08:52:56 --> Helper loaded: form_helper
INFO - 2024-01-05 08:52:56 --> Helper loaded: my_helper
INFO - 2024-01-05 08:52:56 --> Database Driver Class Initialized
INFO - 2024-01-05 08:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:52:56 --> Controller Class Initialized
INFO - 2024-01-05 08:53:40 --> Config Class Initialized
INFO - 2024-01-05 08:53:40 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:53:40 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:53:40 --> Utf8 Class Initialized
INFO - 2024-01-05 08:53:40 --> URI Class Initialized
INFO - 2024-01-05 08:53:40 --> Router Class Initialized
INFO - 2024-01-05 08:53:40 --> Output Class Initialized
INFO - 2024-01-05 08:53:40 --> Security Class Initialized
DEBUG - 2024-01-05 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:53:40 --> Input Class Initialized
INFO - 2024-01-05 08:53:40 --> Language Class Initialized
INFO - 2024-01-05 08:53:40 --> Language Class Initialized
INFO - 2024-01-05 08:53:40 --> Config Class Initialized
INFO - 2024-01-05 08:53:40 --> Loader Class Initialized
INFO - 2024-01-05 08:53:40 --> Helper loaded: url_helper
INFO - 2024-01-05 08:53:40 --> Helper loaded: file_helper
INFO - 2024-01-05 08:53:40 --> Helper loaded: form_helper
INFO - 2024-01-05 08:53:40 --> Helper loaded: my_helper
INFO - 2024-01-05 08:53:40 --> Database Driver Class Initialized
INFO - 2024-01-05 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:53:40 --> Controller Class Initialized
DEBUG - 2024-01-05 08:53:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 08:53:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:53:40 --> Final output sent to browser
DEBUG - 2024-01-05 08:53:40 --> Total execution time: 0.0322
INFO - 2024-01-05 08:53:41 --> Config Class Initialized
INFO - 2024-01-05 08:53:41 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:53:41 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:53:41 --> Utf8 Class Initialized
INFO - 2024-01-05 08:53:41 --> URI Class Initialized
INFO - 2024-01-05 08:53:41 --> Router Class Initialized
INFO - 2024-01-05 08:53:41 --> Output Class Initialized
INFO - 2024-01-05 08:53:41 --> Security Class Initialized
DEBUG - 2024-01-05 08:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:53:41 --> Input Class Initialized
INFO - 2024-01-05 08:53:41 --> Language Class Initialized
INFO - 2024-01-05 08:53:41 --> Language Class Initialized
INFO - 2024-01-05 08:53:41 --> Config Class Initialized
INFO - 2024-01-05 08:53:41 --> Loader Class Initialized
INFO - 2024-01-05 08:53:41 --> Helper loaded: url_helper
INFO - 2024-01-05 08:53:41 --> Helper loaded: file_helper
INFO - 2024-01-05 08:53:41 --> Helper loaded: form_helper
INFO - 2024-01-05 08:53:41 --> Helper loaded: my_helper
INFO - 2024-01-05 08:53:41 --> Database Driver Class Initialized
INFO - 2024-01-05 08:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:53:41 --> Controller Class Initialized
INFO - 2024-01-05 08:53:51 --> Config Class Initialized
INFO - 2024-01-05 08:53:51 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:53:51 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:53:51 --> Utf8 Class Initialized
INFO - 2024-01-05 08:53:51 --> URI Class Initialized
INFO - 2024-01-05 08:53:51 --> Router Class Initialized
INFO - 2024-01-05 08:53:51 --> Output Class Initialized
INFO - 2024-01-05 08:53:51 --> Security Class Initialized
DEBUG - 2024-01-05 08:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:53:51 --> Input Class Initialized
INFO - 2024-01-05 08:53:51 --> Language Class Initialized
INFO - 2024-01-05 08:53:51 --> Language Class Initialized
INFO - 2024-01-05 08:53:51 --> Config Class Initialized
INFO - 2024-01-05 08:53:51 --> Loader Class Initialized
INFO - 2024-01-05 08:53:51 --> Helper loaded: url_helper
INFO - 2024-01-05 08:53:51 --> Helper loaded: file_helper
INFO - 2024-01-05 08:53:51 --> Helper loaded: form_helper
INFO - 2024-01-05 08:53:51 --> Helper loaded: my_helper
INFO - 2024-01-05 08:53:52 --> Database Driver Class Initialized
INFO - 2024-01-05 08:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:53:52 --> Controller Class Initialized
INFO - 2024-01-05 08:53:52 --> Config Class Initialized
INFO - 2024-01-05 08:53:52 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:53:52 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:53:52 --> Utf8 Class Initialized
INFO - 2024-01-05 08:53:52 --> URI Class Initialized
INFO - 2024-01-05 08:53:52 --> Router Class Initialized
INFO - 2024-01-05 08:53:52 --> Output Class Initialized
INFO - 2024-01-05 08:53:52 --> Security Class Initialized
DEBUG - 2024-01-05 08:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:53:52 --> Input Class Initialized
INFO - 2024-01-05 08:53:52 --> Language Class Initialized
INFO - 2024-01-05 08:53:52 --> Language Class Initialized
INFO - 2024-01-05 08:53:52 --> Config Class Initialized
INFO - 2024-01-05 08:53:52 --> Loader Class Initialized
INFO - 2024-01-05 08:53:52 --> Helper loaded: url_helper
INFO - 2024-01-05 08:53:52 --> Helper loaded: file_helper
INFO - 2024-01-05 08:53:52 --> Helper loaded: form_helper
INFO - 2024-01-05 08:53:52 --> Helper loaded: my_helper
INFO - 2024-01-05 08:53:52 --> Database Driver Class Initialized
INFO - 2024-01-05 08:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:53:52 --> Controller Class Initialized
DEBUG - 2024-01-05 08:53:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-05 08:53:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:53:52 --> Final output sent to browser
DEBUG - 2024-01-05 08:53:52 --> Total execution time: 0.0344
INFO - 2024-01-05 08:54:06 --> Config Class Initialized
INFO - 2024-01-05 08:54:06 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:06 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:06 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:06 --> URI Class Initialized
INFO - 2024-01-05 08:54:06 --> Router Class Initialized
INFO - 2024-01-05 08:54:06 --> Output Class Initialized
INFO - 2024-01-05 08:54:06 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:06 --> Input Class Initialized
INFO - 2024-01-05 08:54:06 --> Language Class Initialized
INFO - 2024-01-05 08:54:06 --> Language Class Initialized
INFO - 2024-01-05 08:54:06 --> Config Class Initialized
INFO - 2024-01-05 08:54:06 --> Loader Class Initialized
INFO - 2024-01-05 08:54:06 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:06 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:06 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:06 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:06 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:06 --> Controller Class Initialized
INFO - 2024-01-05 08:54:06 --> Final output sent to browser
DEBUG - 2024-01-05 08:54:06 --> Total execution time: 0.0405
INFO - 2024-01-05 08:54:19 --> Config Class Initialized
INFO - 2024-01-05 08:54:19 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:19 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:19 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:19 --> URI Class Initialized
INFO - 2024-01-05 08:54:19 --> Router Class Initialized
INFO - 2024-01-05 08:54:19 --> Output Class Initialized
INFO - 2024-01-05 08:54:19 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:19 --> Input Class Initialized
INFO - 2024-01-05 08:54:19 --> Language Class Initialized
INFO - 2024-01-05 08:54:19 --> Language Class Initialized
INFO - 2024-01-05 08:54:19 --> Config Class Initialized
INFO - 2024-01-05 08:54:19 --> Loader Class Initialized
INFO - 2024-01-05 08:54:19 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:19 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:19 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:19 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:19 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:19 --> Controller Class Initialized
INFO - 2024-01-05 08:54:19 --> Helper loaded: cookie_helper
INFO - 2024-01-05 08:54:19 --> Final output sent to browser
DEBUG - 2024-01-05 08:54:19 --> Total execution time: 0.0393
INFO - 2024-01-05 08:54:19 --> Config Class Initialized
INFO - 2024-01-05 08:54:19 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:19 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:19 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:19 --> URI Class Initialized
INFO - 2024-01-05 08:54:19 --> Router Class Initialized
INFO - 2024-01-05 08:54:19 --> Output Class Initialized
INFO - 2024-01-05 08:54:19 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:19 --> Input Class Initialized
INFO - 2024-01-05 08:54:19 --> Language Class Initialized
INFO - 2024-01-05 08:54:19 --> Language Class Initialized
INFO - 2024-01-05 08:54:19 --> Config Class Initialized
INFO - 2024-01-05 08:54:19 --> Loader Class Initialized
INFO - 2024-01-05 08:54:19 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:19 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:19 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:19 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:19 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:19 --> Controller Class Initialized
DEBUG - 2024-01-05 08:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-05 08:54:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:54:19 --> Final output sent to browser
DEBUG - 2024-01-05 08:54:19 --> Total execution time: 0.0327
INFO - 2024-01-05 08:54:25 --> Config Class Initialized
INFO - 2024-01-05 08:54:25 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:25 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:25 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:25 --> URI Class Initialized
INFO - 2024-01-05 08:54:25 --> Router Class Initialized
INFO - 2024-01-05 08:54:25 --> Output Class Initialized
INFO - 2024-01-05 08:54:25 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:25 --> Input Class Initialized
INFO - 2024-01-05 08:54:25 --> Language Class Initialized
INFO - 2024-01-05 08:54:25 --> Language Class Initialized
INFO - 2024-01-05 08:54:25 --> Config Class Initialized
INFO - 2024-01-05 08:54:25 --> Loader Class Initialized
INFO - 2024-01-05 08:54:25 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:25 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:25 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:25 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:25 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:25 --> Controller Class Initialized
DEBUG - 2024-01-05 08:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-05 08:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:54:25 --> Final output sent to browser
DEBUG - 2024-01-05 08:54:25 --> Total execution time: 0.0368
INFO - 2024-01-05 08:54:27 --> Config Class Initialized
INFO - 2024-01-05 08:54:27 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:27 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:27 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:27 --> URI Class Initialized
INFO - 2024-01-05 08:54:27 --> Router Class Initialized
INFO - 2024-01-05 08:54:27 --> Output Class Initialized
INFO - 2024-01-05 08:54:27 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:27 --> Input Class Initialized
INFO - 2024-01-05 08:54:27 --> Language Class Initialized
INFO - 2024-01-05 08:54:27 --> Language Class Initialized
INFO - 2024-01-05 08:54:27 --> Config Class Initialized
INFO - 2024-01-05 08:54:27 --> Loader Class Initialized
INFO - 2024-01-05 08:54:27 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:27 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:27 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:27 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:27 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:27 --> Controller Class Initialized
DEBUG - 2024-01-05 08:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 08:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 08:54:27 --> Final output sent to browser
DEBUG - 2024-01-05 08:54:27 --> Total execution time: 0.0372
INFO - 2024-01-05 08:54:27 --> Config Class Initialized
INFO - 2024-01-05 08:54:27 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:27 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:27 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:27 --> URI Class Initialized
INFO - 2024-01-05 08:54:27 --> Router Class Initialized
INFO - 2024-01-05 08:54:27 --> Output Class Initialized
INFO - 2024-01-05 08:54:27 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:27 --> Input Class Initialized
INFO - 2024-01-05 08:54:27 --> Language Class Initialized
INFO - 2024-01-05 08:54:27 --> Language Class Initialized
INFO - 2024-01-05 08:54:27 --> Config Class Initialized
INFO - 2024-01-05 08:54:27 --> Loader Class Initialized
INFO - 2024-01-05 08:54:27 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:27 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:27 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:27 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:27 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:27 --> Controller Class Initialized
INFO - 2024-01-05 08:54:30 --> Config Class Initialized
INFO - 2024-01-05 08:54:30 --> Hooks Class Initialized
DEBUG - 2024-01-05 08:54:30 --> UTF-8 Support Enabled
INFO - 2024-01-05 08:54:30 --> Utf8 Class Initialized
INFO - 2024-01-05 08:54:30 --> URI Class Initialized
INFO - 2024-01-05 08:54:30 --> Router Class Initialized
INFO - 2024-01-05 08:54:30 --> Output Class Initialized
INFO - 2024-01-05 08:54:30 --> Security Class Initialized
DEBUG - 2024-01-05 08:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 08:54:30 --> Input Class Initialized
INFO - 2024-01-05 08:54:30 --> Language Class Initialized
INFO - 2024-01-05 08:54:30 --> Language Class Initialized
INFO - 2024-01-05 08:54:30 --> Config Class Initialized
INFO - 2024-01-05 08:54:30 --> Loader Class Initialized
INFO - 2024-01-05 08:54:30 --> Helper loaded: url_helper
INFO - 2024-01-05 08:54:30 --> Helper loaded: file_helper
INFO - 2024-01-05 08:54:30 --> Helper loaded: form_helper
INFO - 2024-01-05 08:54:30 --> Helper loaded: my_helper
INFO - 2024-01-05 08:54:30 --> Database Driver Class Initialized
INFO - 2024-01-05 08:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 08:54:30 --> Controller Class Initialized
INFO - 2024-01-05 09:06:47 --> Config Class Initialized
INFO - 2024-01-05 09:06:47 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:47 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:47 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:47 --> URI Class Initialized
INFO - 2024-01-05 09:06:47 --> Router Class Initialized
INFO - 2024-01-05 09:06:47 --> Output Class Initialized
INFO - 2024-01-05 09:06:47 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:47 --> Input Class Initialized
INFO - 2024-01-05 09:06:47 --> Language Class Initialized
INFO - 2024-01-05 09:06:47 --> Language Class Initialized
INFO - 2024-01-05 09:06:47 --> Config Class Initialized
INFO - 2024-01-05 09:06:47 --> Loader Class Initialized
INFO - 2024-01-05 09:06:47 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:47 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:47 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:47 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:47 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:47 --> Controller Class Initialized
DEBUG - 2024-01-05 09:06:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 09:06:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:06:47 --> Final output sent to browser
DEBUG - 2024-01-05 09:06:47 --> Total execution time: 0.0482
INFO - 2024-01-05 09:06:47 --> Config Class Initialized
INFO - 2024-01-05 09:06:47 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:47 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:47 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:47 --> URI Class Initialized
INFO - 2024-01-05 09:06:47 --> Router Class Initialized
INFO - 2024-01-05 09:06:47 --> Output Class Initialized
INFO - 2024-01-05 09:06:47 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:47 --> Input Class Initialized
INFO - 2024-01-05 09:06:47 --> Language Class Initialized
INFO - 2024-01-05 09:06:47 --> Language Class Initialized
INFO - 2024-01-05 09:06:47 --> Config Class Initialized
INFO - 2024-01-05 09:06:47 --> Loader Class Initialized
INFO - 2024-01-05 09:06:47 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:47 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:47 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:47 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:47 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:47 --> Controller Class Initialized
INFO - 2024-01-05 09:06:50 --> Config Class Initialized
INFO - 2024-01-05 09:06:50 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:50 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:50 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:50 --> URI Class Initialized
INFO - 2024-01-05 09:06:50 --> Router Class Initialized
INFO - 2024-01-05 09:06:50 --> Output Class Initialized
INFO - 2024-01-05 09:06:50 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:50 --> Input Class Initialized
INFO - 2024-01-05 09:06:50 --> Language Class Initialized
INFO - 2024-01-05 09:06:50 --> Language Class Initialized
INFO - 2024-01-05 09:06:50 --> Config Class Initialized
INFO - 2024-01-05 09:06:50 --> Loader Class Initialized
INFO - 2024-01-05 09:06:50 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:50 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:50 --> Controller Class Initialized
INFO - 2024-01-05 09:06:50 --> Helper loaded: cookie_helper
INFO - 2024-01-05 09:06:50 --> Config Class Initialized
INFO - 2024-01-05 09:06:50 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:50 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:50 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:50 --> URI Class Initialized
INFO - 2024-01-05 09:06:50 --> Router Class Initialized
INFO - 2024-01-05 09:06:50 --> Output Class Initialized
INFO - 2024-01-05 09:06:50 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:50 --> Input Class Initialized
INFO - 2024-01-05 09:06:50 --> Language Class Initialized
INFO - 2024-01-05 09:06:50 --> Language Class Initialized
INFO - 2024-01-05 09:06:50 --> Config Class Initialized
INFO - 2024-01-05 09:06:50 --> Loader Class Initialized
INFO - 2024-01-05 09:06:50 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:50 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:50 --> Controller Class Initialized
INFO - 2024-01-05 09:06:50 --> Config Class Initialized
INFO - 2024-01-05 09:06:50 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:50 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:50 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:50 --> URI Class Initialized
INFO - 2024-01-05 09:06:50 --> Router Class Initialized
INFO - 2024-01-05 09:06:50 --> Output Class Initialized
INFO - 2024-01-05 09:06:50 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:50 --> Input Class Initialized
INFO - 2024-01-05 09:06:50 --> Language Class Initialized
INFO - 2024-01-05 09:06:50 --> Language Class Initialized
INFO - 2024-01-05 09:06:50 --> Config Class Initialized
INFO - 2024-01-05 09:06:50 --> Loader Class Initialized
INFO - 2024-01-05 09:06:50 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:50 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:50 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:50 --> Controller Class Initialized
DEBUG - 2024-01-05 09:06:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-05 09:06:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:06:50 --> Final output sent to browser
DEBUG - 2024-01-05 09:06:50 --> Total execution time: 0.0327
INFO - 2024-01-05 09:06:56 --> Config Class Initialized
INFO - 2024-01-05 09:06:56 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:56 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:56 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:56 --> URI Class Initialized
INFO - 2024-01-05 09:06:56 --> Router Class Initialized
INFO - 2024-01-05 09:06:56 --> Output Class Initialized
INFO - 2024-01-05 09:06:56 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:56 --> Input Class Initialized
INFO - 2024-01-05 09:06:56 --> Language Class Initialized
INFO - 2024-01-05 09:06:56 --> Language Class Initialized
INFO - 2024-01-05 09:06:56 --> Config Class Initialized
INFO - 2024-01-05 09:06:56 --> Loader Class Initialized
INFO - 2024-01-05 09:06:56 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:56 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:56 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:56 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:56 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:56 --> Controller Class Initialized
INFO - 2024-01-05 09:06:56 --> Helper loaded: cookie_helper
INFO - 2024-01-05 09:06:56 --> Final output sent to browser
DEBUG - 2024-01-05 09:06:56 --> Total execution time: 0.0313
INFO - 2024-01-05 09:06:56 --> Config Class Initialized
INFO - 2024-01-05 09:06:56 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:06:56 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:06:56 --> Utf8 Class Initialized
INFO - 2024-01-05 09:06:56 --> URI Class Initialized
INFO - 2024-01-05 09:06:56 --> Router Class Initialized
INFO - 2024-01-05 09:06:56 --> Output Class Initialized
INFO - 2024-01-05 09:06:56 --> Security Class Initialized
DEBUG - 2024-01-05 09:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:06:56 --> Input Class Initialized
INFO - 2024-01-05 09:06:56 --> Language Class Initialized
INFO - 2024-01-05 09:06:56 --> Language Class Initialized
INFO - 2024-01-05 09:06:56 --> Config Class Initialized
INFO - 2024-01-05 09:06:56 --> Loader Class Initialized
INFO - 2024-01-05 09:06:56 --> Helper loaded: url_helper
INFO - 2024-01-05 09:06:56 --> Helper loaded: file_helper
INFO - 2024-01-05 09:06:56 --> Helper loaded: form_helper
INFO - 2024-01-05 09:06:56 --> Helper loaded: my_helper
INFO - 2024-01-05 09:06:56 --> Database Driver Class Initialized
INFO - 2024-01-05 09:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:06:56 --> Controller Class Initialized
DEBUG - 2024-01-05 09:06:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-05 09:06:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:06:56 --> Final output sent to browser
DEBUG - 2024-01-05 09:06:56 --> Total execution time: 0.0337
INFO - 2024-01-05 09:07:00 --> Config Class Initialized
INFO - 2024-01-05 09:07:00 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:00 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:00 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:00 --> URI Class Initialized
INFO - 2024-01-05 09:07:00 --> Router Class Initialized
INFO - 2024-01-05 09:07:00 --> Output Class Initialized
INFO - 2024-01-05 09:07:00 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:00 --> Input Class Initialized
INFO - 2024-01-05 09:07:00 --> Language Class Initialized
INFO - 2024-01-05 09:07:00 --> Language Class Initialized
INFO - 2024-01-05 09:07:00 --> Config Class Initialized
INFO - 2024-01-05 09:07:00 --> Loader Class Initialized
INFO - 2024-01-05 09:07:00 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:00 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:00 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:00 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:00 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:00 --> Controller Class Initialized
DEBUG - 2024-01-05 09:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-05 09:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:07:00 --> Final output sent to browser
DEBUG - 2024-01-05 09:07:00 --> Total execution time: 0.0350
INFO - 2024-01-05 09:07:02 --> Config Class Initialized
INFO - 2024-01-05 09:07:02 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:02 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:02 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:02 --> URI Class Initialized
INFO - 2024-01-05 09:07:02 --> Router Class Initialized
INFO - 2024-01-05 09:07:02 --> Output Class Initialized
INFO - 2024-01-05 09:07:02 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:02 --> Input Class Initialized
INFO - 2024-01-05 09:07:02 --> Language Class Initialized
INFO - 2024-01-05 09:07:02 --> Language Class Initialized
INFO - 2024-01-05 09:07:02 --> Config Class Initialized
INFO - 2024-01-05 09:07:02 --> Loader Class Initialized
INFO - 2024-01-05 09:07:02 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:02 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:02 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:02 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:02 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:02 --> Controller Class Initialized
DEBUG - 2024-01-05 09:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 09:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:07:02 --> Final output sent to browser
DEBUG - 2024-01-05 09:07:02 --> Total execution time: 0.0406
INFO - 2024-01-05 09:07:02 --> Config Class Initialized
INFO - 2024-01-05 09:07:02 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:02 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:02 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:02 --> URI Class Initialized
INFO - 2024-01-05 09:07:02 --> Router Class Initialized
INFO - 2024-01-05 09:07:02 --> Output Class Initialized
INFO - 2024-01-05 09:07:02 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:02 --> Input Class Initialized
INFO - 2024-01-05 09:07:02 --> Language Class Initialized
INFO - 2024-01-05 09:07:02 --> Language Class Initialized
INFO - 2024-01-05 09:07:02 --> Config Class Initialized
INFO - 2024-01-05 09:07:02 --> Loader Class Initialized
INFO - 2024-01-05 09:07:02 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:02 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:02 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:02 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:02 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:02 --> Controller Class Initialized
INFO - 2024-01-05 09:07:05 --> Config Class Initialized
INFO - 2024-01-05 09:07:05 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:05 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:05 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:05 --> URI Class Initialized
INFO - 2024-01-05 09:07:05 --> Router Class Initialized
INFO - 2024-01-05 09:07:05 --> Output Class Initialized
INFO - 2024-01-05 09:07:05 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:05 --> Input Class Initialized
INFO - 2024-01-05 09:07:05 --> Language Class Initialized
INFO - 2024-01-05 09:07:05 --> Language Class Initialized
INFO - 2024-01-05 09:07:05 --> Config Class Initialized
INFO - 2024-01-05 09:07:05 --> Loader Class Initialized
INFO - 2024-01-05 09:07:05 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:05 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:05 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:05 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:05 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:05 --> Controller Class Initialized
INFO - 2024-01-05 09:07:51 --> Config Class Initialized
INFO - 2024-01-05 09:07:51 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:51 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:51 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:51 --> URI Class Initialized
INFO - 2024-01-05 09:07:51 --> Router Class Initialized
INFO - 2024-01-05 09:07:51 --> Output Class Initialized
INFO - 2024-01-05 09:07:51 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:51 --> Input Class Initialized
INFO - 2024-01-05 09:07:51 --> Language Class Initialized
INFO - 2024-01-05 09:07:51 --> Language Class Initialized
INFO - 2024-01-05 09:07:51 --> Config Class Initialized
INFO - 2024-01-05 09:07:51 --> Loader Class Initialized
INFO - 2024-01-05 09:07:51 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:51 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:51 --> Controller Class Initialized
INFO - 2024-01-05 09:07:51 --> Helper loaded: cookie_helper
INFO - 2024-01-05 09:07:51 --> Config Class Initialized
INFO - 2024-01-05 09:07:51 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:51 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:51 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:51 --> URI Class Initialized
INFO - 2024-01-05 09:07:51 --> Router Class Initialized
INFO - 2024-01-05 09:07:51 --> Output Class Initialized
INFO - 2024-01-05 09:07:51 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:51 --> Input Class Initialized
INFO - 2024-01-05 09:07:51 --> Language Class Initialized
INFO - 2024-01-05 09:07:51 --> Language Class Initialized
INFO - 2024-01-05 09:07:51 --> Config Class Initialized
INFO - 2024-01-05 09:07:51 --> Loader Class Initialized
INFO - 2024-01-05 09:07:51 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:51 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:51 --> Controller Class Initialized
INFO - 2024-01-05 09:07:51 --> Config Class Initialized
INFO - 2024-01-05 09:07:51 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:07:51 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:07:51 --> Utf8 Class Initialized
INFO - 2024-01-05 09:07:51 --> URI Class Initialized
INFO - 2024-01-05 09:07:51 --> Router Class Initialized
INFO - 2024-01-05 09:07:51 --> Output Class Initialized
INFO - 2024-01-05 09:07:51 --> Security Class Initialized
DEBUG - 2024-01-05 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:07:51 --> Input Class Initialized
INFO - 2024-01-05 09:07:51 --> Language Class Initialized
INFO - 2024-01-05 09:07:51 --> Language Class Initialized
INFO - 2024-01-05 09:07:51 --> Config Class Initialized
INFO - 2024-01-05 09:07:51 --> Loader Class Initialized
INFO - 2024-01-05 09:07:51 --> Helper loaded: url_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: file_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: form_helper
INFO - 2024-01-05 09:07:51 --> Helper loaded: my_helper
INFO - 2024-01-05 09:07:51 --> Database Driver Class Initialized
INFO - 2024-01-05 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:07:51 --> Controller Class Initialized
DEBUG - 2024-01-05 09:07:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-05 09:07:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:07:51 --> Final output sent to browser
DEBUG - 2024-01-05 09:07:51 --> Total execution time: 0.0331
INFO - 2024-01-05 09:08:01 --> Config Class Initialized
INFO - 2024-01-05 09:08:01 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:08:01 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:08:01 --> Utf8 Class Initialized
INFO - 2024-01-05 09:08:01 --> URI Class Initialized
INFO - 2024-01-05 09:08:01 --> Router Class Initialized
INFO - 2024-01-05 09:08:01 --> Output Class Initialized
INFO - 2024-01-05 09:08:01 --> Security Class Initialized
DEBUG - 2024-01-05 09:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:08:01 --> Input Class Initialized
INFO - 2024-01-05 09:08:01 --> Language Class Initialized
INFO - 2024-01-05 09:08:01 --> Language Class Initialized
INFO - 2024-01-05 09:08:01 --> Config Class Initialized
INFO - 2024-01-05 09:08:01 --> Loader Class Initialized
INFO - 2024-01-05 09:08:01 --> Helper loaded: url_helper
INFO - 2024-01-05 09:08:01 --> Helper loaded: file_helper
INFO - 2024-01-05 09:08:01 --> Helper loaded: form_helper
INFO - 2024-01-05 09:08:01 --> Helper loaded: my_helper
INFO - 2024-01-05 09:08:01 --> Database Driver Class Initialized
INFO - 2024-01-05 09:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:08:01 --> Controller Class Initialized
INFO - 2024-01-05 09:08:01 --> Helper loaded: cookie_helper
INFO - 2024-01-05 09:08:01 --> Final output sent to browser
DEBUG - 2024-01-05 09:08:01 --> Total execution time: 0.0465
INFO - 2024-01-05 09:08:01 --> Config Class Initialized
INFO - 2024-01-05 09:08:01 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:08:01 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:08:01 --> Utf8 Class Initialized
INFO - 2024-01-05 09:08:01 --> URI Class Initialized
INFO - 2024-01-05 09:08:01 --> Router Class Initialized
INFO - 2024-01-05 09:08:01 --> Output Class Initialized
INFO - 2024-01-05 09:08:01 --> Security Class Initialized
DEBUG - 2024-01-05 09:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:08:01 --> Input Class Initialized
INFO - 2024-01-05 09:08:01 --> Language Class Initialized
INFO - 2024-01-05 09:08:01 --> Language Class Initialized
INFO - 2024-01-05 09:08:01 --> Config Class Initialized
INFO - 2024-01-05 09:08:01 --> Loader Class Initialized
INFO - 2024-01-05 09:08:01 --> Helper loaded: url_helper
INFO - 2024-01-05 09:08:01 --> Helper loaded: file_helper
INFO - 2024-01-05 09:08:01 --> Helper loaded: form_helper
INFO - 2024-01-05 09:08:01 --> Helper loaded: my_helper
INFO - 2024-01-05 09:08:01 --> Database Driver Class Initialized
INFO - 2024-01-05 09:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:08:01 --> Controller Class Initialized
DEBUG - 2024-01-05 09:08:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-01-05 09:08:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:08:01 --> Final output sent to browser
DEBUG - 2024-01-05 09:08:01 --> Total execution time: 0.0501
INFO - 2024-01-05 09:08:05 --> Config Class Initialized
INFO - 2024-01-05 09:08:05 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:08:05 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:08:05 --> Utf8 Class Initialized
INFO - 2024-01-05 09:08:05 --> URI Class Initialized
INFO - 2024-01-05 09:08:05 --> Router Class Initialized
INFO - 2024-01-05 09:08:05 --> Output Class Initialized
INFO - 2024-01-05 09:08:05 --> Security Class Initialized
DEBUG - 2024-01-05 09:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:08:05 --> Input Class Initialized
INFO - 2024-01-05 09:08:05 --> Language Class Initialized
INFO - 2024-01-05 09:08:05 --> Language Class Initialized
INFO - 2024-01-05 09:08:05 --> Config Class Initialized
INFO - 2024-01-05 09:08:05 --> Loader Class Initialized
INFO - 2024-01-05 09:08:05 --> Helper loaded: url_helper
INFO - 2024-01-05 09:08:05 --> Helper loaded: file_helper
INFO - 2024-01-05 09:08:05 --> Helper loaded: form_helper
INFO - 2024-01-05 09:08:05 --> Helper loaded: my_helper
INFO - 2024-01-05 09:08:05 --> Database Driver Class Initialized
INFO - 2024-01-05 09:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:08:05 --> Controller Class Initialized
DEBUG - 2024-01-05 09:08:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-01-05 09:08:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:08:05 --> Final output sent to browser
DEBUG - 2024-01-05 09:08:05 --> Total execution time: 0.0864
INFO - 2024-01-05 09:08:07 --> Config Class Initialized
INFO - 2024-01-05 09:08:07 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:08:07 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:08:07 --> Utf8 Class Initialized
INFO - 2024-01-05 09:08:07 --> URI Class Initialized
INFO - 2024-01-05 09:08:07 --> Router Class Initialized
INFO - 2024-01-05 09:08:07 --> Output Class Initialized
INFO - 2024-01-05 09:08:07 --> Security Class Initialized
DEBUG - 2024-01-05 09:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:08:07 --> Input Class Initialized
INFO - 2024-01-05 09:08:07 --> Language Class Initialized
INFO - 2024-01-05 09:08:07 --> Language Class Initialized
INFO - 2024-01-05 09:08:07 --> Config Class Initialized
INFO - 2024-01-05 09:08:07 --> Loader Class Initialized
INFO - 2024-01-05 09:08:07 --> Helper loaded: url_helper
INFO - 2024-01-05 09:08:07 --> Helper loaded: file_helper
INFO - 2024-01-05 09:08:07 --> Helper loaded: form_helper
INFO - 2024-01-05 09:08:07 --> Helper loaded: my_helper
INFO - 2024-01-05 09:08:07 --> Database Driver Class Initialized
INFO - 2024-01-05 09:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:08:07 --> Controller Class Initialized
DEBUG - 2024-01-05 09:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-01-05 09:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:08:07 --> Final output sent to browser
DEBUG - 2024-01-05 09:08:07 --> Total execution time: 0.0387
INFO - 2024-01-05 09:08:07 --> Config Class Initialized
INFO - 2024-01-05 09:08:07 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:08:07 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:08:07 --> Utf8 Class Initialized
INFO - 2024-01-05 09:08:07 --> URI Class Initialized
INFO - 2024-01-05 09:08:07 --> Router Class Initialized
INFO - 2024-01-05 09:08:07 --> Output Class Initialized
INFO - 2024-01-05 09:08:07 --> Security Class Initialized
DEBUG - 2024-01-05 09:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:08:07 --> Input Class Initialized
INFO - 2024-01-05 09:08:07 --> Language Class Initialized
INFO - 2024-01-05 09:08:07 --> Language Class Initialized
INFO - 2024-01-05 09:08:07 --> Config Class Initialized
INFO - 2024-01-05 09:08:07 --> Loader Class Initialized
INFO - 2024-01-05 09:08:07 --> Helper loaded: url_helper
INFO - 2024-01-05 09:08:07 --> Helper loaded: file_helper
INFO - 2024-01-05 09:08:07 --> Helper loaded: form_helper
INFO - 2024-01-05 09:08:07 --> Helper loaded: my_helper
INFO - 2024-01-05 09:08:07 --> Database Driver Class Initialized
INFO - 2024-01-05 09:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:08:07 --> Controller Class Initialized
INFO - 2024-01-05 09:08:21 --> Config Class Initialized
INFO - 2024-01-05 09:08:21 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:08:21 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:08:21 --> Utf8 Class Initialized
INFO - 2024-01-05 09:08:21 --> URI Class Initialized
INFO - 2024-01-05 09:08:21 --> Router Class Initialized
INFO - 2024-01-05 09:08:21 --> Output Class Initialized
INFO - 2024-01-05 09:08:21 --> Security Class Initialized
DEBUG - 2024-01-05 09:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:08:21 --> Input Class Initialized
INFO - 2024-01-05 09:08:21 --> Language Class Initialized
INFO - 2024-01-05 09:08:21 --> Language Class Initialized
INFO - 2024-01-05 09:08:21 --> Config Class Initialized
INFO - 2024-01-05 09:08:21 --> Loader Class Initialized
INFO - 2024-01-05 09:08:21 --> Helper loaded: url_helper
INFO - 2024-01-05 09:08:21 --> Helper loaded: file_helper
INFO - 2024-01-05 09:08:21 --> Helper loaded: form_helper
INFO - 2024-01-05 09:08:21 --> Helper loaded: my_helper
INFO - 2024-01-05 09:08:21 --> Database Driver Class Initialized
INFO - 2024-01-05 09:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:08:21 --> Controller Class Initialized
INFO - 2024-01-05 09:10:01 --> Config Class Initialized
INFO - 2024-01-05 09:10:01 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:10:01 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:10:01 --> Utf8 Class Initialized
INFO - 2024-01-05 09:10:01 --> URI Class Initialized
INFO - 2024-01-05 09:10:01 --> Router Class Initialized
INFO - 2024-01-05 09:10:01 --> Output Class Initialized
INFO - 2024-01-05 09:10:01 --> Security Class Initialized
DEBUG - 2024-01-05 09:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:10:01 --> Input Class Initialized
INFO - 2024-01-05 09:10:01 --> Language Class Initialized
INFO - 2024-01-05 09:10:01 --> Language Class Initialized
INFO - 2024-01-05 09:10:01 --> Config Class Initialized
INFO - 2024-01-05 09:10:01 --> Loader Class Initialized
INFO - 2024-01-05 09:10:01 --> Helper loaded: url_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: file_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: form_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: my_helper
INFO - 2024-01-05 09:10:01 --> Database Driver Class Initialized
INFO - 2024-01-05 09:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:10:01 --> Controller Class Initialized
INFO - 2024-01-05 09:10:01 --> Helper loaded: cookie_helper
INFO - 2024-01-05 09:10:01 --> Config Class Initialized
INFO - 2024-01-05 09:10:01 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:10:01 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:10:01 --> Utf8 Class Initialized
INFO - 2024-01-05 09:10:01 --> URI Class Initialized
INFO - 2024-01-05 09:10:01 --> Router Class Initialized
INFO - 2024-01-05 09:10:01 --> Output Class Initialized
INFO - 2024-01-05 09:10:01 --> Security Class Initialized
DEBUG - 2024-01-05 09:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:10:01 --> Input Class Initialized
INFO - 2024-01-05 09:10:01 --> Language Class Initialized
INFO - 2024-01-05 09:10:01 --> Language Class Initialized
INFO - 2024-01-05 09:10:01 --> Config Class Initialized
INFO - 2024-01-05 09:10:01 --> Loader Class Initialized
INFO - 2024-01-05 09:10:01 --> Helper loaded: url_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: file_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: form_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: my_helper
INFO - 2024-01-05 09:10:01 --> Database Driver Class Initialized
INFO - 2024-01-05 09:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:10:01 --> Controller Class Initialized
INFO - 2024-01-05 09:10:01 --> Config Class Initialized
INFO - 2024-01-05 09:10:01 --> Hooks Class Initialized
DEBUG - 2024-01-05 09:10:01 --> UTF-8 Support Enabled
INFO - 2024-01-05 09:10:01 --> Utf8 Class Initialized
INFO - 2024-01-05 09:10:01 --> URI Class Initialized
INFO - 2024-01-05 09:10:01 --> Router Class Initialized
INFO - 2024-01-05 09:10:01 --> Output Class Initialized
INFO - 2024-01-05 09:10:01 --> Security Class Initialized
DEBUG - 2024-01-05 09:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-05 09:10:01 --> Input Class Initialized
INFO - 2024-01-05 09:10:01 --> Language Class Initialized
INFO - 2024-01-05 09:10:01 --> Language Class Initialized
INFO - 2024-01-05 09:10:01 --> Config Class Initialized
INFO - 2024-01-05 09:10:01 --> Loader Class Initialized
INFO - 2024-01-05 09:10:01 --> Helper loaded: url_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: file_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: form_helper
INFO - 2024-01-05 09:10:01 --> Helper loaded: my_helper
INFO - 2024-01-05 09:10:01 --> Database Driver Class Initialized
INFO - 2024-01-05 09:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-05 09:10:01 --> Controller Class Initialized
DEBUG - 2024-01-05 09:10:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-05 09:10:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-05 09:10:01 --> Final output sent to browser
DEBUG - 2024-01-05 09:10:01 --> Total execution time: 0.0398
