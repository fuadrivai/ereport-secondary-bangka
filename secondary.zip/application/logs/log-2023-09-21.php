<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-21 18:04:17 --> Config Class Initialized
INFO - 2023-09-21 18:04:17 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:04:17 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:04:17 --> Utf8 Class Initialized
INFO - 2023-09-21 18:04:17 --> URI Class Initialized
INFO - 2023-09-21 18:04:17 --> Router Class Initialized
INFO - 2023-09-21 18:04:17 --> Output Class Initialized
INFO - 2023-09-21 18:04:17 --> Security Class Initialized
DEBUG - 2023-09-21 18:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:04:17 --> Input Class Initialized
INFO - 2023-09-21 18:04:17 --> Language Class Initialized
INFO - 2023-09-21 18:04:17 --> Language Class Initialized
INFO - 2023-09-21 18:04:17 --> Config Class Initialized
INFO - 2023-09-21 18:04:17 --> Loader Class Initialized
INFO - 2023-09-21 18:04:17 --> Helper loaded: url_helper
INFO - 2023-09-21 18:04:17 --> Helper loaded: file_helper
INFO - 2023-09-21 18:04:17 --> Helper loaded: form_helper
INFO - 2023-09-21 18:04:17 --> Helper loaded: my_helper
INFO - 2023-09-21 18:04:17 --> Database Driver Class Initialized
INFO - 2023-09-21 18:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:04:17 --> Controller Class Initialized
DEBUG - 2023-09-21 18:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-21 18:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-21 18:04:18 --> Final output sent to browser
DEBUG - 2023-09-21 18:04:18 --> Total execution time: 0.6786
INFO - 2023-09-21 18:04:26 --> Config Class Initialized
INFO - 2023-09-21 18:04:26 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:04:26 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:04:26 --> Utf8 Class Initialized
INFO - 2023-09-21 18:04:26 --> URI Class Initialized
INFO - 2023-09-21 18:04:26 --> Router Class Initialized
INFO - 2023-09-21 18:04:26 --> Output Class Initialized
INFO - 2023-09-21 18:04:26 --> Security Class Initialized
DEBUG - 2023-09-21 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:04:26 --> Input Class Initialized
INFO - 2023-09-21 18:04:26 --> Language Class Initialized
INFO - 2023-09-21 18:04:26 --> Language Class Initialized
INFO - 2023-09-21 18:04:26 --> Config Class Initialized
INFO - 2023-09-21 18:04:26 --> Loader Class Initialized
INFO - 2023-09-21 18:04:26 --> Helper loaded: url_helper
INFO - 2023-09-21 18:04:26 --> Helper loaded: file_helper
INFO - 2023-09-21 18:04:26 --> Helper loaded: form_helper
INFO - 2023-09-21 18:04:26 --> Helper loaded: my_helper
INFO - 2023-09-21 18:04:26 --> Database Driver Class Initialized
INFO - 2023-09-21 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:04:26 --> Controller Class Initialized
INFO - 2023-09-21 18:04:26 --> Helper loaded: cookie_helper
INFO - 2023-09-21 18:04:26 --> Final output sent to browser
DEBUG - 2023-09-21 18:04:26 --> Total execution time: 0.2577
INFO - 2023-09-21 18:04:27 --> Config Class Initialized
INFO - 2023-09-21 18:04:27 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:04:27 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:04:27 --> Utf8 Class Initialized
INFO - 2023-09-21 18:04:27 --> URI Class Initialized
INFO - 2023-09-21 18:04:27 --> Router Class Initialized
INFO - 2023-09-21 18:04:27 --> Output Class Initialized
INFO - 2023-09-21 18:04:27 --> Security Class Initialized
DEBUG - 2023-09-21 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:04:27 --> Input Class Initialized
INFO - 2023-09-21 18:04:27 --> Language Class Initialized
INFO - 2023-09-21 18:04:27 --> Language Class Initialized
INFO - 2023-09-21 18:04:27 --> Config Class Initialized
INFO - 2023-09-21 18:04:27 --> Loader Class Initialized
INFO - 2023-09-21 18:04:27 --> Helper loaded: url_helper
INFO - 2023-09-21 18:04:27 --> Helper loaded: file_helper
INFO - 2023-09-21 18:04:27 --> Helper loaded: form_helper
INFO - 2023-09-21 18:04:27 --> Helper loaded: my_helper
INFO - 2023-09-21 18:04:27 --> Database Driver Class Initialized
INFO - 2023-09-21 18:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:04:27 --> Controller Class Initialized
DEBUG - 2023-09-21 18:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-21 18:04:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-21 18:04:27 --> Final output sent to browser
DEBUG - 2023-09-21 18:04:27 --> Total execution time: 0.1288
INFO - 2023-09-21 18:05:01 --> Config Class Initialized
INFO - 2023-09-21 18:05:01 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:05:01 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:05:01 --> Utf8 Class Initialized
INFO - 2023-09-21 18:05:01 --> URI Class Initialized
DEBUG - 2023-09-21 18:05:01 --> No URI present. Default controller set.
INFO - 2023-09-21 18:05:01 --> Router Class Initialized
INFO - 2023-09-21 18:05:01 --> Output Class Initialized
INFO - 2023-09-21 18:05:01 --> Security Class Initialized
DEBUG - 2023-09-21 18:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:05:01 --> Input Class Initialized
INFO - 2023-09-21 18:05:01 --> Language Class Initialized
INFO - 2023-09-21 18:05:01 --> Language Class Initialized
INFO - 2023-09-21 18:05:01 --> Config Class Initialized
INFO - 2023-09-21 18:05:01 --> Loader Class Initialized
INFO - 2023-09-21 18:05:01 --> Helper loaded: url_helper
INFO - 2023-09-21 18:05:01 --> Helper loaded: file_helper
INFO - 2023-09-21 18:05:01 --> Helper loaded: form_helper
INFO - 2023-09-21 18:05:01 --> Helper loaded: my_helper
INFO - 2023-09-21 18:05:01 --> Database Driver Class Initialized
INFO - 2023-09-21 18:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:05:01 --> Controller Class Initialized
DEBUG - 2023-09-21 18:05:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-21 18:05:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-21 18:05:01 --> Final output sent to browser
DEBUG - 2023-09-21 18:05:01 --> Total execution time: 0.0736
INFO - 2023-09-21 18:05:04 --> Config Class Initialized
INFO - 2023-09-21 18:05:04 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:05:04 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:05:04 --> Utf8 Class Initialized
INFO - 2023-09-21 18:05:04 --> URI Class Initialized
INFO - 2023-09-21 18:05:04 --> Router Class Initialized
INFO - 2023-09-21 18:05:04 --> Output Class Initialized
INFO - 2023-09-21 18:05:04 --> Security Class Initialized
DEBUG - 2023-09-21 18:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:05:04 --> Input Class Initialized
INFO - 2023-09-21 18:05:04 --> Language Class Initialized
INFO - 2023-09-21 18:05:04 --> Language Class Initialized
INFO - 2023-09-21 18:05:04 --> Config Class Initialized
INFO - 2023-09-21 18:05:04 --> Loader Class Initialized
INFO - 2023-09-21 18:05:04 --> Helper loaded: url_helper
INFO - 2023-09-21 18:05:04 --> Helper loaded: file_helper
INFO - 2023-09-21 18:05:04 --> Helper loaded: form_helper
INFO - 2023-09-21 18:05:04 --> Helper loaded: my_helper
INFO - 2023-09-21 18:05:04 --> Database Driver Class Initialized
INFO - 2023-09-21 18:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:05:04 --> Controller Class Initialized
DEBUG - 2023-09-21 18:05:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-21 18:05:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-21 18:05:04 --> Final output sent to browser
DEBUG - 2023-09-21 18:05:04 --> Total execution time: 0.2784
INFO - 2023-09-21 18:05:08 --> Config Class Initialized
INFO - 2023-09-21 18:05:08 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:05:08 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:05:08 --> Utf8 Class Initialized
INFO - 2023-09-21 18:05:08 --> URI Class Initialized
INFO - 2023-09-21 18:05:08 --> Router Class Initialized
INFO - 2023-09-21 18:05:08 --> Output Class Initialized
INFO - 2023-09-21 18:05:08 --> Security Class Initialized
DEBUG - 2023-09-21 18:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:05:08 --> Input Class Initialized
INFO - 2023-09-21 18:05:08 --> Language Class Initialized
INFO - 2023-09-21 18:05:08 --> Language Class Initialized
INFO - 2023-09-21 18:05:08 --> Config Class Initialized
INFO - 2023-09-21 18:05:08 --> Loader Class Initialized
INFO - 2023-09-21 18:05:08 --> Helper loaded: url_helper
INFO - 2023-09-21 18:05:08 --> Helper loaded: file_helper
INFO - 2023-09-21 18:05:08 --> Helper loaded: form_helper
INFO - 2023-09-21 18:05:08 --> Helper loaded: my_helper
INFO - 2023-09-21 18:05:08 --> Database Driver Class Initialized
INFO - 2023-09-21 18:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:05:08 --> Controller Class Initialized
DEBUG - 2023-09-21 18:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-21 18:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-21 18:05:08 --> Final output sent to browser
DEBUG - 2023-09-21 18:05:08 --> Total execution time: 0.1063
INFO - 2023-09-21 18:05:08 --> Config Class Initialized
INFO - 2023-09-21 18:05:08 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:05:08 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:05:08 --> Utf8 Class Initialized
INFO - 2023-09-21 18:05:08 --> URI Class Initialized
INFO - 2023-09-21 18:05:08 --> Router Class Initialized
INFO - 2023-09-21 18:05:08 --> Output Class Initialized
INFO - 2023-09-21 18:05:08 --> Security Class Initialized
DEBUG - 2023-09-21 18:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:05:08 --> Input Class Initialized
INFO - 2023-09-21 18:05:08 --> Language Class Initialized
INFO - 2023-09-21 18:05:08 --> Language Class Initialized
INFO - 2023-09-21 18:05:08 --> Config Class Initialized
INFO - 2023-09-21 18:05:08 --> Loader Class Initialized
INFO - 2023-09-21 18:05:08 --> Helper loaded: url_helper
INFO - 2023-09-21 18:05:08 --> Helper loaded: file_helper
INFO - 2023-09-21 18:05:08 --> Helper loaded: form_helper
INFO - 2023-09-21 18:05:08 --> Helper loaded: my_helper
INFO - 2023-09-21 18:05:08 --> Database Driver Class Initialized
INFO - 2023-09-21 18:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:05:08 --> Controller Class Initialized
INFO - 2023-09-21 18:06:00 --> Config Class Initialized
INFO - 2023-09-21 18:06:00 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:00 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:00 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:00 --> URI Class Initialized
INFO - 2023-09-21 18:06:00 --> Router Class Initialized
INFO - 2023-09-21 18:06:00 --> Output Class Initialized
INFO - 2023-09-21 18:06:00 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:00 --> Input Class Initialized
INFO - 2023-09-21 18:06:00 --> Language Class Initialized
INFO - 2023-09-21 18:06:00 --> Language Class Initialized
INFO - 2023-09-21 18:06:00 --> Config Class Initialized
INFO - 2023-09-21 18:06:00 --> Loader Class Initialized
INFO - 2023-09-21 18:06:00 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:00 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:00 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:00 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:00 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:00 --> Controller Class Initialized
INFO - 2023-09-21 18:06:00 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:00 --> Total execution time: 0.0481
INFO - 2023-09-21 18:06:06 --> Config Class Initialized
INFO - 2023-09-21 18:06:06 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:06 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:06 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:06 --> URI Class Initialized
INFO - 2023-09-21 18:06:06 --> Router Class Initialized
INFO - 2023-09-21 18:06:06 --> Output Class Initialized
INFO - 2023-09-21 18:06:06 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:06 --> Input Class Initialized
INFO - 2023-09-21 18:06:06 --> Language Class Initialized
INFO - 2023-09-21 18:06:06 --> Language Class Initialized
INFO - 2023-09-21 18:06:06 --> Config Class Initialized
INFO - 2023-09-21 18:06:06 --> Loader Class Initialized
INFO - 2023-09-21 18:06:06 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:06 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:06 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:06 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:06 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:06 --> Controller Class Initialized
INFO - 2023-09-21 18:06:06 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:06 --> Total execution time: 0.2043
INFO - 2023-09-21 18:06:07 --> Config Class Initialized
INFO - 2023-09-21 18:06:07 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:07 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:07 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:07 --> URI Class Initialized
INFO - 2023-09-21 18:06:07 --> Router Class Initialized
INFO - 2023-09-21 18:06:07 --> Output Class Initialized
INFO - 2023-09-21 18:06:07 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:07 --> Input Class Initialized
INFO - 2023-09-21 18:06:07 --> Language Class Initialized
INFO - 2023-09-21 18:06:07 --> Language Class Initialized
INFO - 2023-09-21 18:06:07 --> Config Class Initialized
INFO - 2023-09-21 18:06:07 --> Loader Class Initialized
INFO - 2023-09-21 18:06:07 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:07 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:07 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:07 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:07 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:07 --> Controller Class Initialized
INFO - 2023-09-21 18:06:07 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:07 --> Total execution time: 0.3211
INFO - 2023-09-21 18:06:07 --> Config Class Initialized
INFO - 2023-09-21 18:06:07 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:07 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:07 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:07 --> URI Class Initialized
INFO - 2023-09-21 18:06:07 --> Router Class Initialized
INFO - 2023-09-21 18:06:07 --> Output Class Initialized
INFO - 2023-09-21 18:06:07 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:07 --> Input Class Initialized
INFO - 2023-09-21 18:06:07 --> Language Class Initialized
INFO - 2023-09-21 18:06:07 --> Language Class Initialized
INFO - 2023-09-21 18:06:07 --> Config Class Initialized
INFO - 2023-09-21 18:06:07 --> Loader Class Initialized
INFO - 2023-09-21 18:06:07 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:07 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:07 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:07 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:07 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:08 --> Controller Class Initialized
INFO - 2023-09-21 18:06:08 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:08 --> Total execution time: 0.1166
INFO - 2023-09-21 18:06:08 --> Config Class Initialized
INFO - 2023-09-21 18:06:08 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:08 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:08 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:08 --> URI Class Initialized
INFO - 2023-09-21 18:06:08 --> Router Class Initialized
INFO - 2023-09-21 18:06:08 --> Output Class Initialized
INFO - 2023-09-21 18:06:08 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:08 --> Input Class Initialized
INFO - 2023-09-21 18:06:08 --> Language Class Initialized
INFO - 2023-09-21 18:06:08 --> Language Class Initialized
INFO - 2023-09-21 18:06:08 --> Config Class Initialized
INFO - 2023-09-21 18:06:08 --> Loader Class Initialized
INFO - 2023-09-21 18:06:08 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:08 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:08 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:08 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:08 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:08 --> Controller Class Initialized
INFO - 2023-09-21 18:06:08 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:08 --> Total execution time: 0.0388
INFO - 2023-09-21 18:06:08 --> Config Class Initialized
INFO - 2023-09-21 18:06:08 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:08 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:08 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:08 --> URI Class Initialized
INFO - 2023-09-21 18:06:08 --> Router Class Initialized
INFO - 2023-09-21 18:06:08 --> Output Class Initialized
INFO - 2023-09-21 18:06:08 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:08 --> Input Class Initialized
INFO - 2023-09-21 18:06:08 --> Language Class Initialized
INFO - 2023-09-21 18:06:08 --> Language Class Initialized
INFO - 2023-09-21 18:06:08 --> Config Class Initialized
INFO - 2023-09-21 18:06:08 --> Loader Class Initialized
INFO - 2023-09-21 18:06:08 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:08 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:08 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:08 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:08 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:08 --> Controller Class Initialized
INFO - 2023-09-21 18:06:08 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:08 --> Total execution time: 0.0652
INFO - 2023-09-21 18:06:09 --> Config Class Initialized
INFO - 2023-09-21 18:06:09 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:09 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:09 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:09 --> URI Class Initialized
INFO - 2023-09-21 18:06:09 --> Router Class Initialized
INFO - 2023-09-21 18:06:09 --> Output Class Initialized
INFO - 2023-09-21 18:06:09 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:09 --> Input Class Initialized
INFO - 2023-09-21 18:06:09 --> Language Class Initialized
INFO - 2023-09-21 18:06:09 --> Language Class Initialized
INFO - 2023-09-21 18:06:09 --> Config Class Initialized
INFO - 2023-09-21 18:06:09 --> Loader Class Initialized
INFO - 2023-09-21 18:06:09 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:09 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:09 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:09 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:09 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:09 --> Controller Class Initialized
INFO - 2023-09-21 18:06:09 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:09 --> Total execution time: 0.0618
INFO - 2023-09-21 18:06:10 --> Config Class Initialized
INFO - 2023-09-21 18:06:10 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:10 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:10 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:10 --> URI Class Initialized
INFO - 2023-09-21 18:06:10 --> Router Class Initialized
INFO - 2023-09-21 18:06:10 --> Output Class Initialized
INFO - 2023-09-21 18:06:10 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:10 --> Input Class Initialized
INFO - 2023-09-21 18:06:10 --> Language Class Initialized
INFO - 2023-09-21 18:06:10 --> Language Class Initialized
INFO - 2023-09-21 18:06:10 --> Config Class Initialized
INFO - 2023-09-21 18:06:10 --> Loader Class Initialized
INFO - 2023-09-21 18:06:10 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:10 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:10 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:10 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:10 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:10 --> Controller Class Initialized
INFO - 2023-09-21 18:06:10 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:10 --> Total execution time: 0.0428
INFO - 2023-09-21 18:06:11 --> Config Class Initialized
INFO - 2023-09-21 18:06:11 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:06:11 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:06:11 --> Utf8 Class Initialized
INFO - 2023-09-21 18:06:11 --> URI Class Initialized
INFO - 2023-09-21 18:06:11 --> Router Class Initialized
INFO - 2023-09-21 18:06:11 --> Output Class Initialized
INFO - 2023-09-21 18:06:11 --> Security Class Initialized
DEBUG - 2023-09-21 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:06:11 --> Input Class Initialized
INFO - 2023-09-21 18:06:11 --> Language Class Initialized
INFO - 2023-09-21 18:06:11 --> Language Class Initialized
INFO - 2023-09-21 18:06:11 --> Config Class Initialized
INFO - 2023-09-21 18:06:11 --> Loader Class Initialized
INFO - 2023-09-21 18:06:11 --> Helper loaded: url_helper
INFO - 2023-09-21 18:06:11 --> Helper loaded: file_helper
INFO - 2023-09-21 18:06:11 --> Helper loaded: form_helper
INFO - 2023-09-21 18:06:11 --> Helper loaded: my_helper
INFO - 2023-09-21 18:06:11 --> Database Driver Class Initialized
INFO - 2023-09-21 18:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:06:11 --> Controller Class Initialized
INFO - 2023-09-21 18:06:11 --> Final output sent to browser
DEBUG - 2023-09-21 18:06:11 --> Total execution time: 0.0422
INFO - 2023-09-21 18:07:50 --> Config Class Initialized
INFO - 2023-09-21 18:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:07:50 --> Utf8 Class Initialized
INFO - 2023-09-21 18:07:50 --> URI Class Initialized
INFO - 2023-09-21 18:07:50 --> Router Class Initialized
INFO - 2023-09-21 18:07:50 --> Output Class Initialized
INFO - 2023-09-21 18:07:50 --> Security Class Initialized
DEBUG - 2023-09-21 18:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:07:50 --> Input Class Initialized
INFO - 2023-09-21 18:07:50 --> Language Class Initialized
INFO - 2023-09-21 18:07:50 --> Language Class Initialized
INFO - 2023-09-21 18:07:50 --> Config Class Initialized
INFO - 2023-09-21 18:07:50 --> Loader Class Initialized
INFO - 2023-09-21 18:07:50 --> Helper loaded: url_helper
INFO - 2023-09-21 18:07:50 --> Helper loaded: file_helper
INFO - 2023-09-21 18:07:50 --> Helper loaded: form_helper
INFO - 2023-09-21 18:07:50 --> Helper loaded: my_helper
INFO - 2023-09-21 18:07:50 --> Database Driver Class Initialized
INFO - 2023-09-21 18:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:07:50 --> Controller Class Initialized
INFO - 2023-09-21 18:07:50 --> Final output sent to browser
DEBUG - 2023-09-21 18:07:50 --> Total execution time: 0.0904
INFO - 2023-09-21 18:07:50 --> Config Class Initialized
INFO - 2023-09-21 18:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:07:50 --> Utf8 Class Initialized
INFO - 2023-09-21 18:07:50 --> URI Class Initialized
INFO - 2023-09-21 18:07:50 --> Router Class Initialized
INFO - 2023-09-21 18:07:50 --> Output Class Initialized
INFO - 2023-09-21 18:07:50 --> Security Class Initialized
DEBUG - 2023-09-21 18:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:07:50 --> Input Class Initialized
INFO - 2023-09-21 18:07:50 --> Language Class Initialized
INFO - 2023-09-21 18:07:50 --> Language Class Initialized
INFO - 2023-09-21 18:07:50 --> Config Class Initialized
INFO - 2023-09-21 18:07:50 --> Loader Class Initialized
INFO - 2023-09-21 18:07:50 --> Helper loaded: url_helper
INFO - 2023-09-21 18:07:50 --> Helper loaded: file_helper
INFO - 2023-09-21 18:07:50 --> Helper loaded: form_helper
INFO - 2023-09-21 18:07:50 --> Helper loaded: my_helper
INFO - 2023-09-21 18:07:50 --> Database Driver Class Initialized
INFO - 2023-09-21 18:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:07:50 --> Controller Class Initialized
INFO - 2023-09-21 18:08:14 --> Config Class Initialized
INFO - 2023-09-21 18:08:14 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:14 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:14 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:14 --> URI Class Initialized
INFO - 2023-09-21 18:08:14 --> Router Class Initialized
INFO - 2023-09-21 18:08:14 --> Output Class Initialized
INFO - 2023-09-21 18:08:14 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:14 --> Input Class Initialized
INFO - 2023-09-21 18:08:14 --> Language Class Initialized
INFO - 2023-09-21 18:08:14 --> Language Class Initialized
INFO - 2023-09-21 18:08:14 --> Config Class Initialized
INFO - 2023-09-21 18:08:14 --> Loader Class Initialized
INFO - 2023-09-21 18:08:14 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:14 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:14 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:14 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:14 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:14 --> Controller Class Initialized
INFO - 2023-09-21 18:08:14 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:14 --> Total execution time: 0.0454
INFO - 2023-09-21 18:08:17 --> Config Class Initialized
INFO - 2023-09-21 18:08:17 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:17 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:17 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:17 --> URI Class Initialized
INFO - 2023-09-21 18:08:17 --> Router Class Initialized
INFO - 2023-09-21 18:08:17 --> Output Class Initialized
INFO - 2023-09-21 18:08:17 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:17 --> Input Class Initialized
INFO - 2023-09-21 18:08:17 --> Language Class Initialized
INFO - 2023-09-21 18:08:17 --> Language Class Initialized
INFO - 2023-09-21 18:08:17 --> Config Class Initialized
INFO - 2023-09-21 18:08:17 --> Loader Class Initialized
INFO - 2023-09-21 18:08:17 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:17 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:17 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:17 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:17 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:17 --> Controller Class Initialized
INFO - 2023-09-21 18:08:17 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:17 --> Total execution time: 0.0394
INFO - 2023-09-21 18:08:23 --> Config Class Initialized
INFO - 2023-09-21 18:08:23 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:23 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:23 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:23 --> URI Class Initialized
INFO - 2023-09-21 18:08:23 --> Router Class Initialized
INFO - 2023-09-21 18:08:23 --> Output Class Initialized
INFO - 2023-09-21 18:08:23 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:23 --> Input Class Initialized
INFO - 2023-09-21 18:08:23 --> Language Class Initialized
INFO - 2023-09-21 18:08:23 --> Language Class Initialized
INFO - 2023-09-21 18:08:23 --> Config Class Initialized
INFO - 2023-09-21 18:08:23 --> Loader Class Initialized
INFO - 2023-09-21 18:08:23 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:23 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:23 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:23 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:23 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:24 --> Controller Class Initialized
INFO - 2023-09-21 18:08:24 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:24 --> Total execution time: 0.1179
INFO - 2023-09-21 18:08:26 --> Config Class Initialized
INFO - 2023-09-21 18:08:26 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:26 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:26 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:26 --> URI Class Initialized
INFO - 2023-09-21 18:08:26 --> Router Class Initialized
INFO - 2023-09-21 18:08:26 --> Output Class Initialized
INFO - 2023-09-21 18:08:26 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:26 --> Input Class Initialized
INFO - 2023-09-21 18:08:26 --> Language Class Initialized
INFO - 2023-09-21 18:08:26 --> Language Class Initialized
INFO - 2023-09-21 18:08:26 --> Config Class Initialized
INFO - 2023-09-21 18:08:26 --> Loader Class Initialized
INFO - 2023-09-21 18:08:26 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:26 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:26 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:26 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:26 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:26 --> Controller Class Initialized
INFO - 2023-09-21 18:08:26 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:26 --> Total execution time: 0.0441
INFO - 2023-09-21 18:08:26 --> Config Class Initialized
INFO - 2023-09-21 18:08:26 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:26 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:26 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:26 --> URI Class Initialized
INFO - 2023-09-21 18:08:26 --> Router Class Initialized
INFO - 2023-09-21 18:08:26 --> Output Class Initialized
INFO - 2023-09-21 18:08:26 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:26 --> Input Class Initialized
INFO - 2023-09-21 18:08:26 --> Language Class Initialized
INFO - 2023-09-21 18:08:26 --> Language Class Initialized
INFO - 2023-09-21 18:08:26 --> Config Class Initialized
INFO - 2023-09-21 18:08:26 --> Loader Class Initialized
INFO - 2023-09-21 18:08:26 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:26 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:26 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:26 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:27 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:27 --> Controller Class Initialized
INFO - 2023-09-21 18:08:29 --> Config Class Initialized
INFO - 2023-09-21 18:08:29 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:29 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:29 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:29 --> URI Class Initialized
INFO - 2023-09-21 18:08:29 --> Router Class Initialized
INFO - 2023-09-21 18:08:29 --> Output Class Initialized
INFO - 2023-09-21 18:08:29 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:29 --> Input Class Initialized
INFO - 2023-09-21 18:08:29 --> Language Class Initialized
INFO - 2023-09-21 18:08:29 --> Language Class Initialized
INFO - 2023-09-21 18:08:29 --> Config Class Initialized
INFO - 2023-09-21 18:08:29 --> Loader Class Initialized
INFO - 2023-09-21 18:08:29 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:29 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:29 --> Controller Class Initialized
INFO - 2023-09-21 18:08:29 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:29 --> Total execution time: 0.0836
INFO - 2023-09-21 18:08:29 --> Config Class Initialized
INFO - 2023-09-21 18:08:29 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:29 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:29 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:29 --> URI Class Initialized
INFO - 2023-09-21 18:08:29 --> Router Class Initialized
INFO - 2023-09-21 18:08:29 --> Output Class Initialized
INFO - 2023-09-21 18:08:29 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:29 --> Input Class Initialized
INFO - 2023-09-21 18:08:29 --> Language Class Initialized
INFO - 2023-09-21 18:08:29 --> Language Class Initialized
INFO - 2023-09-21 18:08:29 --> Config Class Initialized
INFO - 2023-09-21 18:08:29 --> Loader Class Initialized
INFO - 2023-09-21 18:08:29 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:29 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:29 --> Controller Class Initialized
INFO - 2023-09-21 18:08:29 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:29 --> Total execution time: 0.0610
INFO - 2023-09-21 18:08:29 --> Config Class Initialized
INFO - 2023-09-21 18:08:29 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:29 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:29 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:29 --> URI Class Initialized
INFO - 2023-09-21 18:08:29 --> Router Class Initialized
INFO - 2023-09-21 18:08:29 --> Output Class Initialized
INFO - 2023-09-21 18:08:29 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:29 --> Input Class Initialized
INFO - 2023-09-21 18:08:29 --> Language Class Initialized
INFO - 2023-09-21 18:08:29 --> Language Class Initialized
INFO - 2023-09-21 18:08:29 --> Config Class Initialized
INFO - 2023-09-21 18:08:29 --> Loader Class Initialized
INFO - 2023-09-21 18:08:29 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:29 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:29 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:29 --> Controller Class Initialized
INFO - 2023-09-21 18:08:29 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:29 --> Total execution time: 0.0560
INFO - 2023-09-21 18:08:30 --> Config Class Initialized
INFO - 2023-09-21 18:08:30 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:30 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:30 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:30 --> URI Class Initialized
INFO - 2023-09-21 18:08:30 --> Router Class Initialized
INFO - 2023-09-21 18:08:30 --> Output Class Initialized
INFO - 2023-09-21 18:08:30 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:30 --> Input Class Initialized
INFO - 2023-09-21 18:08:30 --> Language Class Initialized
INFO - 2023-09-21 18:08:30 --> Language Class Initialized
INFO - 2023-09-21 18:08:30 --> Config Class Initialized
INFO - 2023-09-21 18:08:30 --> Loader Class Initialized
INFO - 2023-09-21 18:08:30 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:30 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:30 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:30 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:30 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:30 --> Controller Class Initialized
INFO - 2023-09-21 18:08:30 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:30 --> Total execution time: 0.0354
INFO - 2023-09-21 18:08:31 --> Config Class Initialized
INFO - 2023-09-21 18:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:31 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:31 --> URI Class Initialized
INFO - 2023-09-21 18:08:31 --> Router Class Initialized
INFO - 2023-09-21 18:08:31 --> Output Class Initialized
INFO - 2023-09-21 18:08:31 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:31 --> Input Class Initialized
INFO - 2023-09-21 18:08:31 --> Language Class Initialized
INFO - 2023-09-21 18:08:31 --> Language Class Initialized
INFO - 2023-09-21 18:08:31 --> Config Class Initialized
INFO - 2023-09-21 18:08:31 --> Loader Class Initialized
INFO - 2023-09-21 18:08:31 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:31 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:31 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:31 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:31 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:31 --> Controller Class Initialized
INFO - 2023-09-21 18:08:31 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:31 --> Total execution time: 0.0587
INFO - 2023-09-21 18:08:33 --> Config Class Initialized
INFO - 2023-09-21 18:08:33 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:33 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:33 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:33 --> URI Class Initialized
INFO - 2023-09-21 18:08:33 --> Router Class Initialized
INFO - 2023-09-21 18:08:33 --> Output Class Initialized
INFO - 2023-09-21 18:08:33 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:33 --> Input Class Initialized
INFO - 2023-09-21 18:08:33 --> Language Class Initialized
INFO - 2023-09-21 18:08:33 --> Language Class Initialized
INFO - 2023-09-21 18:08:33 --> Config Class Initialized
INFO - 2023-09-21 18:08:33 --> Loader Class Initialized
INFO - 2023-09-21 18:08:33 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:33 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:33 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:33 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:33 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:33 --> Controller Class Initialized
INFO - 2023-09-21 18:08:33 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:33 --> Total execution time: 0.1461
INFO - 2023-09-21 18:08:34 --> Config Class Initialized
INFO - 2023-09-21 18:08:34 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:34 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:34 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:34 --> URI Class Initialized
INFO - 2023-09-21 18:08:34 --> Router Class Initialized
INFO - 2023-09-21 18:08:34 --> Output Class Initialized
INFO - 2023-09-21 18:08:34 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:34 --> Input Class Initialized
INFO - 2023-09-21 18:08:34 --> Language Class Initialized
INFO - 2023-09-21 18:08:34 --> Language Class Initialized
INFO - 2023-09-21 18:08:34 --> Config Class Initialized
INFO - 2023-09-21 18:08:34 --> Loader Class Initialized
INFO - 2023-09-21 18:08:34 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:34 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:34 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:34 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:34 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:34 --> Controller Class Initialized
INFO - 2023-09-21 18:08:34 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:34 --> Total execution time: 0.0605
INFO - 2023-09-21 18:08:35 --> Config Class Initialized
INFO - 2023-09-21 18:08:35 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:35 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:35 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:35 --> URI Class Initialized
INFO - 2023-09-21 18:08:35 --> Router Class Initialized
INFO - 2023-09-21 18:08:35 --> Output Class Initialized
INFO - 2023-09-21 18:08:35 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:35 --> Input Class Initialized
INFO - 2023-09-21 18:08:35 --> Language Class Initialized
INFO - 2023-09-21 18:08:35 --> Language Class Initialized
INFO - 2023-09-21 18:08:35 --> Config Class Initialized
INFO - 2023-09-21 18:08:35 --> Loader Class Initialized
INFO - 2023-09-21 18:08:35 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:35 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:35 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:35 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:35 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:35 --> Controller Class Initialized
INFO - 2023-09-21 18:08:35 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:35 --> Total execution time: 0.0373
INFO - 2023-09-21 18:08:36 --> Config Class Initialized
INFO - 2023-09-21 18:08:36 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:36 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:36 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:36 --> URI Class Initialized
INFO - 2023-09-21 18:08:36 --> Router Class Initialized
INFO - 2023-09-21 18:08:36 --> Output Class Initialized
INFO - 2023-09-21 18:08:36 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:36 --> Input Class Initialized
INFO - 2023-09-21 18:08:36 --> Language Class Initialized
INFO - 2023-09-21 18:08:36 --> Language Class Initialized
INFO - 2023-09-21 18:08:36 --> Config Class Initialized
INFO - 2023-09-21 18:08:36 --> Loader Class Initialized
INFO - 2023-09-21 18:08:36 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:36 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:36 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:36 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:36 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:36 --> Controller Class Initialized
INFO - 2023-09-21 18:08:36 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:36 --> Total execution time: 0.0308
INFO - 2023-09-21 18:08:39 --> Config Class Initialized
INFO - 2023-09-21 18:08:39 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:39 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:39 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:39 --> URI Class Initialized
INFO - 2023-09-21 18:08:39 --> Router Class Initialized
INFO - 2023-09-21 18:08:39 --> Output Class Initialized
INFO - 2023-09-21 18:08:39 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:39 --> Input Class Initialized
INFO - 2023-09-21 18:08:39 --> Language Class Initialized
INFO - 2023-09-21 18:08:39 --> Language Class Initialized
INFO - 2023-09-21 18:08:39 --> Config Class Initialized
INFO - 2023-09-21 18:08:39 --> Loader Class Initialized
INFO - 2023-09-21 18:08:39 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:39 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:39 --> Controller Class Initialized
INFO - 2023-09-21 18:08:39 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:39 --> Total execution time: 0.0911
INFO - 2023-09-21 18:08:39 --> Config Class Initialized
INFO - 2023-09-21 18:08:39 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:39 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:39 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:39 --> URI Class Initialized
INFO - 2023-09-21 18:08:39 --> Router Class Initialized
INFO - 2023-09-21 18:08:39 --> Output Class Initialized
INFO - 2023-09-21 18:08:39 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:39 --> Input Class Initialized
INFO - 2023-09-21 18:08:39 --> Language Class Initialized
INFO - 2023-09-21 18:08:39 --> Language Class Initialized
INFO - 2023-09-21 18:08:39 --> Config Class Initialized
INFO - 2023-09-21 18:08:39 --> Loader Class Initialized
INFO - 2023-09-21 18:08:39 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:39 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:39 --> Controller Class Initialized
INFO - 2023-09-21 18:08:39 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:39 --> Total execution time: 0.0599
INFO - 2023-09-21 18:08:39 --> Config Class Initialized
INFO - 2023-09-21 18:08:39 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:39 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:39 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:39 --> URI Class Initialized
INFO - 2023-09-21 18:08:39 --> Router Class Initialized
INFO - 2023-09-21 18:08:39 --> Output Class Initialized
INFO - 2023-09-21 18:08:39 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:39 --> Input Class Initialized
INFO - 2023-09-21 18:08:39 --> Language Class Initialized
INFO - 2023-09-21 18:08:39 --> Language Class Initialized
INFO - 2023-09-21 18:08:39 --> Config Class Initialized
INFO - 2023-09-21 18:08:39 --> Loader Class Initialized
INFO - 2023-09-21 18:08:39 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:39 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:39 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:39 --> Controller Class Initialized
INFO - 2023-09-21 18:08:39 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:39 --> Total execution time: 0.0487
INFO - 2023-09-21 18:08:40 --> Config Class Initialized
INFO - 2023-09-21 18:08:40 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:40 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:40 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:40 --> URI Class Initialized
INFO - 2023-09-21 18:08:40 --> Router Class Initialized
INFO - 2023-09-21 18:08:40 --> Output Class Initialized
INFO - 2023-09-21 18:08:40 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:40 --> Input Class Initialized
INFO - 2023-09-21 18:08:40 --> Language Class Initialized
INFO - 2023-09-21 18:08:40 --> Language Class Initialized
INFO - 2023-09-21 18:08:40 --> Config Class Initialized
INFO - 2023-09-21 18:08:40 --> Loader Class Initialized
INFO - 2023-09-21 18:08:40 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:40 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:40 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:40 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:40 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:40 --> Controller Class Initialized
INFO - 2023-09-21 18:08:40 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:40 --> Total execution time: 0.0380
INFO - 2023-09-21 18:08:40 --> Config Class Initialized
INFO - 2023-09-21 18:08:40 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:08:40 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:08:40 --> Utf8 Class Initialized
INFO - 2023-09-21 18:08:40 --> URI Class Initialized
INFO - 2023-09-21 18:08:40 --> Router Class Initialized
INFO - 2023-09-21 18:08:40 --> Output Class Initialized
INFO - 2023-09-21 18:08:40 --> Security Class Initialized
DEBUG - 2023-09-21 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:08:40 --> Input Class Initialized
INFO - 2023-09-21 18:08:40 --> Language Class Initialized
INFO - 2023-09-21 18:08:40 --> Language Class Initialized
INFO - 2023-09-21 18:08:40 --> Config Class Initialized
INFO - 2023-09-21 18:08:40 --> Loader Class Initialized
INFO - 2023-09-21 18:08:40 --> Helper loaded: url_helper
INFO - 2023-09-21 18:08:40 --> Helper loaded: file_helper
INFO - 2023-09-21 18:08:40 --> Helper loaded: form_helper
INFO - 2023-09-21 18:08:40 --> Helper loaded: my_helper
INFO - 2023-09-21 18:08:40 --> Database Driver Class Initialized
INFO - 2023-09-21 18:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:08:40 --> Controller Class Initialized
INFO - 2023-09-21 18:08:40 --> Final output sent to browser
DEBUG - 2023-09-21 18:08:40 --> Total execution time: 0.0300
INFO - 2023-09-21 18:24:53 --> Config Class Initialized
INFO - 2023-09-21 18:24:53 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:24:53 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:24:53 --> Utf8 Class Initialized
INFO - 2023-09-21 18:24:53 --> URI Class Initialized
INFO - 2023-09-21 18:24:53 --> Router Class Initialized
INFO - 2023-09-21 18:24:53 --> Output Class Initialized
INFO - 2023-09-21 18:24:53 --> Security Class Initialized
DEBUG - 2023-09-21 18:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:24:53 --> Input Class Initialized
INFO - 2023-09-21 18:24:53 --> Language Class Initialized
INFO - 2023-09-21 18:24:54 --> Language Class Initialized
INFO - 2023-09-21 18:24:54 --> Config Class Initialized
INFO - 2023-09-21 18:24:54 --> Loader Class Initialized
INFO - 2023-09-21 18:24:54 --> Helper loaded: url_helper
INFO - 2023-09-21 18:24:54 --> Helper loaded: file_helper
INFO - 2023-09-21 18:24:54 --> Helper loaded: form_helper
INFO - 2023-09-21 18:24:54 --> Helper loaded: my_helper
INFO - 2023-09-21 18:24:54 --> Database Driver Class Initialized
INFO - 2023-09-21 18:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:24:54 --> Controller Class Initialized
DEBUG - 2023-09-21 18:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-21 18:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-21 18:24:54 --> Final output sent to browser
DEBUG - 2023-09-21 18:24:54 --> Total execution time: 0.5650
INFO - 2023-09-21 18:24:55 --> Config Class Initialized
INFO - 2023-09-21 18:24:55 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:24:55 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:24:55 --> Utf8 Class Initialized
INFO - 2023-09-21 18:24:55 --> URI Class Initialized
INFO - 2023-09-21 18:24:55 --> Router Class Initialized
INFO - 2023-09-21 18:24:55 --> Output Class Initialized
INFO - 2023-09-21 18:24:55 --> Security Class Initialized
DEBUG - 2023-09-21 18:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:24:55 --> Input Class Initialized
INFO - 2023-09-21 18:24:55 --> Language Class Initialized
INFO - 2023-09-21 18:24:55 --> Language Class Initialized
INFO - 2023-09-21 18:24:55 --> Config Class Initialized
INFO - 2023-09-21 18:24:55 --> Loader Class Initialized
INFO - 2023-09-21 18:24:55 --> Helper loaded: url_helper
INFO - 2023-09-21 18:24:55 --> Helper loaded: file_helper
INFO - 2023-09-21 18:24:55 --> Helper loaded: form_helper
INFO - 2023-09-21 18:24:55 --> Helper loaded: my_helper
INFO - 2023-09-21 18:24:55 --> Database Driver Class Initialized
INFO - 2023-09-21 18:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:24:55 --> Controller Class Initialized
INFO - 2023-09-21 18:24:59 --> Config Class Initialized
INFO - 2023-09-21 18:24:59 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:24:59 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:24:59 --> Utf8 Class Initialized
INFO - 2023-09-21 18:24:59 --> URI Class Initialized
INFO - 2023-09-21 18:24:59 --> Router Class Initialized
INFO - 2023-09-21 18:24:59 --> Output Class Initialized
INFO - 2023-09-21 18:24:59 --> Security Class Initialized
DEBUG - 2023-09-21 18:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:24:59 --> Input Class Initialized
INFO - 2023-09-21 18:24:59 --> Language Class Initialized
INFO - 2023-09-21 18:24:59 --> Language Class Initialized
INFO - 2023-09-21 18:24:59 --> Config Class Initialized
INFO - 2023-09-21 18:24:59 --> Loader Class Initialized
INFO - 2023-09-21 18:24:59 --> Helper loaded: url_helper
INFO - 2023-09-21 18:24:59 --> Helper loaded: file_helper
INFO - 2023-09-21 18:24:59 --> Helper loaded: form_helper
INFO - 2023-09-21 18:24:59 --> Helper loaded: my_helper
INFO - 2023-09-21 18:24:59 --> Database Driver Class Initialized
INFO - 2023-09-21 18:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:24:59 --> Controller Class Initialized
INFO - 2023-09-21 18:25:00 --> Final output sent to browser
DEBUG - 2023-09-21 18:25:00 --> Total execution time: 0.1845
INFO - 2023-09-21 18:25:06 --> Config Class Initialized
INFO - 2023-09-21 18:25:06 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:25:06 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:25:06 --> Utf8 Class Initialized
INFO - 2023-09-21 18:25:06 --> URI Class Initialized
INFO - 2023-09-21 18:25:06 --> Router Class Initialized
INFO - 2023-09-21 18:25:06 --> Output Class Initialized
INFO - 2023-09-21 18:25:06 --> Security Class Initialized
DEBUG - 2023-09-21 18:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:25:06 --> Input Class Initialized
INFO - 2023-09-21 18:25:06 --> Language Class Initialized
INFO - 2023-09-21 18:25:06 --> Language Class Initialized
INFO - 2023-09-21 18:25:06 --> Config Class Initialized
INFO - 2023-09-21 18:25:06 --> Loader Class Initialized
INFO - 2023-09-21 18:25:06 --> Helper loaded: url_helper
INFO - 2023-09-21 18:25:06 --> Helper loaded: file_helper
INFO - 2023-09-21 18:25:06 --> Helper loaded: form_helper
INFO - 2023-09-21 18:25:06 --> Helper loaded: my_helper
INFO - 2023-09-21 18:25:06 --> Database Driver Class Initialized
INFO - 2023-09-21 18:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:25:06 --> Controller Class Initialized
INFO - 2023-09-21 18:25:06 --> Final output sent to browser
DEBUG - 2023-09-21 18:25:06 --> Total execution time: 0.0531
INFO - 2023-09-21 18:25:06 --> Config Class Initialized
INFO - 2023-09-21 18:25:06 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:25:06 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:25:06 --> Utf8 Class Initialized
INFO - 2023-09-21 18:25:06 --> URI Class Initialized
INFO - 2023-09-21 18:25:06 --> Router Class Initialized
INFO - 2023-09-21 18:25:06 --> Output Class Initialized
INFO - 2023-09-21 18:25:06 --> Security Class Initialized
DEBUG - 2023-09-21 18:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:25:06 --> Input Class Initialized
INFO - 2023-09-21 18:25:06 --> Language Class Initialized
INFO - 2023-09-21 18:25:06 --> Language Class Initialized
INFO - 2023-09-21 18:25:06 --> Config Class Initialized
INFO - 2023-09-21 18:25:06 --> Loader Class Initialized
INFO - 2023-09-21 18:25:06 --> Helper loaded: url_helper
INFO - 2023-09-21 18:25:06 --> Helper loaded: file_helper
INFO - 2023-09-21 18:25:06 --> Helper loaded: form_helper
INFO - 2023-09-21 18:25:06 --> Helper loaded: my_helper
INFO - 2023-09-21 18:25:06 --> Database Driver Class Initialized
INFO - 2023-09-21 18:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:25:06 --> Controller Class Initialized
INFO - 2023-09-21 18:25:06 --> Final output sent to browser
DEBUG - 2023-09-21 18:25:06 --> Total execution time: 0.0446
INFO - 2023-09-21 18:25:08 --> Config Class Initialized
INFO - 2023-09-21 18:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:25:08 --> Utf8 Class Initialized
INFO - 2023-09-21 18:25:08 --> URI Class Initialized
INFO - 2023-09-21 18:25:08 --> Router Class Initialized
INFO - 2023-09-21 18:25:08 --> Output Class Initialized
INFO - 2023-09-21 18:25:08 --> Security Class Initialized
DEBUG - 2023-09-21 18:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:25:08 --> Input Class Initialized
INFO - 2023-09-21 18:25:08 --> Language Class Initialized
INFO - 2023-09-21 18:25:08 --> Language Class Initialized
INFO - 2023-09-21 18:25:08 --> Config Class Initialized
INFO - 2023-09-21 18:25:08 --> Loader Class Initialized
INFO - 2023-09-21 18:25:08 --> Helper loaded: url_helper
INFO - 2023-09-21 18:25:08 --> Helper loaded: file_helper
INFO - 2023-09-21 18:25:08 --> Helper loaded: form_helper
INFO - 2023-09-21 18:25:08 --> Helper loaded: my_helper
INFO - 2023-09-21 18:25:08 --> Database Driver Class Initialized
INFO - 2023-09-21 18:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:25:08 --> Controller Class Initialized
INFO - 2023-09-21 18:25:08 --> Final output sent to browser
DEBUG - 2023-09-21 18:25:08 --> Total execution time: 0.1298
INFO - 2023-09-21 18:25:08 --> Config Class Initialized
INFO - 2023-09-21 18:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:25:08 --> Utf8 Class Initialized
INFO - 2023-09-21 18:25:08 --> URI Class Initialized
INFO - 2023-09-21 18:25:08 --> Router Class Initialized
INFO - 2023-09-21 18:25:08 --> Output Class Initialized
INFO - 2023-09-21 18:25:08 --> Security Class Initialized
DEBUG - 2023-09-21 18:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:25:08 --> Input Class Initialized
INFO - 2023-09-21 18:25:08 --> Language Class Initialized
INFO - 2023-09-21 18:25:08 --> Language Class Initialized
INFO - 2023-09-21 18:25:08 --> Config Class Initialized
INFO - 2023-09-21 18:25:08 --> Loader Class Initialized
INFO - 2023-09-21 18:25:08 --> Helper loaded: url_helper
INFO - 2023-09-21 18:25:08 --> Helper loaded: file_helper
INFO - 2023-09-21 18:25:08 --> Helper loaded: form_helper
INFO - 2023-09-21 18:25:08 --> Helper loaded: my_helper
INFO - 2023-09-21 18:25:08 --> Database Driver Class Initialized
INFO - 2023-09-21 18:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:25:08 --> Controller Class Initialized
INFO - 2023-09-21 18:25:08 --> Final output sent to browser
DEBUG - 2023-09-21 18:25:08 --> Total execution time: 0.0381
INFO - 2023-09-21 18:25:09 --> Config Class Initialized
INFO - 2023-09-21 18:25:09 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:25:09 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:25:09 --> Utf8 Class Initialized
INFO - 2023-09-21 18:25:09 --> URI Class Initialized
INFO - 2023-09-21 18:25:09 --> Router Class Initialized
INFO - 2023-09-21 18:25:09 --> Output Class Initialized
INFO - 2023-09-21 18:25:09 --> Security Class Initialized
DEBUG - 2023-09-21 18:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:25:09 --> Input Class Initialized
INFO - 2023-09-21 18:25:09 --> Language Class Initialized
INFO - 2023-09-21 18:25:09 --> Language Class Initialized
INFO - 2023-09-21 18:25:09 --> Config Class Initialized
INFO - 2023-09-21 18:25:09 --> Loader Class Initialized
INFO - 2023-09-21 18:25:09 --> Helper loaded: url_helper
INFO - 2023-09-21 18:25:09 --> Helper loaded: file_helper
INFO - 2023-09-21 18:25:09 --> Helper loaded: form_helper
INFO - 2023-09-21 18:25:09 --> Helper loaded: my_helper
INFO - 2023-09-21 18:25:09 --> Database Driver Class Initialized
INFO - 2023-09-21 18:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:25:09 --> Controller Class Initialized
INFO - 2023-09-21 18:25:09 --> Final output sent to browser
DEBUG - 2023-09-21 18:25:09 --> Total execution time: 0.1561
INFO - 2023-09-21 18:42:34 --> Config Class Initialized
INFO - 2023-09-21 18:42:34 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:42:34 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:42:34 --> Utf8 Class Initialized
INFO - 2023-09-21 18:42:34 --> URI Class Initialized
INFO - 2023-09-21 18:42:34 --> Router Class Initialized
INFO - 2023-09-21 18:42:34 --> Output Class Initialized
INFO - 2023-09-21 18:42:34 --> Security Class Initialized
DEBUG - 2023-09-21 18:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:42:34 --> Input Class Initialized
INFO - 2023-09-21 18:42:34 --> Language Class Initialized
INFO - 2023-09-21 18:42:34 --> Language Class Initialized
INFO - 2023-09-21 18:42:34 --> Config Class Initialized
INFO - 2023-09-21 18:42:34 --> Loader Class Initialized
INFO - 2023-09-21 18:42:34 --> Helper loaded: url_helper
INFO - 2023-09-21 18:42:34 --> Helper loaded: file_helper
INFO - 2023-09-21 18:42:34 --> Helper loaded: form_helper
INFO - 2023-09-21 18:42:34 --> Helper loaded: my_helper
INFO - 2023-09-21 18:42:34 --> Database Driver Class Initialized
INFO - 2023-09-21 18:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:42:34 --> Controller Class Initialized
INFO - 2023-09-21 18:42:34 --> Final output sent to browser
DEBUG - 2023-09-21 18:42:34 --> Total execution time: 0.2659
INFO - 2023-09-21 18:43:04 --> Config Class Initialized
INFO - 2023-09-21 18:43:04 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:04 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:04 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:04 --> URI Class Initialized
INFO - 2023-09-21 18:43:04 --> Router Class Initialized
INFO - 2023-09-21 18:43:04 --> Output Class Initialized
INFO - 2023-09-21 18:43:04 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:04 --> Input Class Initialized
INFO - 2023-09-21 18:43:04 --> Language Class Initialized
INFO - 2023-09-21 18:43:04 --> Language Class Initialized
INFO - 2023-09-21 18:43:04 --> Config Class Initialized
INFO - 2023-09-21 18:43:04 --> Loader Class Initialized
INFO - 2023-09-21 18:43:04 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:04 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:04 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:04 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:04 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:04 --> Controller Class Initialized
INFO - 2023-09-21 18:43:04 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:04 --> Total execution time: 0.1594
INFO - 2023-09-21 18:43:04 --> Config Class Initialized
INFO - 2023-09-21 18:43:04 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:04 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:04 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:04 --> URI Class Initialized
INFO - 2023-09-21 18:43:04 --> Router Class Initialized
INFO - 2023-09-21 18:43:04 --> Output Class Initialized
INFO - 2023-09-21 18:43:04 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:04 --> Input Class Initialized
INFO - 2023-09-21 18:43:04 --> Language Class Initialized
INFO - 2023-09-21 18:43:04 --> Language Class Initialized
INFO - 2023-09-21 18:43:04 --> Config Class Initialized
INFO - 2023-09-21 18:43:04 --> Loader Class Initialized
INFO - 2023-09-21 18:43:04 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:04 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:04 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:04 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:04 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:04 --> Controller Class Initialized
INFO - 2023-09-21 18:43:04 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:04 --> Total execution time: 0.0476
INFO - 2023-09-21 18:43:13 --> Config Class Initialized
INFO - 2023-09-21 18:43:13 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:13 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:13 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:13 --> URI Class Initialized
INFO - 2023-09-21 18:43:13 --> Router Class Initialized
INFO - 2023-09-21 18:43:13 --> Output Class Initialized
INFO - 2023-09-21 18:43:13 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:13 --> Input Class Initialized
INFO - 2023-09-21 18:43:13 --> Language Class Initialized
INFO - 2023-09-21 18:43:13 --> Language Class Initialized
INFO - 2023-09-21 18:43:13 --> Config Class Initialized
INFO - 2023-09-21 18:43:13 --> Loader Class Initialized
INFO - 2023-09-21 18:43:13 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:13 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:13 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:13 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:13 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:13 --> Controller Class Initialized
INFO - 2023-09-21 18:43:13 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:13 --> Total execution time: 0.1521
INFO - 2023-09-21 18:43:15 --> Config Class Initialized
INFO - 2023-09-21 18:43:15 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:15 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:15 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:15 --> URI Class Initialized
INFO - 2023-09-21 18:43:15 --> Router Class Initialized
INFO - 2023-09-21 18:43:15 --> Output Class Initialized
INFO - 2023-09-21 18:43:15 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:15 --> Input Class Initialized
INFO - 2023-09-21 18:43:15 --> Language Class Initialized
INFO - 2023-09-21 18:43:15 --> Language Class Initialized
INFO - 2023-09-21 18:43:15 --> Config Class Initialized
INFO - 2023-09-21 18:43:15 --> Loader Class Initialized
INFO - 2023-09-21 18:43:15 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:15 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:15 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:15 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:15 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:15 --> Controller Class Initialized
INFO - 2023-09-21 18:43:15 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:15 --> Total execution time: 0.0380
INFO - 2023-09-21 18:43:18 --> Config Class Initialized
INFO - 2023-09-21 18:43:18 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:18 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:18 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:18 --> URI Class Initialized
INFO - 2023-09-21 18:43:18 --> Router Class Initialized
INFO - 2023-09-21 18:43:18 --> Output Class Initialized
INFO - 2023-09-21 18:43:18 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:18 --> Input Class Initialized
INFO - 2023-09-21 18:43:18 --> Language Class Initialized
INFO - 2023-09-21 18:43:18 --> Language Class Initialized
INFO - 2023-09-21 18:43:18 --> Config Class Initialized
INFO - 2023-09-21 18:43:18 --> Loader Class Initialized
INFO - 2023-09-21 18:43:18 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:18 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:18 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:18 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:18 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:18 --> Controller Class Initialized
INFO - 2023-09-21 18:43:18 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:18 --> Total execution time: 0.0924
INFO - 2023-09-21 18:43:24 --> Config Class Initialized
INFO - 2023-09-21 18:43:24 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:24 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:24 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:24 --> URI Class Initialized
INFO - 2023-09-21 18:43:25 --> Router Class Initialized
INFO - 2023-09-21 18:43:25 --> Output Class Initialized
INFO - 2023-09-21 18:43:25 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:25 --> Input Class Initialized
INFO - 2023-09-21 18:43:25 --> Language Class Initialized
INFO - 2023-09-21 18:43:25 --> Language Class Initialized
INFO - 2023-09-21 18:43:25 --> Config Class Initialized
INFO - 2023-09-21 18:43:25 --> Loader Class Initialized
INFO - 2023-09-21 18:43:25 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:25 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:25 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:25 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:25 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:25 --> Controller Class Initialized
INFO - 2023-09-21 18:43:25 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:25 --> Total execution time: 0.1798
INFO - 2023-09-21 18:43:27 --> Config Class Initialized
INFO - 2023-09-21 18:43:27 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:27 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:27 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:27 --> URI Class Initialized
INFO - 2023-09-21 18:43:27 --> Router Class Initialized
INFO - 2023-09-21 18:43:27 --> Output Class Initialized
INFO - 2023-09-21 18:43:27 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:27 --> Input Class Initialized
INFO - 2023-09-21 18:43:27 --> Language Class Initialized
INFO - 2023-09-21 18:43:27 --> Language Class Initialized
INFO - 2023-09-21 18:43:27 --> Config Class Initialized
INFO - 2023-09-21 18:43:27 --> Loader Class Initialized
INFO - 2023-09-21 18:43:27 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:27 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:27 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:27 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:28 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:28 --> Controller Class Initialized
INFO - 2023-09-21 18:43:28 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:28 --> Total execution time: 0.1151
INFO - 2023-09-21 18:43:29 --> Config Class Initialized
INFO - 2023-09-21 18:43:29 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:29 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:29 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:29 --> URI Class Initialized
INFO - 2023-09-21 18:43:29 --> Router Class Initialized
INFO - 2023-09-21 18:43:29 --> Output Class Initialized
INFO - 2023-09-21 18:43:29 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:29 --> Input Class Initialized
INFO - 2023-09-21 18:43:29 --> Language Class Initialized
INFO - 2023-09-21 18:43:29 --> Language Class Initialized
INFO - 2023-09-21 18:43:29 --> Config Class Initialized
INFO - 2023-09-21 18:43:29 --> Loader Class Initialized
INFO - 2023-09-21 18:43:29 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:29 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:29 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:29 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:29 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:29 --> Controller Class Initialized
INFO - 2023-09-21 18:43:29 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:29 --> Total execution time: 0.0838
INFO - 2023-09-21 18:43:31 --> Config Class Initialized
INFO - 2023-09-21 18:43:31 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:43:31 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:43:31 --> Utf8 Class Initialized
INFO - 2023-09-21 18:43:31 --> URI Class Initialized
INFO - 2023-09-21 18:43:31 --> Router Class Initialized
INFO - 2023-09-21 18:43:31 --> Output Class Initialized
INFO - 2023-09-21 18:43:31 --> Security Class Initialized
DEBUG - 2023-09-21 18:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:43:31 --> Input Class Initialized
INFO - 2023-09-21 18:43:31 --> Language Class Initialized
INFO - 2023-09-21 18:43:31 --> Language Class Initialized
INFO - 2023-09-21 18:43:31 --> Config Class Initialized
INFO - 2023-09-21 18:43:31 --> Loader Class Initialized
INFO - 2023-09-21 18:43:31 --> Helper loaded: url_helper
INFO - 2023-09-21 18:43:31 --> Helper loaded: file_helper
INFO - 2023-09-21 18:43:31 --> Helper loaded: form_helper
INFO - 2023-09-21 18:43:31 --> Helper loaded: my_helper
INFO - 2023-09-21 18:43:31 --> Database Driver Class Initialized
INFO - 2023-09-21 18:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:43:31 --> Controller Class Initialized
INFO - 2023-09-21 18:43:31 --> Final output sent to browser
DEBUG - 2023-09-21 18:43:31 --> Total execution time: 0.0589
INFO - 2023-09-21 18:55:56 --> Config Class Initialized
INFO - 2023-09-21 18:55:56 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:55:56 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:55:56 --> Utf8 Class Initialized
INFO - 2023-09-21 18:55:56 --> URI Class Initialized
INFO - 2023-09-21 18:55:56 --> Router Class Initialized
INFO - 2023-09-21 18:55:56 --> Output Class Initialized
INFO - 2023-09-21 18:55:56 --> Security Class Initialized
DEBUG - 2023-09-21 18:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:55:56 --> Input Class Initialized
INFO - 2023-09-21 18:55:56 --> Language Class Initialized
INFO - 2023-09-21 18:55:56 --> Language Class Initialized
INFO - 2023-09-21 18:55:56 --> Config Class Initialized
INFO - 2023-09-21 18:55:56 --> Loader Class Initialized
INFO - 2023-09-21 18:55:56 --> Helper loaded: url_helper
INFO - 2023-09-21 18:55:56 --> Helper loaded: file_helper
INFO - 2023-09-21 18:55:56 --> Helper loaded: form_helper
INFO - 2023-09-21 18:55:56 --> Helper loaded: my_helper
INFO - 2023-09-21 18:55:56 --> Database Driver Class Initialized
INFO - 2023-09-21 18:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:55:56 --> Controller Class Initialized
INFO - 2023-09-21 18:55:56 --> Final output sent to browser
DEBUG - 2023-09-21 18:55:56 --> Total execution time: 0.0716
INFO - 2023-09-21 18:56:45 --> Config Class Initialized
INFO - 2023-09-21 18:56:45 --> Hooks Class Initialized
DEBUG - 2023-09-21 18:56:45 --> UTF-8 Support Enabled
INFO - 2023-09-21 18:56:45 --> Utf8 Class Initialized
INFO - 2023-09-21 18:56:45 --> URI Class Initialized
INFO - 2023-09-21 18:56:45 --> Router Class Initialized
INFO - 2023-09-21 18:56:45 --> Output Class Initialized
INFO - 2023-09-21 18:56:45 --> Security Class Initialized
DEBUG - 2023-09-21 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 18:56:45 --> Input Class Initialized
INFO - 2023-09-21 18:56:45 --> Language Class Initialized
INFO - 2023-09-21 18:56:45 --> Language Class Initialized
INFO - 2023-09-21 18:56:45 --> Config Class Initialized
INFO - 2023-09-21 18:56:45 --> Loader Class Initialized
INFO - 2023-09-21 18:56:45 --> Helper loaded: url_helper
INFO - 2023-09-21 18:56:45 --> Helper loaded: file_helper
INFO - 2023-09-21 18:56:45 --> Helper loaded: form_helper
INFO - 2023-09-21 18:56:45 --> Helper loaded: my_helper
INFO - 2023-09-21 18:56:45 --> Database Driver Class Initialized
INFO - 2023-09-21 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 18:56:45 --> Controller Class Initialized
INFO - 2023-09-21 18:56:45 --> Final output sent to browser
DEBUG - 2023-09-21 18:56:45 --> Total execution time: 0.1126
INFO - 2023-09-21 19:02:55 --> Config Class Initialized
INFO - 2023-09-21 19:02:55 --> Hooks Class Initialized
DEBUG - 2023-09-21 19:02:55 --> UTF-8 Support Enabled
INFO - 2023-09-21 19:02:55 --> Utf8 Class Initialized
INFO - 2023-09-21 19:02:55 --> URI Class Initialized
INFO - 2023-09-21 19:02:55 --> Router Class Initialized
INFO - 2023-09-21 19:02:55 --> Output Class Initialized
INFO - 2023-09-21 19:02:55 --> Security Class Initialized
DEBUG - 2023-09-21 19:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 19:02:55 --> Input Class Initialized
INFO - 2023-09-21 19:02:55 --> Language Class Initialized
INFO - 2023-09-21 19:02:55 --> Language Class Initialized
INFO - 2023-09-21 19:02:55 --> Config Class Initialized
INFO - 2023-09-21 19:02:55 --> Loader Class Initialized
INFO - 2023-09-21 19:02:55 --> Helper loaded: url_helper
INFO - 2023-09-21 19:02:55 --> Helper loaded: file_helper
INFO - 2023-09-21 19:02:55 --> Helper loaded: form_helper
INFO - 2023-09-21 19:02:55 --> Helper loaded: my_helper
INFO - 2023-09-21 19:02:55 --> Database Driver Class Initialized
INFO - 2023-09-21 19:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 19:02:55 --> Controller Class Initialized
ERROR - 2023-09-21 19:02:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'dan aplikasi melalui vokal grup')' at line 1 - Invalid query: INSERT INTO t_nilai (tasm,jenis, id_guru_mapel, id_mapel_kd, id_siswa, catatan, catatan_mid) VALUES ('20231', 'c', '7', '11', '1', '', 'Memahami definisi dan implementasi Unisono, secara individu bisa mengimitasi nada diatonis(C-C') dan aplikasi melalui vokal grup')
INFO - 2023-09-21 19:02:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-21 19:03:17 --> Config Class Initialized
INFO - 2023-09-21 19:03:17 --> Hooks Class Initialized
DEBUG - 2023-09-21 19:03:17 --> UTF-8 Support Enabled
INFO - 2023-09-21 19:03:17 --> Utf8 Class Initialized
INFO - 2023-09-21 19:03:17 --> URI Class Initialized
INFO - 2023-09-21 19:03:17 --> Router Class Initialized
INFO - 2023-09-21 19:03:17 --> Output Class Initialized
INFO - 2023-09-21 19:03:17 --> Security Class Initialized
DEBUG - 2023-09-21 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 19:03:17 --> Input Class Initialized
INFO - 2023-09-21 19:03:17 --> Language Class Initialized
INFO - 2023-09-21 19:03:17 --> Language Class Initialized
INFO - 2023-09-21 19:03:17 --> Config Class Initialized
INFO - 2023-09-21 19:03:17 --> Loader Class Initialized
INFO - 2023-09-21 19:03:17 --> Helper loaded: url_helper
INFO - 2023-09-21 19:03:17 --> Helper loaded: file_helper
INFO - 2023-09-21 19:03:17 --> Helper loaded: form_helper
INFO - 2023-09-21 19:03:17 --> Helper loaded: my_helper
INFO - 2023-09-21 19:03:17 --> Database Driver Class Initialized
INFO - 2023-09-21 19:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 19:03:17 --> Controller Class Initialized
INFO - 2023-09-21 19:03:17 --> Final output sent to browser
DEBUG - 2023-09-21 19:03:17 --> Total execution time: 0.0564
INFO - 2023-09-21 19:06:29 --> Config Class Initialized
INFO - 2023-09-21 19:06:29 --> Hooks Class Initialized
DEBUG - 2023-09-21 19:06:29 --> UTF-8 Support Enabled
INFO - 2023-09-21 19:06:29 --> Utf8 Class Initialized
INFO - 2023-09-21 19:06:29 --> URI Class Initialized
INFO - 2023-09-21 19:06:29 --> Router Class Initialized
INFO - 2023-09-21 19:06:29 --> Output Class Initialized
INFO - 2023-09-21 19:06:29 --> Security Class Initialized
DEBUG - 2023-09-21 19:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 19:06:29 --> Input Class Initialized
INFO - 2023-09-21 19:06:29 --> Language Class Initialized
INFO - 2023-09-21 19:06:29 --> Language Class Initialized
INFO - 2023-09-21 19:06:29 --> Config Class Initialized
INFO - 2023-09-21 19:06:29 --> Loader Class Initialized
INFO - 2023-09-21 19:06:29 --> Helper loaded: url_helper
INFO - 2023-09-21 19:06:29 --> Helper loaded: file_helper
INFO - 2023-09-21 19:06:29 --> Helper loaded: form_helper
INFO - 2023-09-21 19:06:29 --> Helper loaded: my_helper
INFO - 2023-09-21 19:06:29 --> Database Driver Class Initialized
INFO - 2023-09-21 19:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 19:06:29 --> Controller Class Initialized
ERROR - 2023-09-21 19:06:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'dan aplikasi melalui vokal grup')' at line 1 - Invalid query: INSERT INTO t_nilai (tasm,jenis, id_guru_mapel, id_mapel_kd, id_siswa, catatan, catatan_mid) VALUES ('20231', 'c', '7', '11', '1', '', 'Memahami definisi dan implementasi Unisono, secara individu bisa mengimitasi nada diatonis(C-C') dan aplikasi melalui vokal grup')
INFO - 2023-09-21 19:06:29 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-21 19:07:04 --> Config Class Initialized
INFO - 2023-09-21 19:07:04 --> Hooks Class Initialized
DEBUG - 2023-09-21 19:07:04 --> UTF-8 Support Enabled
INFO - 2023-09-21 19:07:04 --> Utf8 Class Initialized
INFO - 2023-09-21 19:07:04 --> URI Class Initialized
INFO - 2023-09-21 19:07:04 --> Router Class Initialized
INFO - 2023-09-21 19:07:04 --> Output Class Initialized
INFO - 2023-09-21 19:07:04 --> Security Class Initialized
DEBUG - 2023-09-21 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 19:07:04 --> Input Class Initialized
INFO - 2023-09-21 19:07:04 --> Language Class Initialized
INFO - 2023-09-21 19:07:05 --> Language Class Initialized
INFO - 2023-09-21 19:07:05 --> Config Class Initialized
INFO - 2023-09-21 19:07:05 --> Loader Class Initialized
INFO - 2023-09-21 19:07:05 --> Helper loaded: url_helper
INFO - 2023-09-21 19:07:05 --> Helper loaded: file_helper
INFO - 2023-09-21 19:07:05 --> Helper loaded: form_helper
INFO - 2023-09-21 19:07:05 --> Helper loaded: my_helper
INFO - 2023-09-21 19:07:05 --> Database Driver Class Initialized
INFO - 2023-09-21 19:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 19:07:05 --> Controller Class Initialized
INFO - 2023-09-21 19:07:05 --> Final output sent to browser
DEBUG - 2023-09-21 19:07:05 --> Total execution time: 0.1413
INFO - 2023-09-21 19:07:38 --> Config Class Initialized
INFO - 2023-09-21 19:07:38 --> Hooks Class Initialized
DEBUG - 2023-09-21 19:07:38 --> UTF-8 Support Enabled
INFO - 2023-09-21 19:07:38 --> Utf8 Class Initialized
INFO - 2023-09-21 19:07:38 --> URI Class Initialized
INFO - 2023-09-21 19:07:38 --> Router Class Initialized
INFO - 2023-09-21 19:07:38 --> Output Class Initialized
INFO - 2023-09-21 19:07:38 --> Security Class Initialized
DEBUG - 2023-09-21 19:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-21 19:07:38 --> Input Class Initialized
INFO - 2023-09-21 19:07:38 --> Language Class Initialized
INFO - 2023-09-21 19:07:38 --> Language Class Initialized
INFO - 2023-09-21 19:07:38 --> Config Class Initialized
INFO - 2023-09-21 19:07:38 --> Loader Class Initialized
INFO - 2023-09-21 19:07:38 --> Helper loaded: url_helper
INFO - 2023-09-21 19:07:38 --> Helper loaded: file_helper
INFO - 2023-09-21 19:07:38 --> Helper loaded: form_helper
INFO - 2023-09-21 19:07:38 --> Helper loaded: my_helper
INFO - 2023-09-21 19:07:38 --> Database Driver Class Initialized
INFO - 2023-09-21 19:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-21 19:07:38 --> Controller Class Initialized
INFO - 2023-09-21 19:07:39 --> Final output sent to browser
DEBUG - 2023-09-21 19:07:39 --> Total execution time: 0.2231
