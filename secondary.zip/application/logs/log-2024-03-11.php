<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-11 15:05:55 --> Config Class Initialized
INFO - 2024-03-11 15:05:55 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:05:55 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:05:55 --> Utf8 Class Initialized
INFO - 2024-03-11 15:05:55 --> URI Class Initialized
INFO - 2024-03-11 15:05:55 --> Router Class Initialized
INFO - 2024-03-11 15:05:55 --> Output Class Initialized
INFO - 2024-03-11 15:05:55 --> Security Class Initialized
DEBUG - 2024-03-11 15:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:05:55 --> Input Class Initialized
INFO - 2024-03-11 15:05:55 --> Language Class Initialized
INFO - 2024-03-11 15:05:55 --> Language Class Initialized
INFO - 2024-03-11 15:05:55 --> Config Class Initialized
INFO - 2024-03-11 15:05:55 --> Loader Class Initialized
INFO - 2024-03-11 15:05:56 --> Helper loaded: url_helper
INFO - 2024-03-11 15:05:56 --> Helper loaded: file_helper
INFO - 2024-03-11 15:05:56 --> Helper loaded: form_helper
INFO - 2024-03-11 15:05:56 --> Helper loaded: my_helper
INFO - 2024-03-11 15:05:56 --> Database Driver Class Initialized
INFO - 2024-03-11 15:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:05:56 --> Controller Class Initialized
DEBUG - 2024-03-11 15:05:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-11 15:05:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:05:56 --> Final output sent to browser
DEBUG - 2024-03-11 15:05:56 --> Total execution time: 0.5487
INFO - 2024-03-11 15:05:56 --> Config Class Initialized
INFO - 2024-03-11 15:05:56 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:05:56 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:05:56 --> Utf8 Class Initialized
INFO - 2024-03-11 15:05:56 --> URI Class Initialized
INFO - 2024-03-11 15:05:56 --> Router Class Initialized
INFO - 2024-03-11 15:05:56 --> Output Class Initialized
INFO - 2024-03-11 15:05:56 --> Security Class Initialized
DEBUG - 2024-03-11 15:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:05:56 --> Input Class Initialized
INFO - 2024-03-11 15:05:56 --> Language Class Initialized
INFO - 2024-03-11 15:05:56 --> Language Class Initialized
INFO - 2024-03-11 15:05:56 --> Config Class Initialized
INFO - 2024-03-11 15:05:56 --> Loader Class Initialized
INFO - 2024-03-11 15:05:56 --> Helper loaded: url_helper
INFO - 2024-03-11 15:05:56 --> Helper loaded: file_helper
INFO - 2024-03-11 15:05:56 --> Helper loaded: form_helper
INFO - 2024-03-11 15:05:56 --> Helper loaded: my_helper
INFO - 2024-03-11 15:05:56 --> Database Driver Class Initialized
INFO - 2024-03-11 15:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:05:56 --> Controller Class Initialized
INFO - 2024-03-11 15:06:00 --> Config Class Initialized
INFO - 2024-03-11 15:06:00 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:00 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:00 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:00 --> URI Class Initialized
DEBUG - 2024-03-11 15:06:00 --> No URI present. Default controller set.
INFO - 2024-03-11 15:06:00 --> Router Class Initialized
INFO - 2024-03-11 15:06:00 --> Output Class Initialized
INFO - 2024-03-11 15:06:00 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:00 --> Input Class Initialized
INFO - 2024-03-11 15:06:00 --> Language Class Initialized
INFO - 2024-03-11 15:06:00 --> Language Class Initialized
INFO - 2024-03-11 15:06:00 --> Config Class Initialized
INFO - 2024-03-11 15:06:00 --> Loader Class Initialized
INFO - 2024-03-11 15:06:00 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:00 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:00 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:00 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:00 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:00 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-11 15:06:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:00 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:00 --> Total execution time: 0.0520
INFO - 2024-03-11 15:06:02 --> Config Class Initialized
INFO - 2024-03-11 15:06:02 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:02 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:02 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:02 --> URI Class Initialized
INFO - 2024-03-11 15:06:02 --> Router Class Initialized
INFO - 2024-03-11 15:06:02 --> Output Class Initialized
INFO - 2024-03-11 15:06:02 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:02 --> Input Class Initialized
INFO - 2024-03-11 15:06:02 --> Language Class Initialized
INFO - 2024-03-11 15:06:02 --> Language Class Initialized
INFO - 2024-03-11 15:06:02 --> Config Class Initialized
INFO - 2024-03-11 15:06:02 --> Loader Class Initialized
INFO - 2024-03-11 15:06:02 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:02 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:02 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:02 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:02 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:02 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-11 15:06:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:02 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:02 --> Total execution time: 0.1482
INFO - 2024-03-11 15:06:04 --> Config Class Initialized
INFO - 2024-03-11 15:06:04 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:04 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:04 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:04 --> URI Class Initialized
DEBUG - 2024-03-11 15:06:04 --> No URI present. Default controller set.
INFO - 2024-03-11 15:06:04 --> Router Class Initialized
INFO - 2024-03-11 15:06:04 --> Output Class Initialized
INFO - 2024-03-11 15:06:04 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:04 --> Input Class Initialized
INFO - 2024-03-11 15:06:04 --> Language Class Initialized
INFO - 2024-03-11 15:06:04 --> Language Class Initialized
INFO - 2024-03-11 15:06:04 --> Config Class Initialized
INFO - 2024-03-11 15:06:04 --> Loader Class Initialized
INFO - 2024-03-11 15:06:04 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:04 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:04 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:04 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:04 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:04 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-11 15:06:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:04 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:04 --> Total execution time: 0.0547
INFO - 2024-03-11 15:06:07 --> Config Class Initialized
INFO - 2024-03-11 15:06:07 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:07 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:07 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:07 --> URI Class Initialized
DEBUG - 2024-03-11 15:06:07 --> No URI present. Default controller set.
INFO - 2024-03-11 15:06:07 --> Router Class Initialized
INFO - 2024-03-11 15:06:07 --> Output Class Initialized
INFO - 2024-03-11 15:06:07 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:07 --> Input Class Initialized
INFO - 2024-03-11 15:06:07 --> Language Class Initialized
INFO - 2024-03-11 15:06:07 --> Language Class Initialized
INFO - 2024-03-11 15:06:07 --> Config Class Initialized
INFO - 2024-03-11 15:06:07 --> Loader Class Initialized
INFO - 2024-03-11 15:06:07 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:07 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:07 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:07 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:07 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:07 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-11 15:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:07 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:07 --> Total execution time: 0.0647
INFO - 2024-03-11 15:06:09 --> Config Class Initialized
INFO - 2024-03-11 15:06:09 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:09 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:09 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:09 --> URI Class Initialized
INFO - 2024-03-11 15:06:09 --> Router Class Initialized
INFO - 2024-03-11 15:06:09 --> Output Class Initialized
INFO - 2024-03-11 15:06:09 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:09 --> Input Class Initialized
INFO - 2024-03-11 15:06:09 --> Language Class Initialized
INFO - 2024-03-11 15:06:09 --> Language Class Initialized
INFO - 2024-03-11 15:06:09 --> Config Class Initialized
INFO - 2024-03-11 15:06:09 --> Loader Class Initialized
INFO - 2024-03-11 15:06:09 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:09 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:09 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:09 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:09 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:09 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-11 15:06:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:09 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:09 --> Total execution time: 0.0683
INFO - 2024-03-11 15:06:11 --> Config Class Initialized
INFO - 2024-03-11 15:06:11 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:11 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:11 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:11 --> URI Class Initialized
INFO - 2024-03-11 15:06:11 --> Router Class Initialized
INFO - 2024-03-11 15:06:11 --> Output Class Initialized
INFO - 2024-03-11 15:06:11 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:11 --> Input Class Initialized
INFO - 2024-03-11 15:06:11 --> Language Class Initialized
INFO - 2024-03-11 15:06:11 --> Language Class Initialized
INFO - 2024-03-11 15:06:11 --> Config Class Initialized
INFO - 2024-03-11 15:06:11 --> Loader Class Initialized
INFO - 2024-03-11 15:06:11 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:11 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:11 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:11 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:11 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:11 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-11 15:06:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:11 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:11 --> Total execution time: 0.0394
INFO - 2024-03-11 15:06:12 --> Config Class Initialized
INFO - 2024-03-11 15:06:12 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:12 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:12 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:12 --> URI Class Initialized
DEBUG - 2024-03-11 15:06:12 --> No URI present. Default controller set.
INFO - 2024-03-11 15:06:12 --> Router Class Initialized
INFO - 2024-03-11 15:06:12 --> Output Class Initialized
INFO - 2024-03-11 15:06:12 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:12 --> Input Class Initialized
INFO - 2024-03-11 15:06:12 --> Language Class Initialized
INFO - 2024-03-11 15:06:12 --> Language Class Initialized
INFO - 2024-03-11 15:06:12 --> Config Class Initialized
INFO - 2024-03-11 15:06:12 --> Loader Class Initialized
INFO - 2024-03-11 15:06:12 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:12 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:12 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:12 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:12 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:12 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-11 15:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:12 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:12 --> Total execution time: 0.1229
INFO - 2024-03-11 15:06:13 --> Config Class Initialized
INFO - 2024-03-11 15:06:13 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:13 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:13 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:13 --> URI Class Initialized
INFO - 2024-03-11 15:06:13 --> Router Class Initialized
INFO - 2024-03-11 15:06:13 --> Output Class Initialized
INFO - 2024-03-11 15:06:13 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:13 --> Input Class Initialized
INFO - 2024-03-11 15:06:13 --> Language Class Initialized
INFO - 2024-03-11 15:06:13 --> Language Class Initialized
INFO - 2024-03-11 15:06:13 --> Config Class Initialized
INFO - 2024-03-11 15:06:13 --> Loader Class Initialized
INFO - 2024-03-11 15:06:13 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:13 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:13 --> Controller Class Initialized
INFO - 2024-03-11 15:06:13 --> Helper loaded: cookie_helper
INFO - 2024-03-11 15:06:13 --> Config Class Initialized
INFO - 2024-03-11 15:06:13 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:13 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:13 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:13 --> URI Class Initialized
INFO - 2024-03-11 15:06:13 --> Router Class Initialized
INFO - 2024-03-11 15:06:13 --> Output Class Initialized
INFO - 2024-03-11 15:06:13 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:13 --> Input Class Initialized
INFO - 2024-03-11 15:06:13 --> Language Class Initialized
INFO - 2024-03-11 15:06:13 --> Language Class Initialized
INFO - 2024-03-11 15:06:13 --> Config Class Initialized
INFO - 2024-03-11 15:06:13 --> Loader Class Initialized
INFO - 2024-03-11 15:06:13 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:13 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:13 --> Controller Class Initialized
INFO - 2024-03-11 15:06:13 --> Config Class Initialized
INFO - 2024-03-11 15:06:13 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:13 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:13 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:13 --> URI Class Initialized
INFO - 2024-03-11 15:06:13 --> Router Class Initialized
INFO - 2024-03-11 15:06:13 --> Output Class Initialized
INFO - 2024-03-11 15:06:13 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:13 --> Input Class Initialized
INFO - 2024-03-11 15:06:13 --> Language Class Initialized
INFO - 2024-03-11 15:06:13 --> Language Class Initialized
INFO - 2024-03-11 15:06:13 --> Config Class Initialized
INFO - 2024-03-11 15:06:13 --> Loader Class Initialized
INFO - 2024-03-11 15:06:13 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:13 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:13 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:13 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-11 15:06:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:13 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:13 --> Total execution time: 0.0646
INFO - 2024-03-11 15:06:15 --> Config Class Initialized
INFO - 2024-03-11 15:06:15 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:15 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:15 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:15 --> URI Class Initialized
INFO - 2024-03-11 15:06:15 --> Router Class Initialized
INFO - 2024-03-11 15:06:15 --> Output Class Initialized
INFO - 2024-03-11 15:06:15 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:15 --> Input Class Initialized
INFO - 2024-03-11 15:06:15 --> Language Class Initialized
INFO - 2024-03-11 15:06:15 --> Language Class Initialized
INFO - 2024-03-11 15:06:15 --> Config Class Initialized
INFO - 2024-03-11 15:06:15 --> Loader Class Initialized
INFO - 2024-03-11 15:06:15 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:15 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:15 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:15 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:15 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:15 --> Controller Class Initialized
INFO - 2024-03-11 15:06:15 --> Helper loaded: cookie_helper
INFO - 2024-03-11 15:06:15 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:15 --> Total execution time: 0.0747
INFO - 2024-03-11 15:06:15 --> Config Class Initialized
INFO - 2024-03-11 15:06:15 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:15 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:15 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:15 --> URI Class Initialized
INFO - 2024-03-11 15:06:15 --> Router Class Initialized
INFO - 2024-03-11 15:06:15 --> Output Class Initialized
INFO - 2024-03-11 15:06:15 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:15 --> Input Class Initialized
INFO - 2024-03-11 15:06:15 --> Language Class Initialized
INFO - 2024-03-11 15:06:15 --> Language Class Initialized
INFO - 2024-03-11 15:06:15 --> Config Class Initialized
INFO - 2024-03-11 15:06:15 --> Loader Class Initialized
INFO - 2024-03-11 15:06:15 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:15 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:15 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:15 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:15 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:15 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-11 15:06:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:15 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:15 --> Total execution time: 0.0404
INFO - 2024-03-11 15:06:17 --> Config Class Initialized
INFO - 2024-03-11 15:06:17 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:17 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:17 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:17 --> URI Class Initialized
INFO - 2024-03-11 15:06:17 --> Router Class Initialized
INFO - 2024-03-11 15:06:17 --> Output Class Initialized
INFO - 2024-03-11 15:06:17 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:17 --> Input Class Initialized
INFO - 2024-03-11 15:06:17 --> Language Class Initialized
INFO - 2024-03-11 15:06:17 --> Language Class Initialized
INFO - 2024-03-11 15:06:17 --> Config Class Initialized
INFO - 2024-03-11 15:06:17 --> Loader Class Initialized
INFO - 2024-03-11 15:06:17 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:17 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:17 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:17 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:17 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:17 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-11 15:06:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:17 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:17 --> Total execution time: 0.0310
INFO - 2024-03-11 15:06:19 --> Config Class Initialized
INFO - 2024-03-11 15:06:19 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:19 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:19 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:19 --> URI Class Initialized
INFO - 2024-03-11 15:06:19 --> Router Class Initialized
INFO - 2024-03-11 15:06:19 --> Output Class Initialized
INFO - 2024-03-11 15:06:19 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:19 --> Input Class Initialized
INFO - 2024-03-11 15:06:19 --> Language Class Initialized
INFO - 2024-03-11 15:06:19 --> Language Class Initialized
INFO - 2024-03-11 15:06:19 --> Config Class Initialized
INFO - 2024-03-11 15:06:19 --> Loader Class Initialized
INFO - 2024-03-11 15:06:19 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:19 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:19 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:19 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:19 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:19 --> Controller Class Initialized
DEBUG - 2024-03-11 15:06:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-11 15:06:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:06:19 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:19 --> Total execution time: 0.1667
INFO - 2024-03-11 15:06:19 --> Config Class Initialized
INFO - 2024-03-11 15:06:19 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:19 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:19 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:19 --> URI Class Initialized
INFO - 2024-03-11 15:06:19 --> Router Class Initialized
INFO - 2024-03-11 15:06:19 --> Output Class Initialized
INFO - 2024-03-11 15:06:19 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:19 --> Input Class Initialized
INFO - 2024-03-11 15:06:19 --> Language Class Initialized
INFO - 2024-03-11 15:06:19 --> Language Class Initialized
INFO - 2024-03-11 15:06:19 --> Config Class Initialized
INFO - 2024-03-11 15:06:19 --> Loader Class Initialized
INFO - 2024-03-11 15:06:19 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:19 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:19 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:19 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:19 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:19 --> Controller Class Initialized
INFO - 2024-03-11 15:06:23 --> Config Class Initialized
INFO - 2024-03-11 15:06:23 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:23 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:23 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:23 --> URI Class Initialized
INFO - 2024-03-11 15:06:23 --> Router Class Initialized
INFO - 2024-03-11 15:06:23 --> Output Class Initialized
INFO - 2024-03-11 15:06:23 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:23 --> Input Class Initialized
INFO - 2024-03-11 15:06:23 --> Language Class Initialized
INFO - 2024-03-11 15:06:23 --> Language Class Initialized
INFO - 2024-03-11 15:06:23 --> Config Class Initialized
INFO - 2024-03-11 15:06:23 --> Loader Class Initialized
INFO - 2024-03-11 15:06:23 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:23 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:23 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:23 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:23 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:23 --> Controller Class Initialized
INFO - 2024-03-11 15:06:23 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:23 --> Total execution time: 0.2776
INFO - 2024-03-11 15:06:26 --> Config Class Initialized
INFO - 2024-03-11 15:06:26 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:26 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:26 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:26 --> URI Class Initialized
INFO - 2024-03-11 15:06:26 --> Router Class Initialized
INFO - 2024-03-11 15:06:26 --> Output Class Initialized
INFO - 2024-03-11 15:06:26 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:26 --> Input Class Initialized
INFO - 2024-03-11 15:06:26 --> Language Class Initialized
INFO - 2024-03-11 15:06:26 --> Language Class Initialized
INFO - 2024-03-11 15:06:26 --> Config Class Initialized
INFO - 2024-03-11 15:06:26 --> Loader Class Initialized
INFO - 2024-03-11 15:06:26 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:26 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:26 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:26 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:26 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:26 --> Controller Class Initialized
INFO - 2024-03-11 15:06:26 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:26 --> Total execution time: 0.0411
INFO - 2024-03-11 15:06:36 --> Config Class Initialized
INFO - 2024-03-11 15:06:36 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:36 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:36 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:36 --> URI Class Initialized
INFO - 2024-03-11 15:06:36 --> Router Class Initialized
INFO - 2024-03-11 15:06:36 --> Output Class Initialized
INFO - 2024-03-11 15:06:36 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:36 --> Input Class Initialized
INFO - 2024-03-11 15:06:36 --> Language Class Initialized
INFO - 2024-03-11 15:06:36 --> Language Class Initialized
INFO - 2024-03-11 15:06:36 --> Config Class Initialized
INFO - 2024-03-11 15:06:36 --> Loader Class Initialized
INFO - 2024-03-11 15:06:36 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:36 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:36 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:36 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:36 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:36 --> Controller Class Initialized
INFO - 2024-03-11 15:06:36 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:36 --> Total execution time: 0.0715
INFO - 2024-03-11 15:06:37 --> Config Class Initialized
INFO - 2024-03-11 15:06:37 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:37 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:37 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:37 --> URI Class Initialized
INFO - 2024-03-11 15:06:37 --> Router Class Initialized
INFO - 2024-03-11 15:06:37 --> Output Class Initialized
INFO - 2024-03-11 15:06:37 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:37 --> Input Class Initialized
INFO - 2024-03-11 15:06:37 --> Language Class Initialized
INFO - 2024-03-11 15:06:37 --> Language Class Initialized
INFO - 2024-03-11 15:06:37 --> Config Class Initialized
INFO - 2024-03-11 15:06:37 --> Loader Class Initialized
INFO - 2024-03-11 15:06:37 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:37 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:37 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:37 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:37 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:37 --> Controller Class Initialized
INFO - 2024-03-11 15:06:39 --> Config Class Initialized
INFO - 2024-03-11 15:06:39 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:39 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:39 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:39 --> URI Class Initialized
INFO - 2024-03-11 15:06:39 --> Router Class Initialized
INFO - 2024-03-11 15:06:39 --> Output Class Initialized
INFO - 2024-03-11 15:06:39 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:39 --> Input Class Initialized
INFO - 2024-03-11 15:06:39 --> Language Class Initialized
INFO - 2024-03-11 15:06:39 --> Language Class Initialized
INFO - 2024-03-11 15:06:39 --> Config Class Initialized
INFO - 2024-03-11 15:06:39 --> Loader Class Initialized
INFO - 2024-03-11 15:06:39 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:39 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:39 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:39 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:39 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:39 --> Controller Class Initialized
INFO - 2024-03-11 15:06:39 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:39 --> Total execution time: 0.0770
INFO - 2024-03-11 15:06:51 --> Config Class Initialized
INFO - 2024-03-11 15:06:51 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:51 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:51 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:51 --> URI Class Initialized
INFO - 2024-03-11 15:06:51 --> Router Class Initialized
INFO - 2024-03-11 15:06:51 --> Output Class Initialized
INFO - 2024-03-11 15:06:51 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:52 --> Input Class Initialized
INFO - 2024-03-11 15:06:52 --> Language Class Initialized
INFO - 2024-03-11 15:06:52 --> Language Class Initialized
INFO - 2024-03-11 15:06:52 --> Config Class Initialized
INFO - 2024-03-11 15:06:52 --> Loader Class Initialized
INFO - 2024-03-11 15:06:52 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:52 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:52 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:52 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:52 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:52 --> Controller Class Initialized
INFO - 2024-03-11 15:06:52 --> Final output sent to browser
DEBUG - 2024-03-11 15:06:52 --> Total execution time: 0.0343
INFO - 2024-03-11 15:06:52 --> Config Class Initialized
INFO - 2024-03-11 15:06:52 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:52 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:52 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:52 --> URI Class Initialized
INFO - 2024-03-11 15:06:52 --> Router Class Initialized
INFO - 2024-03-11 15:06:52 --> Output Class Initialized
INFO - 2024-03-11 15:06:52 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:52 --> Input Class Initialized
INFO - 2024-03-11 15:06:52 --> Language Class Initialized
INFO - 2024-03-11 15:06:52 --> Language Class Initialized
INFO - 2024-03-11 15:06:52 --> Config Class Initialized
INFO - 2024-03-11 15:06:52 --> Loader Class Initialized
INFO - 2024-03-11 15:06:52 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:52 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:52 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:52 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:52 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:52 --> Controller Class Initialized
INFO - 2024-03-11 15:06:58 --> Config Class Initialized
INFO - 2024-03-11 15:06:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:06:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:06:58 --> Utf8 Class Initialized
INFO - 2024-03-11 15:06:58 --> URI Class Initialized
INFO - 2024-03-11 15:06:58 --> Router Class Initialized
INFO - 2024-03-11 15:06:58 --> Output Class Initialized
INFO - 2024-03-11 15:06:58 --> Security Class Initialized
DEBUG - 2024-03-11 15:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:06:58 --> Input Class Initialized
INFO - 2024-03-11 15:06:58 --> Language Class Initialized
INFO - 2024-03-11 15:06:58 --> Language Class Initialized
INFO - 2024-03-11 15:06:58 --> Config Class Initialized
INFO - 2024-03-11 15:06:58 --> Loader Class Initialized
INFO - 2024-03-11 15:06:58 --> Helper loaded: url_helper
INFO - 2024-03-11 15:06:58 --> Helper loaded: file_helper
INFO - 2024-03-11 15:06:58 --> Helper loaded: form_helper
INFO - 2024-03-11 15:06:58 --> Helper loaded: my_helper
INFO - 2024-03-11 15:06:58 --> Database Driver Class Initialized
INFO - 2024-03-11 15:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:06:58 --> Controller Class Initialized
INFO - 2024-03-11 15:10:29 --> Config Class Initialized
INFO - 2024-03-11 15:10:29 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:10:29 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:10:29 --> Utf8 Class Initialized
INFO - 2024-03-11 15:10:29 --> URI Class Initialized
INFO - 2024-03-11 15:10:29 --> Router Class Initialized
INFO - 2024-03-11 15:10:29 --> Output Class Initialized
INFO - 2024-03-11 15:10:29 --> Security Class Initialized
DEBUG - 2024-03-11 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:10:29 --> Input Class Initialized
INFO - 2024-03-11 15:10:29 --> Language Class Initialized
INFO - 2024-03-11 15:10:29 --> Language Class Initialized
INFO - 2024-03-11 15:10:29 --> Config Class Initialized
INFO - 2024-03-11 15:10:29 --> Loader Class Initialized
INFO - 2024-03-11 15:10:29 --> Helper loaded: url_helper
INFO - 2024-03-11 15:10:29 --> Helper loaded: file_helper
INFO - 2024-03-11 15:10:29 --> Helper loaded: form_helper
INFO - 2024-03-11 15:10:29 --> Helper loaded: my_helper
INFO - 2024-03-11 15:10:29 --> Database Driver Class Initialized
INFO - 2024-03-11 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:10:29 --> Controller Class Initialized
INFO - 2024-03-11 15:13:23 --> Config Class Initialized
INFO - 2024-03-11 15:13:23 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:23 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:23 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:23 --> URI Class Initialized
INFO - 2024-03-11 15:13:23 --> Router Class Initialized
INFO - 2024-03-11 15:13:23 --> Output Class Initialized
INFO - 2024-03-11 15:13:23 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:23 --> Input Class Initialized
INFO - 2024-03-11 15:13:23 --> Language Class Initialized
INFO - 2024-03-11 15:13:23 --> Language Class Initialized
INFO - 2024-03-11 15:13:23 --> Config Class Initialized
INFO - 2024-03-11 15:13:23 --> Loader Class Initialized
INFO - 2024-03-11 15:13:23 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:23 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:23 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:23 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:23 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:23 --> Controller Class Initialized
DEBUG - 2024-03-11 15:13:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-03-11 15:13:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:13:23 --> Final output sent to browser
DEBUG - 2024-03-11 15:13:23 --> Total execution time: 0.0655
INFO - 2024-03-11 15:13:30 --> Config Class Initialized
INFO - 2024-03-11 15:13:30 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:30 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:30 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:30 --> URI Class Initialized
INFO - 2024-03-11 15:13:30 --> Router Class Initialized
INFO - 2024-03-11 15:13:30 --> Output Class Initialized
INFO - 2024-03-11 15:13:30 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:30 --> Input Class Initialized
INFO - 2024-03-11 15:13:30 --> Language Class Initialized
INFO - 2024-03-11 15:13:30 --> Language Class Initialized
INFO - 2024-03-11 15:13:30 --> Config Class Initialized
INFO - 2024-03-11 15:13:30 --> Loader Class Initialized
INFO - 2024-03-11 15:13:30 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:30 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:30 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:30 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:30 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:30 --> Controller Class Initialized
INFO - 2024-03-11 15:13:30 --> Config Class Initialized
INFO - 2024-03-11 15:13:30 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:30 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:30 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:30 --> URI Class Initialized
INFO - 2024-03-11 15:13:30 --> Router Class Initialized
INFO - 2024-03-11 15:13:30 --> Output Class Initialized
INFO - 2024-03-11 15:13:30 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:30 --> Input Class Initialized
INFO - 2024-03-11 15:13:30 --> Language Class Initialized
INFO - 2024-03-11 15:13:30 --> Language Class Initialized
INFO - 2024-03-11 15:13:30 --> Config Class Initialized
INFO - 2024-03-11 15:13:30 --> Loader Class Initialized
INFO - 2024-03-11 15:13:30 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:30 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:30 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:30 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:30 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:31 --> Controller Class Initialized
DEBUG - 2024-03-11 15:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-11 15:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:13:31 --> Final output sent to browser
DEBUG - 2024-03-11 15:13:31 --> Total execution time: 0.0545
INFO - 2024-03-11 15:13:31 --> Config Class Initialized
INFO - 2024-03-11 15:13:31 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:31 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:31 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:31 --> URI Class Initialized
INFO - 2024-03-11 15:13:31 --> Router Class Initialized
INFO - 2024-03-11 15:13:31 --> Output Class Initialized
INFO - 2024-03-11 15:13:31 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:31 --> Input Class Initialized
INFO - 2024-03-11 15:13:31 --> Language Class Initialized
INFO - 2024-03-11 15:13:31 --> Language Class Initialized
INFO - 2024-03-11 15:13:31 --> Config Class Initialized
INFO - 2024-03-11 15:13:31 --> Loader Class Initialized
INFO - 2024-03-11 15:13:31 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:31 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:31 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:31 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:31 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:31 --> Controller Class Initialized
INFO - 2024-03-11 15:13:33 --> Config Class Initialized
INFO - 2024-03-11 15:13:33 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:33 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:33 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:33 --> URI Class Initialized
INFO - 2024-03-11 15:13:33 --> Router Class Initialized
INFO - 2024-03-11 15:13:33 --> Output Class Initialized
INFO - 2024-03-11 15:13:33 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:33 --> Input Class Initialized
INFO - 2024-03-11 15:13:33 --> Language Class Initialized
INFO - 2024-03-11 15:13:33 --> Language Class Initialized
INFO - 2024-03-11 15:13:33 --> Config Class Initialized
INFO - 2024-03-11 15:13:33 --> Loader Class Initialized
INFO - 2024-03-11 15:13:33 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:33 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:33 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:33 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:33 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:33 --> Controller Class Initialized
INFO - 2024-03-11 15:13:33 --> Final output sent to browser
DEBUG - 2024-03-11 15:13:33 --> Total execution time: 0.2236
INFO - 2024-03-11 15:13:38 --> Config Class Initialized
INFO - 2024-03-11 15:13:38 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:38 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:38 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:38 --> URI Class Initialized
INFO - 2024-03-11 15:13:38 --> Router Class Initialized
INFO - 2024-03-11 15:13:38 --> Output Class Initialized
INFO - 2024-03-11 15:13:38 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:38 --> Input Class Initialized
INFO - 2024-03-11 15:13:38 --> Language Class Initialized
INFO - 2024-03-11 15:13:38 --> Language Class Initialized
INFO - 2024-03-11 15:13:38 --> Config Class Initialized
INFO - 2024-03-11 15:13:38 --> Loader Class Initialized
INFO - 2024-03-11 15:13:38 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:38 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:38 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:38 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:38 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:38 --> Controller Class Initialized
INFO - 2024-03-11 15:13:38 --> Final output sent to browser
DEBUG - 2024-03-11 15:13:38 --> Total execution time: 0.1791
INFO - 2024-03-11 15:13:40 --> Config Class Initialized
INFO - 2024-03-11 15:13:40 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:13:40 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:13:40 --> Utf8 Class Initialized
INFO - 2024-03-11 15:13:40 --> URI Class Initialized
INFO - 2024-03-11 15:13:40 --> Router Class Initialized
INFO - 2024-03-11 15:13:40 --> Output Class Initialized
INFO - 2024-03-11 15:13:40 --> Security Class Initialized
DEBUG - 2024-03-11 15:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:13:40 --> Input Class Initialized
INFO - 2024-03-11 15:13:40 --> Language Class Initialized
INFO - 2024-03-11 15:13:40 --> Language Class Initialized
INFO - 2024-03-11 15:13:40 --> Config Class Initialized
INFO - 2024-03-11 15:13:40 --> Loader Class Initialized
INFO - 2024-03-11 15:13:40 --> Helper loaded: url_helper
INFO - 2024-03-11 15:13:40 --> Helper loaded: file_helper
INFO - 2024-03-11 15:13:40 --> Helper loaded: form_helper
INFO - 2024-03-11 15:13:40 --> Helper loaded: my_helper
INFO - 2024-03-11 15:13:40 --> Database Driver Class Initialized
INFO - 2024-03-11 15:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:13:40 --> Controller Class Initialized
INFO - 2024-03-11 15:13:40 --> Final output sent to browser
DEBUG - 2024-03-11 15:13:40 --> Total execution time: 0.0463
INFO - 2024-03-11 15:16:31 --> Config Class Initialized
INFO - 2024-03-11 15:16:31 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:31 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:31 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:31 --> URI Class Initialized
INFO - 2024-03-11 15:16:31 --> Router Class Initialized
INFO - 2024-03-11 15:16:31 --> Output Class Initialized
INFO - 2024-03-11 15:16:31 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:31 --> Input Class Initialized
INFO - 2024-03-11 15:16:31 --> Language Class Initialized
INFO - 2024-03-11 15:16:31 --> Language Class Initialized
INFO - 2024-03-11 15:16:31 --> Config Class Initialized
INFO - 2024-03-11 15:16:31 --> Loader Class Initialized
INFO - 2024-03-11 15:16:31 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:31 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:31 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:31 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:31 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:31 --> Controller Class Initialized
DEBUG - 2024-03-11 15:16:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-11 15:16:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:16:31 --> Final output sent to browser
DEBUG - 2024-03-11 15:16:31 --> Total execution time: 0.0561
INFO - 2024-03-11 15:16:32 --> Config Class Initialized
INFO - 2024-03-11 15:16:32 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:32 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:32 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:32 --> URI Class Initialized
INFO - 2024-03-11 15:16:32 --> Router Class Initialized
INFO - 2024-03-11 15:16:32 --> Output Class Initialized
INFO - 2024-03-11 15:16:32 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:32 --> Input Class Initialized
INFO - 2024-03-11 15:16:32 --> Language Class Initialized
INFO - 2024-03-11 15:16:32 --> Language Class Initialized
INFO - 2024-03-11 15:16:32 --> Config Class Initialized
INFO - 2024-03-11 15:16:32 --> Loader Class Initialized
INFO - 2024-03-11 15:16:32 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:32 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:32 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:32 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:32 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:32 --> Controller Class Initialized
DEBUG - 2024-03-11 15:16:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-11 15:16:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:16:32 --> Final output sent to browser
DEBUG - 2024-03-11 15:16:32 --> Total execution time: 0.0374
INFO - 2024-03-11 15:16:33 --> Config Class Initialized
INFO - 2024-03-11 15:16:33 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:33 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:33 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:33 --> URI Class Initialized
INFO - 2024-03-11 15:16:33 --> Router Class Initialized
INFO - 2024-03-11 15:16:33 --> Output Class Initialized
INFO - 2024-03-11 15:16:33 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:33 --> Input Class Initialized
INFO - 2024-03-11 15:16:33 --> Language Class Initialized
INFO - 2024-03-11 15:16:33 --> Language Class Initialized
INFO - 2024-03-11 15:16:33 --> Config Class Initialized
INFO - 2024-03-11 15:16:33 --> Loader Class Initialized
INFO - 2024-03-11 15:16:33 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:33 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:33 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:33 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:33 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:33 --> Controller Class Initialized
INFO - 2024-03-11 15:16:36 --> Config Class Initialized
INFO - 2024-03-11 15:16:36 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:36 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:36 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:36 --> URI Class Initialized
INFO - 2024-03-11 15:16:36 --> Router Class Initialized
INFO - 2024-03-11 15:16:36 --> Output Class Initialized
INFO - 2024-03-11 15:16:36 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:36 --> Input Class Initialized
INFO - 2024-03-11 15:16:36 --> Language Class Initialized
INFO - 2024-03-11 15:16:36 --> Language Class Initialized
INFO - 2024-03-11 15:16:36 --> Config Class Initialized
INFO - 2024-03-11 15:16:36 --> Loader Class Initialized
INFO - 2024-03-11 15:16:36 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:36 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:36 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:36 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:36 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:36 --> Controller Class Initialized
INFO - 2024-03-11 15:16:37 --> Final output sent to browser
DEBUG - 2024-03-11 15:16:37 --> Total execution time: 0.0778
INFO - 2024-03-11 15:16:44 --> Config Class Initialized
INFO - 2024-03-11 15:16:44 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:44 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:44 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:44 --> URI Class Initialized
INFO - 2024-03-11 15:16:44 --> Router Class Initialized
INFO - 2024-03-11 15:16:44 --> Output Class Initialized
INFO - 2024-03-11 15:16:44 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:44 --> Input Class Initialized
INFO - 2024-03-11 15:16:44 --> Language Class Initialized
INFO - 2024-03-11 15:16:44 --> Language Class Initialized
INFO - 2024-03-11 15:16:44 --> Config Class Initialized
INFO - 2024-03-11 15:16:44 --> Loader Class Initialized
INFO - 2024-03-11 15:16:44 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:44 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:44 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:44 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:44 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:44 --> Controller Class Initialized
INFO - 2024-03-11 15:16:44 --> Final output sent to browser
DEBUG - 2024-03-11 15:16:44 --> Total execution time: 0.0425
INFO - 2024-03-11 15:16:44 --> Config Class Initialized
INFO - 2024-03-11 15:16:44 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:44 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:44 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:44 --> URI Class Initialized
INFO - 2024-03-11 15:16:44 --> Router Class Initialized
INFO - 2024-03-11 15:16:44 --> Output Class Initialized
INFO - 2024-03-11 15:16:44 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:44 --> Input Class Initialized
INFO - 2024-03-11 15:16:44 --> Language Class Initialized
INFO - 2024-03-11 15:16:44 --> Language Class Initialized
INFO - 2024-03-11 15:16:44 --> Config Class Initialized
INFO - 2024-03-11 15:16:44 --> Loader Class Initialized
INFO - 2024-03-11 15:16:44 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:44 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:44 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:44 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:44 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:44 --> Controller Class Initialized
INFO - 2024-03-11 15:16:46 --> Config Class Initialized
INFO - 2024-03-11 15:16:46 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:46 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:46 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:46 --> URI Class Initialized
INFO - 2024-03-11 15:16:46 --> Router Class Initialized
INFO - 2024-03-11 15:16:46 --> Output Class Initialized
INFO - 2024-03-11 15:16:46 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:46 --> Input Class Initialized
INFO - 2024-03-11 15:16:46 --> Language Class Initialized
INFO - 2024-03-11 15:16:46 --> Language Class Initialized
INFO - 2024-03-11 15:16:46 --> Config Class Initialized
INFO - 2024-03-11 15:16:46 --> Loader Class Initialized
INFO - 2024-03-11 15:16:46 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:46 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:46 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:46 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:46 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:46 --> Controller Class Initialized
INFO - 2024-03-11 15:16:46 --> Final output sent to browser
DEBUG - 2024-03-11 15:16:46 --> Total execution time: 0.1077
INFO - 2024-03-11 15:16:55 --> Config Class Initialized
INFO - 2024-03-11 15:16:55 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:55 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:55 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:55 --> URI Class Initialized
INFO - 2024-03-11 15:16:55 --> Router Class Initialized
INFO - 2024-03-11 15:16:55 --> Output Class Initialized
INFO - 2024-03-11 15:16:55 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:55 --> Input Class Initialized
INFO - 2024-03-11 15:16:55 --> Language Class Initialized
INFO - 2024-03-11 15:16:55 --> Language Class Initialized
INFO - 2024-03-11 15:16:55 --> Config Class Initialized
INFO - 2024-03-11 15:16:55 --> Loader Class Initialized
INFO - 2024-03-11 15:16:55 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:55 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:55 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:55 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:55 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:55 --> Controller Class Initialized
INFO - 2024-03-11 15:16:55 --> Final output sent to browser
DEBUG - 2024-03-11 15:16:55 --> Total execution time: 0.1318
INFO - 2024-03-11 15:16:56 --> Config Class Initialized
INFO - 2024-03-11 15:16:56 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:56 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:56 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:56 --> URI Class Initialized
INFO - 2024-03-11 15:16:56 --> Router Class Initialized
INFO - 2024-03-11 15:16:56 --> Output Class Initialized
INFO - 2024-03-11 15:16:56 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:56 --> Input Class Initialized
INFO - 2024-03-11 15:16:56 --> Language Class Initialized
INFO - 2024-03-11 15:16:56 --> Language Class Initialized
INFO - 2024-03-11 15:16:56 --> Config Class Initialized
INFO - 2024-03-11 15:16:56 --> Loader Class Initialized
INFO - 2024-03-11 15:16:56 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:56 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:56 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:56 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:56 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:56 --> Controller Class Initialized
INFO - 2024-03-11 15:16:58 --> Config Class Initialized
INFO - 2024-03-11 15:16:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:16:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:16:58 --> Utf8 Class Initialized
INFO - 2024-03-11 15:16:58 --> URI Class Initialized
INFO - 2024-03-11 15:16:58 --> Router Class Initialized
INFO - 2024-03-11 15:16:58 --> Output Class Initialized
INFO - 2024-03-11 15:16:58 --> Security Class Initialized
DEBUG - 2024-03-11 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:16:58 --> Input Class Initialized
INFO - 2024-03-11 15:16:58 --> Language Class Initialized
INFO - 2024-03-11 15:16:58 --> Language Class Initialized
INFO - 2024-03-11 15:16:58 --> Config Class Initialized
INFO - 2024-03-11 15:16:58 --> Loader Class Initialized
INFO - 2024-03-11 15:16:58 --> Helper loaded: url_helper
INFO - 2024-03-11 15:16:58 --> Helper loaded: file_helper
INFO - 2024-03-11 15:16:58 --> Helper loaded: form_helper
INFO - 2024-03-11 15:16:58 --> Helper loaded: my_helper
INFO - 2024-03-11 15:16:58 --> Database Driver Class Initialized
INFO - 2024-03-11 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:16:58 --> Controller Class Initialized
INFO - 2024-03-11 15:27:08 --> Config Class Initialized
INFO - 2024-03-11 15:27:08 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:08 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:08 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:08 --> URI Class Initialized
INFO - 2024-03-11 15:27:08 --> Router Class Initialized
INFO - 2024-03-11 15:27:08 --> Output Class Initialized
INFO - 2024-03-11 15:27:08 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:08 --> Input Class Initialized
INFO - 2024-03-11 15:27:08 --> Language Class Initialized
INFO - 2024-03-11 15:27:08 --> Language Class Initialized
INFO - 2024-03-11 15:27:08 --> Config Class Initialized
INFO - 2024-03-11 15:27:08 --> Loader Class Initialized
INFO - 2024-03-11 15:27:08 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:08 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:08 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:08 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:08 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:08 --> Controller Class Initialized
DEBUG - 2024-03-11 15:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-03-11 15:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:27:08 --> Final output sent to browser
DEBUG - 2024-03-11 15:27:08 --> Total execution time: 0.0595
INFO - 2024-03-11 15:27:16 --> Config Class Initialized
INFO - 2024-03-11 15:27:16 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:16 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:16 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:16 --> URI Class Initialized
INFO - 2024-03-11 15:27:16 --> Router Class Initialized
INFO - 2024-03-11 15:27:16 --> Output Class Initialized
INFO - 2024-03-11 15:27:16 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:16 --> Input Class Initialized
INFO - 2024-03-11 15:27:16 --> Language Class Initialized
INFO - 2024-03-11 15:27:16 --> Language Class Initialized
INFO - 2024-03-11 15:27:16 --> Config Class Initialized
INFO - 2024-03-11 15:27:16 --> Loader Class Initialized
INFO - 2024-03-11 15:27:16 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:16 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:16 --> Controller Class Initialized
INFO - 2024-03-11 15:27:16 --> Config Class Initialized
INFO - 2024-03-11 15:27:16 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:16 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:16 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:16 --> URI Class Initialized
INFO - 2024-03-11 15:27:16 --> Router Class Initialized
INFO - 2024-03-11 15:27:16 --> Output Class Initialized
INFO - 2024-03-11 15:27:16 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:16 --> Input Class Initialized
INFO - 2024-03-11 15:27:16 --> Language Class Initialized
INFO - 2024-03-11 15:27:16 --> Language Class Initialized
INFO - 2024-03-11 15:27:16 --> Config Class Initialized
INFO - 2024-03-11 15:27:16 --> Loader Class Initialized
INFO - 2024-03-11 15:27:16 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:16 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:16 --> Controller Class Initialized
DEBUG - 2024-03-11 15:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-11 15:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-11 15:27:16 --> Final output sent to browser
DEBUG - 2024-03-11 15:27:16 --> Total execution time: 0.0378
INFO - 2024-03-11 15:27:16 --> Config Class Initialized
INFO - 2024-03-11 15:27:16 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:16 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:16 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:16 --> URI Class Initialized
INFO - 2024-03-11 15:27:16 --> Router Class Initialized
INFO - 2024-03-11 15:27:16 --> Output Class Initialized
INFO - 2024-03-11 15:27:16 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:16 --> Input Class Initialized
INFO - 2024-03-11 15:27:16 --> Language Class Initialized
INFO - 2024-03-11 15:27:16 --> Language Class Initialized
INFO - 2024-03-11 15:27:16 --> Config Class Initialized
INFO - 2024-03-11 15:27:16 --> Loader Class Initialized
INFO - 2024-03-11 15:27:16 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:16 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:16 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:16 --> Controller Class Initialized
INFO - 2024-03-11 15:27:18 --> Config Class Initialized
INFO - 2024-03-11 15:27:18 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:18 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:18 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:18 --> URI Class Initialized
INFO - 2024-03-11 15:27:18 --> Router Class Initialized
INFO - 2024-03-11 15:27:18 --> Output Class Initialized
INFO - 2024-03-11 15:27:18 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:18 --> Input Class Initialized
INFO - 2024-03-11 15:27:18 --> Language Class Initialized
INFO - 2024-03-11 15:27:18 --> Language Class Initialized
INFO - 2024-03-11 15:27:18 --> Config Class Initialized
INFO - 2024-03-11 15:27:18 --> Loader Class Initialized
INFO - 2024-03-11 15:27:18 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:18 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:18 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:18 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:18 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:18 --> Controller Class Initialized
INFO - 2024-03-11 15:27:19 --> Final output sent to browser
DEBUG - 2024-03-11 15:27:19 --> Total execution time: 0.1327
INFO - 2024-03-11 15:27:21 --> Config Class Initialized
INFO - 2024-03-11 15:27:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:21 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:21 --> URI Class Initialized
INFO - 2024-03-11 15:27:21 --> Router Class Initialized
INFO - 2024-03-11 15:27:21 --> Output Class Initialized
INFO - 2024-03-11 15:27:21 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:21 --> Input Class Initialized
INFO - 2024-03-11 15:27:21 --> Language Class Initialized
INFO - 2024-03-11 15:27:21 --> Language Class Initialized
INFO - 2024-03-11 15:27:21 --> Config Class Initialized
INFO - 2024-03-11 15:27:21 --> Loader Class Initialized
INFO - 2024-03-11 15:27:21 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:21 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:21 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:21 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:21 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:21 --> Controller Class Initialized
INFO - 2024-03-11 15:27:21 --> Final output sent to browser
DEBUG - 2024-03-11 15:27:21 --> Total execution time: 0.0582
INFO - 2024-03-11 15:27:22 --> Config Class Initialized
INFO - 2024-03-11 15:27:22 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:27:22 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:27:22 --> Utf8 Class Initialized
INFO - 2024-03-11 15:27:22 --> URI Class Initialized
INFO - 2024-03-11 15:27:22 --> Router Class Initialized
INFO - 2024-03-11 15:27:22 --> Output Class Initialized
INFO - 2024-03-11 15:27:22 --> Security Class Initialized
DEBUG - 2024-03-11 15:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:27:22 --> Input Class Initialized
INFO - 2024-03-11 15:27:22 --> Language Class Initialized
INFO - 2024-03-11 15:27:22 --> Language Class Initialized
INFO - 2024-03-11 15:27:22 --> Config Class Initialized
INFO - 2024-03-11 15:27:22 --> Loader Class Initialized
INFO - 2024-03-11 15:27:22 --> Helper loaded: url_helper
INFO - 2024-03-11 15:27:22 --> Helper loaded: file_helper
INFO - 2024-03-11 15:27:22 --> Helper loaded: form_helper
INFO - 2024-03-11 15:27:22 --> Helper loaded: my_helper
INFO - 2024-03-11 15:27:22 --> Database Driver Class Initialized
INFO - 2024-03-11 15:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:27:22 --> Controller Class Initialized
INFO - 2024-03-11 15:27:22 --> Final output sent to browser
DEBUG - 2024-03-11 15:27:22 --> Total execution time: 0.0763
