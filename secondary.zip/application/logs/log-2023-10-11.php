<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-11 08:57:27 --> Config Class Initialized
INFO - 2023-10-11 08:57:27 --> Hooks Class Initialized
DEBUG - 2023-10-11 08:57:27 --> UTF-8 Support Enabled
INFO - 2023-10-11 08:57:27 --> Utf8 Class Initialized
INFO - 2023-10-11 08:57:27 --> URI Class Initialized
INFO - 2023-10-11 08:57:27 --> Router Class Initialized
INFO - 2023-10-11 08:57:27 --> Output Class Initialized
INFO - 2023-10-11 08:57:27 --> Security Class Initialized
DEBUG - 2023-10-11 08:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 08:57:27 --> Input Class Initialized
INFO - 2023-10-11 08:57:27 --> Language Class Initialized
INFO - 2023-10-11 08:57:27 --> Language Class Initialized
INFO - 2023-10-11 08:57:27 --> Config Class Initialized
INFO - 2023-10-11 08:57:27 --> Loader Class Initialized
INFO - 2023-10-11 08:57:27 --> Helper loaded: url_helper
INFO - 2023-10-11 08:57:27 --> Helper loaded: file_helper
INFO - 2023-10-11 08:57:27 --> Helper loaded: form_helper
INFO - 2023-10-11 08:57:27 --> Helper loaded: my_helper
INFO - 2023-10-11 08:57:27 --> Database Driver Class Initialized
INFO - 2023-10-11 08:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 08:57:27 --> Controller Class Initialized
DEBUG - 2023-10-11 08:57:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-11 08:57:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-11 08:57:27 --> Final output sent to browser
DEBUG - 2023-10-11 08:57:27 --> Total execution time: 0.1095
INFO - 2023-10-11 08:57:28 --> Config Class Initialized
INFO - 2023-10-11 08:57:28 --> Hooks Class Initialized
DEBUG - 2023-10-11 08:57:28 --> UTF-8 Support Enabled
INFO - 2023-10-11 08:57:28 --> Utf8 Class Initialized
INFO - 2023-10-11 08:57:28 --> URI Class Initialized
INFO - 2023-10-11 08:57:28 --> Router Class Initialized
INFO - 2023-10-11 08:57:28 --> Output Class Initialized
INFO - 2023-10-11 08:57:28 --> Security Class Initialized
DEBUG - 2023-10-11 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 08:57:28 --> Input Class Initialized
INFO - 2023-10-11 08:57:28 --> Language Class Initialized
INFO - 2023-10-11 08:57:28 --> Language Class Initialized
INFO - 2023-10-11 08:57:28 --> Config Class Initialized
INFO - 2023-10-11 08:57:28 --> Loader Class Initialized
INFO - 2023-10-11 08:57:28 --> Helper loaded: url_helper
INFO - 2023-10-11 08:57:28 --> Helper loaded: file_helper
INFO - 2023-10-11 08:57:28 --> Helper loaded: form_helper
INFO - 2023-10-11 08:57:28 --> Helper loaded: my_helper
INFO - 2023-10-11 08:57:28 --> Database Driver Class Initialized
INFO - 2023-10-11 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 08:57:28 --> Controller Class Initialized
INFO - 2023-10-11 08:57:30 --> Config Class Initialized
INFO - 2023-10-11 08:57:30 --> Hooks Class Initialized
DEBUG - 2023-10-11 08:57:30 --> UTF-8 Support Enabled
INFO - 2023-10-11 08:57:30 --> Utf8 Class Initialized
INFO - 2023-10-11 08:57:30 --> URI Class Initialized
INFO - 2023-10-11 08:57:30 --> Router Class Initialized
INFO - 2023-10-11 08:57:30 --> Output Class Initialized
INFO - 2023-10-11 08:57:30 --> Security Class Initialized
DEBUG - 2023-10-11 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 08:57:30 --> Input Class Initialized
INFO - 2023-10-11 08:57:30 --> Language Class Initialized
INFO - 2023-10-11 08:57:30 --> Language Class Initialized
INFO - 2023-10-11 08:57:30 --> Config Class Initialized
INFO - 2023-10-11 08:57:30 --> Loader Class Initialized
INFO - 2023-10-11 08:57:30 --> Helper loaded: url_helper
INFO - 2023-10-11 08:57:30 --> Helper loaded: file_helper
INFO - 2023-10-11 08:57:30 --> Helper loaded: form_helper
INFO - 2023-10-11 08:57:30 --> Helper loaded: my_helper
INFO - 2023-10-11 08:57:30 --> Database Driver Class Initialized
INFO - 2023-10-11 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 08:57:30 --> Controller Class Initialized
INFO - 2023-10-11 08:57:31 --> Final output sent to browser
DEBUG - 2023-10-11 08:57:31 --> Total execution time: 0.5195
INFO - 2023-10-11 08:58:46 --> Config Class Initialized
INFO - 2023-10-11 08:58:46 --> Hooks Class Initialized
DEBUG - 2023-10-11 08:58:46 --> UTF-8 Support Enabled
INFO - 2023-10-11 08:58:46 --> Utf8 Class Initialized
INFO - 2023-10-11 08:58:46 --> URI Class Initialized
INFO - 2023-10-11 08:58:46 --> Router Class Initialized
INFO - 2023-10-11 08:58:46 --> Output Class Initialized
INFO - 2023-10-11 08:58:46 --> Security Class Initialized
DEBUG - 2023-10-11 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 08:58:46 --> Input Class Initialized
INFO - 2023-10-11 08:58:46 --> Language Class Initialized
INFO - 2023-10-11 08:58:46 --> Language Class Initialized
INFO - 2023-10-11 08:58:46 --> Config Class Initialized
INFO - 2023-10-11 08:58:46 --> Loader Class Initialized
INFO - 2023-10-11 08:58:46 --> Helper loaded: url_helper
INFO - 2023-10-11 08:58:46 --> Helper loaded: file_helper
INFO - 2023-10-11 08:58:46 --> Helper loaded: form_helper
INFO - 2023-10-11 08:58:46 --> Helper loaded: my_helper
INFO - 2023-10-11 08:58:46 --> Database Driver Class Initialized
INFO - 2023-10-11 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 08:58:46 --> Controller Class Initialized
INFO - 2023-10-11 08:58:50 --> Config Class Initialized
INFO - 2023-10-11 08:58:50 --> Hooks Class Initialized
DEBUG - 2023-10-11 08:58:50 --> UTF-8 Support Enabled
INFO - 2023-10-11 08:58:50 --> Utf8 Class Initialized
INFO - 2023-10-11 08:58:50 --> URI Class Initialized
INFO - 2023-10-11 08:58:50 --> Router Class Initialized
INFO - 2023-10-11 08:58:50 --> Output Class Initialized
INFO - 2023-10-11 08:58:50 --> Security Class Initialized
DEBUG - 2023-10-11 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 08:58:50 --> Input Class Initialized
INFO - 2023-10-11 08:58:50 --> Language Class Initialized
INFO - 2023-10-11 08:58:50 --> Language Class Initialized
INFO - 2023-10-11 08:58:50 --> Config Class Initialized
INFO - 2023-10-11 08:58:50 --> Loader Class Initialized
INFO - 2023-10-11 08:58:50 --> Helper loaded: url_helper
INFO - 2023-10-11 08:58:50 --> Helper loaded: file_helper
INFO - 2023-10-11 08:58:50 --> Helper loaded: form_helper
INFO - 2023-10-11 08:58:50 --> Helper loaded: my_helper
INFO - 2023-10-11 08:58:50 --> Database Driver Class Initialized
INFO - 2023-10-11 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 08:58:50 --> Controller Class Initialized
INFO - 2023-10-11 08:58:50 --> Final output sent to browser
DEBUG - 2023-10-11 08:58:50 --> Total execution time: 0.3256
INFO - 2023-10-11 08:58:52 --> Config Class Initialized
INFO - 2023-10-11 08:58:52 --> Hooks Class Initialized
DEBUG - 2023-10-11 08:58:52 --> UTF-8 Support Enabled
INFO - 2023-10-11 08:58:52 --> Utf8 Class Initialized
INFO - 2023-10-11 08:58:52 --> URI Class Initialized
INFO - 2023-10-11 08:58:52 --> Router Class Initialized
INFO - 2023-10-11 08:58:52 --> Output Class Initialized
INFO - 2023-10-11 08:58:52 --> Security Class Initialized
DEBUG - 2023-10-11 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 08:58:52 --> Input Class Initialized
INFO - 2023-10-11 08:58:52 --> Language Class Initialized
INFO - 2023-10-11 08:58:52 --> Language Class Initialized
INFO - 2023-10-11 08:58:52 --> Config Class Initialized
INFO - 2023-10-11 08:58:52 --> Loader Class Initialized
INFO - 2023-10-11 08:58:52 --> Helper loaded: url_helper
INFO - 2023-10-11 08:58:52 --> Helper loaded: file_helper
INFO - 2023-10-11 08:58:52 --> Helper loaded: form_helper
INFO - 2023-10-11 08:58:52 --> Helper loaded: my_helper
INFO - 2023-10-11 08:58:52 --> Database Driver Class Initialized
INFO - 2023-10-11 08:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 08:58:52 --> Controller Class Initialized
INFO - 2023-10-11 09:03:51 --> Config Class Initialized
INFO - 2023-10-11 09:03:51 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:51 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:51 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:51 --> URI Class Initialized
DEBUG - 2023-10-11 09:03:51 --> No URI present. Default controller set.
INFO - 2023-10-11 09:03:51 --> Router Class Initialized
INFO - 2023-10-11 09:03:51 --> Output Class Initialized
INFO - 2023-10-11 09:03:51 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:51 --> Input Class Initialized
INFO - 2023-10-11 09:03:51 --> Language Class Initialized
INFO - 2023-10-11 09:03:51 --> Language Class Initialized
INFO - 2023-10-11 09:03:51 --> Config Class Initialized
INFO - 2023-10-11 09:03:51 --> Loader Class Initialized
INFO - 2023-10-11 09:03:51 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:51 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:51 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:51 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:51 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:51 --> Controller Class Initialized
INFO - 2023-10-11 09:03:51 --> Config Class Initialized
INFO - 2023-10-11 09:03:51 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:51 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:51 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:51 --> URI Class Initialized
INFO - 2023-10-11 09:03:51 --> Router Class Initialized
INFO - 2023-10-11 09:03:51 --> Output Class Initialized
INFO - 2023-10-11 09:03:51 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:51 --> Input Class Initialized
INFO - 2023-10-11 09:03:51 --> Language Class Initialized
INFO - 2023-10-11 09:03:51 --> Language Class Initialized
INFO - 2023-10-11 09:03:51 --> Config Class Initialized
INFO - 2023-10-11 09:03:51 --> Loader Class Initialized
INFO - 2023-10-11 09:03:51 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:51 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:51 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:51 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:51 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:51 --> Controller Class Initialized
DEBUG - 2023-10-11 09:03:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-11 09:03:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-11 09:03:51 --> Final output sent to browser
DEBUG - 2023-10-11 09:03:51 --> Total execution time: 0.0423
INFO - 2023-10-11 09:03:54 --> Config Class Initialized
INFO - 2023-10-11 09:03:54 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:54 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:54 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:54 --> URI Class Initialized
INFO - 2023-10-11 09:03:54 --> Router Class Initialized
INFO - 2023-10-11 09:03:54 --> Output Class Initialized
INFO - 2023-10-11 09:03:54 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:54 --> Input Class Initialized
INFO - 2023-10-11 09:03:54 --> Language Class Initialized
INFO - 2023-10-11 09:03:54 --> Language Class Initialized
INFO - 2023-10-11 09:03:54 --> Config Class Initialized
INFO - 2023-10-11 09:03:54 --> Loader Class Initialized
INFO - 2023-10-11 09:03:54 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:54 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:54 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:54 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:54 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:54 --> Controller Class Initialized
INFO - 2023-10-11 09:03:54 --> Helper loaded: cookie_helper
INFO - 2023-10-11 09:03:54 --> Final output sent to browser
DEBUG - 2023-10-11 09:03:54 --> Total execution time: 0.1212
INFO - 2023-10-11 09:03:54 --> Config Class Initialized
INFO - 2023-10-11 09:03:54 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:54 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:54 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:54 --> URI Class Initialized
INFO - 2023-10-11 09:03:54 --> Router Class Initialized
INFO - 2023-10-11 09:03:54 --> Output Class Initialized
INFO - 2023-10-11 09:03:54 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:54 --> Input Class Initialized
INFO - 2023-10-11 09:03:54 --> Language Class Initialized
INFO - 2023-10-11 09:03:54 --> Language Class Initialized
INFO - 2023-10-11 09:03:54 --> Config Class Initialized
INFO - 2023-10-11 09:03:54 --> Loader Class Initialized
INFO - 2023-10-11 09:03:54 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:54 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:54 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:54 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:54 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:54 --> Controller Class Initialized
DEBUG - 2023-10-11 09:03:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-11 09:03:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-11 09:03:54 --> Final output sent to browser
DEBUG - 2023-10-11 09:03:54 --> Total execution time: 0.0584
INFO - 2023-10-11 09:03:56 --> Config Class Initialized
INFO - 2023-10-11 09:03:56 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:56 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:56 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:56 --> URI Class Initialized
INFO - 2023-10-11 09:03:56 --> Router Class Initialized
INFO - 2023-10-11 09:03:56 --> Output Class Initialized
INFO - 2023-10-11 09:03:56 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:56 --> Input Class Initialized
INFO - 2023-10-11 09:03:56 --> Language Class Initialized
INFO - 2023-10-11 09:03:56 --> Language Class Initialized
INFO - 2023-10-11 09:03:56 --> Config Class Initialized
INFO - 2023-10-11 09:03:56 --> Loader Class Initialized
INFO - 2023-10-11 09:03:56 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:56 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:56 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:56 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:56 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:56 --> Controller Class Initialized
DEBUG - 2023-10-11 09:03:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-11 09:03:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-11 09:03:56 --> Final output sent to browser
DEBUG - 2023-10-11 09:03:56 --> Total execution time: 0.0329
INFO - 2023-10-11 09:03:58 --> Config Class Initialized
INFO - 2023-10-11 09:03:58 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:58 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:58 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:58 --> URI Class Initialized
INFO - 2023-10-11 09:03:58 --> Router Class Initialized
INFO - 2023-10-11 09:03:58 --> Output Class Initialized
INFO - 2023-10-11 09:03:58 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:58 --> Input Class Initialized
INFO - 2023-10-11 09:03:58 --> Language Class Initialized
INFO - 2023-10-11 09:03:58 --> Language Class Initialized
INFO - 2023-10-11 09:03:58 --> Config Class Initialized
INFO - 2023-10-11 09:03:58 --> Loader Class Initialized
INFO - 2023-10-11 09:03:58 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:58 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:58 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:58 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:58 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:58 --> Controller Class Initialized
DEBUG - 2023-10-11 09:03:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-11 09:03:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-11 09:03:58 --> Final output sent to browser
DEBUG - 2023-10-11 09:03:58 --> Total execution time: 0.0455
INFO - 2023-10-11 09:03:58 --> Config Class Initialized
INFO - 2023-10-11 09:03:58 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:58 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:58 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:58 --> URI Class Initialized
INFO - 2023-10-11 09:03:58 --> Router Class Initialized
INFO - 2023-10-11 09:03:58 --> Output Class Initialized
INFO - 2023-10-11 09:03:58 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:58 --> Input Class Initialized
INFO - 2023-10-11 09:03:58 --> Language Class Initialized
INFO - 2023-10-11 09:03:58 --> Language Class Initialized
INFO - 2023-10-11 09:03:58 --> Config Class Initialized
INFO - 2023-10-11 09:03:58 --> Loader Class Initialized
INFO - 2023-10-11 09:03:58 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:58 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:58 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:58 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:58 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:58 --> Controller Class Initialized
INFO - 2023-10-11 09:03:59 --> Config Class Initialized
INFO - 2023-10-11 09:03:59 --> Hooks Class Initialized
DEBUG - 2023-10-11 09:03:59 --> UTF-8 Support Enabled
INFO - 2023-10-11 09:03:59 --> Utf8 Class Initialized
INFO - 2023-10-11 09:03:59 --> URI Class Initialized
INFO - 2023-10-11 09:03:59 --> Router Class Initialized
INFO - 2023-10-11 09:03:59 --> Output Class Initialized
INFO - 2023-10-11 09:03:59 --> Security Class Initialized
DEBUG - 2023-10-11 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 09:03:59 --> Input Class Initialized
INFO - 2023-10-11 09:03:59 --> Language Class Initialized
INFO - 2023-10-11 09:03:59 --> Language Class Initialized
INFO - 2023-10-11 09:03:59 --> Config Class Initialized
INFO - 2023-10-11 09:03:59 --> Loader Class Initialized
INFO - 2023-10-11 09:03:59 --> Helper loaded: url_helper
INFO - 2023-10-11 09:03:59 --> Helper loaded: file_helper
INFO - 2023-10-11 09:03:59 --> Helper loaded: form_helper
INFO - 2023-10-11 09:03:59 --> Helper loaded: my_helper
INFO - 2023-10-11 09:03:59 --> Database Driver Class Initialized
INFO - 2023-10-11 09:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 09:03:59 --> Controller Class Initialized
INFO - 2023-10-11 09:03:59 --> Final output sent to browser
DEBUG - 2023-10-11 09:03:59 --> Total execution time: 0.0326
