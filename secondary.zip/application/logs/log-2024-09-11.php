<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-11 09:24:14 --> Config Class Initialized
INFO - 2024-09-11 09:24:14 --> Hooks Class Initialized
DEBUG - 2024-09-11 09:24:14 --> UTF-8 Support Enabled
INFO - 2024-09-11 09:24:14 --> Utf8 Class Initialized
INFO - 2024-09-11 09:24:14 --> URI Class Initialized
INFO - 2024-09-11 09:24:14 --> Router Class Initialized
INFO - 2024-09-11 09:24:14 --> Output Class Initialized
INFO - 2024-09-11 09:24:14 --> Security Class Initialized
DEBUG - 2024-09-11 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 09:24:14 --> Input Class Initialized
INFO - 2024-09-11 09:24:14 --> Language Class Initialized
INFO - 2024-09-11 09:24:14 --> Language Class Initialized
INFO - 2024-09-11 09:24:14 --> Config Class Initialized
INFO - 2024-09-11 09:24:14 --> Loader Class Initialized
INFO - 2024-09-11 09:24:14 --> Helper loaded: url_helper
INFO - 2024-09-11 09:24:14 --> Helper loaded: file_helper
INFO - 2024-09-11 09:24:14 --> Helper loaded: form_helper
INFO - 2024-09-11 09:24:14 --> Helper loaded: my_helper
INFO - 2024-09-11 09:24:14 --> Database Driver Class Initialized
INFO - 2024-09-11 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 09:24:14 --> Controller Class Initialized
INFO - 2024-09-11 09:24:14 --> Helper loaded: cookie_helper
INFO - 2024-09-11 09:24:14 --> Final output sent to browser
DEBUG - 2024-09-11 09:24:14 --> Total execution time: 0.1056
INFO - 2024-09-11 09:24:15 --> Config Class Initialized
INFO - 2024-09-11 09:24:15 --> Hooks Class Initialized
DEBUG - 2024-09-11 09:24:15 --> UTF-8 Support Enabled
INFO - 2024-09-11 09:24:15 --> Utf8 Class Initialized
INFO - 2024-09-11 09:24:15 --> URI Class Initialized
INFO - 2024-09-11 09:24:15 --> Router Class Initialized
INFO - 2024-09-11 09:24:15 --> Output Class Initialized
INFO - 2024-09-11 09:24:15 --> Security Class Initialized
DEBUG - 2024-09-11 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 09:24:15 --> Input Class Initialized
INFO - 2024-09-11 09:24:15 --> Language Class Initialized
INFO - 2024-09-11 09:24:15 --> Language Class Initialized
INFO - 2024-09-11 09:24:15 --> Config Class Initialized
INFO - 2024-09-11 09:24:15 --> Loader Class Initialized
INFO - 2024-09-11 09:24:15 --> Helper loaded: url_helper
INFO - 2024-09-11 09:24:15 --> Helper loaded: file_helper
INFO - 2024-09-11 09:24:15 --> Helper loaded: form_helper
INFO - 2024-09-11 09:24:15 --> Helper loaded: my_helper
INFO - 2024-09-11 09:24:15 --> Database Driver Class Initialized
INFO - 2024-09-11 09:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 09:24:15 --> Controller Class Initialized
INFO - 2024-09-11 09:24:15 --> Helper loaded: cookie_helper
INFO - 2024-09-11 09:24:15 --> Config Class Initialized
INFO - 2024-09-11 09:24:15 --> Hooks Class Initialized
DEBUG - 2024-09-11 09:24:15 --> UTF-8 Support Enabled
INFO - 2024-09-11 09:24:15 --> Utf8 Class Initialized
INFO - 2024-09-11 09:24:15 --> URI Class Initialized
INFO - 2024-09-11 09:24:15 --> Router Class Initialized
INFO - 2024-09-11 09:24:15 --> Output Class Initialized
INFO - 2024-09-11 09:24:15 --> Security Class Initialized
DEBUG - 2024-09-11 09:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 09:24:15 --> Input Class Initialized
INFO - 2024-09-11 09:24:15 --> Language Class Initialized
INFO - 2024-09-11 09:24:15 --> Language Class Initialized
INFO - 2024-09-11 09:24:15 --> Config Class Initialized
INFO - 2024-09-11 09:24:15 --> Loader Class Initialized
INFO - 2024-09-11 09:24:15 --> Helper loaded: url_helper
INFO - 2024-09-11 09:24:15 --> Helper loaded: file_helper
INFO - 2024-09-11 09:24:15 --> Helper loaded: form_helper
INFO - 2024-09-11 09:24:15 --> Helper loaded: my_helper
INFO - 2024-09-11 09:24:15 --> Database Driver Class Initialized
INFO - 2024-09-11 09:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 09:24:15 --> Controller Class Initialized
DEBUG - 2024-09-11 09:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-11 09:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-11 09:24:15 --> Final output sent to browser
DEBUG - 2024-09-11 09:24:15 --> Total execution time: 0.0405
INFO - 2024-09-11 09:24:24 --> Config Class Initialized
INFO - 2024-09-11 09:24:24 --> Hooks Class Initialized
DEBUG - 2024-09-11 09:24:24 --> UTF-8 Support Enabled
INFO - 2024-09-11 09:24:24 --> Utf8 Class Initialized
INFO - 2024-09-11 09:24:24 --> URI Class Initialized
INFO - 2024-09-11 09:24:24 --> Router Class Initialized
INFO - 2024-09-11 09:24:24 --> Output Class Initialized
INFO - 2024-09-11 09:24:24 --> Security Class Initialized
DEBUG - 2024-09-11 09:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 09:24:24 --> Input Class Initialized
INFO - 2024-09-11 09:24:24 --> Language Class Initialized
INFO - 2024-09-11 09:24:24 --> Language Class Initialized
INFO - 2024-09-11 09:24:24 --> Config Class Initialized
INFO - 2024-09-11 09:24:24 --> Loader Class Initialized
INFO - 2024-09-11 09:24:24 --> Helper loaded: url_helper
INFO - 2024-09-11 09:24:24 --> Helper loaded: file_helper
INFO - 2024-09-11 09:24:24 --> Helper loaded: form_helper
INFO - 2024-09-11 09:24:24 --> Helper loaded: my_helper
INFO - 2024-09-11 09:24:24 --> Database Driver Class Initialized
INFO - 2024-09-11 09:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 09:24:24 --> Controller Class Initialized
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-11 09:24:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-11 09:24:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-11 09:24:27 --> Final output sent to browser
DEBUG - 2024-09-11 09:24:27 --> Total execution time: 3.1150
INFO - 2024-09-11 20:53:14 --> Config Class Initialized
INFO - 2024-09-11 20:53:14 --> Hooks Class Initialized
DEBUG - 2024-09-11 20:53:14 --> UTF-8 Support Enabled
INFO - 2024-09-11 20:53:14 --> Utf8 Class Initialized
INFO - 2024-09-11 20:53:14 --> URI Class Initialized
INFO - 2024-09-11 20:53:14 --> Router Class Initialized
INFO - 2024-09-11 20:53:14 --> Output Class Initialized
INFO - 2024-09-11 20:53:14 --> Security Class Initialized
DEBUG - 2024-09-11 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 20:53:14 --> Input Class Initialized
INFO - 2024-09-11 20:53:14 --> Language Class Initialized
INFO - 2024-09-11 20:53:14 --> Language Class Initialized
INFO - 2024-09-11 20:53:14 --> Config Class Initialized
INFO - 2024-09-11 20:53:14 --> Loader Class Initialized
INFO - 2024-09-11 20:53:14 --> Helper loaded: url_helper
INFO - 2024-09-11 20:53:14 --> Helper loaded: file_helper
INFO - 2024-09-11 20:53:14 --> Helper loaded: form_helper
INFO - 2024-09-11 20:53:14 --> Helper loaded: my_helper
INFO - 2024-09-11 20:53:14 --> Database Driver Class Initialized
INFO - 2024-09-11 20:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 20:53:14 --> Controller Class Initialized
INFO - 2024-09-11 20:53:15 --> Config Class Initialized
INFO - 2024-09-11 20:53:15 --> Hooks Class Initialized
DEBUG - 2024-09-11 20:53:15 --> UTF-8 Support Enabled
INFO - 2024-09-11 20:53:15 --> Utf8 Class Initialized
INFO - 2024-09-11 20:53:15 --> URI Class Initialized
INFO - 2024-09-11 20:53:15 --> Router Class Initialized
INFO - 2024-09-11 20:53:15 --> Output Class Initialized
INFO - 2024-09-11 20:53:15 --> Security Class Initialized
DEBUG - 2024-09-11 20:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 20:53:15 --> Input Class Initialized
INFO - 2024-09-11 20:53:15 --> Language Class Initialized
INFO - 2024-09-11 20:53:15 --> Language Class Initialized
INFO - 2024-09-11 20:53:15 --> Config Class Initialized
INFO - 2024-09-11 20:53:15 --> Loader Class Initialized
INFO - 2024-09-11 20:53:15 --> Helper loaded: url_helper
INFO - 2024-09-11 20:53:15 --> Helper loaded: file_helper
INFO - 2024-09-11 20:53:15 --> Helper loaded: form_helper
INFO - 2024-09-11 20:53:15 --> Helper loaded: my_helper
INFO - 2024-09-11 20:53:15 --> Database Driver Class Initialized
INFO - 2024-09-11 20:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 20:53:15 --> Controller Class Initialized
DEBUG - 2024-09-11 20:53:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-11 20:53:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-11 20:53:15 --> Final output sent to browser
DEBUG - 2024-09-11 20:53:15 --> Total execution time: 0.0367
