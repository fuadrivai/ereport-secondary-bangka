<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-29 01:21:19 --> Config Class Initialized
INFO - 2024-09-29 01:21:19 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:21:19 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:21:19 --> Utf8 Class Initialized
INFO - 2024-09-29 01:21:19 --> URI Class Initialized
INFO - 2024-09-29 01:21:19 --> Router Class Initialized
INFO - 2024-09-29 01:21:19 --> Output Class Initialized
INFO - 2024-09-29 01:21:19 --> Security Class Initialized
DEBUG - 2024-09-29 01:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:21:19 --> Input Class Initialized
INFO - 2024-09-29 01:21:19 --> Language Class Initialized
INFO - 2024-09-29 01:21:19 --> Language Class Initialized
INFO - 2024-09-29 01:21:19 --> Config Class Initialized
INFO - 2024-09-29 01:21:19 --> Loader Class Initialized
INFO - 2024-09-29 01:21:19 --> Helper loaded: url_helper
INFO - 2024-09-29 01:21:19 --> Helper loaded: file_helper
INFO - 2024-09-29 01:21:19 --> Helper loaded: form_helper
INFO - 2024-09-29 01:21:19 --> Helper loaded: my_helper
INFO - 2024-09-29 01:21:19 --> Database Driver Class Initialized
INFO - 2024-09-29 01:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:21:19 --> Controller Class Initialized
INFO - 2024-09-29 01:21:19 --> Helper loaded: cookie_helper
INFO - 2024-09-29 01:21:19 --> Final output sent to browser
DEBUG - 2024-09-29 01:21:19 --> Total execution time: 0.0883
INFO - 2024-09-29 01:21:20 --> Config Class Initialized
INFO - 2024-09-29 01:21:20 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:21:20 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:21:20 --> Utf8 Class Initialized
INFO - 2024-09-29 01:21:20 --> URI Class Initialized
INFO - 2024-09-29 01:21:20 --> Router Class Initialized
INFO - 2024-09-29 01:21:20 --> Output Class Initialized
INFO - 2024-09-29 01:21:20 --> Security Class Initialized
DEBUG - 2024-09-29 01:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:21:20 --> Input Class Initialized
INFO - 2024-09-29 01:21:20 --> Language Class Initialized
INFO - 2024-09-29 01:21:20 --> Language Class Initialized
INFO - 2024-09-29 01:21:20 --> Config Class Initialized
INFO - 2024-09-29 01:21:20 --> Loader Class Initialized
INFO - 2024-09-29 01:21:20 --> Helper loaded: url_helper
INFO - 2024-09-29 01:21:20 --> Helper loaded: file_helper
INFO - 2024-09-29 01:21:20 --> Helper loaded: form_helper
INFO - 2024-09-29 01:21:20 --> Helper loaded: my_helper
INFO - 2024-09-29 01:21:20 --> Database Driver Class Initialized
INFO - 2024-09-29 01:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:21:20 --> Controller Class Initialized
INFO - 2024-09-29 01:21:20 --> Helper loaded: cookie_helper
INFO - 2024-09-29 01:21:20 --> Config Class Initialized
INFO - 2024-09-29 01:21:20 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:21:20 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:21:20 --> Utf8 Class Initialized
INFO - 2024-09-29 01:21:20 --> URI Class Initialized
INFO - 2024-09-29 01:21:20 --> Router Class Initialized
INFO - 2024-09-29 01:21:20 --> Output Class Initialized
INFO - 2024-09-29 01:21:20 --> Security Class Initialized
DEBUG - 2024-09-29 01:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:21:20 --> Input Class Initialized
INFO - 2024-09-29 01:21:20 --> Language Class Initialized
INFO - 2024-09-29 01:21:20 --> Language Class Initialized
INFO - 2024-09-29 01:21:20 --> Config Class Initialized
INFO - 2024-09-29 01:21:20 --> Loader Class Initialized
INFO - 2024-09-29 01:21:20 --> Helper loaded: url_helper
INFO - 2024-09-29 01:21:20 --> Helper loaded: file_helper
INFO - 2024-09-29 01:21:20 --> Helper loaded: form_helper
INFO - 2024-09-29 01:21:20 --> Helper loaded: my_helper
INFO - 2024-09-29 01:21:20 --> Database Driver Class Initialized
INFO - 2024-09-29 01:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:21:20 --> Controller Class Initialized
DEBUG - 2024-09-29 01:21:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-29 01:21:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-29 01:21:20 --> Final output sent to browser
DEBUG - 2024-09-29 01:21:20 --> Total execution time: 0.0408
INFO - 2024-09-29 01:21:44 --> Config Class Initialized
INFO - 2024-09-29 01:21:44 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:21:44 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:21:44 --> Utf8 Class Initialized
INFO - 2024-09-29 01:21:44 --> URI Class Initialized
INFO - 2024-09-29 01:21:44 --> Router Class Initialized
INFO - 2024-09-29 01:21:44 --> Output Class Initialized
INFO - 2024-09-29 01:21:44 --> Security Class Initialized
DEBUG - 2024-09-29 01:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:21:44 --> Input Class Initialized
INFO - 2024-09-29 01:21:44 --> Language Class Initialized
INFO - 2024-09-29 01:21:44 --> Language Class Initialized
INFO - 2024-09-29 01:21:44 --> Config Class Initialized
INFO - 2024-09-29 01:21:44 --> Loader Class Initialized
INFO - 2024-09-29 01:21:44 --> Helper loaded: url_helper
INFO - 2024-09-29 01:21:44 --> Helper loaded: file_helper
INFO - 2024-09-29 01:21:44 --> Helper loaded: form_helper
INFO - 2024-09-29 01:21:44 --> Helper loaded: my_helper
INFO - 2024-09-29 01:21:44 --> Database Driver Class Initialized
INFO - 2024-09-29 01:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:21:44 --> Controller Class Initialized
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-29 01:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-29 01:21:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-29 01:21:47 --> Final output sent to browser
DEBUG - 2024-09-29 01:21:47 --> Total execution time: 2.7679
INFO - 2024-09-29 01:22:21 --> Config Class Initialized
INFO - 2024-09-29 01:22:21 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:22:21 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:22:21 --> Utf8 Class Initialized
INFO - 2024-09-29 01:22:21 --> URI Class Initialized
INFO - 2024-09-29 01:22:21 --> Router Class Initialized
INFO - 2024-09-29 01:22:21 --> Output Class Initialized
INFO - 2024-09-29 01:22:21 --> Security Class Initialized
DEBUG - 2024-09-29 01:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:22:21 --> Input Class Initialized
INFO - 2024-09-29 01:22:21 --> Language Class Initialized
INFO - 2024-09-29 01:22:21 --> Language Class Initialized
INFO - 2024-09-29 01:22:21 --> Config Class Initialized
INFO - 2024-09-29 01:22:21 --> Loader Class Initialized
INFO - 2024-09-29 01:22:21 --> Helper loaded: url_helper
INFO - 2024-09-29 01:22:21 --> Helper loaded: file_helper
INFO - 2024-09-29 01:22:21 --> Helper loaded: form_helper
INFO - 2024-09-29 01:22:21 --> Helper loaded: my_helper
INFO - 2024-09-29 01:22:21 --> Database Driver Class Initialized
INFO - 2024-09-29 01:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:22:21 --> Controller Class Initialized
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-29 01:22:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-29 01:22:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-29 01:22:24 --> Final output sent to browser
DEBUG - 2024-09-29 01:22:24 --> Total execution time: 2.4144
INFO - 2024-09-29 01:22:42 --> Config Class Initialized
INFO - 2024-09-29 01:22:42 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:22:42 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:22:42 --> Utf8 Class Initialized
INFO - 2024-09-29 01:22:42 --> URI Class Initialized
INFO - 2024-09-29 01:22:42 --> Router Class Initialized
INFO - 2024-09-29 01:22:42 --> Output Class Initialized
INFO - 2024-09-29 01:22:42 --> Security Class Initialized
DEBUG - 2024-09-29 01:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:22:42 --> Input Class Initialized
INFO - 2024-09-29 01:22:42 --> Language Class Initialized
INFO - 2024-09-29 01:22:42 --> Language Class Initialized
INFO - 2024-09-29 01:22:42 --> Config Class Initialized
INFO - 2024-09-29 01:22:42 --> Loader Class Initialized
INFO - 2024-09-29 01:22:42 --> Helper loaded: url_helper
INFO - 2024-09-29 01:22:42 --> Helper loaded: file_helper
INFO - 2024-09-29 01:22:42 --> Helper loaded: form_helper
INFO - 2024-09-29 01:22:42 --> Helper loaded: my_helper
INFO - 2024-09-29 01:22:42 --> Database Driver Class Initialized
INFO - 2024-09-29 01:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:22:42 --> Controller Class Initialized
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-29 01:22:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-29 01:22:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-29 01:22:44 --> Final output sent to browser
DEBUG - 2024-09-29 01:22:44 --> Total execution time: 2.1963
INFO - 2024-09-29 01:23:02 --> Config Class Initialized
INFO - 2024-09-29 01:23:02 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:23:02 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:23:02 --> Utf8 Class Initialized
INFO - 2024-09-29 01:23:02 --> URI Class Initialized
INFO - 2024-09-29 01:23:02 --> Router Class Initialized
INFO - 2024-09-29 01:23:02 --> Output Class Initialized
INFO - 2024-09-29 01:23:02 --> Security Class Initialized
DEBUG - 2024-09-29 01:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:23:02 --> Input Class Initialized
INFO - 2024-09-29 01:23:02 --> Language Class Initialized
INFO - 2024-09-29 01:23:02 --> Language Class Initialized
INFO - 2024-09-29 01:23:02 --> Config Class Initialized
INFO - 2024-09-29 01:23:02 --> Loader Class Initialized
INFO - 2024-09-29 01:23:02 --> Helper loaded: url_helper
INFO - 2024-09-29 01:23:02 --> Helper loaded: file_helper
INFO - 2024-09-29 01:23:02 --> Helper loaded: form_helper
INFO - 2024-09-29 01:23:02 --> Helper loaded: my_helper
INFO - 2024-09-29 01:23:02 --> Database Driver Class Initialized
INFO - 2024-09-29 01:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:23:02 --> Controller Class Initialized
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-29 01:23:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-29 01:23:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-29 01:23:05 --> Final output sent to browser
DEBUG - 2024-09-29 01:23:05 --> Total execution time: 2.5665
INFO - 2024-09-29 01:23:41 --> Config Class Initialized
INFO - 2024-09-29 01:23:41 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:23:41 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:23:41 --> Utf8 Class Initialized
INFO - 2024-09-29 01:23:41 --> URI Class Initialized
DEBUG - 2024-09-29 01:23:41 --> No URI present. Default controller set.
INFO - 2024-09-29 01:23:41 --> Router Class Initialized
INFO - 2024-09-29 01:23:41 --> Output Class Initialized
INFO - 2024-09-29 01:23:41 --> Security Class Initialized
DEBUG - 2024-09-29 01:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:23:41 --> Input Class Initialized
INFO - 2024-09-29 01:23:41 --> Language Class Initialized
INFO - 2024-09-29 01:23:41 --> Language Class Initialized
INFO - 2024-09-29 01:23:41 --> Config Class Initialized
INFO - 2024-09-29 01:23:41 --> Loader Class Initialized
INFO - 2024-09-29 01:23:41 --> Helper loaded: url_helper
INFO - 2024-09-29 01:23:41 --> Helper loaded: file_helper
INFO - 2024-09-29 01:23:41 --> Helper loaded: form_helper
INFO - 2024-09-29 01:23:41 --> Helper loaded: my_helper
INFO - 2024-09-29 01:23:41 --> Database Driver Class Initialized
INFO - 2024-09-29 01:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:23:41 --> Controller Class Initialized
DEBUG - 2024-09-29 01:23:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-09-29 01:23:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-29 01:23:41 --> Final output sent to browser
DEBUG - 2024-09-29 01:23:41 --> Total execution time: 0.0288
INFO - 2024-09-29 01:23:54 --> Config Class Initialized
INFO - 2024-09-29 01:23:54 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:23:54 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:23:54 --> Utf8 Class Initialized
INFO - 2024-09-29 01:23:54 --> URI Class Initialized
INFO - 2024-09-29 01:23:54 --> Router Class Initialized
INFO - 2024-09-29 01:23:54 --> Output Class Initialized
INFO - 2024-09-29 01:23:54 --> Security Class Initialized
DEBUG - 2024-09-29 01:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:23:54 --> Input Class Initialized
INFO - 2024-09-29 01:23:54 --> Language Class Initialized
INFO - 2024-09-29 01:23:54 --> Language Class Initialized
INFO - 2024-09-29 01:23:54 --> Config Class Initialized
INFO - 2024-09-29 01:23:54 --> Loader Class Initialized
INFO - 2024-09-29 01:23:54 --> Helper loaded: url_helper
INFO - 2024-09-29 01:23:54 --> Helper loaded: file_helper
INFO - 2024-09-29 01:23:54 --> Helper loaded: form_helper
INFO - 2024-09-29 01:23:54 --> Helper loaded: my_helper
INFO - 2024-09-29 01:23:54 --> Database Driver Class Initialized
INFO - 2024-09-29 01:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:23:54 --> Controller Class Initialized
DEBUG - 2024-09-29 01:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-29 01:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-29 01:23:54 --> Final output sent to browser
DEBUG - 2024-09-29 01:23:54 --> Total execution time: 0.0375
INFO - 2024-09-29 01:23:58 --> Config Class Initialized
INFO - 2024-09-29 01:23:58 --> Hooks Class Initialized
DEBUG - 2024-09-29 01:23:58 --> UTF-8 Support Enabled
INFO - 2024-09-29 01:23:58 --> Utf8 Class Initialized
INFO - 2024-09-29 01:23:58 --> URI Class Initialized
INFO - 2024-09-29 01:23:58 --> Router Class Initialized
INFO - 2024-09-29 01:23:58 --> Output Class Initialized
INFO - 2024-09-29 01:23:58 --> Security Class Initialized
DEBUG - 2024-09-29 01:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 01:23:58 --> Input Class Initialized
INFO - 2024-09-29 01:23:58 --> Language Class Initialized
INFO - 2024-09-29 01:23:58 --> Language Class Initialized
INFO - 2024-09-29 01:23:58 --> Config Class Initialized
INFO - 2024-09-29 01:23:58 --> Loader Class Initialized
INFO - 2024-09-29 01:23:58 --> Helper loaded: url_helper
INFO - 2024-09-29 01:23:58 --> Helper loaded: file_helper
INFO - 2024-09-29 01:23:58 --> Helper loaded: form_helper
INFO - 2024-09-29 01:23:58 --> Helper loaded: my_helper
INFO - 2024-09-29 01:23:58 --> Database Driver Class Initialized
INFO - 2024-09-29 01:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-29 01:23:58 --> Controller Class Initialized
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2957
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-09-29 01:23:58 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-09-29 01:23:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
