<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-19 04:28:40 --> Config Class Initialized
INFO - 2024-11-19 04:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:28:40 --> Utf8 Class Initialized
INFO - 2024-11-19 04:28:40 --> URI Class Initialized
INFO - 2024-11-19 04:28:40 --> Router Class Initialized
INFO - 2024-11-19 04:28:40 --> Output Class Initialized
INFO - 2024-11-19 04:28:40 --> Security Class Initialized
DEBUG - 2024-11-19 04:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:28:40 --> Input Class Initialized
INFO - 2024-11-19 04:28:40 --> Language Class Initialized
INFO - 2024-11-19 04:28:40 --> Language Class Initialized
INFO - 2024-11-19 04:28:40 --> Config Class Initialized
INFO - 2024-11-19 04:28:40 --> Loader Class Initialized
INFO - 2024-11-19 04:28:40 --> Helper loaded: url_helper
INFO - 2024-11-19 04:28:40 --> Helper loaded: file_helper
INFO - 2024-11-19 04:28:40 --> Helper loaded: form_helper
INFO - 2024-11-19 04:28:40 --> Helper loaded: my_helper
INFO - 2024-11-19 04:28:40 --> Database Driver Class Initialized
INFO - 2024-11-19 04:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:28:40 --> Controller Class Initialized
INFO - 2024-11-19 04:28:40 --> Helper loaded: cookie_helper
INFO - 2024-11-19 04:28:40 --> Final output sent to browser
DEBUG - 2024-11-19 04:28:40 --> Total execution time: 0.0889
INFO - 2024-11-19 04:28:40 --> Config Class Initialized
INFO - 2024-11-19 04:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:28:40 --> Utf8 Class Initialized
INFO - 2024-11-19 04:28:40 --> URI Class Initialized
INFO - 2024-11-19 04:28:40 --> Router Class Initialized
INFO - 2024-11-19 04:28:40 --> Output Class Initialized
INFO - 2024-11-19 04:28:40 --> Security Class Initialized
DEBUG - 2024-11-19 04:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:28:40 --> Input Class Initialized
INFO - 2024-11-19 04:28:40 --> Language Class Initialized
INFO - 2024-11-19 04:28:40 --> Language Class Initialized
INFO - 2024-11-19 04:28:40 --> Config Class Initialized
INFO - 2024-11-19 04:28:40 --> Loader Class Initialized
INFO - 2024-11-19 04:28:40 --> Helper loaded: url_helper
INFO - 2024-11-19 04:28:40 --> Helper loaded: file_helper
INFO - 2024-11-19 04:28:40 --> Helper loaded: form_helper
INFO - 2024-11-19 04:28:40 --> Helper loaded: my_helper
INFO - 2024-11-19 04:28:40 --> Database Driver Class Initialized
INFO - 2024-11-19 04:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:28:40 --> Controller Class Initialized
INFO - 2024-11-19 04:28:40 --> Helper loaded: cookie_helper
INFO - 2024-11-19 04:28:40 --> Config Class Initialized
INFO - 2024-11-19 04:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:28:40 --> Utf8 Class Initialized
INFO - 2024-11-19 04:28:40 --> URI Class Initialized
INFO - 2024-11-19 04:28:40 --> Router Class Initialized
INFO - 2024-11-19 04:28:40 --> Output Class Initialized
INFO - 2024-11-19 04:28:40 --> Security Class Initialized
DEBUG - 2024-11-19 04:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:28:40 --> Input Class Initialized
INFO - 2024-11-19 04:28:40 --> Language Class Initialized
INFO - 2024-11-19 04:28:41 --> Language Class Initialized
INFO - 2024-11-19 04:28:41 --> Config Class Initialized
INFO - 2024-11-19 04:28:41 --> Loader Class Initialized
INFO - 2024-11-19 04:28:41 --> Helper loaded: url_helper
INFO - 2024-11-19 04:28:41 --> Helper loaded: file_helper
INFO - 2024-11-19 04:28:41 --> Helper loaded: form_helper
INFO - 2024-11-19 04:28:41 --> Helper loaded: my_helper
INFO - 2024-11-19 04:28:41 --> Database Driver Class Initialized
INFO - 2024-11-19 04:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:28:41 --> Controller Class Initialized
ERROR - 2024-11-19 04:28:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT a.id_siswa,a.id_kelas,b.tingkat,a.ta FROM t_kelas_siswa a
                                                    INNER JOIN m_kelas b ON b.id = a.id_kelas
                                                    WHERE a.id_siswa = 
INFO - 2024-11-19 04:28:41 --> Language file loaded: language/english/db_lang.php
