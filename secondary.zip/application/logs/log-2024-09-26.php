<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-26 11:28:24 --> Config Class Initialized
INFO - 2024-09-26 11:28:24 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:24 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:24 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:24 --> URI Class Initialized
INFO - 2024-09-26 11:28:24 --> Router Class Initialized
INFO - 2024-09-26 11:28:24 --> Output Class Initialized
INFO - 2024-09-26 11:28:24 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:24 --> Input Class Initialized
INFO - 2024-09-26 11:28:24 --> Language Class Initialized
INFO - 2024-09-26 11:28:24 --> Language Class Initialized
INFO - 2024-09-26 11:28:24 --> Config Class Initialized
INFO - 2024-09-26 11:28:24 --> Loader Class Initialized
INFO - 2024-09-26 11:28:24 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:24 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:24 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:24 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:24 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:24 --> Controller Class Initialized
DEBUG - 2024-09-26 11:28:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-26 11:28:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:28:24 --> Final output sent to browser
DEBUG - 2024-09-26 11:28:24 --> Total execution time: 0.0620
INFO - 2024-09-26 11:28:29 --> Config Class Initialized
INFO - 2024-09-26 11:28:29 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:29 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:29 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:29 --> URI Class Initialized
INFO - 2024-09-26 11:28:29 --> Router Class Initialized
INFO - 2024-09-26 11:28:29 --> Output Class Initialized
INFO - 2024-09-26 11:28:29 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:29 --> Input Class Initialized
INFO - 2024-09-26 11:28:29 --> Language Class Initialized
INFO - 2024-09-26 11:28:29 --> Language Class Initialized
INFO - 2024-09-26 11:28:29 --> Config Class Initialized
INFO - 2024-09-26 11:28:29 --> Loader Class Initialized
INFO - 2024-09-26 11:28:29 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:29 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:29 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:29 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:29 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:29 --> Controller Class Initialized
INFO - 2024-09-26 11:28:29 --> Helper loaded: cookie_helper
INFO - 2024-09-26 11:28:29 --> Final output sent to browser
DEBUG - 2024-09-26 11:28:29 --> Total execution time: 0.0473
INFO - 2024-09-26 11:28:29 --> Config Class Initialized
INFO - 2024-09-26 11:28:29 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:29 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:29 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:29 --> URI Class Initialized
INFO - 2024-09-26 11:28:29 --> Router Class Initialized
INFO - 2024-09-26 11:28:29 --> Output Class Initialized
INFO - 2024-09-26 11:28:29 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:29 --> Input Class Initialized
INFO - 2024-09-26 11:28:29 --> Language Class Initialized
INFO - 2024-09-26 11:28:29 --> Language Class Initialized
INFO - 2024-09-26 11:28:29 --> Config Class Initialized
INFO - 2024-09-26 11:28:29 --> Loader Class Initialized
INFO - 2024-09-26 11:28:29 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:29 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:29 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:29 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:29 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:29 --> Controller Class Initialized
DEBUG - 2024-09-26 11:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-26 11:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:28:29 --> Final output sent to browser
DEBUG - 2024-09-26 11:28:29 --> Total execution time: 0.0500
INFO - 2024-09-26 11:28:32 --> Config Class Initialized
INFO - 2024-09-26 11:28:32 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:32 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:32 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:32 --> URI Class Initialized
INFO - 2024-09-26 11:28:32 --> Router Class Initialized
INFO - 2024-09-26 11:28:32 --> Output Class Initialized
INFO - 2024-09-26 11:28:32 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:32 --> Input Class Initialized
INFO - 2024-09-26 11:28:32 --> Language Class Initialized
INFO - 2024-09-26 11:28:32 --> Language Class Initialized
INFO - 2024-09-26 11:28:32 --> Config Class Initialized
INFO - 2024-09-26 11:28:32 --> Loader Class Initialized
INFO - 2024-09-26 11:28:32 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:32 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:32 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:32 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:32 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:32 --> Controller Class Initialized
DEBUG - 2024-09-26 11:28:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-26 11:28:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:28:32 --> Final output sent to browser
DEBUG - 2024-09-26 11:28:32 --> Total execution time: 0.0324
INFO - 2024-09-26 11:28:34 --> Config Class Initialized
INFO - 2024-09-26 11:28:34 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:34 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:34 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:34 --> URI Class Initialized
INFO - 2024-09-26 11:28:34 --> Router Class Initialized
INFO - 2024-09-26 11:28:34 --> Output Class Initialized
INFO - 2024-09-26 11:28:34 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:34 --> Input Class Initialized
INFO - 2024-09-26 11:28:34 --> Language Class Initialized
INFO - 2024-09-26 11:28:34 --> Language Class Initialized
INFO - 2024-09-26 11:28:34 --> Config Class Initialized
INFO - 2024-09-26 11:28:34 --> Loader Class Initialized
INFO - 2024-09-26 11:28:34 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:34 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:34 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:34 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:34 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:34 --> Controller Class Initialized
DEBUG - 2024-09-26 11:28:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-26 11:28:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:28:34 --> Final output sent to browser
DEBUG - 2024-09-26 11:28:34 --> Total execution time: 0.0442
INFO - 2024-09-26 11:28:34 --> Config Class Initialized
INFO - 2024-09-26 11:28:34 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:34 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:34 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:34 --> URI Class Initialized
INFO - 2024-09-26 11:28:34 --> Router Class Initialized
INFO - 2024-09-26 11:28:34 --> Output Class Initialized
INFO - 2024-09-26 11:28:34 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:34 --> Input Class Initialized
INFO - 2024-09-26 11:28:34 --> Language Class Initialized
INFO - 2024-09-26 11:28:34 --> Language Class Initialized
INFO - 2024-09-26 11:28:34 --> Config Class Initialized
INFO - 2024-09-26 11:28:34 --> Loader Class Initialized
INFO - 2024-09-26 11:28:34 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:34 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:34 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:34 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:34 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:34 --> Controller Class Initialized
INFO - 2024-09-26 11:28:38 --> Config Class Initialized
INFO - 2024-09-26 11:28:38 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:28:38 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:28:38 --> Utf8 Class Initialized
INFO - 2024-09-26 11:28:38 --> URI Class Initialized
INFO - 2024-09-26 11:28:38 --> Router Class Initialized
INFO - 2024-09-26 11:28:38 --> Output Class Initialized
INFO - 2024-09-26 11:28:38 --> Security Class Initialized
DEBUG - 2024-09-26 11:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:28:38 --> Input Class Initialized
INFO - 2024-09-26 11:28:38 --> Language Class Initialized
INFO - 2024-09-26 11:28:38 --> Language Class Initialized
INFO - 2024-09-26 11:28:38 --> Config Class Initialized
INFO - 2024-09-26 11:28:38 --> Loader Class Initialized
INFO - 2024-09-26 11:28:38 --> Helper loaded: url_helper
INFO - 2024-09-26 11:28:38 --> Helper loaded: file_helper
INFO - 2024-09-26 11:28:38 --> Helper loaded: form_helper
INFO - 2024-09-26 11:28:38 --> Helper loaded: my_helper
INFO - 2024-09-26 11:28:38 --> Database Driver Class Initialized
INFO - 2024-09-26 11:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:28:38 --> Controller Class Initialized
INFO - 2024-09-26 11:28:38 --> Final output sent to browser
DEBUG - 2024-09-26 11:28:38 --> Total execution time: 0.0382
INFO - 2024-09-26 11:32:25 --> Config Class Initialized
INFO - 2024-09-26 11:32:25 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:32:25 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:32:25 --> Utf8 Class Initialized
INFO - 2024-09-26 11:32:25 --> URI Class Initialized
INFO - 2024-09-26 11:32:25 --> Router Class Initialized
INFO - 2024-09-26 11:32:25 --> Output Class Initialized
INFO - 2024-09-26 11:32:25 --> Security Class Initialized
DEBUG - 2024-09-26 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:32:25 --> Input Class Initialized
INFO - 2024-09-26 11:32:25 --> Language Class Initialized
INFO - 2024-09-26 11:32:25 --> Language Class Initialized
INFO - 2024-09-26 11:32:25 --> Config Class Initialized
INFO - 2024-09-26 11:32:25 --> Loader Class Initialized
INFO - 2024-09-26 11:32:25 --> Helper loaded: url_helper
INFO - 2024-09-26 11:32:25 --> Helper loaded: file_helper
INFO - 2024-09-26 11:32:25 --> Helper loaded: form_helper
INFO - 2024-09-26 11:32:25 --> Helper loaded: my_helper
INFO - 2024-09-26 11:32:25 --> Database Driver Class Initialized
INFO - 2024-09-26 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:32:25 --> Controller Class Initialized
INFO - 2024-09-26 11:32:25 --> Final output sent to browser
DEBUG - 2024-09-26 11:32:25 --> Total execution time: 0.2072
INFO - 2024-09-26 11:32:54 --> Config Class Initialized
INFO - 2024-09-26 11:32:54 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:32:54 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:32:54 --> Utf8 Class Initialized
INFO - 2024-09-26 11:32:54 --> URI Class Initialized
INFO - 2024-09-26 11:32:54 --> Router Class Initialized
INFO - 2024-09-26 11:32:54 --> Output Class Initialized
INFO - 2024-09-26 11:32:54 --> Security Class Initialized
DEBUG - 2024-09-26 11:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:32:54 --> Input Class Initialized
INFO - 2024-09-26 11:32:54 --> Language Class Initialized
INFO - 2024-09-26 11:32:54 --> Language Class Initialized
INFO - 2024-09-26 11:32:54 --> Config Class Initialized
INFO - 2024-09-26 11:32:54 --> Loader Class Initialized
INFO - 2024-09-26 11:32:54 --> Helper loaded: url_helper
INFO - 2024-09-26 11:32:54 --> Helper loaded: file_helper
INFO - 2024-09-26 11:32:54 --> Helper loaded: form_helper
INFO - 2024-09-26 11:32:54 --> Helper loaded: my_helper
INFO - 2024-09-26 11:32:54 --> Database Driver Class Initialized
INFO - 2024-09-26 11:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:32:54 --> Controller Class Initialized
INFO - 2024-09-26 11:32:54 --> Final output sent to browser
DEBUG - 2024-09-26 11:32:54 --> Total execution time: 0.1519
INFO - 2024-09-26 11:32:57 --> Config Class Initialized
INFO - 2024-09-26 11:32:57 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:32:57 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:32:57 --> Utf8 Class Initialized
INFO - 2024-09-26 11:32:57 --> URI Class Initialized
INFO - 2024-09-26 11:32:57 --> Router Class Initialized
INFO - 2024-09-26 11:32:57 --> Output Class Initialized
INFO - 2024-09-26 11:32:57 --> Security Class Initialized
DEBUG - 2024-09-26 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:32:57 --> Input Class Initialized
INFO - 2024-09-26 11:32:57 --> Language Class Initialized
INFO - 2024-09-26 11:32:57 --> Language Class Initialized
INFO - 2024-09-26 11:32:57 --> Config Class Initialized
INFO - 2024-09-26 11:32:57 --> Loader Class Initialized
INFO - 2024-09-26 11:32:57 --> Helper loaded: url_helper
INFO - 2024-09-26 11:32:57 --> Helper loaded: file_helper
INFO - 2024-09-26 11:32:57 --> Helper loaded: form_helper
INFO - 2024-09-26 11:32:57 --> Helper loaded: my_helper
INFO - 2024-09-26 11:32:57 --> Database Driver Class Initialized
INFO - 2024-09-26 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:32:57 --> Controller Class Initialized
DEBUG - 2024-09-26 11:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-26 11:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:32:57 --> Final output sent to browser
DEBUG - 2024-09-26 11:32:57 --> Total execution time: 0.1080
INFO - 2024-09-26 11:37:06 --> Config Class Initialized
INFO - 2024-09-26 11:37:06 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:06 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:06 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:06 --> URI Class Initialized
INFO - 2024-09-26 11:37:06 --> Router Class Initialized
INFO - 2024-09-26 11:37:06 --> Output Class Initialized
INFO - 2024-09-26 11:37:06 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:06 --> Input Class Initialized
INFO - 2024-09-26 11:37:06 --> Language Class Initialized
INFO - 2024-09-26 11:37:06 --> Language Class Initialized
INFO - 2024-09-26 11:37:06 --> Config Class Initialized
INFO - 2024-09-26 11:37:06 --> Loader Class Initialized
INFO - 2024-09-26 11:37:06 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:06 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:06 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:06 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:06 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:06 --> Controller Class Initialized
DEBUG - 2024-09-26 11:37:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-26 11:37:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:37:06 --> Final output sent to browser
DEBUG - 2024-09-26 11:37:06 --> Total execution time: 0.0763
INFO - 2024-09-26 11:37:14 --> Config Class Initialized
INFO - 2024-09-26 11:37:14 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:14 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:14 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:14 --> URI Class Initialized
INFO - 2024-09-26 11:37:14 --> Router Class Initialized
INFO - 2024-09-26 11:37:14 --> Output Class Initialized
INFO - 2024-09-26 11:37:14 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:14 --> Input Class Initialized
INFO - 2024-09-26 11:37:14 --> Language Class Initialized
INFO - 2024-09-26 11:37:14 --> Language Class Initialized
INFO - 2024-09-26 11:37:14 --> Config Class Initialized
INFO - 2024-09-26 11:37:14 --> Loader Class Initialized
INFO - 2024-09-26 11:37:14 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:14 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:14 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:14 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:14 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:15 --> Controller Class Initialized
INFO - 2024-09-26 11:37:15 --> Helper loaded: cookie_helper
INFO - 2024-09-26 11:37:15 --> Final output sent to browser
DEBUG - 2024-09-26 11:37:15 --> Total execution time: 0.0587
INFO - 2024-09-26 11:37:15 --> Config Class Initialized
INFO - 2024-09-26 11:37:15 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:15 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:15 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:15 --> URI Class Initialized
INFO - 2024-09-26 11:37:15 --> Router Class Initialized
INFO - 2024-09-26 11:37:15 --> Output Class Initialized
INFO - 2024-09-26 11:37:15 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:15 --> Input Class Initialized
INFO - 2024-09-26 11:37:15 --> Language Class Initialized
INFO - 2024-09-26 11:37:15 --> Language Class Initialized
INFO - 2024-09-26 11:37:15 --> Config Class Initialized
INFO - 2024-09-26 11:37:15 --> Loader Class Initialized
INFO - 2024-09-26 11:37:15 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:15 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:15 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:15 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:15 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:15 --> Controller Class Initialized
DEBUG - 2024-09-26 11:37:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-26 11:37:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:37:15 --> Final output sent to browser
DEBUG - 2024-09-26 11:37:15 --> Total execution time: 0.0590
INFO - 2024-09-26 11:37:16 --> Config Class Initialized
INFO - 2024-09-26 11:37:16 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:16 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:16 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:16 --> URI Class Initialized
INFO - 2024-09-26 11:37:16 --> Router Class Initialized
INFO - 2024-09-26 11:37:16 --> Output Class Initialized
INFO - 2024-09-26 11:37:16 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:16 --> Input Class Initialized
INFO - 2024-09-26 11:37:16 --> Language Class Initialized
INFO - 2024-09-26 11:37:16 --> Language Class Initialized
INFO - 2024-09-26 11:37:16 --> Config Class Initialized
INFO - 2024-09-26 11:37:16 --> Loader Class Initialized
INFO - 2024-09-26 11:37:16 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:16 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:16 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:16 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:16 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:16 --> Controller Class Initialized
DEBUG - 2024-09-26 11:37:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-26 11:37:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:37:16 --> Final output sent to browser
DEBUG - 2024-09-26 11:37:16 --> Total execution time: 0.0754
INFO - 2024-09-26 11:37:16 --> Config Class Initialized
INFO - 2024-09-26 11:37:16 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:16 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:16 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:16 --> URI Class Initialized
INFO - 2024-09-26 11:37:16 --> Router Class Initialized
INFO - 2024-09-26 11:37:16 --> Output Class Initialized
INFO - 2024-09-26 11:37:16 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:16 --> Input Class Initialized
INFO - 2024-09-26 11:37:16 --> Language Class Initialized
INFO - 2024-09-26 11:37:16 --> Language Class Initialized
INFO - 2024-09-26 11:37:16 --> Config Class Initialized
INFO - 2024-09-26 11:37:16 --> Loader Class Initialized
INFO - 2024-09-26 11:37:16 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:16 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:16 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:16 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:16 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:16 --> Controller Class Initialized
INFO - 2024-09-26 11:37:19 --> Config Class Initialized
INFO - 2024-09-26 11:37:19 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:19 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:19 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:19 --> URI Class Initialized
INFO - 2024-09-26 11:37:19 --> Router Class Initialized
INFO - 2024-09-26 11:37:19 --> Output Class Initialized
INFO - 2024-09-26 11:37:19 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:19 --> Input Class Initialized
INFO - 2024-09-26 11:37:19 --> Language Class Initialized
INFO - 2024-09-26 11:37:19 --> Language Class Initialized
INFO - 2024-09-26 11:37:19 --> Config Class Initialized
INFO - 2024-09-26 11:37:19 --> Loader Class Initialized
INFO - 2024-09-26 11:37:19 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:19 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:19 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:19 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:19 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:19 --> Controller Class Initialized
DEBUG - 2024-09-26 11:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-26 11:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 11:37:19 --> Final output sent to browser
DEBUG - 2024-09-26 11:37:19 --> Total execution time: 0.0378
INFO - 2024-09-26 11:37:23 --> Config Class Initialized
INFO - 2024-09-26 11:37:23 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:37:23 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:37:23 --> Utf8 Class Initialized
INFO - 2024-09-26 11:37:23 --> URI Class Initialized
INFO - 2024-09-26 11:37:23 --> Router Class Initialized
INFO - 2024-09-26 11:37:23 --> Output Class Initialized
INFO - 2024-09-26 11:37:23 --> Security Class Initialized
DEBUG - 2024-09-26 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:37:23 --> Input Class Initialized
INFO - 2024-09-26 11:37:23 --> Language Class Initialized
INFO - 2024-09-26 11:37:23 --> Language Class Initialized
INFO - 2024-09-26 11:37:23 --> Config Class Initialized
INFO - 2024-09-26 11:37:23 --> Loader Class Initialized
INFO - 2024-09-26 11:37:23 --> Helper loaded: url_helper
INFO - 2024-09-26 11:37:23 --> Helper loaded: file_helper
INFO - 2024-09-26 11:37:23 --> Helper loaded: form_helper
INFO - 2024-09-26 11:37:23 --> Helper loaded: my_helper
INFO - 2024-09-26 11:37:23 --> Database Driver Class Initialized
INFO - 2024-09-26 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:37:23 --> Controller Class Initialized
INFO - 2024-09-26 11:37:23 --> Final output sent to browser
DEBUG - 2024-09-26 11:37:23 --> Total execution time: 0.0362
INFO - 2024-09-26 11:38:25 --> Config Class Initialized
INFO - 2024-09-26 11:38:25 --> Hooks Class Initialized
DEBUG - 2024-09-26 11:38:25 --> UTF-8 Support Enabled
INFO - 2024-09-26 11:38:25 --> Utf8 Class Initialized
INFO - 2024-09-26 11:38:25 --> URI Class Initialized
INFO - 2024-09-26 11:38:25 --> Router Class Initialized
INFO - 2024-09-26 11:38:25 --> Output Class Initialized
INFO - 2024-09-26 11:38:25 --> Security Class Initialized
DEBUG - 2024-09-26 11:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 11:38:25 --> Input Class Initialized
INFO - 2024-09-26 11:38:25 --> Language Class Initialized
INFO - 2024-09-26 11:38:25 --> Language Class Initialized
INFO - 2024-09-26 11:38:25 --> Config Class Initialized
INFO - 2024-09-26 11:38:25 --> Loader Class Initialized
INFO - 2024-09-26 11:38:25 --> Helper loaded: url_helper
INFO - 2024-09-26 11:38:25 --> Helper loaded: file_helper
INFO - 2024-09-26 11:38:25 --> Helper loaded: form_helper
INFO - 2024-09-26 11:38:25 --> Helper loaded: my_helper
INFO - 2024-09-26 11:38:25 --> Database Driver Class Initialized
INFO - 2024-09-26 11:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 11:38:25 --> Controller Class Initialized
INFO - 2024-09-26 11:38:25 --> Final output sent to browser
DEBUG - 2024-09-26 11:38:25 --> Total execution time: 0.3220
INFO - 2024-09-26 12:08:35 --> Config Class Initialized
INFO - 2024-09-26 12:08:35 --> Hooks Class Initialized
DEBUG - 2024-09-26 12:08:35 --> UTF-8 Support Enabled
INFO - 2024-09-26 12:08:35 --> Utf8 Class Initialized
INFO - 2024-09-26 12:08:35 --> URI Class Initialized
INFO - 2024-09-26 12:08:35 --> Router Class Initialized
INFO - 2024-09-26 12:08:35 --> Output Class Initialized
INFO - 2024-09-26 12:08:35 --> Security Class Initialized
DEBUG - 2024-09-26 12:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 12:08:35 --> Input Class Initialized
INFO - 2024-09-26 12:08:35 --> Language Class Initialized
INFO - 2024-09-26 12:08:35 --> Language Class Initialized
INFO - 2024-09-26 12:08:35 --> Config Class Initialized
INFO - 2024-09-26 12:08:35 --> Loader Class Initialized
INFO - 2024-09-26 12:08:35 --> Helper loaded: url_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: file_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: form_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: my_helper
INFO - 2024-09-26 12:08:35 --> Database Driver Class Initialized
INFO - 2024-09-26 12:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 12:08:35 --> Controller Class Initialized
INFO - 2024-09-26 12:08:35 --> Helper loaded: cookie_helper
INFO - 2024-09-26 12:08:35 --> Final output sent to browser
DEBUG - 2024-09-26 12:08:35 --> Total execution time: 0.0629
INFO - 2024-09-26 12:08:35 --> Config Class Initialized
INFO - 2024-09-26 12:08:35 --> Hooks Class Initialized
DEBUG - 2024-09-26 12:08:35 --> UTF-8 Support Enabled
INFO - 2024-09-26 12:08:35 --> Utf8 Class Initialized
INFO - 2024-09-26 12:08:35 --> URI Class Initialized
INFO - 2024-09-26 12:08:35 --> Router Class Initialized
INFO - 2024-09-26 12:08:35 --> Output Class Initialized
INFO - 2024-09-26 12:08:35 --> Security Class Initialized
DEBUG - 2024-09-26 12:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 12:08:35 --> Input Class Initialized
INFO - 2024-09-26 12:08:35 --> Language Class Initialized
INFO - 2024-09-26 12:08:35 --> Language Class Initialized
INFO - 2024-09-26 12:08:35 --> Config Class Initialized
INFO - 2024-09-26 12:08:35 --> Loader Class Initialized
INFO - 2024-09-26 12:08:35 --> Helper loaded: url_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: file_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: form_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: my_helper
INFO - 2024-09-26 12:08:35 --> Database Driver Class Initialized
INFO - 2024-09-26 12:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 12:08:35 --> Controller Class Initialized
INFO - 2024-09-26 12:08:35 --> Helper loaded: cookie_helper
INFO - 2024-09-26 12:08:35 --> Config Class Initialized
INFO - 2024-09-26 12:08:35 --> Hooks Class Initialized
DEBUG - 2024-09-26 12:08:35 --> UTF-8 Support Enabled
INFO - 2024-09-26 12:08:35 --> Utf8 Class Initialized
INFO - 2024-09-26 12:08:35 --> URI Class Initialized
INFO - 2024-09-26 12:08:35 --> Router Class Initialized
INFO - 2024-09-26 12:08:35 --> Output Class Initialized
INFO - 2024-09-26 12:08:35 --> Security Class Initialized
DEBUG - 2024-09-26 12:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 12:08:35 --> Input Class Initialized
INFO - 2024-09-26 12:08:35 --> Language Class Initialized
INFO - 2024-09-26 12:08:35 --> Language Class Initialized
INFO - 2024-09-26 12:08:35 --> Config Class Initialized
INFO - 2024-09-26 12:08:35 --> Loader Class Initialized
INFO - 2024-09-26 12:08:35 --> Helper loaded: url_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: file_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: form_helper
INFO - 2024-09-26 12:08:35 --> Helper loaded: my_helper
INFO - 2024-09-26 12:08:35 --> Database Driver Class Initialized
INFO - 2024-09-26 12:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-26 12:08:35 --> Controller Class Initialized
DEBUG - 2024-09-26 12:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-26 12:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-26 12:08:35 --> Final output sent to browser
DEBUG - 2024-09-26 12:08:35 --> Total execution time: 0.0425
