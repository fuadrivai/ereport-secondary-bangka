<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-15 15:54:48 --> Config Class Initialized
INFO - 2024-05-15 15:54:48 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:54:48 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:54:48 --> Utf8 Class Initialized
INFO - 2024-05-15 15:54:48 --> URI Class Initialized
INFO - 2024-05-15 15:54:48 --> Router Class Initialized
INFO - 2024-05-15 15:54:48 --> Output Class Initialized
INFO - 2024-05-15 15:54:48 --> Security Class Initialized
DEBUG - 2024-05-15 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:54:48 --> Input Class Initialized
INFO - 2024-05-15 15:54:48 --> Language Class Initialized
INFO - 2024-05-15 15:54:48 --> Language Class Initialized
INFO - 2024-05-15 15:54:48 --> Config Class Initialized
INFO - 2024-05-15 15:54:48 --> Loader Class Initialized
INFO - 2024-05-15 15:54:48 --> Helper loaded: url_helper
INFO - 2024-05-15 15:54:48 --> Helper loaded: file_helper
INFO - 2024-05-15 15:54:48 --> Helper loaded: form_helper
INFO - 2024-05-15 15:54:48 --> Helper loaded: my_helper
INFO - 2024-05-15 15:54:48 --> Database Driver Class Initialized
INFO - 2024-05-15 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:54:48 --> Controller Class Initialized
DEBUG - 2024-05-15 15:54:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-15 15:54:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-15 15:54:48 --> Final output sent to browser
DEBUG - 2024-05-15 15:54:48 --> Total execution time: 0.0708
INFO - 2024-05-15 15:54:51 --> Config Class Initialized
INFO - 2024-05-15 15:54:51 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:54:51 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:54:51 --> Utf8 Class Initialized
INFO - 2024-05-15 15:54:51 --> URI Class Initialized
INFO - 2024-05-15 15:54:51 --> Router Class Initialized
INFO - 2024-05-15 15:54:51 --> Output Class Initialized
INFO - 2024-05-15 15:54:51 --> Security Class Initialized
DEBUG - 2024-05-15 15:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:54:51 --> Input Class Initialized
INFO - 2024-05-15 15:54:51 --> Language Class Initialized
INFO - 2024-05-15 15:54:51 --> Language Class Initialized
INFO - 2024-05-15 15:54:51 --> Config Class Initialized
INFO - 2024-05-15 15:54:51 --> Loader Class Initialized
INFO - 2024-05-15 15:54:51 --> Helper loaded: url_helper
INFO - 2024-05-15 15:54:51 --> Helper loaded: file_helper
INFO - 2024-05-15 15:54:51 --> Helper loaded: form_helper
INFO - 2024-05-15 15:54:51 --> Helper loaded: my_helper
INFO - 2024-05-15 15:54:51 --> Database Driver Class Initialized
INFO - 2024-05-15 15:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:54:51 --> Controller Class Initialized
INFO - 2024-05-15 15:54:51 --> Helper loaded: cookie_helper
INFO - 2024-05-15 15:54:51 --> Final output sent to browser
DEBUG - 2024-05-15 15:54:51 --> Total execution time: 0.0329
INFO - 2024-05-15 15:54:51 --> Config Class Initialized
INFO - 2024-05-15 15:54:51 --> Hooks Class Initialized
DEBUG - 2024-05-15 15:54:51 --> UTF-8 Support Enabled
INFO - 2024-05-15 15:54:51 --> Utf8 Class Initialized
INFO - 2024-05-15 15:54:51 --> URI Class Initialized
INFO - 2024-05-15 15:54:51 --> Router Class Initialized
INFO - 2024-05-15 15:54:51 --> Output Class Initialized
INFO - 2024-05-15 15:54:51 --> Security Class Initialized
DEBUG - 2024-05-15 15:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-15 15:54:51 --> Input Class Initialized
INFO - 2024-05-15 15:54:51 --> Language Class Initialized
INFO - 2024-05-15 15:54:51 --> Language Class Initialized
INFO - 2024-05-15 15:54:51 --> Config Class Initialized
INFO - 2024-05-15 15:54:51 --> Loader Class Initialized
INFO - 2024-05-15 15:54:51 --> Helper loaded: url_helper
INFO - 2024-05-15 15:54:51 --> Helper loaded: file_helper
INFO - 2024-05-15 15:54:51 --> Helper loaded: form_helper
INFO - 2024-05-15 15:54:51 --> Helper loaded: my_helper
INFO - 2024-05-15 15:54:51 --> Database Driver Class Initialized
INFO - 2024-05-15 15:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-15 15:54:51 --> Controller Class Initialized
DEBUG - 2024-05-15 15:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-05-15 15:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-15 15:54:51 --> Final output sent to browser
DEBUG - 2024-05-15 15:54:51 --> Total execution time: 0.0552
